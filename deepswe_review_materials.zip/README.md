# DeepSWE and Codex review materials — updated 2026-11-11

This is the current source directory for `deepswe_review_materials.zip`.

| Directory | Contents and scope |
|---|---|
| [deepswe_core_evidence_slim](deepswe_core_evidence_slim/README.md) | Historical scores and final patches for 2,879 runs, the frozen label projection, 64 tasks, nine selected interactions and five local repair-replay kits. Historical source files and their checksums are preserved. |
| [deepswe_473_terminal_evidence](deepswe_473_terminal_evidence/README.md) | Current opinions for 473 runs / 546 terminal events and 85 relation types; evidence summaries and source attribution. |
| [deepswe_process_audit_20261110](deepswe_process_audit_20261110/README.md) | A six-task / 12-case descriptive process review, public trajectories, source-linked quotations, annotations, counts, and the Kea public-field forwarding recovery record. |
| [codex_72_baseline_model_responses](codex_72_baseline_model_responses/README.md) | Raw model-event records, readable responses, tasks, final patches, evaluation reports/logs and run information for 72 fixed Codex baselines. [Per-task index](codex_72_baseline_model_responses/INDEX.md); [assistant-assisted mismatch audit](codex_72_baseline_model_responses/AUDIT_REPORT.md). |

## Verify after extraction

```sh
python3 verify.py
```

The verifier checks the complete file inventory and hashes, the historical core, current opinion counts and scope filters, supplied process annotations against public source quotations, and the 72-run Codex audit counts. It does not execute archived shell commands, call coding models, or rerun defect programs. `SHA256SUMS` covers every distributed file except itself.

## Evidence levels

- Current terminal opinions label 473 runs / 546 events as execution-supported: 179 events retain their original execution evidence, and 367 incorporate completed supplementary execution checks. The strict all-undisputed subset is 290 runs / 314 events, with 75 original passes and 215 failures. Original evaluation scores are unchanged.
- The five historical fixed-patch, same-input repair comparisons remain a separate set. Current execution-support counts do not imply 546 independent repair comparisons.
- The process review reads existing public records. It is assistant-assisted, is not an additional human blinded audit, and does not estimate population frequencies or cognitive causes. Six tasks are selected using seed 20261110; events are selected for descriptive case review, with recovery cases supported by complete failure–repair–verification records.
- The six recovery cases comprise three existing-test triggers, two additional-probe triggers, and one agent-added-test trigger. All are already present in the frozen cohort; the full-corpus recovery counts remain 370 runs / 415 events, including 83 runs with terminal diagnoses.

The core README and frozen fields describe their historical release. For the current package inventory and evidence counts, use this root README and the companion directories above. The separate Codex directory contains the raw model-event records for all 72 selected baseline runs. Source hashes identify the associated archived material.

## 中文入口

过程核查材料位于第三个目录：[过程核查报告](deepswe_process_audit_20261110/REPORT.md)。[核查范围与运行方式](deepswe_process_audit_20261110/README.md)说明核验命令和范围。该核验检查已有原文与统计；终态记录分别标明原执行证据与补充执行结果。
