# Codex baseline: astropy__astropy.b0db0daa.test_tree.261bac3c.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the existing VOTable helpers, validation policy machinery, and nearby tests first, then implement only the requested interfaces and run focused tests plus relevant regressions.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "pwd && rg -n \"def check_token|def _get_default_unit_format|def check_astroyear|def check_string|def set_all_tables_format|class VOTableFile\" astropy/utils/xml/check.py astropy/io/votable/tree.py && rg -n \"check_token|check_astroyear|check_string|set_all_tables_format|default_unit_format\" astropy -g '*test*.py'"
```

退出码：`127`

输出：
```
/testbed
/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
`rg` is not available in this environment, so I’m switching to repository-local `grep`/`find` inspection.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "grep -nE \"def check_token|def _get_default_unit_format|def check_astroyear|def check_string|def set_all_tables_format|class VOTableFile\" astropy/utils/xml/check.py astropy/io/votable/tree.py; find astropy -path '*test*.py' -type f -print0 | xargs -0 grep -nE \"check_token|check_astroyear|check_string|set_all_tables_format|default_unit_format\""
```

退出码：`0`

输出：
```
astropy/io/votable/tree.py:4138:class VOTableFile(Element, _IDProperty, _DescriptionProperty):
astropy/utils/tests/test_xml.py:34:def test_check_token():
astropy/utils/tests/test_xml.py:35:    assert check.check_token("token")
astropy/utils/tests/test_xml.py:36:    assert not check.check_token("token\rtoken")
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' astropy/utils/xml/check.py; sed -n '1,260p' astropy/io/votable/tree.py; sed -n '4020,4300p' astropy/io/votable/tree.py; sed -n '1,120p' astropy/utils/tests/test_xml.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
A collection of functions for checking various XML-related strings for
standards compliance.
"""

import re
import urllib.parse




























_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"














def check_mime_content_type(content_type):
    """
    Returns `True` if *content_type* is a valid MIME content type
    (syntactically at least), as defined by RFC 2045.
    """
    ctrls = "".join(chr(x) for x in range(0x20))
    token_regex = f'[^()<>@,;:\\"/[\\]?= {ctrls}\x7f]+'
    return (
        re.match(rf"(?P<type>{token_regex})/(?P<subtype>{token_regex})$", content_type)
        is not None
    )


# Licensed under a 3-clause BSD style license - see LICENSE.rst
# TODO: Test FITS parsing

# STDLIB
import base64
import codecs
import gzip
import io
import json
import os
import re
import urllib.request

# THIRD-PARTY
import numpy as np
from numpy import ma

# LOCAL
from astropy import __version__ as astropy_version
from astropy.io import fits
from astropy.utils import deprecated
from astropy.utils.collections import HomogeneousList
from astropy.utils.data import get_pkg_data_filename
from astropy.utils.xml import iterparser
from astropy.utils.xml.writer import XMLWriter

from . import converters, util, xmlutil
from . import ucd as ucd_mod
from .exceptions import (
    E06,
    E08,
    E09,
    E10,
    E11,
    E12,
    E13,
    E15,
    E16,
    E17,
    E18,
    E19,
    E20,
    E21,
    E22,
    E23,
    E25,
    E26,
    W06,
    W07,
    W08,
    W09,
    W10,
    W11,
    W12,
    W13,
    W15,
    W17,
    W18,
    W19,
    W20,
    W21,
    W22,
    W26,
    W27,
    W28,
    W29,
    W32,
    W33,
    W35,
    W36,
    W37,
    W38,
    W40,
    W41,
    W42,
    W43,
    W44,
    W45,
    W50,
    W52,
    W53,
    W54,
    W56,
    W57,
    vo_raise,
    vo_reraise,
    vo_warn,
    warn_or_raise,
    warn_unknown_attrs,
)

try:
    from . import tablewriter

    _has_c_tabledata_writer = True
except ImportError:
    _has_c_tabledata_writer = False


__all__ = [
    "CooSys",
    "Element",
    "Field",
    "FieldRef",
    "Group",
    "Info",
    "Link",
    "MivotBlock",
    "Param",
    "ParamRef",
    "Resource",
    "TableElement",
    "TimeSys",
    "VOTableFile",
    "Values",
]


# The default number of rows to read in each chunk before converting
# to an array.
DEFAULT_CHUNK_SIZE = 256
RESIZE_AMOUNT = 1.5

######################################################################
# FACTORY FUNCTIONS


def _resize(masked, new_size):
    """
    Masked arrays can not be resized inplace, and `np.resize` and
    `ma.resize` are both incompatible with structured arrays.
    Therefore, we do all this.
    """
    new_array = ma.zeros((new_size,), dtype=masked.dtype)
    length = min(len(masked), new_size)
    new_array[:length] = masked[:length]

    return new_array


def _lookup_by_attr_factory(attr, unique, iterator, element_name, doc):
    """
    Creates a function useful for looking up an element by a given
    attribute.

    Parameters
    ----------
    attr : str
        The attribute name

    unique : bool
        Should be `True` if the attribute is unique and therefore this
        should return only one value.  Otherwise, returns a list of
        values.

    iterator : generator
        A generator that iterates over some arbitrary set of elements

    element_name : str
        The XML element name of the elements being iterated over (used
        for error messages only).

    doc : str
        A docstring to apply to the generated function.

    Returns
    -------
    factory : function
        A function that looks up an element by the given attribute.
    """

    def lookup_by_attr(self, ref, before=None):
        """
        Given a string *ref*, finds the first element in the iterator
        where the given attribute == *ref*.  If *before* is provided,
        will stop searching at the object *before*.  This is
        important, since "forward references" are not allowed in the
        VOTABLE format.
        """
        for element in getattr(self, iterator)():
            if element is before:
                if getattr(element, attr, None) == ref:
                    vo_raise(
                        KeyError,
                        f"{element_name} references itself",
                        element._config,
                        element._pos,
                    )
                break
            if getattr(element, attr, None) == ref:
                yield element

    def lookup_by_attr_unique(self, ref, before=None):
        for element in lookup_by_attr(self, ref, before=before):
            return element
        raise KeyError(
            f"No {element_name} with {attr} '{ref}' found before the referencing "
            f"{element_name}"
        )

    if unique:
        lookup_by_attr_unique.__doc__ = doc
        return lookup_by_attr_unique
    else:
        lookup_by_attr.__doc__ = doc
        return lookup_by_attr


def _lookup_by_id_or_name_factory(iterator, element_name, doc):
    """
    Like `_lookup_by_attr_factory`, but looks in both the "ID" and
    "name" attributes.
    """

    def lookup_by_id_or_name(self, ref, before=None):
        """
        Given an key *ref*, finds the first element in the iterator
        with the attribute ID == *ref* or name == *ref*.  If *before*
        is provided, will stop searching at the object *before*.  This
        is important, since "forward references" are not allowed in
        the VOTABLE format.
        """
        for element in getattr(self, iterator)():
            if element is before:
                if ref in (element.ID, element.name):
                    vo_raise(
                        KeyError,
                        f"{element_name} references itself",
                        element._config,
                        element._pos,
                    )
                break
            if ref in (element.ID, element.name):
                return element
        raise KeyError(
            f"No {element_name} with ID or name '{ref}' found before the referencing "
            f"{element_name}"
        )

    lookup_by_id_or_name.__doc__ = doc
    return lookup_by_id_or_name



















        self._votable = votable

        tag_mapping = {
            "TABLE": self._add_table,
            "INFO": self._add_info,
            "PARAM": self._add_param,
            "GROUP": self._add_group,
            "COOSYS": self._add_coosys,
            "TIMESYS": self._add_timesys,
            "RESOURCE": self._add_resource,
            "LINK": self._add_link,
            "DESCRIPTION": self._ignore_add,
        }

        for start, tag, data, pos in iterator:
            # If the resource content starts with VODML,
            # the parsing is delegated to the MIVOT parser
            if tag == "VODML":
                self._mivot_block.parse(votable, iterator, config)
            elif start:
                tag_mapping.get(tag, self._add_unknown_tag)(
                    iterator, tag, data, config, pos
                )
            elif tag == "DESCRIPTION":
                if self.description is not None:
                    warn_or_raise(W17, W17, "RESOURCE", config, pos)
                self.description = data or None
            elif tag == "RESOURCE":
                break

        del self._votable

        return self

    def to_xml(self, w, **kwargs):
        attrs = w.object_attrs(self, ("ID", "type", "utype"))
        attrs.update(self.extra_attributes)
        with w.tag("RESOURCE", attrib=attrs):
            if self.description is not None:
                w.element("DESCRIPTION", self.description, wrap=True)
            if self.mivot_block is not None and self.type == "meta":
                self.mivot_block.to_xml(w)
            element_sets = [
                self.infos,
                self.coordinate_systems,
                self.time_systems,
                self.params,
                self.links,
            ]
            if kwargs["version_1_2_or_later"]:
                element_sets.append(self.groups)

            for element_set in element_sets:
                for element in element_set:
                    element.to_xml(w, **kwargs)

            # The mivot_block should be before the table
            for elm in self.resources:
                if elm.type == "meta" and elm.mivot_block is not None:
                    elm.to_xml(w, **kwargs)

            for elm in self.tables:
                elm.to_xml(w, **kwargs)

            for elm in self.resources:
                if elm.type != "meta":
                    elm.to_xml(w, **kwargs)

    def iter_tables(self):
        """
        Recursively iterates over all tables in the resource and
        nested resources.
        """
        yield from self.tables
        for resource in self.resources:
            yield from resource.iter_tables()

    def iter_fields_and_params(self):
        """
        Recursively iterates over all FIELD_ and PARAM_ elements in
        the resource, its tables and nested resources.
        """
        yield from self.params
        for table in self.tables:
            yield from table.iter_fields_and_params()
        for resource in self.resources:
            yield from resource.iter_fields_and_params()

    def iter_coosys(self):
        """
        Recursively iterates over all the COOSYS_ elements in the
        resource and nested resources.
        """
        yield from self.coordinate_systems
        for resource in self.resources:
            yield from resource.iter_coosys()

    def iter_timesys(self):
        """
        Recursively iterates over all the TIMESYS_ elements in the
        resource and nested resources.
        """
        yield from self.time_systems
        for resource in self.resources:
            yield from resource.iter_timesys()

    def iter_info(self):
        """
        Recursively iterates over all the INFO_ elements in the
        resource and nested resources.
        """
        yield from self.infos
        for table in self.tables:
            yield from table.iter_info()
        for resource in self.resources:
            yield from resource.iter_info()


class VOTableFile(Element, _IDProperty, _DescriptionProperty):
    """
    VOTABLE_ element: represents an entire file.

    The keyword arguments correspond to setting members of the same
    name, documented below.

    *version* is settable at construction time only, since conformance
    tests for building the rest of the structure depend on it.
    """

    def __init__(self, ID=None, id=None, config=None, pos=None, version="1.4"):
        self._config = config.copy() if config is not None else {}

        # Version setter forces the associated version config settings to
        # be calculated.
        self.version = version
        self._pos = pos

        Element.__init__(self)
        self.ID = resolve_id(ID, id, config, pos)
        self.description = None

        self._coordinate_systems = HomogeneousList(CooSys)
        self._time_systems = HomogeneousList(TimeSys)
        self._params = HomogeneousList(Param)
        self._infos = HomogeneousList(Info)
        self._resources = HomogeneousList(Resource)
        self._groups = HomogeneousList(Group)





    @property
    def config(self):
        """
        Configuration used to construct this object. Will always include the
        version check values.
        """
        return self._config

    @property
    def version(self):
        """
        The version of the VOTable specification that the file uses.
        """
        return self._version

    @version.setter
    def version(self, version):
        version = str(version)
        if version not in self._version_namespace_map:
            allowed_from_map = "', '".join(self._version_namespace_map)
            raise ValueError(
                f"astropy.io.votable version should be in ('{allowed_from_map}')."
            )
        self._version = version
        # Force config update.
        self._config.update(self._get_version_checks())
        self._config["version"] = version

    @property
    def coordinate_systems(self):
        """
        A list of coordinate system descriptions for the file.  Must
        contain only `CooSys` objects.
        """
        return self._coordinate_systems

    @property
    def time_systems(self):
        """
        A list of time system descriptions for the file.  Must
        contain only `TimeSys` objects.
        """
        return self._time_systems

    @property
    def params(self):
        """
        A list of parameters (constant-valued columns) that apply to
        the entire file.  Must contain only `Param` objects.
        """
        return self._params

    @property
    def infos(self):
        """
        A list of informational parameters (key-value pairs) for the
        entire file.  Must only contain `Info` objects.
        """
        return self._infos

    @property
    def resources(self):
        """
        A list of resources, in the order they appear in the file.
        Must only contain `Resource` objects.
        """
        return self._resources

    @property
    def groups(self):
        """
        A list of groups, in the order they appear in the file.  Only
        supported as a child of the VOTABLE element in VOTable 1.2 or
        later.
        """
        return self._groups

    def _add_param(self, iterator, tag, data, config, pos):
        param = Param(self, config=config, pos=pos, **data)
        self.params.append(param)
        param.parse(iterator, config)

    def _add_resource(self, iterator, tag, data, config, pos):
        resource = Resource(config=config, pos=pos, **data)
        self.resources.append(resource)
        resource.parse(self, iterator, config)

    def _add_coosys(self, iterator, tag, data, config, pos):
        coosys = CooSys(config=config, pos=pos, **data)
        self.coordinate_systems.append(coosys)
        coosys.parse(iterator, config)

    def _add_timesys(self, iterator, tag, data, config, pos):
        timesys = TimeSys(config=config, pos=pos, **data)
        self.time_systems.append(timesys)
        timesys.parse(iterator, config)

    def _add_info(self, iterator, tag, data, config, pos):
        info = Info(config=config, pos=pos, **data)
        self.infos.append(info)
        info.parse(iterator, config)

    def _add_group(self, iterator, tag, data, config, pos):
        if not config.get("version_1_2_or_later"):
            warn_or_raise(W26, W26, ("GROUP", "VOTABLE", "1.2"), config, pos)
        group = Group(self, config=config, pos=pos, **data)
        self.groups.append(group)
        group.parse(iterator, config)

    def _get_version_checks(self):
        config = {}
        config["version"] = self.version
        config["version_1_1_or_later"] = util.version_compare(self.version, "1.1") >= 0
        config["version_1_2_or_later"] = util.version_compare(self.version, "1.2") >= 0
        config["version_1_3_or_later"] = util.version_compare(self.version, "1.3") >= 0
        config["version_1_4_or_later"] = util.version_compare(self.version, "1.4") >= 0
        config["version_1_5_or_later"] = util.version_compare(self.version, "1.5") >= 0
        return config

    # Map VOTable version numbers to namespace URIs and schema information.
    _version_namespace_map = {
        # Version 1.0 isn't well-supported, but is allowed on parse (with a warning).
        # It used DTD rather than schema, so this information would not be useful.
        # By omitting 1.0 from this dict we can use the keys as the list of versions
        # that are allowed in various other checks.
        "1.1": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.1",
            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.1",
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import io

import pytest

from astropy.utils.compat.optional_deps import HAS_BLEACH
from astropy.utils.xml import check, unescaper, writer


def test_writer():
    fh = io.StringIO()
    w = writer.XMLWriter(fh)
    with w.tag("html"):
        with w.tag("body"):
            w.data("This is the content")
            w.comment("comment")

    value = "".join(fh.getvalue().split())
    assert value == "<html><body>Thisisthecontent<!--comment--></body></html>"


def test_check_id():
    assert check.check_id("Fof32")
    assert check.check_id("_Fof32")
    assert not check.check_id("32Fof")


def test_fix_id():
    assert check.fix_id("Fof32") == "Fof32"
    assert check.fix_id("@#f") == "___f"


def test_check_token():
    assert check.check_token("token")
    assert not check.check_token("token\rtoken")


def test_check_mime_content_type():
    assert check.check_mime_content_type("image/jpeg")
    assert not check.check_mime_content_type("image")


def test_check_anyuri():
    assert check.check_anyuri("https://github.com/astropy/astropy")


def test_unescape_all():
    # str
    url_in = (
        "http://casu.ast.cam.ac.uk/ag/iphas-dsa%2FSubmitCone?"
        "DSACAT=IDR&amp;amp;DSATAB=Emitters&amp;amp;"
    )
    url_out = (
        "http://casu.ast.cam.ac.uk/ag/iphas-dsa/SubmitCone?DSACAT=IDR&DSATAB=Emitters&"
    )
    assert unescaper.unescape_all(url_in) == url_out

    # bytes
    url_in = (
        b"http://casu.ast.cam.ac.uk/ag/iphas-dsa%2FSubmitCone?"
        b"DSACAT=IDR&amp;amp;DSATAB=Emitters&amp;amp;"
    )
    url_out = (
        b"http://casu.ast.cam.ac.uk/ag/iphas-dsa/SubmitCone?DSACAT=IDR&DSATAB=Emitters&"
    )
    assert unescaper.unescape_all(url_in) == url_out


def test_escape_xml():
    s = writer.xml_escape("This & That")
    assert type(s) == str
    assert s == "This &amp; That"

    s = writer.xml_escape(1)
    assert type(s) == str
    assert s == "1"

    s = writer.xml_escape(b"This & That")
    assert type(s) == bytes
    assert s == b"This &amp; That"


@pytest.mark.skipif(HAS_BLEACH, reason="bleach is installed")
def test_escape_xml_without_bleach():
    fh = io.StringIO()
    w = writer.XMLWriter(fh)

    with pytest.raises(
        ValueError, match=r"bleach package is required when HTML escaping is disabled"
    ):
        with w.xml_cleaning_method("bleach_clean"):
            pass


@pytest.mark.skipif(not HAS_BLEACH, reason="requires bleach")
def test_escape_xml_with_bleach():
    fh = io.StringIO()
    w = writer.XMLWriter(fh)

    # Turn off XML escaping, but still sanitize unsafe tags like <script>
    with w.xml_cleaning_method("bleach_clean"):
        w.start("td")
        w.data("<script>x</script> <em>OK</em>")
        w.end(indent=False)
    assert fh.getvalue() == "<td>&lt;script&gt;x&lt;/script&gt; <em>OK</em></td>\n"

    fh = io.StringIO()
    w = writer.XMLWriter(fh)

    # Default is True (all XML tags escaped)
    with w.xml_cleaning_method():
        w.start("td")
        w.data("<script>x</script> <em>OK</em>")
        w.end(indent=False)
    assert (
        fh.getvalue()
        == "<td>&lt;script&gt;x&lt;/script&gt; &lt;em&gt;OK&lt;/em&gt;</td>\n"
    )
```

## 原始行 16 · command_execution

命令：
```
/bin/bash -lc 'nl -ba astropy/utils/xml/check.py; grep -nE "''^def check_|''^def fix_|''^def _get_default|astroyear|W07|W08|format" astropy/io/votable/tree.py | head -200; grep -R -n "W07'"\\|W08\" astropy/io/votable/tests astropy/io/votable | head -100; grep -R -n \"tabledata_format\\|format =.*binary\\|format.*binary2\\|set_all_tables\" astropy/io/votable | head -200"
```

退出码：`0`

输出：
```
     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	"""
     3	A collection of functions for checking various XML-related strings for
     4	standards compliance.
     5	"""
     6	
     7	import re
     8	import urllib.parse
     9	
    10	
    11	
    12	
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	def check_mime_content_type(content_type):
    53	    """
    54	    Returns `True` if *content_type* is a valid MIME content type
    55	    (syntactically at least), as defined by RFC 2045.
    56	    """
    57	    ctrls = "".join(chr(x) for x in range(0x20))
    58	    token_regex = f'[^()<>@,;:\\"/[\\]?= {ctrls}\x7f]+'
    59	    return (
    60	        re.match(rf"(?P<type>{token_regex})/(?P<subtype>{token_regex})$", content_type)
    61	        is not None
    62	    )
    63	
    64	
49:    W07,
50:    W08,
178:        VOTABLE format.
221:        the VOTABLE format.
281:        supported version checks then version information will be stored in
349:def check_ucd(ucd, config=None, pos=None):
362:        Information about the source of the value
425:        """Extended data type information."""
926:        default_format = _get_default_unit_format(self._config)
927:        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
931:        format = _get_unit_format(self._config)
932:        if format != default_format:
933:            unit_obj = u.Unit(unit, format=format, parse_strict="silent")
1048:        the document, for MIN/MAX/OPTION information.
1512:        file.  Otherwise, it is purely informational -- the Numpy
1514:        information.
1534:        the XML file.  Otherwise, it is purely informational -- the
1536:        information.
1553:    # they're just informational, such as to refer to a coordinate
1558:        On FIELD_ elements, ref is used only for informational
1587:        default_format = _get_default_unit_format(self._config)
1588:        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
1592:        format = _get_unit_format(self._config)
1593:        if format != default_format:
1594:            unit_obj = u.Unit(unit, format=format, parse_strict="silent")
1662:        informational and is not used by the `astropy.io.votable`
1703:            format = _get_unit_format(self._config)
1705:                attrib["unit"] = self.unit.to_string(format)
1722:        to match the information in this `Field`.
1739:            and self.converter.output_format != "{!s:>}"
1741:            column.format = self.converter.output_format
1780:        # TODO: Parse format into precision and width
1981:        check_astroyear(equinox, "equinox", self._config, self._pos)
1998:        check_astroyear(epoch, "epoch", self._config, self._pos)
2332:    This information is currently ignored by the vo package---that is
2334:    information is stored so that it can be written out again to the
2537:        self.format = "tabledata"
2570:        for all metadata (FIELD_, PARAM_ etc.) information.
2602:    def format(self):
2603:        """The serialization format of the table [*required*].
2610:        Note that the 'fits' format, since it requires an external
2612:        format will be read out, by default, in 'tabledata' format.
2616:        return self._format
2618:    @format.setter
2619:    def format(self, format):
2620:        format = format.lower()
2621:        if format == "fits":
2624:                "fits format can not be written out, only read.",
2628:        if format == "binary2":
2636:        elif format not in ("tabledata", "binary"):
2637:            vo_raise(W37, f"Invalid format '{format}'", self._config, self._pos)
2638:        self._format = format
2684:        and parameters are grouped.  Currently this information is
2685:        only kept around for round-tripping and informational
2759:                dtype.append((id, x.converter.format))
2841:            # referenced information
3339:            array = Table.read(fd, format="parquet")
3350:        specified_format = kwargs.get("tabledata_format")
3351:        if specified_format is not None:
3352:            format = specified_format
3354:            format = self.format
3355:        if format == "fits":
3356:            format = "tabledata"
3380:                    if format == "tabledata":
3382:                    elif format == "binary":
3384:                    elif format == "binary2":
3447:                                write(td.format(val))
3666:            self.check_content_format()
3703:        # The content is formatted on the fly: not mandatory but cool for debugging
3772:    def check_content_format(self):
3774:        Check if the content is on xml format by building a VOTable,
3934:        A list of informational parameters (key-value pairs) for the
4227:        A list of informational parameters (key-value pairs) for the
4291:    # Map VOTable version numbers to namespace URIs and schema information.
4294:        # It used DTD rather than schema, so this information would not be useful.
4410:        tabledata_format=None,
4426:        tabledata_format : str, optional
4427:            Override the format of the table(s) data to write.  Must
4429:            ``binary2``.  By default, use the format that was specified
4433:        if tabledata_format is not None:
4434:            if tabledata_format.lower() not in ("tabledata", "binary", "binary2"):
4435:                raise ValueError(f"Unknown format type '{format}'")
4439:            "tabledata_format": tabledata_format,
4457:            w.write(xml_header.lstrip().format(**locals()))
astropy/io/votable/exceptions.py:437:class W07(VOTableSpecWarning):
astropy/io/votable/exceptions.py:458:class W08(VOTableSpecWarning):
astropy/io/votable/tree.py:49:    W07,
astropy/io/votable/tree.py:50:    W08,
astropy/io/votable/connect.py:132:    input, output, table_id=None, overwrite=False, tabledata_format=None
astropy/io/votable/connect.py:152:    tabledata_format : str, optional
astropy/io/votable/connect.py:176:    table_file.to_xml(output, tabledata_format=tabledata_format)
astropy/io/votable/connect.py:254:    votable.to_xml(output, tabledata_format="binary")
astropy/io/votable/table.py:187:def writeto(table, file, tabledata_format=None):
astropy/io/votable/table.py:198:    tabledata_format : str, optional
astropy/io/votable/table.py:215:        file, tabledata_format=tabledata_format, _debug_python_based_parser=True
astropy/io/votable/tests/test_table.py:257:    t.write(output, format="votable", tabledata_format="binary")
astropy/io/votable/tests/test_table.py:264:    t.write(output, format="votable", tabledata_format="binary2")
astropy/io/votable/tests/test_table.py:408:    t.write(fname, format="votable", tabledata_format="binary")
astropy/io/votable/tests/test_table.py:540:    astropy_table.write(output, format="votable", tabledata_format="binary2")
astropy/io/votable/tests/test_table.py:579:    for format_name in ["tabledata", "binary", "binary2"]:
astropy/io/votable/tests/test_table.py:582:        if format_name == "binary2":
astropy/io/votable/tests/test_table.py:637:    table.format = "binary2"
astropy/io/votable/tests/test_table.py:676:    table.format = "binary2"
astropy/io/votable/tests/test_table.py:744:    table.format = "binary2"
astropy/io/votable/tests/test_table.py:782:    for format_name in ["tabledata", "binary", "binary2"]:
astropy/io/votable/tests/test_table.py:785:        if format_name == "binary2":
astropy/io/votable/tests/test_vo.py:126:        votable.get_first_table().format = "binary"
astropy/io/votable/tests/test_vo.py:130:        votable.get_first_table().format = "binary2"
astropy/io/votable/tests/test_vo.py:753:        votable.get_first_table().format = "binary"
astropy/io/votable/tests/test_vo.py:798:        votable.get_first_table().format = "binary2"
astropy/io/votable/tests/test_vo.py:828:@pytest.mark.parametrize("format_", ["binary", "binary2"])
astropy/io/votable/tests/test_vo.py:833:    if format_ == "binary2":
astropy/io/votable/tree.py:2628:        if format == "binary2":
astropy/io/votable/tree.py:3350:        specified_format = kwargs.get("tabledata_format")
astropy/io/votable/tree.py:3382:                    elif format == "binary":
astropy/io/votable/tree.py:3384:                    elif format == "binary2":
astropy/io/votable/tree.py:4410:        tabledata_format=None,
astropy/io/votable/tree.py:4426:        tabledata_format : str, optional
astropy/io/votable/tree.py:4433:        if tabledata_format is not None:
astropy/io/votable/tree.py:4434:            if tabledata_format.lower() not in ("tabledata", "binary", "binary2"):
astropy/io/votable/tree.py:4439:            "tabledata_format": tabledata_format,
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "sed -n '250,410p' astropy/io/votable/tree.py; sed -n '880,960p' astropy/io/votable/tree.py; sed -n '1550,1610p' astropy/io/votable/tree.py; sed -n '2500,2650p' astropy/io/votable/tree.py; sed -n '4300,4510p' astropy/io/votable/tree.py; sed -n '400,490p' astropy/io/votable/exceptions.py; grep -nE \"def warn_or_raise|def vo_warn|def vo_raise\" astropy/io/votable/exceptions.py"
```

退出码：`0`

输出：
```

















def _attach_default_config(votable, config) -> dict:
    """Create default config if none given.

    Parameters
    ----------
    votable
        Object that might potentially have a config attached to it.
    config : `dict` or `None`
        Config to be used or defined.

    Returns
    -------
    config : `dict`
        If config was `None` this will be a new `dict`. If the ``votable``
        supported version checks then version information will be stored in
        the returned `dict`. If it was defined this will be the given
        parameter unchanged.
    """
    if config is None:
        if hasattr(votable, "_get_version_checks"):
            config = votable._get_version_checks()
        else:
            config = {}
    return config


######################################################################
# ATTRIBUTE CHECKERS















































def resolve_id(ID, id, config=None, pos=None):
    if ID is None and id is not None:
        warn_or_raise(W09, W09, (), config, pos)
        return id
    return ID


def check_ucd(ucd, config=None, pos=None):
    """
    Warns or raises a
    `~astropy.io.votable.exceptions.VOTableSpecError` if *ucd* is not
    a valid `unified content descriptor`_ string as defined by the
    VOTABLE standard.

    Parameters
    ----------
    ucd : str
        A UCD string.

    config, pos : optional
        Information about the source of the value
    """
    if config is None:
        config = {}
    if config.get("version_1_1_or_later"):
        try:
            ucd_mod.parse_ucd(
                ucd,
                check_controlled_vocabulary=config.get("version_1_2_or_later", False),
                has_colon=config.get("version_1_2_or_later", False),
            )
        except ValueError as e:
            # This weird construction is for Python 3 compatibility
            if config.get("verify", "ignore") == "exception":
                vo_raise(W06, (ucd, str(e)), config, pos)
            elif config.get("verify", "ignore") == "warn":
                vo_warn(W06, (ucd, str(e)), config, pos)
                return False
            else:
                return False
    return True


######################################################################
# PROPERTY MIXINS
class _IDProperty:
    @property
    def ID(self):
        """
        The XML ID_ of the element.  May be `None` or a string
        conforming to XML ID_ syntax.
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        xmlutil.check_id(ID, "ID", self._config, self._pos)
        self._ID = ID

    @ID.deleter
    def ID(self):
        self._ID = None


class _NameProperty:
    @property
    def name(self):
        """An optional name for the element."""
        return self._name
        return self._ref

    @ref.setter
    def ref(self, ref):
        if ref is not None and not self._config.get("version_1_2_or_later"):
            warn_or_raise(W28, W28, ("ref", "INFO", "1.2"), self._config, self._pos)
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        # TODO: actually apply the reference
        # if ref is not None:
        #     try:
        #         other = self._votable.get_values_by_id(ref, before=self)
        #     except KeyError:
        #         vo_raise(
        #             "VALUES ref='%s', which has not already been defined." %
        #             self.ref, self._config, self._pos, KeyError)
        #     self.null = other.null
        #     self.type = other.type
        #     self.min = other.min
        #     self.min_inclusive = other.min_inclusive
        #     self.max = other.max
        #     self.max_inclusive = other.max_inclusive
        #     self._options[:] = other.options
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def unit(self):
        """A string specifying the units_ for the INFO_."""
        return self._unit

    @unit.setter
    def unit(self, unit):
        if unit is None:
            self._unit = None
            return

        from astropy import units as u

        if not self._config.get("version_1_2_or_later"):
            warn_or_raise(W28, W28, ("unit", "INFO", "1.2"), self._config, self._pos)

        # First, parse the unit in the default way, so that we can
        # still emit a warning if the unit is not to spec.
        default_format = _get_default_unit_format(self._config)
        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
        if isinstance(unit_obj, u.UnrecognizedUnit):
            warn_or_raise(W50, W50, (unit,), self._config, self._pos)

        format = _get_unit_format(self._config)
        if format != default_format:
            unit_obj = u.Unit(unit, format=format, parse_strict="silent")

        self._unit = unit_obj

    @unit.deleter
    def unit(self):
        self._unit = None

    def to_xml(self, w, **kwargs):
        attrib = w.object_attrs(self, self._attr_list)
        if "unit" in attrib:
            attrib["unit"] = self.unit.to_string("cds")
        w.element(self._element_name, self._content, attrib=attrib)


class Values(Element, _IDProperty):
    """
    VALUES_ element: used within FIELD_ and PARAM_ elements to define the domain of values.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    def __init__(
        self,
        votable,
        field,
        ID=None,
        self._width = None

    # ref on FIELD and PARAM behave differently than elsewhere -- here
    # they're just informational, such as to refer to a coordinate
    # system.
    @property
    def ref(self):
        """
        On FIELD_ elements, ref is used only for informational
        purposes, for example to refer to a COOSYS_ or TIMESYS_ element.
        """
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def unit(self):
        """A string specifying the units_ for the FIELD_."""
        return self._unit

    @unit.setter
    def unit(self, unit):
        if unit is None:
            self._unit = None
            return

        from astropy import units as u

        # First, parse the unit in the default way, so that we can
        # still emit a warning if the unit is not to spec.
        default_format = _get_default_unit_format(self._config)
        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
        if isinstance(unit_obj, u.UnrecognizedUnit):
            warn_or_raise(W50, W50, (unit,), self._config, self._pos)

        format = _get_unit_format(self._config)
        if format != default_format:
            unit_obj = u.Unit(unit, format=format, parse_strict="silent")

        self._unit = unit_obj

    @unit.deleter
    def unit(self):
        self._unit = None

    @property
    def arraysize(self):
        """
        Specifies the size of the multidimensional array if this
        FIELD_ contains more than a single value.

        See `multidimensional arrays`_.
        """
        return self._arraysize
    """

    def __init__(
        self,
        votable,
        ID=None,
        name=None,
        ref=None,
        ucd=None,
        utype=None,
        nrows=None,
        id=None,
        config=None,
        pos=None,
        **extra,
    ):
        self._config = _attach_default_config(votable, config)
        self._pos = pos
        self._empty = False

        Element.__init__(self)
        self._votable = votable

        self.ID = resolve_id(ID, id, self._config, pos) or xmlutil.fix_id(
            name, self._config, pos
        )
        self.name = name
        xmlutil.check_id(ref, "ref", self._config, pos)
        self._ref = ref
        self.ucd = ucd
        self.utype = utype
        if nrows is not None:
            nrows = int(nrows)
            if nrows < 0:
                raise ValueError("'nrows' cannot be negative.")
        self._nrows = nrows
        self.description = None
        self.format = "tabledata"

        self._fields = HomogeneousList(Field)
        self._all_fields = HomogeneousList(Field)
        self._params = HomogeneousList(Param)
        self._groups = HomogeneousList(Group)
        self._links = HomogeneousList(Link)
        self._infos = HomogeneousList(Info)

        self.array = ma.array([])

        warn_unknown_attrs("TABLE", extra.keys(), self._config, pos)

    def __repr__(self):
        s = repr(self.to_table())
        if s.startswith("<Table"):
            s = "<VO" + s[1:]
        return s

    def __bytes__(self):
        return bytes(self.to_table())

    def __str__(self):
        return str(self.to_table())

    @property
    def ref(self):
        return self._ref

    @ref.setter
    def ref(self, ref):
        """
        Refer to another TABLE, previously defined, by the *ref* ID_
        for all metadata (FIELD_, PARAM_ etc.) information.
        """
        # When the ref changes, we want to verify that it will work
        # by actually going and looking for the referenced table.
        # If found, set a bunch of properties in this table based
        # on the other one.
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        if ref is not None:
            try:
                table = self._votable.get_table_by_id(ref, before=self)
            except KeyError:
                warn_or_raise(W43, W43, ("TABLE", self.ref), self._config, self._pos)
                ref = None
            else:
                self._fields = table.fields
                self._all_fields = table.all_fields
                self._params = table.params
                self._groups = table.groups
                self._links = table.links
        else:
            del self._fields[:]
            del self._all_fields[:]
            del self._params[:]
            del self._groups[:]
            del self._links[:]
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def format(self):
        """The serialization format of the table [*required*].

        Must be one of:

          'tabledata' (TABLEDATA_), 'binary' (BINARY_), 'binary2' (BINARY2_)
          'fits' (FITS_).

        Note that the 'fits' format, since it requires an external
        file, can not be written out.  Any file read in with 'fits'
        format will be read out, by default, in 'tabledata' format.

        See :ref:`astropy:votable-serialization`.
        """
        return self._format

    @format.setter
    def format(self, format):
        format = format.lower()
        if format == "fits":
            vo_raise(
                NotImplementedError,
                "fits format can not be written out, only read.",
                self._config,
                self._pos,
            )
        if format == "binary2":
            if not self._config.get("version_1_3_or_later"):
                vo_raise(
                    W37,
                    "binary2 only supported in votable 1.3 or later",
                    self._config,
                    self._pos,
                )
        elif format not in ("tabledata", "binary"):
            vo_raise(W37, f"Invalid format '{format}'", self._config, self._pos)
        self._format = format

    @property
    def nrows(self):
        """
        [*immutable*] The number of rows in the table, as specified in
        the XML file.
        """
        return self._nrows

    @property
    def fields(self):
        """
            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.1",
        },
        "1.2": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.2",
            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.2",
        },
        # With 1.3 we'll be more explicit with the schema location.
        # - xsi:schemaLocation uses the namespace name along with the URL
        #   to reference it.
        # - For convenience, but somewhat confusingly, the namespace URIs
        #   are also usable URLs for accessing an applicable schema.
        #   However to avoid confusion, we'll use the explicit schema URL.
        "1.3": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.3.xsd"
            ),
        },
        # With 1.4 namespace URIs stopped incrementing with minor version changes
        # so we use the same URI as with 1.3.  See this IVOA note for more info:
        # http://www.ivoa.net/documents/Notes/XMLVers/20180529/
        "1.4": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.4.xsd"
            ),
        },
        "1.5": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.5.xsd"
            ),
        },
    }

    def parse(self, iterator, config):
        config["_current_table_number"] = 0

        for start, tag, data, pos in iterator:
            if start:
                if tag == "xml":
                    pass
                elif tag == "VOTABLE":
                    if "version" not in data:
                        warn_or_raise(W20, W20, self.version, config, pos)
                        config["version"] = self.version
                    else:
                        config["version"] = self._version = data["version"]
                        if config["version"].lower().startswith("v"):
                            warn_or_raise(W29, W29, config["version"], config, pos)
                            self._version = config["version"] = config["version"][1:]
                        if config["version"] not in self._version_namespace_map:
                            vo_warn(W21, config["version"], config, pos)

                        # Update the configuration of the VOTableFile itself.
                        # This can not be done via the .version property setter
                        # because that refuses to allow votable 1.0.
                        self._config["version"] = config["version"]
                        self._config.update(self._get_version_checks())

                    if "xmlns" in data:
                        ns_info = self._version_namespace_map.get(config["version"], {})
                        correct_ns = ns_info.get("namespace_uri")
                        if data["xmlns"] != correct_ns:
                            vo_warn(W41, (correct_ns, data["xmlns"]), config, pos)
                    else:
                        vo_warn(W42, (), config, pos)

                    break
                else:
                    vo_raise(E19, (), config, pos)
        config.update(self._get_version_checks())

        tag_mapping = {
            "PARAM": self._add_param,
            "RESOURCE": self._add_resource,
            "COOSYS": self._add_coosys,
            "TIMESYS": self._add_timesys,
            "INFO": self._add_info,
            "DEFINITIONS": self._add_definitions,
            "DESCRIPTION": self._ignore_add,
            "GROUP": self._add_group,
        }

        for start, tag, data, pos in iterator:
            if start:
                tag_mapping.get(tag, self._add_unknown_tag)(
                    iterator, tag, data, config, pos
                )
            elif tag == "DESCRIPTION":
                if self.description is not None:
                    warn_or_raise(W17, W17, "VOTABLE", config, pos)
                self.description = data or None

        if not len(self.resources) and config["version_1_2_or_later"]:
            warn_or_raise(W53, W53, (), config, pos)

        return self

    def to_xml(
        self,
        fd,
        compressed=False,
        tabledata_format=None,
        _debug_python_based_parser=False,
        _astropy_version=None,
    ):
        """
        Write to an XML file.

        Parameters
        ----------
        fd : str or file-like
            Where to write the file. If a file-like object, must be writable.

        compressed : bool, optional
            When `True`, write to a gzip-compressed file.  (Default:
            `False`)

        tabledata_format : str, optional
            Override the format of the table(s) data to write.  Must
            be one of ``tabledata`` (text representation), ``binary`` or
            ``binary2``.  By default, use the format that was specified
            in each `TableElement` object as it was created or read in.  See
            :ref:`astropy:votable-serialization`.
        """
        if tabledata_format is not None:
            if tabledata_format.lower() not in ("tabledata", "binary", "binary2"):
                raise ValueError(f"Unknown format type '{format}'")

        kwargs = {
            "version": self.version,
            "tabledata_format": tabledata_format,
            "_debug_python_based_parser": _debug_python_based_parser,
            "_group_number": 1,
        }
        kwargs.update(self._get_version_checks())

        with util.convert_to_writable_filelike(fd, compressed=compressed) as fh:
            w = XMLWriter(fh)
            version = self.version
            if _astropy_version is None:
                lib_version = astropy_version
            else:
                lib_version = _astropy_version

            xml_header = """
<?xml version="1.0" encoding="utf-8"?>
<!-- Produced with astropy.io.votable version {lib_version}
     http://www.astropy.org/ -->\n"""
            w.write(xml_header.lstrip().format(**locals()))

            # Build the VOTABLE tag attributes.
            votable_attr = {
                "version": version,
                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            }
            ns_info = self._version_namespace_map.get(version, {})
            namespace_uri = ns_info.get("namespace_uri")
            if namespace_uri:
                votable_attr["xmlns"] = namespace_uri
            schema_location_attr = ns_info.get("schema_location_attr")
            schema_location_value = ns_info.get("schema_location_value")
            if schema_location_attr and schema_location_value:
                votable_attr[schema_location_attr] = schema_location_value

            with w.tag("VOTABLE", votable_attr):
                if self.description is not None:
                    w.element("DESCRIPTION", self.description, wrap=True)
                element_sets = [
                    self.coordinate_systems,
                    self.time_systems,
                    self.params,
                    self.infos,
                    self.resources,
                ]
                if kwargs["version_1_2_or_later"]:
                    element_sets.append(self.groups)

                for element_set in element_sets:
                    for element in element_set:
                        element.to_xml(w, **kwargs)

    def iter_tables(self):
        """
        Iterates over all tables in the VOTable file in a "flat" way,
        ignoring the nesting of resources etc.
        """
        for resource in self.resources:
            yield from resource.iter_tables()

    def get_first_table(self):
        """
        Often, you know there is only one table in the file, and
        that's all you need.  This method returns that first table.
        """
        for table in self.iter_tables():
            if not table.is_empty():
                return table
        raise IndexError("No table found in VOTABLE file.")

    get_table_by_id = _lookup_by_attr_factory(
        "ID",
        True,
    <http://www.ivoa.net/documents/VOTable/20091130/REC-VOTable-1.2.html#sec:link>`__
    """

    message_template = "content-type '{}' must be a valid MIME content type"
    default_args = ("x",)


class W05(VOTableSpecWarning):
    """
    The attribute must be a valid URI as defined in `RFC 2396
    <https://www.ietf.org/rfc/rfc2396.txt>`_.
    """

    message_template = "'{}' is not a valid URI"
    default_args = ("x",)


class W06(VOTableSpecWarning):
    """
    This warning is emitted when a ``ucd`` attribute does not match
    the syntax of a `unified content descriptor
    <https://vizier.unistra.fr/doc/UCD.htx>`__.

    If the VOTable version is 1.2 or later, the UCD will also be
    checked to ensure it conforms to the controlled vocabulary defined
    by UCD1+.

    **References**: `1.1
    <http://www.ivoa.net/documents/VOTable/20040811/REC-VOTable-1.1-20040811.html#sec:ucd>`__,
    `1.2
    <http://www.ivoa.net/documents/VOTable/20091130/REC-VOTable-1.2.html#sec:ucd>`__
    """

    message_template = "Invalid UCD '{}': {}"
    default_args = ("x", "explanation")


class W07(VOTableSpecWarning):
    """Invalid astroYear.

    As astro year field is a Besselian or Julian year matching the
    regular expression::

        ^[JB]?[0-9]+([.][0-9]*)?$

    Defined in this XML Schema snippet::

        <xs:simpleType  name="astroYear">
          <xs:restriction base="xs:token">
            <xs:pattern  value="[JB]?[0-9]+([.][0-9]*)?"/>
          </xs:restriction>
        </xs:simpleType>
    """

    message_template = "Invalid astroYear in {}: '{}'"
    default_args = ("x", "y")


class W08(VOTableSpecWarning):
    """
    To avoid local-dependent number parsing differences, ``astropy.io.votable``
    may require a string or unicode string where a numeric type may
    make more sense.
    """

    message_template = "'{}' must be a str or bytes object"

    default_args = ("x",)


class W09(VOTableSpecWarning):
    """
    The VOTable specification uses the attribute name ``ID`` (with
    uppercase letters) to specify unique identifiers.  Some
    VOTable-producing tools use the more standard lowercase ``id``
    instead. ``astropy.io.votable`` accepts ``id`` and emits this warning if
    ``verify`` is ``'warn'``.

    **References**: `1.1
    <http://www.ivoa.net/documents/VOTable/20040811/REC-VOTable-1.1-20040811.html#sec:name>`__,
    `1.2
    <http://www.ivoa.net/documents/VOTable/20091130/REC-VOTable-1.2.html#sec:name>`__
    """

    message_template = "ID attribute not capitalized"


class W10(VOTableSpecWarning):
    """
    The parser has encountered an element that does not exist in the
    specification, or appears in an invalid context.  Check the file
98:def warn_or_raise(
118:def vo_raise(exception_class, args=(), config=None, pos=None):
145:def vo_warn(warning_class, args=(), config=None, pos=None, stacklevel=1):
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc "git status --short; git diff -- astropy/utils/xml/check.py astropy/io/votable/tree.py; sed -n '1,180p' astropy/io/votable/exceptions.py; sed -n '1,260p' astropy/io/votable/xmlutil.py; grep -R -n \"_get_unit_format\\|_get_default_unit_format\" astropy/io/votable --exclude=tree.py"
```

退出码：`1`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""VOTable exceptions and warnings.

.. _warnings:

Warnings
--------
.. note::
    Most of the following warnings indicate violations of the VOTable
    specification.  They should be reported to the authors of the
    tools that produced the VOTable file.

    To control the warnings emitted, use the standard Python
    :mod:`warnings` module and the ``astropy.io.votable.exceptions.conf.max_warnings``
    configuration item.  Most of these are of the type `VOTableSpecWarning`.

{warnings}

.. _exceptions:

Exceptions
----------

.. note::

    This is a list of many of the fatal exceptions emitted by ``astropy.io.votable``
    when the file does not conform to spec.  Other exceptions may be
    raised due to unforeseen cases or bugs in ``astropy.io.votable`` itself.

{exceptions}
"""

# STDLIB
import io
import re
from textwrap import dedent
from warnings import warn

from astropy import config as _config
from astropy.utils.exceptions import AstropyWarning

__all__ = [
    "Conf",
    "IOWarning",
    "UnimplementedWarning",
    "VOTableChangeWarning",
    "VOTableSpecError",
    "VOTableSpecWarning",
    "VOWarning",
    "conf",
    "parse_vowarning",
    "vo_raise",
    "vo_reraise",
    "vo_warn",
    "warn_or_raise",
    "warn_unknown_attrs",
]


# NOTE: Cannot put this in __init__.py due to circular import.
class Conf(_config.ConfigNamespace):
    """
    Configuration parameters for `astropy.io.votable.exceptions`.
    """

    max_warnings = _config.ConfigItem(
        10,
        "Number of times the same type of warning is displayed before being suppressed",
        cfgtype="integer",
    )


conf = Conf()
























def warn_or_raise(
    warning_class, exception_class=None, args=(), config=None, pos=None, stacklevel=1
):
    """
    Warn or raise an exception, depending on the verify setting.
    """
    if config is None:
        config = {}
    # NOTE: the default here is deliberately warn rather than ignore, since
    # one would expect that calling warn_or_raise without config should not
    # silence the warnings.
    config_value = config.get("verify", "warn")
    if config_value == "exception":
        if exception_class is None:
            exception_class = warning_class
        vo_raise(exception_class, args, config, pos)
    elif config_value == "warn":
        vo_warn(warning_class, args, config, pos, stacklevel=stacklevel + 1)


def vo_raise(exception_class, args=(), config=None, pos=None):
    """
    Raise an exception, with proper position information if available.
    """
    if config is None:
        config = {}
    raise exception_class(args, config, pos)


def vo_reraise(exc, config=None, pos=None, additional=""):
    """
    Raise an exception, with proper position information if available.

    Restores the original traceback of the exception, and should only
    be called within an "except:" block of code.
    """
    if config is None:
        config = {}
    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
    if message.split()[0] == str(exc).split()[0]:
        message = str(exc)
    if len(additional):
        message += " " + additional
    exc.args = (message,)
    raise exc


def vo_warn(warning_class, args=(), config=None, pos=None, stacklevel=1):
    """
    Warn, with proper position information if available.
    """
    if config is None:
        config = {}
    # NOTE: the default here is deliberately warn rather than ignore, since
    # one would expect that calling warn_or_raise without config should not
    # silence the warnings.
    if config.get("verify", "warn") != "ignore":
        warning = warning_class(args, config, pos)
        _suppressed_warning(warning, config, stacklevel=stacklevel + 1)


def warn_unknown_attrs(element, attrs, config, pos, good_attr=[], stacklevel=1):
    for attr in attrs:
        if attr not in good_attr:
            vo_warn(W48, (attr, element), config, pos, stacklevel=stacklevel + 1)


_warning_pat = re.compile(
    r":?(?P<nline>[0-9?]+):(?P<nchar>[0-9?]+): "
    r"((?P<warning>[WE]\d+): )?(?P<rest>.*)$"
)


def parse_vowarning(line):
    """
    Parses the vo warning string back into its parts.
    """
    result = {}
    match = _warning_pat.search(line)
    if match:
        result["warning"] = warning = match.group("warning")
        if warning is not None:
            result["is_warning"] = warning[0].upper() == "W"
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Various XML-related utilities.
"""

# ASTROPY
from astropy.logger import log
from astropy.utils import data
from astropy.utils.xml import check as xml_check
from astropy.utils.xml import validate

# LOCAL
from .exceptions import W02, W03, W04, W05, vo_warn, warn_or_raise

__all__ = [
    "check_anyuri",
    "check_id",
    "check_mime_content_type",
    "check_token",
    "fix_id",
    "validate_schema",
]


def check_id(ID, name="ID", config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if *ID*
    is not a valid XML ID_.

    *name* is the name of the attribute being checked (used only for
    error messages).
    """
    if ID is not None and not xml_check.check_id(ID):
        warn_or_raise(W02, W02, (name, ID), config, pos)
        return False
    return True


def fix_id(ID, config=None, pos=None):
    """
    Given an arbitrary string, create one that can be used as an xml id.

    This is rather simplistic at the moment, since it just replaces
    non-valid characters with underscores.
    """
    if ID is None:
        return None
    corrected = xml_check.fix_id(ID)
    if corrected != ID:
        vo_warn(W03, (ID, corrected), config, pos)
    return corrected


_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"


def check_token(token, attr_name, config=None, pos=None):
    """
    Raises a `ValueError` if *token* is not a valid XML token.

    As defined by XML Schema Part 2.
    """
    return token is None or xml_check.check_token(token)


def check_mime_content_type(content_type, config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
    *content_type* is not a valid MIME content type.

    As defined by RFC 2045 (syntactically, at least).
    """
    if content_type is not None and not xml_check.check_mime_content_type(content_type):
        warn_or_raise(W04, W04, content_type, config, pos)
        return False
    return True


def check_anyuri(uri, config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
    *uri* is not a valid URI.

    As defined in RFC 2396.
    """
    if uri is not None and not xml_check.check_anyuri(uri):
        warn_or_raise(W05, W05, uri, config, pos)
        return False
    return True


def validate_schema(filename, version="1.1"):
    """
    Validates the given file against the appropriate VOTable schema.

    Parameters
    ----------
    filename : str
        The path to the XML file to validate

    version : str, optional
        The VOTABLE version to check, which must be a string \"1.0\",
        \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
        version \"1.1\" is assumed.

        For version \"1.0\", it is checked against a DTD, since that
        version did not have an XML Schema.

    Returns
    -------
    returncode, stdout, stderr : int, str, str
        Returns the returncode from xmllint and the stdout and stderr
        as strings
    """
    supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]

    if version == "1.0":
        schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
    else:
        if version not in supported_schemas:
            log.info(f"{filename} has version {version}, using schema 1.1")
            version = "1.1"
        schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")

    return validate.validate_schema(filename, schema_path)
```

## 原始行 25 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/utils/tests/test_xml.py astropy/io/votable/tests/test_tree.py -q'
```

退出码：`4`

输出：
```
ERROR: file or directory not found: astropy/io/votable/tests/test_tree.py

Internet access disabled

no tests ran in 0.00s
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "find astropy/io/votable/tests -maxdepth 1 -type f -printf '%f\\n' | sort; python -m pytest astropy/utils/tests/test_xml.py -q"
```

退出码：`1`

输出：
```
__init__.py
test_converter.py
test_coosys.py
test_dataorigin.py
test_exception.py
test_resource.py
test_schema_versions.py
test_table.py
test_ucd.py
test_util.py
test_vo.py
Internet access disabled
.FFF.F...s                                                               [100%]
=================================== FAILURES ===================================
________________________________ test_check_id _________________________________

    def test_check_id():
>       assert check.check_id("Fof32")
               ^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'check_id'

astropy/utils/tests/test_xml.py:24: AttributeError
_________________________________ test_fix_id __________________________________

    def test_fix_id():
>       assert check.fix_id("Fof32") == "Fof32"
               ^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'fix_id'

astropy/utils/tests/test_xml.py:30: AttributeError
_______________________________ test_check_token _______________________________

    def test_check_token():
>       assert check.check_token("token")
               ^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'check_token'

astropy/utils/tests/test_xml.py:35: AttributeError
______________________________ test_check_anyuri _______________________________

    def test_check_anyuri():
>       assert check.check_anyuri("https://github.com/astropy/astropy")
               ^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'check_anyuri'

astropy/utils/tests/test_xml.py:45: AttributeError
=========================== short test summary info ============================
FAILED astropy/utils/tests/test_xml.py::test_check_id - AttributeError: modul...
FAILED astropy/utils/tests/test_xml.py::test_fix_id - AttributeError: module ...
FAILED astropy/utils/tests/test_xml.py::test_check_token - AttributeError: mo...
FAILED astropy/utils/tests/test_xml.py::test_check_anyuri - AttributeError: m...
4 failed, 5 passed, 1 skipped in 0.07s
```

## 原始行 30 · agent_message

```
The source is intentionally masked beyond the four named bodies: `tree.py` also lacks the requested module-level validators, while `check.py` is missing adjacent XML helpers that its existing visible tests and VOTable wrapper call. I’ll restore the smallest coherent helper set needed by these interfaces, without touching parser/writer subsystems.
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
try:
    import astropy.io.votable.tree as t
    print('imported', t)
    for name in ('_get_default_unit_format', '_get_unit_format', 'check_astroyear', 'check_string'):
        print(name, hasattr(t, name))
except Exception:
    import traceback
    traceback.print_exc()
PY
python -m pytest astropy/io/votable/tests/test_coosys.py astropy/io/votable/tests/test_resource.py astropy/io/votable/tests/test_schema_versions.py -q"
```

退出码：`1`

输出：
```
imported <module 'astropy.io.votable.tree' from '/testbed/astropy/io/votable/tree.py'>
_get_default_unit_format False
_get_unit_format False
check_astroyear False
check_string False
Internet access disabled
FFFFFFFFFFFFFFFFF..............                                          [100%]
=================================== FAILURES ===================================
___________________________ test_accept_refposition ____________________________

    def test_accept_refposition():
        for ns_version, version, coosys, expected_warnings in [
            ("1.1", "1.1", COOSYS_NO_REFPOSITION, None),
            ("1.2", "1.2", COOSYS_NO_REFPOSITION, W27),
            ("1.3", "1.3", COOSYS_NO_REFPOSITION, None),
            ("1.3", "1.4", COOSYS_NO_REFPOSITION, None),
            ("1.3", "1.5", COOSYS_NO_REFPOSITION, None),
            ("1.1", "1.1", COOSYS_REFPOSITION, W57),
            ("1.2", "1.2", COOSYS_REFPOSITION, (W27, W57)),
            ("1.3", "1.3", COOSYS_REFPOSITION, W57),
            ("1.3", "1.4", COOSYS_REFPOSITION, W57),
            ("1.3", "1.5", COOSYS_REFPOSITION, None),
        ]:
            xml_string = COOSYS_TEMPLATE.format(ns_version, version, coosys)
            input = io.BytesIO(bytes(xml_string, "utf-8"))
            if expected_warnings is not None:
                with pytest.warns(expected_warnings) as record:
                    vot = parse(input, verify="warn")
                # If expected_warnings is a tuple, pytest.warns checked for at least one of the warnings,
                # so make sure we got the right number of them.
                if isinstance(expected_warnings, tuple):
                    assert len(record) == len(expected_warnings)
            else:
>               vot = parse(input, verify="warn")
                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:56: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7e574ee30360>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
______________________________ test_coosys_system ______________________________

    def test_coosys_system():
        for version, system, expected_warning in [
            ("1.4", "ICRS", None),
            ("1.4", "supergalactic", None),
            ("1.4", "InvalidSystem", E16),
            ("1.5", "ICRS", None),
            ("1.5", "supergalactic", None),
            ("1.5", "InvalidSystem", E16),
        ]:
            xml_string = COOSYS_SYSTEM_TEMPLATE.format(version, system)
            input = io.BytesIO(bytes(xml_string, "utf-8"))
            if expected_warning is not None:
                with pytest.warns(expected_warning):
                    parse(input, verify="warn")
            else:
>               parse(input, verify="warn")

astropy/io/votable/tests/test_coosys.py:74: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7e574ecb75b0>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
_________________________________ test_coosys __________________________________

    def test_coosys():
>       votable = parse(get_pkg_data_filename("data/coosys.xml"))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:99: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = '/testbed/astropy/io/votable/tests/data/coosys.xml'
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
____________________________ test_coosys_roundtrip _____________________________

    def test_coosys_roundtrip():
>       orig_votable = parse(get_pkg_data_filename("data/coosys.xml"))
                       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:104: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = '/testbed/astropy/io/votable/tests/data/coosys.xml'
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
_______ test_coosys_to_astropy_frame_and_time[ICRS-None-None-expected0] ________

system = 'ICRS', equinox = None, epoch = None, expected = <ICRS Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574ee28150>
equinox = None

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
_______ test_coosys_to_astropy_frame_and_time[FK4-B1950-B1950-expected1] _______

system = 'FK4', equinox = 'B1950', epoch = 'B1950'
expected = <FK4 Frame (equinox=B1950.000, obstime=B1950.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574edca710>
equinox = 'B1950'

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
_______ test_coosys_to_astropy_frame_and_time[FK5-J2000-None-expected2] ________

system = 'FK5', equinox = 'J2000', epoch = None
expected = <FK5 Frame (equinox=J2000.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574ede7ad0>
equinox = 'J2000'

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
_____ test_coosys_to_astropy_frame_and_time[eq_FK4-B1950-B1950-expected3] ______

system = 'eq_FK4', equinox = 'B1950', epoch = 'B1950'
expected = <FK4 Frame (equinox=B1950.000, obstime=B1950.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574efd3d50>
equinox = 'B1950'

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
______ test_coosys_to_astropy_frame_and_time[eq_FK5-J2000-None-expected4] ______

system = 'eq_FK5', equinox = 'J2000', epoch = None
expected = <FK5 Frame (equinox=J2000.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574efdabd0>
equinox = 'J2000'

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
_____ test_coosys_to_astropy_frame_and_time[GALACTIC-None-None-expected5] ______

system = 'GALACTIC', equinox = None, epoch = None, expected = <Galactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574f090a90>
equinox = None

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
_____ test_coosys_to_astropy_frame_and_time[galactic-None-None-expected6] ______

system = 'galactic', equinox = None, epoch = None, expected = <Galactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574ee58690>
equinox = None

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
__ test_coosys_to_astropy_frame_and_time[SUPER_GALACTIC-None-None-expected7] ___

system = 'SUPER_GALACTIC', equinox = None, epoch = None
expected = <Supergalactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574f088d50>
equinox = None

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
___ test_coosys_to_astropy_frame_and_time[supergalactic-None-None-expected8] ___

system = 'supergalactic', equinox = None, epoch = None
expected = <Supergalactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574f090a90>
equinox = None

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
______ test_coosys_to_astropy_frame_and_time[AZ_EL-None-J2020-expected9] _______

system = 'AZ_EL', equinox = None, epoch = 'J2020'
expected = <AltAz Frame (obstime=None, location=None, pressure=0.0 hPa, temperature=0.0 deg_C, relative_humidity=0.0, obswl=1.0 micron)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574ee42010>
equinox = None

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
______________________ test_coosys_to_astropy_frame_error ______________________

    def test_coosys_to_astropy_frame_error():
        with pytest.raises(
            ValueError,
            match=(
                "There is no direct correspondence between 'BODY' and an astropy frame.*"
            ),
        ):
>           CooSys(system="BODY").to_astropy_frame()
            ^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:139: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1903: in __init__
    self.equinox = equinox
    ^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_equinox'") raised in repr()] CooSys object at 0x7e574ee0bbd0>
equinox = None

    @equinox.setter
    def equinox(self, equinox):
>       check_astroyear(equinox, "equinox", self._config, self._pos)
        ^^^^^^^^^^^^^^^
E       NameError: name 'check_astroyear' is not defined

astropy/io/votable/tree.py:1981: NameError
_____________________________ test_resource_groups _____________________________

    def test_resource_groups():
        # Read the VOTABLE
>       votable = parse(get_pkg_data_filename("data/resource_groups.xml"))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_resource.py:11: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = '/testbed/astropy/io/votable/tests/data/resource_groups.xml'
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
________________________________ test_roundtrip ________________________________

    def test_roundtrip():
        # Issue #16511 VOTable writer does not write out GROUPs within RESOURCEs
    
        # Read the VOTABLE
>       votable = parse(get_pkg_data_filename("data/resource_groups.xml"))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_resource.py:31: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = '/testbed/astropy/io/votable/tests/data/resource_groups.xml'
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_coosys.py::test_accept_refposition - Nam...
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_system - NameErro...
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys - NameError: name...
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_roundtrip - NameE...
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[ICRS-None-None-expected0]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[FK4-B1950-B1950-expected1]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[FK5-J2000-None-expected2]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[eq_FK4-B1950-B1950-expected3]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[eq_FK5-J2000-None-expected4]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[GALACTIC-None-None-expected5]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[galactic-None-None-expected6]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[SUPER_GALACTIC-None-None-expected7]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[supergalactic-None-None-expected8]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[AZ_EL-None-J2020-expected9]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_error
FAILED astropy/io/votable/tests/test_resource.py::test_resource_groups - Name...
FAILED astropy/io/votable/tests/test_resource.py::test_roundtrip - NameError:...
17 failed, 14 passed in 0.75s
```

## 原始行 36 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"unit_format\" astropy/io/votable astropy/io/votable/tests | head -100; grep -R -n \"check_string(\" astropy/io/votable/tree.py; grep -R -n \"astroYear\\|Invalid astroYear\\|equinox.*invalid\\|W07\\|must be a str or bytes\" astropy/io/votable/tests astropy -g 2>/dev/null | head -200; grep -n \"check_\" astropy/io/votable/tree.py | head -100"
```

退出码：`0`

输出：
```
grep: astropy/io/votable/__pycache__/tree.cpython-311.pyc: binary file matches
grep: astropy/io/votable/__pycache__/exceptions.cpython-311.pyc: binary file matches
grep: astropy/io/votable/__pycache__/table.cpython-311.pyc: binary file matches
astropy/io/votable/exceptions.py:1081:    Consider passing an explicit ``unit_format`` parameter if the units
astropy/io/votable/table.py:40:    unit_format=None,
astropy/io/votable/table.py:104:    unit_format : str, astropy.units.format.Base subclass or None, optional
astropy/io/votable/table.py:151:        "unit_format": unit_format,
astropy/io/votable/tests/test_table.py:164:    t = Table.read(filename, format="votable", unit_format="generic")
astropy/io/votable/tests/test_vo.py:1073:        get_pkg_data_filename("data/nonstandard_units.xml"), unit_format="generic"
astropy/io/votable/tree.py:926:        default_format = _get_default_unit_format(self._config)
astropy/io/votable/tree.py:931:        format = _get_unit_format(self._config)
astropy/io/votable/tree.py:1587:        default_format = _get_default_unit_format(self._config)
astropy/io/votable/tree.py:1592:        format = _get_unit_format(self._config)
astropy/io/votable/tree.py:1703:            format = _get_unit_format(self._config)
astropy/io/votable/tests/test_table.py:164:    t = Table.read(filename, format="votable", unit_format="generic")
astropy/io/votable/tests/test_vo.py:1073:        get_pkg_data_filename("data/nonstandard_units.xml"), unit_format="generic"
434:        check_string(xtype, "xtype", self._config, self._pos)
460:        check_string(utype, "utype", self._config, self._pos)
636:        check_string(content, "content", self._config, self._pos)
857:        check_string(value, "value", self._config, self._pos)
867:        check_string(content, "content", self._config, self._pos)
349:def check_ucd(ucd, config=None, pos=None):
370:                check_controlled_vocabulary=config.get("version_1_2_or_later", False),
398:        xmlutil.check_id(ID, "ID", self._config, self._pos)
414:        xmlutil.check_token(name, "name", self._config, self._pos)
434:        check_string(xtype, "xtype", self._config, self._pos)
460:        check_string(utype, "utype", self._config, self._pos)
489:            check_ucd(ucd, self._config, self._pos)
636:        check_string(content, "content", self._config, self._pos)
733:        xmlutil.check_mime_content_type(content_type, self._config, self._pos)
750:        xmlutil.check_anyuri(href, self._config, self._pos)
842:        xmlutil.check_token(name, "name", self._config, self._pos)
857:        check_string(value, "value", self._config, self._pos)
867:        check_string(content, "content", self._config, self._pos)
886:        xmlutil.check_id(ref, "ref", self._config, self._pos)
1054:        xmlutil.check_id(ref, "ref", self._config, self._pos)
1181:                        xmlutil.check_token(data.get("name"), "name", config, pos)
1565:        xmlutil.check_id(ref, "ref", self._config, self._pos)
1928:        xmlutil.check_id(ID, "ID", self._config, self._pos)
1981:        check_astroyear(equinox, "equinox", self._config, self._pos)
1998:        check_astroyear(epoch, "epoch", self._config, self._pos)
2115:        xmlutil.check_id(ID, "ID", self._config, self._pos)
2238:        xmlutil.check_id(ref, "ref", self._config, self._pos)
2303:        xmlutil.check_id(ref, "ref", self._config, self._pos)
2386:        xmlutil.check_id(ref, "ref", self._config, self._pos)
2527:        xmlutil.check_id(ref, "ref", self._config, pos)
2576:        xmlutil.check_id(ref, "ref", self._config, self._pos)
3122:                        xmlutil.check_anyuri(href, config, pos)
3666:            self.check_content_format()
3772:    def check_content_format(self):
```

## 原始行 39 · command_execution

命令：
```
/bin/bash -lc "grep -R -nE \"astroYear|Invalid astroYear|W07|must be a str or bytes|check_string|check_astroyear|set_all_tables_format\" astropy/io/votable/tests astropy/utils/tests || true; sed -n '1,190p' astropy/io/votable/table.py; sed -n '1050,1100p' astropy/io/votable/exceptions.py; sed -n '390,500p' astropy/io/votable/tree.py; sed -n '600,890p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
This file contains a contains the high-level functions to read a
VOTable file.
"""

# STDLIB
import io
import os
import sys
import textwrap
import warnings

from astropy.utils import data
from astropy.utils.xml import iterparser

# LOCAL
from . import exceptions, tree

__all__ = [
    "from_table",
    "parse",
    "parse_single_table",
    "reset_vo_warnings",
    "validate",
    "writeto",
]


def parse(
    source,
    columns=None,
    invalid="exception",
    verify=None,
    chunk_size=tree.DEFAULT_CHUNK_SIZE,
    table_number=None,
    table_id=None,
    filename=None,
    unit_format=None,
    datatype_mapping=None,
    _debug_python_based_parser=False,
):
    """
    Parses a VOTABLE_ xml file (or file-like object), and returns a
    `~astropy.io.votable.tree.VOTableFile` object.

    Parameters
    ----------
    source : path-like or file-like
        Path or file-like object containing a VOTABLE_ xml file.
        If file, must be readable.

    columns : sequence of str, optional
        List of field names to include in the output.  The default is
        to include all fields.

    invalid : str, optional
        One of the following values:

            - 'exception': throw an exception when an invalid value is
              encountered (default)

            - 'mask': mask out invalid values

    verify : {'ignore', 'warn', 'exception'}, optional
        When ``'exception'``, raise an error when the file violates the spec,
        otherwise either issue a warning (``'warn'``) or silently continue
        (``'ignore'``). Warnings may be controlled using the standard Python
        mechanisms.  See the `warnings` module in the Python standard library
        for more information. When not provided, uses the configuration setting
        ``astropy.io.votable.verify``, which defaults to 'ignore'.

        .. versionchanged:: 4.0
           ``verify`` replaces the ``pedantic`` argument, which will be
           deprecated in future.
        .. versionchanged:: 5.0
            The ``pedantic`` argument is deprecated.
        .. versionchanged:: 6.0
            The ``pedantic`` argument is removed.

    chunk_size : int, optional
        The number of rows to read before converting to an array.
        Higher numbers are likely to be faster, but will consume more
        memory.

    table_number : int, optional
        The number of table in the file to read in.  If `None`, all
        tables will be read.  If a number, 0 refers to the first table
        in the file, and only that numbered table will be parsed and
        read in.  Should not be used with ``table_id``.

    table_id : str, optional
        The ID of the table in the file to read in.  Should not be
        used with ``table_number``.

    filename : str, optional
        A filename, URL or other identifier to use in error messages.
        If *filename* is None and *source* is a string (i.e. a path),
        then *source* will be used as a filename for error messages.
        Therefore, *filename* is only required when source is a
        file-like object.

    unit_format : str, astropy.units.format.Base subclass or None, optional
        The unit format to use when parsing unit attributes.  If a
        string, must be the name of a unit formatter. The built-in
        formats include ``generic``, ``fits``, ``cds``, and
        ``vounit``.  A custom formatter may be provided by passing a
        `~astropy.units.format.Base` subclass.  If `None` (default),
        the unit format to use will be the one specified by the
        VOTable specification (which is ``cds`` up to version 1.3 of
        VOTable, and ``vounit`` in more recent versions of the spec).

    datatype_mapping : dict, optional
        A mapping of datatype names (`str`) to valid VOTable datatype names
        (str). For example, if the file being read contains the datatype
        "unsignedInt" (an invalid datatype in VOTable), include the mapping
        ``{"unsignedInt": "long"}``.

    Returns
    -------
    votable : `~astropy.io.votable.tree.VOTableFile` object

    See Also
    --------
    astropy.io.votable.exceptions : The exceptions this function may raise.
    """
    from . import VERIFY_OPTIONS, conf

    invalid = invalid.lower()
    if invalid not in ("exception", "mask"):
        raise ValueError(
            "accepted values of ``invalid`` are: ``'exception'`` or ``'mask'``."
        )

    if verify is None:
        verify = conf.verify
    elif verify not in VERIFY_OPTIONS:
        raise ValueError(f"verify should be one of {'/'.join(VERIFY_OPTIONS)}")

    if datatype_mapping is None:
        datatype_mapping = {}

    config = {
        "columns": columns,
        "invalid": invalid,
        "verify": verify,
        "chunk_size": chunk_size,
        "table_number": table_number,
        "filename": filename,
        "unit_format": unit_format,
        "datatype_mapping": datatype_mapping,
    }

    if isinstance(source, str):
        source = os.path.expanduser(source)

    if filename is None and isinstance(source, str):
        config["filename"] = source

    with iterparser.get_xml_iterator(
        source, _debug_python_based_parser=_debug_python_based_parser
    ) as iterator:
        return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)


def parse_single_table(source, **kwargs):
    """
    Parses a VOTABLE_ xml file (or file-like object), reading and
    returning only the first `~astropy.io.votable.tree.TableElement`
    instance.

    See `parse` for a description of the keyword arguments.

    Returns
    -------
    votable : `~astropy.io.votable.tree.TableElement` object
    """
    if kwargs.get("table_number") is None:
        kwargs["table_number"] = 0

    votable = parse(source, **kwargs)

    return votable.get_first_table()


def writeto(table, file, tabledata_format=None):
    """
    Writes a `~astropy.io.votable.tree.VOTableFile` to a VOTABLE_ xml file.



class W48(VOTableSpecWarning):
    """
    The attribute is not defined in the specification.
    """

    message_template = "Unknown attribute '{}' on {}"
    default_args = ("attribute", "element")


class W49(VOTableSpecWarning):
    """
    Prior to VOTable 1.3, the empty cell was illegal for integer
    fields.

    If a \"null\" value was specified for the cell, it will be used
    for the value, otherwise, 0 will be used.
    """

    message_template = "Empty cell illegal for integer fields."


class W50(VOTableSpecWarning):
    """
    Invalid unit string as defined in the `Units in the VO, Version 1.0
    <https://www.ivoa.net/documents/VOUnits/20140523/index.html>`_
    (VOTable version >= 1.4) or `Standards for Astronomical Catalogues,
    Version 2.0 <https://cdsarc.cds.unistra.fr/doc/catstd-3.2.htx>`_
    (version < 1.4).

    Consider passing an explicit ``unit_format`` parameter if the units
    in this file conform to another specification.
    """

    message_template = "Invalid unit string '{}'"
    default_args = ("x",)


class W51(VOTableSpecWarning):
    """
    The integer value is out of range for the size of the field.
    """

    message_template = "Value '{}' is out of range for a {} integer field"
    default_args = ("x", "n-bit")


class W52(VOTableSpecWarning):
    """
    The BINARY2 format was introduced in VOTable 1.3.  It should
        """
        The XML ID_ of the element.  May be `None` or a string
        conforming to XML ID_ syntax.
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        xmlutil.check_id(ID, "ID", self._config, self._pos)
        self._ID = ID

    @ID.deleter
    def ID(self):
        self._ID = None


class _NameProperty:
    @property
    def name(self):
        """An optional name for the element."""
        return self._name

    @name.setter
    def name(self, name):
        xmlutil.check_token(name, "name", self._config, self._pos)
        self._name = name

    @name.deleter
    def name(self):
        self._name = None


class _XtypeProperty:
    @property
    def xtype(self):
        """Extended data type information."""
        return self._xtype

    @xtype.setter
    def xtype(self, xtype):
        if xtype is not None and not self._config.get("version_1_2_or_later"):
            warn_or_raise(
                W28, W28, ("xtype", self._element_name, "1.2"), self._config, self._pos
            )
        check_string(xtype, "xtype", self._config, self._pos)
        self._xtype = xtype

    @xtype.deleter
    def xtype(self):
        self._xtype = None


class _UtypeProperty:
    _utype_in_v1_2 = False

    @property
    def utype(self):
        """The usage-specific or `unique type`_ of the element."""
        return self._utype

    @utype.setter
    def utype(self, utype):
        if (
            self._utype_in_v1_2
            and utype is not None
            and not self._config.get("version_1_2_or_later")
        ):
            warn_or_raise(
                W28, W28, ("utype", self._element_name, "1.2"), self._config, self._pos
            )
        check_string(utype, "utype", self._config, self._pos)
        self._utype = utype

    @utype.deleter
    def utype(self):
        self._utype = None


class _UcdProperty:
    _ucd_in_v1_2 = False

    @property
    def ucd(self):
        """The `unified content descriptor`_ for the element."""
        return self._ucd

    @ucd.setter
    def ucd(self, ucd):
        if ucd is not None and ucd.strip() == "":
            ucd = None
        if ucd is not None:
            if self._ucd_in_v1_2 and not self._config.get("version_1_2_or_later"):
                warn_or_raise(
                    W28,
                    W28,
                    ("ucd", self._element_name, "1.2"),
                    self._config,
                    self._pos,
                )
            check_ucd(ucd, self._config, self._pos)
        self._ucd = ucd

    @ucd.deleter
    def ucd(self):
        self._ucd = None


class _DescriptionProperty:
    @property
    def description(self):
        """
class SimpleElementWithContent(SimpleElement):
    """
    A base class for simple elements, such as FIELD, PARAM and INFO
    that don't require any special parsing or outputting machinery.
    """

    def __init__(self):
        SimpleElement.__init__(self)

        self._content = None

    def parse(self, iterator, config):
        for start, tag, data, pos in iterator:
            if start and tag != self._element_name:
                self._add_unknown_tag(iterator, tag, data, config, pos)
            elif tag == self._element_name:
                if data:
                    self.content = data
                break

        return self

    def to_xml(self, w, **kwargs):
        w.element(
            self._element_name,
            self._content,
            attrib=w.object_attrs(self, self._attr_list),
        )

    @property
    def content(self):
        """The content of the element."""
        return self._content

    @content.setter
    def content(self, content):
        check_string(content, "content", self._config, self._pos)
        self._content = content

    @content.deleter
    def content(self):
        self._content = None


class Link(SimpleElement, _IDProperty):
    """
    LINK_ elements: used to reference external documents and servers through a URI.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    _attr_list = [
        "ID",
        "content_role",
        "content_type",
        "title",
        "value",
        "href",
        "action",
    ]
    _element_name = "LINK"

    def __init__(
        self,
        ID=None,
        title=None,
        value=None,
        href=None,
        action=None,
        id=None,
        config=None,
        pos=None,
        **kwargs,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        SimpleElement.__init__(self)

        content_role = kwargs.get("content-role") or kwargs.get("content_role")
        content_type = kwargs.get("content-type") or kwargs.get("content_type")

        if "gref" in kwargs:
            warn_or_raise(W11, W11, (), config, pos)

        self.ID = resolve_id(ID, id, config, pos)
        self.content_role = content_role
        self.content_type = content_type
        self.title = title
        self.value = value
        self.href = href
        self.action = action

        warn_unknown_attrs(
            "LINK",
            kwargs.keys(),
            config,
            pos,
            ["content-role", "content_role", "content-type", "content_type", "gref"],
        )

    @property
    def content_role(self):
        """Defines the MIME role of the referenced object.

        Must be one of:

          None, 'query', 'hints', 'doc', 'location' or 'type'
        """
        return self._content_role

    @content_role.setter
    def content_role(self, content_role):
        if (
            content_role == "type" and not self._config.get("version_1_3_or_later")
        ) or content_role not in (None, "query", "hints", "doc", "location"):
            vo_warn(W45, (content_role,), self._config, self._pos)
        self._content_role = content_role

    @content_role.deleter
    def content_role(self):
        self._content_role = None

    @property
    def content_type(self):
        """Defines the MIME content type of the referenced object."""
        return self._content_type

    @content_type.setter
    def content_type(self, content_type):
        xmlutil.check_mime_content_type(content_type, self._config, self._pos)
        self._content_type = content_type

    @content_type.deleter
    def content_type(self):
        self._content_type = None

    @property
    def href(self):
        """
        A URI to an arbitrary protocol.  The vo package only supports
        http and anonymous ftp.
        """
        return self._href

    @href.setter
    def href(self, href):
        xmlutil.check_anyuri(href, self._config, self._pos)
        self._href = href

    @href.deleter
    def href(self):
        self._href = None

    def to_table_column(self, column):
        meta = {}
        for key in self._attr_list:
            val = getattr(self, key, None)
            if val is not None:
                meta[key] = val

        column.meta.setdefault("links", [])
        column.meta["links"].append(meta)

    @classmethod
    def from_table_column(cls, d):
        return cls(**d)


class Info(SimpleElementWithContent, _IDProperty, _XtypeProperty, _UtypeProperty):
    """
    INFO_ elements: arbitrary key-value pairs for extensions to the standard.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    _element_name = "INFO"
    _attr_list_11 = ["ID", "name", "value"]
    _attr_list_12 = _attr_list_11 + ["xtype", "ref", "unit", "ucd", "utype"]
    _utype_in_v1_2 = True

    def __init__(
        self,
        ID=None,
        name=None,
        value=None,
        id=None,
        xtype=None,
        ref=None,
        unit=None,
        ucd=None,
        utype=None,
        config=None,
        pos=None,
        **extra,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        SimpleElementWithContent.__init__(self)

        self.ID = resolve_id(ID, id, config, pos) or xmlutil.fix_id(name, config, pos)
        self.name = name
        self.value = value
        self.xtype = xtype
        self.ref = ref
        self.unit = unit
        self.ucd = ucd
        self.utype = utype

        if config.get("version_1_2_or_later"):
            self._attr_list = self._attr_list_12
        else:
            self._attr_list = self._attr_list_11
            if xtype is not None:
                warn_unknown_attrs("INFO", ["xtype"], config, pos)
            if ref is not None:
                warn_unknown_attrs("INFO", ["ref"], config, pos)
            if unit is not None:
                warn_unknown_attrs("INFO", ["unit"], config, pos)
            if ucd is not None:
                warn_unknown_attrs("INFO", ["ucd"], config, pos)
            if utype is not None:
                warn_unknown_attrs("INFO", ["utype"], config, pos)

        warn_unknown_attrs("INFO", extra.keys(), config, pos)

    @property
    def name(self):
        """[*required*] The key of the key-value pair."""
        return self._name

    @name.setter
    def name(self, name):
        if name is None:
            warn_or_raise(W35, W35, "name", self._config, self._pos)
        xmlutil.check_token(name, "name", self._config, self._pos)
        self._name = name

    @property
    def value(self):
        """
        [*required*] The value of the key-value pair.  (Always stored
        as a string or unicode string).
        """
        return self._value

    @value.setter
    def value(self, value):
        if value is None:
            warn_or_raise(W35, W35, "value", self._config, self._pos)
        check_string(value, "value", self._config, self._pos)
        self._value = value

    @property
    def content(self):
        """The content inside the INFO element."""
        return self._content

    @content.setter
    def content(self, content):
        check_string(content, "content", self._config, self._pos)
        self._content = content

    @content.deleter
    def content(self):
        self._content = None

    @property
    def ref(self):
        """
        Refer to another INFO_ element by ID_, defined previously in
        the document.
        """
        return self._ref

    @ref.setter
    def ref(self, ref):
        if ref is not None and not self._config.get("version_1_2_or_later"):
            warn_or_raise(W28, W28, ("ref", "INFO", "1.2"), self._config, self._pos)
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        # TODO: actually apply the reference
        # if ref is not None:
        #     try:
        #         other = self._votable.get_values_by_id(ref, before=self)
```

## 原始行 44 · file_change

```
{
  "id": "item_29",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/check.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 47 · file_change

```
{
  "id": "item_31",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 50 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '300,400p'; nl -ba astropy/io/votable/tree.py | sed -n '4170,4225p'; nl -ba astropy/utils/xml/check.py | sed -n '1,120p'"
```

退出码：`0`

输出：
```
   300	def _get_default_unit_format(config):
   301	    """Return the unit syntax prescribed by the configured VOTable version."""
   302	    return "vounit" if config.get("version_1_4_or_later", False) else "cds"
   303	
   304	
   305	def _get_unit_format(config):
   306	    """Return an explicit unit format, or the version-dependent default."""
   307	    return config.get("unit_format") or _get_default_unit_format(config)
   308	
   309	
   310	def check_astroyear(year, field, config=None, pos=None):
   311	    """Validate an astronomical year value from a VOTable attribute."""
   312	    if year is not None and (
   313	        not isinstance(year, str) or _astroyear_re.fullmatch(year) is None
   314	    ):
   315	        warn_or_raise(W07, W07, (field, year), config, pos)
   316	        return False
   317	    return True
   318	
   319	
   320	def check_string(string, attr_name, config=None, pos=None):
   321	    """Validate that a VOTable attribute is a string or bytes value."""
   322	    if string is not None and not isinstance(string, (str, bytes)):
   323	        warn_or_raise(W08, W08, (attr_name,), config, pos)
   324	        return False
   325	    return True
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	def resolve_id(ID, id, config=None, pos=None):
   374	    if ID is None and id is not None:
   375	        warn_or_raise(W09, W09, (), config, pos)
   376	        return id
   377	    return ID
   378	
   379	
   380	def check_ucd(ucd, config=None, pos=None):
   381	    """
   382	    Warns or raises a
   383	    `~astropy.io.votable.exceptions.VOTableSpecError` if *ucd* is not
   384	    a valid `unified content descriptor`_ string as defined by the
   385	    VOTABLE standard.
   386	
   387	    Parameters
   388	    ----------
   389	    ucd : str
   390	        A UCD string.
   391	
   392	    config, pos : optional
   393	        Information about the source of the value
   394	    """
   395	    if config is None:
   396	        config = {}
   397	    if config.get("version_1_1_or_later"):
   398	        try:
   399	            ucd_mod.parse_ucd(
   400	                ucd,
  4170	    """
  4171	    VOTABLE_ element: represents an entire file.
  4172	
  4173	    The keyword arguments correspond to setting members of the same
  4174	    name, documented below.
  4175	
  4176	    *version* is settable at construction time only, since conformance
  4177	    tests for building the rest of the structure depend on it.
  4178	    """
  4179	
  4180	    def __init__(self, ID=None, id=None, config=None, pos=None, version="1.4"):
  4181	        self._config = config.copy() if config is not None else {}
  4182	
  4183	        # Version setter forces the associated version config settings to
  4184	        # be calculated.
  4185	        self.version = version
  4186	        self._pos = pos
  4187	
  4188	        Element.__init__(self)
  4189	        self.ID = resolve_id(ID, id, config, pos)
  4190	        self.description = None
  4191	
  4192	        self._coordinate_systems = HomogeneousList(CooSys)
  4193	        self._time_systems = HomogeneousList(TimeSys)
  4194	        self._params = HomogeneousList(Param)
  4195	        self._infos = HomogeneousList(Info)
  4196	        self._resources = HomogeneousList(Resource)
  4197	        self._groups = HomogeneousList(Group)
  4198	
  4199	
  4200	
  4201	
  4202	
  4203	    @property
  4204	    def config(self):
  4205	        """
  4206	        Configuration used to construct this object. Will always include the
  4207	        version check values.
  4208	        """
  4209	        return self._config
  4210	
  4211	    @property
  4212	    def version(self):
  4213	        """
  4214	        The version of the VOTable specification that the file uses.
  4215	        """
  4216	        return self._version
  4217	
  4218	    @version.setter
  4219	    def version(self, version):
  4220	        version = str(version)
  4221	        if version not in self._version_namespace_map:
  4222	            allowed_from_map = "', '".join(self._version_namespace_map)
  4223	            raise ValueError(
  4224	                f"astropy.io.votable version should be in ('{allowed_from_map}')."
  4225	            )
     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	"""
     3	A collection of functions for checking various XML-related strings for
     4	standards compliance.
     5	"""
     6	
     7	import re
     8	import urllib.parse
     9	
    10	
    11	_id_regex = re.compile(r"^[A-Za-z_][A-Za-z0-9._-]*$")
    12	_id_char_regex = re.compile(r"[^A-Za-z0-9._-]")
    13	
    14	
    15	def check_id(ID):
    16	    """Return whether *ID* has the lexical form of an XML ID."""
    17	    return isinstance(ID, str) and _id_regex.fullmatch(ID) is not None
    18	
    19	
    20	def fix_id(ID):
    21	    """Convert an arbitrary string to the lexical form of an XML ID."""
    22	    if not isinstance(ID, str):
    23	        ID = str(ID)
    24	    if not ID or ID[0] not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_":
    25	        ID = "_" + ID
    26	    return _id_char_regex.sub("_", ID)
    27	
    28	
    29	def check_anyuri(uri):
    30	    """Return whether *uri* can be parsed as an XML ``anyURI`` value."""
    31	    try:
    32	        urllib.parse.urlparse(uri)
    33	    except (AttributeError, TypeError, ValueError):
    34	        return False
    35	    return True
    36	
    37	
    38	def check_token(token):
    39	    """
    40	    Returns `True` if *token* is a valid XML token, as defined by XML
    41	    Schema Part 2.
    42	
    43	    XML ``token`` values may be empty, but may not contain tabs or line
    44	    breaks, leading or trailing spaces, or consecutive spaces.
    45	    """
    46	    if not isinstance(token, str):
    47	        return False
    48	    return (
    49	        "\r" not in token
    50	        and "\n" not in token
    51	        and "\t" not in token
    52	        and not token.startswith(" ")
    53	        and not token.endswith(" ")
    54	        and "  " not in token
    55	    )
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	def check_mime_content_type(content_type):
   100	    """
   101	    Returns `True` if *content_type* is a valid MIME content type
   102	    (syntactically at least), as defined by RFC 2045.
   103	    """
   104	    ctrls = "".join(chr(x) for x in range(0x20))
   105	    token_regex = f'[^()<>@,;:\\"/[\\]?= {ctrls}\x7f]+'
   106	    return (
   107	        re.match(rf"(?P<type>{token_regex})/(?P<subtype>{token_regex})$", content_type)
   108	        is not None
   109	    )
   110
```

## 原始行 53 · file_change

```
{
  "id": "item_35",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 56 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"Info(\\|xtype=.*[0-9]\\|utype=.*[0-9]\\|content=.*bytes\\|value=b\" astropy/io/votable/tests | head -100; python -m pytest astropy/utils/tests/test_xml.py -q; python - <<'PY'
import warnings
from astropy.io.votable.exceptions import W07, W08
from astropy.io.votable.tree import (
    VOTableFile, Resource, TableElement, _get_default_unit_format,
    check_astroyear, check_string,
)

assert _get_default_unit_format({'version_1_4_or_later': True}) == 'vounit'
assert _get_default_unit_format({'version_1_4_or_later': False}) == 'cds'
for value in (None, '2000', '1950.5', 'J2000', 'B1900.0', '2000.'):
    assert check_astroyear(value, 'epoch', {'verify':'exception'})
for value in ('', 'J', '2000AD', '2000.5.0', ' J2000', 'j2000'):
    assert not check_astroyear(value, 'epoch', {'verify':'ignore'})
try:
    check_astroyear('J', 'epoch', {'verify':'exception'})
except W07:
    pass
else:
    raise AssertionError('W07 not raised')
assert check_string(None, 'x', {'verify':'exception'})
assert check_string('x', 'x', {'verify':'exception'})
assert check_string(b'x', 'x', {'verify':'exception'})
assert not check_string(1, 'x', {'verify':'ignore'})
try:
    check_string(1, 'x', {'verify':'exception'})
except W08:
    pass
else:
    raise AssertionError('W08 not raised')

v = VOTableFile(version='1.3')
r = Resource(config=v.config)
v.resources.append(r)
t = TableElement(v, config=v.config)
r.tables.append(t)
v.set_all_tables_format('BINARY2')
assert t.format == 'binary2'
v12 = VOTableFile(version='1.2')
r12 = Resource(config=v12.config)
v12.resources.append(r12)
t12 = TableElement(v12, config=v12.config)
r12.tables.append(t12)
try:
    v12.set_all_tables_format('binary2')
except W07:
    raise AssertionError('wrong exception')
except Exception:
    pass
else:
    raise AssertionError('binary2 accepted for 1.2')
print('direct interface checks passed')
PY"
```

退出码：`1`

输出：
```
astropy/io/votable/tests/data/gemini.xml:99:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="" />
astropy/io/votable/tests/data/gemini.xml:101:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:102:      <PARAM name="TIME" datatype="double" ucd="time;stat.interval" unit="d" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:113:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="" />
astropy/io/votable/tests/data/gemini.xml:115:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:116:      <PARAM name="TIME" datatype="double" ucd="time;stat.interval" unit="d" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:127:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="">
astropy/io/votable/tests/data/gemini.xml:137:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="">
astropy/io/votable/tests/data/gemini.xml:151:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="">
astropy/io/votable/tests/data/gemini.xml:161:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="">
astropy/io/votable/tests/data/binary2_masked_strings.xml:20:<FIELD datatype="double" name="ra" ref="GAIADR2" ucd="pos.eq.ra;meta.main" unit="deg" utype="Char.SpatialAxis.Coverage.Location.Coord.Position2D.Value2.C1">
astropy/io/votable/tests/data/binary2_masked_strings.xml:23:<FIELD datatype="double" name="dec" ref="GAIADR2" ucd="pos.eq.dec;meta.main" unit="deg" utype="Char.SpatialAxis.Coverage.Location.Coord.Position2D.Value2.C2">
Internet access disabled
.........s                                                               [100%]
9 passed, 1 skipped in 0.02s
Traceback (most recent call last):
  File "<stdin>", line 15, in <module>
  File "/testbed/astropy/io/votable/tree.py", line 315, in check_astroyear
    warn_or_raise(W07, W07, (field, year), config, pos)
  File "/testbed/astropy/io/votable/exceptions.py", line 113, in warn_or_raise
    vo_raise(exception_class, args, config, pos)
  File "/testbed/astropy/io/votable/exceptions.py", line 124, in vo_raise
    raise exception_class(args, config, pos)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/votable/exceptions.py", line 231, in __init__
    self.formatted_message = _format_message(
                             ^^^^^^^^^^^^^^^
NameError: name '_format_message' is not defined
```

## 原始行 58 · agent_message

```
The direct checks exposed a required dependency in the repository’s validation path: `warn_or_raise` cannot currently construct W07/W08 because its message-formatting helper is also masked. Since the requested behavior explicitly includes warn/raise policy, I’m repairing that narrow exception helper path before final verification.
```

## 原始行 60 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/exceptions.py | sed -n '130,280p'; sed -n '1,260p' astropy/io/votable/tests/test_exception.py; grep -R -n \"reset_vo_warnings\\|_warning_counts\\|max_warnings\\|_suppressed_warning\\|_format_message\" astropy/io/votable astropy/io/votable/tests | head -200"
```

退出码：`0`

输出：
```
   130	
   131	    Restores the original traceback of the exception, and should only
   132	    be called within an "except:" block of code.
   133	    """
   134	    if config is None:
   135	        config = {}
   136	    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
   137	    if message.split()[0] == str(exc).split()[0]:
   138	        message = str(exc)
   139	    if len(additional):
   140	        message += " " + additional
   141	    exc.args = (message,)
   142	    raise exc
   143	
   144	
   145	def vo_warn(warning_class, args=(), config=None, pos=None, stacklevel=1):
   146	    """
   147	    Warn, with proper position information if available.
   148	    """
   149	    if config is None:
   150	        config = {}
   151	    # NOTE: the default here is deliberately warn rather than ignore, since
   152	    # one would expect that calling warn_or_raise without config should not
   153	    # silence the warnings.
   154	    if config.get("verify", "warn") != "ignore":
   155	        warning = warning_class(args, config, pos)
   156	        _suppressed_warning(warning, config, stacklevel=stacklevel + 1)
   157	
   158	
   159	def warn_unknown_attrs(element, attrs, config, pos, good_attr=[], stacklevel=1):
   160	    for attr in attrs:
   161	        if attr not in good_attr:
   162	            vo_warn(W48, (attr, element), config, pos, stacklevel=stacklevel + 1)
   163	
   164	
   165	_warning_pat = re.compile(
   166	    r":?(?P<nline>[0-9?]+):(?P<nchar>[0-9?]+): "
   167	    r"((?P<warning>[WE]\d+): )?(?P<rest>.*)$"
   168	)
   169	
   170	
   171	def parse_vowarning(line):
   172	    """
   173	    Parses the vo warning string back into its parts.
   174	    """
   175	    result = {}
   176	    match = _warning_pat.search(line)
   177	    if match:
   178	        result["warning"] = warning = match.group("warning")
   179	        if warning is not None:
   180	            result["is_warning"] = warning[0].upper() == "W"
   181	            result["is_exception"] = not result["is_warning"]
   182	            result["number"] = int(match.group("warning")[1:])
   183	            result["doc_url"] = f"io/votable/api_exceptions.html#{warning.lower()}"
   184	        else:
   185	            result["is_warning"] = False
   186	            result["is_exception"] = False
   187	            result["is_other"] = True
   188	            result["number"] = None
   189	            result["doc_url"] = None
   190	        try:
   191	            result["nline"] = int(match.group("nline"))
   192	        except ValueError:
   193	            result["nline"] = 0
   194	        try:
   195	            result["nchar"] = int(match.group("nchar"))
   196	        except ValueError:
   197	            result["nchar"] = 0
   198	        result["message"] = match.group("rest")
   199	        result["is_something"] = True
   200	    else:
   201	        result["warning"] = None
   202	        result["is_warning"] = False
   203	        result["is_exception"] = False
   204	        result["is_other"] = False
   205	        result["is_something"] = False
   206	        if not isinstance(line, str):
   207	            line = line.decode("utf-8")
   208	        result["message"] = line
   209	
   210	    return result
   211	
   212	
   213	class VOWarning(AstropyWarning):
   214	    """
   215	    The base class of all VO warnings and exceptions.
   216	
   217	    Handles the formatting of the message with a warning or exception
   218	    code, filename, line and column number.
   219	    """
   220	
   221	    default_args = ()
   222	    message_template = ""
   223	
   224	    def __init__(self, args, config=None, pos=None):
   225	        if config is None:
   226	            config = {}
   227	        if not isinstance(args, tuple):
   228	            args = (args,)
   229	        msg = self.message_template.format(*args)
   230	
   231	        self.formatted_message = _format_message(
   232	            msg, self.__class__.__name__, config, pos
   233	        )
   234	        Warning.__init__(self, self.formatted_message)
   235	
   236	    def __str__(self):
   237	        return self.formatted_message
   238	
   239	    @classmethod
   240	    def get_short_name(cls):
   241	        if len(cls.default_args):
   242	            return cls.message_template.format(*cls.default_args)
   243	        return cls.message_template
   244	
   245	
   246	class VOTableChangeWarning(VOWarning, SyntaxWarning):
   247	    """
   248	    A change has been made to the input XML file.
   249	    """
   250	
   251	
   252	class VOTableSpecWarning(VOWarning, SyntaxWarning):
   253	    """
   254	    The input XML file violates the spec, but there is an obvious workaround.
   255	    """
   256	
   257	
   258	class ModelMappingSpecWarning(VOWarning, SyntaxWarning):
   259	    """
   260	    The input model mapping XML mapping block violates the spec.
   261	    """
   262	
   263	
   264	class UnimplementedWarning(VOWarning, SyntaxWarning):
   265	    """
   266	    A feature of the VOTABLE_ spec is not implemented.
   267	    """
   268	
   269	
   270	class IOWarning(VOWarning, RuntimeWarning):
   271	    """
   272	    A network or IO error occurred, but was recovered using the cache.
   273	    """
   274	
   275	
   276	class VOTableSpecError(VOWarning, ValueError):
   277	    """
   278	    The input XML file violates the spec and there is no good workaround.
   279	    """
   280	
# Licensed under a 3-clause BSD style license - see LICENSE.rst
import pytest

# LOCAL
from astropy.io.votable import converters, exceptions, tree


def test_reraise():
    def fail():
        raise RuntimeError("This failed")

    with pytest.raises(RuntimeError, match="From here"):
        try:
            fail()
        except RuntimeError as e:
            exceptions.vo_reraise(e, additional="From here")


def test_parse_vowarning():
    config = {"verify": "exception", "filename": "foo.xml"}
    pos = (42, 64)
    with pytest.warns(exceptions.W47) as w:
        field = tree.Field(None, name="c", datatype="char", config=config, pos=pos)
        converters.get_converter(field, config=config, pos=pos)

    parts = exceptions.parse_vowarning(str(w[0].message))

    match = {
        "number": 47,
        "is_exception": False,
        "nchar": 64,
        "warning": "W47",
        "is_something": True,
        "message": "Missing arraysize indicates length 1",
        "doc_url": "io/votable/api_exceptions.html#w47",
        "nline": 42,
        "is_warning": True,
    }
    assert parts == match


def test_suppress_warnings():
    cfg = {}
    warn = exceptions.W01("foo")

    with exceptions.conf.set_temp("max_warnings", 2):
        with pytest.warns(exceptions.W01) as record:
            exceptions._suppressed_warning(warn, cfg)
            assert len(record) == 1
            assert "suppressing" not in str(record[0].message)

        with pytest.warns(exceptions.W01, match="suppressing"):
            exceptions._suppressed_warning(warn, cfg)

        exceptions._suppressed_warning(warn, cfg)

    assert cfg["_warning_counts"][exceptions.W01] == 3
    assert exceptions.conf.max_warnings == 10
grep: astropy/io/votable/__pycache__/exceptions.cpython-311.pyc: binary file matches
grep: astropy/io/votable/__pycache__/table.cpython-311.pyc: binary file matches
astropy/io/votable/exceptions.py:14:    :mod:`warnings` module and the ``astropy.io.votable.exceptions.conf.max_warnings``
astropy/io/votable/exceptions.py:66:    max_warnings = _config.ConfigItem(
astropy/io/votable/exceptions.py:136:    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
astropy/io/votable/exceptions.py:156:        _suppressed_warning(warning, config, stacklevel=stacklevel + 1)
astropy/io/votable/exceptions.py:231:        self.formatted_message = _format_message(
astropy/io/votable/table.py:25:    "reset_vo_warnings",
astropy/io/votable/table.py:261:    reset_vo_warnings()
astropy/io/votable/table.py:409:def reset_vo_warnings():
astropy/io/votable/tests/test_exception.py:46:    with exceptions.conf.set_temp("max_warnings", 2):
astropy/io/votable/tests/test_exception.py:48:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:53:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:55:        exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:57:    assert cfg["_warning_counts"][exceptions.W01] == 3
astropy/io/votable/tests/test_exception.py:58:    assert exceptions.conf.max_warnings == 10
astropy/io/votable/tests/test_exception.py:46:    with exceptions.conf.set_temp("max_warnings", 2):
astropy/io/votable/tests/test_exception.py:48:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:53:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:55:        exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:57:    assert cfg["_warning_counts"][exceptions.W01] == 3
astropy/io/votable/tests/test_exception.py:58:    assert exceptions.conf.max_warnings == 10
```

## 原始行 63 · command_execution

命令：
```
/bin/bash -lc "grep -R -nE \"foo.xml:|W[0-9][0-9]:|E[0-9][0-9]:|suppressing\" astropy/io/votable/tests | head -100; sed -n '390,430p' astropy/io/votable/table.py; sed -n '200,250p' astropy/io/votable/exceptions.py"
```

退出码：`0`

输出：
```
astropy/io/votable/tests/test_table.py:115:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_table.py:142:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_table.py:493:    assert "E02: Incorrect number of elements in array." in validate_out
astropy/io/votable/tests/test_converter.py:91:    with pytest.warns(exceptions.E24, match=r"E24: Attempt to write non-ASCII value"):
astropy/io/votable/tests/test_converter.py:93:    with pytest.warns(exceptions.E24, match=r"E24: Attempt to write non-ASCII value"):
astropy/io/votable/tests/test_converter.py:105:    with pytest.raises(exceptions.E24, match=r"E24: Attempt to write non-ASCII value"):
astropy/io/votable/tests/test_converter.py:113:    with pytest.raises(exceptions.E24, match=r"E24: Attempt to write non-ASCII value"):
astropy/io/votable/tests/data/validation.txt:3:11: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:7:11: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:12:12: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:16:20: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:20:21: W50: Invalid unit string 'foo'
astropy/io/votable/tests/data/validation.txt:24:27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
astropy/io/votable/tests/data/validation.txt:28:28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
astropy/io/votable/tests/data/validation.txt:32:34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
astropy/io/votable/tests/data/validation.txt:36:38: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:40:41: W09: ID attribute not capitalized
astropy/io/votable/tests/data/validation.txt:44:44: W13: 'unicodeString' is not a valid VOTable datatype, should be
astropy/io/votable/tests/data/validation.txt:49:46: W13: 'string' is not a valid VOTable datatype, should be 'char'
astropy/io/votable/tests/data/validation.txt:53:49: W51: Value '-32769' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:57:57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
astropy/io/votable/tests/data/validation.txt:61:98: W17: GROUP element contains more than one DESCRIPTION element
astropy/io/votable/tests/data/validation.txt:65:105: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:69:42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
astropy/io/votable/tests/data/validation.txt:74:113: W46: char value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:78:115: W46: unicodeChar value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:82:116: W46: char value is too long for specified length of 4
astropy/io/votable/tests/data/validation.txt:86:136: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:91:136: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:95:144: W46: char value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:99:147: W46: char value is too long for specified length of 4
astropy/io/votable/tests/data/validation.txt:103:148: W51: Value '256' is out of range for a 8-bit unsigned integer
astropy/io/votable/tests/data/validation.txt:108:149: W51: Value '65536' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:112:152: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:116:155: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:120:171: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:125:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:129:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:133:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:137:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:141:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:145:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:149:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:153:171: W49: Empty cell illegal for integer fields. (suppressing further
astropy/io/votable/tests/data/validation.txt:158:177: W46: unicodeChar value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:162:179: W51: Value '-23' is out of range for a 8-bit unsigned integer
astropy/io/votable/tests/data/validation.txt:167:202: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:172:211: W51: Value '65535' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:176:217: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:180:219: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:185:227: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:190:233: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:195:241: W51: Value '256' is out of range for a 8-bit unsigned integer
astropy/io/votable/tests/data/validation.txt:200:242: W51: Value '65536' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:204:248: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:208:250: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:213:258: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:218:260: E02: Incorrect number of elements in array. Expected multiple of
astropy/io/votable/tests/data/validation.txt:219:  4, got 1 (suppressing further warnings of this type...)
astropy/io/votable/tests/data/validation.txt:223:278: W46: char value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:227:280: W46: unicodeChar value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:231:281: W46: char value is too long for specified length of 4
astropy/io/votable/tests/data/no_resource.txt:3:5: W53: VOTABLE element must contain at least one RESOURCE element.
astropy/io/votable/tests/test_exception.py:50:            assert "suppressing" not in str(record[0].message)
astropy/io/votable/tests/test_exception.py:52:        with pytest.warns(exceptions.W01, match="suppressing"):
astropy/io/votable/tests/test_vo.py:184:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:191:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:198:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:721:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:756:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:785:        # W31: NaN's can not be represented in integer field
astropy/io/votable/tests/test_vo.py:801:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:839:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:1006:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:1215:    assert "E23: Invalid timeorigin attribute 'bad-origin'" in outstr
astropy/io/votable/tests/test_vo.py:1216:    assert "E22: ID attribute is required for all TIMESYS elements" in outstr
astropy/io/votable/tests/test_vo.py:1217:    assert "W48: Unknown attribute 'refposition_mispelled' on TIMESYS" in outstr
    if isinstance(source, str):
        source = os.path.expanduser(source)
    try:
        with iterparser.get_xml_iterator(source) as iterator:
            for start, tag, d, pos in iterator:
                if tag != "xml":
                    return False
                break

            for start, tag, d, pos in iterator:
                if tag != "VOTABLE":
                    return False
                break

            return True
    except ValueError:
        return False


def reset_vo_warnings():
    """
    Resets all of the vo warning state so that warnings that
    have already been emitted will be emitted again. This is
    used, for example, by `validate` which must emit all
    warnings each time it is called.

    """
    from . import converters, xmlutil

    # -----------------------------------------------------------#
    #  This is a special variable used by the Python warnings    #
    #  infrastructure to keep track of warnings that have        #
    #  already been seen.  Since we want to get every single     #
    #  warning out of this, we have to delete all of them first. #
    # -----------------------------------------------------------#
    for module in (converters, exceptions, tree, xmlutil):
        try:
            del module.__warningregistry__
        except AttributeError:
            pass
    else:
        result["warning"] = None
        result["is_warning"] = False
        result["is_exception"] = False
        result["is_other"] = False
        result["is_something"] = False
        if not isinstance(line, str):
            line = line.decode("utf-8")
        result["message"] = line

    return result


class VOWarning(AstropyWarning):
    """
    The base class of all VO warnings and exceptions.

    Handles the formatting of the message with a warning or exception
    code, filename, line and column number.
    """

    default_args = ()
    message_template = ""

    def __init__(self, args, config=None, pos=None):
        if config is None:
            config = {}
        if not isinstance(args, tuple):
            args = (args,)
        msg = self.message_template.format(*args)

        self.formatted_message = _format_message(
            msg, self.__class__.__name__, config, pos
        )
        Warning.__init__(self, self.formatted_message)

    def __str__(self):
        return self.formatted_message

    @classmethod
    def get_short_name(cls):
        if len(cls.default_args):
            return cls.message_template.format(*cls.default_args)
        return cls.message_template


class VOTableChangeWarning(VOWarning, SyntaxWarning):
    """
    A change has been made to the input XML file.
    """
```

## 原始行 66 · file_change

```
{
  "id": "item_44",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/exceptions.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 69 · command_execution

命令：
```
/bin/bash -lc "python -m pytest astropy/io/votable/tests/test_exception.py astropy/utils/tests/test_xml.py -q
python - <<'PY'
from astropy.io.votable.exceptions import W07, W08, W37
from astropy.io.votable.tree import (
    VOTableFile, Resource, TableElement, _get_default_unit_format,
    check_astroyear, check_string,
)

assert _get_default_unit_format({'version_1_4_or_later': True}) == 'vounit'
assert _get_default_unit_format({'version_1_4_or_later': False}) == 'cds'
for value in (None, '2000', '1950.5', 'J2000', 'B1900.0', '2000.'):
    assert check_astroyear(value, 'epoch', {'verify':'exception'})
for value in ('', 'J', '2000AD', '2000.5.0', ' J2000', 'j2000'):
    assert not check_astroyear(value, 'epoch', {'verify':'ignore'})
try:
    check_astroyear('J', 'epoch', {'verify':'exception'})
except W07:
    pass
else:
    raise AssertionError('W07 not raised')
assert check_string(None, 'x', {'verify':'exception'})
assert check_string('x', 'x', {'verify':'exception'})
assert check_string(b'x', 'x', {'verify':'exception'})
assert not check_string(1, 'x', {'verify':'ignore'})
try:
    check_string(1, 'x', {'verify':'exception'})
except W08:
    pass
else:
    raise AssertionError('W08 not raised')

v = VOTableFile(version='1.3')
r = Resource(config=v.config)
v.resources.append(r)
t = TableElement(v, config=v.config)
r.tables.append(t)
v.set_all_tables_format('BINARY2')
assert t.format == 'binary2'
v12 = VOTableFile(version='1.2')
r12 = Resource(config=v12.config)
v12.resources.append(r12)
t12 = TableElement(v12, config=v12.config)
r12.tables.append(t12)
try:
    v12.set_all_tables_format('binary2')
except W37:
    pass
else:
    raise AssertionError('binary2 accepted for 1.2')
print('direct interface checks passed')
PY"
```

退出码：`0`

输出：
```
Internet access disabled
.F..........s                                                            [100%]
=================================== FAILURES ===================================
_____________________________ test_parse_vowarning _____________________________

    def test_parse_vowarning():
        config = {"verify": "exception", "filename": "foo.xml"}
        pos = (42, 64)
        with pytest.warns(exceptions.W47) as w:
>           field = tree.Field(None, name="c", datatype="char", config=config, pos=pos)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_exception.py:23: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1463: in __init__
    self.values = Values(self._votable, self)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1014: in __init__
    self.min = None
    ^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'Values' object has no attribute '_max'") raised in repr()] Values object at 0x71b8800d7790>
min = None

    @min.setter
    def min(self, min):
>       self._min = self._parse_minmax(min)
                    ^^^^^^^^^^^^^^^^^^
E       AttributeError: 'Values' object has no attribute '_parse_minmax'

astropy/io/votable/tree.py:1115: AttributeError

During handling of the above exception, another exception occurred:

    def test_parse_vowarning():
        config = {"verify": "exception", "filename": "foo.xml"}
        pos = (42, 64)
>       with pytest.warns(exceptions.W47) as w:
E       Failed: DID NOT WARN. No warnings of type (<class 'astropy.io.votable.exceptions.W47'>,) were emitted.
E        Emitted warnings: [].

astropy/io/votable/tests/test_exception.py:22: Failed
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_exception.py::test_parse_vowarning - Fai...
1 failed, 11 passed, 1 skipped in 0.14s
direct interface checks passed
```

## 原始行 71 · agent_message

```
The requested interfaces now pass direct behavioral checks, including version gating for `binary2`, both verification modes for W07/W08, empty and whitespace-sensitive XML tokens, and the 1.4 unit-format switch. I’m reviewing the diff and running the nearest tests that do not depend on the intentionally unimplemented parser stack.
```

## 原始行 73 · command_execution

命令：
```
/bin/bash -lc 'git diff --check; git diff --stat; git diff -- astropy/utils/xml/check.py astropy/io/votable/tree.py astropy/io/votable/exceptions.py; python -m pytest astropy/io/votable/tests/test_schema_versions.py astropy/utils/tests/test_xml.py -q'
```

退出码：`0`

输出：
```
 astropy/io/votable/exceptions.py | 34 +++++++++++++++++++++++++++-
 astropy/io/votable/tree.py       | 39 +++++++++++++++++++++++++++++++-
 astropy/utils/xml/check.py       | 48 +++++++++++++++++++++++++++++++++++++++-
 3 files changed, 118 insertions(+), 3 deletions(-)
diff --git a/astropy/io/votable/exceptions.py b/astropy/io/votable/exceptions.py
index cda29c9..f2af3c2 100644
--- a/astropy/io/votable/exceptions.py
+++ b/astropy/io/votable/exceptions.py
@@ -73,6 +73,38 @@ class Conf(_config.ConfigNamespace):
 conf = Conf()
 
 
+def _format_message(message, warning_name, config=None, pos=None):
+    """Add source location and warning code information to a message."""
+    if config is None:
+        config = {}
+    if pos is None:
+        pos = ("?", "?")
+    filename = config.get("filename")
+    location = f"{pos[0]}:{pos[1]}"
+    if filename:
+        location = f"{filename}:{location}"
+    return f"{location}: {warning_name}: {message}"
+
+
+def _suppressed_warning(warning, config=None, stacklevel=1):
+    """Emit repeated warning classes only up to ``conf.max_warnings``."""
+    if config is None:
+        config = {}
+    counts = config.setdefault("_warning_counts", {})
+    warning_class = warning.__class__
+    count = counts.get(warning_class, 0)
+    counts[warning_class] = count + 1
+
+    if count >= conf.max_warnings:
+        return
+    if count == conf.max_warnings - 1:
+        warning.formatted_message += (
+            " (suppressing further warnings of this type...)"
+        )
+        warning.args = (warning.formatted_message,)
+    warn(warning, stacklevel=stacklevel + 1)
+
+
 
 
 
@@ -1609,4 +1641,4 @@ if __doc__ is not None:
     __doc__ = __doc__.format(**_build_doc_string())
 
 __all__ += [x[0] for x in _get_warning_and_exception_classes("W")]
-__all__ += [x[0] for x in _get_warning_and_exception_classes("E")]
\ No newline at end of file
+__all__ += [x[0] for x in _get_warning_and_exception_classes("E")]
diff --git a/astropy/io/votable/tree.py b/astropy/io/votable/tree.py
index 87e4db2..77b7fb7 100644
--- a/astropy/io/votable/tree.py
+++ b/astropy/io/votable/tree.py
@@ -294,6 +294,37 @@ def _attach_default_config(votable, config) -> dict:
 # ATTRIBUTE CHECKERS
 
 
+_astroyear_re = re.compile(r"^[JB]?[0-9]+(?:[.][0-9]*)?$")
+
+
+def _get_default_unit_format(config):
+    """Return the unit syntax prescribed by the configured VOTable version."""
+    return "vounit" if config.get("version_1_4_or_later", False) else "cds"
+
+
+def _get_unit_format(config):
+    """Return an explicit unit format, or the version-dependent default."""
+    return config.get("unit_format") or _get_default_unit_format(config)
+
+
+def check_astroyear(year, field, config=None, pos=None):
+    """Validate an astronomical year value from a VOTable attribute."""
+    if year is not None and (
+        not isinstance(year, str) or _astroyear_re.fullmatch(year) is None
+    ):
+        warn_or_raise(W07, W07, (field, year), config, pos)
+        return False
+    return True
+
+
+def check_string(string, attr_name, config=None, pos=None):
+    """Validate that a VOTable attribute is a string or bytes value."""
+    if string is not None and not isinstance(string, (str, bytes)):
+        warn_or_raise(W08, W08, (attr_name,), config, pos)
+        return False
+    return True
+
+
 
 
 
@@ -4166,6 +4197,12 @@ class VOTableFile(Element, _IDProperty, _DescriptionProperty):
         self._groups = HomogeneousList(Group)
 
 
+    def set_all_tables_format(self, format):
+        """Set the output storage format for every table in this file."""
+        for table in self.iter_tables():
+            table.format = format
+
+
 
 
 
@@ -4703,4 +4740,4 @@ class VOTableFile(Element, _IDProperty, _DescriptionProperty):
             votable.ID = table_id
         resource.tables.append(votable)
         votable_file.resources.append(resource)
-        return votable_file
\ No newline at end of file
+        return votable_file
diff --git a/astropy/utils/xml/check.py b/astropy/utils/xml/check.py
index 1f711a6..5c99019 100644
--- a/astropy/utils/xml/check.py
+++ b/astropy/utils/xml/check.py
@@ -8,6 +8,53 @@ import re
 import urllib.parse
 
 
+_id_regex = re.compile(r"^[A-Za-z_][A-Za-z0-9._-]*$")
+_id_char_regex = re.compile(r"[^A-Za-z0-9._-]")
+
+
+def check_id(ID):
+    """Return whether *ID* has the lexical form of an XML ID."""
+    return isinstance(ID, str) and _id_regex.fullmatch(ID) is not None
+
+
+def fix_id(ID):
+    """Convert an arbitrary string to the lexical form of an XML ID."""
+    if not isinstance(ID, str):
+        ID = str(ID)
+    if not ID or ID[0] not in "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz_":
+        ID = "_" + ID
+    return _id_char_regex.sub("_", ID)
+
+
+def check_anyuri(uri):
+    """Return whether *uri* can be parsed as an XML ``anyURI`` value."""
+    try:
+        urllib.parse.urlparse(uri)
+    except (AttributeError, TypeError, ValueError):
+        return False
+    return True
+
+
+def check_token(token):
+    """
+    Returns `True` if *token* is a valid XML token, as defined by XML
+    Schema Part 2.
+
+    XML ``token`` values may be empty, but may not contain tabs or line
+    breaks, leading or trailing spaces, or consecutive spaces.
+    """
+    if not isinstance(token, str):
+        return False
+    return (
+        "\r" not in token
+        and "\n" not in token
+        and "\t" not in token
+        and not token.startswith(" ")
+        and not token.endswith(" ")
+        and "  " not in token
+    )
+
+
 
 
 
@@ -61,4 +108,3 @@ def check_mime_content_type(content_type):
         is not None
     )
 
-
Internet access disabled
.......................s                                                 [100%]
23 passed, 1 skipped in 0.08s
```

## 原始行 76 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import warnings
from astropy.io.votable.exceptions import W07, W08, W37
from astropy.io.votable.tree import VOTableFile, Resource, TableElement, check_astroyear, check_string
from astropy.utils.xml.check import check_token

valid_tokens = ['', 'a', 'a b', 'a  b'.replace('  ', ' '), 'é x']
invalid_tokens = [' ', ' a', 'a ', 'a  b', 'a\\tb', 'a\\nb', 'a\\rb']
assert all(check_token(x) for x in valid_tokens)
assert not any(check_token(x) for x in invalid_tokens)

for func, args, warning_type in [
    (check_astroyear, ('2000AD', 'epoch'), W07),
    (check_string, (12, 'name'), W08),
]:
    with warnings.catch_warnings(record=True) as seen:
        warnings.simplefilter('always')
        assert func(*args, config={'verify': 'warn'}, pos=(2, 3)) is False
        assert len(seen) == 1 and isinstance(seen[0].message, warning_type)
    try:
        func(*args, config={'verify': 'exception'}, pos=(2, 3))
    except warning_type:
        pass
    else:
        raise AssertionError(f'{warning_type.__name__} not raised')

v = VOTableFile(version='1.4')
r1 = Resource(config=v.config)
r2 = Resource(config=v.config)
v.resources.append(r1)
r1.resources.append(r2)
for resource in (r1, r2):
    resource.tables.append(TableElement(v, config=v.config))
for fmt in ('tabledata', 'binary', 'binary2'):
    v.set_all_tables_format(fmt)
    assert [t.format for t in v.iter_tables()] == [fmt, fmt]
try:
    v.set_all_tables_format('fits')
except NotImplementedError:
    pass
else:
    raise AssertionError('fits accepted')
print('edge checks passed')
PY
python -m compileall -q astropy/utils/xml/check.py astropy/io/votable/tree.py astropy/io/votable/exceptions.py
git status --short"
```

退出码：`0`

输出：
```
edge checks passed
 M astropy/io/votable/exceptions.py
 M astropy/io/votable/tree.py
 M astropy/utils/xml/check.py
```

## 原始行 79 · command_execution

命令：
```
/bin/bash -lc "python -m pytest astropy/io/votable/tests/test_coosys.py -q -k 'to_astropy_frame' astropy/io/votable/tests/test_table.py -q -k 'format'"
```

退出码：`1`

输出：
```
Internet access disabled
F                                                                        [100%]
=================================== FAILURES ===================================
____________________________ test_write_with_format ____________________________

    def test_write_with_format():
        t = Table()
        c = Column(data=[1, 2, 3], name="a")
        t.add_column(c)
    
        output = io.BytesIO()
>       t.write(output, format="votable", tabledata_format="binary")

astropy/io/votable/tests/test_table.py:257: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:130: in __call__
    self.registry.write(instance, *args, **kwargs)
astropy/io/registry/core.py:386: in write
    return writer(data, *args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:173: in write_table_votable
    table_file = from_table(input, table_id=table_id)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/table.py:372: in from_table
    return tree.VOTableFile.from_table(table, table_id=table_id)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4738: in from_table
    votable = TableElement.from_table(votable_file, table)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:3594: in from_table
    new_table.add_field(Field.from_table_column(votable, column))
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1802: in from_table_column
    field = cls(votable, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1463: in __init__
    self.values = Values(self._votable, self)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1014: in __init__
    self.min = None
    ^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'Values' object has no attribute '_max'") raised in repr()] Values object at 0x73d993865150>
min = None

    @min.setter
    def min(self, min):
>       self._min = self._parse_minmax(min)
                    ^^^^^^^^^^^^^^^^^^
E       AttributeError: 'Values' object has no attribute '_parse_minmax'

astropy/io/votable/tree.py:1115: AttributeError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_write_with_format - Attri...
```

## 原始行 82 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_error -q'
```

退出码：`1`

输出：
```
Internet access disabled
FFFFFFFFFFF                                                              [100%]
=================================== FAILURES ===================================
_______ test_coosys_to_astropy_frame_and_time[ICRS-None-None-expected0] ________

system = 'ICRS', equinox = None, epoch = None, expected = <ICRS Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x75851935ae10>
system = 'ICRS'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
_______ test_coosys_to_astropy_frame_and_time[FK4-B1950-B1950-expected1] _______

system = 'FK4', equinox = 'B1950', epoch = 'B1950'
expected = <FK4 Frame (equinox=B1950.000, obstime=B1950.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x758519b84a10>
system = 'FK4'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
_______ test_coosys_to_astropy_frame_and_time[FK5-J2000-None-expected2] ________

system = 'FK5', equinox = 'J2000', epoch = None
expected = <FK5 Frame (equinox=J2000.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x758519390450>
system = 'FK5'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
_____ test_coosys_to_astropy_frame_and_time[eq_FK4-B1950-B1950-expected3] ______

system = 'eq_FK4', equinox = 'B1950', epoch = 'B1950'
expected = <FK4 Frame (equinox=B1950.000, obstime=B1950.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x75851a75e6d0>
system = 'eq_FK4'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
______ test_coosys_to_astropy_frame_and_time[eq_FK5-J2000-None-expected4] ______

system = 'eq_FK5', equinox = 'J2000', epoch = None
expected = <FK5 Frame (equinox=J2000.000)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x758519584550>
system = 'eq_FK5'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
_____ test_coosys_to_astropy_frame_and_time[GALACTIC-None-None-expected5] ______

system = 'GALACTIC', equinox = None, epoch = None, expected = <Galactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x758519536850>
system = 'GALACTIC'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
_____ test_coosys_to_astropy_frame_and_time[galactic-None-None-expected6] ______

system = 'galactic', equinox = None, epoch = None, expected = <Galactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x7585193d74d0>
system = 'galactic'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
__ test_coosys_to_astropy_frame_and_time[SUPER_GALACTIC-None-None-expected7] ___

system = 'SUPER_GALACTIC', equinox = None, epoch = None
expected = <Supergalactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x758519384410>
system = 'SUPER_GALACTIC'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
___ test_coosys_to_astropy_frame_and_time[supergalactic-None-None-expected8] ___

system = 'supergalactic', equinox = None, epoch = None
expected = <Supergalactic Frame>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x7585191653d0>
system = 'supergalactic'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
______ test_coosys_to_astropy_frame_and_time[AZ_EL-None-J2020-expected9] _______

system = 'AZ_EL', equinox = None, epoch = 'J2020'
expected = <AltAz Frame (obstime=None, location=None, pressure=0.0 hPa, temperature=0.0 deg_C, relative_humidity=0.0, obswl=1.0 micron)>

    @pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
    def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
>       coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x7585193d7f90>
system = 'AZ_EL'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
______________________ test_coosys_to_astropy_frame_error ______________________

    def test_coosys_to_astropy_frame_error():
        with pytest.raises(
            ValueError,
            match=(
                "There is no direct correspondence between 'BODY' and an astropy frame.*"
            ),
        ):
>           CooSys(system="BODY").to_astropy_frame()
            ^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:139: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1936: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x75851956f0d0>
system = 'BODY'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1972: AttributeError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[ICRS-None-None-expected0]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[FK4-B1950-B1950-expected1]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[FK5-J2000-None-expected2]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[eq_FK4-B1950-B1950-expected3]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[eq_FK5-J2000-None-expected4]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[GALACTIC-None-None-expected5]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[galactic-None-None-expected6]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[SUPER_GALACTIC-None-None-expected7]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[supergalactic-None-None-expected8]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_and_time[AZ_EL-None-J2020-expected9]
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_to_astropy_frame_error
11 failed in 0.58s
```

## 原始行 86 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,120p' astropy/io/votable/util.py; grep -R -n \"version_compare\" astropy/io/votable/tests astropy/io/votable | head -50"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Various utilities and cookbook-like things.
"""

# STDLIB
import codecs
import contextlib
import gzip
import io
import os
import re

from packaging.version import Version

__all__ = [
    "coerce_range_list_param",
    "convert_to_writable_filelike",
    "stc_reference_frames",
]


@contextlib.contextmanager
def convert_to_writable_filelike(fd, compressed=False):
    """
    Returns a writable file-like object suitable for streaming output.

    Parameters
    ----------
    fd : str or file-like
        May be:

            - a file path string, in which case it is opened, and the file
              object is returned.

            - an object with a :meth:``write`` method, in which case that
              object is returned.

    compressed : bool, optional
        If `True`, create a gzip-compressed file.  (Default is `False`).

    Returns
    -------
    fd : :term:`file-like (writeable)`
    """
    if isinstance(fd, str):
        fd = os.path.expanduser(fd)
        if fd.endswith(".gz") or compressed:
            with gzip.GzipFile(filename=fd, mode="wb") as real_fd:
                encoded_fd = io.TextIOWrapper(real_fd, encoding="utf8")
                yield encoded_fd
                encoded_fd.flush()
                real_fd.flush()
                return
        else:
            with open(fd, "w", encoding="utf8") as real_fd:
                yield real_fd
                return
    elif hasattr(fd, "write"):
        assert callable(fd.write)

        if compressed:
            fd = gzip.GzipFile(fileobj=fd, mode="wb")

        # If we can't write Unicode strings, use a codecs.StreamWriter
        # object
        needs_wrapper = False
        try:
            fd.write("")
        except TypeError:
            needs_wrapper = True

        if not hasattr(fd, "encoding") or fd.encoding is None:
            needs_wrapper = True

        if needs_wrapper:
            yield codecs.getwriter("utf-8")(fd)
        else:
            yield fd

        fd.flush()
        if isinstance(fd, gzip.GzipFile):
            fd.close()

        return
    else:
        raise TypeError("Can not be coerced to writable file-like object")


# <http://www.ivoa.net/documents/REC/DM/STC-20071030.html>
stc_reference_frames = {
    "FK4",
    "FK5",
    "ECLIPTIC",
    "ICRS",
    "GALACTIC",
    "GALACTIC_I",
    "GALACTIC_II",
    "SUPER_GALACTIC",
    "AZ_EL",
    "BODY",
    "GEO_C",
    "GEO_D",
    "MAG",
    "GSE",
    "GSM",
    "SM",
    "HGC",
    "HGS",
    "HEEQ",
    "HRTN",
    "HPC",
    "HPR",
    "HCC",
    "HGI",
    "MERCURY_C",
    "VENUS_C",
    "LUNA_C",
    "MARS_C",
    "JUPITER_C_III",
grep: astropy/io/votable/__pycache__/tree.cpython-311.pyc: binary file matches
grep: astropy/io/votable/__pycache__/util.cpython-311.pyc: binary file matches
astropy/io/votable/util.py:240:def version_compare(a, b):
astropy/io/votable/tree.py:4321:        config["version_1_1_or_later"] = util.version_compare(self.version, "1.1") >= 0
astropy/io/votable/tree.py:4322:        config["version_1_2_or_later"] = util.version_compare(self.version, "1.2") >= 0
astropy/io/votable/tree.py:4323:        config["version_1_3_or_later"] = util.version_compare(self.version, "1.3") >= 0
astropy/io/votable/tree.py:4324:        config["version_1_4_or_later"] = util.version_compare(self.version, "1.4") >= 0
astropy/io/votable/tree.py:4325:        config["version_1_5_or_later"] = util.version_compare(self.version, "1.5") >= 0
```

## 原始行 89 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/utils/tests/test_xml.py astropy/io/votable/tests/test_schema_versions.py astropy/io/votable/tests/test_exception.py::test_reraise astropy/io/votable/tests/test_exception.py::test_suppress_warnings -q'
```

退出码：`0`

输出：
```
Internet access disabled
.........s................                                               [100%]
25 passed, 1 skipped in 0.08s
```

## 原始行 92 · file_change

```
{
  "id": "item_62",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 95 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.votable.tree import _get_default_unit_format
expected = {'1.1': 'cds', '1.2': 'cds', '1.3': 'cds', '1.4': 'vounit', '1.5': 'vounit'}
for version, unit_format in expected.items():
    assert _get_default_unit_format({'version': version}) == unit_format
print('version fallback checks passed')
PY
python -m pytest astropy/utils/tests/test_xml.py astropy/io/votable/tests/test_schema_versions.py astropy/io/votable/tests/test_exception.py::test_reraise astropy/io/votable/tests/test_exception.py::test_suppress_warnings -q
git diff --check
git status --short"
```

退出码：`0`

输出：
```
version fallback checks passed
Internet access disabled
.........s................                                               [100%]
25 passed, 1 skipped in 0.08s
 M astropy/io/votable/exceptions.py
 M astropy/io/votable/tree.py
 M astropy/utils/xml/check.py
```

## 原始行 97 · agent_message

```
Implemented the requested VOTable utilities:

- XML token validation in [check.py](/testbed/astropy/utils/xml/check.py:38)
- Version-dependent unit format selection
- Astronomical-year and string validation with W07/W08 handling
- `VOTableFile.set_all_tables_format`
- Required warning formatting/suppression helpers
- Restored adjacent XML helpers required by visible tests

Validation completed:

- `25 passed, 1 skipped`
- Direct edge-case checks passed
- `git diff --check` passed
```
