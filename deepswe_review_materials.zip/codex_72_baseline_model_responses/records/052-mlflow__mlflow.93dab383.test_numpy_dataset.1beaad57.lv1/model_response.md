# Codex baseline: mlflow__mlflow.93dab383.test_numpy_dataset.1beaad57.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the specified modules and nearby tests/callers first, then implement the smallest compatible changes and run focused pytest coverage. I’ll use only the visible `/testbed` tree as requested.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' mlflow/types/utils.py && sed -n '1,220p' mlflow/data/dataset_source.py && sed -n '1,300p' mlflow/data/dataset.py"
```

退出码：`0`

输出：
```
import logging
import warnings
from collections import defaultdict
from copy import deepcopy
from typing import Any, Dict, List

import numpy as np
import pandas as pd
import pydantic

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.types import DataType
from mlflow.types.schema import (
    HAS_PYSPARK,
    AnyType,
    Array,
    ColSpec,
    Map,
    Object,
    ParamSchema,
    ParamSpec,
    Property,
    Schema,
    SparkMLVector,
    TensorSpec,
)

MULTIPLE_TYPES_ERROR_MSG = (
    "Expected all values in the list to be of the same type. To specify a model signature "
    "with a list containing elements of multiple types, define the signature manually "
    "using the Array(AnyType()) type from mlflow.models.schema."
)
_logger = logging.getLogger(__name__)


class TensorsNotSupportedException(MlflowException):
    def __init__(self, msg):
        super().__init__(f"Multidimensional arrays (aka tensors) are not supported. {msg}")


























































def _infer_colspec_type(data: Any) -> DataType | Array | Object | AnyType:
    """
    Infer an MLflow Colspec type from the dataset.

    Args:
        data: data to infer from.

    Returns:
        Object
    """
    dtype = _infer_datatype(data)

    if dtype is None:
        raise MlflowException(
            f"Numpy array must include at least one non-empty item. Invalid input `{data}`."
        )

    return dtype


class InvalidDataForSignatureInferenceError(MlflowException):
    def __init__(self, message):
        super().__init__(message=message, error_code=INVALID_PARAMETER_VALUE)


def _infer_datatype(data: Any) -> DataType | Array | Object | AnyType | None:
    """
    Infer the datatype of input data.
    Data type and inferred schema type mapping:
        - dict -> Object
        - list -> Array
        - numpy.ndarray -> Array
        - scalar -> DataType
        - None, empty dictionary/list -> AnyType

    .. Note::
        Empty numpy arrays are inferred as None to keep the backward compatibility, as numpy
        arrays are used by some traditional ML flavors.
        e.g. numpy.array([]) -> None, numpy.array([[], []]) -> None
        While empty lists are inferred as AnyType instead of None after the support of AnyType.
        e.g. [] -> AnyType, [[], []] -> Array(Any)
    """
    if isinstance(data, pydantic.BaseModel):
        raise InvalidDataForSignatureInferenceError(
            message="MLflow does not support inferring model signature from input example "
            "with Pydantic objects. To use Pydantic objects, define your PythonModel's "
            "`predict` method with a Pydantic type hint, and model signature will be automatically "
            "inferred when logging the model. e.g. "
            "`def predict(self, model_input: list[PydanticType])`. Check "
            "https://mlflow.org/docs/latest/model/python_model.html#type-hint-usage-in-pythonmodel "
            "for more details."
        )

    if _is_none_or_nan(data) or (isinstance(data, (list, dict)) and not data):
        return AnyType()

    if isinstance(data, dict):
        properties = []
        for k, v in data.items():
            dtype = _infer_datatype(v)
            if dtype is None:
                raise MlflowException("Dictionary value must not be an empty numpy array.")
            properties.append(
                Property(name=k, dtype=dtype, required=not isinstance(dtype, AnyType))
            )
        return Object(properties=properties)

    if isinstance(data, (list, np.ndarray)):
        return _infer_array_datatype(data)

    return _infer_scalar_datatype(data)


def _infer_array_datatype(data: list[Any] | np.ndarray) -> Array | None:
    """Infer schema from an array. This tries to infer type if there is at least one
    non-null item in the list, assuming the list has a homogeneous type. However,
    if the list is empty or all items are null, returns None as a sign of undetermined.

    E.g.
        ["a", "b"] => Array(string)
        ["a", None] => Array(string)
        [["a", "b"], []] => Array(Array(string))
        [["a", "b"], None] => Array(Array(string))
        [] => None
        [None] => Array(Any)

    Args:
        data: data to infer from.

    Returns:
        Array(dtype) or None if undetermined
    """
    result = None
    for item in data:
        dtype = _infer_datatype(item)

        # Skip item with undetermined type
        if dtype is None:
            continue

        if result is None:
            result = Array(dtype)
        elif isinstance(result.dtype, (Array, Object, Map, AnyType)):
            try:
                result = Array(result.dtype._merge(dtype))
            except MlflowException as e:
                raise MlflowException.invalid_parameter_value(MULTIPLE_TYPES_ERROR_MSG) from e
        elif isinstance(result.dtype, DataType):
            if not isinstance(dtype, AnyType) and dtype != result.dtype:
                raise MlflowException.invalid_parameter_value(MULTIPLE_TYPES_ERROR_MSG)
        else:
            raise MlflowException.invalid_parameter_value(
                f"{dtype} is not a valid type for an item of a list or numpy array."
            )
    return result


# datetime is not included here
SCALAR_TO_DATATYPE_MAPPING = {
    bool: DataType.boolean,
    np.bool_: DataType.boolean,
    int: DataType.long,
    np.int64: DataType.long,
    np.int32: DataType.integer,
    float: DataType.double,
    np.float64: DataType.double,
    np.float32: DataType.float,
    str: DataType.string,
    np.str_: DataType.string,
    object: DataType.string,
    bytes: DataType.binary,
    np.bytes_: DataType.binary,
    bytearray: DataType.binary,
}


def _infer_scalar_datatype(data) -> DataType:
    if data_type := SCALAR_TO_DATATYPE_MAPPING.get(type(data)):
        return data_type
    if DataType.check_type(DataType.datetime, data):
        return DataType.datetime
    if HAS_PYSPARK:
        for data_type in DataType.all_types():
            if isinstance(data, type(data_type.to_spark())):
                return data_type
    raise MlflowException.invalid_parameter_value(
        f"Data {data} is not one of the supported DataType"
    )















import json
from abc import abstractmethod
from typing import Any


class DatasetSource:
    """
    Represents the source of a dataset used in MLflow Tracking, providing information such as
    cloud storage location, delta table name / version, etc.
    """

    @staticmethod
    @abstractmethod
    def _get_source_type() -> str:
        """Obtains a string representing the source type of the dataset.

        Returns:
            A string representing the source type of the dataset, e.g. "s3", "delta_table", ...

        """

    @abstractmethod
    def load(self) -> Any:
        """
        Loads files / objects referred to by the DatasetSource. For example, depending on the type
        of :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`, this may download
        source CSV files from S3 to the local filesystem, load a source Delta Table as a Spark
        DataFrame, etc.

        Returns:
            The downloaded source, e.g. a local filesystem path, a Spark DataFrame, etc.

        """

    @staticmethod
    @abstractmethod
    def _can_resolve(raw_source: Any) -> bool:
        """Determines whether this type of DatasetSource can be resolved from a specified raw source
        object. For example, an S3DatasetSource can be resolved from an S3 URI like
        "s3://mybucket/path/to/iris/data" but not from an Azure Blob Storage URI like
        "wasbs:/account@host.blob.core.windows.net".

        Args:
            raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data".

        Returns:
            True if this DatasetSource can resolve the raw source, False otherwise.

        """

    @classmethod
    @abstractmethod
    def _resolve(cls, raw_source: Any) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a raw source object, such as a
        string URI like "s3://mybucket/path/to/iris/data" or a delta table identifier
        like "my.delta.table@2".

        Args:
            raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data".

        Returns:
            A DatasetSource instance derived from the raw_source.

        """

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """Obtains a JSON-compatible dictionary representation of the DatasetSource.

        Returns:
            A JSON-compatible dictionary representation of the DatasetSource.

        """












    @classmethod
    @abstractmethod
    def from_dict(cls, source_dict: dict[Any, Any]) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a dictionary representation.

        Args:
            source_dict: A dictionary representation of the DatasetSource.

        Returns:
            A DatasetSource instance.

        """

    @classmethod
    def from_json(cls, source_json: str) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a JSON string representation.

        Args:
            source_json: A JSON string representation of the DatasetSource.

        Returns:
            A DatasetSource instance.

        """
        return cls.from_dict(json.loads(source_json))import json
from abc import abstractmethod
from typing import Any

from mlflow.data.dataset_source import DatasetSource
from mlflow.entities import Dataset as DatasetEntity


class Dataset:
    """
    Represents a dataset for use with MLflow Tracking, including the name, digest (hash),
    schema, and profile of the dataset as well as source information (e.g. the S3 bucket or
    managed Delta table from which the dataset was derived). Most datasets expose features
    and targets for training and evaluation as well.
    """











    @abstractmethod
    def _compute_digest(self) -> str:
        """Computes a digest for the dataset. Called if the user doesn't supply
        a digest when constructing the dataset.

        Returns:
            A string digest for the dataset. We recommend a maximum digest length
            of 10 characters with an ideal length of 8 characters.

        """




























    def _get_source_type(self) -> str:
        """Returns the type of the dataset's underlying source."""

        return self.source._get_source_type()


















    @property
    def source(self) -> DatasetSource:
        """
        Information about the dataset's source, represented as an instance of
        :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`. For example, this
        may be the S3 location or the name of the managed Delta Table from which the dataset
        was derived.
        """
        return self._source

    @property
    @abstractmethod
    def profile(self) -> Any | None:
        """
        Optional summary statistics for the dataset, such as the number of rows in a table, the
        mean / median / std of each table column, etc.
        """

    @property
    @abstractmethod
    def schema(self) -> Any | None:
        """
        Optional dataset schema, such as an instance of :py:class:`mlflow.types.Schema` representing
        the features and targets of the dataset.
        """

    def _to_mlflow_entity(self) -> DatasetEntity:
        """
        Returns:
            A `mlflow.entities.Dataset` instance representing the dataset.
        """
        dataset_dict = self.to_dict()
        return DatasetEntity(
            name=dataset_dict["name"],
            digest=dataset_dict["digest"],
            source_type=dataset_dict["source_type"],
            source=dataset_dict["source"],
            schema=dataset_dict.get("schema"),
            profile=dataset_dict.get("profile"),
        )
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc "sed -n '260,760p' mlflow/types/utils.py"
```

退出码：`0`

输出：
```















































































































































































































def _infer_numpy_dtype(dtype) -> DataType:
    supported_types = np.dtype

    # noinspection PyBroadException
    try:
        from pandas.core.dtypes.base import ExtensionDtype

        supported_types = (np.dtype, ExtensionDtype)
    except ImportError:
        # This version of pandas does not support extension types
        pass
    if not isinstance(dtype, supported_types):
        raise TypeError(f"Expected numpy.dtype or pandas.ExtensionDtype, got '{type(dtype)}'.")

    if dtype.kind == "b":
        return DataType.boolean
    elif dtype.kind in {"i", "u"}:
        if dtype.itemsize < 4 or (dtype.kind == "i" and dtype.itemsize == 4):
            return DataType.integer
        elif dtype.itemsize < 8 or (dtype.kind == "i" and dtype.itemsize == 8):
            return DataType.long
    elif dtype.kind == "f":
        if dtype.itemsize <= 4:
            return DataType.float
        elif dtype.itemsize <= 8:
            return DataType.double

    elif dtype.kind == "U":
        return DataType.string
    elif dtype.kind == "S":
        return DataType.binary
    elif dtype.kind == "O":
        raise Exception(
            "Can not infer object without looking at the values, call _map_numpy_array instead."
        )
    elif dtype.kind == "M":
        return DataType.datetime
    raise MlflowException(f"Unsupported numpy data type '{dtype}', kind '{dtype.kind}'")


def _is_none_or_nan(x):
    if isinstance(x, float):
        return np.isnan(x)
    # NB: We can't use pd.isna() because the input can be a series.
    return x is None or x is pd.NA or x is pd.NaT


def _infer_required(col) -> bool:
    if isinstance(col, (list, pd.Series)):
        return not any(_is_none_or_nan(x) for x in col)
    return not _is_none_or_nan(col)


def _infer_pandas_column(col: pd.Series) -> DataType:
    if not isinstance(col, pd.Series):
        raise TypeError(f"Expected pandas.Series, got '{type(col)}'.")
    if len(col.values.shape) > 1:
        raise MlflowException(f"Expected 1d array, got array with shape {col.shape}")

    if col.dtype.kind == "O":
        col = col.infer_objects()
    if col.dtype.kind == "O":
        try:
            # We convert pandas Series into list and infer the schema.
            # The real schema for internal field should be the Array's dtype
            arr_type = _infer_colspec_type(col.to_list())
            return arr_type.dtype
        except Exception as e:
            # For backwards compatibility, we fall back to string
            # if the provided array is of string type
            # This is for diviner test where df field is ('key2', 'key1', 'key0')
            if pd.api.types.is_string_dtype(col):
                return DataType.string
            raise MlflowException(f"Failed to infer schema for pandas.Series {col}. Error: {e}")
    else:
        # NB: The following works for numpy types as well as pandas extension types.
        return _infer_numpy_dtype(col.dtype)


def _infer_spark_type(x, data=None, col_name=None) -> DataType:
    import pyspark.sql.types
    from pyspark.ml.linalg import VectorUDT
    from pyspark.sql.functions import col, collect_list

    if isinstance(x, pyspark.sql.types.NumericType):
        if isinstance(x, pyspark.sql.types.IntegralType):
            if isinstance(x, pyspark.sql.types.LongType):
                return DataType.long
            else:
                return DataType.integer
        elif isinstance(x, pyspark.sql.types.FloatType):
            return DataType.float
        elif isinstance(x, pyspark.sql.types.DoubleType):
            return DataType.double
    elif isinstance(x, pyspark.sql.types.BooleanType):
        return DataType.boolean
    elif isinstance(x, pyspark.sql.types.StringType):
        return DataType.string
    elif isinstance(x, pyspark.sql.types.BinaryType):
        return DataType.binary
    # NB: Spark differentiates date and timestamps, so we coerce both to TimestampType.
    elif isinstance(x, (pyspark.sql.types.DateType, pyspark.sql.types.TimestampType)):
        return DataType.datetime
    elif isinstance(x, pyspark.sql.types.ArrayType):
        return Array(_infer_spark_type(x.elementType))
    elif isinstance(x, pyspark.sql.types.StructType):
        return Object(
            properties=[
                Property(
                    name=f.name,
                    dtype=_infer_spark_type(f.dataType),
                    required=not f.nullable,
                )
                for f in x.fields
            ]
        )
    elif isinstance(x, pyspark.sql.types.MapType):
        if data is None or col_name is None:
            raise MlflowException("Cannot infer schema for MapType without data and column name.")
        # Map MapType to StructType
        # Note that MapType assumes all values are of same type,
        # if they're not then spark picks the first item's type
        # and tries to convert rest to that type.
        # e.g.
        # >>> spark.createDataFrame([{"col": {"a": 1, "b": "b"}}]).show()
        # +-------------------+
        # |                col|
        # +-------------------+
        # |{a -> 1, b -> null}|
        # +-------------------+
        if isinstance(x.valueType, pyspark.sql.types.MapType):
            raise MlflowException(
                "Please construct spark DataFrame with schema using StructType "
                "for dictionary/map fields, MLflow schema inference only supports "
                "scalar, array and struct types."
            )

        merged_keys = (
            data.selectExpr(f"map_keys({col_name}) as keys")
            .agg(collect_list(col("keys")).alias("merged_keys"))
            .head()
            .merged_keys
        )
        keys = {key for sublist in merged_keys for key in sublist}
        return Object(
            properties=[
                Property(
                    name=k,
                    dtype=_infer_spark_type(x.valueType),
                )
                for k in keys
            ]
        )
    elif isinstance(x, VectorUDT):
        return SparkMLVector()

    else:
        raise MlflowException.invalid_parameter_value(
            f"Unsupported Spark Type '{type(x)}' for MLflow schema."
        )


def _is_spark_df(x) -> bool:
    try:
        import pyspark.sql.dataframe

        if isinstance(x, pyspark.sql.dataframe.DataFrame):
            return True
    except ImportError:
        return False
    # For spark 4.0
    try:
        import pyspark.sql.connect.dataframe

        return isinstance(x, pyspark.sql.connect.dataframe.DataFrame)
    except ImportError:
        return False


def _validate_input_dictionary_contains_only_strings_and_lists_of_strings(data) -> None:
    # isinstance(True, int) is True
    invalid_keys = [
        key for key in data.keys() if not isinstance(key, (str, int)) or isinstance(key, bool)
    ]
    if invalid_keys:
        raise MlflowException(
            f"The dictionary keys are not all strings or indexes. Invalid keys: {invalid_keys}"
        )
    if any(isinstance(value, np.ndarray) for value in data.values()) and not all(
        isinstance(value, np.ndarray) for value in data.values()
    ):
        raise MlflowException("The dictionary values are not all numpy.ndarray.")

    invalid_values = [
        key
        for key, value in data.items()
        if (isinstance(value, list) and not all(isinstance(item, (str, bytes)) for item in value))
        or (not isinstance(value, (np.ndarray, list, str, bytes)))
    ]
    if invalid_values:
        raise MlflowException.invalid_parameter_value(
            "Invalid values in dictionary. If passing a dictionary containing strings, all "
            "values must be either strings or lists of strings. If passing a dictionary containing "
            "numeric values, the data must be enclosed in a numpy.ndarray. The following keys "
            f"in the input dictionary are invalid: {invalid_values}",
        )


def _is_list_str(type_hint: Any) -> bool:
    return type_hint in [
        List[str],  # noqa: UP006
        list[str],
    ]


def _is_list_dict_str(type_hint: Any) -> bool:
    return type_hint in [
        List[Dict[str, str]],  # noqa: UP006
        list[Dict[str, str]],  # noqa: UP006
        List[dict[str, str]],  # noqa: UP006
        list[dict[str, str]],
    ]


def _get_array_depth(l: Any) -> int:
    if isinstance(l, np.ndarray):
        return l.ndim
    if isinstance(l, list):
        return max(_get_array_depth(item) for item in l) + 1 if l else 1
    return 0


def _infer_type_and_shape(value):
    if isinstance(value, (list, np.ndarray)):
        ndim = _get_array_depth(value)
        if ndim != 1:
            raise MlflowException.invalid_parameter_value(
                f"Expected parameters to be 1D array or scalar, got {ndim}D array",
            )
        if all(DataType.check_type(DataType.datetime, v) for v in value):
            return DataType.datetime, (-1,)
        value_type = _infer_numpy_dtype(np.array(value).dtype)
        return value_type, (-1,)
    elif DataType.check_type(DataType.datetime, value):
        return DataType.datetime, None
    elif np.isscalar(value):
        try:
            value_type = _infer_numpy_dtype(np.array(value).dtype)
            return value_type, None
        except (Exception, MlflowException) as e:
            raise MlflowException.invalid_parameter_value(
                f"Failed to infer schema for parameter {value}: {e!r}"
            )
    elif isinstance(value, dict):
        # reuse _infer_schema to infer schema for dict, wrapping it in a dictionary is
        # necessary to make sure value is inferred as Object
        schema = _infer_schema({"value": value})
        object_type = schema.inputs[0].type
        return object_type, None
    raise MlflowException.invalid_parameter_value(
        f"Expected parameters to be 1D array or scalar, got {type(value).__name__}",
    )


def _infer_param_schema(parameters: dict[str, Any]):
    if not isinstance(parameters, dict):
        raise MlflowException.invalid_parameter_value(
            f"Expected parameters to be dict, got {type(parameters).__name__}",
        )

    param_specs = []
    invalid_params = []
    for name, value in parameters.items():
        try:
            value_type, shape = _infer_type_and_shape(value)
            param_specs.append(
                ParamSpec(name=name, dtype=value_type, default=deepcopy(value), shape=shape)
            )
        except Exception as e:
            invalid_params.append((name, value, e))

    if invalid_params:
        raise MlflowException.invalid_parameter_value(
            f"Failed to infer schema for parameters: {invalid_params}",
        )

    return ParamSchema(param_specs)
```

## 原始行 11 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,420p' mlflow/data/evaluation_dataset.py"
```

退出码：`0`

输出：
```
import hashlib
import json
import logging
import math
import struct
import sys

from packaging.version import Version

import mlflow
from mlflow.entities import RunTag
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.utils.string_utils import generate_feature_name_if_not_string

try:
    # `numpy` and `pandas` are not required for `mlflow-skinny`.
    import numpy as np
    import pandas as pd
except ImportError:
    pass

_logger = logging.getLogger(__name__)































def _hash_array_of_dict_as_bytes(data):
    # NB: If an array or list contains dictionary element, it can't be hashed with
    # pandas.util.hash_array. Hence we need to manually hash the elements here. This is
    # particularly for the LLM use case where the input can be a list of dictionary
    # (chat/completion payloads), so doesn't handle more complex case like nested lists.
    result = b""
    for elm in data:
        if isinstance(elm, (list, np.ndarray)):
            result += _hash_array_of_dict_as_bytes(elm)
        elif isinstance(elm, dict):
            result += _hash_dict_as_bytes(elm)
        else:
            result += _hash_data_as_bytes(elm)
    return result














def _hash_data_as_bytes(data):
    try:
        if isinstance(data, (list, np.ndarray)):
            return _hash_ndarray_as_bytes(data)
        if isinstance(data, dict):
            return _hash_dict_as_bytes(data)
        if np.isscalar(data):
            return _hash_uint64_ndarray_as_bytes(pd.util.hash_array(np.array([data])))
    except Exception:
        pass
    # Skip unsupported types by returning an empty byte string
    return b""


def _hash_dict_as_bytes(data_dict):
    result = _hash_ndarray_as_bytes(list(data_dict.keys()))
    try:
        result += _hash_ndarray_as_bytes(list(data_dict.values()))
    # If the values containing non-hashable objects, we will hash the values recursively.
    except Exception:
        for value in data_dict.values():
            result += _hash_data_as_bytes(value)
    return result











































































def convert_data_to_mlflow_dataset(data, targets=None, predictions=None, name=None):
    """Convert input data to mlflow dataset."""
    supported_dataframe_types = [pd.DataFrame]
    if "pyspark" in sys.modules:
        from mlflow.utils.spark_utils import get_spark_dataframe_type

        spark_df_type = get_spark_dataframe_type()
        supported_dataframe_types.append(spark_df_type)

    if predictions is not None:
        _validate_dataset_type_supports_predictions(
            data=data, supported_predictions_dataset_types=supported_dataframe_types
        )

    if isinstance(data, list):
        # If the list is flat, we assume each element is an independent sample.
        if not isinstance(data[0], (list, np.ndarray)):
            data = [[elm] for elm in data]

        return mlflow.data.from_numpy(
            np.array(data), targets=np.array(targets) if targets else None, name=name
        )
    elif isinstance(data, np.ndarray):
        return mlflow.data.from_numpy(data, targets=targets, name=name)
    elif isinstance(data, pd.DataFrame):
        return mlflow.data.from_pandas(df=data, targets=targets, predictions=predictions, name=name)
    elif "pyspark" in sys.modules and isinstance(data, spark_df_type):
        return mlflow.data.from_spark(df=data, targets=targets, predictions=predictions, name=name)
    else:
        # Cannot convert to mlflow dataset, return original data.
        _logger.info(
            "Cannot convert input data to `evaluate()` to an mlflow dataset, input must be a list, "
            f"a numpy array, a panda Dataframe or a spark Dataframe, but received {type(data)}."
        )
        return data


def _validate_dataset_type_supports_predictions(data, supported_predictions_dataset_types):
    """
    Validate that the dataset type supports a user-specified "predictions" column.
    """
    if not any(isinstance(data, sdt) for sdt in supported_predictions_dataset_types):
        raise MlflowException(
            message=(
                "If predictions is specified, data must be one of the following types, or an"
                " MLflow Dataset that represents one of the following types:"
                f" {supported_predictions_dataset_types}."
            ),
            error_code=INVALID_PARAMETER_VALUE,
        )


class EvaluationDataset:
    """
    An input dataset for model evaluation. This is intended for use with the
    :py:func:`mlflow.models.evaluate()`
    API.
    """

    NUM_SAMPLE_ROWS_FOR_HASH = 5
    SPARK_DATAFRAME_LIMIT = 10000
```

## 原始行 14 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,360p' mlflow/data/schema.py && rg -n \"def is_tensor_spec|class Schema|class TensorSpec\" mlflow/types/schema.py && sed -n '900,1250p' mlflow/types/schema.py"
```

退出码：`127`

输出：
```
from typing import Any

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.types.schema import Schema


class TensorDatasetSchema:
    """
    Represents the schema of a dataset with tensor features and targets.
    """
























































    def __eq__(self, other) -> bool:
        return (
            isinstance(other, TensorDatasetSchema)
            and self.features == other.features
            and self.targets == other.targets
        )

    def __repr__(self) -> str:
        return f"features:\n  {self.features!r}\ntargets:\n  {self.targets!r}\n"/bin/bash: line 1: rg: command not found
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "rg -n \"_get_tensor_shape|clean_tensor_type|_infer_schema\\(|features_data|TensorDatasetSchema|\\.digest|to_json\\(\\)\" tests mlflow | head -n 400"
```

退出码：`0`

输出：
```
/bin/bash: line 1: rg: command not found
```

## 原始行 17 · agent_message

```
The target files are intentionally masked in several regions, including constructors and helpers that the requested properties depend on. I’m mapping those gaps against visible tests and concrete dataset subclasses so the restored behavior remains compatible across the repository.
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/types/utils.py | sed -n '1,760p'"
```

退出码：`0`

输出：
```
     1	import logging
     2	import warnings
     3	from collections import defaultdict
     4	from copy import deepcopy
     5	from typing import Any, Dict, List
     6	
     7	import numpy as np
     8	import pandas as pd
     9	import pydantic
    10	
    11	from mlflow.exceptions import MlflowException
    12	from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    13	from mlflow.types import DataType
    14	from mlflow.types.schema import (
    15	    HAS_PYSPARK,
    16	    AnyType,
    17	    Array,
    18	    ColSpec,
    19	    Map,
    20	    Object,
    21	    ParamSchema,
    22	    ParamSpec,
    23	    Property,
    24	    Schema,
    25	    SparkMLVector,
    26	    TensorSpec,
    27	)
    28	
    29	MULTIPLE_TYPES_ERROR_MSG = (
    30	    "Expected all values in the list to be of the same type. To specify a model signature "
    31	    "with a list containing elements of multiple types, define the signature manually "
    32	    "using the Array(AnyType()) type from mlflow.models.schema."
    33	)
    34	_logger = logging.getLogger(__name__)
    35	
    36	
    37	class TensorsNotSupportedException(MlflowException):
    38	    def __init__(self, msg):
    39	        super().__init__(f"Multidimensional arrays (aka tensors) are not supported. {msg}")
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	def _infer_colspec_type(data: Any) -> DataType | Array | Object | AnyType:
    99	    """
   100	    Infer an MLflow Colspec type from the dataset.
   101	
   102	    Args:
   103	        data: data to infer from.
   104	
   105	    Returns:
   106	        Object
   107	    """
   108	    dtype = _infer_datatype(data)
   109	
   110	    if dtype is None:
   111	        raise MlflowException(
   112	            f"Numpy array must include at least one non-empty item. Invalid input `{data}`."
   113	        )
   114	
   115	    return dtype
   116	
   117	
   118	class InvalidDataForSignatureInferenceError(MlflowException):
   119	    def __init__(self, message):
   120	        super().__init__(message=message, error_code=INVALID_PARAMETER_VALUE)
   121	
   122	
   123	def _infer_datatype(data: Any) -> DataType | Array | Object | AnyType | None:
   124	    """
   125	    Infer the datatype of input data.
   126	    Data type and inferred schema type mapping:
   127	        - dict -> Object
   128	        - list -> Array
   129	        - numpy.ndarray -> Array
   130	        - scalar -> DataType
   131	        - None, empty dictionary/list -> AnyType
   132	
   133	    .. Note::
   134	        Empty numpy arrays are inferred as None to keep the backward compatibility, as numpy
   135	        arrays are used by some traditional ML flavors.
   136	        e.g. numpy.array([]) -> None, numpy.array([[], []]) -> None
   137	        While empty lists are inferred as AnyType instead of None after the support of AnyType.
   138	        e.g. [] -> AnyType, [[], []] -> Array(Any)
   139	    """
   140	    if isinstance(data, pydantic.BaseModel):
   141	        raise InvalidDataForSignatureInferenceError(
   142	            message="MLflow does not support inferring model signature from input example "
   143	            "with Pydantic objects. To use Pydantic objects, define your PythonModel's "
   144	            "`predict` method with a Pydantic type hint, and model signature will be automatically "
   145	            "inferred when logging the model. e.g. "
   146	            "`def predict(self, model_input: list[PydanticType])`. Check "
   147	            "https://mlflow.org/docs/latest/model/python_model.html#type-hint-usage-in-pythonmodel "
   148	            "for more details."
   149	        )
   150	
   151	    if _is_none_or_nan(data) or (isinstance(data, (list, dict)) and not data):
   152	        return AnyType()
   153	
   154	    if isinstance(data, dict):
   155	        properties = []
   156	        for k, v in data.items():
   157	            dtype = _infer_datatype(v)
   158	            if dtype is None:
   159	                raise MlflowException("Dictionary value must not be an empty numpy array.")
   160	            properties.append(
   161	                Property(name=k, dtype=dtype, required=not isinstance(dtype, AnyType))
   162	            )
   163	        return Object(properties=properties)
   164	
   165	    if isinstance(data, (list, np.ndarray)):
   166	        return _infer_array_datatype(data)
   167	
   168	    return _infer_scalar_datatype(data)
   169	
   170	
   171	def _infer_array_datatype(data: list[Any] | np.ndarray) -> Array | None:
   172	    """Infer schema from an array. This tries to infer type if there is at least one
   173	    non-null item in the list, assuming the list has a homogeneous type. However,
   174	    if the list is empty or all items are null, returns None as a sign of undetermined.
   175	
   176	    E.g.
   177	        ["a", "b"] => Array(string)
   178	        ["a", None] => Array(string)
   179	        [["a", "b"], []] => Array(Array(string))
   180	        [["a", "b"], None] => Array(Array(string))
   181	        [] => None
   182	        [None] => Array(Any)
   183	
   184	    Args:
   185	        data: data to infer from.
   186	
   187	    Returns:
   188	        Array(dtype) or None if undetermined
   189	    """
   190	    result = None
   191	    for item in data:
   192	        dtype = _infer_datatype(item)
   193	
   194	        # Skip item with undetermined type
   195	        if dtype is None:
   196	            continue
   197	
   198	        if result is None:
   199	            result = Array(dtype)
   200	        elif isinstance(result.dtype, (Array, Object, Map, AnyType)):
   201	            try:
   202	                result = Array(result.dtype._merge(dtype))
   203	            except MlflowException as e:
   204	                raise MlflowException.invalid_parameter_value(MULTIPLE_TYPES_ERROR_MSG) from e
   205	        elif isinstance(result.dtype, DataType):
   206	            if not isinstance(dtype, AnyType) and dtype != result.dtype:
   207	                raise MlflowException.invalid_parameter_value(MULTIPLE_TYPES_ERROR_MSG)
   208	        else:
   209	            raise MlflowException.invalid_parameter_value(
   210	                f"{dtype} is not a valid type for an item of a list or numpy array."
   211	            )
   212	    return result
   213	
   214	
   215	# datetime is not included here
   216	SCALAR_TO_DATATYPE_MAPPING = {
   217	    bool: DataType.boolean,
   218	    np.bool_: DataType.boolean,
   219	    int: DataType.long,
   220	    np.int64: DataType.long,
   221	    np.int32: DataType.integer,
   222	    float: DataType.double,
   223	    np.float64: DataType.double,
   224	    np.float32: DataType.float,
   225	    str: DataType.string,
   226	    np.str_: DataType.string,
   227	    object: DataType.string,
   228	    bytes: DataType.binary,
   229	    np.bytes_: DataType.binary,
   230	    bytearray: DataType.binary,
   231	}
   232	
   233	
   234	def _infer_scalar_datatype(data) -> DataType:
   235	    if data_type := SCALAR_TO_DATATYPE_MAPPING.get(type(data)):
   236	        return data_type
   237	    if DataType.check_type(DataType.datetime, data):
   238	        return DataType.datetime
   239	    if HAS_PYSPARK:
   240	        for data_type in DataType.all_types():
   241	            if isinstance(data, type(data_type.to_spark())):
   242	                return data_type
   243	    raise MlflowException.invalid_parameter_value(
   244	        f"Data {data} is not one of the supported DataType"
   245	    )
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	
   303	
   304	
   305	
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	
   414	
   415	
   416	
   417	
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	
   426	
   427	
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	
   437	
   438	
   439	
   440	
   441	
   442	
   443	
   444	
   445	
   446	
   447	
   448	
   449	
   450	
   451	
   452	
   453	
   454	
   455	
   456	
   457	
   458	
   459	
   460	
   461	
   462	
   463	
   464	
   465	
   466	
   467	def _infer_numpy_dtype(dtype) -> DataType:
   468	    supported_types = np.dtype
   469	
   470	    # noinspection PyBroadException
   471	    try:
   472	        from pandas.core.dtypes.base import ExtensionDtype
   473	
   474	        supported_types = (np.dtype, ExtensionDtype)
   475	    except ImportError:
   476	        # This version of pandas does not support extension types
   477	        pass
   478	    if not isinstance(dtype, supported_types):
   479	        raise TypeError(f"Expected numpy.dtype or pandas.ExtensionDtype, got '{type(dtype)}'.")
   480	
   481	    if dtype.kind == "b":
   482	        return DataType.boolean
   483	    elif dtype.kind in {"i", "u"}:
   484	        if dtype.itemsize < 4 or (dtype.kind == "i" and dtype.itemsize == 4):
   485	            return DataType.integer
   486	        elif dtype.itemsize < 8 or (dtype.kind == "i" and dtype.itemsize == 8):
   487	            return DataType.long
   488	    elif dtype.kind == "f":
   489	        if dtype.itemsize <= 4:
   490	            return DataType.float
   491	        elif dtype.itemsize <= 8:
   492	            return DataType.double
   493	
   494	    elif dtype.kind == "U":
   495	        return DataType.string
   496	    elif dtype.kind == "S":
   497	        return DataType.binary
   498	    elif dtype.kind == "O":
   499	        raise Exception(
   500	            "Can not infer object without looking at the values, call _map_numpy_array instead."
   501	        )
   502	    elif dtype.kind == "M":
   503	        return DataType.datetime
   504	    raise MlflowException(f"Unsupported numpy data type '{dtype}', kind '{dtype.kind}'")
   505	
   506	
   507	def _is_none_or_nan(x):
   508	    if isinstance(x, float):
   509	        return np.isnan(x)
   510	    # NB: We can't use pd.isna() because the input can be a series.
   511	    return x is None or x is pd.NA or x is pd.NaT
   512	
   513	
   514	def _infer_required(col) -> bool:
   515	    if isinstance(col, (list, pd.Series)):
   516	        return not any(_is_none_or_nan(x) for x in col)
   517	    return not _is_none_or_nan(col)
   518	
   519	
   520	def _infer_pandas_column(col: pd.Series) -> DataType:
   521	    if not isinstance(col, pd.Series):
   522	        raise TypeError(f"Expected pandas.Series, got '{type(col)}'.")
   523	    if len(col.values.shape) > 1:
   524	        raise MlflowException(f"Expected 1d array, got array with shape {col.shape}")
   525	
   526	    if col.dtype.kind == "O":
   527	        col = col.infer_objects()
   528	    if col.dtype.kind == "O":
   529	        try:
   530	            # We convert pandas Series into list and infer the schema.
   531	            # The real schema for internal field should be the Array's dtype
   532	            arr_type = _infer_colspec_type(col.to_list())
   533	            return arr_type.dtype
   534	        except Exception as e:
   535	            # For backwards compatibility, we fall back to string
   536	            # if the provided array is of string type
   537	            # This is for diviner test where df field is ('key2', 'key1', 'key0')
   538	            if pd.api.types.is_string_dtype(col):
   539	                return DataType.string
   540	            raise MlflowException(f"Failed to infer schema for pandas.Series {col}. Error: {e}")
   541	    else:
   542	        # NB: The following works for numpy types as well as pandas extension types.
   543	        return _infer_numpy_dtype(col.dtype)
   544	
   545	
   546	def _infer_spark_type(x, data=None, col_name=None) -> DataType:
   547	    import pyspark.sql.types
   548	    from pyspark.ml.linalg import VectorUDT
   549	    from pyspark.sql.functions import col, collect_list
   550	
   551	    if isinstance(x, pyspark.sql.types.NumericType):
   552	        if isinstance(x, pyspark.sql.types.IntegralType):
   553	            if isinstance(x, pyspark.sql.types.LongType):
   554	                return DataType.long
   555	            else:
   556	                return DataType.integer
   557	        elif isinstance(x, pyspark.sql.types.FloatType):
   558	            return DataType.float
   559	        elif isinstance(x, pyspark.sql.types.DoubleType):
   560	            return DataType.double
   561	    elif isinstance(x, pyspark.sql.types.BooleanType):
   562	        return DataType.boolean
   563	    elif isinstance(x, pyspark.sql.types.StringType):
   564	        return DataType.string
   565	    elif isinstance(x, pyspark.sql.types.BinaryType):
   566	        return DataType.binary
   567	    # NB: Spark differentiates date and timestamps, so we coerce both to TimestampType.
   568	    elif isinstance(x, (pyspark.sql.types.DateType, pyspark.sql.types.TimestampType)):
   569	        return DataType.datetime
   570	    elif isinstance(x, pyspark.sql.types.ArrayType):
   571	        return Array(_infer_spark_type(x.elementType))
   572	    elif isinstance(x, pyspark.sql.types.StructType):
   573	        return Object(
   574	            properties=[
   575	                Property(
   576	                    name=f.name,
   577	                    dtype=_infer_spark_type(f.dataType),
   578	                    required=not f.nullable,
   579	                )
   580	                for f in x.fields
   581	            ]
   582	        )
   583	    elif isinstance(x, pyspark.sql.types.MapType):
   584	        if data is None or col_name is None:
   585	            raise MlflowException("Cannot infer schema for MapType without data and column name.")
   586	        # Map MapType to StructType
   587	        # Note that MapType assumes all values are of same type,
   588	        # if they're not then spark picks the first item's type
   589	        # and tries to convert rest to that type.
   590	        # e.g.
   591	        # >>> spark.createDataFrame([{"col": {"a": 1, "b": "b"}}]).show()
   592	        # +-------------------+
   593	        # |                col|
   594	        # +-------------------+
   595	        # |{a -> 1, b -> null}|
   596	        # +-------------------+
   597	        if isinstance(x.valueType, pyspark.sql.types.MapType):
   598	            raise MlflowException(
   599	                "Please construct spark DataFrame with schema using StructType "
   600	                "for dictionary/map fields, MLflow schema inference only supports "
   601	                "scalar, array and struct types."
   602	            )
   603	
   604	        merged_keys = (
   605	            data.selectExpr(f"map_keys({col_name}) as keys")
   606	            .agg(collect_list(col("keys")).alias("merged_keys"))
   607	            .head()
   608	            .merged_keys
   609	        )
   610	        keys = {key for sublist in merged_keys for key in sublist}
   611	        return Object(
   612	            properties=[
   613	                Property(
   614	                    name=k,
   615	                    dtype=_infer_spark_type(x.valueType),
   616	                )
   617	                for k in keys
   618	            ]
   619	        )
   620	    elif isinstance(x, VectorUDT):
   621	        return SparkMLVector()
   622	
   623	    else:
   624	        raise MlflowException.invalid_parameter_value(
   625	            f"Unsupported Spark Type '{type(x)}' for MLflow schema."
   626	        )
   627	
   628	
   629	def _is_spark_df(x) -> bool:
   630	    try:
   631	        import pyspark.sql.dataframe
   632	
   633	        if isinstance(x, pyspark.sql.dataframe.DataFrame):
   634	            return True
   635	    except ImportError:
   636	        return False
   637	    # For spark 4.0
   638	    try:
   639	        import pyspark.sql.connect.dataframe
   640	
   641	        return isinstance(x, pyspark.sql.connect.dataframe.DataFrame)
   642	    except ImportError:
   643	        return False
   644	
   645	
   646	def _validate_input_dictionary_contains_only_strings_and_lists_of_strings(data) -> None:
   647	    # isinstance(True, int) is True
   648	    invalid_keys = [
   649	        key for key in data.keys() if not isinstance(key, (str, int)) or isinstance(key, bool)
   650	    ]
   651	    if invalid_keys:
   652	        raise MlflowException(
   653	            f"The dictionary keys are not all strings or indexes. Invalid keys: {invalid_keys}"
   654	        )
   655	    if any(isinstance(value, np.ndarray) for value in data.values()) and not all(
   656	        isinstance(value, np.ndarray) for value in data.values()
   657	    ):
   658	        raise MlflowException("The dictionary values are not all numpy.ndarray.")
   659	
   660	    invalid_values = [
   661	        key
   662	        for key, value in data.items()
   663	        if (isinstance(value, list) and not all(isinstance(item, (str, bytes)) for item in value))
   664	        or (not isinstance(value, (np.ndarray, list, str, bytes)))
   665	    ]
   666	    if invalid_values:
   667	        raise MlflowException.invalid_parameter_value(
   668	            "Invalid values in dictionary. If passing a dictionary containing strings, all "
   669	            "values must be either strings or lists of strings. If passing a dictionary containing "
   670	            "numeric values, the data must be enclosed in a numpy.ndarray. The following keys "
   671	            f"in the input dictionary are invalid: {invalid_values}",
   672	        )
   673	
   674	
   675	def _is_list_str(type_hint: Any) -> bool:
   676	    return type_hint in [
   677	        List[str],  # noqa: UP006
   678	        list[str],
   679	    ]
   680	
   681	
   682	def _is_list_dict_str(type_hint: Any) -> bool:
   683	    return type_hint in [
   684	        List[Dict[str, str]],  # noqa: UP006
   685	        list[Dict[str, str]],  # noqa: UP006
   686	        List[dict[str, str]],  # noqa: UP006
   687	        list[dict[str, str]],
   688	    ]
   689	
   690	
   691	def _get_array_depth(l: Any) -> int:
   692	    if isinstance(l, np.ndarray):
   693	        return l.ndim
   694	    if isinstance(l, list):
   695	        return max(_get_array_depth(item) for item in l) + 1 if l else 1
   696	    return 0
   697	
   698	
   699	def _infer_type_and_shape(value):
   700	    if isinstance(value, (list, np.ndarray)):
   701	        ndim = _get_array_depth(value)
   702	        if ndim != 1:
   703	            raise MlflowException.invalid_parameter_value(
   704	                f"Expected parameters to be 1D array or scalar, got {ndim}D array",
   705	            )
   706	        if all(DataType.check_type(DataType.datetime, v) for v in value):
   707	            return DataType.datetime, (-1,)
   708	        value_type = _infer_numpy_dtype(np.array(value).dtype)
   709	        return value_type, (-1,)
   710	    elif DataType.check_type(DataType.datetime, value):
   711	        return DataType.datetime, None
   712	    elif np.isscalar(value):
   713	        try:
   714	            value_type = _infer_numpy_dtype(np.array(value).dtype)
   715	            return value_type, None
   716	        except (Exception, MlflowException) as e:
   717	            raise MlflowException.invalid_parameter_value(
   718	                f"Failed to infer schema for parameter {value}: {e!r}"
   719	            )
   720	    elif isinstance(value, dict):
   721	        # reuse _infer_schema to infer schema for dict, wrapping it in a dictionary is
   722	        # necessary to make sure value is inferred as Object
   723	        schema = _infer_schema({"value": value})
   724	        object_type = schema.inputs[0].type
   725	        return object_type, None
   726	    raise MlflowException.invalid_parameter_value(
   727	        f"Expected parameters to be 1D array or scalar, got {type(value).__name__}",
   728	    )
   729	
   730	
   731	def _infer_param_schema(parameters: dict[str, Any]):
   732	    if not isinstance(parameters, dict):
   733	        raise MlflowException.invalid_parameter_value(
   734	            f"Expected parameters to be dict, got {type(parameters).__name__}",
   735	        )
   736	
   737	    param_specs = []
   738	    invalid_params = []
   739	    for name, value in parameters.items():
   740	        try:
   741	            value_type, shape = _infer_type_and_shape(value)
   742	            param_specs.append(
   743	                ParamSpec(name=name, dtype=value_type, default=deepcopy(value), shape=shape)
   744	            )
   745	        except Exception as e:
   746	            invalid_params.append((name, value, e))
   747	
   748	    if invalid_params:
   749	        raise MlflowException.invalid_parameter_value(
   750	            f"Failed to infer schema for parameters: {invalid_params}",
   751	        )
   752	
   753	    return ParamSchema(param_specs)
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/data/dataset.py | sed -n '1,300p'; nl -ba mlflow/data/schema.py | sed -n '1,240p'"
```

退出码：`0`

输出：
```
     1	import json
     2	from abc import abstractmethod
     3	from typing import Any
     4	
     5	from mlflow.data.dataset_source import DatasetSource
     6	from mlflow.entities import Dataset as DatasetEntity
     7	
     8	
     9	class Dataset:
    10	    """
    11	    Represents a dataset for use with MLflow Tracking, including the name, digest (hash),
    12	    schema, and profile of the dataset as well as source information (e.g. the S3 bucket or
    13	    managed Delta table from which the dataset was derived). Most datasets expose features
    14	    and targets for training and evaluation as well.
    15	    """
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	    @abstractmethod
    28	    def _compute_digest(self) -> str:
    29	        """Computes a digest for the dataset. Called if the user doesn't supply
    30	        a digest when constructing the dataset.
    31	
    32	        Returns:
    33	            A string digest for the dataset. We recommend a maximum digest length
    34	            of 10 characters with an ideal length of 8 characters.
    35	
    36	        """
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	    def _get_source_type(self) -> str:
    66	        """Returns the type of the dataset's underlying source."""
    67	
    68	        return self.source._get_source_type()
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	    @property
    88	    def source(self) -> DatasetSource:
    89	        """
    90	        Information about the dataset's source, represented as an instance of
    91	        :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`. For example, this
    92	        may be the S3 location or the name of the managed Delta Table from which the dataset
    93	        was derived.
    94	        """
    95	        return self._source
    96	
    97	    @property
    98	    @abstractmethod
    99	    def profile(self) -> Any | None:
   100	        """
   101	        Optional summary statistics for the dataset, such as the number of rows in a table, the
   102	        mean / median / std of each table column, etc.
   103	        """
   104	
   105	    @property
   106	    @abstractmethod
   107	    def schema(self) -> Any | None:
   108	        """
   109	        Optional dataset schema, such as an instance of :py:class:`mlflow.types.Schema` representing
   110	        the features and targets of the dataset.
   111	        """
   112	
   113	    def _to_mlflow_entity(self) -> DatasetEntity:
   114	        """
   115	        Returns:
   116	            A `mlflow.entities.Dataset` instance representing the dataset.
   117	        """
   118	        dataset_dict = self.to_dict()
   119	        return DatasetEntity(
   120	            name=dataset_dict["name"],
   121	            digest=dataset_dict["digest"],
   122	            source_type=dataset_dict["source_type"],
   123	            source=dataset_dict["source"],
   124	            schema=dataset_dict.get("schema"),
   125	            profile=dataset_dict.get("profile"),
   126	        )
     1	from typing import Any
     2	
     3	from mlflow.exceptions import MlflowException
     4	from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
     5	from mlflow.types.schema import Schema
     6	
     7	
     8	class TensorDatasetSchema:
     9	    """
    10	    Represents the schema of a dataset with tensor features and targets.
    11	    """
    12	
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	    def __eq__(self, other) -> bool:
    69	        return (
    70	            isinstance(other, TensorDatasetSchema)
    71	            and self.features == other.features
    72	            and self.targets == other.targets
    73	        )
    74	
    75	    def __repr__(self) -> str:
    76	        return f"features:\n  {self.features!r}\ntargets:\n  {self.targets!r}\n"
```

## 原始行 23 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/data/evaluation_dataset.py | sed -n '1,500p'"
```

退出码：`0`

输出：
```
     1	import hashlib
     2	import json
     3	import logging
     4	import math
     5	import struct
     6	import sys
     7	
     8	from packaging.version import Version
     9	
    10	import mlflow
    11	from mlflow.entities import RunTag
    12	from mlflow.exceptions import MlflowException
    13	from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    14	from mlflow.utils.string_utils import generate_feature_name_if_not_string
    15	
    16	try:
    17	    # `numpy` and `pandas` are not required for `mlflow-skinny`.
    18	    import numpy as np
    19	    import pandas as pd
    20	except ImportError:
    21	    pass
    22	
    23	_logger = logging.getLogger(__name__)
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	def _hash_array_of_dict_as_bytes(data):
    56	    # NB: If an array or list contains dictionary element, it can't be hashed with
    57	    # pandas.util.hash_array. Hence we need to manually hash the elements here. This is
    58	    # particularly for the LLM use case where the input can be a list of dictionary
    59	    # (chat/completion payloads), so doesn't handle more complex case like nested lists.
    60	    result = b""
    61	    for elm in data:
    62	        if isinstance(elm, (list, np.ndarray)):
    63	            result += _hash_array_of_dict_as_bytes(elm)
    64	        elif isinstance(elm, dict):
    65	            result += _hash_dict_as_bytes(elm)
    66	        else:
    67	            result += _hash_data_as_bytes(elm)
    68	    return result
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	def _hash_data_as_bytes(data):
    84	    try:
    85	        if isinstance(data, (list, np.ndarray)):
    86	            return _hash_ndarray_as_bytes(data)
    87	        if isinstance(data, dict):
    88	            return _hash_dict_as_bytes(data)
    89	        if np.isscalar(data):
    90	            return _hash_uint64_ndarray_as_bytes(pd.util.hash_array(np.array([data])))
    91	    except Exception:
    92	        pass
    93	    # Skip unsupported types by returning an empty byte string
    94	    return b""
    95	
    96	
    97	def _hash_dict_as_bytes(data_dict):
    98	    result = _hash_ndarray_as_bytes(list(data_dict.keys()))
    99	    try:
   100	        result += _hash_ndarray_as_bytes(list(data_dict.values()))
   101	    # If the values containing non-hashable objects, we will hash the values recursively.
   102	    except Exception:
   103	        for value in data_dict.values():
   104	            result += _hash_data_as_bytes(value)
   105	    return result
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	def convert_data_to_mlflow_dataset(data, targets=None, predictions=None, name=None):
   182	    """Convert input data to mlflow dataset."""
   183	    supported_dataframe_types = [pd.DataFrame]
   184	    if "pyspark" in sys.modules:
   185	        from mlflow.utils.spark_utils import get_spark_dataframe_type
   186	
   187	        spark_df_type = get_spark_dataframe_type()
   188	        supported_dataframe_types.append(spark_df_type)
   189	
   190	    if predictions is not None:
   191	        _validate_dataset_type_supports_predictions(
   192	            data=data, supported_predictions_dataset_types=supported_dataframe_types
   193	        )
   194	
   195	    if isinstance(data, list):
   196	        # If the list is flat, we assume each element is an independent sample.
   197	        if not isinstance(data[0], (list, np.ndarray)):
   198	            data = [[elm] for elm in data]
   199	
   200	        return mlflow.data.from_numpy(
   201	            np.array(data), targets=np.array(targets) if targets else None, name=name
   202	        )
   203	    elif isinstance(data, np.ndarray):
   204	        return mlflow.data.from_numpy(data, targets=targets, name=name)
   205	    elif isinstance(data, pd.DataFrame):
   206	        return mlflow.data.from_pandas(df=data, targets=targets, predictions=predictions, name=name)
   207	    elif "pyspark" in sys.modules and isinstance(data, spark_df_type):
   208	        return mlflow.data.from_spark(df=data, targets=targets, predictions=predictions, name=name)
   209	    else:
   210	        # Cannot convert to mlflow dataset, return original data.
   211	        _logger.info(
   212	            "Cannot convert input data to `evaluate()` to an mlflow dataset, input must be a list, "
   213	            f"a numpy array, a panda Dataframe or a spark Dataframe, but received {type(data)}."
   214	        )
   215	        return data
   216	
   217	
   218	def _validate_dataset_type_supports_predictions(data, supported_predictions_dataset_types):
   219	    """
   220	    Validate that the dataset type supports a user-specified "predictions" column.
   221	    """
   222	    if not any(isinstance(data, sdt) for sdt in supported_predictions_dataset_types):
   223	        raise MlflowException(
   224	            message=(
   225	                "If predictions is specified, data must be one of the following types, or an"
   226	                " MLflow Dataset that represents one of the following types:"
   227	                f" {supported_predictions_dataset_types}."
   228	            ),
   229	            error_code=INVALID_PARAMETER_VALUE,
   230	        )
   231	
   232	
   233	class EvaluationDataset:
   234	    """
   235	    An input dataset for model evaluation. This is intended for use with the
   236	    :py:func:`mlflow.models.evaluate()`
   237	    API.
   238	    """
   239	
   240	    NUM_SAMPLE_ROWS_FOR_HASH = 5
   241	    SPARK_DATAFRAME_LIMIT = 10000
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	
   303	
   304	
   305	
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	
   414	
   415	
   416	
   417	
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	    @property
   426	    def feature_names(self):
   427	        return self._feature_names
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	    @property
   437	    def labels_data(self):
   438	        """
   439	        return labels data as a numpy array
   440	        """
   441	        return self._labels_data
   442	
   443	    @property
   444	    def has_targets(self):
   445	        """
   446	        Returns True if the dataset has targets, False otherwise.
   447	        """
   448	        return self._has_targets
   449	
   450	    @property
   451	    def targets_name(self):
   452	        """
   453	        return targets name
   454	        """
   455	        return self._targets_name
   456	
   457	    @property
   458	    def predictions_data(self):
   459	        """
   460	        return labels data as a numpy array
   461	        """
   462	        return self._predictions_data
   463	
   464	    @property
   465	    def has_predictions(self):
   466	        """
   467	        Returns True if the dataset has targets, False otherwise.
   468	        """
   469	        return self._has_predictions
   470	
   471	    @property
   472	    def predictions_name(self):
   473	        """
   474	        return predictions name
   475	        """
   476	        return self._predictions_name
   477	
   478	    @property
   479	    def name(self):
   480	        """
   481	        Dataset name, which is specified dataset name or the dataset hash if user don't specify
   482	        name.
   483	        """
   484	        return self._user_specified_name if self._user_specified_name is not None else self.hash
   485	
   486	    @property
   487	    def path(self):
   488	        """
   489	        Dataset path
   490	        """
   491	        return self._path
   492	
   493	    @property
   494	    def hash(self):
   495	        """
   496	        Dataset hash, includes hash on first 20 rows and last 20 rows.
   497	        """
   498	        return self._hash
   499	
   500	    @property
```

## 原始行 25 · command_execution

命令：
```
/bin/bash -lc 'git status --short; find tests -type f | head -n 80; find mlflow/data -maxdepth 2 -type f | sort'
```

退出码：`0`

输出：
```
tests/examples/test_examples.py
tests/examples/README.md
tests/examples/__init__.py
tests/webhooks/test_e2e.py
tests/webhooks/test_delivery.py
tests/webhooks/__init__.py
tests/webhooks/app.py
tests/dev/test_update_mlflow_versions.py
tests/dev/test_remove_experimental_decorators.py
tests/dev/test_check_function_signatures.py
tests/dev/__init__.py
tests/dev/test_check_init_py.py
tests/dspy/test_save.py
tests/dspy/test_dspy_evaluate.py
tests/dspy/test_dspy_autolog.py
tests/dspy/test_dspy_util.py
tests/dspy/__init__.py
tests/dspy/conftest.py
tests/pmdarima/test_pmdarima_model_export.py
tests/pmdarima/__init__.py
tests/litellm/__init__.py
tests/litellm/conftest.py
tests/litellm/test_litellm_autolog.py
tests/test_mlflow_version_comp.py
tests/autogen/test_autogen_autolog.py
tests/autogen/__init__.py
tests/autologging/test_autologging_behaviors_unit.py
tests/autologging/test_autologging_client.py
tests/autologging/test_autologging_utils.py
tests/autologging/test_training_session.py
tests/autologging/test_autologging_behaviors_integration.py
tests/autologging/test_autologging_safety_unit.py
tests/autologging/__init__.py
tests/autologging/async_helper.py
tests/autologging/fixtures.py
tests/langchain/test_langchain_tracer.py
tests/langchain/test_langchain_output_parsers.py
tests/langchain/test_langchain_document_conversion.py
tests/langchain/test_langchain_databricks_integration.py
tests/langchain/state_of_the_union.txt
tests/langchain/test_langchain_autolog.py
tests/langchain/test_chat_utils.py
tests/langchain/sample_code/chain.py
tests/langchain/sample_code/model_with_config.py
tests/langchain/sample_code/workflow.py
tests/langchain/sample_code/langchain_chat_agent.py
tests/langchain/sample_code/config.yml
tests/langchain/sample_code/no_config/chain.py
tests/langchain/sample_code/chain_with_mlflow_prompt.py
tests/langchain/sample_code/openai_agent.py
tests/langchain/test_langchain_databricks_dependency_extraction.py
tests/langchain/test_responses_agent_langchain.py
tests/langchain/test_chat_agent_langchain.py
tests/langchain/__init__.py
tests/langchain/agent_executor/chain.py
tests/langchain/agent_executor/config.yml
tests/langchain/conftest.py
tests/langchain/test_langchain_model_export.py
tests/langchain/test_langchain_evaluation.py
tests/spacy/test_spacy_model_export.py
tests/spacy/__init__.py
tests/test_cli.py
tests/prophet/test_prophet_model_export.py
tests/prophet/__init__.py
tests/optuna/test_storage.py
tests/optuna/__init__.py
tests/mistral/test_mistral_autolog.py
tests/mistral/__init__.py
tests/spark/autologging/ml/test_pyspark_ml_autologging.py
tests/spark/autologging/ml/test_pyspark_ml_autologging_custom_allowlist.py
tests/spark/autologging/ml/__init__.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_order.py
tests/spark/autologging/datasource/test_spark_datasource_autologging.py
tests/spark/autologging/datasource/test_autologging_behavior_without_spark_session.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_crossframework.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_missing_jar.py
tests/spark/autologging/datasource/__init__.py
tests/spark/autologging/datasource/conftest.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_unit.py
tests/spark/autologging/datasource/test_spark_disable_autologging.py
mlflow/data/__init__.py
mlflow/data/artifact_dataset_sources.py
mlflow/data/code_dataset_source.py
mlflow/data/dataset.py
mlflow/data/dataset_registry.py
mlflow/data/dataset_source.py
mlflow/data/dataset_source_registry.py
mlflow/data/delta_dataset_source.py
mlflow/data/digest_utils.py
mlflow/data/evaluation_dataset.py
mlflow/data/evaluation_dataset_source.py
mlflow/data/filesystem_dataset_source.py
mlflow/data/http_dataset_source.py
mlflow/data/huggingface_dataset.py
mlflow/data/huggingface_dataset_source.py
mlflow/data/meta_dataset.py
mlflow/data/numpy_dataset.py
mlflow/data/pandas_dataset.py
mlflow/data/polars_dataset.py
mlflow/data/pyfunc_dataset_mixin.py
mlflow/data/schema.py
mlflow/data/sources.py
mlflow/data/spark_dataset.py
mlflow/data/spark_dataset_source.py
mlflow/data/spark_delta_utils.py
mlflow/data/tensorflow_dataset.py
mlflow/data/uc_volume_dataset_source.py
```

## 原始行 27 · command_execution

命令：
```
/bin/bash -lc "grep -RInE '_get_tensor_shape|clean_tensor_type|_infer_schema\\(|features_data|TensorDatasetSchema|is_tensor_spec' tests mlflow --exclude='*.pyc' | head -n 600"
```

退出码：`0`

输出：
```
tests/pyfunc/test_spark.py:1388:        _infer_schema(complex_df)
tests/tensorflow/test_tensorflow2_autolog.py:228:        feature_schema = _infer_schema(data)
tests/tensorflow/test_tensorflow2_autolog.py:229:        target_schema = _infer_schema(labels)
tests/tensorflow/test_tensorflow2_autolog.py:271:        feature_schema = _infer_schema(data_as_tensor.numpy())
tests/tensorflow/test_tensorflow2_autolog.py:272:        target_schema = _infer_schema(labels_as_tensor.numpy())
tests/tensorflow/test_tensorflow2_autolog.py:301:                    "features": _infer_schema(
tests/genai/datasets/test_evaluation_dataset.py:191:    assert legacy_dataset._features_data.equals(dataset.to_df())
tests/lightgbm/test_lightgbm_autolog.py:650:    assert signature.inputs == _infer_schema(X)
tests/lightgbm/test_lightgbm_autolog.py:772:            {"mlflow_colspec": _infer_schema(train_set.data).to_dict()}
tests/lightgbm/test_lightgbm_autolog.py:789:        {"mlflow_colspec": _infer_schema(train_set.data).to_dict()}
tests/lightgbm/test_lightgbm_autolog.py:793:        {"mlflow_colspec": _infer_schema(valid_set.data).to_dict()}
tests/pytorch/test_pytorch_model_export.py:80:def iris_tensor_spec():
tests/pytorch/test_pytorch_model_export.py:209:def test_signature_and_examples_are_saved_correctly(sequential_model, data, iris_tensor_spec):
tests/pytorch/test_pytorch_model_export.py:212:    for signature in (None, iris_tensor_spec):
tests/pytorch/test_pytorch_model_export.py:223:                    assert mlflow_model.signature == iris_tensor_spec
tests/utils/test_proto_json_utils.py:301:    new_schema = _infer_schema(tfserving_input["instances"])
tests/types/test_schema.py:34:    _get_tensor_shape,
tests/types/test_schema.py:179:    schema = _infer_schema(dict_of_ndarrays)
tests/types/test_schema.py:191:    schema = _infer_schema(basic_types)
tests/types/test_schema.py:202:    schema = _infer_schema(ext_types)
tests/types/test_schema.py:208:    schema = _infer_schema(pd.Series(np.array(["a"], dtype=object)))
tests/types/test_schema.py:210:    schema = _infer_schema(pd.Series(np.array([bytes([1])], dtype=object)))
tests/types/test_schema.py:212:    schema = _infer_schema(pd.Series(np.array([bytearray([1]), None], dtype=object), name="input"))
tests/types/test_schema.py:214:    schema = _infer_schema(pd.Series(np.array([1.1, None], dtype=object), name="input"))
tests/types/test_schema.py:218:    schema = _infer_schema(pd.Series(np.array([bytes([1])], dtype=np.bytes_)))
tests/types/test_schema.py:222:    schema = _infer_schema(pd.Series(np.array(["a"], dtype=str)))
tests/types/test_schema.py:226:    schema = _infer_schema(pd.Series(np.array([True], dtype=bool)))
tests/types/test_schema.py:231:        schema = _infer_schema(pd.Series(np.array([1, 2, 3], dtype=t)))
tests/types/test_schema.py:236:        schema = _infer_schema(pd.Series(np.array([1, 2, 3], dtype=t)))
tests/types/test_schema.py:241:        _infer_schema(pd.Series(np.array([1, 2, 3], dtype=np.uint64)))
tests/types/test_schema.py:245:        schema = _infer_schema(pd.Series(np.array([1.1, 2.2, 3.3], dtype=t)))
tests/types/test_schema.py:249:    schema = _infer_schema(pd.Series(np.array([1.1, 2.2, 3.3], dtype=np.float64)))
tests/types/test_schema.py:253:    schema = _infer_schema(
tests/types/test_schema.py:266:            _infer_schema(pd.Series(np.array([1, 2, 3], dtype=np.float128)))
tests/types/test_schema.py:272:        assert "test" in _infer_schema(s).input_names()
tests/types/test_schema.py:273:        assert len(_infer_schema(s).input_names()) == 1
tests/types/test_schema.py:276:def test_get_tensor_shape(dict_of_ndarrays):
tests/types/test_schema.py:277:    assert all(-1 == _get_tensor_shape(tensor)[0] for tensor in dict_of_ndarrays.values())
tests/types/test_schema.py:282:        assert _get_tensor_shape(data, i)[i] == -1
tests/types/test_schema.py:285:    assert all([_get_tensor_shape(data, None) != -1])
tests/types/test_schema.py:291:        _get_tensor_shape(data, 10)
tests/types/test_schema.py:295:        _get_tensor_shape(data, -10)
tests/types/test_schema.py:308:        schema = _infer_schema(sparse_matrix)
tests/types/test_schema.py:310:        assert _get_tensor_shape(sparse_matrix) == (-1, 8)
tests/types/test_schema.py:315:    schema = _infer_schema(dict_of_ndarrays)
tests/types/test_schema.py:318:            TensorSpec(tensor.dtype, _get_tensor_shape(tensor), name)
tests/types/test_schema.py:348:    assert _infer_schema(data) == schema
tests/types/test_schema.py:354:        _infer_schema(data)
tests/types/test_schema.py:360:            _infer_schema(data)
tests/types/test_schema.py:365:        _infer_schema(["a", 1])
tests/types/test_schema.py:368:        _infer_schema(["a", ["b", "c"]])
tests/types/test_schema.py:372:    schema = _infer_schema([{"a": "a", "b": "b"}, {"a": "a", "b": "b"}])
tests/types/test_schema.py:375:    schema = _infer_schema([{"a": 1}, {"b": "a"}])
tests/types/test_schema.py:468:        schema = _infer_schema(data)
tests/types/test_schema.py:475:        schema = _infer_schema(nparray)
tests/types/test_schema.py:598:    schema = _infer_schema(pandas_df_with_all_types)
tests/types/test_schema.py:611:        schema = _infer_schema(sparkdf)
tests/types/test_schema.py:620:    schema = _infer_schema(df)
tests/types/test_schema.py:639:    schema = _infer_schema(df)
tests/types/test_schema.py:668:    schema = _infer_schema(df)
tests/types/test_schema.py:705:    schema = _infer_schema(pandas_df_with_all_types)
tests/types/test_schema.py:715:        schema2 = _infer_schema(sparkdf)
tests/types/test_schema.py:735:    inferred_schema = _infer_schema(ragged_array)
tests/types/test_schema.py:751:    standard_spec = _infer_schema(standard_array).inputs[0]
tests/types/test_schema.py:1519:    schema = _infer_schema(data)
tests/types/test_schema.py:1567:    schema = _infer_schema(data)
tests/types/test_schema.py:1621:    assert _infer_schema(data) == Schema([ColSpec(data_type)])
tests/types/test_schema.py:1641:    assert _infer_schema(test_data) == Schema([ColSpec(Array(data_type), name="data")])
tests/types/test_schema.py:1644:    inferred_schema = _infer_schema(test_data)
tests/types/test_schema.py:1665:    assert _infer_schema(data) == Schema([ColSpec(data_type)])
tests/types/test_schema.py:1668:    assert _infer_schema(test_data) == Schema([ColSpec(Array(data_type), name="data")])
tests/types/test_schema.py:1671:    assert _infer_schema(test_data) == Schema([ColSpec(Array(Array(data_type)), name="data")])
tests/types/test_schema.py:1674:    inferred_schema = _infer_schema(test_data)
tests/types/test_schema.py:1691:    inferred_schema = _infer_schema(test_data)
tests/types/test_schema.py:1705:    assert _infer_schema(data) == Schema([ColSpec(DataType.string)])
tests/types/test_schema.py:1708:    assert _infer_schema(data) == Schema([ColSpec(DataType.string)])
tests/types/test_schema.py:1711:    assert _infer_schema(data) == Schema([ColSpec(Array(DataType.string))])
tests/types/test_schema.py:1714:    assert _infer_schema(data) == Schema([ColSpec(Array(AnyType()))])
tests/types/test_schema.py:1716:    assert _infer_schema([[]]) == Schema([ColSpec(AnyType())])
tests/types/test_schema.py:1723:        _infer_schema([np.array([])])
tests/types/test_schema.py:1736:    inferred_schema = _infer_schema(data)
tests/types/test_schema.py:1754:    inferred_schema = _infer_schema(data)
tests/types/test_schema.py:1759:    assert _infer_schema(data) == Schema(
tests/types/test_schema.py:2066:    inferred_schema = _infer_schema(data)
tests/types/test_type_hints.py:500:    schema = _infer_schema(data)
tests/xgboost/test_xgboost_autolog.py:741:        feature_schema = _infer_schema(dtrain.get_data().toarray())
tests/xgboost/test_xgboost_autolog.py:772:    dtrain_feature_schema = _infer_schema(dtrain.get_data().toarray())
tests/xgboost/test_xgboost_autolog.py:782:    deval_feature_schema = _infer_schema(deval.get_data().toarray())
tests/sklearn/test_sklearn_autolog.py:1156:        feature_schema = _infer_schema(X)
tests/sklearn/test_sklearn_autolog.py:1157:        target_schema = _infer_schema(y)
tests/sklearn/test_sklearn_autolog.py:1185:    feature_schema = _infer_schema(X)
tests/sklearn/test_sklearn_autolog.py:1186:    target_schema = _infer_schema(y)
tests/sklearn/test_sklearn_autolog.py:1220:    feature_schema = _infer_schema(X)
tests/sklearn/test_sklearn_autolog.py:1221:    target_schema = _infer_schema(y)
tests/data/test_huggingface_dataset_and_source.py:57:    assert mlflow_ds.schema == _infer_schema(ds.to_pandas())
tests/data/test_huggingface_dataset_and_source.py:109:    assert mlflow_ds.schema == _infer_schema(ds.to_pandas())
tests/data/test_huggingface_dataset_and_source.py:138:    assert mlflow_ds.schema == _infer_schema(ds.to_pandas())
tests/data/test_huggingface_dataset_and_source.py:266:    assert evaluation_dataset.features_data.equals(dataset.ds.to_pandas().drop("label", axis=1))
tests/data/test_polars_dataset.py:29:def test_infer_schema() -> None:
tests/data/test_polars_dataset.py:259:    assert isinstance(evaluation_dataset.features_data, pd.DataFrame)
tests/data/test_polars_dataset.py:260:    assert evaluation_dataset.features_data.equals(df.drop("c").to_pandas())
tests/data/test_pandas_dataset.py:167:    assert mlflow_df.schema == _infer_schema(df)
tests/data/test_pandas_dataset.py:187:    assert mlflow_df.schema == _infer_schema(df)
tests/data/test_pandas_dataset.py:207:    assert mlflow_df.schema == _infer_schema(df)
tests/data/test_pandas_dataset.py:243:    assert evaluation_dataset.features_data.equals(df.drop("c", axis=1))
tests/data/test_pandas_dataset.py:282:    assert evaluation_dataset.features_data.equals(df)
tests/data/test_tensorflow_dataset.py:11:from mlflow.data.schema import TensorDatasetSchema
tests/data/test_tensorflow_dataset.py:96:    assert TensorDatasetSchema.from_dict(parsed_schema) == dataset.schema
tests/data/test_tensorflow_dataset.py:161:    assert TensorDatasetSchema.from_dict(parsed_schema) == dataset.schema
tests/data/test_tensorflow_dataset.py:165:    features_dataset = tf.data.Dataset.from_tensors(
tests/data/test_tensorflow_dataset.py:180:        features=features_dataset, targets=targets_dataset, source=source, name="testname"
tests/data/test_tensorflow_dataset.py:182:    assert dataset.schema.features == _infer_schema(
tests/data/test_tensorflow_dataset.py:188:    assert dataset.schema.targets == _infer_schema(
tests/data/test_tensorflow_dataset.py:199:        "features_cardinality": features_dataset.cardinality().numpy(),
tests/data/test_tensorflow_dataset.py:205:    features_dataset = tf.data.Dataset.from_tensors(
tests/data/test_tensorflow_dataset.py:214:        features=features_dataset, targets=targets_dataset, source=source, name="testname"
tests/data/test_tensorflow_dataset.py:216:    assert dataset.schema.features == _infer_schema(
tests/data/test_tensorflow_dataset.py:222:    assert dataset.schema.targets == _infer_schema(
tests/data/test_tensorflow_dataset.py:233:        "features_cardinality": features_dataset.cardinality().numpy(),
tests/data/test_tensorflow_dataset.py:309:    assert np.array_equal(evaluation_dataset.features_data, dataset.data.numpy())
tests/data/test_tensorflow_dataset.py:335:    assert mlflow_ds.schema == TensorDatasetSchema(
tests/data/test_tensorflow_dataset.py:336:        features=_infer_schema(next(tf_dataset.as_numpy_iterator()))
tests/data/test_tensorflow_dataset.py:352:    assert mlflow_ds.schema == TensorDatasetSchema(
tests/data/test_tensorflow_dataset.py:353:        features=_infer_schema(next(tf_dataset_x.as_numpy_iterator())),
tests/data/test_tensorflow_dataset.py:354:        targets=_infer_schema(next(tf_dataset_y.as_numpy_iterator())),
tests/data/test_tensorflow_dataset.py:369:    assert mlflow_ds.schema == TensorDatasetSchema(features=_infer_schema(tf_tensor.numpy()))
tests/data/test_tensorflow_dataset.py:384:    assert mlflow_ds.schema == TensorDatasetSchema(
tests/data/test_tensorflow_dataset.py:385:        features=_infer_schema(tf_tensor_x.numpy()),
tests/data/test_tensorflow_dataset.py:386:        targets=_infer_schema(tf_tensor_y.numpy()),
tests/data/test_spark_dataset.py:73:    assert dataset.schema == _infer_schema(original_df)
tests/data/test_spark_dataset.py:421:    assert evaluation_dataset.features_data.equals(df_spark.toPandas()[["a"]])
tests/resources/mlflow-test-plugin/mlflow_test_plugin/dummy_evaluator.py:115:        self.X = dataset.features_data
tests/resources/mlflow-test-plugin/mlflow_test_plugin/dummy_dataset.py:64:        return _infer_schema(self._data_list)
tests/resources/data/dataset.py:69:        return _infer_schema(np.array(self._data_list))
tests/evaluate/test_default_evaluator.py:150:    y_pred = model.predict(diabetes_dataset.features_data)
tests/evaluate/test_default_evaluator.py:154:        diabetes_dataset.features_data, diabetes_dataset.labels_data, sample_weight=sample_weights
tests/evaluate/test_default_evaluator.py:200:    y_pred = model.predict(diabetes_dataset.features_data)
tests/evaluate/test_default_evaluator.py:204:        diabetes_dataset.features_data, diabetes_dataset.labels_data
tests/evaluate/test_default_evaluator.py:252:    y_pred = predict_fn(iris_dataset.features_data)
tests/evaluate/test_default_evaluator.py:253:    y_probs = predict_proba_fn(iris_dataset.features_data)
tests/evaluate/test_default_evaluator.py:259:        iris_dataset.features_data, iris_dataset.labels_data, sample_weight=sample_weights
tests/evaluate/test_default_evaluator.py:311:    y_pred = predict_fn(iris_dataset.features_data)
tests/evaluate/test_default_evaluator.py:312:    y_probs = predict_proba_fn(iris_dataset.features_data)
tests/evaluate/test_default_evaluator.py:318:        iris_dataset.features_data, iris_dataset.labels_data
tests/evaluate/test_default_evaluator.py:345:    y_pred = predict_fn(breast_cancer_dataset.features_data)
tests/evaluate/test_default_evaluator.py:346:    y_probs = predict_proba_fn(breast_cancer_dataset.features_data)
tests/evaluate/test_default_evaluator.py:350:        breast_cancer_dataset.features_data,
tests/evaluate/test_default_evaluator.py:408:    y_pred = predict_fn(breast_cancer_dataset.features_data)
tests/evaluate/test_default_evaluator.py:409:    y_probs = predict_proba_fn(breast_cancer_dataset.features_data)
tests/evaluate/test_default_evaluator.py:415:        breast_cancer_dataset.features_data, breast_cancer_dataset.labels_data
tests/evaluate/test_default_evaluator.py:439:    X = diabetes_spark_dataset.features_data
tests/evaluate/test_default_evaluator.py:480:    X = diabetes_spark_dataset.features_data
tests/evaluate/test_default_evaluator.py:527:    y_pred = predict_fn(breast_cancer_dataset.features_data)
tests/evaluate/test_default_evaluator.py:531:        breast_cancer_dataset.features_data, breast_cancer_dataset.labels_data
tests/evaluate/test_default_evaluator.py:609:    y_pred = predict_fn(breast_cancer_dataset.features_data)
tests/evaluate/test_default_evaluator.py:613:        breast_cancer_dataset.features_data, breast_cancer_dataset.labels_data
tests/evaluate/test_default_evaluator.py:715:        predict_fn(breast_cancer_dataset.features_data),
tests/evaluate/test_default_evaluator.py:716:        raw_model.predict(breast_cancer_dataset.features_data),
tests/evaluate/test_default_evaluator.py:719:        predict_proba_fn(breast_cancer_dataset.features_data),
tests/evaluate/test_default_evaluator.py:720:        raw_model.predict_proba(breast_cancer_dataset.features_data),
tests/evaluate/test_default_evaluator.py:1481:    y_pred = predict_fn(breast_cancer_dataset.features_data)
tests/evaluate/test_default_evaluator.py:1844:    y_pred = model.predict(iris_dataset.features_data)
tests/evaluate/test_evaluation.py:405:    y_pred = classifier_model.predict(iris_dataset.features_data)
tests/evaluate/test_evaluation.py:530:    y_pred = regressor_model.predict(diabetes_dataset.features_data)
tests/evaluate/test_evaluation.py:751:    assert list(eval_dataset.features_data.columns) == ["f1", "f2", "f3"]
tests/evaluate/test_evaluation.py:752:    np.testing.assert_array_equal(eval_dataset.features_data.f1.to_numpy(), [1, 2])
tests/evaluate/test_evaluation.py:753:    np.testing.assert_array_equal(eval_dataset.features_data.f2.to_numpy(), [3, 4])
tests/evaluate/test_evaluation.py:754:    np.testing.assert_array_equal(eval_dataset.features_data.f3.to_numpy(), [5, 6])
tests/evaluate/test_evaluation.py:758:    assert list(eval_dataset2.features_data.columns) == ["f3", "f2"]
tests/evaluate/test_evaluation.py:759:    np.testing.assert_array_equal(eval_dataset2.features_data.f2.to_numpy(), [3, 4])
tests/evaluate/test_evaluation.py:760:    np.testing.assert_array_equal(eval_dataset2.features_data.f3.to_numpy(), [5, 6])
tests/evaluate/test_evaluation.py:769:        np.testing.assert_array_equal(eval_dataset1.features_data, features)
tests/evaluate/test_evaluation.py:805:        assert list(dataset.features_data.columns) == ["f1", "f2"]
tests/evaluate/test_evaluation.py:806:        assert list(dataset.features_data["f1"]) == [1.0] * 5
tests/evaluate/test_evaluation.py:807:        assert list(dataset.features_data["f2"]) == [2.0] * 5
tests/evaluate/test_evaluation.py:1289:            y = model.predict(pd.DataFrame(dataset.features_data))
mlflow/utils/proto_json_utils.py:313:    elif schema.is_tensor_spec() and len(schema.input_types()) == 1:
mlflow/utils/proto_json_utils.py:335:                elif schema.is_tensor_spec() and isinstance(pdf[col_name].iloc[0], list):
mlflow/types/schema.py:1048:        if self.is_tensor_spec():
mlflow/types/schema.py:1058:        if self.is_tensor_spec():
mlflow/types/schema.py:1072:        if self.is_tensor_spec():
mlflow/types/utils.py:723:        schema = _infer_schema({"value": value})
mlflow/models/evaluation/default_evaluator.py:774:        if isinstance(self.dataset.features_data, pd.DataFrame):
mlflow/models/evaluation/default_evaluator.py:777:                data = self.dataset.features_data.assign(
mlflow/models/evaluation/default_evaluator.py:784:                data = self.dataset.features_data.assign(outputs=y_pred)
mlflow/models/evaluation/default_evaluator.py:787:            data = pd.DataFrame(self.dataset.features_data, columns=self.dataset.feature_names)
mlflow/models/evaluation/default_evaluator.py:952:                self.dataset.features_data, self.dataset.feature_names
mlflow/models/utils.py:733:    if clean_tensor_type(actual_type) != expected_type:
mlflow/models/utils.py:1149:    if not input_schema.is_tensor_spec():
mlflow/models/utils.py:1262:    elif not input_schema.is_tensor_spec():
mlflow/models/utils.py:1272:    if input_schema.is_tensor_spec():
mlflow/models/signature.py:263:                    convert_dataclass_to_schema(data) if is_dataclass(data) else _infer_schema(data)
mlflow/models/signature.py:531:        input_schema = _infer_schema(input_data)
mlflow/models/signature.py:542:            not input_schema.is_tensor_spec()
mlflow/models/signature.py:550:            output_schema = _infer_schema(prediction)
mlflow/data/pandas_dataset.py:133:            return _infer_schema(self._df)
mlflow/data/numpy_dataset.py:13:from mlflow.data.schema import TensorDatasetSchema
mlflow/data/numpy_dataset.py:120:    def schema(self) -> TensorDatasetSchema | None:
mlflow/data/numpy_dataset.py:125:            features_schema = _infer_schema(self._features)
mlflow/data/numpy_dataset.py:128:                targets_schema = _infer_schema(self._targets)
mlflow/data/numpy_dataset.py:129:            return TensorDatasetSchema(features=features_schema, targets=targets_schema)
mlflow/data/tensorflow_dataset.py:17:from mlflow.data.schema import TensorDatasetSchema
mlflow/data/tensorflow_dataset.py:207:    def schema(self) -> TensorDatasetSchema | None:
mlflow/data/tensorflow_dataset.py:216:            return TensorDatasetSchema(features=features_schema, targets=targets_schema)
mlflow/data/tensorflow_dataset.py:228:                return _infer_schema(numpy_data)
mlflow/data/tensorflow_dataset.py:241:            return _infer_schema(tf_object.numpy())
mlflow/data/tensorflow_dataset.py:259:        return _infer_schema(numpy_data)
mlflow/data/tensorflow_dataset.py:271:        return _infer_schema(
mlflow/data/spark_dataset.py:182:            return _infer_schema(self._df)
mlflow/data/schema.py:8:class TensorDatasetSchema:
mlflow/data/schema.py:70:            isinstance(other, TensorDatasetSchema)
mlflow/data/huggingface_dataset.py:140:            return _infer_schema(df)
mlflow/data/evaluation_dataset.py:553:        if isinstance(self._features_data, np.ndarray):
mlflow/data/evaluation_dataset.py:554:            is_features_data_equal = np.array_equal(self._features_data, other._features_data)
mlflow/data/evaluation_dataset.py:556:            is_features_data_equal = self._features_data.equals(other._features_data)
mlflow/data/evaluation_dataset.py:559:            is_features_data_equal
```

## 原始行 30 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/types/schema.py | sed -n '880,1120p'"
```

退出码：`0`

输出：
```
   880	        self,
   881	        type: np.dtype,
   882	        shape: tuple[int, ...] | list[int],
   883	        name: str | None = None,
   884	    ):
   885	        self._name = name
   886	        self._tensorInfo = TensorInfo(type, shape)
   887	
   888	    @property
   889	    def type(self) -> np.dtype:
   890	        """
   891	        A unique character code for each of the 21 different numpy built-in types.
   892	        See https://numpy.org/devdocs/reference/generated/numpy.dtype.html#numpy.dtype for details.
   893	        """
   894	        return self._tensorInfo.dtype
   895	
   896	    @property
   897	    def name(self) -> str | None:
   898	        """The tensor name or None if the tensor is unnamed."""
   899	        return self._name
   900	
   901	    @property
   902	    def shape(self) -> tuple[int, ...]:
   903	        """The tensor shape"""
   904	        return self._tensorInfo.shape
   905	
   906	    @property
   907	    def required(self) -> bool:
   908	        """Whether this tensor is required."""
   909	        return True
   910	
   911	    def to_dict(self) -> dict[str, Any]:
   912	        if self.name is None:
   913	            return {"type": "tensor", "tensor-spec": self._tensorInfo.to_dict()}
   914	        else:
   915	            return {"name": self.name, "type": "tensor", "tensor-spec": self._tensorInfo.to_dict()}
   916	
   917	    @classmethod
   918	    def from_json_dict(cls, **kwargs):
   919	        """
   920	        Deserialize from a json loaded dictionary.
   921	        The dictionary is expected to contain `type` and `tensor-spec` keys.
   922	        """
   923	        if not {"tensor-spec", "type"} <= set(kwargs.keys()):
   924	            raise MlflowException(
   925	                "Missing keys in TensorSpec JSON. Expected to find keys `tensor-spec` and `type`"
   926	            )
   927	        if kwargs["type"] != "tensor":
   928	            raise MlflowException("Type mismatch, TensorSpec expects `tensor` as the type")
   929	        tensor_info = TensorInfo.from_json_dict(**kwargs["tensor-spec"])
   930	        return cls(
   931	            tensor_info.dtype, tensor_info.shape, kwargs["name"] if "name" in kwargs else None
   932	        )
   933	
   934	    def __eq__(self, other) -> bool:
   935	        if isinstance(other, TensorSpec):
   936	            names_eq = (self.name is None and other.name is None) or self.name == other.name
   937	            return names_eq and self.type == other.type and self.shape == other.shape
   938	        return False
   939	
   940	    def __repr__(self) -> str:
   941	        if self.name is None:
   942	            return repr(self._tensorInfo)
   943	        else:
   944	            return f"{self.name!r}: {self._tensorInfo!r}"
   945	
   946	
   947	class Schema:
   948	    """
   949	    Specification of a dataset.
   950	
   951	    Schema is represented as a list of :py:class:`ColSpec` or :py:class:`TensorSpec`. A combination
   952	    of `ColSpec` and `TensorSpec` is not allowed.
   953	
   954	    The dataset represented by a schema can be named, with unique non empty names for every input.
   955	    In the case of :py:class:`ColSpec`, the dataset columns can be unnamed with implicit integer
   956	    index defined by their list indices.
   957	    Combination of named and unnamed data inputs are not allowed.
   958	    """
   959	
   960	    def __init__(self, inputs: list[ColSpec | TensorSpec]):
   961	        if not isinstance(inputs, list):
   962	            raise MlflowException.invalid_parameter_value(
   963	                f"Inputs of Schema must be a list, got type {type(inputs).__name__}"
   964	            )
   965	        if not inputs:
   966	            raise MlflowException.invalid_parameter_value(
   967	                "Creating Schema with empty inputs is not allowed."
   968	            )
   969	
   970	        if not (all(x.name is None for x in inputs) or all(x.name is not None for x in inputs)):
   971	            raise MlflowException(
   972	                "Creating Schema with a combination of named and unnamed inputs "
   973	                f"is not allowed. Got input names {[x.name for x in inputs]}"
   974	            )
   975	        if not (
   976	            all(isinstance(x, TensorSpec) for x in inputs)
   977	            or all(isinstance(x, ColSpec) for x in inputs)
   978	        ):
   979	            raise MlflowException(
   980	                "Creating Schema with a combination of {0} and {1} is not supported. "
   981	                f"Please choose one of {ColSpec.__name__} or {TensorSpec.__name__}"
   982	            )
   983	        if (
   984	            all(isinstance(x, TensorSpec) for x in inputs)
   985	            and len(inputs) > 1
   986	            and any(x.name is None for x in inputs)
   987	        ):
   988	            raise MlflowException(
   989	                "Creating Schema with multiple unnamed TensorSpecs is not supported. "
   990	                "Please provide names for each TensorSpec."
   991	            )
   992	        if all(x.name is None for x in inputs) and any(x.required is False for x in inputs):
   993	            raise MlflowException(
   994	                "Creating Schema with unnamed optional inputs is not supported. "
   995	                "Please name all inputs or make all inputs required."
   996	            )
   997	        self._inputs = inputs
   998	
   999	    def __len__(self):
  1000	        return len(self._inputs)
  1001	
  1002	    def __iter__(self):
  1003	        return iter(self._inputs)
  1004	
  1005	    @property
  1006	    def inputs(self) -> list[ColSpec | TensorSpec]:
  1007	        """Representation of a dataset that defines this schema."""
  1008	        return self._inputs
  1009	
  1010	
  1011	
  1012	
  1013	
  1014	    def input_names(self) -> list[str | int]:
  1015	        """Get list of data names or range of indices if the schema has no names."""
  1016	        return [x.name or i for i, x in enumerate(self.inputs)]
  1017	
  1018	    def required_input_names(self) -> list[str | int]:
  1019	        """Get list of required data names or range of indices if schema has no names."""
  1020	        return [x.name or i for i, x in enumerate(self.inputs) if x.required]
  1021	
  1022	    def optional_input_names(self) -> list[str | int]:
  1023	        """Get list of optional data names or range of indices if schema has no names."""
  1024	        return [x.name or i for i, x in enumerate(self.inputs) if not x.required]
  1025	
  1026	    def has_input_names(self) -> bool:
  1027	        """Return true iff this schema declares names, false otherwise."""
  1028	        return self.inputs and self.inputs[0].name is not None
  1029	
  1030	    def input_types(self) -> list[DataType | np.dtype | Array | Object]:
  1031	        """Get types for each column in the schema."""
  1032	        return [x.type for x in self.inputs]
  1033	
  1034	    def input_types_dict(self) -> dict[str, DataType | np.dtype | Array | Object]:
  1035	        """Maps column names to types, iff this schema declares names."""
  1036	        if not self.has_input_names():
  1037	            raise MlflowException("Cannot get input types as a dict for schema without names.")
  1038	        return {x.name: x.type for x in self.inputs}
  1039	
  1040	    def input_dict(self) -> dict[str, ColSpec | TensorSpec]:
  1041	        """Maps column names to inputs, iff this schema declares names."""
  1042	        if not self.has_input_names():
  1043	            raise MlflowException("Cannot get input dict for schema without names.")
  1044	        return {x.name: x for x in self.inputs}
  1045	
  1046	    def numpy_types(self) -> list[np.dtype]:
  1047	        """Convenience shortcut to get the datatypes as numpy types."""
  1048	        if self.is_tensor_spec():
  1049	            return [x.type for x in self.inputs]
  1050	        if all(isinstance(x.type, DataType) for x in self.inputs):
  1051	            return [x.type.to_numpy() for x in self.inputs]
  1052	        raise MlflowException(
  1053	            "Failed to get numpy types as some of the inputs types are not DataType."
  1054	        )
  1055	
  1056	    def pandas_types(self) -> list[np.dtype]:
  1057	        """Convenience shortcut to get the datatypes as pandas types. Unsupported by TensorSpec."""
  1058	        if self.is_tensor_spec():
  1059	            raise MlflowException("TensorSpec only supports numpy types, use numpy_types() instead")
  1060	        if all(isinstance(x.type, DataType) for x in self.inputs):
  1061	            return [x.type.to_pandas() for x in self.inputs]
  1062	        raise MlflowException(
  1063	            "Failed to get pandas types as some of the inputs types are not DataType."
  1064	        )
  1065	
  1066	    def as_spark_schema(self):
  1067	        """Convert to Spark schema. If this schema is a single unnamed column, it is converted
  1068	        directly the corresponding spark data type, otherwise it's returned as a struct (missing
  1069	        column names are filled with an integer sequence).
  1070	        Unsupported by TensorSpec.
  1071	        """
  1072	        if self.is_tensor_spec():
  1073	            raise MlflowException("TensorSpec cannot be converted to spark dataframe")
  1074	        if len(self.inputs) == 1 and self.inputs[0].name is None:
  1075	            return self.inputs[0].type.to_spark()
  1076	        from pyspark.sql.types import StructField, StructType
  1077	
  1078	        return StructType(
  1079	            [
  1080	                StructField(
  1081	                    name=col.name or str(i), dataType=col.type.to_spark(), nullable=not col.required
  1082	                )
  1083	                for i, col in enumerate(self.inputs)
  1084	            ]
  1085	        )
  1086	
  1087	    def to_json(self) -> str:
  1088	        """Serialize into json string."""
  1089	        return json.dumps([x.to_dict() for x in self.inputs])
  1090	
  1091	    def to_dict(self) -> list[dict[str, Any]]:
  1092	        """Serialize into a jsonable dictionary."""
  1093	        return [x.to_dict() for x in self.inputs]
  1094	
  1095	    @classmethod
  1096	    def from_json(cls, json_str: str):
  1097	        """Deserialize from a json string."""
  1098	
  1099	        def read_input(x: dict[str, Any]):
  1100	            return (
  1101	                TensorSpec.from_json_dict(**x)
  1102	                if x["type"] == "tensor"
  1103	                else ColSpec.from_json_dict(**x)
  1104	            )
  1105	
  1106	        return cls([read_input(x) for x in json.loads(json_str)])
  1107	
  1108	    def __eq__(self, other) -> bool:
  1109	        if isinstance(other, Schema):
  1110	            return self.inputs == other.inputs
  1111	        else:
  1112	            return False
  1113	
  1114	    def __repr__(self) -> str:
  1115	        return repr(self.inputs)
  1116	
  1117	
  1118	class ParamSpec:
  1119	    """
  1120	    Specification used to represent parameters for the model.
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "nl -ba tests/types/test_schema.py | sed -n '1,820p'"
```

退出码：`0`

输出：
```
     1	import datetime
     2	import json
     3	import math
     4	import re
     5	from dataclasses import dataclass, field
     6	from typing import Optional
     7	
     8	import numpy as np
     9	import pandas as pd
    10	import pyspark
    11	import pyspark.sql.types as T
    12	import pytest
    13	from scipy.sparse import csc_matrix, csr_matrix
    14	
    15	from mlflow.exceptions import MlflowException
    16	from mlflow.models import rag_signatures
    17	from mlflow.models.utils import _enforce_tensor_spec
    18	from mlflow.pyfunc import _parse_spark_datatype
    19	from mlflow.types import DataType
    20	from mlflow.types.schema import (
    21	    AnyType,
    22	    Array,
    23	    ColSpec,
    24	    Object,
    25	    ParamSchema,
    26	    ParamSpec,
    27	    Property,
    28	    Schema,
    29	    TensorSpec,
    30	    convert_dataclass_to_schema,
    31	)
    32	from mlflow.types.utils import (
    33	    MULTIPLE_TYPES_ERROR_MSG,
    34	    _get_tensor_shape,
    35	    _infer_colspec_type,
    36	    _infer_param_schema,
    37	    _infer_schema,
    38	    _validate_input_dictionary_contains_only_strings_and_lists_of_strings,
    39	)
    40	
    41	
    42	@pytest.fixture(scope="module")
    43	def spark():
    44	    with pyspark.sql.SparkSession.builder.getOrCreate() as s:
    45	        yield s
    46	
    47	
    48	def test_col_spec():
    49	    a1 = ColSpec("string", "a")
    50	    a2 = ColSpec(DataType.string, "a")
    51	    a3 = ColSpec(DataType.integer, "a")
    52	    assert a1 != a3
    53	    b1 = ColSpec(DataType.string, "b")
    54	    assert b1 != a1
    55	    assert a1 == a2
    56	    with pytest.raises(MlflowException, match="Unsupported type 'unsupported'"):
    57	        ColSpec("unsupported")
    58	    a4 = ColSpec(**a1.to_dict())
    59	    assert a4 == a1
    60	    assert ColSpec(**json.loads(json.dumps(a1.to_dict()))) == a1
    61	    a5 = ColSpec("string")
    62	    a6 = ColSpec("string", None)
    63	    assert a5 == a6
    64	    assert ColSpec(**json.loads(json.dumps(a5.to_dict()))) == a5
    65	
    66	
    67	def test_tensor_spec():
    68	    a1 = TensorSpec(np.dtype("float64"), (-1, 3, 3), "a")
    69	    a2 = TensorSpec(np.dtype("float"), (-1, 3, 3), "a")  # float defaults to float64
    70	    a3 = TensorSpec(np.dtype("float"), [-1, 3, 3], "a")
    71	    a4 = TensorSpec(np.dtype("int"), (-1, 3, 3), "a")
    72	    assert a1 == a2
    73	    assert a1 == a3
    74	    assert a1 != a4
    75	    b1 = TensorSpec(np.dtype("float64"), (-1, 3, 3), "b")
    76	    assert b1 != a1
    77	    with pytest.raises(TypeError, match="Expected `dtype` to be instance"):
    78	        TensorSpec("Unsupported", (-1, 3, 3), "a")
    79	    with pytest.raises(TypeError, match="Expected `shape` to be instance"):
    80	        TensorSpec(np.dtype("float64"), np.array([-1, 2, 3]), "b")
    81	    with pytest.raises(
    82	        MlflowException,
    83	        match="MLflow does not support size information in flexible numpy data types",
    84	    ):
    85	        TensorSpec(np.dtype("<U10"), (-1,), "b")
    86	
    87	    a5 = TensorSpec.from_json_dict(**a1.to_dict())
    88	    assert a5 == a1
    89	    assert TensorSpec.from_json_dict(**json.loads(json.dumps(a1.to_dict()))) == a1
    90	    a6 = TensorSpec(np.dtype("float64"), (-1, 3, 3))
    91	    a7 = TensorSpec(np.dtype("float64"), (-1, 3, 3), None)
    92	    assert a6 == a7
    93	    assert TensorSpec.from_json_dict(**json.loads(json.dumps(a6.to_dict()))) == a6
    94	
    95	
    96	@pytest.fixture
    97	def pandas_df_with_all_types():
    98	    df = pd.DataFrame(
    99	        {
   100	            "boolean": [True, False, True],
   101	            "integer": np.array([1, 2, 3], np.int32),
   102	            "long": np.array([1, 2, 3], np.int64),
   103	            "float": np.array([math.pi, 2 * math.pi, 3 * math.pi], np.float32),
   104	            "double": [math.pi, 2 * math.pi, 3 * math.pi],
   105	            "binary": [bytearray([1, 2, 3]), bytearray([4, 5, 6]), bytearray([7, 8, 9])],
   106	            "string": ["a", "b", "c"],
   107	            "datetime": [
   108	                np.datetime64("2021-01-01"),
   109	                np.datetime64("2021-02-02"),
   110	                np.datetime64("2021-03-03"),
   111	            ],
   112	            "boolean_ext": [True, False, True],
   113	            "integer_ext": [1, 2, 3],
   114	            "string_ext": ["a", "b", "c"],
   115	        }
   116	    )
   117	    df["boolean_ext"] = df["boolean_ext"].astype("boolean")
   118	    df["integer_ext"] = df["integer_ext"].astype("Int64")
   119	    df["string_ext"] = df["string_ext"].astype("string")
   120	    return df
   121	
   122	
   123	@pytest.fixture
   124	def dict_of_ndarrays():
   125	    return {
   126	        "1D": np.arange(0, 12, 0.5),
   127	        "2D": np.arange(0, 12, 0.5).reshape(3, 8),
   128	        "3D": np.arange(0, 12, 0.5).reshape(2, 3, 4),
   129	        "4D": np.arange(0, 12, 0.5).reshape(3, 2, 2, 2),
   130	    }
   131	
   132	
   133	def test_schema_creation():
   134	    # can create schema with named col specs
   135	    Schema([ColSpec("double", "a"), ColSpec("integer", "b")])
   136	
   137	    # can create schema with unnamed col specs
   138	    Schema([ColSpec("double"), ColSpec("integer")])
   139	
   140	    # can create schema with multiple named tensor specs
   141	    Schema([TensorSpec(np.dtype("float64"), (-1,), "a"), TensorSpec(np.dtype("uint8"), (-1,), "b")])
   142	
   143	    # can create schema with single unnamed tensor spec
   144	    Schema([TensorSpec(np.dtype("float64"), (-1,))])
   145	
   146	    # combination of tensor and col spec is not allowed
   147	    with pytest.raises(MlflowException, match="Please choose one of"):
   148	        Schema([TensorSpec(np.dtype("float64"), (-1,)), ColSpec("double")])
   149	
   150	    # combination of named and unnamed inputs is not allowed
   151	    with pytest.raises(
   152	        MlflowException, match="Creating Schema with a combination of named and unnamed inputs"
   153	    ):
   154	        Schema(
   155	            [TensorSpec(np.dtype("float64"), (-1,), "blah"), TensorSpec(np.dtype("float64"), (-1,))]
   156	        )
   157	
   158	    with pytest.raises(
   159	        MlflowException, match="Creating Schema with a combination of named and unnamed inputs"
   160	    ):
   161	        Schema([ColSpec("double", "blah"), ColSpec("double")])
   162	
   163	    # multiple unnamed tensor specs is not allowed
   164	    with pytest.raises(
   165	        MlflowException, match="Creating Schema with multiple unnamed TensorSpecs is not supported"
   166	    ):
   167	        Schema([TensorSpec(np.dtype("double"), (-1,)), TensorSpec(np.dtype("double"), (-1,))])
   168	
   169	
   170	def test_schema_creation_errors():
   171	    with pytest.raises(MlflowException, match=r"Creating Schema with empty inputs is not allowed."):
   172	        Schema([])
   173	
   174	    with pytest.raises(MlflowException, match=r"Inputs of Schema must be a list, got type dict"):
   175	        Schema({"col1": ColSpec(DataType.string)})
   176	
   177	
   178	def test_get_schema_type(dict_of_ndarrays):
   179	    schema = _infer_schema(dict_of_ndarrays)
   180	    assert ["float64"] * 4 == schema.numpy_types()
   181	    with pytest.raises(MlflowException, match="TensorSpec only supports numpy types"):
   182	        schema.pandas_types()
   183	    with pytest.raises(MlflowException, match="TensorSpec cannot be converted to spark dataframe"):
   184	        schema.as_spark_schema()
   185	
   186	
   187	def test_schema_inference_on_dataframe(pandas_df_with_all_types):
   188	    basic_types = pandas_df_with_all_types.drop(
   189	        columns=["boolean_ext", "integer_ext", "string_ext"]
   190	    )
   191	    schema = _infer_schema(basic_types)
   192	    assert schema == Schema([ColSpec(x, x) for x in basic_types.columns])
   193	
   194	    ext_types = pandas_df_with_all_types[["boolean_ext", "integer_ext", "string_ext"]].copy()
   195	    expected_schema = Schema(
   196	        [
   197	            ColSpec(DataType.boolean, "boolean_ext"),
   198	            ColSpec(DataType.long, "integer_ext"),
   199	            ColSpec(DataType.string, "string_ext"),
   200	        ]
   201	    )
   202	    schema = _infer_schema(ext_types)
   203	    assert schema == expected_schema
   204	
   205	
   206	def test_schema_inference_on_pandas_series():
   207	    # test objects
   208	    schema = _infer_schema(pd.Series(np.array(["a"], dtype=object)))
   209	    assert schema == Schema([ColSpec(DataType.string)])
   210	    schema = _infer_schema(pd.Series(np.array([bytes([1])], dtype=object)))
   211	    assert schema == Schema([ColSpec(DataType.binary)])
   212	    schema = _infer_schema(pd.Series(np.array([bytearray([1]), None], dtype=object), name="input"))
   213	    assert schema == Schema([ColSpec(DataType.binary, name="input", required=False)])
   214	    schema = _infer_schema(pd.Series(np.array([1.1, None], dtype=object), name="input"))
   215	    assert schema == Schema([ColSpec(DataType.double, name="input", required=False)])
   216	
   217	    # test bytes
   218	    schema = _infer_schema(pd.Series(np.array([bytes([1])], dtype=np.bytes_)))
   219	    assert schema == Schema([ColSpec(DataType.binary)])
   220	
   221	    # test string
   222	    schema = _infer_schema(pd.Series(np.array(["a"], dtype=str)))
   223	    assert schema == Schema([ColSpec(DataType.string)])
   224	
   225	    # test boolean
   226	    schema = _infer_schema(pd.Series(np.array([True], dtype=bool)))
   227	    assert schema == Schema([ColSpec(DataType.boolean)])
   228	
   229	    # test ints
   230	    for t in [np.uint8, np.uint16, np.int8, np.int16, np.int32]:
   231	        schema = _infer_schema(pd.Series(np.array([1, 2, 3], dtype=t)))
   232	        assert schema == Schema([ColSpec("integer")])
   233	
   234	    # test longs
   235	    for t in [np.uint32, np.int64]:
   236	        schema = _infer_schema(pd.Series(np.array([1, 2, 3], dtype=t)))
   237	        assert schema == Schema([ColSpec("long")])
   238	
   239	    # unsigned long is unsupported
   240	    with pytest.raises(MlflowException, match="Unsupported numpy data type"):
   241	        _infer_schema(pd.Series(np.array([1, 2, 3], dtype=np.uint64)))
   242	
   243	    # test floats
   244	    for t in [np.float16, np.float32]:
   245	        schema = _infer_schema(pd.Series(np.array([1.1, 2.2, 3.3], dtype=t)))
   246	        assert schema == Schema([ColSpec("float")])
   247	
   248	    # test doubles
   249	    schema = _infer_schema(pd.Series(np.array([1.1, 2.2, 3.3], dtype=np.float64)))
   250	    assert schema == Schema([ColSpec("double")])
   251	
   252	    # test datetime
   253	    schema = _infer_schema(
   254	        pd.Series(
   255	            np.array(
   256	                ["2021-01-01 00:00:00", "2021-02-02 00:00:00", "2021-03-03 12:00:00"],
   257	                dtype="datetime64",
   258	            )
   259	        )
   260	    )
   261	    assert schema == Schema([ColSpec("datetime")])
   262	
   263	    # unsupported
   264	    if hasattr(np, "float128"):
   265	        with pytest.raises(MlflowException, match="Unsupported numpy data type"):
   266	            _infer_schema(pd.Series(np.array([1, 2, 3], dtype=np.float128)))
   267	
   268	    # test names
   269	    s = pd.Series([1, 2, 3])
   270	    if hasattr(s, "name"):
   271	        s.rename("test", inplace=True)
   272	        assert "test" in _infer_schema(s).input_names()
   273	        assert len(_infer_schema(s).input_names()) == 1
   274	
   275	
   276	def test_get_tensor_shape(dict_of_ndarrays):
   277	    assert all(-1 == _get_tensor_shape(tensor)[0] for tensor in dict_of_ndarrays.values())
   278	
   279	    data = dict_of_ndarrays["4D"]
   280	    # Specify variable dimension
   281	    for i in range(-4, 4):
   282	        assert _get_tensor_shape(data, i)[i] == -1
   283	
   284	    # Specify None
   285	    assert all([_get_tensor_shape(data, None) != -1])
   286	
   287	    # Out of bounds
   288	    with pytest.raises(
   289	        MlflowException, match="The specified variable_dimension 10 is out of bounds"
   290	    ):
   291	        _get_tensor_shape(data, 10)
   292	    with pytest.raises(
   293	        MlflowException, match="The specified variable_dimension -10 is out of bounds"
   294	    ):
   295	        _get_tensor_shape(data, -10)
   296	
   297	
   298	@pytest.fixture
   299	def dict_of_sparse_matrix():
   300	    return {
   301	        "csc": csc_matrix(np.arange(0, 12, 0.5).reshape(3, 8)),
   302	        "csr": csr_matrix(np.arange(0, 12, 0.5).reshape(3, 8)),
   303	    }
   304	
   305	
   306	def test_get_sparse_matrix_data_type_and_shape(dict_of_sparse_matrix):
   307	    for sparse_matrix in dict_of_sparse_matrix.values():
   308	        schema = _infer_schema(sparse_matrix)
   309	        assert schema.numpy_types() == ["float64"]
   310	        assert _get_tensor_shape(sparse_matrix) == (-1, 8)
   311	
   312	
   313	def test_schema_inference_on_dictionary(dict_of_ndarrays):
   314	    # test dictionary
   315	    schema = _infer_schema(dict_of_ndarrays)
   316	    assert schema == Schema(
   317	        [
   318	            TensorSpec(tensor.dtype, _get_tensor_shape(tensor), name)
   319	            for name, tensor in dict_of_ndarrays.items()
   320	        ]
   321	    )
   322	
   323	
   324	@pytest.mark.parametrize(
   325	    ("data", "schema"),
   326	    [
   327	        (
   328	            {"a": "b", "c": "d"},
   329	            Schema([ColSpec(DataType.string, "a"), ColSpec(DataType.string, "c")]),
   330	        ),
   331	        (
   332	            {"a": ["a", "b"], "b": ["c", "d"]},
   333	            Schema([ColSpec(Array(DataType.string), "a"), ColSpec(Array(DataType.string), "b")]),
   334	        ),
   335	        (
   336	            {"a": "a", "b": ["a", "b"]},
   337	            Schema([ColSpec(DataType.string, "a"), ColSpec(Array(DataType.string), "b")]),
   338	        ),
   339	        (
   340	            [{"a": 1}, {"a": 1, "b": ["a", "b"]}],
   341	            Schema(
   342	                [ColSpec(DataType.long, "a"), ColSpec(Array(DataType.string), "b", required=False)]
   343	            ),
   344	        ),
   345	    ],
   346	)
   347	def test_schema_inference_on_dictionary_of_strings(data, schema):
   348	    assert _infer_schema(data) == schema
   349	
   350	
   351	def test_schema_inference_on_list_with_errors():
   352	    data = [{"a": 1, "b": "c"}, {"a": 1, "b": ["a", "b"]}]
   353	    with pytest.raises(MlflowException, match=re.escape(MULTIPLE_TYPES_ERROR_MSG)):
   354	        _infer_schema(data)
   355	
   356	
   357	def test_schema_inference_validating_dictionary_keys():
   358	    for data in [{1.7: "a", "b": "c"}, {12.4: "c", "d": "e"}]:
   359	        with pytest.raises(MlflowException, match="The dictionary keys are not all strings."):
   360	            _infer_schema(data)
   361	
   362	
   363	def test_schema_inference_on_lists_with_errors():
   364	    with pytest.raises(MlflowException, match=re.escape(MULTIPLE_TYPES_ERROR_MSG)):
   365	        _infer_schema(["a", 1])
   366	
   367	    with pytest.raises(MlflowException, match=re.escape(MULTIPLE_TYPES_ERROR_MSG)):
   368	        _infer_schema(["a", ["b", "c"]])
   369	
   370	
   371	def test_schema_inference_on_list_of_dicts():
   372	    schema = _infer_schema([{"a": "a", "b": "b"}, {"a": "a", "b": "b"}])
   373	    assert schema == Schema([ColSpec(DataType.string, "a"), ColSpec(DataType.string, "b")])
   374	
   375	    schema = _infer_schema([{"a": 1}, {"b": "a"}])
   376	    assert schema == Schema(
   377	        [
   378	            ColSpec(DataType.long, "a", required=False),
   379	            ColSpec(DataType.string, "b", required=False),
   380	        ]
   381	    )
   382	
   383	
   384	def test_dict_input_valid_checks_on_keys():
   385	    match = "The dictionary keys are not all strings or "
   386	    # User-defined keys
   387	
   388	    class Hashable:
   389	        def __init__(self, x: str, y: str):
   390	            self.x = x
   391	            self.y = y
   392	
   393	        def __hash__(self):
   394	            return hash((self.x, self.y))
   395	
   396	        def __eq__(self, other):
   397	            return isinstance(other, Hashable) and self.x == other.x and self.y == other.y
   398	
   399	    hash_obj_1 = Hashable("some", "custom")
   400	    hash_obj_2 = Hashable("some", "other")
   401	    custom_hashable_dict = {hash_obj_1: "value", hash_obj_2: "other_value"}
   402	
   403	    with pytest.raises(MlflowException, match=match):
   404	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(custom_hashable_dict)
   405	
   406	    # keys are floats
   407	    float_keys_dict = {1.1: "a", 2.2: "b"}
   408	
   409	    with pytest.raises(MlflowException, match=match):
   410	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(float_keys_dict)
   411	
   412	    # keys are bool
   413	    bool_keys_dict = {True: "a", False: "b"}
   414	
   415	    with pytest.raises(MlflowException, match=match):
   416	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(bool_keys_dict)
   417	    # keys are tuples
   418	    tuple_keys_dict = {("a", "b"): "a", ("a", "c"): "b"}
   419	
   420	    with pytest.raises(MlflowException, match=match):
   421	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(tuple_keys_dict)
   422	
   423	    # keys are frozenset
   424	    frozen_set_dict = {frozenset({"a", "b"}): "a", frozenset({"b", "c"}): "b"}
   425	
   426	    with pytest.raises(MlflowException, match=match):
   427	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(frozen_set_dict)
   428	
   429	
   430	def test_dict_input_valid_checks_on_values():
   431	    match = "Invalid values in dictionary. If passing a dictionary containing strings"
   432	
   433	    list_of_ints = {"a": [1, 2, 3], "b": [1, 2, 3]}
   434	    with pytest.raises(MlflowException, match=match):
   435	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_ints)
   436	
   437	    list_of_floats = {"a": [1.1, 1.2], "b": [1.1, 2.2]}
   438	    with pytest.raises(MlflowException, match=match):
   439	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_floats)
   440	
   441	    list_of_dics = {"a": [{"a": "b"}, {"b": "c"}], "b": [{"a": "c"}, {"b": "d"}]}
   442	    with pytest.raises(MlflowException, match=match):
   443	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_dics)
   444	
   445	    list_of_lists = {"a": [["b", "c"], ["d", "e"]], "b": [["e", "f"], ["g", "h"]]}
   446	    with pytest.raises(MlflowException, match=match):
   447	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_lists)
   448	
   449	    list_of_set = {"a": [{"b", "c"}, {"d", "e"}], "b": [{"a", "c"}, {"d", "f"}]}
   450	    with pytest.raises(MlflowException, match=match):
   451	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_set)
   452	
   453	    list_of_frozen_set = {
   454	        "a": [frozenset({"b", "c"}), frozenset({"d", "e"})],
   455	        "b": [frozenset({"a", "c"}), frozenset({"d", "f"})],
   456	    }
   457	    with pytest.raises(MlflowException, match=match):
   458	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_frozen_set)
   459	
   460	    list_of_bool = {"a": [True, True, False], "b": [False, False, True]}
   461	    with pytest.raises(MlflowException, match=match):
   462	        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_bool)
   463	
   464	
   465	def test_schema_inference_on_basic_numpy(pandas_df_with_all_types):
   466	    for col in pandas_df_with_all_types:
   467	        data = pandas_df_with_all_types[col].to_numpy()
   468	        schema = _infer_schema(data)
   469	        assert schema == Schema([TensorSpec(type=data.dtype, shape=(-1,))])
   470	
   471	
   472	# Todo: arjundc : Remove _enforce_tensor_spec and move to its own test file.
   473	def test_all_numpy_dtypes():
   474	    def test_dtype(nparray, dtype):
   475	        schema = _infer_schema(nparray)
   476	        assert schema == Schema([TensorSpec(np.dtype(dtype), (-1,))])
   477	        spec = schema.inputs[0]
   478	        recreated_spec = TensorSpec.from_json_dict(**spec.to_dict())
   479	        assert spec == recreated_spec
   480	        enforced_array = _enforce_tensor_spec(nparray, spec)
   481	        assert isinstance(enforced_array, np.ndarray)
   482	
   483	    bool_ = ["bool", "bool_"]
   484	    object_ = ["object"]
   485	    signed_int = [
   486	        "byte",
   487	        "int8",
   488	        "short",
   489	        "int16",
   490	        "intc",
   491	        "int32",
   492	        "int_",
   493	        "int",
   494	        "intp",
   495	        "int64",
   496	        "longlong",
   497	    ]
   498	    unsigned_int = [
   499	        "ubyte",
   500	        "uint8",
   501	        "ushort",
   502	        "uint16",
   503	        "uintc",
   504	        "uint32",
   505	        "uint",
   506	        "uintp",
   507	        "uint64",
   508	        "ulonglong",
   509	    ]
   510	    floating = ["half", "float16", "single", "float32", "double", "float64"]
   511	    complex_ = [
   512	        "csingle",
   513	        "complex64",
   514	        "cdouble",
   515	        "complex128",
   516	    ]
   517	    bytes_ = ["bytes_"]
   518	    str_ = ["str_"]
   519	    platform_dependent = [
   520	        # Complex
   521	        "clongdouble",
   522	        "clongfloat",
   523	        "longcomplex",
   524	        "complex256",
   525	        # Float
   526	        "longdouble",
   527	        "longfloat",
   528	        "float128",
   529	    ]
   530	
   531	    # test boolean
   532	    for dtype in bool_:
   533	        test_dtype(np.array([True, False, True], dtype=dtype), dtype)
   534	        test_dtype(np.array([123, 0, -123], dtype=dtype), dtype)
   535	
   536	    # test object
   537	    for dtype in object_:
   538	        test_dtype(np.array([True, False, True], dtype=dtype), dtype)
   539	        test_dtype(np.array([123, 0, -123.544], dtype=dtype), dtype)
   540	        test_dtype(np.array(["test", "this", "type"], dtype=dtype), dtype)
   541	        test_dtype(np.array(["test", 123, "type"], dtype=dtype), dtype)
   542	        test_dtype(np.array(["test", 123, 234 + 543j], dtype=dtype), dtype)
   543	
   544	    # test signedInt_
   545	    for dtype in signed_int:
   546	        test_dtype(np.array([1, 2, 3, -5], dtype=dtype), dtype)
   547	
   548	    # test unsignedInt_
   549	    for dtype in unsigned_int:
   550	        test_dtype(np.array([1, 2, 3, 5], dtype=dtype), dtype)
   551	
   552	    # test floating
   553	    for dtype in floating:
   554	        test_dtype(np.array([1.1, -2.2, 3.3, 5.12], dtype=dtype), dtype)
   555	
   556	    # test complex
   557	    for dtype in complex_:
   558	        test_dtype(np.array([1 + 2j, -2.2 - 3.6j], dtype=dtype), dtype)
   559	
   560	    # test bytes_
   561	    for dtype in bytes_:
   562	        test_dtype(np.array([bytes([1, 255, 12, 34])], dtype=dtype), dtype)
   563	    # Explicitly giving size information for flexible dtype bytes
   564	    test_dtype(np.array([bytes([1, 255, 12, 34])], dtype="S10"), "S")
   565	    test_dtype(np.array([bytes([1, 255, 12, 34])], dtype="S10"), "bytes")
   566	
   567	    # str_
   568	    for dtype in str_:
   569	        test_dtype(np.array(["m", "l", "f", "l", "o", "w"], dtype=dtype), dtype)
   570	        test_dtype(np.array(["mlflow"], dtype=dtype), dtype)
   571	        test_dtype(np.array(["mlflow is the best"], dtype=dtype), dtype)
   572	    # Explicitly giving size information for flexible dtype str_
   573	    test_dtype(np.array(["a", "bc", "def"], dtype="U16"), "str")
   574	    test_dtype(np.array(["a", "bc", "def"], dtype="U16"), "U")
   575	
   576	    # test datetime
   577	    test_dtype(
   578	        np.array(
   579	            ["2021-01-01 00:00:00", "2021-02-02 00:00:00", "2021-03-03 12:00:00"],
   580	            dtype="datetime64",
   581	        ),
   582	        "datetime64[s]",
   583	    )
   584	
   585	    # platform_dependent
   586	    for dtype in platform_dependent:
   587	        if hasattr(np, dtype):
   588	            test_dtype(np.array([1.1, -2.2, 3.3, 5.12], dtype=dtype), dtype)
   589	
   590	
   591	def test_spark_schema_inference(pandas_df_with_all_types):
   592	    import pyspark
   593	    from pyspark.sql.types import StructField, StructType
   594	
   595	    pandas_df_with_all_types = pandas_df_with_all_types.drop(
   596	        columns=["boolean_ext", "integer_ext", "string_ext"]
   597	    )
   598	    schema = _infer_schema(pandas_df_with_all_types)
   599	    assert schema == Schema([ColSpec(x, x) for x in pandas_df_with_all_types.columns])
   600	    with pyspark.sql.SparkSession.builder.getOrCreate() as spark:
   601	        struct_fields = []
   602	        for t in schema.input_types():
   603	            if t == DataType.datetime:
   604	                struct_fields.append(
   605	                    StructField("datetime", _parse_spark_datatype("timestamp"), True)
   606	                )
   607	            else:
   608	                struct_fields.append(StructField(t.name, _parse_spark_datatype(t.name), True))
   609	        spark_schema = StructType(struct_fields)
   610	        sparkdf = spark.createDataFrame(pandas_df_with_all_types, schema=spark_schema)
   611	        schema = _infer_schema(sparkdf)
   612	        assert schema == Schema([ColSpec(x, x) for x in pandas_df_with_all_types.columns])
   613	
   614	
   615	def test_spark_schema_inference_complex(spark):
   616	    df = spark.createDataFrame(
   617	        [(["arr"],)],
   618	        schema=T.StructType([T.StructField("arr", T.ArrayType(T.StringType()))]),
   619	    )
   620	    schema = _infer_schema(df)
   621	    assert schema == Schema([ColSpec(Array(DataType.string), "arr")])
   622	
   623	    df = spark.createDataFrame(
   624	        [({"str": "s", "str_nullable": None},)],
   625	        schema=T.StructType(
   626	            [
   627	                T.StructField(
   628	                    "obj",
   629	                    T.StructType(
   630	                        [
   631	                            T.StructField("str", T.StringType(), nullable=False),
   632	                            T.StructField("str_nullable", T.StringType(), nullable=True),
   633	                        ]
   634	                    ),
   635	                )
   636	            ]
   637	        ),
   638	    )
   639	    schema = _infer_schema(df)
   640	    assert schema == Schema(
   641	        [
   642	            ColSpec(
   643	                Object(
   644	                    [
   645	                        Property("str", DataType.string, required=True),
   646	                        Property("str_nullable", DataType.string, required=False),
   647	                    ]
   648	                ),
   649	                "obj",
   650	            )
   651	        ]
   652	    )
   653	
   654	    df = spark.createDataFrame(
   655	        [([{"str": "s"}],)],
   656	        schema=T.StructType(
   657	            [
   658	                T.StructField(
   659	                    "obj_arr",
   660	                    T.ArrayType(
   661	                        T.StructType([T.StructField("str", T.StringType(), nullable=False)])
   662	                    ),
   663	                )
   664	            ]
   665	        ),
   666	    )
   667	
   668	    schema = _infer_schema(df)
   669	    assert schema == Schema(
   670	        [
   671	            ColSpec(
   672	                Array(Object([Property("str", DataType.string, required=True)])),
   673	                "obj_arr",
   674	            )
   675	        ]
   676	    )
   677	
   678	
   679	def test_spark_type_mapping(pandas_df_with_all_types):
   680	    import pyspark
   681	    from pyspark.sql.types import (
   682	        BinaryType,
   683	        BooleanType,
   684	        DoubleType,
   685	        FloatType,
   686	        IntegerType,
   687	        LongType,
   688	        StringType,
   689	        StructField,
   690	        StructType,
   691	        TimestampType,
   692	    )
   693	
   694	    assert isinstance(DataType.boolean.to_spark(), BooleanType)
   695	    assert isinstance(DataType.integer.to_spark(), IntegerType)
   696	    assert isinstance(DataType.long.to_spark(), LongType)
   697	    assert isinstance(DataType.float.to_spark(), FloatType)
   698	    assert isinstance(DataType.double.to_spark(), DoubleType)
   699	    assert isinstance(DataType.string.to_spark(), StringType)
   700	    assert isinstance(DataType.binary.to_spark(), BinaryType)
   701	    assert isinstance(DataType.datetime.to_spark(), TimestampType)
   702	    pandas_df_with_all_types = pandas_df_with_all_types.drop(
   703	        columns=["boolean_ext", "integer_ext", "string_ext"]
   704	    )
   705	    schema = _infer_schema(pandas_df_with_all_types)
   706	    expected_spark_schema = StructType(
   707	        [StructField(t.name, t.to_spark(), False) for t in schema.input_types()]
   708	    )
   709	    actual_spark_schema = schema.as_spark_schema()
   710	    assert expected_spark_schema.jsonValue() == actual_spark_schema.jsonValue()
   711	    with pyspark.sql.SparkSession(pyspark.SparkContext.getOrCreate()) as spark_session:
   712	        sparkdf = spark_session.createDataFrame(
   713	            pandas_df_with_all_types, schema=actual_spark_schema
   714	        )
   715	        schema2 = _infer_schema(sparkdf)
   716	        assert schema == schema2
   717	
   718	    # test unnamed columns
   719	    schema = Schema([ColSpec(col.type) for col in schema.inputs])
   720	    expected_spark_schema = StructType(
   721	        [StructField(str(i), t.to_spark(), False) for i, t in enumerate(schema.input_types())]
   722	    )
   723	    actual_spark_schema = schema.as_spark_schema()
   724	    assert expected_spark_schema.jsonValue() == actual_spark_schema.jsonValue()
   725	
   726	    # test single unnamed column is mapped to just a single spark type
   727	    schema = Schema([ColSpec(DataType.integer)])
   728	    spark_type = schema.as_spark_schema()
   729	    assert isinstance(spark_type, IntegerType)
   730	
   731	
   732	def test_enforce_tensor_spec_variable_signature():
   733	    standard_array = np.array([[[1, 2, 3], [1, 2, 3]], [[1, 2, 3], [1, 2, 3]]], dtype=np.int32)
   734	    ragged_array = np.array([[[1, 2, 3], [1, 2, 3]], [[1, 2, 3]]], dtype=object)
   735	    inferred_schema = _infer_schema(ragged_array)
   736	    inferred_spec = inferred_schema.inputs[0]
   737	    assert inferred_spec.shape == (-1,)
   738	    assert inferred_spec.type == np.dtype(object)
   739	
   740	    result_array = _enforce_tensor_spec(standard_array, inferred_spec)
   741	    np.testing.assert_array_equal(standard_array, result_array)
   742	    result_array = _enforce_tensor_spec(ragged_array, inferred_spec)
   743	    np.testing.assert_array_equal(ragged_array, result_array)
   744	
   745	    manual_spec = TensorSpec(np.dtype(np.int32), (-1, -1, 3))
   746	    result_array = _enforce_tensor_spec(standard_array, manual_spec)
   747	    np.testing.assert_array_equal(standard_array, result_array)
   748	    result_array = _enforce_tensor_spec(ragged_array, manual_spec)
   749	    np.testing.assert_array_equal(ragged_array, result_array)
   750	
   751	    standard_spec = _infer_schema(standard_array).inputs[0]
   752	    assert standard_spec.shape == (-1, 2, 3)
   753	
   754	    result_array = _enforce_tensor_spec(standard_array, standard_spec)
   755	    np.testing.assert_array_equal(standard_array, result_array)
   756	    with pytest.raises(
   757	        MlflowException,
   758	        match=re.escape(r"Shape of input (2,) does not match expected shape (-1, 2, 3)."),
   759	    ):
   760	        _enforce_tensor_spec(ragged_array, standard_spec)
   761	
   762	
   763	def test_datatype_type_check():
   764	    assert DataType.check_type(DataType.string, "string")
   765	
   766	    integer_type = DataType.integer
   767	    assert DataType.check_type(integer_type, 1)
   768	    assert DataType.check_type(integer_type, np.int32(1))
   769	    assert not DataType.check_type(integer_type, np.int64(1))
   770	    # Note that isinstance(True, int) returns True
   771	    assert not DataType.check_type(integer_type, True)
   772	
   773	    long_type = DataType.long
   774	    assert DataType.check_type(long_type, 1)
   775	    assert DataType.check_type(long_type, np.int64(1))
   776	    assert not DataType.check_type(long_type, np.int32(1))
   777	
   778	    bool_type = DataType.boolean
   779	    assert DataType.check_type(bool_type, True)
   780	    assert DataType.check_type(bool_type, np.bool_(True))
   781	    assert not DataType.check_type(bool_type, 1)
   782	
   783	    double_type = DataType.double
   784	    assert DataType.check_type(double_type, 1.0)
   785	    assert DataType.check_type(double_type, np.float64(1.0))
   786	    assert not DataType.check_type(double_type, np.float32(1.0))
   787	
   788	    float_type = DataType.float
   789	    assert DataType.check_type(float_type, 1.0)
   790	    assert DataType.check_type(float_type, np.float32(1.0))
   791	    assert not DataType.check_type(float_type, np.float64(1.0))
   792	
   793	    datetime_type = DataType.datetime
   794	    assert DataType.check_type(datetime_type, datetime.date(2023, 6, 26))
   795	    assert DataType.check_type(datetime_type, np.datetime64("2023-06-26 00:00:00"))
   796	    assert not DataType.check_type(datetime_type, "2023-06-26 00:00:00")
   797	
   798	
   799	def test_param_schema_find_duplicates():
   800	    with pytest.raises(
   801	        MlflowException, match=re.escape("Duplicated parameters found in schema: ['param1']")
   802	    ):
   803	        ParamSchema(
   804	            [
   805	                ParamSpec("param1", DataType.string, "default1", None),
   806	                ParamSpec("param1", DataType.string, "default1", None),
   807	                ParamSpec("param2", DataType.string, "default2", None),
   808	            ]
   809	        )
   810	
   811	    with pytest.raises(
   812	        MlflowException, match=re.escape("Duplicated parameters found in schema: ['param1']")
   813	    ):
   814	        ParamSchema(
   815	            [
   816	                ParamSpec("param1", DataType.string, "default1", None),
   817	                ParamSpec("param2", DataType.string, "default2", None),
   818	                ParamSpec("param1", DataType.string, "default1", None),
   819	            ]
   820	        )
```

## 原始行 35 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/data/evaluation_dataset.py | sed -n '150,650p'"
```

退出码：`0`

输出：
```
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	def convert_data_to_mlflow_dataset(data, targets=None, predictions=None, name=None):
   182	    """Convert input data to mlflow dataset."""
   183	    supported_dataframe_types = [pd.DataFrame]
   184	    if "pyspark" in sys.modules:
   185	        from mlflow.utils.spark_utils import get_spark_dataframe_type
   186	
   187	        spark_df_type = get_spark_dataframe_type()
   188	        supported_dataframe_types.append(spark_df_type)
   189	
   190	    if predictions is not None:
   191	        _validate_dataset_type_supports_predictions(
   192	            data=data, supported_predictions_dataset_types=supported_dataframe_types
   193	        )
   194	
   195	    if isinstance(data, list):
   196	        # If the list is flat, we assume each element is an independent sample.
   197	        if not isinstance(data[0], (list, np.ndarray)):
   198	            data = [[elm] for elm in data]
   199	
   200	        return mlflow.data.from_numpy(
   201	            np.array(data), targets=np.array(targets) if targets else None, name=name
   202	        )
   203	    elif isinstance(data, np.ndarray):
   204	        return mlflow.data.from_numpy(data, targets=targets, name=name)
   205	    elif isinstance(data, pd.DataFrame):
   206	        return mlflow.data.from_pandas(df=data, targets=targets, predictions=predictions, name=name)
   207	    elif "pyspark" in sys.modules and isinstance(data, spark_df_type):
   208	        return mlflow.data.from_spark(df=data, targets=targets, predictions=predictions, name=name)
   209	    else:
   210	        # Cannot convert to mlflow dataset, return original data.
   211	        _logger.info(
   212	            "Cannot convert input data to `evaluate()` to an mlflow dataset, input must be a list, "
   213	            f"a numpy array, a panda Dataframe or a spark Dataframe, but received {type(data)}."
   214	        )
   215	        return data
   216	
   217	
   218	def _validate_dataset_type_supports_predictions(data, supported_predictions_dataset_types):
   219	    """
   220	    Validate that the dataset type supports a user-specified "predictions" column.
   221	    """
   222	    if not any(isinstance(data, sdt) for sdt in supported_predictions_dataset_types):
   223	        raise MlflowException(
   224	            message=(
   225	                "If predictions is specified, data must be one of the following types, or an"
   226	                " MLflow Dataset that represents one of the following types:"
   227	                f" {supported_predictions_dataset_types}."
   228	            ),
   229	            error_code=INVALID_PARAMETER_VALUE,
   230	        )
   231	
   232	
   233	class EvaluationDataset:
   234	    """
   235	    An input dataset for model evaluation. This is intended for use with the
   236	    :py:func:`mlflow.models.evaluate()`
   237	    API.
   238	    """
   239	
   240	    NUM_SAMPLE_ROWS_FOR_HASH = 5
   241	    SPARK_DATAFRAME_LIMIT = 10000
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	
   303	
   304	
   305	
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	
   414	
   415	
   416	
   417	
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	    @property
   426	    def feature_names(self):
   427	        return self._feature_names
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	    @property
   437	    def labels_data(self):
   438	        """
   439	        return labels data as a numpy array
   440	        """
   441	        return self._labels_data
   442	
   443	    @property
   444	    def has_targets(self):
   445	        """
   446	        Returns True if the dataset has targets, False otherwise.
   447	        """
   448	        return self._has_targets
   449	
   450	    @property
   451	    def targets_name(self):
   452	        """
   453	        return targets name
   454	        """
   455	        return self._targets_name
   456	
   457	    @property
   458	    def predictions_data(self):
   459	        """
   460	        return labels data as a numpy array
   461	        """
   462	        return self._predictions_data
   463	
   464	    @property
   465	    def has_predictions(self):
   466	        """
   467	        Returns True if the dataset has targets, False otherwise.
   468	        """
   469	        return self._has_predictions
   470	
   471	    @property
   472	    def predictions_name(self):
   473	        """
   474	        return predictions name
   475	        """
   476	        return self._predictions_name
   477	
   478	    @property
   479	    def name(self):
   480	        """
   481	        Dataset name, which is specified dataset name or the dataset hash if user don't specify
   482	        name.
   483	        """
   484	        return self._user_specified_name if self._user_specified_name is not None else self.hash
   485	
   486	    @property
   487	    def path(self):
   488	        """
   489	        Dataset path
   490	        """
   491	        return self._path
   492	
   493	    @property
   494	    def hash(self):
   495	        """
   496	        Dataset hash, includes hash on first 20 rows and last 20 rows.
   497	        """
   498	        return self._hash
   499	
   500	    @property
   501	    def _metadata(self):
   502	        """
   503	        Return dataset metadata containing name, hash, and optional path.
   504	        """
   505	        metadata = {
   506	            "name": self.name,
   507	            "hash": self.hash,
   508	        }
   509	        if self.path is not None:
   510	            metadata["path"] = self.path
   511	        return metadata
   512	
   513	    @property
   514	    def digest(self):
   515	        """
   516	        Return the digest of the dataset.
   517	        """
   518	        return self._digest
   519	
   520	    def _log_dataset_tag(self, client, run_id, model_uuid):
   521	        """
   522	        Log dataset metadata as a tag "mlflow.datasets", if the tag already exists, it will
   523	        append current dataset metadata into existing tag content.
   524	        """
   525	        existing_dataset_metadata_str = client.get_run(run_id).data.tags.get(
   526	            "mlflow.datasets", "[]"
   527	        )
   528	        dataset_metadata_list = json.loads(existing_dataset_metadata_str)
   529	
   530	        for metadata in dataset_metadata_list:
   531	            if (
   532	                metadata["hash"] == self.hash
   533	                and metadata["name"] == self.name
   534	                and metadata["model"] == model_uuid
   535	            ):
   536	                break
   537	        else:
   538	            dataset_metadata_list.append({**self._metadata, "model": model_uuid})
   539	
   540	        dataset_metadata_str = json.dumps(dataset_metadata_list, separators=(",", ":"))
   541	        client.log_batch(
   542	            run_id,
   543	            tags=[RunTag("mlflow.datasets", dataset_metadata_str)],
   544	        )
   545	
   546	    def __hash__(self):
   547	        return hash(self.hash)
   548	
   549	    def __eq__(self, other):
   550	        if not isinstance(other, EvaluationDataset):
   551	            return False
   552	
   553	        if isinstance(self._features_data, np.ndarray):
   554	            is_features_data_equal = np.array_equal(self._features_data, other._features_data)
   555	        else:
   556	            is_features_data_equal = self._features_data.equals(other._features_data)
   557	
   558	        return (
   559	            is_features_data_equal
   560	            and np.array_equal(self._labels_data, other._labels_data)
   561	            and self.name == other.name
   562	            and self.path == other.path
   563	            and self._feature_names == other._feature_names
   564	        )
```

## 原始行 36 · command_execution

命令：
```
/bin/bash -lc "nl -ba tests/types/test_schema.py | sed -n '1480,1785p'; nl -ba tests/types/test_schema.py | sed -n '2020,2090p'"
```

退出码：`0`

输出：
```
  1480	                {"role": "user", "content": "Summarize the following document ...", "name": "jeff"},
  1481	            ]
  1482	        },
  1483	    ]
  1484	    dtype = _infer_colspec_type(data)
  1485	    assert dtype == Array(
  1486	        Object(
  1487	            [
  1488	                Property(
  1489	                    "messages",
  1490	                    Array(
  1491	                        Object(
  1492	                            [
  1493	                                Property("role", DataType.string),
  1494	                                Property("content", DataType.string),
  1495	                                Property("name", DataType.string, required=False),
  1496	                            ]
  1497	                        )
  1498	                    ),
  1499	                )
  1500	            ]
  1501	        )
  1502	    )
  1503	
  1504	
  1505	def test_infer_schema_on_objects_and_arrays_to_and_from_dict():
  1506	    data = [
  1507	        {
  1508	            "messages": [
  1509	                {"role": "system", "content": "Translate every message you receive to French."},
  1510	                {"role": "user", "content": "I like machine learning"},
  1511	            ],
  1512	        },
  1513	        {
  1514	            "messages": [
  1515	                {"role": "user", "content": "Summarize the following document ...", "name": "jeff"},
  1516	            ]
  1517	        },
  1518	    ]
  1519	    schema = _infer_schema(data)
  1520	    assert schema == Schema(
  1521	        [
  1522	            ColSpec(
  1523	                Array(
  1524	                    Object(
  1525	                        [
  1526	                            Property("role", DataType.string),
  1527	                            Property("content", DataType.string),
  1528	                            Property("name", DataType.string, required=False),
  1529	                        ]
  1530	                    )
  1531	                ),
  1532	                name="messages",
  1533	            )
  1534	        ]
  1535	    )
  1536	    assert schema.to_dict() == [
  1537	        {
  1538	            "type": "array",
  1539	            "items": {
  1540	                "type": "object",
  1541	                "properties": {
  1542	                    "content": {"type": "string", "required": True},
  1543	                    "name": {"type": "string", "required": False},
  1544	                    "role": {"type": "string", "required": True},
  1545	                },
  1546	            },
  1547	            "name": "messages",
  1548	            "required": True,
  1549	        }
  1550	    ]
  1551	    assert Schema.from_json(json.dumps(schema.to_dict())) == schema
  1552	
  1553	    data = [
  1554	        {
  1555	            "messages": [
  1556	                {"role": "system", "content": "Translate every message you receive to French."},
  1557	                {"role": "user", "content": "I like machine learning"},
  1558	            ],
  1559	            "another_message": "hello world",
  1560	        },
  1561	        {
  1562	            "messages": [
  1563	                {"role": "user", "content": "Summarize the following document ...", "name": "jeff"},
  1564	            ]
  1565	        },
  1566	    ]
  1567	    schema = _infer_schema(data)
  1568	    assert schema == Schema(
  1569	        [
  1570	            ColSpec(
  1571	                Array(
  1572	                    Object(
  1573	                        [
  1574	                            Property("role", DataType.string),
  1575	                            Property("content", DataType.string),
  1576	                            Property("name", DataType.string, required=False),
  1577	                        ]
  1578	                    )
  1579	                ),
  1580	                name="messages",
  1581	            ),
  1582	            ColSpec(DataType.string, name="another_message", required=False),
  1583	        ]
  1584	    )
  1585	    assert schema.to_dict() == [
  1586	        {
  1587	            "type": "array",
  1588	            "items": {
  1589	                "type": "object",
  1590	                "properties": {
  1591	                    "content": {"type": "string", "required": True},
  1592	                    "name": {"type": "string", "required": False},
  1593	                    "role": {"type": "string", "required": True},
  1594	                },
  1595	            },
  1596	            "name": "messages",
  1597	            "required": True,
  1598	        },
  1599	        {
  1600	            "type": "string",
  1601	            "name": "another_message",
  1602	            "required": False,
  1603	        },
  1604	    ]
  1605	    assert Schema.from_json(json.dumps(schema.to_dict())) == schema
  1606	
  1607	
  1608	@pytest.mark.parametrize(
  1609	    ("data", "data_type"),
  1610	    [
  1611	        ("string", DataType.string),
  1612	        (np.int32(1), DataType.integer),
  1613	        (True, DataType.boolean),
  1614	        (1.0, DataType.double),
  1615	        (np.float32(0.1), DataType.float),
  1616	        (np.int64(100), DataType.long),
  1617	        (np.datetime64("2023-10-13 00:00:00"), DataType.datetime),
  1618	    ],
  1619	)
  1620	def test_schema_inference_on_datatypes(data, data_type):
  1621	    assert _infer_schema(data) == Schema([ColSpec(data_type)])
  1622	
  1623	
  1624	@pytest.mark.parametrize(
  1625	    ("data", "data_type"),
  1626	    [
  1627	        (["a", "b", "c"], DataType.string),
  1628	        ([np.int32(1), np.int32(2)], DataType.integer),
  1629	        ([True, False], DataType.boolean),
  1630	        ([1.0, 2.0], DataType.double),
  1631	        ([np.float32(0.1), np.float32(0.2)], DataType.float),
  1632	        ([np.int64(100), np.int64(200)], DataType.long),
  1633	        (
  1634	            [np.datetime64("2023-10-13 00:00:00"), np.datetime64("2023-10-14 00:00:00")],
  1635	            DataType.datetime,
  1636	        ),
  1637	    ],
  1638	)
  1639	def test_schema_inference_on_dictionaries(data, data_type):
  1640	    test_data = {"data": data}
  1641	    assert _infer_schema(test_data) == Schema([ColSpec(Array(data_type), name="data")])
  1642	
  1643	    test_data = {"data": {"dict": data}}
  1644	    inferred_schema = _infer_schema(test_data)
  1645	    expected_schema = Schema([ColSpec(Object([Property("dict", Array(data_type))]), name="data")])
  1646	    assert inferred_schema == expected_schema
  1647	
  1648	
  1649	@pytest.mark.parametrize(
  1650	    ("data", "data_type"),
  1651	    [
  1652	        (["a", "b", "c"], DataType.string),
  1653	        ([np.int32(1), np.int32(2)], DataType.integer),
  1654	        ([True, False], DataType.boolean),
  1655	        ([1.0, 2.0], DataType.double),
  1656	        ([np.float32(0.1), np.float32(0.2)], DataType.float),
  1657	        ([np.int64(100), np.int64(200)], DataType.long),
  1658	        (
  1659	            [np.datetime64("2023-10-13 00:00:00"), np.datetime64("2023-10-14 00:00:00")],
  1660	            DataType.datetime,
  1661	        ),
  1662	    ],
  1663	)
  1664	def test_schema_inference_on_lists(data, data_type):
  1665	    assert _infer_schema(data) == Schema([ColSpec(data_type)])
  1666	
  1667	    test_data = [{"data": data}]
  1668	    assert _infer_schema(test_data) == Schema([ColSpec(Array(data_type), name="data")])
  1669	
  1670	    test_data = [{"data": [data]}]
  1671	    assert _infer_schema(test_data) == Schema([ColSpec(Array(Array(data_type)), name="data")])
  1672	
  1673	    test_data = [{"data": {"dict": data}}, {"data": {"dict": data, "string": "a"}}]
  1674	    inferred_schema = _infer_schema(test_data)
  1675	    expected_schema = Schema(
  1676	        [
  1677	            ColSpec(
  1678	                Object(
  1679	                    [
  1680	                        Property("dict", Array(data_type)),
  1681	                        Property("string", DataType.string, required=False),
  1682	                    ]
  1683	                ),
  1684	                name="data",
  1685	            )
  1686	        ]
  1687	    )
  1688	    assert inferred_schema == expected_schema
  1689	
  1690	    test_data = [{"data": {"dict": data}}, {"data": {"dict": data}, "string": "a"}]
  1691	    inferred_schema = _infer_schema(test_data)
  1692	    expected_schema = Schema(
  1693	        [
  1694	            ColSpec(Object([Property("dict", Array(data_type))]), name="data"),
  1695	            ColSpec(DataType.string, name="string", required=False),
  1696	        ]
  1697	    )
  1698	    assert inferred_schema == expected_schema
  1699	
  1700	
  1701	def test_schema_inference_with_empty_lists():
  1702	    # If (non-nested) empty list is passed, should be inferred as string for backward compatibility
  1703	    # with version 2.7.1: https://github.com/mlflow/mlflow/blob/v2.7.1/mlflow/types/utils.py#L150
  1704	    data = []
  1705	    assert _infer_schema(data) == Schema([ColSpec(DataType.string)])
  1706	
  1707	    data = [None, "a"]
  1708	    assert _infer_schema(data) == Schema([ColSpec(DataType.string)])
  1709	
  1710	    data = [["a", "b", "c"], ["a", "b", "c", "d"], None]
  1711	    assert _infer_schema(data) == Schema([ColSpec(Array(DataType.string))])
  1712	
  1713	    data = [[None, np.nan]]
  1714	    assert _infer_schema(data) == Schema([ColSpec(Array(AnyType()))])
  1715	
  1716	    assert _infer_schema([[]]) == Schema([ColSpec(AnyType())])
  1717	
  1718	    # Empty numpy array is not allowed.
  1719	    with pytest.raises(
  1720	        MlflowException,
  1721	        match=r"Numpy array must include at least one non-empty item",
  1722	    ):
  1723	        _infer_schema([np.array([])])
  1724	
  1725	    # If at least one of sublists is not empty, we can assume other empty lists have the same type.
  1726	    data = [
  1727	        {
  1728	            "data": [
  1729	                ["a", "b", "c"],
  1730	                [],
  1731	                ["d", "e"],
  1732	                [],
  1733	            ]
  1734	        }
  1735	    ]
  1736	    inferred_schema = _infer_schema(data)
  1737	    expected_schema = Schema([ColSpec(Array(Array(DataType.string)), name="data")])
  1738	    assert inferred_schema == expected_schema
  1739	
  1740	    # Complex case for deeply nested array
  1741	    data = [
  1742	        {
  1743	            "data": [
  1744	                [["a", "b", "c"], [], ["d"]],
  1745	                [[], ["e"]],
  1746	                [
  1747	                    [],
  1748	                    [],
  1749	                    [],
  1750	                ],
  1751	            ]
  1752	        }
  1753	    ]
  1754	    inferred_schema = _infer_schema(data)
  1755	    expected_schema = Schema([ColSpec(Array(Array(Array(DataType.string))), name="data")])
  1756	    assert inferred_schema == expected_schema
  1757	
  1758	    data = [{"data": {"key": []}}]
  1759	    assert _infer_schema(data) == Schema(
  1760	        [ColSpec(Object([Property("key", AnyType(), required=False)]), name="data")]
  1761	    )
  1762	
  1763	
  1764	def test_repr_of_objects():
  1765	    obj = Object(
  1766	        properties=[
  1767	            Property(name="a", dtype=DataType.string),
  1768	            Property(name="b", dtype=DataType.double, required=False),
  1769	            Property(name="c", dtype=Array(DataType.long)),
  1770	            Property(name="d", dtype=Object([Property("d1", DataType.string)])),
  1771	        ]
  1772	    )
  1773	    obj_repr = (
  1774	        "{a: string (required), b: double (optional), c: Array(long) "
  1775	        "(required), d: {d1: string (required)} (required)}"
  1776	    )
  1777	    assert repr(obj) == obj_repr
  1778	
  1779	    arr = Array(obj)
  1780	    assert repr(arr) == f"Array({obj_repr})"
  1781	
  1782	
  1783	def test_convert_dataclass_to_schema_for_rag():
  1784	    schema = convert_dataclass_to_schema(rag_signatures.ChatCompletionRequest())
  1785	    schema_dict = schema.to_dict()
  2020	                            "example": False,
  2021	                            "tool_calls": [],
  2022	                            "invalid_tool_calls": [],
  2023	                            "usage_metadata": None,
  2024	                        },
  2025	                        {
  2026	                            "content": "Who owns MLflow?",
  2027	                            "additional_kwargs": {},
  2028	                            "response_metadata": {},
  2029	                            "type": "human",
  2030	                            "name": None,
  2031	                            "id": None,
  2032	                            "example": False,
  2033	                        },
  2034	                    ],
  2035	                    "text": "Hello?",
  2036	                }
  2037	            ],
  2038	            Schema(
  2039	                [
  2040	                    ColSpec(
  2041	                        Array(
  2042	                            Object(
  2043	                                properties=[
  2044	                                    Property("content", DataType.string),
  2045	                                    Property("additional_kwargs", AnyType(), required=False),
  2046	                                    Property("response_metadata", AnyType(), required=False),
  2047	                                    Property("type", DataType.string),
  2048	                                    Property("name", AnyType(), required=False),
  2049	                                    Property("id", AnyType(), required=False),
  2050	                                    Property("example", DataType.boolean, required=False),
  2051	                                    Property("tool_calls", AnyType(), required=False),
  2052	                                    Property("invalid_tool_calls", AnyType(), required=False),
  2053	                                    Property("usage_metadata", AnyType(), required=False),
  2054	                                ]
  2055	                            )
  2056	                        ),
  2057	                        name="messages",
  2058	                    ),
  2059	                    ColSpec(DataType.string, name="text"),
  2060	                ]
  2061	            ),
  2062	        ),
  2063	    ],
  2064	)
  2065	def test_infer_schema_with_anytype(data, expected_schema):
  2066	    inferred_schema = _infer_schema(data)
  2067	    assert inferred_schema == expected_schema
```

## 原始行 38 · command_execution

命令：
```
/bin/bash -lc "grep -RInE 'Dataset\\(|to_dict\\(|to_json\\(|\\.name|\\.digest' tests/data --include='*.py' | head -n 500"
```

退出码：`0`

输出：
```
tests/data/test_dataset.py:9:def test_conversion_to_json():
tests/data/test_dataset.py:12:    dataset = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")
tests/data/test_dataset.py:14:    dataset_json = dataset.to_json()
tests/data/test_dataset.py:17:    assert parsed_json["name"] == dataset.name
tests/data/test_dataset.py:18:    assert parsed_json["digest"] == dataset.digest
tests/data/test_dataset.py:19:    assert parsed_json["source"] == dataset.source.to_json()
tests/data/test_dataset.py:30:    dataset = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")
tests/data/test_dataset.py:31:    assert dataset.digest == dataset._compute_digest()
tests/data/test_dataset.py:38:    dataset_without_name = SampleDataset(data_list=[1, 2, 3], source=source)
tests/data/test_dataset.py:39:    assert dataset_without_name.name == "dataset"
tests/data/test_dataset.py:41:    dataset_with_name = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")
tests/data/test_dataset.py:42:    assert dataset_with_name.name == "testname"
tests/data/test_huggingface_dataset_and_source.py:78:    assert reloaded_mlflow_ds.digest == mlflow_ds.digest
tests/data/test_huggingface_dataset_and_source.py:126:    assert reloaded_mlflow_ds.digest == mlflow_ds.digest
tests/data/test_huggingface_dataset_and_source.py:155:    assert reloaded_mlflow_ds.digest == mlflow_ds.digest
tests/data/test_huggingface_dataset_and_source.py:163:    assert mlflow_ds.name == "myname"
tests/data/test_huggingface_dataset_and_source.py:164:    assert mlflow_ds.digest == "mydigest"
tests/data/test_huggingface_dataset_and_source.py:185:    assert mlflow_ds.digest == "1dda4ce8"
tests/data/test_huggingface_dataset_and_source.py:205:    assert "mlflow.source.name" in mlflow_ds.source.to_json()
tests/data/test_huggingface_dataset_and_source.py:208:def test_dataset_conversion_to_json():
tests/data/test_huggingface_dataset_and_source.py:212:    dataset_json = mlflow_ds.to_json()
tests/data/test_huggingface_dataset_and_source.py:215:    assert parsed_json["name"] == mlflow_ds.name
tests/data/test_huggingface_dataset_and_source.py:216:    assert parsed_json["digest"] == mlflow_ds.digest
tests/data/test_huggingface_dataset_and_source.py:217:    assert parsed_json["source"] == mlflow_ds.source.to_json()
tests/data/test_huggingface_dataset_and_source.py:225:def test_dataset_source_conversion_to_json():
tests/data/test_huggingface_dataset_and_source.py:238:    source_json = source.to_json()
tests/data/test_huggingface_dataset_and_source.py:248:    assert json.loads(reloaded_source.to_json()) == parsed_source
tests/data/test_huggingface_dataset_and_source.py:255:    assert reloaded_source.to_json() == source.to_json()
tests/data/test_dataset_source_registry.py:42:    resolved_source_json = resolved_source.to_json()
tests/data/test_dataset_registry.py:109:    assert dataset.name == "dataset_name"
tests/data/test_dataset_registry.py:110:    assert dataset.digest == "foo"
tests/data/test_dataset_registry.py:120:        return SampleDataset(data_list=data_list, source=resolved_source, name=name, digest=digest)
tests/data/test_dataset_registry.py:134:    assert dataset1.name == "name1"
tests/data/test_dataset_registry.py:135:    assert dataset1.digest == "digest1"
tests/data/test_dataset_registry.py:146:    assert dataset2.name == "name2"
tests/data/test_dataset_registry.py:147:    assert dataset2.digest == "digest2"
tests/data/test_polars_dataset.py:104:def test_conversion_to_json(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:105:    dataset = PolarsDataset(
tests/data/test_polars_dataset.py:109:    dataset_json = dataset.to_json()
tests/data/test_polars_dataset.py:113:    assert parsed_json["name"] == dataset.name
tests/data/test_polars_dataset.py:114:    assert parsed_json["digest"] == dataset.digest
tests/data/test_polars_dataset.py:115:    assert parsed_json["source"] == dataset.source.to_json()
tests/data/test_polars_dataset.py:124:    dataset = PolarsDataset(df=pl.DataFrame([1, 2, 3], schema=["Numbers"]), source=source)
tests/data/test_polars_dataset.py:125:    assert dataset.digest == dataset._compute_digest()
tests/data/test_polars_dataset.py:127:    assert re.match(r"^\d+$", dataset.digest)
tests/data/test_polars_dataset.py:132:    dataset1 = PolarsDataset(
tests/data/test_polars_dataset.py:136:    dataset2 = PolarsDataset(
tests/data/test_polars_dataset.py:139:    assert dataset1.digest == dataset2.digest
tests/data/test_polars_dataset.py:144:    dataset1 = PolarsDataset(
tests/data/test_polars_dataset.py:148:    dataset2 = PolarsDataset(
tests/data/test_polars_dataset.py:151:    assert dataset1.digest != dataset2.digest
tests/data/test_polars_dataset.py:156:    dataset = PolarsDataset(df=df, source=source)
tests/data/test_polars_dataset.py:162:    dataset_no_targets = PolarsDataset(df=df_no_targets, source=source)
tests/data/test_polars_dataset.py:168:    dataset_with_targets = PolarsDataset(df=df_with_targets, source=source, targets="c")
tests/data/test_polars_dataset.py:178:        PolarsDataset(df=df, source=source, targets="d")
tests/data/test_polars_dataset.py:183:    dataset = PolarsDataset(df=df, source=source)
tests/data/test_polars_dataset.py:195:    dataset = PolarsDataset(df=df, source=source, targets="c")
tests/data/test_polars_dataset.py:246:    assert "mlflow.source.name" in mlflow_df.source.to_json()
tests/data/test_polars_dataset.py:253:    dataset = PolarsDataset(df=df, source=source, targets="c", name="testname")
tests/data/test_polars_dataset.py:256:    assert evaluation_dataset.name is not None
tests/data/test_polars_dataset.py:257:    assert evaluation_dataset.digest is not None
tests/data/test_http_dataset_source.py:18:    assert source.to_json() == json.dumps({"url": url})
tests/data/test_http_dataset_source.py:21:        source.to_json(), source_type=source._get_source_type()
tests/data/test_pandas_dataset.py:37:def test_conversion_to_json():
tests/data/test_pandas_dataset.py:41:    dataset = PandasDataset(
tests/data/test_pandas_dataset.py:47:    dataset_json = dataset.to_json()
tests/data/test_pandas_dataset.py:50:    assert parsed_json["name"] == dataset.name
tests/data/test_pandas_dataset.py:51:    assert parsed_json["digest"] == dataset.digest
tests/data/test_pandas_dataset.py:52:    assert parsed_json["source"] == dataset.source.to_json()
tests/data/test_pandas_dataset.py:63:    dataset = PandasDataset(
tests/data/test_pandas_dataset.py:68:    assert dataset.digest == dataset._compute_digest()
tests/data/test_pandas_dataset.py:69:    assert dataset.digest == "31ccce44"
tests/data/test_pandas_dataset.py:76:    dataset = PandasDataset(
tests/data/test_pandas_dataset.py:88:    dataset_no_targets = PandasDataset(
tests/data/test_pandas_dataset.py:95:    dataset_with_targets = PandasDataset(
tests/data/test_pandas_dataset.py:112:        PandasDataset(
tests/data/test_pandas_dataset.py:124:    dataset = PandasDataset(
tests/data/test_pandas_dataset.py:136:    dataset = PandasDataset(
tests/data/test_pandas_dataset.py:223:    assert "mlflow.source.name" in mlflow_df.source.to_json()
tests/data/test_pandas_dataset.py:232:    dataset = PandasDataset(
tests/data/test_pandas_dataset.py:240:    assert evaluation_dataset.name is not None
tests/data/test_pandas_dataset.py:241:    assert evaluation_dataset.digest is not None
tests/data/test_pandas_dataset.py:251:    dataset1 = PandasDataset(
tests/data/test_pandas_dataset.py:257:    dataset2 = PandasDataset(
tests/data/test_pandas_dataset.py:263:    assert dataset1.digest != dataset2.digest
tests/data/test_pandas_dataset.py:276:    dataset1 = PandasDataset(df=df, source=source, name="testname")
tests/data/test_pandas_dataset.py:277:    dataset2 = PandasDataset(df=df, source=source, name="testname")
tests/data/test_pandas_dataset.py:278:    assert dataset1.digest == dataset2.digest
tests/data/test_artifact_dataset_sources.py:54:    source_json = dataset_source.to_json()
tests/data/test_tensorflow_dataset.py:79:def test_conversion_to_json():
tests/data/test_tensorflow_dataset.py:84:    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:86:    dataset_json = dataset.to_json()
tests/data/test_tensorflow_dataset.py:89:    assert parsed_json["name"] == dataset.name
tests/data/test_tensorflow_dataset.py:90:    assert parsed_json["digest"] == dataset.digest
tests/data/test_tensorflow_dataset.py:91:    assert parsed_json["source"] == dataset.source.to_json()
tests/data/test_tensorflow_dataset.py:149:    dataset = TensorFlowDataset(features=features, targets=targets, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:151:    dataset_json = dataset.to_json()
tests/data/test_tensorflow_dataset.py:154:    assert parsed_json["name"] == dataset.name
tests/data/test_tensorflow_dataset.py:155:    assert parsed_json["digest"] == dataset.digest
tests/data/test_tensorflow_dataset.py:156:    assert parsed_json["source"] == dataset.source.to_json()
tests/data/test_tensorflow_dataset.py:179:    dataset = TensorFlowDataset(
tests/data/test_tensorflow_dataset.py:213:    dataset = TensorFlowDataset(
tests/data/test_tensorflow_dataset.py:243:    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:244:    assert dataset.digest == dataset._compute_digest()
tests/data/test_tensorflow_dataset.py:245:    assert dataset.digest == "666a9820"
tests/data/test_tensorflow_dataset.py:253:    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:262:    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:271:    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:282:    dataset = TensorFlowDataset(features=tf_tensor, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:293:    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
tests/data/test_tensorflow_dataset.py:304:    dataset = TensorFlowDataset(
tests/data/test_tensorflow_dataset.py:320:    dataset = TensorFlowDataset(
tests/data/test_tensorflow_dataset.py:402:    assert "mlflow.source.name" in mlflow_ds.source.to_json()
tests/data/test_tensorflow_dataset.py:410:    assert mlflow_ds.digest == "bc8ef018"
tests/data/test_spark_dataset_source.py:34:    assert spark_datasource.to_json() == json.dumps({"path": path})
tests/data/test_spark_dataset_source.py:39:        spark_datasource.to_json(), source_type=spark_datasource._get_source_type()
tests/data/test_spark_dataset_source.py:43:    assert reloaded_source.to_json() == spark_datasource.to_json()
tests/data/test_spark_dataset_source.py:52:    assert spark_datasource.to_json() == json.dumps({"table_name": "temp"})
tests/data/test_spark_dataset_source.py:57:        spark_datasource.to_json(), source_type=spark_datasource._get_source_type()
tests/data/test_spark_dataset_source.py:61:    assert reloaded_source.to_json() == spark_datasource.to_json()
tests/data/test_spark_dataset_source.py:70:    assert spark_datasource.to_json() == json.dumps({"sql": "SELECT * FROM temp_sql"})
tests/data/test_spark_dataset_source.py:75:        spark_datasource.to_json(), source_type=spark_datasource._get_source_type()
tests/data/test_spark_dataset_source.py:79:    assert reloaded_source.to_json() == spark_datasource.to_json()
tests/data/test_dataset_source.py:19:    source_json = source.to_json()
tests/data/test_dataset_source.py:32:    assert json.loads(source1.to_json()) == json.loads(pandas_ds.source.to_json())
tests/data/test_dataset_source.py:41:    assert json.loads(source2.to_json()) == json.loads(pandas_ds.source.to_json())
tests/data/test_dataset_source.py:45:    assert json.loads(source3.to_json()) == json.loads(pandas_ds.source.to_json())
tests/data/test_dataset_source.py:55:    assert json.loads(source1.to_json()) == json.loads(pandas_ds.source.to_json())
tests/data/test_dataset_source.py:64:    assert json.loads(source2.to_json()) == json.loads(pandas_ds.source.to_json())
tests/data/test_dataset_source.py:68:    assert json.loads(source3.to_json()) == json.loads(pandas_ds.source.to_json())
tests/data/test_spark_dataset.py:84:        assert dataset.name == expected_name
tests/data/test_spark_dataset.py:94:    dataset = SparkDataset(
tests/data/test_spark_dataset.py:100:    dataset_json = dataset.to_json()
tests/data/test_spark_dataset.py:103:    assert parsed_json["name"] == dataset.name
tests/data/test_spark_dataset.py:104:    assert parsed_json["digest"] == dataset.digest
tests/data/test_spark_dataset.py:105:    assert parsed_json["source"] == dataset.source.to_json()
tests/data/test_spark_dataset.py:120:    dataset = SparkDataset(
tests/data/test_spark_dataset.py:126:    dataset_json = dataset.to_json()
tests/data/test_spark_dataset.py:129:    assert parsed_json["name"] == dataset.name
tests/data/test_spark_dataset.py:130:    assert parsed_json["digest"] == dataset.digest
tests/data/test_spark_dataset.py:131:    assert parsed_json["source"] == dataset.source.to_json()
tests/data/test_spark_dataset.py:146:    dataset = SparkDataset(
tests/data/test_spark_dataset.py:151:    assert dataset.digest == dataset._compute_digest()
tests/data/test_spark_dataset.py:163:    dataset = SparkDataset(
tests/data/test_spark_dataset.py:177:    dataset_no_targets = SparkDataset(
tests/data/test_spark_dataset.py:183:    dataset_with_targets = SparkDataset(
tests/data/test_spark_dataset.py:195:        SparkDataset(
tests/data/test_spark_dataset.py:209:    dataset_no_predictions = SparkDataset(
tests/data/test_spark_dataset.py:215:    dataset_with_predictions = SparkDataset(
tests/data/test_spark_dataset.py:227:        SparkDataset(
tests/data/test_spark_dataset.py:242:    assert "mlflow.source.name" in mlflow_df.source.to_json()
tests/data/test_spark_dataset.py:412:    dataset = SparkDataset(
tests/data/test_meta_dataset.py:29:    dataset = MetaDataset(source=source)
tests/data/test_meta_dataset.py:31:    json_str = dataset.to_json()
tests/data/test_meta_dataset.py:55:    dataset = MetaDataset(source=source, schema=schema)
tests/data/test_meta_dataset.py:57:    json_str = dataset.to_json()
tests/data/test_meta_dataset.py:63:    assert json.loads(parsed_json["schema"])["mlflow_colspec"] == schema.to_dict()
tests/data/test_meta_dataset.py:68:    dataset1 = MetaDataset(source=http_source)
tests/data/test_meta_dataset.py:75:    dataset2 = MetaDataset(source=http_source, schema=schema)
tests/data/test_meta_dataset.py:77:    assert dataset1.digest != dataset2.digest
tests/data/test_meta_dataset.py:80:    dataset3 = MetaDataset(source=delta_source)
tests/data/test_meta_dataset.py:81:    assert dataset1.digest != dataset3.digest
tests/data/test_meta_dataset.py:102:        dataset = MetaDataset(source=uc_volume_source)
tests/data/test_meta_dataset.py:103:        json_str = dataset.to_json()
tests/data/test_meta_dataset.py:117:    meta_dataset = MetaDataset(source=pandas_dataset)
tests/data/test_meta_dataset.py:119:    parsed_json = json.loads(meta_dataset.to_json())
tests/data/test_delta_dataset_source.py:39:    assert delta_datasource.to_dict()["path"] == path
tests/data/test_delta_dataset_source.py:42:        delta_datasource.to_json(), source_type=delta_datasource._get_source_type()
tests/data/test_delta_dataset_source.py:46:    assert reloaded_source.to_json() == delta_datasource.to_json()
tests/data/test_delta_dataset_source.py:59:    assert delta_datasource.to_dict()["delta_table_name"] == "temp_delta"
tests/data/test_delta_dataset_source.py:62:        delta_datasource.to_json(), source_type=delta_datasource._get_source_type()
tests/data/test_delta_dataset_source.py:66:    assert reloaded_source.to_json() == delta_datasource.to_json()
tests/data/test_delta_dataset_source.py:87:    config = delta_datasource.to_dict()
tests/data/test_delta_dataset_source.py:92:        delta_datasource.to_json(), source_type=delta_datasource._get_source_type()
tests/data/test_delta_dataset_source.py:96:    assert reloaded_source.to_json() == delta_datasource.to_json()
tests/data/test_delta_dataset_source.py:156:        assert delta_datasource.to_json() == json.dumps(
tests/data/test_delta_dataset_source.py:223:        req_body = message_to_json(GetTable(full_name_arg=test_table_name))
tests/data/test_code_dataset_source.py:10:    assert code_datasource.to_dict() == {
```

## 原始行 41 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/data/evaluation_dataset.py | sed -n '90,580p'"
```

退出码：`0`

输出：
```
    90	            return _hash_uint64_ndarray_as_bytes(pd.util.hash_array(np.array([data])))
    91	    except Exception:
    92	        pass
    93	    # Skip unsupported types by returning an empty byte string
    94	    return b""
    95	
    96	
    97	def _hash_dict_as_bytes(data_dict):
    98	    result = _hash_ndarray_as_bytes(list(data_dict.keys()))
    99	    try:
   100	        result += _hash_ndarray_as_bytes(list(data_dict.values()))
   101	    # If the values containing non-hashable objects, we will hash the values recursively.
   102	    except Exception:
   103	        for value in data_dict.values():
   104	            result += _hash_data_as_bytes(value)
   105	    return result
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	def convert_data_to_mlflow_dataset(data, targets=None, predictions=None, name=None):
   182	    """Convert input data to mlflow dataset."""
   183	    supported_dataframe_types = [pd.DataFrame]
   184	    if "pyspark" in sys.modules:
   185	        from mlflow.utils.spark_utils import get_spark_dataframe_type
   186	
   187	        spark_df_type = get_spark_dataframe_type()
   188	        supported_dataframe_types.append(spark_df_type)
   189	
   190	    if predictions is not None:
   191	        _validate_dataset_type_supports_predictions(
   192	            data=data, supported_predictions_dataset_types=supported_dataframe_types
   193	        )
   194	
   195	    if isinstance(data, list):
   196	        # If the list is flat, we assume each element is an independent sample.
   197	        if not isinstance(data[0], (list, np.ndarray)):
   198	            data = [[elm] for elm in data]
   199	
   200	        return mlflow.data.from_numpy(
   201	            np.array(data), targets=np.array(targets) if targets else None, name=name
   202	        )
   203	    elif isinstance(data, np.ndarray):
   204	        return mlflow.data.from_numpy(data, targets=targets, name=name)
   205	    elif isinstance(data, pd.DataFrame):
   206	        return mlflow.data.from_pandas(df=data, targets=targets, predictions=predictions, name=name)
   207	    elif "pyspark" in sys.modules and isinstance(data, spark_df_type):
   208	        return mlflow.data.from_spark(df=data, targets=targets, predictions=predictions, name=name)
   209	    else:
   210	        # Cannot convert to mlflow dataset, return original data.
   211	        _logger.info(
   212	            "Cannot convert input data to `evaluate()` to an mlflow dataset, input must be a list, "
   213	            f"a numpy array, a panda Dataframe or a spark Dataframe, but received {type(data)}."
   214	        )
   215	        return data
   216	
   217	
   218	def _validate_dataset_type_supports_predictions(data, supported_predictions_dataset_types):
   219	    """
   220	    Validate that the dataset type supports a user-specified "predictions" column.
   221	    """
   222	    if not any(isinstance(data, sdt) for sdt in supported_predictions_dataset_types):
   223	        raise MlflowException(
   224	            message=(
   225	                "If predictions is specified, data must be one of the following types, or an"
   226	                " MLflow Dataset that represents one of the following types:"
   227	                f" {supported_predictions_dataset_types}."
   228	            ),
   229	            error_code=INVALID_PARAMETER_VALUE,
   230	        )
   231	
   232	
   233	class EvaluationDataset:
   234	    """
   235	    An input dataset for model evaluation. This is intended for use with the
   236	    :py:func:`mlflow.models.evaluate()`
   237	    API.
   238	    """
   239	
   240	    NUM_SAMPLE_ROWS_FOR_HASH = 5
   241	    SPARK_DATAFRAME_LIMIT = 10000
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	
   303	
   304	
   305	
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	
   414	
   415	
   416	
   417	
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	    @property
   426	    def feature_names(self):
   427	        return self._feature_names
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	    @property
   437	    def labels_data(self):
   438	        """
   439	        return labels data as a numpy array
   440	        """
   441	        return self._labels_data
   442	
   443	    @property
   444	    def has_targets(self):
   445	        """
   446	        Returns True if the dataset has targets, False otherwise.
   447	        """
   448	        return self._has_targets
   449	
   450	    @property
   451	    def targets_name(self):
   452	        """
   453	        return targets name
   454	        """
   455	        return self._targets_name
   456	
   457	    @property
   458	    def predictions_data(self):
   459	        """
   460	        return labels data as a numpy array
   461	        """
   462	        return self._predictions_data
   463	
   464	    @property
   465	    def has_predictions(self):
   466	        """
   467	        Returns True if the dataset has targets, False otherwise.
   468	        """
   469	        return self._has_predictions
   470	
   471	    @property
   472	    def predictions_name(self):
   473	        """
   474	        return predictions name
   475	        """
   476	        return self._predictions_name
   477	
   478	    @property
   479	    def name(self):
   480	        """
   481	        Dataset name, which is specified dataset name or the dataset hash if user don't specify
   482	        name.
   483	        """
   484	        return self._user_specified_name if self._user_specified_name is not None else self.hash
   485	
   486	    @property
   487	    def path(self):
   488	        """
   489	        Dataset path
   490	        """
   491	        return self._path
   492	
   493	    @property
   494	    def hash(self):
   495	        """
   496	        Dataset hash, includes hash on first 20 rows and last 20 rows.
   497	        """
   498	        return self._hash
   499	
   500	    @property
   501	    def _metadata(self):
   502	        """
   503	        Return dataset metadata containing name, hash, and optional path.
   504	        """
   505	        metadata = {
   506	            "name": self.name,
   507	            "hash": self.hash,
   508	        }
   509	        if self.path is not None:
   510	            metadata["path"] = self.path
   511	        return metadata
   512	
   513	    @property
   514	    def digest(self):
   515	        """
   516	        Return the digest of the dataset.
   517	        """
   518	        return self._digest
   519	
   520	    def _log_dataset_tag(self, client, run_id, model_uuid):
   521	        """
   522	        Log dataset metadata as a tag "mlflow.datasets", if the tag already exists, it will
   523	        append current dataset metadata into existing tag content.
   524	        """
   525	        existing_dataset_metadata_str = client.get_run(run_id).data.tags.get(
   526	            "mlflow.datasets", "[]"
   527	        )
   528	        dataset_metadata_list = json.loads(existing_dataset_metadata_str)
   529	
   530	        for metadata in dataset_metadata_list:
   531	            if (
   532	                metadata["hash"] == self.hash
   533	                and metadata["name"] == self.name
   534	                and metadata["model"] == model_uuid
   535	            ):
   536	                break
   537	        else:
   538	            dataset_metadata_list.append({**self._metadata, "model": model_uuid})
   539	
   540	        dataset_metadata_str = json.dumps(dataset_metadata_list, separators=(",", ":"))
   541	        client.log_batch(
   542	            run_id,
   543	            tags=[RunTag("mlflow.datasets", dataset_metadata_str)],
   544	        )
   545	
   546	    def __hash__(self):
   547	        return hash(self.hash)
   548	
   549	    def __eq__(self, other):
   550	        if not isinstance(other, EvaluationDataset):
   551	            return False
   552	
   553	        if isinstance(self._features_data, np.ndarray):
   554	            is_features_data_equal = np.array_equal(self._features_data, other._features_data)
   555	        else:
   556	            is_features_data_equal = self._features_data.equals(other._features_data)
   557	
   558	        return (
   559	            is_features_data_equal
   560	            and np.array_equal(self._labels_data, other._labels_data)
   561	            and self.name == other.name
   562	            and self.path == other.path
   563	            and self._feature_names == other._feature_names
   564	        )
```

## 原始行 44 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^def test_.*schema'"\\|"'^def test_get_tensor'"\\|clean_tensor' tests/types/test_schema.py; sed -n '170,780p' tests/types/test_schema.py"
```

退出码：`0`

输出：
```
133:def test_schema_creation():
170:def test_schema_creation_errors():
178:def test_get_schema_type(dict_of_ndarrays):
187:def test_schema_inference_on_dataframe(pandas_df_with_all_types):
206:def test_schema_inference_on_pandas_series():
276:def test_get_tensor_shape(dict_of_ndarrays):
313:def test_schema_inference_on_dictionary(dict_of_ndarrays):
347:def test_schema_inference_on_dictionary_of_strings(data, schema):
351:def test_schema_inference_on_list_with_errors():
357:def test_schema_inference_validating_dictionary_keys():
363:def test_schema_inference_on_lists_with_errors():
371:def test_schema_inference_on_list_of_dicts():
465:def test_schema_inference_on_basic_numpy(pandas_df_with_all_types):
591:def test_spark_schema_inference(pandas_df_with_all_types):
615:def test_spark_schema_inference_complex(spark):
799:def test_param_schema_find_duplicates():
983:def test_infer_param_schema():
1069:def test_param_schema_for_dicts():
1115:def test_infer_param_schema_with_errors():
1505:def test_infer_schema_on_objects_and_arrays_to_and_from_dict():
1620:def test_schema_inference_on_datatypes(data, data_type):
1639:def test_schema_inference_on_dictionaries(data, data_type):
1664:def test_schema_inference_on_lists(data, data_type):
1701:def test_schema_inference_with_empty_lists():
1783:def test_convert_dataclass_to_schema_for_rag():
1832:def test_convert_dataclass_to_schema_complex():
1874:def test_convert_dataclass_to_schema_invalid():
2065:def test_infer_schema_with_anytype(data, expected_schema):
def test_schema_creation_errors():
    with pytest.raises(MlflowException, match=r"Creating Schema with empty inputs is not allowed."):
        Schema([])

    with pytest.raises(MlflowException, match=r"Inputs of Schema must be a list, got type dict"):
        Schema({"col1": ColSpec(DataType.string)})


def test_get_schema_type(dict_of_ndarrays):
    schema = _infer_schema(dict_of_ndarrays)
    assert ["float64"] * 4 == schema.numpy_types()
    with pytest.raises(MlflowException, match="TensorSpec only supports numpy types"):
        schema.pandas_types()
    with pytest.raises(MlflowException, match="TensorSpec cannot be converted to spark dataframe"):
        schema.as_spark_schema()


def test_schema_inference_on_dataframe(pandas_df_with_all_types):
    basic_types = pandas_df_with_all_types.drop(
        columns=["boolean_ext", "integer_ext", "string_ext"]
    )
    schema = _infer_schema(basic_types)
    assert schema == Schema([ColSpec(x, x) for x in basic_types.columns])

    ext_types = pandas_df_with_all_types[["boolean_ext", "integer_ext", "string_ext"]].copy()
    expected_schema = Schema(
        [
            ColSpec(DataType.boolean, "boolean_ext"),
            ColSpec(DataType.long, "integer_ext"),
            ColSpec(DataType.string, "string_ext"),
        ]
    )
    schema = _infer_schema(ext_types)
    assert schema == expected_schema


def test_schema_inference_on_pandas_series():
    # test objects
    schema = _infer_schema(pd.Series(np.array(["a"], dtype=object)))
    assert schema == Schema([ColSpec(DataType.string)])
    schema = _infer_schema(pd.Series(np.array([bytes([1])], dtype=object)))
    assert schema == Schema([ColSpec(DataType.binary)])
    schema = _infer_schema(pd.Series(np.array([bytearray([1]), None], dtype=object), name="input"))
    assert schema == Schema([ColSpec(DataType.binary, name="input", required=False)])
    schema = _infer_schema(pd.Series(np.array([1.1, None], dtype=object), name="input"))
    assert schema == Schema([ColSpec(DataType.double, name="input", required=False)])

    # test bytes
    schema = _infer_schema(pd.Series(np.array([bytes([1])], dtype=np.bytes_)))
    assert schema == Schema([ColSpec(DataType.binary)])

    # test string
    schema = _infer_schema(pd.Series(np.array(["a"], dtype=str)))
    assert schema == Schema([ColSpec(DataType.string)])

    # test boolean
    schema = _infer_schema(pd.Series(np.array([True], dtype=bool)))
    assert schema == Schema([ColSpec(DataType.boolean)])

    # test ints
    for t in [np.uint8, np.uint16, np.int8, np.int16, np.int32]:
        schema = _infer_schema(pd.Series(np.array([1, 2, 3], dtype=t)))
        assert schema == Schema([ColSpec("integer")])

    # test longs
    for t in [np.uint32, np.int64]:
        schema = _infer_schema(pd.Series(np.array([1, 2, 3], dtype=t)))
        assert schema == Schema([ColSpec("long")])

    # unsigned long is unsupported
    with pytest.raises(MlflowException, match="Unsupported numpy data type"):
        _infer_schema(pd.Series(np.array([1, 2, 3], dtype=np.uint64)))

    # test floats
    for t in [np.float16, np.float32]:
        schema = _infer_schema(pd.Series(np.array([1.1, 2.2, 3.3], dtype=t)))
        assert schema == Schema([ColSpec("float")])

    # test doubles
    schema = _infer_schema(pd.Series(np.array([1.1, 2.2, 3.3], dtype=np.float64)))
    assert schema == Schema([ColSpec("double")])

    # test datetime
    schema = _infer_schema(
        pd.Series(
            np.array(
                ["2021-01-01 00:00:00", "2021-02-02 00:00:00", "2021-03-03 12:00:00"],
                dtype="datetime64",
            )
        )
    )
    assert schema == Schema([ColSpec("datetime")])

    # unsupported
    if hasattr(np, "float128"):
        with pytest.raises(MlflowException, match="Unsupported numpy data type"):
            _infer_schema(pd.Series(np.array([1, 2, 3], dtype=np.float128)))

    # test names
    s = pd.Series([1, 2, 3])
    if hasattr(s, "name"):
        s.rename("test", inplace=True)
        assert "test" in _infer_schema(s).input_names()
        assert len(_infer_schema(s).input_names()) == 1


def test_get_tensor_shape(dict_of_ndarrays):
    assert all(-1 == _get_tensor_shape(tensor)[0] for tensor in dict_of_ndarrays.values())

    data = dict_of_ndarrays["4D"]
    # Specify variable dimension
    for i in range(-4, 4):
        assert _get_tensor_shape(data, i)[i] == -1

    # Specify None
    assert all([_get_tensor_shape(data, None) != -1])

    # Out of bounds
    with pytest.raises(
        MlflowException, match="The specified variable_dimension 10 is out of bounds"
    ):
        _get_tensor_shape(data, 10)
    with pytest.raises(
        MlflowException, match="The specified variable_dimension -10 is out of bounds"
    ):
        _get_tensor_shape(data, -10)


@pytest.fixture
def dict_of_sparse_matrix():
    return {
        "csc": csc_matrix(np.arange(0, 12, 0.5).reshape(3, 8)),
        "csr": csr_matrix(np.arange(0, 12, 0.5).reshape(3, 8)),
    }


def test_get_sparse_matrix_data_type_and_shape(dict_of_sparse_matrix):
    for sparse_matrix in dict_of_sparse_matrix.values():
        schema = _infer_schema(sparse_matrix)
        assert schema.numpy_types() == ["float64"]
        assert _get_tensor_shape(sparse_matrix) == (-1, 8)


def test_schema_inference_on_dictionary(dict_of_ndarrays):
    # test dictionary
    schema = _infer_schema(dict_of_ndarrays)
    assert schema == Schema(
        [
            TensorSpec(tensor.dtype, _get_tensor_shape(tensor), name)
            for name, tensor in dict_of_ndarrays.items()
        ]
    )


@pytest.mark.parametrize(
    ("data", "schema"),
    [
        (
            {"a": "b", "c": "d"},
            Schema([ColSpec(DataType.string, "a"), ColSpec(DataType.string, "c")]),
        ),
        (
            {"a": ["a", "b"], "b": ["c", "d"]},
            Schema([ColSpec(Array(DataType.string), "a"), ColSpec(Array(DataType.string), "b")]),
        ),
        (
            {"a": "a", "b": ["a", "b"]},
            Schema([ColSpec(DataType.string, "a"), ColSpec(Array(DataType.string), "b")]),
        ),
        (
            [{"a": 1}, {"a": 1, "b": ["a", "b"]}],
            Schema(
                [ColSpec(DataType.long, "a"), ColSpec(Array(DataType.string), "b", required=False)]
            ),
        ),
    ],
)
def test_schema_inference_on_dictionary_of_strings(data, schema):
    assert _infer_schema(data) == schema


def test_schema_inference_on_list_with_errors():
    data = [{"a": 1, "b": "c"}, {"a": 1, "b": ["a", "b"]}]
    with pytest.raises(MlflowException, match=re.escape(MULTIPLE_TYPES_ERROR_MSG)):
        _infer_schema(data)


def test_schema_inference_validating_dictionary_keys():
    for data in [{1.7: "a", "b": "c"}, {12.4: "c", "d": "e"}]:
        with pytest.raises(MlflowException, match="The dictionary keys are not all strings."):
            _infer_schema(data)


def test_schema_inference_on_lists_with_errors():
    with pytest.raises(MlflowException, match=re.escape(MULTIPLE_TYPES_ERROR_MSG)):
        _infer_schema(["a", 1])

    with pytest.raises(MlflowException, match=re.escape(MULTIPLE_TYPES_ERROR_MSG)):
        _infer_schema(["a", ["b", "c"]])


def test_schema_inference_on_list_of_dicts():
    schema = _infer_schema([{"a": "a", "b": "b"}, {"a": "a", "b": "b"}])
    assert schema == Schema([ColSpec(DataType.string, "a"), ColSpec(DataType.string, "b")])

    schema = _infer_schema([{"a": 1}, {"b": "a"}])
    assert schema == Schema(
        [
            ColSpec(DataType.long, "a", required=False),
            ColSpec(DataType.string, "b", required=False),
        ]
    )


def test_dict_input_valid_checks_on_keys():
    match = "The dictionary keys are not all strings or "
    # User-defined keys

    class Hashable:
        def __init__(self, x: str, y: str):
            self.x = x
            self.y = y

        def __hash__(self):
            return hash((self.x, self.y))

        def __eq__(self, other):
            return isinstance(other, Hashable) and self.x == other.x and self.y == other.y

    hash_obj_1 = Hashable("some", "custom")
    hash_obj_2 = Hashable("some", "other")
    custom_hashable_dict = {hash_obj_1: "value", hash_obj_2: "other_value"}

    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(custom_hashable_dict)

    # keys are floats
    float_keys_dict = {1.1: "a", 2.2: "b"}

    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(float_keys_dict)

    # keys are bool
    bool_keys_dict = {True: "a", False: "b"}

    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(bool_keys_dict)
    # keys are tuples
    tuple_keys_dict = {("a", "b"): "a", ("a", "c"): "b"}

    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(tuple_keys_dict)

    # keys are frozenset
    frozen_set_dict = {frozenset({"a", "b"}): "a", frozenset({"b", "c"}): "b"}

    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(frozen_set_dict)


def test_dict_input_valid_checks_on_values():
    match = "Invalid values in dictionary. If passing a dictionary containing strings"

    list_of_ints = {"a": [1, 2, 3], "b": [1, 2, 3]}
    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_ints)

    list_of_floats = {"a": [1.1, 1.2], "b": [1.1, 2.2]}
    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_floats)

    list_of_dics = {"a": [{"a": "b"}, {"b": "c"}], "b": [{"a": "c"}, {"b": "d"}]}
    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_dics)

    list_of_lists = {"a": [["b", "c"], ["d", "e"]], "b": [["e", "f"], ["g", "h"]]}
    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_lists)

    list_of_set = {"a": [{"b", "c"}, {"d", "e"}], "b": [{"a", "c"}, {"d", "f"}]}
    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_set)

    list_of_frozen_set = {
        "a": [frozenset({"b", "c"}), frozenset({"d", "e"})],
        "b": [frozenset({"a", "c"}), frozenset({"d", "f"})],
    }
    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_frozen_set)

    list_of_bool = {"a": [True, True, False], "b": [False, False, True]}
    with pytest.raises(MlflowException, match=match):
        _validate_input_dictionary_contains_only_strings_and_lists_of_strings(list_of_bool)


def test_schema_inference_on_basic_numpy(pandas_df_with_all_types):
    for col in pandas_df_with_all_types:
        data = pandas_df_with_all_types[col].to_numpy()
        schema = _infer_schema(data)
        assert schema == Schema([TensorSpec(type=data.dtype, shape=(-1,))])


# Todo: arjundc : Remove _enforce_tensor_spec and move to its own test file.
def test_all_numpy_dtypes():
    def test_dtype(nparray, dtype):
        schema = _infer_schema(nparray)
        assert schema == Schema([TensorSpec(np.dtype(dtype), (-1,))])
        spec = schema.inputs[0]
        recreated_spec = TensorSpec.from_json_dict(**spec.to_dict())
        assert spec == recreated_spec
        enforced_array = _enforce_tensor_spec(nparray, spec)
        assert isinstance(enforced_array, np.ndarray)

    bool_ = ["bool", "bool_"]
    object_ = ["object"]
    signed_int = [
        "byte",
        "int8",
        "short",
        "int16",
        "intc",
        "int32",
        "int_",
        "int",
        "intp",
        "int64",
        "longlong",
    ]
    unsigned_int = [
        "ubyte",
        "uint8",
        "ushort",
        "uint16",
        "uintc",
        "uint32",
        "uint",
        "uintp",
        "uint64",
        "ulonglong",
    ]
    floating = ["half", "float16", "single", "float32", "double", "float64"]
    complex_ = [
        "csingle",
        "complex64",
        "cdouble",
        "complex128",
    ]
    bytes_ = ["bytes_"]
    str_ = ["str_"]
    platform_dependent = [
        # Complex
        "clongdouble",
        "clongfloat",
        "longcomplex",
        "complex256",
        # Float
        "longdouble",
        "longfloat",
        "float128",
    ]

    # test boolean
    for dtype in bool_:
        test_dtype(np.array([True, False, True], dtype=dtype), dtype)
        test_dtype(np.array([123, 0, -123], dtype=dtype), dtype)

    # test object
    for dtype in object_:
        test_dtype(np.array([True, False, True], dtype=dtype), dtype)
        test_dtype(np.array([123, 0, -123.544], dtype=dtype), dtype)
        test_dtype(np.array(["test", "this", "type"], dtype=dtype), dtype)
        test_dtype(np.array(["test", 123, "type"], dtype=dtype), dtype)
        test_dtype(np.array(["test", 123, 234 + 543j], dtype=dtype), dtype)

    # test signedInt_
    for dtype in signed_int:
        test_dtype(np.array([1, 2, 3, -5], dtype=dtype), dtype)

    # test unsignedInt_
    for dtype in unsigned_int:
        test_dtype(np.array([1, 2, 3, 5], dtype=dtype), dtype)

    # test floating
    for dtype in floating:
        test_dtype(np.array([1.1, -2.2, 3.3, 5.12], dtype=dtype), dtype)

    # test complex
    for dtype in complex_:
        test_dtype(np.array([1 + 2j, -2.2 - 3.6j], dtype=dtype), dtype)

    # test bytes_
    for dtype in bytes_:
        test_dtype(np.array([bytes([1, 255, 12, 34])], dtype=dtype), dtype)
    # Explicitly giving size information for flexible dtype bytes
    test_dtype(np.array([bytes([1, 255, 12, 34])], dtype="S10"), "S")
    test_dtype(np.array([bytes([1, 255, 12, 34])], dtype="S10"), "bytes")

    # str_
    for dtype in str_:
        test_dtype(np.array(["m", "l", "f", "l", "o", "w"], dtype=dtype), dtype)
        test_dtype(np.array(["mlflow"], dtype=dtype), dtype)
        test_dtype(np.array(["mlflow is the best"], dtype=dtype), dtype)
    # Explicitly giving size information for flexible dtype str_
    test_dtype(np.array(["a", "bc", "def"], dtype="U16"), "str")
    test_dtype(np.array(["a", "bc", "def"], dtype="U16"), "U")

    # test datetime
    test_dtype(
        np.array(
            ["2021-01-01 00:00:00", "2021-02-02 00:00:00", "2021-03-03 12:00:00"],
            dtype="datetime64",
        ),
        "datetime64[s]",
    )

    # platform_dependent
    for dtype in platform_dependent:
        if hasattr(np, dtype):
            test_dtype(np.array([1.1, -2.2, 3.3, 5.12], dtype=dtype), dtype)


def test_spark_schema_inference(pandas_df_with_all_types):
    import pyspark
    from pyspark.sql.types import StructField, StructType

    pandas_df_with_all_types = pandas_df_with_all_types.drop(
        columns=["boolean_ext", "integer_ext", "string_ext"]
    )
    schema = _infer_schema(pandas_df_with_all_types)
    assert schema == Schema([ColSpec(x, x) for x in pandas_df_with_all_types.columns])
    with pyspark.sql.SparkSession.builder.getOrCreate() as spark:
        struct_fields = []
        for t in schema.input_types():
            if t == DataType.datetime:
                struct_fields.append(
                    StructField("datetime", _parse_spark_datatype("timestamp"), True)
                )
            else:
                struct_fields.append(StructField(t.name, _parse_spark_datatype(t.name), True))
        spark_schema = StructType(struct_fields)
        sparkdf = spark.createDataFrame(pandas_df_with_all_types, schema=spark_schema)
        schema = _infer_schema(sparkdf)
        assert schema == Schema([ColSpec(x, x) for x in pandas_df_with_all_types.columns])


def test_spark_schema_inference_complex(spark):
    df = spark.createDataFrame(
        [(["arr"],)],
        schema=T.StructType([T.StructField("arr", T.ArrayType(T.StringType()))]),
    )
    schema = _infer_schema(df)
    assert schema == Schema([ColSpec(Array(DataType.string), "arr")])

    df = spark.createDataFrame(
        [({"str": "s", "str_nullable": None},)],
        schema=T.StructType(
            [
                T.StructField(
                    "obj",
                    T.StructType(
                        [
                            T.StructField("str", T.StringType(), nullable=False),
                            T.StructField("str_nullable", T.StringType(), nullable=True),
                        ]
                    ),
                )
            ]
        ),
    )
    schema = _infer_schema(df)
    assert schema == Schema(
        [
            ColSpec(
                Object(
                    [
                        Property("str", DataType.string, required=True),
                        Property("str_nullable", DataType.string, required=False),
                    ]
                ),
                "obj",
            )
        ]
    )

    df = spark.createDataFrame(
        [([{"str": "s"}],)],
        schema=T.StructType(
            [
                T.StructField(
                    "obj_arr",
                    T.ArrayType(
                        T.StructType([T.StructField("str", T.StringType(), nullable=False)])
                    ),
                )
            ]
        ),
    )

    schema = _infer_schema(df)
    assert schema == Schema(
        [
            ColSpec(
                Array(Object([Property("str", DataType.string, required=True)])),
                "obj_arr",
            )
        ]
    )


def test_spark_type_mapping(pandas_df_with_all_types):
    import pyspark
    from pyspark.sql.types import (
        BinaryType,
        BooleanType,
        DoubleType,
        FloatType,
        IntegerType,
        LongType,
        StringType,
        StructField,
        StructType,
        TimestampType,
    )

    assert isinstance(DataType.boolean.to_spark(), BooleanType)
    assert isinstance(DataType.integer.to_spark(), IntegerType)
    assert isinstance(DataType.long.to_spark(), LongType)
    assert isinstance(DataType.float.to_spark(), FloatType)
    assert isinstance(DataType.double.to_spark(), DoubleType)
    assert isinstance(DataType.string.to_spark(), StringType)
    assert isinstance(DataType.binary.to_spark(), BinaryType)
    assert isinstance(DataType.datetime.to_spark(), TimestampType)
    pandas_df_with_all_types = pandas_df_with_all_types.drop(
        columns=["boolean_ext", "integer_ext", "string_ext"]
    )
    schema = _infer_schema(pandas_df_with_all_types)
    expected_spark_schema = StructType(
        [StructField(t.name, t.to_spark(), False) for t in schema.input_types()]
    )
    actual_spark_schema = schema.as_spark_schema()
    assert expected_spark_schema.jsonValue() == actual_spark_schema.jsonValue()
    with pyspark.sql.SparkSession(pyspark.SparkContext.getOrCreate()) as spark_session:
        sparkdf = spark_session.createDataFrame(
            pandas_df_with_all_types, schema=actual_spark_schema
        )
        schema2 = _infer_schema(sparkdf)
        assert schema == schema2

    # test unnamed columns
    schema = Schema([ColSpec(col.type) for col in schema.inputs])
    expected_spark_schema = StructType(
        [StructField(str(i), t.to_spark(), False) for i, t in enumerate(schema.input_types())]
    )
    actual_spark_schema = schema.as_spark_schema()
    assert expected_spark_schema.jsonValue() == actual_spark_schema.jsonValue()

    # test single unnamed column is mapped to just a single spark type
    schema = Schema([ColSpec(DataType.integer)])
    spark_type = schema.as_spark_schema()
    assert isinstance(spark_type, IntegerType)


def test_enforce_tensor_spec_variable_signature():
    standard_array = np.array([[[1, 2, 3], [1, 2, 3]], [[1, 2, 3], [1, 2, 3]]], dtype=np.int32)
    ragged_array = np.array([[[1, 2, 3], [1, 2, 3]], [[1, 2, 3]]], dtype=object)
    inferred_schema = _infer_schema(ragged_array)
    inferred_spec = inferred_schema.inputs[0]
    assert inferred_spec.shape == (-1,)
    assert inferred_spec.type == np.dtype(object)

    result_array = _enforce_tensor_spec(standard_array, inferred_spec)
    np.testing.assert_array_equal(standard_array, result_array)
    result_array = _enforce_tensor_spec(ragged_array, inferred_spec)
    np.testing.assert_array_equal(ragged_array, result_array)

    manual_spec = TensorSpec(np.dtype(np.int32), (-1, -1, 3))
    result_array = _enforce_tensor_spec(standard_array, manual_spec)
    np.testing.assert_array_equal(standard_array, result_array)
    result_array = _enforce_tensor_spec(ragged_array, manual_spec)
    np.testing.assert_array_equal(ragged_array, result_array)

    standard_spec = _infer_schema(standard_array).inputs[0]
    assert standard_spec.shape == (-1, 2, 3)

    result_array = _enforce_tensor_spec(standard_array, standard_spec)
    np.testing.assert_array_equal(standard_array, result_array)
    with pytest.raises(
        MlflowException,
        match=re.escape(r"Shape of input (2,) does not match expected shape (-1, 2, 3)."),
    ):
        _enforce_tensor_spec(ragged_array, standard_spec)


def test_datatype_type_check():
    assert DataType.check_type(DataType.string, "string")

    integer_type = DataType.integer
    assert DataType.check_type(integer_type, 1)
    assert DataType.check_type(integer_type, np.int32(1))
    assert not DataType.check_type(integer_type, np.int64(1))
    # Note that isinstance(True, int) returns True
    assert not DataType.check_type(integer_type, True)

    long_type = DataType.long
    assert DataType.check_type(long_type, 1)
    assert DataType.check_type(long_type, np.int64(1))
    assert not DataType.check_type(long_type, np.int32(1))

    bool_type = DataType.boolean
    assert DataType.check_type(bool_type, True)
    assert DataType.check_type(bool_type, np.bool_(True))
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' tests/data/test_evaluation_dataset.py 2>/dev/null || true; grep -RIn 'EvaluationDataset(' tests/evaluate tests/data --include='*.py' | head -n 120"
```

退出码：`0`

输出：
```
tests/evaluate/test_evaluation.py:125:    ds = EvaluationDataset(**constructor_args)
tests/evaluate/test_evaluation.py:136:    ds = EvaluationDataset(**constructor_args)
tests/evaluate/test_evaluation.py:145:    ds = EvaluationDataset(**constructor_args)
tests/evaluate/test_evaluation.py:156:    ds = EvaluationDataset(**constructor_args)
tests/evaluate/test_evaluation.py:329:    ds = EvaluationDataset(**constructor_args)
tests/evaluate/test_evaluation.py:342:    ds = EvaluationDataset(**constructor_args)
tests/evaluate/test_evaluation.py:677:    d1 = EvaluationDataset(data=X, targets=y, name="a1")
tests/evaluate/test_evaluation.py:679:    d2 = EvaluationDataset(data=X, targets=y)
tests/evaluate/test_evaluation.py:685:    d1 = EvaluationDataset(data=X, targets=y, name="a1", path="/path/to/a1")
tests/evaluate/test_evaluation.py:734:    dataset = EvaluationDataset(data=df)
tests/evaluate/test_evaluation.py:743:    dataset2 = EvaluationDataset(data=df2)
tests/evaluate/test_evaluation.py:749:    eval_dataset = EvaluationDataset(data=data, targets="label")
tests/evaluate/test_evaluation.py:757:    eval_dataset2 = EvaluationDataset(data=data, targets="label", feature_names=["f3", "f2"])
tests/evaluate/test_evaluation.py:768:        eval_dataset1 = EvaluationDataset(data=input_data, targets=labels)
tests/evaluate/test_evaluation.py:773:    assert EvaluationDataset(
tests/evaluate/test_evaluation.py:778:        EvaluationDataset(data=[[1, 2], [3, 4, 5]], targets=labels)
tests/evaluate/test_evaluation.py:783:    eval_dataset2 = EvaluationDataset(data=[list(range(9))], targets=labels)
tests/evaluate/test_evaluation.py:786:    eval_dataset2 = EvaluationDataset(data=[list(range(10))], targets=labels)
tests/evaluate/test_evaluation.py:789:    eval_dataset2 = EvaluationDataset(data=[list(range(99))], targets=labels)
tests/evaluate/test_evaluation.py:792:    eval_dataset2 = EvaluationDataset(data=[list(range(100))], targets=labels)
tests/evaluate/test_evaluation.py:798:        EvaluationDataset(data=[[1, 2], [3, 4]], targets=[1, 2, 3])
tests/evaluate/test_evaluation.py:804:        dataset = EvaluationDataset(spark_df, targets="y")
```

## 原始行 48 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' tests/data/test_dataset.py; sed -n '1,120p' tests/resources/data/dataset.py; sed -n '1,190p' mlflow/data/numpy_dataset.py; sed -n '1,220p' mlflow/data/pandas_dataset.py"
```

退出码：`0`

输出：
```
import json

from mlflow.types.schema import Schema

from tests.resources.data.dataset import SampleDataset
from tests.resources.data.dataset_source import SampleDatasetSource


def test_conversion_to_json():
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)
    dataset = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")

    dataset_json = dataset.to_json()
    parsed_json = json.loads(dataset_json)
    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
    assert parsed_json["name"] == dataset.name
    assert parsed_json["digest"] == dataset.digest
    assert parsed_json["source"] == dataset.source.to_json()
    assert parsed_json["source_type"] == dataset.source._get_source_type()
    assert parsed_json["profile"] == json.dumps(dataset.profile)

    schema_json = json.dumps(json.loads(parsed_json["schema"])["mlflow_colspec"])
    assert Schema.from_json(schema_json) == dataset.schema


def test_digest_property_has_expected_value():
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)
    dataset = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")
    assert dataset.digest == dataset._compute_digest()


def test_expected_name_is_used():
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)

    dataset_without_name = SampleDataset(data_list=[1, 2, 3], source=source)
    assert dataset_without_name.name == "dataset"

    dataset_with_name = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")
    assert dataset_with_name.name == "testname"
import base64
import hashlib
import json
from typing import Any

import numpy as np
import pandas as pd

from mlflow.data.dataset import Dataset
from mlflow.types import Schema
from mlflow.types.utils import _infer_schema

from tests.resources.data.dataset_source import SampleDatasetSource


class SampleDataset(Dataset):
    def __init__(
        self,
        data_list: list[int],
        source: SampleDatasetSource,
        name: str | None = None,
        digest: str | None = None,
    ):
        self._data_list = data_list
        super().__init__(source=source, name=name, digest=digest)

    def _compute_digest(self) -> str:
        """
        Computes a digest for the dataset. Called if the user doesn't supply
        a digest when constructing the dataset.
        """
        hash_md5 = hashlib.md5(usedforsecurity=False)
        for hash_part in pd.util.hash_array(np.array(self._data_list)):
            hash_md5.update(hash_part)
        return base64.b64encode(hash_md5.digest()).decode("ascii")

    def to_dict(self) -> dict[str, str]:
        """
        Returns:
            A string dictionary containing the following fields: name,
            digest, source, source type, schema (optional), profile
            (optional).
        """
        config = super().to_dict()
        config.update(
            {
                "schema": json.dumps({"mlflow_colspec": self.schema.to_dict()}),
                "profile": json.dumps(self.profile),
            }
        )
        return config

    @property
    def data_list(self) -> list[int]:
        return self._data_list

    @property
    def source(self) -> SampleDatasetSource:
        return self._source

    @property
    def profile(self) -> Any | None:
        return {
            "length": len(self._data_list),
        }

    @property
    def schema(self) -> Schema:
        return _infer_schema(np.array(self._data_list))
import json
import logging
from functools import cached_property
from typing import Any

import numpy as np

from mlflow.data.dataset import Dataset
from mlflow.data.dataset_source import DatasetSource

from mlflow.data.evaluation_dataset import EvaluationDataset
from mlflow.data.pyfunc_dataset_mixin import PyFuncConvertibleDatasetMixin, PyFuncInputsOutputs
from mlflow.data.schema import TensorDatasetSchema


_logger = logging.getLogger(__name__)


class NumpyDataset(Dataset, PyFuncConvertibleDatasetMixin):
    """
    Represents a NumPy dataset for use with MLflow Tracking.
    """

    def __init__(
        self,
        features: np.ndarray | dict[str, np.ndarray],
        source: DatasetSource,
        targets: np.ndarray | dict[str, np.ndarray] = None,
        name: str | None = None,
        digest: str | None = None,
    ):
        """
        Args:
            features: A numpy array or dictionary of numpy arrays containing dataset features.
            source: The source of the numpy dataset.
            targets: A numpy array or dictionary of numpy arrays containing dataset targets.
                Optional.
            name: The name of the dataset. E.g. "wiki_train". If unspecified, a name is
                automatically generated.
            digest: The digest (hash, fingerprint) of the dataset. If unspecified, a digest
                is automatically computed.
        """
        self._features = features
        self._targets = targets
        super().__init__(source=source, name=name, digest=digest)

    def _compute_digest(self) -> str:
        """
        Computes a digest for the dataset. Called if the user doesn't supply
        a digest when constructing the dataset.
        """
        return compute_numpy_digest(self._features, self._targets)

    def to_dict(self) -> dict[str, str]:
        """Create config dictionary for the dataset.

        Returns a string dictionary containing the following fields: name, digest, source, source
        type, schema, and profile.
        """
        schema = json.dumps(self.schema.to_dict()) if self.schema else None
        config = super().to_dict()
        config.update(
            {
                "schema": schema,
                "profile": json.dumps(self.profile),
            }
        )
        return config

    @property
    def source(self) -> DatasetSource:
        """
        The source of the dataset.
        """
        return self._source

    @property
    def features(self) -> np.ndarray | dict[str, np.ndarray]:
        """
        The features of the dataset.
        """
        return self._features

    @property
    def targets(self) -> np.ndarray | dict[str, np.ndarray] | None:
        """
        The targets of the dataset. May be ``None`` if no targets are available.
        """
        return self._targets

    @property
    def profile(self) -> Any | None:
        """
        A profile of the dataset. May be ``None`` if a profile cannot be computed.
        """

        def get_profile_attribute(numpy_data, attr_name):
            if isinstance(numpy_data, dict):
                return {key: getattr(array, attr_name) for key, array in numpy_data.items()}
            else:
                return getattr(numpy_data, attr_name)

        profile = {
            "features_shape": get_profile_attribute(self._features, "shape"),
            "features_size": get_profile_attribute(self._features, "size"),
            "features_nbytes": get_profile_attribute(self._features, "nbytes"),
        }
        if self._targets is not None:
            profile.update(
                {
                    "targets_shape": get_profile_attribute(self._targets, "shape"),
                    "targets_size": get_profile_attribute(self._targets, "size"),
                    "targets_nbytes": get_profile_attribute(self._targets, "nbytes"),
                }
            )

        return profile

    @cached_property
    def schema(self) -> TensorDatasetSchema | None:
        """
        MLflow TensorSpec schema representing the dataset features and targets (optional).
        """
        try:
            features_schema = _infer_schema(self._features)
            targets_schema = None
            if self._targets is not None:
                targets_schema = _infer_schema(self._targets)
            return TensorDatasetSchema(features=features_schema, targets=targets_schema)
        except Exception as e:
            _logger.warning("Failed to infer schema for NumPy dataset. Exception: %s", e)
            return None

    def to_pyfunc(self) -> PyFuncInputsOutputs:
        """
        Converts the dataset to a collection of pyfunc inputs and outputs for model
        evaluation. Required for use with mlflow.evaluate().
        """
        return PyFuncInputsOutputs(self._features, self._targets)

    def to_evaluation_dataset(self, path=None, feature_names=None) -> EvaluationDataset:
        """
        Converts the dataset to an EvaluationDataset for model evaluation. Required
        for use with mlflow.sklearn.evaluate().
        """
        return EvaluationDataset(
            data=self._features,
            targets=self._targets,
            path=path,
            feature_names=feature_names,
            name=self.name,
            digest=self.digest,
        )


def from_numpy(
    features: np.ndarray | dict[str, np.ndarray],
    source: str | DatasetSource = None,
    targets: np.ndarray | dict[str, np.ndarray] = None,
    name: str | None = None,
    digest: str | None = None,
) -> NumpyDataset:
    """
    Constructs a :py:class:`NumpyDataset <mlflow.data.numpy_dataset.NumpyDataset>` object from
    NumPy features, optional targets, and source. If the source is path like, then this will
    construct a DatasetSource object from the source path. Otherwise, the source is assumed to
    be a DatasetSource object.

    Args:
        features: NumPy features, represented as an np.ndarray or dictionary of named np.ndarrays.
        source: The source from which the numpy data was derived, e.g. a filesystem path, an S3 URI,
            an HTTPS URL, a delta table name with version, or spark table etc. ``source`` may be
            specified as a URI, a path-like string, or an instance of
            :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`. If unspecified,
            the source is assumed to be the code location (e.g. notebook cell, script, etc.) where
            :py:func:`from_numpy <mlflow.data.from_numpy>` is being called.
        targets: Optional NumPy targets, represented as an np.ndarray or dictionary of named
            np.ndarrays.
        name: The name of the dataset. If unspecified, a name is generated.
        digest: The dataset digest (hash). If unspecified, a digest is computed automatically.

    .. code-block:: python
        :test:
        :caption: Basic Example

        import mlflow
        import numpy as np

        x = np.random.uniform(size=[2, 5, 4])
        y = np.random.randint(2, size=[2])
import json
import logging
from functools import cached_property
from typing import Any

import pandas as pd

from mlflow.data.dataset import Dataset
from mlflow.data.dataset_source import DatasetSource
from mlflow.data.digest_utils import compute_pandas_digest
from mlflow.data.evaluation_dataset import EvaluationDataset
from mlflow.data.pyfunc_dataset_mixin import PyFuncConvertibleDatasetMixin, PyFuncInputsOutputs
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.types import Schema


_logger = logging.getLogger(__name__)


class PandasDataset(Dataset, PyFuncConvertibleDatasetMixin):
    """
    Represents a Pandas DataFrame for use with MLflow Tracking.
    """

    def __init__(
        self,
        df: pd.DataFrame,
        source: DatasetSource,
        targets: str | None = None,
        name: str | None = None,
        digest: str | None = None,
        predictions: str | None = None,
    ):
        """
        Args:
            df: A pandas DataFrame.
            source: The source of the pandas DataFrame.
            targets: The name of the target column. Optional.
            name: The name of the dataset. E.g. "wiki_train". If unspecified, a name is
                automatically generated.
            digest: The digest (hash, fingerprint) of the dataset. If unspecified, a digest
                is automatically computed.
            predictions: Optional. The name of the column containing model predictions,
                if the dataset contains model predictions. If specified, this column
                must be present in the dataframe (``df``).
        """
        if targets is not None and targets not in df.columns:
            raise MlflowException(
                f"The specified pandas DataFrame does not contain the specified targets column"
                f" '{targets}'.",
                INVALID_PARAMETER_VALUE,
            )
        if predictions is not None and predictions not in df.columns:
            raise MlflowException(
                f"The specified pandas DataFrame does not contain the specified predictions column"
                f" '{predictions}'.",
                INVALID_PARAMETER_VALUE,
            )
        self._df = df
        self._targets = targets
        self._predictions = predictions
        super().__init__(source=source, name=name, digest=digest)

    def _compute_digest(self) -> str:
        """
        Computes a digest for the dataset. Called if the user doesn't supply
        a digest when constructing the dataset.
        """
        return compute_pandas_digest(self._df)

    def to_dict(self) -> dict[str, str]:
        """Create config dictionary for the dataset.

        Returns a string dictionary containing the following fields: name, digest, source, source
        type, schema, and profile.
        """
        schema = json.dumps({"mlflow_colspec": self.schema.to_dict()}) if self.schema else None
        config = super().to_dict()
        config.update(
            {
                "schema": schema,
                "profile": json.dumps(self.profile),
            }
        )
        return config

    @property
    def df(self) -> pd.DataFrame:
        """
        The underlying pandas DataFrame.
        """
        return self._df

    @property
    def source(self) -> DatasetSource:
        """
        The source of the dataset.
        """
        return self._source

    @property
    def targets(self) -> str | None:
        """
        The name of the target column. May be ``None`` if no target column is available.
        """
        return self._targets

    @property
    def predictions(self) -> str | None:
        """
        The name of the predictions column. May be ``None`` if no predictions column is available.
        """
        return self._predictions

    @property
    def profile(self) -> Any | None:
        """
        A profile of the dataset. May be ``None`` if a profile cannot be computed.
        """
        return {
            "num_rows": len(self._df),
            "num_elements": int(self._df.size),
        }

    @cached_property
    def schema(self) -> Schema | None:
        """
        An instance of :py:class:`mlflow.types.Schema` representing the tabular dataset. May be
        ``None`` if the schema cannot be inferred from the dataset.
        """
        try:
            return _infer_schema(self._df)
        except Exception as e:
            _logger.debug("Failed to infer schema for Pandas dataset. Exception: %s", e)
            return None

    def to_pyfunc(self) -> PyFuncInputsOutputs:
        """
        Converts the dataset to a collection of pyfunc inputs and outputs for model
        evaluation. Required for use with mlflow.evaluate().
        """
        if self._targets:
            inputs = self._df.drop(columns=[self._targets])
            outputs = self._df[self._targets]
            return PyFuncInputsOutputs(inputs, outputs)
        else:
            return PyFuncInputsOutputs(self._df)

    def to_evaluation_dataset(self, path=None, feature_names=None) -> EvaluationDataset:
        """
        Converts the dataset to an EvaluationDataset for model evaluation. Required
        for use with mlflow.evaluate().
        """
        return EvaluationDataset(
            data=self._df,
            targets=self._targets,
            path=path,
            feature_names=feature_names,
            predictions=self._predictions,
            name=self.name,
            digest=self.digest,
        )


def from_pandas(
    df: pd.DataFrame,
    source: str | DatasetSource = None,
    targets: str | None = None,
    name: str | None = None,
    digest: str | None = None,
    predictions: str | None = None,
) -> PandasDataset:
    """
    Constructs a :py:class:`PandasDataset <mlflow.data.pandas_dataset.PandasDataset>` instance from
    a Pandas DataFrame, optional targets, optional predictions, and source.

    Args:
        df: A Pandas DataFrame.
        source: The source from which the DataFrame was derived, e.g. a filesystem
            path, an S3 URI, an HTTPS URL, a delta table name with version, or
            spark table etc. ``source`` may be specified as a URI, a path-like string,
            or an instance of
            :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`.
            If unspecified, the source is assumed to be the code location
            (e.g. notebook cell, script, etc.) where
            :py:func:`from_pandas <mlflow.data.from_pandas>` is being called.
        targets: An optional target column name for supervised training. This column
            must be present in the dataframe (``df``).
        name: The name of the dataset. If unspecified, a name is generated.
        digest: The dataset digest (hash). If unspecified, a digest is computed
            automatically.
        predictions: An optional predictions column name for model evaluation. This column
            must be present in the dataframe (``df``).

    .. code-block:: python
        :test:
        :caption: Example

        import mlflow
        import pandas as pd

        x = pd.DataFrame(
            [["tom", 10, 1, 1], ["nick", 15, 0, 1], ["july", 14, 1, 1]],
            columns=["Name", "Age", "Label", "ModelOutput"],
        )
        dataset = mlflow.data.from_pandas(x, targets="Label", predictions="ModelOutput")
    """

    from mlflow.data.code_dataset_source import CodeDatasetSource
    from mlflow.data.dataset_source_registry import resolve_dataset_source
    from mlflow.tracking.context import registry

    if source is not None:
        if isinstance(source, DatasetSource):
            resolved_source = source
        else:
            resolved_source = resolve_dataset_source(
                source,
            )
```

## 原始行 50 · command_execution

命令：
```
/bin/bash -lc "grep -RIn '"'^def _'"' mlflow/types/utils.py; grep -RIn '"'^    def '"' mlflow/data/evaluation_dataset.py mlflow/data/dataset.py mlflow/data/schema.py mlflow/data/dataset_source.py; grep -RIn 'from mlflow.types.utils import' mlflow tests --include='*.py' | head -n 200"
```

退出码：`0`

输出：
```
98:def _infer_colspec_type(data: Any) -> DataType | Array | Object | AnyType:
123:def _infer_datatype(data: Any) -> DataType | Array | Object | AnyType | None:
171:def _infer_array_datatype(data: list[Any] | np.ndarray) -> Array | None:
234:def _infer_scalar_datatype(data) -> DataType:
467:def _infer_numpy_dtype(dtype) -> DataType:
507:def _is_none_or_nan(x):
514:def _infer_required(col) -> bool:
520:def _infer_pandas_column(col: pd.Series) -> DataType:
546:def _infer_spark_type(x, data=None, col_name=None) -> DataType:
629:def _is_spark_df(x) -> bool:
646:def _validate_input_dictionary_contains_only_strings_and_lists_of_strings(data) -> None:
675:def _is_list_str(type_hint: Any) -> bool:
682:def _is_list_dict_str(type_hint: Any) -> bool:
691:def _get_array_depth(l: Any) -> int:
699:def _infer_type_and_shape(value):
731:def _infer_param_schema(parameters: dict[str, Any]):
mlflow/data/evaluation_dataset.py:426:    def feature_names(self):
mlflow/data/evaluation_dataset.py:437:    def labels_data(self):
mlflow/data/evaluation_dataset.py:444:    def has_targets(self):
mlflow/data/evaluation_dataset.py:451:    def targets_name(self):
mlflow/data/evaluation_dataset.py:458:    def predictions_data(self):
mlflow/data/evaluation_dataset.py:465:    def has_predictions(self):
mlflow/data/evaluation_dataset.py:472:    def predictions_name(self):
mlflow/data/evaluation_dataset.py:479:    def name(self):
mlflow/data/evaluation_dataset.py:487:    def path(self):
mlflow/data/evaluation_dataset.py:494:    def hash(self):
mlflow/data/evaluation_dataset.py:501:    def _metadata(self):
mlflow/data/evaluation_dataset.py:514:    def digest(self):
mlflow/data/evaluation_dataset.py:520:    def _log_dataset_tag(self, client, run_id, model_uuid):
mlflow/data/evaluation_dataset.py:546:    def __hash__(self):
mlflow/data/evaluation_dataset.py:549:    def __eq__(self, other):
mlflow/data/dataset.py:28:    def _compute_digest(self) -> str:
mlflow/data/dataset.py:65:    def _get_source_type(self) -> str:
mlflow/data/dataset.py:88:    def source(self) -> DatasetSource:
mlflow/data/dataset.py:99:    def profile(self) -> Any | None:
mlflow/data/dataset.py:107:    def schema(self) -> Any | None:
mlflow/data/dataset.py:113:    def _to_mlflow_entity(self) -> DatasetEntity:
mlflow/data/schema.py:68:    def __eq__(self, other) -> bool:
mlflow/data/schema.py:75:    def __repr__(self) -> str:
mlflow/data/dataset_source.py:14:    def _get_source_type() -> str:
mlflow/data/dataset_source.py:23:    def load(self) -> Any:
mlflow/data/dataset_source.py:37:    def _can_resolve(raw_source: Any) -> bool:
mlflow/data/dataset_source.py:53:    def _resolve(cls, raw_source: Any) -> "DatasetSource":
mlflow/data/dataset_source.py:67:    def to_dict(self) -> dict[str, Any]:
mlflow/data/dataset_source.py:88:    def from_dict(cls, source_dict: dict[Any, Any]) -> "DatasetSource":
mlflow/data/dataset_source.py:100:    def from_json(cls, source_json: str) -> "DatasetSource":
mlflow/pyfunc/model.py:58:from mlflow.types.utils import _is_list_dict_str, _is_list_str
mlflow/transformers/__init__.py:98:from mlflow.types.utils import _validate_input_dictionary_contains_only_strings_and_lists_of_strings
mlflow/models/utils.py:32:from mlflow.types.utils import TensorsNotSupportedException, _infer_param_schema, _is_none_or_nan
mlflow/models/signature.py:36:from mlflow.types.utils import InvalidDataForSignatureInferenceError, _infer_param_schema
tests/pyfunc/test_spark.py:59:from mlflow.types.utils import _infer_schema
tests/tensorflow/test_tensorflow2_autolog.py:27:from mlflow.types.utils import _infer_schema
tests/lightgbm/test_lightgbm_autolog.py:21:from mlflow.types.utils import _infer_schema
tests/utils/test_proto_json_utils.py:18:from mlflow.types.utils import _infer_schema
tests/types/test_schema.py:32:from mlflow.types.utils import (
tests/types/test_type_hints.py:24:from mlflow.types.utils import _infer_schema
tests/xgboost/test_xgboost_autolog.py:21:from mlflow.types.utils import _infer_schema
tests/sklearn/test_sklearn_autolog.py:39:from mlflow.types.utils import _infer_schema
tests/models/test_signature.py:25:from mlflow.types.utils import InvalidDataForSignatureInferenceError
tests/models/test_model_input_examples.py:24:from mlflow.types.utils import TensorsNotSupportedException
tests/data/test_huggingface_dataset_and_source.py:19:from mlflow.types.utils import _infer_schema
tests/data/test_pandas_dataset.py:16:from mlflow.types.utils import _infer_schema
tests/data/test_tensorflow_dataset.py:14:from mlflow.types.utils import _infer_schema
tests/data/test_spark_dataset.py:16:from mlflow.types.utils import _infer_schema
tests/resources/mlflow-test-plugin/mlflow_test_plugin/dummy_dataset.py:9:from mlflow.types.utils import _infer_schema
tests/resources/data/dataset.py:11:from mlflow.types.utils import _infer_schema
```

## 原始行 53 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^def test_'"' tests/types/test_schema.py | sed -n '1,140p'; grep -n '"'^def test_'"' tests/data/test_evaluation_dataset.py 2>/dev/null || true; find tests -iname '*evaluation_dataset*' -type f"
```

退出码：`0`

输出：
```
48:def test_col_spec():
67:def test_tensor_spec():
133:def test_schema_creation():
170:def test_schema_creation_errors():
178:def test_get_schema_type(dict_of_ndarrays):
187:def test_schema_inference_on_dataframe(pandas_df_with_all_types):
206:def test_schema_inference_on_pandas_series():
276:def test_get_tensor_shape(dict_of_ndarrays):
306:def test_get_sparse_matrix_data_type_and_shape(dict_of_sparse_matrix):
313:def test_schema_inference_on_dictionary(dict_of_ndarrays):
347:def test_schema_inference_on_dictionary_of_strings(data, schema):
351:def test_schema_inference_on_list_with_errors():
357:def test_schema_inference_validating_dictionary_keys():
363:def test_schema_inference_on_lists_with_errors():
371:def test_schema_inference_on_list_of_dicts():
384:def test_dict_input_valid_checks_on_keys():
430:def test_dict_input_valid_checks_on_values():
465:def test_schema_inference_on_basic_numpy(pandas_df_with_all_types):
473:def test_all_numpy_dtypes():
591:def test_spark_schema_inference(pandas_df_with_all_types):
615:def test_spark_schema_inference_complex(spark):
679:def test_spark_type_mapping(pandas_df_with_all_types):
732:def test_enforce_tensor_spec_variable_signature():
763:def test_datatype_type_check():
799:def test_param_schema_find_duplicates():
835:def test_param_spec_to_and_from_dict():
970:def test_param_spec_from_dict_backward_compatibility():
983:def test_infer_param_schema():
1069:def test_param_schema_for_dicts():
1115:def test_infer_param_schema_with_errors():
1122:def test_object_construction_with_errors():
1149:def test_property_to_and_from_dict(data_type):
1177:def test_property_from_dict_with_errors():
1246:def test_object_to_and_from_dict():
1260:def test_object_from_dict_with_errors():
1289:def test_array_to_and_from_dict(data_type):
1306:def test_array_from_dict_with_errors():
1334:def test_nested_array_object_to_and_from_dict():
1383:def test_merge_object_example():
1410:def test_merge_property_example():
1440:def test_infer_colspec_type():
1505:def test_infer_schema_on_objects_and_arrays_to_and_from_dict():
1620:def test_schema_inference_on_datatypes(data, data_type):
1639:def test_schema_inference_on_dictionaries(data, data_type):
1664:def test_schema_inference_on_lists(data, data_type):
1701:def test_schema_inference_with_empty_lists():
1764:def test_repr_of_objects():
1783:def test_convert_dataclass_to_schema_for_rag():
1832:def test_convert_dataclass_to_schema_complex():
1874:def test_convert_dataclass_to_schema_invalid():
2065:def test_infer_schema_with_anytype(data, expected_schema):
tests/genai/datasets/test_databricks_evaluation_dataset_source.py
tests/genai/datasets/test_evaluation_dataset.py
tests/entities/test_evaluation_dataset.py
```

## 原始行 56 · command_execution

命令：
```
/bin/bash -lc "grep -RInE 'with pytest.raises.*Dataset|source=.*None|digest=\"\"|name=\"\"|Dataset.__init__|TensorDatasetSchema' tests/data --include='*.py' | head -n 300"
```

退出码：`0`

输出：
```
tests/data/test_dataset_registry.py:78:    with pytest.raises(MlflowException, match="must have a return type annotation.*Dataset"):
tests/data/test_dataset_registry.py:88:    with pytest.raises(MlflowException, match="must have a return type annotation.*Dataset"):
tests/data/test_tensorflow_dataset.py:11:from mlflow.data.schema import TensorDatasetSchema
tests/data/test_tensorflow_dataset.py:96:    assert TensorDatasetSchema.from_dict(parsed_schema) == dataset.schema
tests/data/test_tensorflow_dataset.py:161:    assert TensorDatasetSchema.from_dict(parsed_schema) == dataset.schema
tests/data/test_tensorflow_dataset.py:335:    assert mlflow_ds.schema == TensorDatasetSchema(
tests/data/test_tensorflow_dataset.py:352:    assert mlflow_ds.schema == TensorDatasetSchema(
tests/data/test_tensorflow_dataset.py:369:    assert mlflow_ds.schema == TensorDatasetSchema(features=_infer_schema(tf_tensor.numpy()))
tests/data/test_tensorflow_dataset.py:384:    assert mlflow_ds.schema == TensorDatasetSchema(
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,130p' mlflow/data/meta_dataset.py; sed -n '1,130p' mlflow/data/dataset_registry.py; sed -n '1,130p' tests/resources/data/dataset_source.py"
```

退出码：`0`

输出：
```
import hashlib
import json
from typing import Any

from mlflow.data.dataset import Dataset
from mlflow.data.dataset_source import DatasetSource
from mlflow.types import Schema


class MetaDataset(Dataset):
    """Dataset that only contains metadata.

    This class is used to represent a dataset that only contains metadata, which is useful when
    users only want to log metadata to MLflow without logging the actual data. For example, users
    build a custom dataset from a text file publicly hosted in the Internet, and they want to log
    the text file's URL to MLflow for future tracking instead of the dataset itself.

    Args:
        source: dataset source of type `DatasetSource`, indicates where the data is from.
        name: name of the dataset. If not specified, a name is automatically generated.
        digest: digest (hash, fingerprint) of the dataset. If not specified, a digest is
            automatically computed.
        schame: schema of the dataset.

    .. code-block:: python
        :caption: Create a MetaDataset

        import mlflow

        mlflow.set_experiment("/test-mlflow-meta-dataset")

        source = mlflow.data.http_dataset_source.HTTPDatasetSource(
            url="https://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz"
        )
        ds = mlflow.data.meta_dataset.MetaDataset(source)

        with mlflow.start_run() as run:
            mlflow.log_input(ds)

    .. code-block:: python
        :caption: Create a MetaDataset with schema

        import mlflow

        mlflow.set_experiment("/test-mlflow-meta-dataset")

        source = mlflow.data.http_dataset_source.HTTPDatasetSource(
            url="https://ai.stanford.edu/~amaas/data/sentiment/aclImdb_v1.tar.gz"
        )
        schema = Schema(
            [
                ColSpec(type=mlflow.types.DataType.string, name="text"),
                ColSpec(type=mlflow.types.DataType.integer, name="label"),
            ]
        )
        ds = mlflow.data.meta_dataset.MetaDataset(source, schema=schema)

        with mlflow.start_run() as run:
            mlflow.log_input(ds)
    """

    def __init__(
        self,
        source: DatasetSource,
        name: str | None = None,
        digest: str | None = None,
        schema: Schema | None = None,
    ):
        # Set `self._schema` before calling the superclass constructor because
        # `self._compute_digest` depends on `self._schema`.
        self._schema = schema
        super().__init__(source=source, name=name, digest=digest)

    def _compute_digest(self) -> str:
        """Computes a digest for the dataset.

        The digest computation of `MetaDataset` is based on the dataset's name, source, source type,
        and schema instead of the actual data. Basically we compute the sha256 hash of the config
        dict.
        """
        config = {
            "name": self.name,
            "source": self.source.to_json(),
            "source_type": self.source._get_source_type(),
            "schema": self.schema.to_dict() if self.schema else "",
        }
        return hashlib.sha256(json.dumps(config).encode("utf-8")).hexdigest()[:8]

    @property
    def schema(self) -> Any | None:
        """Returns the schema of the dataset."""
        return self._schema

    def to_dict(self) -> dict[str, str]:
        """Create config dictionary for the MetaDataset.

        Returns a string dictionary containing the following fields: name, digest, source, source
        type, schema, and profile.
        """
        config = super().to_dict()
        if self.schema:
            schema = json.dumps({"mlflow_colspec": self.schema.to_dict()}) if self.schema else None
            config["schema"] = schema
        return config
import inspect
import warnings
from contextlib import suppress
from typing import Callable

import mlflow.data
from mlflow.data.dataset import Dataset
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.utils.plugins import get_entry_points


class DatasetRegistry:
    def __init__(self):
        self.constructors = {}

    def register_constructor(
        self,
        constructor_fn: Callable[[str | None, str | None], Dataset],
        constructor_name: str | None = None,
    ) -> str:
        """Registers a dataset constructor.

        Args:
            constructor_fn: A function that accepts at least the following
                inputs and returns an instance of a subclass of
                :py:class:`mlflow.data.dataset.Dataset`:

                - name: Optional. A string dataset name
                - digest: Optional. A string dataset digest.

            constructor_name: The name of the constructor, e.g.
                "from_spark". The name must begin with the
                string "from_" or "load_". If unspecified, the `__name__`
                attribute of the `constructor_fn` is used instead and must
                begin with the string "from_" or "load_".

        Returns:
            The name of the registered constructor, e.g. "from_pandas" or "load_delta".
        """
        if constructor_name is None:
            constructor_name = constructor_fn.__name__
        DatasetRegistry._validate_constructor(constructor_fn, constructor_name)
        self.constructors[constructor_name] = constructor_fn
        return constructor_name

    def register_entrypoints(self):
        """
        Registers dataset sources defined as Python entrypoints. For reference, see
        https://mlflow.org/docs/latest/plugins.html#defining-a-plugin.
        """
        for entrypoint in get_entry_points("mlflow.dataset_constructor"):
            try:
                self.register_constructor(
                    constructor_fn=entrypoint.load(), constructor_name=entrypoint.name
                )
            except Exception as exc:
                warnings.warn(
                    f"Failure attempting to register dataset constructor"
                    f' "{entrypoint.name}": {exc}.',
                    stacklevel=2,
                )

    @staticmethod
    def _validate_constructor(
        constructor_fn: Callable[[str | None, str | None], Dataset],
        constructor_name: str,
    ):
        if not constructor_name.startswith("load_") and not constructor_name.startswith("from_"):
            raise MlflowException(
                f"Invalid dataset constructor name: {constructor_name}."
                f" Constructor name must start with 'load_' or 'from_'.",
                INVALID_PARAMETER_VALUE,
            )

        signature = inspect.signature(constructor_fn)
        parameters = signature.parameters
        for expected_kwarg in ["name", "digest"]:
            if expected_kwarg not in parameters or parameters[expected_kwarg].kind not in [
                inspect.Parameter.KEYWORD_ONLY,
                inspect.Parameter.POSITIONAL_OR_KEYWORD,
            ]:
                raise MlflowException(
                    f"Invalid dataset constructor function: {constructor_fn.__name__}. Function"
                    f" must define an optional parameter named '{expected_kwarg}'.",
                    INVALID_PARAMETER_VALUE,
                )

        if not issubclass(signature.return_annotation, Dataset):
            raise MlflowException(
                f"Invalid dataset constructor function: {constructor_fn.__name__}. Function must"
                f" have a return type annotation that is a subclass of"
                f" :py:class:`mlflow.data.dataset.Dataset`.",
                INVALID_PARAMETER_VALUE,
            )


def register_constructor(
    constructor_fn: Callable[[str | None, str | None], Dataset],
    constructor_name: str | None = None,
) -> str:
    """Registers a dataset constructor.

    Args:
        constructor_fn: A function that accepts at least the following
            inputs and returns an instance of a subclass of
            :py:class:`mlflow.data.dataset.Dataset`:

            - name: Optional. A string dataset name
            - digest: Optional. A string dataset digest.

        constructor_name: The name of the constructor, e.g.
            "from_spark". The name must begin with the
            string "from_" or "load_". If unspecified, the `__name__`
            attribute of the `constructor_fn` is used instead and must
            begin with the string "from_" or "load_".

    Returns:
        The name of the registered constructor, e.g. "from_pandas" or "load_delta".

    """
    registered_constructor_name = _dataset_registry.register_constructor(
        constructor_fn=constructor_fn, constructor_name=constructor_name
    )
    setattr(mlflow.data, registered_constructor_name, constructor_fn)
    mlflow.data.__all__.append(registered_constructor_name)
    return registered_constructor_name


def get_registered_constructors() -> dict[str, Callable[[str | None, str | None], Dataset]]:
from typing import Any
from urllib.parse import urlparse

from mlflow.artifacts import download_artifacts
from mlflow.data.dataset_source import DatasetSource
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE


class SampleDatasetSource(DatasetSource):
    def __init__(self, uri):
        self._uri = uri

    @property
    def uri(self):
        return self._uri

    @staticmethod
    def _get_source_type() -> str:
        return "test"

    def load(self) -> str:
        # Ignore the "test" URI scheme and download the local path
        parsed_uri = urlparse(self._uri)
        return download_artifacts(parsed_uri.path)

    @staticmethod
    def _can_resolve(raw_source: Any) -> bool:
        if not isinstance(raw_source, str):
            return False

        try:
            parsed_source = urlparse(raw_source)
            return parsed_source.scheme == "test"
        except Exception:
            return False

    @classmethod
    def _resolve(cls, raw_source: Any) -> DatasetSource:
        return cls(raw_source)

    def to_dict(self) -> dict[Any, Any]:
        return {"uri": self.uri}

    @classmethod
    def from_dict(cls, source_dict: dict[Any, Any]) -> DatasetSource:
        uri = source_dict.get("uri")
        if uri is None:
            raise MlflowException(
                'Failed to parse dummy dataset source. Missing expected key: "uri"',
                INVALID_PARAMETER_VALUE,
            )

        return cls(uri=uri)
```

## 原始行 60 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' tests/data/test_tensorflow_dataset.py; grep -RIn 'mlflow_tensorspec' mlflow tests/data --include='*.py' | head -n 100"
```

退出码：`0`

输出：
```
import json

import numpy as np
import pytest
import tensorflow as tf

import mlflow.data
from mlflow.data.code_dataset_source import CodeDatasetSource
from mlflow.data.evaluation_dataset import EvaluationDataset
from mlflow.data.pyfunc_dataset_mixin import PyFuncInputsOutputs
from mlflow.data.schema import TensorDatasetSchema
from mlflow.data.tensorflow_dataset import TensorFlowDataset
from mlflow.exceptions import MlflowException
from mlflow.types.utils import _infer_schema

from tests.resources.data.dataset_source import SampleDatasetSource


def test_dataset_construction_validates_features_and_targets():
    x = np.random.sample((100, 2))
    tf_dataset = tf.data.Dataset.from_tensors(x)
    tf_tensor = tf.convert_to_tensor(x)

    with pytest.raises(
        MlflowException,
        match="features' must be an instance of tf.data.Dataset or a TensorFlow Tensor.*NoneType",
    ):
        mlflow.data.from_tensorflow(features=None)
    with pytest.raises(
        MlflowException,
        match="features' must be an instance of tf.data.Dataset or a TensorFlow Tensor.*str",
    ):
        mlflow.data.from_tensorflow(features="foo")
    with pytest.raises(
        MlflowException,
        match="features' must be an instance of tf.data.Dataset or a TensorFlow Tensor.*str",
    ):
        mlflow.data.from_tensorflow(features="foo", targets=tf_tensor)

    mlflow.data.from_tensorflow(features=tf_tensor, targets=tf_tensor)
    mlflow.data.from_tensorflow(features=tf_tensor, targets=None)
    with pytest.raises(
        MlflowException,
        match=(
            "If 'features' is a TensorFlow Tensor, then 'targets' must also be a TensorFlow"
            " Tensor.*str"
        ),
    ):
        mlflow.data.from_tensorflow(features=tf_tensor, targets="foo")
    with pytest.raises(
        MlflowException,
        match=(
            "If 'features' is a TensorFlow Tensor, then 'targets' must also be a TensorFlow"
            " Tensor.*Dataset"
        ),
    ):
        mlflow.data.from_tensorflow(features=tf_tensor, targets=tf_dataset)

    mlflow.data.from_tensorflow(features=tf_dataset, targets=tf_dataset)
    mlflow.data.from_tensorflow(features=tf_dataset, targets=None)
    with pytest.raises(
        MlflowException,
        match=(
            "If 'features' is an instance of tf.data.Dataset, then 'targets' must also be an"
            " instance of tf.data.Dataset.*str"
        ),
    ):
        mlflow.data.from_tensorflow(features=tf_dataset, targets="foo")
    with pytest.raises(
        MlflowException,
        match=(
            "If 'features' is an instance of tf.data.Dataset, then 'targets' must also be an"
            " instance of tf.data.Dataset.*Tensor"
        ),
    ):
        mlflow.data.from_tensorflow(features=tf_dataset, targets=tf_tensor)


def test_conversion_to_json():
    source_uri = "test:/my/test/uri"
    x = np.random.sample((100, 2))
    tf_dataset = tf.data.Dataset.from_tensors(x)
    source = SampleDatasetSource._resolve(source_uri)
    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")

    dataset_json = dataset.to_json()
    parsed_json = json.loads(dataset_json)
    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
    assert parsed_json["name"] == dataset.name
    assert parsed_json["digest"] == dataset.digest
    assert parsed_json["source"] == dataset.source.to_json()
    assert parsed_json["source_type"] == dataset.source._get_source_type()
    assert parsed_json["profile"] == json.dumps(dataset.profile)

    parsed_schema = json.loads(parsed_json["schema"])
    assert TensorDatasetSchema.from_dict(parsed_schema) == dataset.schema


@pytest.mark.parametrize(
    ("features", "targets"),
    [
        (
            tf.data.Dataset.from_tensors(
                {"a": np.random.sample((100, 2)), "b": np.random.sample((100, 4))}
            ),
            tf.data.Dataset.from_tensors(
                {"c": np.random.sample((100, 1)), "d": np.random.sample((100,))}
            ),
        ),
        (
            tf.data.Dataset.from_tensors(
                (
                    np.random.sample((100, 2)),
                    np.random.sample((100, 4)),
                )
            ),
            tf.data.Dataset.from_tensors(
                (
                    np.random.sample((100, 1)),
                    np.random.sample((100,)),
                )
            ),
        ),
        (
            tf.data.Dataset.from_tensors(
                (
                    np.random.sample((100, 2)),
                    np.random.sample((100, 4)),
                )
            ),
            tf.data.Dataset.from_tensors(
                {"c": np.random.sample((100, 1)), "d": np.random.sample((100,))}
            ),
        ),
        (
            tf.data.Dataset.from_tensors(
                (
                    np.random.sample((100, 2)),
                    np.random.sample((100, 4)),
                )
            ),
            None,
        ),
    ],
)
def test_conversion_to_json_with_multi_tensor_datasets(features, targets):
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)
    dataset = TensorFlowDataset(features=features, targets=targets, source=source, name="testname")

    dataset_json = dataset.to_json()
    parsed_json = json.loads(dataset_json)
    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
    assert parsed_json["name"] == dataset.name
    assert parsed_json["digest"] == dataset.digest
    assert parsed_json["source"] == dataset.source.to_json()
    assert parsed_json["source_type"] == dataset.source._get_source_type()
    assert parsed_json["profile"] == json.dumps(dataset.profile)

    parsed_schema = json.loads(parsed_json["schema"])
    assert TensorDatasetSchema.from_dict(parsed_schema) == dataset.schema


def test_schema_and_profile_with_multi_tensor_tuple_datasets():
    features_dataset = tf.data.Dataset.from_tensors(
        (
            np.random.sample((100, 2)),
            np.random.sample((100, 4)),
        )
    )
    targets_dataset = tf.data.Dataset.from_tensors(
        (
            np.random.sample((100, 1)),
            np.random.sample((100,)),
        )
    )
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)
    dataset = TensorFlowDataset(
        features=features_dataset, targets=targets_dataset, source=source, name="testname"
    )
    assert dataset.schema.features == _infer_schema(
        {
            "0": np.random.sample((100, 2)),
            "1": np.random.sample((100, 4)),
        }
    )
    assert dataset.schema.targets == _infer_schema(
        {
            "0": np.random.sample((100, 1)),
            "1": np.random.sample((100,)),
        }
    )
    assert dataset.profile == {
        "features_cardinality": 1,
        "targets_cardinality": 1,
    }
    assert dataset.profile == {
        "features_cardinality": features_dataset.cardinality().numpy(),
        "targets_cardinality": targets_dataset.cardinality().numpy(),
    }


def test_schema_and_profile_with_multi_tensor_dict_datasets():
    features_dataset = tf.data.Dataset.from_tensors(
        {"a": np.random.sample((100, 2)), "b": np.random.sample((100, 4))}
    )
    targets_dataset = tf.data.Dataset.from_tensors(
        {"c": np.random.sample((100, 1)), "d": np.random.sample((100,))}
    )
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)
    dataset = TensorFlowDataset(
        features=features_dataset, targets=targets_dataset, source=source, name="testname"
    )
    assert dataset.schema.features == _infer_schema(
        {
            "a": np.random.sample((100, 2)),
            "b": np.random.sample((100, 4)),
        }
    )
    assert dataset.schema.targets == _infer_schema(
        {
            "c": np.random.sample((100, 1)),
            "d": np.random.sample((100,)),
        }
    )
    assert dataset.profile == {
        "features_cardinality": 1,
        "targets_cardinality": 1,
    }
    assert dataset.profile == {
        "features_cardinality": features_dataset.cardinality().numpy(),
        "targets_cardinality": targets_dataset.cardinality().numpy(),
    }


def test_digest_property_has_expected_value():
    source_uri = "test:/my/test/uri"
    x = [[1, 2, 3], [4, 5, 6]]
    tf_dataset = tf.data.Dataset.from_tensors(x)
    source = SampleDatasetSource._resolve(source_uri)
    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
    assert dataset.digest == dataset._compute_digest()
    assert dataset.digest == "666a9820"


def test_data_property_has_expected_value():
    source_uri = "test:/my/test/uri"
    x = [[1, 2, 3], [4, 5, 6]]
    tf_dataset = tf.data.Dataset.from_tensors(x)
    source = SampleDatasetSource._resolve(source_uri)
    dataset = TensorFlowDataset(features=tf_dataset, source=source, name="testname")
    assert dataset.data == tf_dataset


def test_source_property_has_expected_value():
    source_uri = "test:/my/test/uri"
    x = [[1, 2, 3], [4, 5, 6]]
    tf_dataset = tf.data.Dataset.from_tensors(x)
```

## 原始行 62 · command_execution

命令：
```
/bin/bash -lc "grep -RIn 'clean_tensor_type' tests mlflow --include='*.py'; grep -RIn 'is_tensor_spec()' tests/types tests/models tests/utils --include='*.py' | head -n 100"
```

退出码：`0`

输出：
```
mlflow/models/utils.py:733:    if clean_tensor_type(actual_type) != expected_type:
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc "grep -RIn 'schema.to_dict' mlflow/data tests/data --include='*.py' | head -n 80; sed -n '180,300p' mlflow/data/tensorflow_dataset.py; sed -n '1,120p' mlflow/data/schema.py"
```

退出码：`0`

输出：
```
mlflow/data/pandas_dataset.py:78:        schema = json.dumps({"mlflow_colspec": self.schema.to_dict()}) if self.schema else None
mlflow/data/numpy_dataset.py:60:        schema = json.dumps(self.schema.to_dict()) if self.schema else None
mlflow/data/tensorflow_dataset.py:153:        schema = json.dumps(self.schema.to_dict()) if self.schema else None
mlflow/data/polars_dataset.py:211:        schema = json.dumps({"mlflow_colspec": self.schema.to_dict()} if self.schema else None)
mlflow/data/spark_dataset.py:82:        schema = json.dumps({"mlflow_colspec": self.schema.to_dict()}) if self.schema else None
mlflow/data/huggingface_dataset.py:77:        schema = json.dumps({"mlflow_colspec": self.schema.to_dict()}) if self.schema else None
mlflow/data/meta_dataset.py:85:            "schema": self.schema.to_dict() if self.schema else "",
mlflow/data/meta_dataset.py:102:            schema = json.dumps({"mlflow_colspec": self.schema.to_dict()}) if self.schema else None
tests/data/test_meta_dataset.py:63:    assert json.loads(parsed_json["schema"])["mlflow_colspec"] == schema.to_dict()
        The targets of the dataset.
        """
        return self._targets

    @property
    def profile(self) -> Any | None:
        """
        A profile of the dataset. May be None if no profile is available.
        """
        import tensorflow as tf

        profile = {
            "features_cardinality": int(self._features.cardinality().numpy())
            if isinstance(self._features, tf.data.Dataset)
            else int(tf.size(self._features).numpy()),
        }
        if self._targets is not None:
            profile.update(
                {
                    "targets_cardinality": int(self._targets.cardinality().numpy())
                    if isinstance(self._targets, tf.data.Dataset)
                    else int(tf.size(self._targets).numpy()),
                }
            )
        return profile

    @cached_property
    def schema(self) -> TensorDatasetSchema | None:
        """
        An MLflow TensorSpec schema representing the tensor dataset
        """
        try:
            features_schema = TensorFlowDataset._get_tf_object_schema(self._features)
            targets_schema = None
            if self._targets is not None:
                targets_schema = TensorFlowDataset._get_tf_object_schema(self._targets)
            return TensorDatasetSchema(features=features_schema, targets=targets_schema)
        except Exception as e:
            _logger.warning("Failed to infer schema for TensorFlow dataset. Exception: %s", e)
            return None

    @staticmethod
    def _get_tf_object_schema(tf_object) -> Schema:
        import tensorflow as tf

        if isinstance(tf_object, tf.data.Dataset):
            numpy_data = next(tf_object.as_numpy_iterator())
            if isinstance(numpy_data, np.ndarray):
                return _infer_schema(numpy_data)
            elif isinstance(numpy_data, dict):
                return TensorFlowDataset._get_schema_from_tf_dataset_dict_numpy_data(numpy_data)
            elif isinstance(numpy_data, tuple):
                return TensorFlowDataset._get_schema_from_tf_dataset_tuple_numpy_data(numpy_data)
            else:
                raise MlflowException(
                    f"Failed to infer schema for tf.data.Dataset due to unrecognized numpy iterator"
                    f" data type. Numpy iterator data types 'np.ndarray', 'dict', and 'tuple' are"
                    f" supported. Found: {type(numpy_data)}.",
                    INVALID_PARAMETER_VALUE,
                )
        elif tf.is_tensor(tf_object):
            return _infer_schema(tf_object.numpy())
        else:
            raise MlflowException(
                f"Cannot infer schema of an object that is not an instance of tf.data.Dataset or"
                f" a TensorFlow Tensor. Found: {type(tf_object)}",
                INTERNAL_ERROR,
            )

    @staticmethod
    def _get_schema_from_tf_dataset_dict_numpy_data(numpy_data: dict[Any, Any]) -> Schema:
        if not all(isinstance(data_element, np.ndarray) for data_element in numpy_data.values()):
            raise MlflowException(
                "Failed to infer schema for tf.data.Dataset. Schemas can only be inferred"
                " if the dataset consists of tensors. Ragged tensors, tensor arrays, and"
                " other types are not supported. Additionally, datasets with nested tensors"
                " are not supported.",
                INVALID_PARAMETER_VALUE,
            )
        return _infer_schema(numpy_data)

    @staticmethod
    def _get_schema_from_tf_dataset_tuple_numpy_data(numpy_data: tuple[Any]) -> Schema:
        if not all(isinstance(data_element, np.ndarray) for data_element in numpy_data):
            raise MlflowException(
                "Failed to infer schema for tf.data.Dataset. Schemas can only be inferred"
                " if the dataset consists of tensors. Ragged tensors, tensor arrays, and"
                " other types are not supported. Additionally, datasets with nested tensors"
                " are not supported.",
                INVALID_PARAMETER_VALUE,
            )
        return _infer_schema(
            {
                # MLflow Schemas currently require each tensor to have a name, if more than
                # one tensor is defined. Accordingly, use the index as the name
                str(i): data_element
                for i, data_element in enumerate(numpy_data)
            }
        )

    def to_pyfunc(self) -> PyFuncInputsOutputs:
        """
        Converts the dataset to a collection of pyfunc inputs and outputs for model
        evaluation. Required for use with mlflow.evaluate().
        """
        return PyFuncInputsOutputs(self._features, self._targets)

    def to_evaluation_dataset(self, path=None, feature_names=None) -> EvaluationDataset:
        """
        Converts the dataset to an EvaluationDataset for model evaluation. Only supported if the
        dataset is a Tensor. Required for use with mlflow.evaluate().
        """
        import tensorflow as tf

        # check that data and targets are Tensors
        if not tf.is_tensor(self._features):
            raise MlflowException("Data must be a Tensor to convert to an EvaluationDataset.")
        if self._targets is not None and not tf.is_tensor(self._targets):
            raise MlflowException("Targets must be a Tensor to convert to an EvaluationDataset.")
        return EvaluationDataset(
            data=self._features.numpy(),
from typing import Any

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.types.schema import Schema


class TensorDatasetSchema:
    """
    Represents the schema of a dataset with tensor features and targets.
    """
























































    def __eq__(self, other) -> bool:
        return (
            isinstance(other, TensorDatasetSchema)
            and self.features == other.features
            and self.targets == other.targets
        )

    def __repr__(self) -> str:
        return f"features:\n  {self.features!r}\ntargets:\n  {self.targets!r}\n"
```

## 原始行 68 · command_execution

命令：
```
/bin/bash -lc "sed -n '1430,1770p' tests/types/test_schema.py"
```

退出码：`0`

输出：
```
            properties=[
                Property(name="a", dtype=DataType.string, required=False),
                Property(name="b", dtype=DataType.double, required=False),
            ]
        ),
    )
    assert prop1.to_dict() == prop1_dict
    assert prop2.to_dict() == prop2_dict


def test_infer_colspec_type():
    data = {"role": "system", "content": "Translate every message you receive to French."}
    dtype = _infer_colspec_type(data)
    assert dtype == Object(
        [Property("role", DataType.string), Property("content", DataType.string)]
    )

    data = {
        "messages": [
            {"role": "system", "content": "Translate every message you receive to French."},
            {"role": "user", "content": "I like machine learning", "name": "John Doe"},
        ],
    }
    dtype = _infer_colspec_type(data)
    assert dtype == Object(
        [
            Property(
                "messages",
                Array(
                    Object(
                        [
                            Property("role", DataType.string),
                            Property("content", DataType.string),
                            Property("name", DataType.string, required=False),
                        ]
                    )
                ),
            )
        ]
    )

    data = [
        {
            "messages": [
                {"role": "system", "content": "Translate every message you receive to French."},
                {"role": "user", "content": "I like machine learning"},
            ],
        },
        {
            "messages": [
                {"role": "user", "content": "Summarize the following document ...", "name": "jeff"},
            ]
        },
    ]
    dtype = _infer_colspec_type(data)
    assert dtype == Array(
        Object(
            [
                Property(
                    "messages",
                    Array(
                        Object(
                            [
                                Property("role", DataType.string),
                                Property("content", DataType.string),
                                Property("name", DataType.string, required=False),
                            ]
                        )
                    ),
                )
            ]
        )
    )


def test_infer_schema_on_objects_and_arrays_to_and_from_dict():
    data = [
        {
            "messages": [
                {"role": "system", "content": "Translate every message you receive to French."},
                {"role": "user", "content": "I like machine learning"},
            ],
        },
        {
            "messages": [
                {"role": "user", "content": "Summarize the following document ...", "name": "jeff"},
            ]
        },
    ]
    schema = _infer_schema(data)
    assert schema == Schema(
        [
            ColSpec(
                Array(
                    Object(
                        [
                            Property("role", DataType.string),
                            Property("content", DataType.string),
                            Property("name", DataType.string, required=False),
                        ]
                    )
                ),
                name="messages",
            )
        ]
    )
    assert schema.to_dict() == [
        {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "content": {"type": "string", "required": True},
                    "name": {"type": "string", "required": False},
                    "role": {"type": "string", "required": True},
                },
            },
            "name": "messages",
            "required": True,
        }
    ]
    assert Schema.from_json(json.dumps(schema.to_dict())) == schema

    data = [
        {
            "messages": [
                {"role": "system", "content": "Translate every message you receive to French."},
                {"role": "user", "content": "I like machine learning"},
            ],
            "another_message": "hello world",
        },
        {
            "messages": [
                {"role": "user", "content": "Summarize the following document ...", "name": "jeff"},
            ]
        },
    ]
    schema = _infer_schema(data)
    assert schema == Schema(
        [
            ColSpec(
                Array(
                    Object(
                        [
                            Property("role", DataType.string),
                            Property("content", DataType.string),
                            Property("name", DataType.string, required=False),
                        ]
                    )
                ),
                name="messages",
            ),
            ColSpec(DataType.string, name="another_message", required=False),
        ]
    )
    assert schema.to_dict() == [
        {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "content": {"type": "string", "required": True},
                    "name": {"type": "string", "required": False},
                    "role": {"type": "string", "required": True},
                },
            },
            "name": "messages",
            "required": True,
        },
        {
            "type": "string",
            "name": "another_message",
            "required": False,
        },
    ]
    assert Schema.from_json(json.dumps(schema.to_dict())) == schema


@pytest.mark.parametrize(
    ("data", "data_type"),
    [
        ("string", DataType.string),
        (np.int32(1), DataType.integer),
        (True, DataType.boolean),
        (1.0, DataType.double),
        (np.float32(0.1), DataType.float),
        (np.int64(100), DataType.long),
        (np.datetime64("2023-10-13 00:00:00"), DataType.datetime),
    ],
)
def test_schema_inference_on_datatypes(data, data_type):
    assert _infer_schema(data) == Schema([ColSpec(data_type)])


@pytest.mark.parametrize(
    ("data", "data_type"),
    [
        (["a", "b", "c"], DataType.string),
        ([np.int32(1), np.int32(2)], DataType.integer),
        ([True, False], DataType.boolean),
        ([1.0, 2.0], DataType.double),
        ([np.float32(0.1), np.float32(0.2)], DataType.float),
        ([np.int64(100), np.int64(200)], DataType.long),
        (
            [np.datetime64("2023-10-13 00:00:00"), np.datetime64("2023-10-14 00:00:00")],
            DataType.datetime,
        ),
    ],
)
def test_schema_inference_on_dictionaries(data, data_type):
    test_data = {"data": data}
    assert _infer_schema(test_data) == Schema([ColSpec(Array(data_type), name="data")])

    test_data = {"data": {"dict": data}}
    inferred_schema = _infer_schema(test_data)
    expected_schema = Schema([ColSpec(Object([Property("dict", Array(data_type))]), name="data")])
    assert inferred_schema == expected_schema


@pytest.mark.parametrize(
    ("data", "data_type"),
    [
        (["a", "b", "c"], DataType.string),
        ([np.int32(1), np.int32(2)], DataType.integer),
        ([True, False], DataType.boolean),
        ([1.0, 2.0], DataType.double),
        ([np.float32(0.1), np.float32(0.2)], DataType.float),
        ([np.int64(100), np.int64(200)], DataType.long),
        (
            [np.datetime64("2023-10-13 00:00:00"), np.datetime64("2023-10-14 00:00:00")],
            DataType.datetime,
        ),
    ],
)
def test_schema_inference_on_lists(data, data_type):
    assert _infer_schema(data) == Schema([ColSpec(data_type)])

    test_data = [{"data": data}]
    assert _infer_schema(test_data) == Schema([ColSpec(Array(data_type), name="data")])

    test_data = [{"data": [data]}]
    assert _infer_schema(test_data) == Schema([ColSpec(Array(Array(data_type)), name="data")])

    test_data = [{"data": {"dict": data}}, {"data": {"dict": data, "string": "a"}}]
    inferred_schema = _infer_schema(test_data)
    expected_schema = Schema(
        [
            ColSpec(
                Object(
                    [
                        Property("dict", Array(data_type)),
                        Property("string", DataType.string, required=False),
                    ]
                ),
                name="data",
            )
        ]
    )
    assert inferred_schema == expected_schema

    test_data = [{"data": {"dict": data}}, {"data": {"dict": data}, "string": "a"}]
    inferred_schema = _infer_schema(test_data)
    expected_schema = Schema(
        [
            ColSpec(Object([Property("dict", Array(data_type))]), name="data"),
            ColSpec(DataType.string, name="string", required=False),
        ]
    )
    assert inferred_schema == expected_schema


def test_schema_inference_with_empty_lists():
    # If (non-nested) empty list is passed, should be inferred as string for backward compatibility
    # with version 2.7.1: https://github.com/mlflow/mlflow/blob/v2.7.1/mlflow/types/utils.py#L150
    data = []
    assert _infer_schema(data) == Schema([ColSpec(DataType.string)])

    data = [None, "a"]
    assert _infer_schema(data) == Schema([ColSpec(DataType.string)])

    data = [["a", "b", "c"], ["a", "b", "c", "d"], None]
    assert _infer_schema(data) == Schema([ColSpec(Array(DataType.string))])

    data = [[None, np.nan]]
    assert _infer_schema(data) == Schema([ColSpec(Array(AnyType()))])

    assert _infer_schema([[]]) == Schema([ColSpec(AnyType())])

    # Empty numpy array is not allowed.
    with pytest.raises(
        MlflowException,
        match=r"Numpy array must include at least one non-empty item",
    ):
        _infer_schema([np.array([])])

    # If at least one of sublists is not empty, we can assume other empty lists have the same type.
    data = [
        {
            "data": [
                ["a", "b", "c"],
                [],
                ["d", "e"],
                [],
            ]
        }
    ]
    inferred_schema = _infer_schema(data)
    expected_schema = Schema([ColSpec(Array(Array(DataType.string)), name="data")])
    assert inferred_schema == expected_schema

    # Complex case for deeply nested array
    data = [
        {
            "data": [
                [["a", "b", "c"], [], ["d"]],
                [[], ["e"]],
                [
                    [],
                    [],
                    [],
                ],
            ]
        }
    ]
    inferred_schema = _infer_schema(data)
    expected_schema = Schema([ColSpec(Array(Array(Array(DataType.string))), name="data")])
    assert inferred_schema == expected_schema

    data = [{"data": {"key": []}}]
    assert _infer_schema(data) == Schema(
        [ColSpec(Object([Property("key", AnyType(), required=False)]), name="data")]
    )


def test_repr_of_objects():
    obj = Object(
        properties=[
            Property(name="a", dtype=DataType.string),
            Property(name="b", dtype=DataType.double, required=False),
            Property(name="c", dtype=Array(DataType.long)),
            Property(name="d", dtype=Object([Property("d1", DataType.string)])),
```

## 原始行 71 · command_execution

命令：
```
/bin/bash -lc "grep -n 'warn\\|warning\\|integer columns' tests/types/test_schema.py | head -n 50; grep -RIn 'Hint: Inferred schema contains integer' tests mlflow --include='*.py' | head"
```

退出码：`0`

输出：
```

```

## 原始行 74 · command_execution

命令：
```
/bin/bash -lc "grep -n '_hash_' mlflow/data/evaluation_dataset.py; grep -RIn 'EvaluationDataset(' tests/evaluate/test_evaluation.py | head -n 80; sed -n '700,840p' tests/evaluate/test_evaluation.py; sed -n '780,835p' tests/evaluate/test_evaluation.py"
```

退出码：`0`

输出：
```
55:def _hash_array_of_dict_as_bytes(data):
63:            result += _hash_array_of_dict_as_bytes(elm)
65:            result += _hash_dict_as_bytes(elm)
67:            result += _hash_data_as_bytes(elm)
83:def _hash_data_as_bytes(data):
86:            return _hash_ndarray_as_bytes(data)
88:            return _hash_dict_as_bytes(data)
90:            return _hash_uint64_ndarray_as_bytes(pd.util.hash_array(np.array([data])))
97:def _hash_dict_as_bytes(data_dict):
98:    result = _hash_ndarray_as_bytes(list(data_dict.keys()))
100:        result += _hash_ndarray_as_bytes(list(data_dict.values()))
104:            result += _hash_data_as_bytes(value)
546:    def __hash__(self):
125:    ds = EvaluationDataset(**constructor_args)
136:    ds = EvaluationDataset(**constructor_args)
145:    ds = EvaluationDataset(**constructor_args)
156:    ds = EvaluationDataset(**constructor_args)
329:    ds = EvaluationDataset(**constructor_args)
342:    ds = EvaluationDataset(**constructor_args)
677:    d1 = EvaluationDataset(data=X, targets=y, name="a1")
679:    d2 = EvaluationDataset(data=X, targets=y)
685:    d1 = EvaluationDataset(data=X, targets=y, name="a1", path="/path/to/a1")
734:    dataset = EvaluationDataset(data=df)
743:    dataset2 = EvaluationDataset(data=df2)
749:    eval_dataset = EvaluationDataset(data=data, targets="label")
757:    eval_dataset2 = EvaluationDataset(data=data, targets="label", feature_names=["f3", "f2"])
768:        eval_dataset1 = EvaluationDataset(data=input_data, targets=labels)
773:    assert EvaluationDataset(
778:        EvaluationDataset(data=[[1, 2], [3, 4, 5]], targets=labels)
783:    eval_dataset2 = EvaluationDataset(data=[list(range(9))], targets=labels)
786:    eval_dataset2 = EvaluationDataset(data=[list(range(10))], targets=labels)
789:    eval_dataset2 = EvaluationDataset(data=[list(range(99))], targets=labels)
792:    eval_dataset2 = EvaluationDataset(data=[list(range(100))], targets=labels)
798:        EvaluationDataset(data=[[1, 2], [3, 4]], targets=[1, 2, 3])
804:        dataset = EvaluationDataset(spark_df, targets="y")
    list1 = [100] + list0[1:]
    list2 = list0[:-1] + [100]
    list3 = list0[:10] + [100] + list0[10:]

    assert len({get_md5(list0), get_md5(list1), get_md5(list2), get_md5(list3)}) == 4

    list4 = list0[:10] + [99] + list0[10:]
    assert get_md5(list3) == get_md5(list4)


def test_gen_md5_for_arraylike_obj_with_pandas_df_using_float_idx_does_not_raise_keyerror():
    float_indices = np.random.uniform(low=0.5, high=13.3, size=(10,))
    df = pd.DataFrame(np.random.randn(10, 4), index=float_indices, columns=["A", "B", "C", "D"])
    md5_gen = hashlib.md5(usedforsecurity=False)
    assert _gen_md5_for_arraylike_obj(md5_gen, df) is None


def test_dataset_hash(
    iris_dataset, iris_pandas_df_dataset, iris_pandas_df_num_cols_dataset, diabetes_spark_dataset
):
    assert iris_dataset.hash == "99329a790dc483e7382c0d1d27aac3f3"
    assert iris_pandas_df_dataset.hash == "799d4f50e2e353127f94a0e5300add06"
    assert iris_pandas_df_num_cols_dataset.hash == "3c5fc56830a0646001253e25e17bdce4"
    assert diabetes_spark_dataset.hash == "ebfb050519e7e5b463bd38b0c8d04243"


def test_trace_dataset_hash():
    # Validates that a dataset containing Traces can be hashed.
    df = pd.DataFrame(
        {
            "request": ["Hello"],
            "trace": [Trace(info=create_test_trace_info("tr"), data=TraceData([]))],
        }
    )
    dataset = EvaluationDataset(data=df)
    assert dataset.hash == "757c14bf38aa42d36b93ccd70b1ea719"
    # Hash of a dataset with a different column should be different
    df2 = pd.DataFrame(
        {
            "request": ["Hi"],
            "trace": [Trace(info=create_test_trace_info("tr"), data=TraceData([]))],
        }
    )
    dataset2 = EvaluationDataset(data=df2)
    assert dataset2.hash != dataset.hash


def test_dataset_with_pandas_dataframe():
    data = pd.DataFrame({"f1": [1, 2], "f2": [3, 4], "f3": [5, 6], "label": [0, 1]})
    eval_dataset = EvaluationDataset(data=data, targets="label")

    assert list(eval_dataset.features_data.columns) == ["f1", "f2", "f3"]
    np.testing.assert_array_equal(eval_dataset.features_data.f1.to_numpy(), [1, 2])
    np.testing.assert_array_equal(eval_dataset.features_data.f2.to_numpy(), [3, 4])
    np.testing.assert_array_equal(eval_dataset.features_data.f3.to_numpy(), [5, 6])
    np.testing.assert_array_equal(eval_dataset.labels_data, [0, 1])

    eval_dataset2 = EvaluationDataset(data=data, targets="label", feature_names=["f3", "f2"])
    assert list(eval_dataset2.features_data.columns) == ["f3", "f2"]
    np.testing.assert_array_equal(eval_dataset2.features_data.f2.to_numpy(), [3, 4])
    np.testing.assert_array_equal(eval_dataset2.features_data.f3.to_numpy(), [5, 6])


def test_dataset_with_array_data():
    features = [[1, 2], [3, 4]]
    labels = [0, 1]

    for input_data in [features, np.array(features)]:
        eval_dataset1 = EvaluationDataset(data=input_data, targets=labels)
        np.testing.assert_array_equal(eval_dataset1.features_data, features)
        np.testing.assert_array_equal(eval_dataset1.labels_data, labels)
        assert list(eval_dataset1.feature_names) == ["feature_1", "feature_2"]

    assert EvaluationDataset(
        data=input_data, targets=labels, feature_names=["a", "b"]
    ).feature_names == ["a", "b"]

    with pytest.raises(MlflowException, match="all elements must have the same length"):
        EvaluationDataset(data=[[1, 2], [3, 4, 5]], targets=labels)


def test_dataset_autogen_feature_names():
    labels = [0]
    eval_dataset2 = EvaluationDataset(data=[list(range(9))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1}" for i in range(9)]

    eval_dataset2 = EvaluationDataset(data=[list(range(10))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1:02d}" for i in range(10)]

    eval_dataset2 = EvaluationDataset(data=[list(range(99))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1:02d}" for i in range(99)]

    eval_dataset2 = EvaluationDataset(data=[list(range(100))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1:03d}" for i in range(100)]

    with pytest.raises(
        MlflowException, match="features example rows must be the same length with labels array"
    ):
        EvaluationDataset(data=[[1, 2], [3, 4]], targets=[1, 2, 3])


def test_dataset_from_spark_df(spark_session):
    spark_df = spark_session.createDataFrame([(1.0, 2.0, 3.0)] * 10, ["f1", "f2", "y"])
    with mock.patch.object(EvaluationDataset, "SPARK_DATAFRAME_LIMIT", 5):
        dataset = EvaluationDataset(spark_df, targets="y")
        assert list(dataset.features_data.columns) == ["f1", "f2"]
        assert list(dataset.features_data["f1"]) == [1.0] * 5
        assert list(dataset.features_data["f2"]) == [2.0] * 5
        assert list(dataset.labels_data) == [3.0] * 5


def test_log_dataset_tag(iris_dataset, iris_pandas_df_dataset):
    model_uuid = uuid.uuid4().hex
    with mlflow.start_run() as run:
        client = MlflowClient()
        iris_dataset._log_dataset_tag(client, run.info.run_id, model_uuid=model_uuid)
        _, _, tags, _ = get_run_data(run.info.run_id)

        logged_meta1 = {**iris_dataset._metadata, "model": model_uuid}
        logged_meta2 = {**iris_pandas_df_dataset._metadata, "model": model_uuid}

        assert json.loads(tags["mlflow.datasets"]) == [logged_meta1]

        raw_tag = get_raw_tag(run.info.run_id, "mlflow.datasets")
        assert " " not in raw_tag  # assert the tag string remove all whitespace chars.

        # Test appending dataset tag
        iris_pandas_df_dataset._log_dataset_tag(client, run.info.run_id, model_uuid=model_uuid)
        _, _, tags, _ = get_run_data(run.info.run_id)
        assert json.loads(tags["mlflow.datasets"]) == [
            logged_meta1,
            logged_meta2,
        ]

        # Test log repetitive dataset
        iris_dataset._log_dataset_tag(client, run.info.run_id, model_uuid=model_uuid)
        _, _, tags, _ = get_run_data(run.info.run_id)
        assert json.loads(tags["mlflow.datasets"]) == [
            logged_meta1,
            logged_meta2,
        ]

def test_dataset_autogen_feature_names():
    labels = [0]
    eval_dataset2 = EvaluationDataset(data=[list(range(9))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1}" for i in range(9)]

    eval_dataset2 = EvaluationDataset(data=[list(range(10))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1:02d}" for i in range(10)]

    eval_dataset2 = EvaluationDataset(data=[list(range(99))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1:02d}" for i in range(99)]

    eval_dataset2 = EvaluationDataset(data=[list(range(100))], targets=labels)
    assert eval_dataset2.feature_names == [f"feature_{i + 1:03d}" for i in range(100)]

    with pytest.raises(
        MlflowException, match="features example rows must be the same length with labels array"
    ):
        EvaluationDataset(data=[[1, 2], [3, 4]], targets=[1, 2, 3])


def test_dataset_from_spark_df(spark_session):
    spark_df = spark_session.createDataFrame([(1.0, 2.0, 3.0)] * 10, ["f1", "f2", "y"])
    with mock.patch.object(EvaluationDataset, "SPARK_DATAFRAME_LIMIT", 5):
        dataset = EvaluationDataset(spark_df, targets="y")
        assert list(dataset.features_data.columns) == ["f1", "f2"]
        assert list(dataset.features_data["f1"]) == [1.0] * 5
        assert list(dataset.features_data["f2"]) == [2.0] * 5
        assert list(dataset.labels_data) == [3.0] * 5


def test_log_dataset_tag(iris_dataset, iris_pandas_df_dataset):
    model_uuid = uuid.uuid4().hex
    with mlflow.start_run() as run:
        client = MlflowClient()
        iris_dataset._log_dataset_tag(client, run.info.run_id, model_uuid=model_uuid)
        _, _, tags, _ = get_run_data(run.info.run_id)

        logged_meta1 = {**iris_dataset._metadata, "model": model_uuid}
        logged_meta2 = {**iris_pandas_df_dataset._metadata, "model": model_uuid}

        assert json.loads(tags["mlflow.datasets"]) == [logged_meta1]

        raw_tag = get_raw_tag(run.info.run_id, "mlflow.datasets")
        assert " " not in raw_tag  # assert the tag string remove all whitespace chars.

        # Test appending dataset tag
        iris_pandas_df_dataset._log_dataset_tag(client, run.info.run_id, model_uuid=model_uuid)
        _, _, tags, _ = get_run_data(run.info.run_id)
        assert json.loads(tags["mlflow.datasets"]) == [
            logged_meta1,
            logged_meta2,
        ]

        # Test log repetitive dataset
        iris_dataset._log_dataset_tag(client, run.info.run_id, model_uuid=model_uuid)
```

## 原始行 77 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' tests/evaluate/test_evaluation.py; sed -n '630,735p' tests/evaluate/test_evaluation.py; grep -nE '_gen_md5|_hash_ndarray|_hash_uint64' tests/evaluate/test_evaluation.py"
```

退出码：`0`

输出：
```
import hashlib
import io
import json
import os
import re
import signal
import subprocess
import uuid
from typing import Any, NamedTuple
from unittest import mock

import numpy as np
import pandas as pd
import pytest
import sklearn
import sklearn.compose
import sklearn.datasets
import sklearn.impute
import sklearn.linear_model
import sklearn.pipeline
import sklearn.preprocessing
from mlflow_test_plugin.dummy_evaluator import Array2DEvaluationArtifact, DummyEvaluator
from PIL import Image, ImageChops
from pyspark.ml.linalg import Vectors
from pyspark.ml.regression import LinearRegression as SparkLinearRegression
from pyspark.sql import SparkSession
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    mean_absolute_error,
    mean_squared_error,
)

import mlflow
from mlflow import MlflowClient
from mlflow.data.evaluation_dataset import EvaluationDataset, _gen_md5_for_arraylike_obj
from mlflow.data.pandas_dataset import from_pandas
from mlflow.entities import Trace, TraceData
from mlflow.exceptions import MlflowException
from mlflow.models.evaluation import (
    EvaluationArtifact,
    EvaluationResult,
    ModelEvaluator,
    evaluate,
)
from mlflow.models.evaluation.artifacts import ImageEvaluationArtifact
from mlflow.models.evaluation.base import (
    _get_model_from_deployment_endpoint_uri,
    _is_model_deployment_endpoint_uri,
    _start_run_or_reuse_active_run,
    resolve_evaluators_and_configs,
)
from mlflow.models.evaluation.evaluator_registry import _model_evaluation_registry
from mlflow.pyfunc import _ServedPyFuncModel
from mlflow.pyfunc.scoring_server.client import ScoringServerClient
from mlflow.tracing.constant import TraceMetadataKey
from mlflow.tracking.artifact_utils import get_artifact_uri
from mlflow.utils.file_utils import TempDir

from tests.tracing.helper import create_test_trace_info, get_traces
from tests.utils.test_file_utils import spark_session  # noqa: F401

INFERENCE_FILE_NAME = "inference_inputs_outputs.json"


def get_iris():
    iris = sklearn.datasets.load_iris()
    return iris.data, iris.target


def get_diabetes_dataset():
    data = sklearn.datasets.load_diabetes()
    return data.data, data.target


def get_diabetes_spark_dataset():
    data = sklearn.datasets.load_diabetes()
    spark = SparkSession.builder.master("local[*]").getOrCreate()
    rows = [
        (Vectors.dense(features), float(label)) for features, label in zip(data.data, data.target)
    ]
    return spark.createDataFrame(spark.sparkContext.parallelize(rows, 1), ["features", "label"])


def get_breast_cancer_dataset():
    data = sklearn.datasets.load_breast_cancer()
    return data.data, data.target


class RunData(NamedTuple):
    params: dict[str, Any]
    metrics: dict[str, Any]
    tags: dict[str, Any]
    artifacts: list[str]


def get_run_data(run_id):
    client = MlflowClient()
    data = client.get_run(run_id).data
    artifacts = [f.path for f in client.list_artifacts(run_id)]
    return RunData(params=data.params, metrics=data.metrics, tags=data.tags, artifacts=artifacts)


def get_run_datasets(run_id):
    client = MlflowClient()
    return client.get_run(run_id).inputs.dataset_inputs


def get_raw_tag(run_id, tag_name):
    client = MlflowClient()
    data = client.get_run(run_id).data
    return data.tags[tag_name]


def get_local_artifact_path(run_id, artifact_path):
    return get_artifact_uri(run_id, artifact_path).replace("file://", "")


@pytest.fixture(scope="module")
def iris_dataset():
    X, y = get_iris()
    eval_X = X[0::3]
    eval_y = y[0::3]
    constructor_args = {"data": eval_X, "targets": eval_y, "name": "dataset"}
    ds = EvaluationDataset(**constructor_args)
    ds._constructor_args = constructor_args
    return ds


@pytest.fixture(scope="module")
def diabetes_dataset():
    X, y = get_diabetes_dataset()
    eval_X = X[0::3]
    eval_y = y[0::3]
    constructor_args = {"data": eval_X, "targets": eval_y}
    ds = EvaluationDataset(**constructor_args)
    ds._constructor_args = constructor_args
    return ds


@pytest.fixture(scope="module")
def diabetes_spark_dataset():
    spark_df = get_diabetes_spark_dataset().sample(fraction=0.3, seed=1)
    constructor_args = {"data": spark_df, "targets": "label"}
    ds = EvaluationDataset(**constructor_args)
    ds._constructor_args = constructor_args
    return ds


@pytest.fixture(scope="module")
def breast_cancer_dataset():
    X, y = get_breast_cancer_dataset()
    eval_X = X[0::3]
    eval_y = y[0::3]
    constructor_args = {"data": eval_X, "targets": eval_y}
    ds = EvaluationDataset(**constructor_args)
    ds._constructor_args = constructor_args
    return ds


def get_pipeline_model_dataset():
    """
    The dataset tweaks the IRIS dataset by changing its first 2 features into categorical features,
    and replace some feature values with NA values.
    The dataset is prepared for a pipeline model, see `pipeline_model_uri`.
    """
    X, y = get_iris()

    def convert_num_to_label(x):
        return f"v_{round(x)}"

    f1 = np.array(list(map(convert_num_to_label, X[:, 0])))
    f2 = np.array(list(map(convert_num_to_label, X[:, 1])))
    f3 = X[:, 2]
    f4 = X[:, 3]

    f1[0::8] = None
    f2[1::8] = None
    f3[2::8] = np.nan
    f4[3::8] = np.nan
    data = sklearn.datasets.load_diabetes()
    df = pd.DataFrame(data.data, columns=data.feature_names)
    df["y"] = data.target
    mlflow_df = from_pandas(df=df, source="my_src", targets="y")
    with mlflow.start_run() as run:
        eval_result = evaluate(
            linear_regressor_model_uri,
            data=mlflow_df,
            model_type="regressor",
            evaluators=["default"],
        )
    _, saved_metrics, _, _ = get_run_data(run.info.run_id)

    for k, v in eval_result.metrics.items():
        assert v == saved_metrics[k]

    datasets = get_run_datasets(run.info.run_id)
    assert len(datasets) == 1
    assert len(datasets[0].tags) == 0


def test_pandas_df_regressor_evaluation_mlflow_dataset_with_targets_from_dataset(
    linear_regressor_model_uri,
):
    data = sklearn.datasets.load_diabetes()
    df = pd.DataFrame(data.data, columns=data.feature_names)
    df["y"] = data.target
    mlflow_df = from_pandas(df=df, source="my_src", targets="y")
    with mlflow.start_run() as run:
        eval_result = evaluate(
            linear_regressor_model_uri,
            data=mlflow_df,
            model_type="regressor",
            evaluators=["default"],
        )
    _, saved_metrics, _, _ = get_run_data(run.info.run_id)

    for k, v in eval_result.metrics.items():
        assert v == saved_metrics[k]

    datasets = get_run_datasets(run.info.run_id)
    assert len(datasets) == 1
    assert len(datasets[0].tags) == 0


def test_dataset_name():
    X, y = get_iris()
    d1 = EvaluationDataset(data=X, targets=y, name="a1")
    assert d1.name == "a1"
    d2 = EvaluationDataset(data=X, targets=y)
    assert d2.name == d2.hash


def test_dataset_metadata():
    X, y = get_iris()
    d1 = EvaluationDataset(data=X, targets=y, name="a1", path="/path/to/a1")
    assert d1._metadata == {
        "hash": "6bdf4e119bf1a37e7907dfd9f0e68733",
        "name": "a1",
        "path": "/path/to/a1",
    }


def test_gen_md5_for_arraylike_obj():
    def get_md5(data):
        md5_gen = hashlib.md5(usedforsecurity=False)
        _gen_md5_for_arraylike_obj(md5_gen, data)
        return md5_gen.hexdigest()

    list0 = list(range(20))
    list1 = [100] + list0[1:]
    list2 = list0[:-1] + [100]
    list3 = list0[:10] + [100] + list0[10:]

    assert len({get_md5(list0), get_md5(list1), get_md5(list2), get_md5(list3)}) == 4

    list4 = list0[:10] + [99] + list0[10:]
    assert get_md5(list3) == get_md5(list4)


def test_gen_md5_for_arraylike_obj_with_pandas_df_using_float_idx_does_not_raise_keyerror():
    float_indices = np.random.uniform(low=0.5, high=13.3, size=(10,))
    df = pd.DataFrame(np.random.randn(10, 4), index=float_indices, columns=["A", "B", "C", "D"])
    md5_gen = hashlib.md5(usedforsecurity=False)
    assert _gen_md5_for_arraylike_obj(md5_gen, df) is None


def test_dataset_hash(
    iris_dataset, iris_pandas_df_dataset, iris_pandas_df_num_cols_dataset, diabetes_spark_dataset
):
    assert iris_dataset.hash == "99329a790dc483e7382c0d1d27aac3f3"
    assert iris_pandas_df_dataset.hash == "799d4f50e2e353127f94a0e5300add06"
    assert iris_pandas_df_num_cols_dataset.hash == "3c5fc56830a0646001253e25e17bdce4"
    assert diabetes_spark_dataset.hash == "ebfb050519e7e5b463bd38b0c8d04243"


def test_trace_dataset_hash():
    # Validates that a dataset containing Traces can be hashed.
    df = pd.DataFrame(
        {
            "request": ["Hello"],
            "trace": [Trace(info=create_test_trace_info("tr"), data=TraceData([]))],
        }
    )
    dataset = EvaluationDataset(data=df)
    assert dataset.hash == "757c14bf38aa42d36b93ccd70b1ea719"
36:from mlflow.data.evaluation_dataset import EvaluationDataset, _gen_md5_for_arraylike_obj
693:def test_gen_md5_for_arraylike_obj():
696:        _gen_md5_for_arraylike_obj(md5_gen, data)
710:def test_gen_md5_for_arraylike_obj_with_pandas_df_using_float_idx_does_not_raise_keyerror():
714:    assert _gen_md5_for_arraylike_obj(md5_gen, df) is None
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc "grep -RInE 'SPARK_DATAFRAME_LIMIT|dataset is truncated|Spark.*limit|10000' tests/evaluate tests/data --include='*.py' | head -n 100; grep -RInE 'predictions=.*EvaluationDataset|EvaluationDataset\\(.*predictions' tests/evaluate tests/data --include='*.py' | head -n 100"
```

退出码：`0`

输出：
```
tests/evaluate/test_evaluation.py:803:    with mock.patch.object(EvaluationDataset, "SPARK_DATAFRAME_LIMIT", 5):
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc "grep -RIn 'EvaluationDataset(' mlflow --include='*.py'; grep -RIn '\\.predictions_name\\|\\.has_predictions\\|\\.targets_name' mlflow tests/evaluate --include='*.py' | head -n 150"
```

退出码：`0`

输出：
```
mlflow/genai/datasets/evaluation_dataset.py:15:class EvaluationDataset(Dataset, PyFuncConvertibleDatasetMixin):
mlflow/genai/datasets/evaluation_dataset.py:176:        return EvaluationDataset(dataset)
mlflow/genai/datasets/evaluation_dataset.py:191:        return EvaluationDataset(dataset)
mlflow/genai/datasets/evaluation_dataset.py:264:        return LegacyEvaluationDataset(
mlflow/genai/datasets/__init__.py:181:                return EvaluationDataset(db_create(name, experiment_ids))
mlflow/genai/datasets/__init__.py:199:        return EvaluationDataset(mlflow_dataset)
mlflow/genai/datasets/__init__.py:320:                return EvaluationDataset(db_get(name))
mlflow/genai/datasets/__init__.py:329:        return EvaluationDataset(mlflow_dataset)
mlflow/genai/datasets/__init__.py:509:    return [EvaluationDataset(dataset) for dataset in mlflow_datasets]
mlflow/genai/datasets/__init__.py:682:    return EvaluationDataset(mlflow_dataset)
mlflow/genai/datasets/__init__.py:719:    return EvaluationDataset(mlflow_dataset)
mlflow/entities/evaluation_dataset.py:25:class EvaluationDataset(_MlflowObject, Dataset, PyFuncConvertibleDatasetMixin):
mlflow/models/evaluation/base.py:1781:                dataset = EvaluationDataset(
mlflow/data/pandas_dataset.py:155:        return EvaluationDataset(
mlflow/data/numpy_dataset.py:146:        return EvaluationDataset(
mlflow/data/tensorflow_dataset.py:299:        return EvaluationDataset(
mlflow/data/polars_dataset.py:282:        return EvaluationDataset(
mlflow/data/spark_dataset.py:217:        return EvaluationDataset(
mlflow/data/huggingface_dataset.py:168:        return EvaluationDataset(
mlflow/store/tracking/sqlalchemy_store.py:3783:            created_dataset = EvaluationDataset(
mlflow/store/tracking/dbmodels/models.py:1291:class SqlEvaluationDataset(Base):
mlflow/store/tracking/dbmodels/models.py:1380:        dataset = EvaluationDataset(
mlflow/models/evaluation/default_evaluator.py:491:                if column in ("predictions", self.predictions, self.dataset.predictions_name):
mlflow/models/evaluation/default_evaluator.py:493:                elif column in ("targets", self.dataset.targets_name):
mlflow/models/evaluation/default_evaluator.py:623:        elif self.dataset.predictions_name:
mlflow/models/evaluation/default_evaluator.py:624:            output_columns.append(self.dataset.predictions_name)
mlflow/models/evaluation/default_evaluator.py:630:            if self.dataset.targets_name:
mlflow/models/evaluation/default_evaluator.py:631:                input_columns.append(self.dataset.targets_name)
mlflow/models/evaluation/default_evaluator.py:779:                        self.dataset.targets_name or "target": self.dataset.labels_data,
mlflow/models/evaluation/default_evaluator.py:780:                        self.dataset.predictions_name or self.predictions or "outputs": y_pred,
mlflow/models/evaluation/default_evaluator.py:791:                        self.dataset.targets_name or "target": self.dataset.labels_data,
mlflow/models/evaluation/default_evaluator.py:792:                        self.dataset.predictions_name or self.predictions or "outputs": y_pred,
```

## 原始行 85 · command_execution

命令：
```
/bin/bash -lc "sed -n '1750,1805p' mlflow/models/evaluation/base.py; sed -n '135,175p' mlflow/data/pandas_dataset.py; sed -n '200,235p' mlflow/data/spark_dataset.py; sed -n '150,180p' mlflow/data/huggingface_dataset.py"
```

退出码：`0`

输出：
```
                )
            else:
                data = convert_data_to_mlflow_dataset(data=data, targets=targets)

        from mlflow.data.pyfunc_dataset_mixin import PyFuncConvertibleDatasetMixin

        # model_id could be None
        with _set_active_model(model_id=model_id) if model_id else nullcontext():
            if isinstance(data, Dataset) and issubclass(
                data.__class__, PyFuncConvertibleDatasetMixin
            ):
                dataset = data.to_evaluation_dataset(dataset_path, feature_names)

                # Use metrix_prefix configured for builtin evaluators as a dataset tag
                context = None
                for e in evaluators:
                    if _model_evaluation_registry.is_builtin(e.name) and e.config.get(
                        "metric_prefix"
                    ):
                        context = e.config.get("metric_prefix")
                        break

                client = MlflowClient()
                tags = [InputTag(key=MLFLOW_DATASET_CONTEXT, value=context)] if context else []
                dataset_input = DatasetInput(dataset=data._to_mlflow_entity(), tags=tags)
                client.log_inputs(
                    run_id,
                    [dataset_input],
                    models=[LoggedModelInput(model_id)] if model_id else None,
                )
            else:
                dataset = EvaluationDataset(
                    data,
                    targets=targets,
                    path=dataset_path,
                    feature_names=feature_names,
                    predictions=predictions,
                )
            predictions_expected_in_model_output = predictions if model is not None else None

            try:
                evaluate_result = _evaluate(
                    model=model,
                    model_type=model_type,
                    model_id=model_id,
                    dataset=dataset,
                    run_id=run_id,
                    evaluator_name_list=evaluator_name_list,
                    evaluator_name_to_conf_map=evaluator_name_to_conf_map,
                    extra_metrics=extra_metrics,
                    custom_artifacts=custom_artifacts,
                    predictions=predictions_expected_in_model_output,
                    evaluators=evaluators,
                )
            finally:
                if isinstance(model, _ServedPyFuncModel):
            _logger.debug("Failed to infer schema for Pandas dataset. Exception: %s", e)
            return None

    def to_pyfunc(self) -> PyFuncInputsOutputs:
        """
        Converts the dataset to a collection of pyfunc inputs and outputs for model
        evaluation. Required for use with mlflow.evaluate().
        """
        if self._targets:
            inputs = self._df.drop(columns=[self._targets])
            outputs = self._df[self._targets]
            return PyFuncInputsOutputs(inputs, outputs)
        else:
            return PyFuncInputsOutputs(self._df)

    def to_evaluation_dataset(self, path=None, feature_names=None) -> EvaluationDataset:
        """
        Converts the dataset to an EvaluationDataset for model evaluation. Required
        for use with mlflow.evaluate().
        """
        return EvaluationDataset(
            data=self._df,
            targets=self._targets,
            path=path,
            feature_names=feature_names,
            predictions=self._predictions,
            name=self.name,
            digest=self.digest,
        )


def from_pandas(
    df: pd.DataFrame,
    source: str | DatasetSource = None,
    targets: str | None = None,
    name: str | None = None,
    digest: str | None = None,
    predictions: str | None = None,
) -> PandasDataset:
    """
    Constructs a :py:class:`PandasDataset <mlflow.data.pandas_dataset.PandasDataset>` instance from
                    f" the pandas representation of the Spark dataset does not contain the"
                    f" specified targets column '{self._targets}'.",
                    # This is an internal error because we should have validated the presence of
                    # the target column in the Hugging Face dataset at construction time
                    INTERNAL_ERROR,
                )
            inputs = df.drop(columns=self._targets)
            outputs = df[self._targets]
            return PyFuncInputsOutputs(inputs=inputs, outputs=outputs)
        else:
            return PyFuncInputsOutputs(inputs=df, outputs=None)

    def to_evaluation_dataset(self, path=None, feature_names=None) -> EvaluationDataset:
        """
        Converts the dataset to an EvaluationDataset for model evaluation. Required
        for use with mlflow.evaluate().
        """
        return EvaluationDataset(
            data=self._df.limit(10000).toPandas(),
            targets=self._targets,
            path=path,
            feature_names=feature_names,
            predictions=self._predictions,
            name=self.name,
            digest=self.digest,
        )


def load_delta(
    path: str | None = None,
    table_name: str | None = None,
    version: str | None = None,
    targets: str | None = None,
    name: str | None = None,
    digest: str | None = None,
) -> SparkDataset:
                    f"Failed to convert Hugging Face dataset to pyfunc inputs and outputs because"
                    f" the pandas representation of the Hugging Face dataset does not contain the"
                    f" specified targets column '{self._targets}'.",
                    # This is an internal error because we should have validated the presence of
                    # the target column in the Hugging Face dataset at construction time
                    INTERNAL_ERROR,
                )
            inputs = df.drop(columns=self._targets)
            outputs = df[self._targets]
            return PyFuncInputsOutputs(inputs=inputs, outputs=outputs)
        else:
            return PyFuncInputsOutputs(inputs=df, outputs=None)

    def to_evaluation_dataset(self, path=None, feature_names=None) -> EvaluationDataset:
        """
        Converts the dataset to an EvaluationDataset for model evaluation. Required
        for use with mlflow.evaluate().
        """
        return EvaluationDataset(
            data=self._ds.to_pandas(),
            targets=self._targets,
            path=path,
            feature_names=feature_names,
            name=self.name,
            digest=self.digest,
        )


def from_huggingface(
    ds,
    path: str | None = None,
```

## 原始行 87 · agent_message

```
The visible tests confirm the intended schema split: top-level NumPy/sparse inputs become `TensorSpec`, while lists, mappings, pandas, and Spark inputs become `ColSpec` schemas, including merged optional fields for lists of records. I’m now restoring those interfaces plus the minimal constructors/serialization helpers their callers require.
```

## 原始行 89 · file_change

```
{
  "id": "item_52",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/data/dataset.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/data/dataset_source.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/data/schema.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/types/schema.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/types/utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 92 · command_execution

命令：
```
/bin/bash -lc 'git diff --stat; python -m pytest tests/data/test_dataset.py tests/types/test_schema.py -q --disable-warnings --maxfail=1'
```

退出码：`2`

输出：
```
 mlflow/data/dataset.py        |  35 +++++++++-
 mlflow/data/dataset_source.py |  14 ++--
 mlflow/data/schema.py         |  47 ++++++++++++-
 mlflow/types/schema.py        |   7 +-
 mlflow/types/utils.py         | 152 +++++++++++++++++++++++++++++++++++++++++-
 5 files changed, 239 insertions(+), 16 deletions(-)
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 3 items / 1 error

==================================== ERRORS ====================================
[31m[1m_________________ ERROR collecting tests/types/test_schema.py __________________[0m
[31mImportError while importing test module '/testbed/tests/types/test_schema.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
tests/types/test_schema.py:10: in <module>
    import pyspark
E   ModuleNotFoundError: No module named 'pyspark'[0m
[36m[1m=========================== short test summary info ============================[0m
[31mERROR[0m tests/types/test_schema.py
[31m!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!![0m
!!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
[31m=============================== [31m[1m1 error[0m[31m in 0.28s[0m[31m ===============================[0m
```

## 原始行 96 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/data/test_dataset.py tests/data/test_dataset_source.py tests/data/test_http_dataset_source.py -q --disable-warnings --maxfail=1'
```

退出码：`2`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 8 items / 1 error

==================================== ERRORS ====================================
[31m[1m___________ ERROR collecting tests/data/test_http_dataset_source.py ____________[0m
[31mImportError while importing test module '/testbed/tests/data/test_http_dataset_source.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
tests/data/test_http_dataset_source.py:8: in <module>
    from mlflow.data.dataset_source_registry import get_dataset_source_from_json, resolve_dataset_source
E   ImportError: cannot import name 'resolve_dataset_source' from 'mlflow.data.dataset_source_registry' (/testbed/mlflow/data/dataset_source_registry.py)[0m
[36m[1m=========================== short test summary info ============================[0m
[31mERROR[0m tests/data/test_http_dataset_source.py
[31m!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!![0m
!!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
[31m=============================== [31m[1m1 error[0m[31m in 0.14s[0m[31m ===============================[0m
```

## 原始行 99 · command_execution

命令：
```
/bin/bash -lc "grep -RIn 'def generate_feature_name_if_not_string' mlflow/utils/string_utils.py; sed -n '15,45p' mlflow/utils/string_utils.py; grep -RIn '_digest' mlflow/data/evaluation_dataset.py tests/evaluate --include='*.py' | head -n 50"
```

退出码：`0`

输出：
```
25:def generate_feature_name_if_not_string(s: Any) -> str:
def strip_suffix(original: str, suffix: str) -> str:
    if original.endswith(suffix) and suffix != "":
        return original[: -len(suffix)]
    return original


def is_string_type(item: Any) -> bool:
    return isinstance(item, str)


def generate_feature_name_if_not_string(s: Any) -> str:
    if isinstance(s, str):
        return s

    return f"feature_{s}"


def truncate_str_from_middle(s: str, max_length: int) -> str:
    assert max_length > 5
    if len(s) <= max_length:
        return s
    else:
        left_part_len = (max_length - 3) // 2
        right_part_len = max_length - 3 - left_part_len
        return f"{s[:left_part_len]}...{s[-right_part_len:]}"


def _create_table(
    rows: list[list[str]], headers: list[str], column_sep: str = " " * 2, min_column_width: int = 4
) -> str:
    """
mlflow/data/evaluation_dataset.py:518:        return self._digest
tests/evaluate/logging/test_utils.py:130:        "dataset_digest",
```

## 原始行 103 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import hashlib, struct
import numpy as np, pandas as pd
from sklearn.datasets import load_iris
X,y=load_iris(return_X_y=True)

def hb(a):
 a=np.asarray(a)
 if a.dtype.kind=='O': return b''.join(struct.pack('>Q',int(x)) for x in pd.util.hash_array(a))
 return a.data.tobytes()
def g(data):
 h=hashlib.md5(usedforsecurity=False)
 for d in (data[0],data[1]):
  s=np.concatenate([d[:5],d[-5:]]) if len(d)>10 else d
  h.update(hb(s))
 return h.hexdigest()
print(g((X,y)))
# evaluation fixture every third
print(g((X[::3],y[::3])))
PY"
```

退出码：`0`

输出：
```
6d79021d96df949fb22aed60b05fd5b0
964c81757909e86bf5308f20285b5585
```

## 原始行 106 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import hashlib,struct,itertools
import numpy as np,pandas as pd
from sklearn.datasets import load_iris
X,y=load_iris(return_X_y=True);X=X[::3];y=y[::3]
def hb(a):
 a=np.asarray(a)
 return a.data.tobytes() if a.dtype.kind"'!='"'O' else b''.join(struct.pack('>Q',int(x)) for x in pd.util.hash_array(a))
samp=lambda a: np.concatenate([a[:5],a[-5:]]) if len(a)>10 else a
parts={'X':hb(samp(X)),'y':hb(samp(y)),'names':hb(np.array([f'feature_{i+1}' for i in range(4)])),'shape':str(X.shape).encode(),'cols':''.join([f'feature_{i+1}' for i in range(4)]).encode()}
for n in range(2,6):
 for ks in itertools.permutations(parts,n):
  h=hashlib.md5(usedforsecurity=False)
  for k in ks:h.update(parts[k])
  if h.hexdigest()=='99329a790dc483e7382c0d1d27aac3f3':print(ks)
print(parts.keys())
PY"
```

退出码：`0`

输出：
```
dict_keys(['X', 'y', 'names', 'shape', 'cols'])
```

## 原始行 109 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import hashlib,struct,itertools
import numpy as np,pandas as pd
from sklearn.datasets import load_iris
X,y=load_iris(return_X_y=True);X=X[::3];y=y[::3]
def hb(a):
 a=np.asarray(a)
 if a.ndim>1: a=a.flatten()
 return b''.join(struct.pack('>Q',int(x)) for x in pd.util.hash_array(a))
samp=lambda a: np.concatenate([a[:5],a[-5:]]) if len(a)>10 else a
for sample_separate in [False,True]:
 parts=[]
 if sample_separate: parts=[hb(X[:5]),hb(X[-5:]),hb(y[:5]),hb(y[-5:])]
 else: parts=[hb(samp(X)),hb(samp(y))]
 h=hashlib.md5(usedforsecurity=False)
 for p in parts:h.update(p)
 print(sample_separate,h.hexdigest())
PY"
```

退出码：`0`

输出：
```
False a21eecc0b9427cf8a93250f917b25788
True a21eecc0b9427cf8a93250f917b25788
```

## 原始行 112 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import hashlib,struct,itertools
import numpy as np,pandas as pd
from sklearn.datasets import load_iris
X,y=load_iris(return_X_y=True);X=X[::3];y=y[::3]
def hb(a):
 a=np.asarray(a).flatten(); return b''.join(struct.pack('>Q',int(x)) for x in pd.util.hash_array(a))
def raw(a):return np.asarray(a).data.tobytes()
samp=lambda a: np.concatenate([a[:5],a[-5:]]) if len(a)>10 else a
names=np.array([f'feature_{i+1}' for i in range(4)])
parts={'Xh':hb(samp(X)),'yh':hb(samp(y)),'nh':hb(names),'Xr':raw(samp(X)),'yr':raw(samp(y)),'nr':raw(names),'nstr':str(list(names)).encode()}
target='99329a790dc483e7382c0d1d27aac3f3'
for n in range(2,7):
 for ks in itertools.permutations(parts,n):
  h=hashlib.md5(usedforsecurity=False)
  for k in ks:h.update(parts[k])
  if h.hexdigest()==target:print(ks);raise SystemExit
print('no')
PY"
```

退出码：`0`

输出：
```
no
```

## 原始行 118 · error

```
{
  "id": "item_70",
  "type": "error",
  "message": "Falling back from WebSockets to HTTPS transport. stream disconnected before completion: tls handshake eof"
}
```
