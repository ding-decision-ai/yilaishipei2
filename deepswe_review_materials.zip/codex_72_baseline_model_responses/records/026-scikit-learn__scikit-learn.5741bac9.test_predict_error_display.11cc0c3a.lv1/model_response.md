# Codex baseline: scikit-learn__scikit-learn.5741bac9.test_predict_error_display.11cc0c3a.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the existing plotting module, exports, nearby visualization conventions, and the visible regression plot tests, then implement the class and run the focused test suite.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' sklearn/metrics/_plot/regression.py && rg -n \"PredictionErrorDisplay|regression.py\" sklearn/metrics sklearn/metrics/_plot -g '*.py' | head -200 && rg -n \"prediction error|actual_vs_predicted|residual_vs_predicted\" sklearn -g '*test*.py'"
```

退出码：`127`

输出：
```
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

import numbers

import numpy as np

from sklearn.utils import _safe_indexing, check_random_state




class PredictionErrorDisplay:
    """Visualization of the prediction error of a regression model.

    This tool can display "residuals vs predicted" or "actual vs predicted"
    using scatter plots to qualitatively assess the behavior of a regressor,
    preferably on held-out data points.

    See the details in the docstrings of
    :func:`~sklearn.metrics.PredictionErrorDisplay.from_estimator` or
    :func:`~sklearn.metrics.PredictionErrorDisplay.from_predictions` to
    create a visualizer. All parameters are stored as attributes.

    For general information regarding `scikit-learn` visualization tools, read
    more in the :ref:`Visualization Guide <visualizations>`.
    For details regarding interpreting these plots, refer to the
    :ref:`Model Evaluation Guide <visualization_regression_evaluation>`.

    .. versionadded:: 1.2

    Parameters
    ----------
    y_true : ndarray of shape (n_samples,)
        True values.

    y_pred : ndarray of shape (n_samples,)
        Prediction values.

    Attributes
    ----------
    line_ : matplotlib Artist
        Optimal line representing `y_true == y_pred`. Therefore, it is a
        diagonal line for `kind="predictions"` and a horizontal line for
        `kind="residuals"`.

    errors_lines_ : matplotlib Artist or None
        Residual lines. If `with_errors=False`, then it is set to `None`.

    scatter_ : matplotlib Artist
        Scatter data points.

    ax_ : matplotlib Axes
        Axes with the different matplotlib axis.

    figure_ : matplotlib Figure
        Figure containing the scatter and lines.

    See Also
    --------
    PredictionErrorDisplay.from_estimator : Prediction error visualization
        given an estimator and some data.
    PredictionErrorDisplay.from_predictions : Prediction error visualization
        given the true and predicted targets.

    Examples
    --------
    >>> import matplotlib.pyplot as plt
    >>> from sklearn.datasets import load_diabetes
    >>> from sklearn.linear_model import Ridge
    >>> from sklearn.metrics import PredictionErrorDisplay
    >>> X, y = load_diabetes(return_X_y=True)
    >>> ridge = Ridge().fit(X, y)
    >>> y_pred = ridge.predict(X)
    >>> display = PredictionErrorDisplay(y_true=y, y_pred=y_pred)
    >>> display.plot()
    <...>
    >>> plt.show()
    """

/bin/bash: line 1: rg: command not found
/bin/bash: line 1: rg: command not found
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc "wc -l sklearn/metrics/_plot/regression.py; sed -n '1,240p' sklearn/metrics/_plot/__init__.py; grep -R -n \"PredictionErrorDisplay\\|actual_vs_predicted\\|residual_vs_predicted\" sklearn/metrics --include='*.py' | head -240; find sklearn/metrics/_plot -maxdepth 2 -type f -name '*.py' -print"
```

退出码：`0`

输出：
```
80 sklearn/metrics/_plot/regression.py
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause
sklearn/metrics/_plot/regression.py:13:class PredictionErrorDisplay:
sklearn/metrics/_plot/regression.py:21:    :func:`~sklearn.metrics.PredictionErrorDisplay.from_estimator` or
sklearn/metrics/_plot/regression.py:22:    :func:`~sklearn.metrics.PredictionErrorDisplay.from_predictions` to
sklearn/metrics/_plot/regression.py:61:    PredictionErrorDisplay.from_estimator : Prediction error visualization
sklearn/metrics/_plot/regression.py:63:    PredictionErrorDisplay.from_predictions : Prediction error visualization
sklearn/metrics/_plot/regression.py:71:    >>> from sklearn.metrics import PredictionErrorDisplay
sklearn/metrics/_plot/regression.py:75:    >>> display = PredictionErrorDisplay(y_true=y, y_pred=y_pred)
sklearn/metrics/_plot/tests/test_common_curve_display.py:14:    PredictionErrorDisplay,
sklearn/metrics/_plot/tests/test_common_curve_display.py:270:        PredictionErrorDisplay,
sklearn/metrics/__init__.py:34:from sklearn.metrics._plot.regression import PredictionErrorDisplay
sklearn/metrics/__init__.py:108:    "PredictionErrorDisplay",
sklearn/metrics/_plot/regression.py
sklearn/metrics/_plot/det_curve.py
sklearn/metrics/_plot/confusion_matrix.py
sklearn/metrics/_plot/precision_recall_curve.py
sklearn/metrics/_plot/tests/test_common_curve_display.py
sklearn/metrics/_plot/tests/test_det_curve_display.py
sklearn/metrics/_plot/tests/test_precision_recall_display.py
sklearn/metrics/_plot/tests/test_roc_curve_display.py
sklearn/metrics/_plot/tests/__init__.py
sklearn/metrics/_plot/tests/test_confusion_matrix_display.py
sklearn/metrics/_plot/__init__.py
sklearn/metrics/_plot/roc_curve.py
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,360p' sklearn/metrics/_plot/tests/test_common_curve_display.py; sed -n '1,280p' sklearn/metrics/_plot/confusion_matrix.py; sed -n '1,240p' sklearn/metrics/_plot/roc_curve.py; grep -R -n \"_validate_params\\|validate_params\" sklearn/metrics/_plot sklearn/utils --include='*.py' | head -100; grep -R -n \"_check_pos_label_consistency\\|check_matplotlib_support\" sklearn --include='*.py' | head -100"
```

退出码：`0`

输出：
```
import numpy as np
import pytest

from sklearn.base import BaseEstimator, ClassifierMixin, clone
from sklearn.calibration import CalibrationDisplay
from sklearn.compose import make_column_transformer
from sklearn.datasets import load_iris
from sklearn.exceptions import NotFittedError
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    ConfusionMatrixDisplay,
    DetCurveDisplay,
    PrecisionRecallDisplay,
    PredictionErrorDisplay,
    RocCurveDisplay,
)
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor


@pytest.fixture(scope="module")
def data():
    return load_iris(return_X_y=True)


@pytest.fixture(scope="module")
def data_binary(data):
    X, y = data
    return X[y < 2], y[y < 2]


@pytest.mark.parametrize(
    "Display",
    [CalibrationDisplay, DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay],
)
def test_display_curve_error_classifier(pyplot, data, data_binary, Display):
    """Check that a proper error is raised when only binary classification is
    supported."""
    X, y = data
    X_binary, y_binary = data_binary
    clf = DecisionTreeClassifier().fit(X, y)

    # Case 1: multiclass classifier with multiclass target
    msg = "Expected 'estimator' to be a binary classifier. Got 3 classes instead."
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(clf, X, y)

    # Case 2: multiclass classifier with binary target
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(clf, X_binary, y_binary)

    # Case 3: binary classifier with multiclass target
    clf = DecisionTreeClassifier().fit(X_binary, y_binary)
    msg = "The target y is not binary. Got multiclass type of target."
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(clf, X, y)


@pytest.mark.parametrize(
    "Display",
    [CalibrationDisplay, DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay],
)
def test_display_curve_error_regression(pyplot, data_binary, Display):
    """Check that we raise an error with regressor."""

    # Case 1: regressor
    X, y = data_binary
    regressor = DecisionTreeRegressor().fit(X, y)

    msg = "Expected 'estimator' to be a binary classifier. Got DecisionTreeRegressor"
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(regressor, X, y)

    # Case 2: regression target
    classifier = DecisionTreeClassifier().fit(X, y)
    # Force `y_true` to be seen as a regression problem
    y = y + 0.5
    msg = "The target y is not binary. Got continuous type of target."
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(classifier, X, y)
    with pytest.raises(ValueError, match=msg):
        Display.from_predictions(y, regressor.fit(X, y).predict(X))


@pytest.mark.parametrize(
    "response_method, msg",
    [
        (
            "predict_proba",
            "MyClassifier has none of the following attributes: predict_proba.",
        ),
        (
            "decision_function",
            "MyClassifier has none of the following attributes: decision_function.",
        ),
        (
            "auto",
            (
                "MyClassifier has none of the following attributes: predict_proba,"
                " decision_function."
            ),
        ),
        (
            "bad_method",
            "MyClassifier has none of the following attributes: bad_method.",
        ),
    ],
)
@pytest.mark.parametrize(
    "Display", [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay]
)
def test_display_curve_error_no_response(
    pyplot,
    data_binary,
    response_method,
    msg,
    Display,
):
    """Check that a proper error is raised when the response method requested
    is not defined for the given trained classifier."""
    X, y = data_binary

    class MyClassifier(ClassifierMixin, BaseEstimator):
        def fit(self, X, y):
            self.classes_ = [0, 1]
            return self

    clf = MyClassifier().fit(X, y)

    with pytest.raises(AttributeError, match=msg):
        Display.from_estimator(clf, X, y, response_method=response_method)


@pytest.mark.parametrize(
    "Display", [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay]
)
@pytest.mark.parametrize("constructor_name", ["from_estimator", "from_predictions"])
def test_display_curve_estimator_name_multiple_calls(
    pyplot,
    data_binary,
    Display,
    constructor_name,
):
    """Check that passing `name` when calling `plot` will overwrite the original name
    in the legend."""
    X, y = data_binary
    clf_name = "my hand-crafted name"
    clf = LogisticRegression().fit(X, y)
    y_pred = clf.predict_proba(X)[:, 1]

    # safe guard for the binary if/else construction
    assert constructor_name in ("from_estimator", "from_predictions")

    if constructor_name == "from_estimator":
        disp = Display.from_estimator(clf, X, y, name=clf_name)
    else:
        disp = Display.from_predictions(y, y_pred, name=clf_name)
    # TODO: Clean-up once `estimator_name` deprecated in all displays
    if Display in (PrecisionRecallDisplay, RocCurveDisplay):
        assert disp.name == clf_name
    else:
        assert disp.estimator_name == clf_name
    pyplot.close("all")
    disp.plot()
    assert clf_name in disp.line_.get_label()
    pyplot.close("all")
    clf_name = "another_name"
    disp.plot(name=clf_name)
    assert clf_name in disp.line_.get_label()


@pytest.mark.parametrize(
    "clf",
    [
        LogisticRegression(),
        make_pipeline(StandardScaler(), LogisticRegression()),
        make_pipeline(
            make_column_transformer((StandardScaler(), [0, 1])), LogisticRegression()
        ),
    ],
)
@pytest.mark.parametrize(
    "Display", [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay]
)
def test_display_curve_not_fitted_errors_old_name(pyplot, data_binary, clf, Display):
    """Check that a proper error is raised when the classifier is not
    fitted."""
    X, y = data_binary
    # clone since we parametrize the test and the classifier will be fitted
    # when testing the second and subsequent plotting function
    model = clone(clf)
    with pytest.raises(NotFittedError):
        Display.from_estimator(model, X, y)
    model.fit(X, y)
    disp = Display.from_estimator(model, X, y)
    assert model.__class__.__name__ in disp.line_.get_label()
    # TODO: Clean-up once `estimator_name` deprecated in all displays
    if Display in (PrecisionRecallDisplay, RocCurveDisplay):
        assert disp.name == model.__class__.__name__
    else:
        assert disp.estimator_name == model.__class__.__name__


@pytest.mark.parametrize(
    "clf",
    [
        LogisticRegression(),
        make_pipeline(StandardScaler(), LogisticRegression()),
        make_pipeline(
            make_column_transformer((StandardScaler(), [0, 1])), LogisticRegression()
        ),
    ],
)
@pytest.mark.parametrize("Display", [RocCurveDisplay])
def test_display_curve_not_fitted_errors(pyplot, data_binary, clf, Display):
    """Check that a proper error is raised when the classifier is not fitted."""
    X, y = data_binary
    # clone since we parametrize the test and the classifier will be fitted
    # when testing the second and subsequent plotting function
    model = clone(clf)
    with pytest.raises(NotFittedError):
        Display.from_estimator(model, X, y)
    model.fit(X, y)
    disp = Display.from_estimator(model, X, y)
    assert model.__class__.__name__ in disp.line_.get_label()
    assert disp.name == model.__class__.__name__


@pytest.mark.parametrize(
    "Display", [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay]
)
def test_display_curve_n_samples_consistency(pyplot, data_binary, Display):
    """Check the error raised when `y_pred` or `sample_weight` have inconsistent
    length."""
    X, y = data_binary
    classifier = DecisionTreeClassifier().fit(X, y)

    msg = "Found input variables with inconsistent numbers of samples"
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(classifier, X[:-2], y)
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(classifier, X, y[:-2])
    with pytest.raises(ValueError, match=msg):
        Display.from_estimator(classifier, X, y, sample_weight=np.ones(X.shape[0] - 2))


@pytest.mark.parametrize(
    "Display", [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay]
)
def test_display_curve_error_pos_label(pyplot, data_binary, Display):
    """Check consistence of error message when `pos_label` should be specified."""
    X, y = data_binary
    y = y + 10

    classifier = DecisionTreeClassifier().fit(X, y)
    y_pred = classifier.predict_proba(X)[:, -1]
    msg = r"y_true takes value in {10, 11} and pos_label is not specified"
    with pytest.raises(ValueError, match=msg):
        Display.from_predictions(y, y_pred)


@pytest.mark.parametrize(
    "Display",
    [
        CalibrationDisplay,
        DetCurveDisplay,
        PrecisionRecallDisplay,
        RocCurveDisplay,
        PredictionErrorDisplay,
        ConfusionMatrixDisplay,
    ],
)
@pytest.mark.parametrize(
    "constructor",
    ["from_predictions", "from_estimator"],
)
def test_classifier_display_curve_named_constructor_return_type(
    pyplot, data_binary, Display, constructor
):
    """Check that named constructors return the correct type when subclassed.

    Non-regression test for:
    https://github.com/scikit-learn/scikit-learn/pull/27675
    """
    X, y = data_binary

    # This can be anything - we just need to check the named constructor return
    # type so the only requirement here is instantiating the class without error
    y_pred = y

    classifier = LogisticRegression().fit(X, y)

    class SubclassOfDisplay(Display):
        pass

    if constructor == "from_predictions":
        curve = SubclassOfDisplay.from_predictions(y, y_pred)
    else:  # constructor == "from_estimator"
        curve = SubclassOfDisplay.from_estimator(classifier, X, y)

    assert isinstance(curve, SubclassOfDisplay)


# TODO(1.10): Remove once deprecated in all Displays
@pytest.mark.parametrize(
    "Display, display_kwargs",
    [
        # TODO(1.10): Remove
        (
            PrecisionRecallDisplay,
            {"precision": np.array([1, 0.5, 0]), "recall": np.array([0, 0.5, 1])},
        ),
        # TODO(1.9): Remove
        (RocCurveDisplay, {"fpr": np.array([0, 0.5, 1]), "tpr": np.array([0, 0.5, 1])}),
    ],
)
def test_display_estimator_name_deprecation(pyplot, Display, display_kwargs):
    """Check deprecation of `estimator_name`."""
    with pytest.warns(FutureWarning, match="`estimator_name` is deprecated in"):
        Display(**display_kwargs, estimator_name="test")
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

from itertools import product

import numpy as np

from sklearn.base import is_classifier
from sklearn.metrics import confusion_matrix


from sklearn.utils.multiclass import unique_labels


class ConfusionMatrixDisplay:
    """Confusion Matrix visualization.

    It is recommended to use
    :func:`~sklearn.metrics.ConfusionMatrixDisplay.from_estimator` or
    :func:`~sklearn.metrics.ConfusionMatrixDisplay.from_predictions` to
    create a :class:`ConfusionMatrixDisplay`. All parameters are stored as
    attributes.

    For general information regarding `scikit-learn` visualization tools, see
    the :ref:`Visualization Guide <visualizations>`.
    For guidance on interpreting these plots, refer to the
    :ref:`Model Evaluation Guide <confusion_matrix>`.

    Parameters
    ----------
    confusion_matrix : ndarray of shape (n_classes, n_classes)
        Confusion matrix.

    display_labels : ndarray of shape (n_classes,), default=None
        Display labels for plot. If None, display labels are set from 0 to
        `n_classes - 1`.

    Attributes
    ----------
    im_ : matplotlib AxesImage
        Image representing the confusion matrix.

    text_ : ndarray of shape (n_classes, n_classes), dtype=matplotlib Text, \
            or None
        Array of matplotlib axes. `None` if `include_values` is false.

    ax_ : matplotlib Axes
        Axes with confusion matrix.

    figure_ : matplotlib Figure
        Figure containing the confusion matrix.

    See Also
    --------
    confusion_matrix : Compute Confusion Matrix to evaluate the accuracy of a
        classification.
    ConfusionMatrixDisplay.from_estimator : Plot the confusion matrix
        given an estimator, the data, and the label.
    ConfusionMatrixDisplay.from_predictions : Plot the confusion matrix
        given the true and predicted labels.

    Examples
    --------
    >>> import matplotlib.pyplot as plt
    >>> from sklearn.datasets import make_classification
    >>> from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay
    >>> from sklearn.model_selection import train_test_split
    >>> from sklearn.svm import SVC
    >>> X, y = make_classification(random_state=0)
    >>> X_train, X_test, y_train, y_test = train_test_split(X, y,
    ...                                                     random_state=0)
    >>> clf = SVC(random_state=0)
    >>> clf.fit(X_train, y_train)
    SVC(random_state=0)
    >>> predictions = clf.predict(X_test)
    >>> cm = confusion_matrix(y_test, predictions, labels=clf.classes_)
    >>> disp = ConfusionMatrixDisplay(confusion_matrix=cm,
    ...                               display_labels=clf.classes_)
    >>> disp.plot()
    <...>
    >>> plt.show()
    """

    def __init__(self, confusion_matrix, *, display_labels=None):
        self.confusion_matrix = confusion_matrix
        self.display_labels = display_labels

    def plot(
        self,
        *,
        include_values=True,
        cmap="viridis",
        xticks_rotation="horizontal",
        values_format=None,
        ax=None,
        colorbar=True,
        im_kw=None,
        text_kw=None,
    ):
        """Plot visualization.

        Parameters
        ----------
        include_values : bool, default=True
            Includes values in confusion matrix.

        cmap : str or matplotlib Colormap, default='viridis'
            Colormap recognized by matplotlib.

        xticks_rotation : {'vertical', 'horizontal'} or float, \
                         default='horizontal'
            Rotation of xtick labels.

        values_format : str, default=None
            Format specification for values in confusion matrix. If `None`,
            the format specification is 'd' or '.2g' whichever is shorter.

        ax : matplotlib axes, default=None
            Axes object to plot on. If `None`, a new figure and axes is
            created.

        colorbar : bool, default=True
            Whether or not to add a colorbar to the plot.

        im_kw : dict, default=None
            Dict with keywords passed to `matplotlib.pyplot.imshow` call.

        text_kw : dict, default=None
            Dict with keywords passed to `matplotlib.pyplot.text` call.

            .. versionadded:: 1.2

        Returns
        -------
        display : :class:`~sklearn.metrics.ConfusionMatrixDisplay`
            Returns a :class:`~sklearn.metrics.ConfusionMatrixDisplay` instance
            that contains all the information to plot the confusion matrix.
        """
        check_matplotlib_support("ConfusionMatrixDisplay.plot")
        import matplotlib.pyplot as plt

        if ax is None:
            fig, ax = plt.subplots()
        else:
            fig = ax.figure

        cm = self.confusion_matrix
        n_classes = cm.shape[0]

        default_im_kw = dict(interpolation="nearest", cmap=cmap)
        im_kw = im_kw or {}
        im_kw = _validate_style_kwargs(default_im_kw, im_kw)
        text_kw = text_kw or {}

        self.im_ = ax.imshow(cm, **im_kw)
        self.text_ = None
        cmap_min, cmap_max = self.im_.cmap(0), self.im_.cmap(1.0)

        if include_values:
            self.text_ = np.empty_like(cm, dtype=object)

            # print text with appropriate color depending on background
            thresh = (cm.max() + cm.min()) / 2.0

            for i, j in product(range(n_classes), range(n_classes)):
                color = cmap_max if cm[i, j] < thresh else cmap_min

                if values_format is None:
                    text_cm = format(cm[i, j], ".2g")
                    if cm.dtype.kind != "f":
                        text_d = format(cm[i, j], "d")
                        if len(text_d) < len(text_cm):
                            text_cm = text_d
                else:
                    text_cm = format(cm[i, j], values_format)

                default_text_kwargs = dict(ha="center", va="center", color=color)
                text_kwargs = _validate_style_kwargs(default_text_kwargs, text_kw)

                self.text_[i, j] = ax.text(j, i, text_cm, **text_kwargs)

        if self.display_labels is None:
            display_labels = np.arange(n_classes)
        else:
            display_labels = self.display_labels
        if colorbar:
            fig.colorbar(self.im_, ax=ax)
        ax.set(
            xticks=np.arange(n_classes),
            yticks=np.arange(n_classes),
            xticklabels=display_labels,
            yticklabels=display_labels,
            ylabel="True label",
            xlabel="Predicted label",
        )

        ax.set_ylim((n_classes - 0.5, -0.5))
        plt.setp(ax.get_xticklabels(), rotation=xticks_rotation)

        self.figure_ = fig
        self.ax_ = ax
        return self

    @classmethod
    def from_estimator(
        cls,
        estimator,
        X,
        y,
        *,
        labels=None,
        sample_weight=None,
        normalize=None,
        display_labels=None,
        include_values=True,
        xticks_rotation="horizontal",
        values_format=None,
        cmap="viridis",
        ax=None,
        colorbar=True,
        im_kw=None,
        text_kw=None,
    ):
        """Plot Confusion Matrix given an estimator and some data.

        For general information regarding `scikit-learn` visualization tools, see
        the :ref:`Visualization Guide <visualizations>`.
        For guidance on interpreting these plots, refer to the
        :ref:`Model Evaluation Guide <confusion_matrix>`.

        .. versionadded:: 1.0

        Parameters
        ----------
        estimator : estimator instance
            Fitted classifier or a fitted :class:`~sklearn.pipeline.Pipeline`
            in which the last estimator is a classifier.

        X : {array-like, sparse matrix} of shape (n_samples, n_features)
            Input values.

        y : array-like of shape (n_samples,)
            Target values.

        labels : array-like of shape (n_classes,), default=None
            List of labels to index the confusion matrix. This may be used to
            reorder or select a subset of labels. If `None` is given, those
            that appear at least once in `y_true` or `y_pred` are used in
            sorted order.

        sample_weight : array-like of shape (n_samples,), default=None
            Sample weights.

        normalize : {'true', 'pred', 'all'}, default=None
            Either to normalize the counts display in the matrix:

            - if `'true'`, the confusion matrix is normalized over the true
              conditions (e.g. rows);
            - if `'pred'`, the confusion matrix is normalized over the
              predicted conditions (e.g. columns);
            - if `'all'`, the confusion matrix is normalized by the total
              number of samples;
            - if `None` (default), the confusion matrix will not be normalized.

        display_labels : array-like of shape (n_classes,), default=None
            Target names used for plotting. By default, `labels` will be used
            if it is defined, otherwise the unique labels of `y_true` and
            `y_pred` will be used.

        include_values : bool, default=True
            Includes values in confusion matrix.

        xticks_rotation : {'vertical', 'horizontal'} or float, \
                default='horizontal'
            Rotation of xtick labels.

        values_format : str, default=None
            Format specification for values in confusion matrix. If `None`, the
            format specification is 'd' or '.2g' whichever is shorter.

# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause


import numpy as np

from sklearn.metrics._ranking import auc, roc_curve
from sklearn.utils import _safe_indexing
from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin, _check_param_lengths, _convert_to_list_leaving_none, _deprecate_estimator_name, _deprecate_y_pred_parameter, _despine








from sklearn.utils._response import _get_response_values_binary


class RocCurveDisplay(_BinaryClassifierCurveDisplayMixin):
    """ROC Curve visualization.

    It is recommended to use
    :func:`~sklearn.metrics.RocCurveDisplay.from_estimator` or
    :func:`~sklearn.metrics.RocCurveDisplay.from_predictions` or
    :func:`~sklearn.metrics.RocCurveDisplay.from_cv_results` to create
    a :class:`~sklearn.metrics.RocCurveDisplay`. All parameters are
    stored as attributes.

    For general information regarding `scikit-learn` visualization tools, see
    the :ref:`Visualization Guide <visualizations>`.
    For guidance on interpreting these plots, refer to the :ref:`Model
    Evaluation Guide <roc_metrics>`.

    Parameters
    ----------
    fpr : ndarray or list of ndarrays
        False positive rates. Each ndarray should contain values for a single curve.
        If plotting multiple curves, list should be of same length as `tpr`.

        .. versionchanged:: 1.7
            Now accepts a list for plotting multiple curves.

    tpr : ndarray or list of ndarrays
        True positive rates. Each ndarray should contain values for a single curve.
        If plotting multiple curves, list should be of same length as `fpr`.

        .. versionchanged:: 1.7
            Now accepts a list for plotting multiple curves.

    roc_auc : float or list of floats, default=None
        Area under ROC curve, used for labeling each curve in the legend.
        If plotting multiple curves, should be a list of the same length as `fpr`
        and `tpr`. If `None`, ROC AUC scores are not shown in the legend.

        .. versionchanged:: 1.7
            Now accepts a list for plotting multiple curves.

    name : str or list of str, default=None
        Name for labeling legend entries. The number of legend entries is determined
        by the `curve_kwargs` passed to `plot`, and is not affected by `name`.
        To label each curve, provide a list of strings. To avoid labeling
        individual curves that have the same appearance, a list cannot be used in
        conjunction with `curve_kwargs` being a dictionary or None. If a
        string is provided, it will be used to either label the single legend entry
        or if there are multiple legend entries, label each individual curve with
        the same name. If `None`, no name is shown in the legend.

        .. versionchanged:: 1.7
            `estimator_name` was deprecated in favor of `name`.

    pos_label : int, float, bool or str, default=None
        The class considered the positive class when ROC AUC metrics computed.
        If not `None`, this value is displayed in the x- and y-axes labels.

        .. versionadded:: 0.24

    estimator_name : str, default=None
        Name of estimator. If None, the estimator name is not shown.

        .. deprecated:: 1.7
            `estimator_name` is deprecated and will be removed in 1.9. Use `name`
            instead.

    Attributes
    ----------
    line_ : matplotlib Artist or list of matplotlib Artists
        ROC Curves.

        .. versionchanged:: 1.7
            This attribute can now be a list of Artists, for when multiple curves
            are plotted.

    chance_level_ : matplotlib Artist or None
        The chance level line. It is `None` if the chance level is not plotted.

        .. versionadded:: 1.3

    ax_ : matplotlib Axes
        Axes with ROC Curve.

    figure_ : matplotlib Figure
        Figure containing the curve.

    See Also
    --------
    roc_curve : Compute Receiver operating characteristic (ROC) curve.
    RocCurveDisplay.from_estimator : Plot Receiver Operating Characteristic
        (ROC) curve given an estimator and some data.
    RocCurveDisplay.from_predictions : Plot Receiver Operating Characteristic
        (ROC) curve given the true and predicted values.
    RocCurveDisplay.from_cv_results : Plot multi-fold ROC curves given
        cross-validation results.
    roc_auc_score : Compute the area under the ROC curve.

    Examples
    --------
    >>> import matplotlib.pyplot as plt
    >>> import numpy as np
    >>> from sklearn import metrics
    >>> y_true = np.array([0, 0, 1, 1])
    >>> y_score = np.array([0.1, 0.4, 0.35, 0.8])
    >>> fpr, tpr, thresholds = metrics.roc_curve(y_true, y_score)
    >>> roc_auc = metrics.auc(fpr, tpr)
    >>> display = metrics.RocCurveDisplay(fpr=fpr, tpr=tpr, roc_auc=roc_auc,
    ...                                   name='example estimator')
    >>> display.plot()
    <...>
    >>> plt.show()
    """

    def __init__(
        self,
        *,
        fpr,
        tpr,
        roc_auc=None,
        name=None,
        pos_label=None,
        estimator_name="deprecated",
    ):
        self.fpr = fpr
        self.tpr = tpr
        self.roc_auc = roc_auc
        self.name = _deprecate_estimator_name(estimator_name, name, "1.7")
        self.pos_label = pos_label

    def _validate_plot_params(self, *, ax, name):
        self.ax_, self.figure_, name = super()._validate_plot_params(ax=ax, name=name)

        fpr = _convert_to_list_leaving_none(self.fpr)
        tpr = _convert_to_list_leaving_none(self.tpr)
        roc_auc = _convert_to_list_leaving_none(self.roc_auc)
        name = _convert_to_list_leaving_none(name)

        optional = {"self.roc_auc": roc_auc}
        if isinstance(name, list) and len(name) != 1:
            optional.update({"'name' (or self.name)": name})
        _check_param_lengths(
            required={"self.fpr": fpr, "self.tpr": tpr},
            optional=optional,
            class_name="RocCurveDisplay",
        )
        return fpr, tpr, roc_auc, name

    def plot(
        self,
        ax=None,
        *,
        name=None,
        curve_kwargs=None,
        plot_chance_level=False,
        chance_level_kw=None,
        despine=False,
        **kwargs,
    ):
        """Plot visualization.

        Parameters
        ----------
        ax : matplotlib axes, default=None
            Axes object to plot on. If `None`, a new figure and axes is
            created.

        name : str or list of str, default=None
            Name for labeling legend entries. The number of legend entries
            is determined by `curve_kwargs`, and is not affected by `name`.
            To label each curve, provide a list of strings. To avoid labeling
            individual curves that have the same appearance, a list cannot be used in
            conjunction with `curve_kwargs` being a dictionary or None. If a
            string is provided, it will be used to either label the single legend entry
            or if there are multiple legend entries, label each individual curve with
            the same name. If `None`, set to `name` provided at `RocCurveDisplay`
            initialization. If still `None`, no name is shown in the legend.

            .. versionadded:: 1.7

        curve_kwargs : dict or list of dict, default=None
            Keywords arguments to be passed to matplotlib's `plot` function
            to draw individual ROC curves. For single curve plotting, should be
            a dictionary. For multi-curve plotting, if a list is provided the
            parameters are applied to the ROC curves of each CV fold
            sequentially and a legend entry is added for each curve.
            If a single dictionary is provided, the same parameters are applied
            to all ROC curves and a single legend entry for all curves is added,
            labeled with the mean ROC AUC score.

            .. versionadded:: 1.7

        plot_chance_level : bool, default=False
            Whether to plot the chance level.

            .. versionadded:: 1.3

        chance_level_kw : dict, default=None
            Keyword arguments to be passed to matplotlib's `plot` for rendering
            the chance level line.

            .. versionadded:: 1.3

        despine : bool, default=False
            Whether to remove the top and right spines from the plot.

            .. versionadded:: 1.6

        **kwargs : dict
            Keyword arguments to be passed to matplotlib's `plot`.

            .. deprecated:: 1.7
                kwargs is deprecated and will be removed in 1.9. Pass matplotlib
                arguments to `curve_kwargs` as a dictionary instead.

        Returns
        -------
        display : :class:`~sklearn.metrics.RocCurveDisplay`
            Object that stores computed values.
        """
        fpr, tpr, roc_auc, name = self._validate_plot_params(ax=ax, name=name)
        n_curves = len(fpr)
sklearn/utils/_chunking.py:11:from sklearn.utils._param_validation import Interval, validate_params
sklearn/utils/_chunking.py:25:@validate_params(
sklearn/utils/_chunking.py:81:@validate_params(
sklearn/utils/estimator_checks.py:77:    validate_params,
sklearn/utils/estimator_checks.py:692:@validate_params(
sklearn/utils/class_weight.py:9:from sklearn.utils._param_validation import StrOptions, validate_params
sklearn/utils/class_weight.py:13:@validate_params(
sklearn/utils/class_weight.py:106:@validate_params(
sklearn/utils/_param_validation.py:150:def validate_params(parameter_constraints, *, prefer_skip_nested_validation):
sklearn/utils/_param_validation.py:688:    @validate_params(
sklearn/utils/extmath.py:25:from sklearn.utils._param_validation import Interval, StrOptions, validate_params
sklearn/utils/extmath.py:384:@validate_params(
sklearn/utils/_mask.py:10:from sklearn.utils._param_validation import validate_params
sklearn/utils/_mask.py:70:@validate_params(
sklearn/utils/graph.py:10:from sklearn.utils._param_validation import Integral, Interval, validate_params
sklearn/utils/graph.py:16:@validate_params(
sklearn/utils/tests/test_param_validation.py:35:    validate_params,
sklearn/utils/tests/test_param_validation.py:41:@validate_params(
sklearn/utils/tests/test_param_validation.py:52:    @validate_params({"a": [Real]}, prefer_skip_nested_validation=True)
sklearn/utils/tests/test_param_validation.py:57:    @validate_params({"a": [Real]}, prefer_skip_nested_validation=True)
sklearn/utils/tests/test_param_validation.py:472:def test_validate_params():
sklearn/utils/tests/test_param_validation.py:473:    """Check that validate_params works no matter how the arguments are passed"""
sklearn/utils/tests/test_param_validation.py:506:def test_validate_params_missing_params():
sklearn/utils/tests/test_param_validation.py:511:    @validate_params({"a": [int]}, prefer_skip_nested_validation=True)
sklearn/utils/tests/test_param_validation.py:519:    """Check that validate_params functions can be decorated"""
sklearn/utils/tests/test_param_validation.py:533:def test_validate_params_method():
sklearn/utils/tests/test_param_validation.py:534:    """Check that validate_params works with methods"""
sklearn/utils/tests/test_param_validation.py:549:def test_validate_params_estimator():
sklearn/utils/tests/test_param_validation.py:550:    """Check that validate_params works with Estimator instances"""
sklearn/utils/tests/test_param_validation.py:569:    @validate_params(
sklearn/utils/tests/test_param_validation.py:593:    @validate_params(
sklearn/utils/tests/test_param_validation.py:615:def test_validate_params_set_param_constraints_attribute():
sklearn/utils/tests/test_param_validation.py:616:    """Check that the validate_params decorator properly sets the parameter constraints
sklearn/utils/tests/test_param_validation.py:624:    """Check that validate_params raise a deprecation message but still passes
sklearn/utils/tests/test_param_validation.py:628:    @validate_params({"param": ["boolean"]}, prefer_skip_nested_validation=True)
sklearn/utils/tests/test_param_validation.py:640:    @validate_params(
sklearn/utils/tests/test_param_validation.py:724:    @validate_params({"a": [int]}, prefer_skip_nested_validation=True)
sklearn/utils/tests/test_param_validation.py:740:    @validate_params({"a": [int]}, prefer_skip_nested_validation=True)
sklearn/utils/tests/test_param_validation.py:744:    @validate_params(
sklearn/utils/tests/test_param_validation.py:777:    @validate_params(
sklearn/utils/_indexing.py:18:from sklearn.utils._param_validation import Interval, validate_params
sklearn/utils/_indexing.py:497:@validate_params(
sklearn/calibration.py:62:    _check_pos_label_consistency,
sklearn/calibration.py:1283:    pos_label = _check_pos_label_consistency(pos_label, y_true)
sklearn/inspection/_plot/partial_dependence.py:17:from sklearn.utils._optional_dependencies import check_matplotlib_support
sklearn/inspection/_plot/partial_dependence.py:540:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
sklearn/inspection/_plot/partial_dependence.py:1223:        check_matplotlib_support("plot_partial_dependence")
sklearn/inspection/_plot/decision_boundary.py:11:from sklearn.utils._optional_dependencies import check_matplotlib_support
sklearn/inspection/_plot/decision_boundary.py:206:        check_matplotlib_support("DecisionBoundaryDisplay.plot")
sklearn/inspection/_plot/decision_boundary.py:432:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
sklearn/inspection/_partial_dependence.py:27:from sklearn.utils._optional_dependencies import check_matplotlib_support  # noqa: F401
sklearn/metrics/_plot/confusion_matrix.py:139:        check_matplotlib_support("ConfusionMatrixDisplay.plot")
sklearn/metrics/_plot/confusion_matrix.py:331:        check_matplotlib_support(method_name)
sklearn/metrics/_plot/confusion_matrix.py:472:        check_matplotlib_support(f"{cls.__name__}.from_predictions")
sklearn/metrics/_classification.py:57:    _check_pos_label_consistency,
sklearn/metrics/_classification.py:3600:        pos_label = _check_pos_label_consistency(pos_label, y_true)
sklearn/metrics/_ranking.py:40:from sklearn.utils.validation import _check_pos_label_consistency, _check_sample_weight
sklearn/metrics/_ranking.py:886:    pos_label = _check_pos_label_consistency(pos_label, y_true)
sklearn/model_selection/_plot.py:25:        check_matplotlib_support(f"{self.__class__.__name__}.plot")
sklearn/model_selection/_plot.py:471:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
sklearn/model_selection/_plot.py:850:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
sklearn/utils/validation.py:2582:def _check_pos_label_consistency(pos_label, y_true):
sklearn/utils/_plotting.py:13:from sklearn.utils.validation import _check_pos_label_consistency, _num_samples
sklearn/utils/_plotting.py:24:        check_matplotlib_support(f"{self.__class__.__name__}.plot")
sklearn/utils/_plotting.py:40:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
sklearn/utils/_plotting.py:57:        check_matplotlib_support(f"{cls.__name__}.from_predictions")
sklearn/utils/_plotting.py:66:        pos_label = _check_pos_label_consistency(pos_label, y_true)
sklearn/utils/_plotting.py:81:        check_matplotlib_support(f"{cls.__name__}.from_cv_results")
sklearn/utils/tests/test_validation.py:71:    _check_pos_label_consistency,
sklearn/utils/tests/test_validation.py:1668:def test_check_pos_label_consistency(y_true):
sklearn/utils/tests/test_validation.py:1669:    assert _check_pos_label_consistency(None, y_true) == 1
sklearn/utils/tests/test_validation.py:1678:def test_check_pos_label_consistency_array_api(array_namespace, device, dtype, y_true):
sklearn/utils/tests/test_validation.py:1682:        assert _check_pos_label_consistency(None, arr) == 1
sklearn/utils/tests/test_validation.py:1686:def test_check_pos_label_consistency_invalid(y_true):
sklearn/utils/tests/test_validation.py:1688:        _check_pos_label_consistency(None, y_true)
sklearn/utils/tests/test_validation.py:1690:    assert _check_pos_label_consistency("a", y_true) == "a"
sklearn/utils/tests/test_validation.py:1699:def test_check_pos_label_consistency_invalid_array_api(
sklearn/utils/tests/test_validation.py:1706:            _check_pos_label_consistency(None, arr)
sklearn/utils/tests/test_validation.py:1708:        assert _check_pos_label_consistency("a", arr) == "a"
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "nl -ba sklearn/metrics/_plot/confusion_matrix.py | sed -n '1,35p'; grep -R -n \"def _validate_style_kwargs\" sklearn | head -20; sed -n '1,130p' sklearn/utils/_plotting.py; find sklearn -path '*test*regression*' -o -name 'test_regression_display.py' -print; git status --short"
```

退出码：`0`

输出：
```
     1	# Authors: The scikit-learn developers
     2	# SPDX-License-Identifier: BSD-3-Clause
     3	
     4	from itertools import product
     5	
     6	import numpy as np
     7	
     8	from sklearn.base import is_classifier
     9	from sklearn.metrics import confusion_matrix
    10	
    11	
    12	from sklearn.utils.multiclass import unique_labels
    13	
    14	
    15	class ConfusionMatrixDisplay:
    16	    """Confusion Matrix visualization.
    17	
    18	    It is recommended to use
    19	    :func:`~sklearn.metrics.ConfusionMatrixDisplay.from_estimator` or
    20	    :func:`~sklearn.metrics.ConfusionMatrixDisplay.from_predictions` to
    21	    create a :class:`ConfusionMatrixDisplay`. All parameters are stored as
    22	    attributes.
    23	
    24	    For general information regarding `scikit-learn` visualization tools, see
    25	    the :ref:`Visualization Guide <visualizations>`.
    26	    For guidance on interpreting these plots, refer to the
    27	    :ref:`Model Evaluation Guide <confusion_matrix>`.
    28	
    29	    Parameters
    30	    ----------
    31	    confusion_matrix : ndarray of shape (n_classes, n_classes)
    32	        Confusion matrix.
    33	
    34	    display_labels : ndarray of shape (n_classes,), default=None
    35	        Display labels for plot. If None, display labels are set from 0 to
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause
import warnings
from collections.abc import Mapping

import numpy as np

from sklearn.utils import check_consistent_length

from sklearn.utils._response import _get_response_values_binary
from sklearn.utils.fixes import parse_version
from sklearn.utils.multiclass import type_of_target
from sklearn.utils.validation import _check_pos_label_consistency, _num_samples


class _BinaryClassifierCurveDisplayMixin:
    """Mixin class to be used in Displays requiring a binary classifier.

    The aim of this class is to centralize some validations regarding the estimator and
    the target and gather the response of the estimator.
    """

    def _validate_plot_params(self, *, ax=None, name=None):
        check_matplotlib_support(f"{self.__class__.__name__}.plot")
        import matplotlib.pyplot as plt

        if ax is None:
            _, ax = plt.subplots()

        # Display classes are in process of changing from `estimator_name` to `name`.
        # Try old attr name: `estimator_name` first.
        if name is None:
            name = getattr(self, "estimator_name", getattr(self, "name", None))
        return ax, ax.figure, name

    @classmethod
    def _validate_and_get_response_values(
        cls, estimator, X, y, *, response_method="auto", pos_label=None, name=None
    ):
        check_matplotlib_support(f"{cls.__name__}.from_estimator")

        name = estimator.__class__.__name__ if name is None else name

        y_pred, pos_label = _get_response_values_binary(
            estimator,
            X,
            response_method=response_method,
            pos_label=pos_label,
        )

        return y_pred, pos_label, name

    @classmethod
    def _validate_from_predictions_params(
        cls, y_true, y_pred, *, sample_weight=None, pos_label=None, name=None
    ):
        check_matplotlib_support(f"{cls.__name__}.from_predictions")

        if type_of_target(y_true) != "binary":
            raise ValueError(
                f"The target y is not binary. Got {type_of_target(y_true)} type of"
                " target."
            )

        check_consistent_length(y_true, y_pred, sample_weight)
        pos_label = _check_pos_label_consistency(pos_label, y_true)

        name = name if name is not None else "Classifier"

        return pos_label, name

    @classmethod
    def _validate_from_cv_results_params(
        cls,
        cv_results,
        X,
        y,
        *,
        sample_weight,
    ):
        check_matplotlib_support(f"{cls.__name__}.from_cv_results")

        required_keys = {"estimator", "indices"}
        if not all(key in cv_results for key in required_keys):
            raise ValueError(
                "`cv_results` does not contain one of the following required keys: "
                f"{required_keys}. Set explicitly the parameters "
                "`return_estimator=True` and `return_indices=True` to the function"
                "`cross_validate`."
            )

        train_size, test_size = (
            len(cv_results["indices"]["train"][0]),
            len(cv_results["indices"]["test"][0]),
        )

        if _num_samples(X) != train_size + test_size:
            raise ValueError(
                "`X` does not contain the correct number of samples. "
                f"Expected {train_size + test_size}, got {_num_samples(X)}."
            )

        if type_of_target(y) != "binary":
            raise ValueError(
                f"The target `y` is not binary. Got {type_of_target(y)} type of target."
            )
        check_consistent_length(X, y, sample_weight)

    @staticmethod
    def _get_legend_label(curve_legend_metric, curve_name, legend_metric_name):
        """Helper to get legend label using `name` and `legend_metric`"""
        if curve_legend_metric is not None and curve_name is not None:
            label = f"{curve_name} ({legend_metric_name} = {curve_legend_metric:0.2f})"
        elif curve_legend_metric is not None:
            label = f"{legend_metric_name} = {curve_legend_metric:0.2f}"
        elif curve_name is not None:
            label = curve_name
        else:
            label = None
        return label

    @staticmethod
    def _validate_curve_kwargs(
        n_curves,
        name,
        legend_metric,
        legend_metric_name,
        curve_kwargs,
        **kwargs,
    ):
```

## 原始行 18 · agent_message

```
The target file is a deliberate stub, while the public export already exists. I’m now checking the repository’s current helper APIs and parameter-validation conventions so the implementation fits this tree’s version and hidden tests, especially style-alias conflicts and subsampling edge cases.
```

## 原始行 20 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"validate_style_kwargs\" sklearn --include='*.py' || true; grep -R -n \"default_.*kw\\|style_kwargs\" sklearn/*/_plot sklearn/metrics/_plot --include='*.py' | head -120; grep -R -n \"When an integer, subsample\\|subsample should be\\|subsample=\" sklearn --include='*.py' | head -100; grep -n \"__version__\" sklearn/__init__.py; grep -n \"version =\" pyproject.toml setup.cfg 2>/dev/null | head -20; sed -n '1,220p' sklearn/utils/_optional_dependencies.py; grep -R -n \"check_consistent_length(y_true, y_pred\" sklearn/metrics --include='*.py' | head -30"
```

退出码：`0`

输出：
```
sklearn/calibration.py:1441:        line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)
sklearn/inspection/_plot/partial_dependence.py:18:from sklearn.utils._plotting import _validate_style_kwargs
sklearn/inspection/_plot/partial_dependence.py:1312:        contour_kw = _validate_style_kwargs(default_contour_kws, contour_kw)
sklearn/inspection/_plot/partial_dependence.py:1443:                line_kw = _validate_style_kwargs(default_line_kws, line_kw)
sklearn/inspection/_plot/partial_dependence.py:1445:                ice_lines_kw = _validate_style_kwargs(
sklearn/inspection/_plot/partial_dependence.py:1446:                    _validate_style_kwargs(default_ice_lines_kws, line_kw), ice_lines_kw
sklearn/inspection/_plot/partial_dependence.py:1450:                pd_line_kw = _validate_style_kwargs(
sklearn/inspection/_plot/partial_dependence.py:1451:                    _validate_style_kwargs(default_pd_lines_kws, line_kw), pd_line_kw
sklearn/inspection/_plot/partial_dependence.py:1455:                bar_kw = _validate_style_kwargs(default_bar_kws, bar_kw)
sklearn/inspection/_plot/partial_dependence.py:1458:                heatmap_kw = _validate_style_kwargs(default_heatmap_kw, heatmap_kw)
sklearn/metrics/_plot/confusion_matrix.py:152:        im_kw = _validate_style_kwargs(default_im_kw, im_kw)
sklearn/metrics/_plot/confusion_matrix.py:178:                text_kwargs = _validate_style_kwargs(default_text_kwargs, text_kw)
sklearn/metrics/_plot/precision_recall_curve.py:217:        line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)
sklearn/metrics/_plot/precision_recall_curve.py:255:            chance_level_line_kw = _validate_style_kwargs(
sklearn/metrics/_plot/roc_curve.py:268:        chance_level_kw = _validate_style_kwargs(
sklearn/utils/_plotting.py:238:            _validate_style_kwargs({"label": label}, curve_kwargs[fold_idx])
sklearn/utils/tests/test_plotting.py:11:    _validate_style_kwargs,
sklearn/utils/tests/test_plotting.py:473:def test_validate_style_kwargs(default_kwargs, user_kwargs, expected):
sklearn/utils/tests/test_plotting.py:474:    """Check the behaviour of `validate_style_kwargs` with various type of entries."""
sklearn/utils/tests/test_plotting.py:475:    result = _validate_style_kwargs(default_kwargs, user_kwargs)
sklearn/utils/tests/test_plotting.py:486:def test_validate_style_kwargs_error(default_kwargs, user_kwargs):
sklearn/utils/tests/test_plotting.py:487:    """Check that `validate_style_kwargs` raises TypeError"""
sklearn/utils/tests/test_plotting.py:489:        _validate_style_kwargs(default_kwargs, user_kwargs)
sklearn/inspection/_plot/partial_dependence.py:18:from sklearn.utils._plotting import _validate_style_kwargs
sklearn/inspection/_plot/partial_dependence.py:1048:            default_im_kw = dict(interpolation="nearest", cmap="viridis")
sklearn/inspection/_plot/partial_dependence.py:1049:            im_kw = {**default_im_kw, **heatmap_kw}
sklearn/inspection/_plot/partial_dependence.py:1311:        default_contour_kws = {"alpha": 0.75}
sklearn/inspection/_plot/partial_dependence.py:1312:        contour_kw = _validate_style_kwargs(default_contour_kws, contour_kw)
sklearn/inspection/_plot/partial_dependence.py:1417:                default_line_kws = {
sklearn/inspection/_plot/partial_dependence.py:1422:                    default_ice_lines_kws = {"alpha": 0.3, "linewidth": 0.5}
sklearn/inspection/_plot/partial_dependence.py:1423:                    default_pd_lines_kws = {}
sklearn/inspection/_plot/partial_dependence.py:1427:                    default_ice_lines_kws = {
sklearn/inspection/_plot/partial_dependence.py:1432:                    default_pd_lines_kws = {
sklearn/inspection/_plot/partial_dependence.py:1437:                    default_ice_lines_kws = {}
sklearn/inspection/_plot/partial_dependence.py:1438:                    default_pd_lines_kws = {}
sklearn/inspection/_plot/partial_dependence.py:1440:                default_ice_lines_kws = {**default_line_kws, **default_ice_lines_kws}
sklearn/inspection/_plot/partial_dependence.py:1441:                default_pd_lines_kws = {**default_line_kws, **default_pd_lines_kws}
sklearn/inspection/_plot/partial_dependence.py:1443:                line_kw = _validate_style_kwargs(default_line_kws, line_kw)
sklearn/inspection/_plot/partial_dependence.py:1445:                ice_lines_kw = _validate_style_kwargs(
sklearn/inspection/_plot/partial_dependence.py:1446:                    _validate_style_kwargs(default_ice_lines_kws, line_kw), ice_lines_kw
sklearn/inspection/_plot/partial_dependence.py:1450:                pd_line_kw = _validate_style_kwargs(
sklearn/inspection/_plot/partial_dependence.py:1451:                    _validate_style_kwargs(default_pd_lines_kws, line_kw), pd_line_kw
sklearn/inspection/_plot/partial_dependence.py:1454:                default_bar_kws = {"color": "C0"}
sklearn/inspection/_plot/partial_dependence.py:1455:                bar_kw = _validate_style_kwargs(default_bar_kws, bar_kw)
sklearn/inspection/_plot/partial_dependence.py:1457:                default_heatmap_kw = {}
sklearn/inspection/_plot/partial_dependence.py:1458:                heatmap_kw = _validate_style_kwargs(default_heatmap_kw, heatmap_kw)
sklearn/metrics/_plot/confusion_matrix.py:150:        default_im_kw = dict(interpolation="nearest", cmap=cmap)
sklearn/metrics/_plot/confusion_matrix.py:152:        im_kw = _validate_style_kwargs(default_im_kw, im_kw)
sklearn/metrics/_plot/confusion_matrix.py:177:                default_text_kwargs = dict(ha="center", va="center", color=color)
sklearn/metrics/_plot/confusion_matrix.py:178:                text_kwargs = _validate_style_kwargs(default_text_kwargs, text_kw)
sklearn/metrics/_plot/precision_recall_curve.py:207:        default_line_kwargs = {"drawstyle": "steps-post"}
sklearn/metrics/_plot/precision_recall_curve.py:209:            default_line_kwargs["label"] = (
sklearn/metrics/_plot/precision_recall_curve.py:213:            default_line_kwargs["label"] = f"AP = {self.average_precision:0.2f}"
sklearn/metrics/_plot/precision_recall_curve.py:215:            default_line_kwargs["label"] = name
sklearn/metrics/_plot/precision_recall_curve.py:217:        line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)
sklearn/metrics/_plot/precision_recall_curve.py:246:            default_chance_level_line_kw = {
sklearn/metrics/_plot/precision_recall_curve.py:255:            chance_level_line_kw = _validate_style_kwargs(
sklearn/metrics/_plot/precision_recall_curve.py:256:                default_chance_level_line_kw, chance_level_kw
sklearn/metrics/_plot/roc_curve.py:259:        default_chance_level_line_kw = {
sklearn/metrics/_plot/roc_curve.py:268:        chance_level_kw = _validate_style_kwargs(
sklearn/metrics/_plot/roc_curve.py:269:            default_chance_level_line_kw, chance_level_kw
sklearn/metrics/_plot/confusion_matrix.py:150:        default_im_kw = dict(interpolation="nearest", cmap=cmap)
sklearn/metrics/_plot/confusion_matrix.py:152:        im_kw = _validate_style_kwargs(default_im_kw, im_kw)
sklearn/metrics/_plot/confusion_matrix.py:177:                default_text_kwargs = dict(ha="center", va="center", color=color)
sklearn/metrics/_plot/confusion_matrix.py:178:                text_kwargs = _validate_style_kwargs(default_text_kwargs, text_kw)
sklearn/metrics/_plot/precision_recall_curve.py:207:        default_line_kwargs = {"drawstyle": "steps-post"}
sklearn/metrics/_plot/precision_recall_curve.py:209:            default_line_kwargs["label"] = (
sklearn/metrics/_plot/precision_recall_curve.py:213:            default_line_kwargs["label"] = f"AP = {self.average_precision:0.2f}"
sklearn/metrics/_plot/precision_recall_curve.py:215:            default_line_kwargs["label"] = name
sklearn/metrics/_plot/precision_recall_curve.py:217:        line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)
sklearn/metrics/_plot/precision_recall_curve.py:246:            default_chance_level_line_kw = {
sklearn/metrics/_plot/precision_recall_curve.py:255:            chance_level_line_kw = _validate_style_kwargs(
sklearn/metrics/_plot/precision_recall_curve.py:256:                default_chance_level_line_kw, chance_level_kw
sklearn/metrics/_plot/roc_curve.py:259:        default_chance_level_line_kw = {
sklearn/metrics/_plot/roc_curve.py:268:        chance_level_kw = _validate_style_kwargs(
sklearn/metrics/_plot/roc_curve.py:269:            default_chance_level_line_kw, chance_level_kw
sklearn/inspection/_plot/partial_dependence.py:230:        subsample=1000,
sklearn/inspection/_plot/partial_dependence.py:270:        subsample=1000,
sklearn/inspection/_plot/partial_dependence.py:710:                    f"When an integer, subsample={subsample} should be positive."
sklearn/inspection/_plot/partial_dependence.py:715:                    f"When a floating-point, subsample={subsample} should be in "
sklearn/inspection/_plot/partial_dependence.py:772:            subsample=subsample,
sklearn/inspection/_plot/tests/test_plot_partial_dependence.py:161:        subsample=subsample,
sklearn/inspection/_plot/tests/test_plot_partial_dependence.py:736:            "When an integer, subsample=-1 should be positive.",
sklearn/inspection/_plot/tests/test_plot_partial_dependence.py:741:            r"When a floating-point, subsample=1.2 should be in the \(0, 1\) range",
sklearn/inspection/_plot/tests/test_plot_partial_dependence.py:935:        subsample=20,
sklearn/inspection/_plot/tests/test_plot_partial_dependence.py:1260:        subsample=5,
sklearn/utils/_test_common/instance_generator.py:572:            dict(strategy="quantile", subsample=None, quantile_method="inverted_cdf"),
sklearn/utils/_test_common/instance_generator.py:575:                subsample=None,
sklearn/utils/_test_common/instance_generator.py:578:            dict(strategy="uniform", subsample=None),
sklearn/preprocessing/_discretization.py:80:        `subsample=None` means that all the training samples are used when
sklearn/preprocessing/_discretization.py:225:        subsample=200_000,
sklearn/preprocessing/_data.py:2699:        Disable subsampling by setting `subsample=None`.
sklearn/preprocessing/_data.py:2779:        subsample=10_000,
sklearn/preprocessing/_data.py:3100:    subsample=int(1e5),
sklearn/preprocessing/_data.py:3153:        Disable subsampling by setting `subsample=None`.
sklearn/preprocessing/_data.py:3225:        subsample=subsample,
sklearn/preprocessing/tests/test_discretization.py:461:        n_bins=3, strategy=strategy, quantile_method=quantile_method, subsample=None
sklearn/preprocessing/tests/test_discretization.py:558:    kbd_without_subsampling.set_params(subsample=None)
sklearn/preprocessing/tests/test_discretization.py:616:            subsample=50000,
sklearn/preprocessing/tests/test_discretization.py:622:            strategy=strategy, subsample=50000, random_state=global_random_seed
sklearn/preprocessing/tests/test_discretization.py:627:    kbd_no_subsampling.set_params(subsample=None)
sklearn/preprocessing/tests/test_data.py:1314:        QuantileTransformer(subsample=10).fit(X)
sklearn/preprocessing/tests/test_data.py:1404:        ignore_implicit_zeros=True, n_quantiles=5, subsample=8, random_state=0
sklearn/preprocessing/tests/test_data.py:1461:            subsample=n_samples // 10,
sklearn/preprocessing/tests/test_data.py:1480:            subsample=n_samples // 10,
sklearn/preprocessing/tests/test_data.py:1493:    """Check the behaviour of `QuantileTransformer` when `subsample=None`."""
sklearn/preprocessing/tests/test_data.py:1497:    transformer = QuantileTransformer(n_quantiles=n_quantiles, subsample=None).fit(X)
sklearn/ensemble/_gb.py:1480:        subsample=1.0,
sklearn/ensemble/_gb.py:1508:            subsample=subsample,
sklearn/ensemble/_gb.py:2086:        subsample=1.0,
sklearn/ensemble/_gb.py:2115:            subsample=subsample,
sklearn/ensemble/_hist_gradient_boosting/binning.py:165:        subsample=int(2e5),
sklearn/ensemble/_hist_gradient_boosting/tests/test_binning.py:254:    mapper_no_subsample = _BinMapper(subsample=None, random_state=0).fit(DATA)
sklearn/ensemble/_hist_gradient_boosting/tests/test_binning.py:255:    mapper_subsample = _BinMapper(subsample=256, random_state=0).fit(DATA)
sklearn/ensemble/tests/test_gradient_boosting.py:160:            subsample=subsample,
sklearn/ensemble/tests/test_gradient_boosting.py:196:        subsample=subsample,
sklearn/ensemble/tests/test_gradient_boosting.py:605:        n_estimators=100, random_state=1, subsample=0.5
sklearn/ensemble/tests/test_gradient_boosting.py:622:        n_estimators=100, random_state=1, subsample=0.5
sklearn/ensemble/tests/test_gradient_boosting.py:631:        subsample=0.5,
sklearn/ensemble/tests/test_gradient_boosting.py:658:        subsample=1.0,
sklearn/ensemble/tests/test_gradient_boosting.py:668:        n_estimators=100, loss="log_loss", random_state=1, subsample=0.5
sklearn/ensemble/tests/test_gradient_boosting.py:681:        subsample=0.5,
sklearn/ensemble/tests/test_gradient_boosting.py:706:        n_estimators=100, random_state=1, verbose=1, subsample=0.8
sklearn/ensemble/tests/test_gradient_boosting.py:838:        subsample=0.5,
sklearn/ensemble/tests/test_gradient_boosting.py:891:    est.set_params(n_estimators=110, subsample=0.5)
sklearn/ensemble/tests/test_gradient_boosting.py:908:    est = Cls(n_estimators=200, max_depth=1, subsample=0.5, random_state=1)
sklearn/ensemble/tests/test_gradient_boosting.py:912:        n_estimators=100, max_depth=1, subsample=0.5, random_state=1, warm_start=True
sklearn/ensemble/tests/test_gradient_boosting.py:932:        n_estimators=100, max_depth=1, subsample=0.5, random_state=1, warm_start=True
sklearn/ensemble/tests/test_gradient_boosting.py:945:        subsample=0.5,
sklearn/ensemble/tests/test_gradient_boosting.py:997:    est = Cls(n_estimators=20, max_depth=1, random_state=1, subsample=0.5)
sklearn/ensemble/tests/test_gradient_boosting.py:1017:        n_estimators=20, max_depth=1, random_state=1, subsample=0.5, warm_start=True
45:__version__ = "1.8.dev0"
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause






















def check_pandas_support(caller_name):
    """Raise ImportError with detailed error message if pandas is not installed.

    Plot utilities like :func:`fetch_openml` should lazily import
    pandas and call this helper before any computation.

    Parameters
    ----------
    caller_name : str
        The name of the caller that requires pandas.

    Returns
    -------
    pandas
        The pandas package.
    """
    try:
        import pandas

        return pandas
    except ImportError as e:
        raise ImportError("{} requires pandas.".format(caller_name)) from esklearn/metrics/_classification.py:104:    check_consistent_length(y_true, y_pred, sample_weight)
sklearn/metrics/_regression.py:113:    check_consistent_length(y_true, y_pred, sample_weight)
```

## 原始行 23 · command_execution

命令：
```
/bin/bash -lc "sed -n '180,285p' sklearn/utils/_plotting.py; sed -n '450,510p' sklearn/utils/tests/test_plotting.py; sed -n '680,730p' sklearn/inspection/_plot/partial_dependence.py; grep -R -n \"def check_matplotlib_support\" . --exclude-dir=.git --include='*.py' || true; grep -R -n \"from sklearn.utils._optional_dependencies import\" sklearn/metrics/_plot sklearn/calibration.py --include='*.py'; grep -R -n \"from sklearn.utils._plotting import\" sklearn/metrics/_plot sklearn/calibration.py --include='*.py' | head -60; git diff --stat; git status --short"
```

退出码：`0`

输出：
```
        if (
            isinstance(name, list)
            and len(name) != 1
            and not isinstance(curve_kwargs, list)
        ):
            raise ValueError(
                "To avoid labeling individual curves that have the same appearance, "
                f"`curve_kwargs` should be a list of {n_curves} dictionaries. "
                "Alternatively, set `name` to `None` or a single string to label "
                "a single legend entry with mean ROC AUC score of all curves."
            )

        # Ensure `name` is of the correct length
        if isinstance(name, str):
            name = [name]
        if isinstance(name, list) and len(name) == 1:
            name = name * n_curves
        name = [None] * n_curves if name is None else name

        # Ensure `curve_kwargs` is of correct length
        if isinstance(curve_kwargs, Mapping):
            curve_kwargs = [curve_kwargs] * n_curves

        default_multi_curve_kwargs = {"alpha": 0.5, "linestyle": "--", "color": "blue"}
        if curve_kwargs is None:
            if n_curves > 1:
                curve_kwargs = [default_multi_curve_kwargs] * n_curves
            else:
                curve_kwargs = [{}]

        labels = []
        if "mean" in legend_metric:
            label_aggregate = _BinaryClassifierCurveDisplayMixin._get_legend_label(
                legend_metric["mean"], name[0], legend_metric_name
            )
            # Note: "std" always `None` when "mean" is `None` - no metric value added
            # to label in this case
            if legend_metric["std"] is not None:
                # Add the "+/- std" to the end (in brackets if name provided)
                if name[0] is not None:
                    label_aggregate = (
                        label_aggregate[:-1] + f" +/- {legend_metric['std']:0.2f})"
                    )
                else:
                    label_aggregate = (
                        label_aggregate + f" +/- {legend_metric['std']:0.2f}"
                    )
            # Add `label` for first curve only, set to `None` for remaining curves
            labels.extend([label_aggregate] + [None] * (n_curves - 1))
        else:
            for curve_legend_metric, curve_name in zip(legend_metric["metric"], name):
                labels.append(
                    _BinaryClassifierCurveDisplayMixin._get_legend_label(
                        curve_legend_metric, curve_name, legend_metric_name
                    )
                )

        curve_kwargs_ = [
            _validate_style_kwargs({"label": label}, curve_kwargs[fold_idx])
            for fold_idx, label in enumerate(labels)
        ]
        return curve_kwargs_


def _validate_score_name(score_name, scoring, negate_score):
    """Validate the `score_name` parameter.

    If `score_name` is provided, we just return it as-is.
    If `score_name` is `None`, we use `Score` if `negate_score` is `False` and
    `Negative score` otherwise.
    If `score_name` is a string or a callable, we infer the name. We replace `_` by
    spaces and capitalize the first letter. We remove `neg_` and replace it by
    `"Negative"` if `negate_score` is `False` or just remove it otherwise.
    """
    if score_name is not None:
        return score_name
    elif scoring is None:
        return "Negative score" if negate_score else "Score"
    else:
        score_name = scoring.__name__ if callable(scoring) else scoring
        if negate_score:
            if score_name.startswith("neg_"):
                score_name = score_name[4:]
            else:
                score_name = f"Negative {score_name}"
        elif score_name.startswith("neg_"):
            score_name = f"Negative {score_name[4:]}"
        score_name = score_name.replace("_", " ")
        return score_name.capitalize()


def _interval_max_min_ratio(data):
    """Compute the ratio between the largest and smallest inter-point distances.

    A value larger than 5 typically indicates that the parameter range would
    better be displayed with a log scale while a linear scale would be more
    suitable otherwise.
    """
    diff = np.diff(np.sort(data))
    return diff.max() / diff.min()






            {
                "ls": "dashed",
                "c": "red",
                "ec": "black",
                "fc": "yellow",
                "lw": 2,
                "mec": "green",
                "mfcalt": "blue",
                "ms": 5,
            },
            {
                "linestyle": "dashed",
                "color": "red",
                "edgecolor": "black",
                "facecolor": "yellow",
                "linewidth": 2,
                "markeredgecolor": "green",
                "markerfacecoloralt": "blue",
                "markersize": 5,
            },
        ),
    ],
)
def test_validate_style_kwargs(default_kwargs, user_kwargs, expected):
    """Check the behaviour of `validate_style_kwargs` with various type of entries."""
    result = _validate_style_kwargs(default_kwargs, user_kwargs)
    assert result == expected, (
        "The validation of style keywords does not provide the expected results: "
        f"Got {result} instead of {expected}."
    )


@pytest.mark.parametrize(
    "default_kwargs, user_kwargs",
    [({}, {"ls": 2, "linestyle": 3}), ({}, {"c": "r", "color": "blue"})],
)
def test_validate_style_kwargs_error(default_kwargs, user_kwargs):
    """Check that `validate_style_kwargs` raises TypeError"""
    with pytest.raises(TypeError):
        _validate_style_kwargs(default_kwargs, user_kwargs)


def test_despine(pyplot):
    ax = pyplot.gca()
    _despine(ax)
    assert ax.spines["top"].get_visible() is False
    assert ax.spines["right"].get_visible() is False
    assert ax.spines["bottom"].get_bounds() == (0, 1)
    assert ax.spines["left"].get_bounds() == (0, 1)


@pytest.mark.parametrize("estimator_name", ["my_est_name", "deprecated"])
@pytest.mark.parametrize("name", [None, "my_name"])
def test_deprecate_estimator_name(estimator_name, name):
    """Check `_deprecate_estimator_name` behaves correctly"""
    version = "1.7"
    version_remove = "1.9"

    if estimator_name == "deprecated":
        name_out = _deprecate_estimator_name(estimator_name, name, version)
        assert name_out == name
                        f"{min_n_cats}. Got {grid_resolution} instead."
                    )

            for is_cat, kind_plot in zip(is_categorical, kind_):
                if any(is_cat) and kind_plot != "average":
                    raise ValueError(
                        "It is not possible to display individual effects for"
                        " categorical features."
                    )

        # Early exit if the axes does not have the correct number of axes
        if ax is not None and not isinstance(ax, plt.Axes):
            axes = np.asarray(ax, dtype=object)
            if axes.size != len(features):
                raise ValueError(
                    "Expected ax to have {} axes, got {}".format(
                        len(features), axes.size
                    )
                )

        for i in chain.from_iterable(features):
            if i >= len(feature_names):
                raise ValueError(
                    "All entries of features must be less than "
                    "len(feature_names) = {0}, got {1}.".format(len(feature_names), i)
                )

        if isinstance(subsample, numbers.Integral):
            if subsample <= 0:
                raise ValueError(
                    f"When an integer, subsample={subsample} should be positive."
                )
        elif isinstance(subsample, numbers.Real):
            if subsample <= 0 or subsample >= 1:
                raise ValueError(
                    f"When a floating-point, subsample={subsample} should be in "
                    "the (0, 1) range."
                )

        # compute predictions and/or averaged predictions
        pd_results = Parallel(n_jobs=n_jobs, verbose=verbose)(
            delayed(partial_dependence)(
                estimator,
                X,
                fxs,
                sample_weight=sample_weight,
                feature_names=feature_names,
                categorical_features=categorical_features,
                response_method=response_method,
                method=method,
                grid_resolution=grid_resolution,
sklearn/metrics/_plot/det_curve.py:8:from sklearn.utils._plotting import (
sklearn/metrics/_plot/precision_recall_curve.py:7:from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin, _deprecate_estimator_name, _deprecate_y_pred_parameter, _despine
sklearn/metrics/_plot/roc_curve.py:9:from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin, _check_param_lengths, _convert_to_list_leaving_none, _deprecate_estimator_name, _deprecate_y_pred_parameter, _despine
sklearn/calibration.py:46:from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,35p' sklearn/utils/tests/test_plotting.py; sed -n '420,485p' sklearn/utils/tests/test_plotting.py; sed -n '1,75p' sklearn/calibration.py; sed -n '1,25p' sklearn/inspection/_plot/partial_dependence.py; sed -n '1,25p' sklearn/metrics/_plot/det_curve.py; python - <<'PY'
from sklearn.metrics import PredictionErrorDisplay
print(PredictionErrorDisplay)
try:
 from sklearn.utils._plotting import _validate_style_kwargs
 print('style helper', _validate_style_kwargs)
except Exception as e: print(type(e).__name__, e)
try:
 from sklearn.utils._optional_dependencies import check_matplotlib_support
 print('mpl helper', check_matplotlib_support)
except Exception as e: print(type(e).__name__, e)
PY"
```

退出码：`0`

输出：
```
import numpy as np
import pytest

from sklearn.linear_model import LogisticRegression
from sklearn.utils._plotting import (
    _BinaryClassifierCurveDisplayMixin,
    _deprecate_estimator_name,
    _despine,
    _interval_max_min_ratio,
    _validate_score_name,
    _validate_style_kwargs,
)
from sklearn.utils._response import _get_response_values_binary
from sklearn.utils._testing import assert_allclose


@pytest.mark.parametrize("ax", [None, "Ax"])
@pytest.mark.parametrize(
    "name, expected_name_out", [(None, "TestEstimator"), ("CustomName", "CustomName")]
)
def test_validate_plot_params(pyplot, ax, name, expected_name_out):
    """Check `_validate_plot_params` returns the correct values."""
    display = _BinaryClassifierCurveDisplayMixin()
    display.estimator_name = "TestEstimator"
    if ax:
        _, ax = pyplot.subplots()
    ax_out, _, name_out = display._validate_plot_params(ax=ax, name=name)

    assert name_out == expected_name_out

    if ax:
        assert ax == ax_out


@pytest.mark.parametrize("pos_label", [None, 0])
        # This is not exactly spaced on a log scale but we will benefit from treating
        # it as such for visualization.
        ([1, 2, 5, 10, 20, 50], 20, 40),
    ],
)
def test_inverval_max_min_ratio(data, lower_bound, upper_bound):
    assert lower_bound < _interval_max_min_ratio(data) < upper_bound


@pytest.mark.parametrize(
    "default_kwargs, user_kwargs, expected",
    [
        (
            {"color": "blue", "linewidth": 2},
            {"linestyle": "dashed"},
            {"color": "blue", "linewidth": 2, "linestyle": "dashed"},
        ),
        (
            {"color": "blue", "linestyle": "solid"},
            {"c": "red", "ls": "dashed"},
            {"color": "red", "linestyle": "dashed"},
        ),
        (
            {"label": "xxx", "color": "k", "linestyle": "--"},
            {"ls": "-."},
            {"label": "xxx", "color": "k", "linestyle": "-."},
        ),
        ({}, {}, {}),
        (
            {},
            {
                "ls": "dashed",
                "c": "red",
                "ec": "black",
                "fc": "yellow",
                "lw": 2,
                "mec": "green",
                "mfcalt": "blue",
                "ms": 5,
            },
            {
                "linestyle": "dashed",
                "color": "red",
                "edgecolor": "black",
                "facecolor": "yellow",
                "linewidth": 2,
                "markeredgecolor": "green",
                "markerfacecoloralt": "blue",
                "markersize": 5,
            },
        ),
    ],
)
def test_validate_style_kwargs(default_kwargs, user_kwargs, expected):
    """Check the behaviour of `validate_style_kwargs` with various type of entries."""
    result = _validate_style_kwargs(default_kwargs, user_kwargs)
    assert result == expected, (
        "The validation of style keywords does not provide the expected results: "
        f"Got {result} instead of {expected}."
    )


@pytest.mark.parametrize(
    "default_kwargs, user_kwargs",
    [({}, {"ls": 2, "linestyle": 3}), ({}, {"c": "r", "color": "blue"})],
)
"""Methods for calibrating predicted probabilities."""

# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

import warnings
from functools import partial
from inspect import signature
from math import log
from numbers import Integral, Real

import numpy as np
from scipy.optimize import minimize, minimize_scalar
from scipy.special import expit

from sklearn._loss import HalfBinomialLoss, HalfMultinomialLoss
from sklearn.base import (
    BaseEstimator,
    ClassifierMixin,
    MetaEstimatorMixin,
    RegressorMixin,
    _fit_context,
    clone,
)
from sklearn.externals import array_api_extra as xpx
from sklearn.frozen import FrozenEstimator
from sklearn.isotonic import IsotonicRegression
from sklearn.model_selection import LeaveOneOut, check_cv, cross_val_predict
from sklearn.preprocessing import LabelEncoder, label_binarize
from sklearn.svm import LinearSVC
from sklearn.utils import Bunch, _safe_indexing, column_or_1d, get_tags, indexable
from sklearn.utils._array_api import (
    _convert_to_numpy,
    _half_multinomial_loss,
    _is_numpy_namespace,
    ensure_common_namespace_device,
    get_namespace,
    get_namespace_and_device,
)
from sklearn.utils._param_validation import (
    HasMethods,
    Interval,
    StrOptions,
    validate_params,
)
from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin



from sklearn.utils._response import _get_response_values, _process_predict_proba
from sklearn.utils.extmath import softmax
from sklearn.utils.metadata_routing import (
    MetadataRouter,
    MethodMapping,
    _routing_enabled,
    process_routing,
)
from sklearn.utils.multiclass import check_classification_targets
from sklearn.utils.parallel import Parallel, delayed
from sklearn.utils.validation import (
    _check_method_params,
    _check_pos_label_consistency,
    _check_response_method,
    _check_sample_weight,
    _num_samples,
    check_array,
    check_consistent_length,
    check_is_fitted,
)


class CalibratedClassifierCV(ClassifierMixin, MetaEstimatorMixin, BaseEstimator):
    """Calibrate probabilities using isotonic, sigmoid, or temperature scaling.

    This class uses cross-validation to both estimate the parameters of a
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

import numbers
from itertools import chain
from math import ceil

import numpy as np
from scipy import sparse
from scipy.stats.mstats import mquantiles

from sklearn.base import is_regressor
from sklearn.inspection import partial_dependence
from sklearn.inspection._pd_utils import _check_feature_names, _get_feature_index
from sklearn.utils import Bunch, _safe_indexing, check_array, check_random_state
from sklearn.utils._encode import _unique
from sklearn.utils._optional_dependencies import check_matplotlib_support
from sklearn.utils._plotting import _validate_style_kwargs
from sklearn.utils.parallel import Parallel, delayed


class PartialDependenceDisplay:
    """Partial Dependence Plot (PDP) and Individual Conditional Expectation (ICE).

    It is recommended to use
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

import numpy as np
import scipy as sp

from sklearn.metrics._ranking import det_curve
from sklearn.utils._plotting import (
    _BinaryClassifierCurveDisplayMixin,
    _deprecate_y_pred_parameter,
)


class DetCurveDisplay(_BinaryClassifierCurveDisplayMixin):
    """Detection Error Tradeoff (DET) curve visualization.

    It is recommended to use :func:`~sklearn.metrics.DetCurveDisplay.from_estimator`
    or :func:`~sklearn.metrics.DetCurveDisplay.from_predictions` to create a
    visualizer. All parameters are stored as attributes.

    For general information regarding `scikit-learn` visualization tools, see
    the :ref:`Visualization Guide <visualizations>`.
    For guidance on interpreting these plots, refer to the
    :ref:`Model Evaluation Guide <det_curve>`.

<class 'sklearn.metrics._plot.regression.PredictionErrorDisplay'>
ImportError cannot import name '_validate_style_kwargs' from 'sklearn.utils._plotting' (/testbed/sklearn/utils/_plotting.py)
ImportError cannot import name 'check_matplotlib_support' from 'sklearn.utils._optional_dependencies' (/testbed/sklearn/utils/_optional_dependencies.py)
```

## 原始行 29 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from sklearn.metrics import PredictionErrorDisplay
print(PredictionErrorDisplay)
from sklearn.utils._plotting import _validate_style_kwargs
from sklearn.utils._optional_dependencies import check_matplotlib_support
print(_validate_style_kwargs, check_matplotlib_support)
PY"
```

退出码：`1`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 3, in <module>
<class 'sklearn.metrics._plot.regression.PredictionErrorDisplay'>
ImportError: cannot import name '_validate_style_kwargs' from 'sklearn.utils._plotting' (/testbed/sklearn/utils/_plotting.py)
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "wc -l sklearn/utils/_optional_dependencies.py sklearn/utils/_plotting.py; nl -ba sklearn/utils/_optional_dependencies.py | sed -n '1,100p'; nl -ba sklearn/utils/_plotting.py | sed -n '1,380p'; grep -R -n \"check_matplotlib_support\" sklearn --include='*.py' | cut -d: -f1 | sort -u"
```

退出码：`0`

输出：
```
   45 sklearn/utils/_optional_dependencies.py
  433 sklearn/utils/_plotting.py
  478 total
     1	# Authors: The scikit-learn developers
     2	# SPDX-License-Identifier: BSD-3-Clause
     3	
     4	
     5	
     6	
     7	
     8	
     9	
    10	
    11	
    12	
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	def check_pandas_support(caller_name):
    26	    """Raise ImportError with detailed error message if pandas is not installed.
    27	
    28	    Plot utilities like :func:`fetch_openml` should lazily import
    29	    pandas and call this helper before any computation.
    30	
    31	    Parameters
    32	    ----------
    33	    caller_name : str
    34	        The name of the caller that requires pandas.
    35	
    36	    Returns
    37	    -------
    38	    pandas
    39	        The pandas package.
    40	    """
    41	    try:
    42	        import pandas
    43	
    44	        return pandas
    45	    except ImportError as e:
    46	        raise ImportError("{} requires pandas.".format(caller_name)) from e
     1	# Authors: The scikit-learn developers
     2	# SPDX-License-Identifier: BSD-3-Clause
     3	import warnings
     4	from collections.abc import Mapping
     5	
     6	import numpy as np
     7	
     8	from sklearn.utils import check_consistent_length
     9	
    10	from sklearn.utils._response import _get_response_values_binary
    11	from sklearn.utils.fixes import parse_version
    12	from sklearn.utils.multiclass import type_of_target
    13	from sklearn.utils.validation import _check_pos_label_consistency, _num_samples
    14	
    15	
    16	class _BinaryClassifierCurveDisplayMixin:
    17	    """Mixin class to be used in Displays requiring a binary classifier.
    18	
    19	    The aim of this class is to centralize some validations regarding the estimator and
    20	    the target and gather the response of the estimator.
    21	    """
    22	
    23	    def _validate_plot_params(self, *, ax=None, name=None):
    24	        check_matplotlib_support(f"{self.__class__.__name__}.plot")
    25	        import matplotlib.pyplot as plt
    26	
    27	        if ax is None:
    28	            _, ax = plt.subplots()
    29	
    30	        # Display classes are in process of changing from `estimator_name` to `name`.
    31	        # Try old attr name: `estimator_name` first.
    32	        if name is None:
    33	            name = getattr(self, "estimator_name", getattr(self, "name", None))
    34	        return ax, ax.figure, name
    35	
    36	    @classmethod
    37	    def _validate_and_get_response_values(
    38	        cls, estimator, X, y, *, response_method="auto", pos_label=None, name=None
    39	    ):
    40	        check_matplotlib_support(f"{cls.__name__}.from_estimator")
    41	
    42	        name = estimator.__class__.__name__ if name is None else name
    43	
    44	        y_pred, pos_label = _get_response_values_binary(
    45	            estimator,
    46	            X,
    47	            response_method=response_method,
    48	            pos_label=pos_label,
    49	        )
    50	
    51	        return y_pred, pos_label, name
    52	
    53	    @classmethod
    54	    def _validate_from_predictions_params(
    55	        cls, y_true, y_pred, *, sample_weight=None, pos_label=None, name=None
    56	    ):
    57	        check_matplotlib_support(f"{cls.__name__}.from_predictions")
    58	
    59	        if type_of_target(y_true) != "binary":
    60	            raise ValueError(
    61	                f"The target y is not binary. Got {type_of_target(y_true)} type of"
    62	                " target."
    63	            )
    64	
    65	        check_consistent_length(y_true, y_pred, sample_weight)
    66	        pos_label = _check_pos_label_consistency(pos_label, y_true)
    67	
    68	        name = name if name is not None else "Classifier"
    69	
    70	        return pos_label, name
    71	
    72	    @classmethod
    73	    def _validate_from_cv_results_params(
    74	        cls,
    75	        cv_results,
    76	        X,
    77	        y,
    78	        *,
    79	        sample_weight,
    80	    ):
    81	        check_matplotlib_support(f"{cls.__name__}.from_cv_results")
    82	
    83	        required_keys = {"estimator", "indices"}
    84	        if not all(key in cv_results for key in required_keys):
    85	            raise ValueError(
    86	                "`cv_results` does not contain one of the following required keys: "
    87	                f"{required_keys}. Set explicitly the parameters "
    88	                "`return_estimator=True` and `return_indices=True` to the function"
    89	                "`cross_validate`."
    90	            )
    91	
    92	        train_size, test_size = (
    93	            len(cv_results["indices"]["train"][0]),
    94	            len(cv_results["indices"]["test"][0]),
    95	        )
    96	
    97	        if _num_samples(X) != train_size + test_size:
    98	            raise ValueError(
    99	                "`X` does not contain the correct number of samples. "
   100	                f"Expected {train_size + test_size}, got {_num_samples(X)}."
   101	            )
   102	
   103	        if type_of_target(y) != "binary":
   104	            raise ValueError(
   105	                f"The target `y` is not binary. Got {type_of_target(y)} type of target."
   106	            )
   107	        check_consistent_length(X, y, sample_weight)
   108	
   109	    @staticmethod
   110	    def _get_legend_label(curve_legend_metric, curve_name, legend_metric_name):
   111	        """Helper to get legend label using `name` and `legend_metric`"""
   112	        if curve_legend_metric is not None and curve_name is not None:
   113	            label = f"{curve_name} ({legend_metric_name} = {curve_legend_metric:0.2f})"
   114	        elif curve_legend_metric is not None:
   115	            label = f"{legend_metric_name} = {curve_legend_metric:0.2f}"
   116	        elif curve_name is not None:
   117	            label = curve_name
   118	        else:
   119	            label = None
   120	        return label
   121	
   122	    @staticmethod
   123	    def _validate_curve_kwargs(
   124	        n_curves,
   125	        name,
   126	        legend_metric,
   127	        legend_metric_name,
   128	        curve_kwargs,
   129	        **kwargs,
   130	    ):
   131	        """Get validated line kwargs for each curve.
   132	
   133	        Parameters
   134	        ----------
   135	        n_curves : int
   136	            Number of curves.
   137	
   138	        name : list of str or None
   139	            Name for labeling legend entries.
   140	
   141	        legend_metric : dict
   142	            Dictionary with "mean" and "std" keys, or "metric" key of metric
   143	            values for each curve. If None, "label" will not contain metric values.
   144	
   145	        legend_metric_name : str
   146	            Name of the summary value provided in `legend_metrics`.
   147	
   148	        curve_kwargs : dict or list of dict or None
   149	            Dictionary with keywords passed to the matplotlib's `plot` function
   150	            to draw the individual curves. If a list is provided, the
   151	            parameters are applied to the curves sequentially. If a single
   152	            dictionary is provided, the same parameters are applied to all
   153	            curves.
   154	
   155	        **kwargs : dict
   156	            Deprecated. Keyword arguments to be passed to matplotlib's `plot`.
   157	        """
   158	        # TODO(1.9): Remove deprecated **kwargs
   159	        if curve_kwargs and kwargs:
   160	            raise ValueError(
   161	                "Cannot provide both `curve_kwargs` and `kwargs`. `**kwargs` is "
   162	                "deprecated in 1.7 and will be removed in 1.9. Pass all matplotlib "
   163	                "arguments to `curve_kwargs` as a dictionary."
   164	            )
   165	        if kwargs:
   166	            warnings.warn(
   167	                "`**kwargs` is deprecated and will be removed in 1.9. Pass all "
   168	                "matplotlib arguments to `curve_kwargs` as a dictionary instead.",
   169	                FutureWarning,
   170	            )
   171	            curve_kwargs = kwargs
   172	
   173	        if isinstance(curve_kwargs, list) and len(curve_kwargs) != n_curves:
   174	            raise ValueError(
   175	                f"`curve_kwargs` must be None, a dictionary or a list of length "
   176	                f"{n_curves}. Got: {curve_kwargs}."
   177	            )
   178	
   179	        # Ensure valid `name` and `curve_kwargs` combination.
   180	        if (
   181	            isinstance(name, list)
   182	            and len(name) != 1
   183	            and not isinstance(curve_kwargs, list)
   184	        ):
   185	            raise ValueError(
   186	                "To avoid labeling individual curves that have the same appearance, "
   187	                f"`curve_kwargs` should be a list of {n_curves} dictionaries. "
   188	                "Alternatively, set `name` to `None` or a single string to label "
   189	                "a single legend entry with mean ROC AUC score of all curves."
   190	            )
   191	
   192	        # Ensure `name` is of the correct length
   193	        if isinstance(name, str):
   194	            name = [name]
   195	        if isinstance(name, list) and len(name) == 1:
   196	            name = name * n_curves
   197	        name = [None] * n_curves if name is None else name
   198	
   199	        # Ensure `curve_kwargs` is of correct length
   200	        if isinstance(curve_kwargs, Mapping):
   201	            curve_kwargs = [curve_kwargs] * n_curves
   202	
   203	        default_multi_curve_kwargs = {"alpha": 0.5, "linestyle": "--", "color": "blue"}
   204	        if curve_kwargs is None:
   205	            if n_curves > 1:
   206	                curve_kwargs = [default_multi_curve_kwargs] * n_curves
   207	            else:
   208	                curve_kwargs = [{}]
   209	
   210	        labels = []
   211	        if "mean" in legend_metric:
   212	            label_aggregate = _BinaryClassifierCurveDisplayMixin._get_legend_label(
   213	                legend_metric["mean"], name[0], legend_metric_name
   214	            )
   215	            # Note: "std" always `None` when "mean" is `None` - no metric value added
   216	            # to label in this case
   217	            if legend_metric["std"] is not None:
   218	                # Add the "+/- std" to the end (in brackets if name provided)
   219	                if name[0] is not None:
   220	                    label_aggregate = (
   221	                        label_aggregate[:-1] + f" +/- {legend_metric['std']:0.2f})"
   222	                    )
   223	                else:
   224	                    label_aggregate = (
   225	                        label_aggregate + f" +/- {legend_metric['std']:0.2f}"
   226	                    )
   227	            # Add `label` for first curve only, set to `None` for remaining curves
   228	            labels.extend([label_aggregate] + [None] * (n_curves - 1))
   229	        else:
   230	            for curve_legend_metric, curve_name in zip(legend_metric["metric"], name):
   231	                labels.append(
   232	                    _BinaryClassifierCurveDisplayMixin._get_legend_label(
   233	                        curve_legend_metric, curve_name, legend_metric_name
   234	                    )
   235	                )
   236	
   237	        curve_kwargs_ = [
   238	            _validate_style_kwargs({"label": label}, curve_kwargs[fold_idx])
   239	            for fold_idx, label in enumerate(labels)
   240	        ]
   241	        return curve_kwargs_
   242	
   243	
   244	def _validate_score_name(score_name, scoring, negate_score):
   245	    """Validate the `score_name` parameter.
   246	
   247	    If `score_name` is provided, we just return it as-is.
   248	    If `score_name` is `None`, we use `Score` if `negate_score` is `False` and
   249	    `Negative score` otherwise.
   250	    If `score_name` is a string or a callable, we infer the name. We replace `_` by
   251	    spaces and capitalize the first letter. We remove `neg_` and replace it by
   252	    `"Negative"` if `negate_score` is `False` or just remove it otherwise.
   253	    """
   254	    if score_name is not None:
   255	        return score_name
   256	    elif scoring is None:
   257	        return "Negative score" if negate_score else "Score"
   258	    else:
   259	        score_name = scoring.__name__ if callable(scoring) else scoring
   260	        if negate_score:
   261	            if score_name.startswith("neg_"):
   262	                score_name = score_name[4:]
   263	            else:
   264	                score_name = f"Negative {score_name}"
   265	        elif score_name.startswith("neg_"):
   266	            score_name = f"Negative {score_name[4:]}"
   267	        score_name = score_name.replace("_", " ")
   268	        return score_name.capitalize()
   269	
   270	
   271	def _interval_max_min_ratio(data):
   272	    """Compute the ratio between the largest and smallest inter-point distances.
   273	
   274	    A value larger than 5 typically indicates that the parameter range would
   275	    better be displayed with a log scale while a linear scale would be more
   276	    suitable otherwise.
   277	    """
   278	    diff = np.diff(np.sort(data))
   279	    return diff.max() / diff.min()
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	
   303	
   304	
   305	
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	def _despine(ax):
   346	    """Remove the top and right spines of the plot.
   347	
   348	    Parameters
   349	    ----------
   350	    ax : matplotlib.axes.Axes
   351	        The axes of the plot to despine.
   352	    """
   353	    for s in ["top", "right"]:
   354	        ax.spines[s].set_visible(False)
   355	    for s in ["bottom", "left"]:
   356	        ax.spines[s].set_bounds(0, 1)
   357	
   358	
   359	def _deprecate_estimator_name(estimator_name, name, version):
   360	    """Deprecate `estimator_name` in favour of `name`."""
   361	    version = parse_version(version)
   362	    version_remove = f"{version.major}.{version.minor + 2}"
   363	    if estimator_name != "deprecated":
   364	        if name:
   365	            raise ValueError(
   366	                "Cannot provide both `estimator_name` and `name`. `estimator_name` "
   367	                f"is deprecated in {version} and will be removed in {version_remove}. "
   368	                "Use `name` only."
   369	            )
   370	        warnings.warn(
   371	            f"`estimator_name` is deprecated in {version} and will be removed in "
   372	            f"{version_remove}. Use `name` instead.",
   373	            FutureWarning,
   374	        )
   375	        return estimator_name
   376	    return name
   377	
   378	
   379	def _convert_to_list_leaving_none(param):
   380	    """Convert parameters to a list, leaving `None` as is."""
sklearn/inspection/_partial_dependence.py
sklearn/inspection/_plot/decision_boundary.py
sklearn/inspection/_plot/partial_dependence.py
sklearn/metrics/_plot/confusion_matrix.py
sklearn/model_selection/_plot.py
sklearn/utils/_plotting.py
```

## 原始行 38 · command_execution

命令：
```
/bin/bash -lc "grep -n \"check_matplotlib_support\\|_validate_style_kwargs\" sklearn/calibration.py sklearn/metrics/_plot/*.py sklearn/model_selection/_plot.py sklearn/inspection/_partial_dependence.py sklearn/inspection/_plot/decision_boundary.py; sed -n '1,35p' sklearn/model_selection/_plot.py; sed -n '1,35p' sklearn/inspection/_partial_dependence.py; sed -n '1,30p' sklearn/inspection/_plot/decision_boundary.py; grep -R -n \"_validate_style_kwargs\" sklearn --include='*.py' | grep '"'^.*import'"'"
```

退出码：`0`

输出：
```
sklearn/calibration.py:1441:        line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)
sklearn/metrics/_plot/confusion_matrix.py:139:        check_matplotlib_support("ConfusionMatrixDisplay.plot")
sklearn/metrics/_plot/confusion_matrix.py:152:        im_kw = _validate_style_kwargs(default_im_kw, im_kw)
sklearn/metrics/_plot/confusion_matrix.py:178:                text_kwargs = _validate_style_kwargs(default_text_kwargs, text_kw)
sklearn/metrics/_plot/confusion_matrix.py:331:        check_matplotlib_support(method_name)
sklearn/metrics/_plot/confusion_matrix.py:472:        check_matplotlib_support(f"{cls.__name__}.from_predictions")
sklearn/metrics/_plot/precision_recall_curve.py:217:        line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)
sklearn/metrics/_plot/precision_recall_curve.py:255:            chance_level_line_kw = _validate_style_kwargs(
sklearn/metrics/_plot/roc_curve.py:268:        chance_level_kw = _validate_style_kwargs(
sklearn/model_selection/_plot.py:25:        check_matplotlib_support(f"{self.__class__.__name__}.plot")
sklearn/model_selection/_plot.py:471:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
sklearn/model_selection/_plot.py:850:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
sklearn/inspection/_partial_dependence.py:27:from sklearn.utils._optional_dependencies import check_matplotlib_support  # noqa: F401
sklearn/inspection/_plot/decision_boundary.py:11:from sklearn.utils._optional_dependencies import check_matplotlib_support
sklearn/inspection/_plot/decision_boundary.py:206:        check_matplotlib_support("DecisionBoundaryDisplay.plot")
sklearn/inspection/_plot/decision_boundary.py:432:        check_matplotlib_support(f"{cls.__name__}.from_estimator")
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

import numpy as np

from sklearn.model_selection._validation import learning_curve, validation_curve

from sklearn.utils._plotting import _interval_max_min_ratio, _validate_score_name


class _BaseCurveDisplay:
    def _plot_curve(
        self,
        x_data,
        *,
        ax=None,
        negate_score=False,
        score_name=None,
        score_type="test",
        std_display_style="fill_between",
        line_kw=None,
        fill_between_kw=None,
        errorbar_kw=None,
    ):
        check_matplotlib_support(f"{self.__class__.__name__}.plot")

        import matplotlib.pyplot as plt

        if ax is None:
            _, ax = plt.subplots()

        if negate_score:
            train_scores, test_scores = -self.train_scores, -self.test_scores
        else:
            train_scores, test_scores = self.train_scores, self.test_scores
"""Partial dependence plots for regression and classification models."""

# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

import warnings
from collections.abc import Iterable

import numpy as np
from scipy import sparse
from scipy.stats.mstats import mquantiles

from sklearn.base import is_classifier, is_regressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble._gb import BaseGradientBoosting
from sklearn.ensemble._hist_gradient_boosting.gradient_boosting import (
    BaseHistGradientBoosting,
)
from sklearn.inspection._pd_utils import _check_feature_names, _get_feature_index
from sklearn.tree import DecisionTreeRegressor
from sklearn.utils import Bunch, _safe_indexing, check_array
from sklearn.utils._indexing import (
    _determine_key_type,
    _get_column_indices,
    _safe_assign,
)
from sklearn.utils._optional_dependencies import check_matplotlib_support  # noqa: F401
from sklearn.utils._param_validation import (
    HasMethods,
    Integral,
    Interval,
    StrOptions,
    validate_params,
)
from sklearn.utils._response import _get_response_values
# Authors: The scikit-learn developers
# SPDX-License-Identifier: BSD-3-Clause

import warnings

import numpy as np

from sklearn.base import is_regressor
from sklearn.preprocessing import LabelEncoder
from sklearn.utils import _safe_indexing
from sklearn.utils._optional_dependencies import check_matplotlib_support
from sklearn.utils._response import _get_response_values
from sklearn.utils._set_output import _get_adapter_from_container
from sklearn.utils.validation import (
    _is_arraylike_not_scalar,
    _is_pandas_df,
    _is_polars_df,
    _num_features,
    check_is_fitted,
)


def _check_boundary_response_method(estimator, response_method, class_of_interest):
    """Validate the response methods to be used with the fitted estimator.

    Parameters
    ----------
    estimator : object
        Fitted estimator to check.

sklearn/inspection/_plot/partial_dependence.py:18:from sklearn.utils._plotting import _validate_style_kwargs
```

## 原始行 41 · command_execution

命令：
```
/bin/bash -lc "grep -R -n 'must be one of.*Got.*instead' sklearn --include='*.py' | head -50; grep -R -n 'Got .* instead' sklearn/metrics/_plot sklearn/inspection/_plot --include='*.py' | head -50; grep -R -n 'kind.*actual_vs\\|kind.*residual' doc examples sklearn --include='*.rst' --include='*.py' 2>/dev/null | head -80"
```

退出码：`0`

输出：
```
sklearn/metrics/_plot/tests/test_common_curve_display.py:45:    msg = "Expected 'estimator' to be a binary classifier. Got 3 classes instead."
sklearn/inspection/_plot/partial_dependence.py:648:                    f" integer, or string. Got {categorical_features.dtype} instead."
sklearn/inspection/_plot/partial_dependence.py:680:                        f"{min_n_cats}. Got {grid_resolution} instead."
sklearn/inspection/_plot/decision_boundary.py:213:                f"Got {plot_method} instead."
sklearn/inspection/_plot/decision_boundary.py:444:                f"eps must be greater than or equal to 0. Got {eps} instead."
sklearn/inspection/_plot/decision_boundary.py:452:                f"Got {plot_method} instead."
sklearn/inspection/_plot/decision_boundary.py:458:                f"n_features must be equal to 2. Got {num_features} instead."
sklearn/inspection/_plot/tests/test_boundary_decision_display.py:51:    msg = "n_features must be equal to 2. Got 4 instead."
sklearn/inspection/_plot/tests/test_boundary_decision_display.py:154:            r"grid_resolution must be greater than 1. Got 1 instead",
sklearn/inspection/_plot/tests/test_boundary_decision_display.py:158:            r"grid_resolution must be greater than 1. Got -1 instead",
sklearn/inspection/_plot/tests/test_boundary_decision_display.py:160:        ({"eps": -1.1}, r"eps must be greater than or equal to 0. Got -1.1 instead"),
examples/inspection/plot_linear_model_coefficient_interpretation.py:191:    y_test, y_pred, kind="actual_vs_predicted", ax=ax, scatter_kwargs={"alpha": 0.5}
examples/inspection/plot_linear_model_coefficient_interpretation.py:485:    y_test, y_pred, kind="actual_vs_predicted", ax=ax, scatter_kwargs={"alpha": 0.5}
examples/inspection/plot_linear_model_coefficient_interpretation.py:576:    y_test, y_pred, kind="actual_vs_predicted", ax=ax, scatter_kwargs={"alpha": 0.5}
examples/inspection/plot_linear_model_coefficient_interpretation.py:680:    y_test, y_pred, kind="actual_vs_predicted", ax=ax, scatter_kwargs={"alpha": 0.5}
examples/release_highlights/plot_release_highlights_1_2_0.py:87:    hist_no_interact, X, y, kind="actual_vs_predicted", ax=axs[0]
examples/release_highlights/plot_release_highlights_1_2_0.py:90:    hist_no_interact, X, y, kind="residual_vs_predicted", ax=axs[1]
examples/model_selection/plot_cv_predict.py:50:    kind="actual_vs_predicted",
examples/model_selection/plot_cv_predict.py:59:    kind="residual_vs_predicted",
examples/compose/plot_transformed_target.py:99:    kind="actual_vs_predicted",
examples/compose/plot_transformed_target.py:106:    kind="actual_vs_predicted",
examples/compose/plot_transformed_target.py:190:    kind="actual_vs_predicted",
examples/compose/plot_transformed_target.py:197:    kind="actual_vs_predicted",
examples/compose/plot_transformed_target.py:215:    kind="residual_vs_predicted",
examples/compose/plot_transformed_target.py:222:    kind="residual_vs_predicted",
examples/applications/plot_cyclical_feature_engineering.py:779:plot_kinds = ["actual_vs_predicted", "residual_vs_predicted"]
examples/applications/plot_time_series_lagged_features.py:406:        kind="residual_vs_predicted",
examples/ensemble/plot_stack_predictors.py:239:        kind="actual_vs_predicted",
sklearn/metrics/_plot/regression.py:45:        `kind="residuals"`.
```

## 原始行 43 · agent_message

```
The surrounding code confirms two shared utilities were also masked: matplotlib availability checking and matplotlib style-key normalization. I’m restoring those utilities and using them in the display so aliases such as `c`/`color` override defaults correctly while duplicate aliases raise consistently.
```

## 原始行 45 · file_change

```
{
  "id": "item_30",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/sklearn/metrics/_plot/regression.py",
      "kind": "update"
    },
    {
      "path": "/testbed/sklearn/utils/_optional_dependencies.py",
      "kind": "update"
    },
    {
      "path": "/testbed/sklearn/utils/_plotting.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 48 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest sklearn/utils/tests/test_plotting.py -q'
```

退出码：`0`

输出：
```
[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 69%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                         [100%][0m
[32m[32m[1m104 passed[0m[32m in 1.67s[0m[0m
```

## 原始行 51 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest sklearn/metrics/_plot/tests/test_common_curve_display.py -q'
```

退出码：`1`

输出：
```
[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[31m               [100%][0m
=================================== FAILURES ===================================
[31m[1m_ test_display_curve_estimator_name_multiple_calls[from_estimator-PrecisionRecallDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay'>
constructor_name = 'from_estimator'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mconstructor_name[39;49;00m[33m"[39;49;00m, [[33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_estimator_name_multiple_calls[39;49;00m([90m[39;49;00m
        pyplot,[90m[39;49;00m
        data_binary,[90m[39;49;00m
        Display,[90m[39;49;00m
        constructor_name,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that passing `name` when calling `plot` will overwrite the original name[39;49;00m
    [33m    in the legend."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        clf_name = [33m"[39;49;00m[33mmy hand-crafted name[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        clf = LogisticRegression().fit(X, y)[90m[39;49;00m
        y_pred = clf.predict_proba(X)[:, [94m1[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
        [90m# safe guard for the binary if/else construction[39;49;00m[90m[39;49;00m
        [94massert[39;49;00m constructor_name [95min[39;49;00m ([33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor_name == [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
>           disp = Display.from_estimator(clf, X, y, name=clf_name)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:156: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:408: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:575: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay object at 0x7090302a7310>
ax = None, name = 'my hand-crafted name', plot_chance_level = False
chance_level_kw = None, despine = False, kwargs = {}
default_line_kwargs = {'drawstyle': 'steps-post', 'label': 'my hand-crafted name (AP = 1.00)'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name of precision recall curve for labeling. If `None`, use[39;49;00m
    [33m        `name` if not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level. The chance level is the prevalence[39;49;00m
    [33m        of the positive label computed from the data passed during[39;49;00m
    [33m        :meth:`from_estimator` or :meth:`from_predictions` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.PrecisionRecallDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m[39;49;00m
    [33m    Notes[39;49;00m
    [33m    -----[39;49;00m
    [33m    The average precision (cf. :func:`~sklearn.metrics.average_precision_score`)[39;49;00m
    [33m    in scikit-learn is computed without any interpolation. To be consistent[39;49;00m
    [33m    with this metric, the precision-recall curve is plotted without any[39;49;00m
    [33m    interpolation as well (step-wise style).[39;49;00m
    [33m[39;49;00m
    [33m    You can change this style by passing the keyword argument[39;49;00m
    [33m    `drawstyle="default"`. However, the curve will not be strictly[39;49;00m
    [33m    consistent with the reported average precision.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mdrawstyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33msteps-post[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = ([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mname[33m}[39;49;00m[33m (AP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94melif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mAP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
    [90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:217: NameError
[31m[1m_ test_display_curve_estimator_name_multiple_calls[from_estimator-RocCurveDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>
constructor_name = 'from_estimator'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mconstructor_name[39;49;00m[33m"[39;49;00m, [[33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_estimator_name_multiple_calls[39;49;00m([90m[39;49;00m
        pyplot,[90m[39;49;00m
        data_binary,[90m[39;49;00m
        Display,[90m[39;49;00m
        constructor_name,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that passing `name` when calling `plot` will overwrite the original name[39;49;00m
    [33m    in the legend."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        clf_name = [33m"[39;49;00m[33mmy hand-crafted name[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        clf = LogisticRegression().fit(X, y)[90m[39;49;00m
        y_pred = clf.predict_proba(X)[:, [94m1[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
        [90m# safe guard for the binary if/else construction[39;49;00m[90m[39;49;00m
        [94massert[39;49;00m constructor_name [95min[39;49;00m ([33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor_name == [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
>           disp = Display.from_estimator(clf, X, y, name=clf_name)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:156: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902e1a7cd0>
ax = None, name = ['my hand-crafted name']
curve_kwargs = [{'label': 'my hand-crafted name (AUC = 1.00)'}]
plot_chance_level = False, chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0., 0., 0., 1.])], tpr = [array([0.  , 0.02, 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m_ test_display_curve_estimator_name_multiple_calls[from_predictions-PrecisionRecallDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay'>
constructor_name = 'from_predictions'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mconstructor_name[39;49;00m[33m"[39;49;00m, [[33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_estimator_name_multiple_calls[39;49;00m([90m[39;49;00m
        pyplot,[90m[39;49;00m
        data_binary,[90m[39;49;00m
        Display,[90m[39;49;00m
        constructor_name,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that passing `name` when calling `plot` will overwrite the original name[39;49;00m
    [33m    in the legend."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        clf_name = [33m"[39;49;00m[33mmy hand-crafted name[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        clf = LogisticRegression().fit(X, y)[90m[39;49;00m
        y_pred = clf.predict_proba(X)[:, [94m1[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
        [90m# safe guard for the binary if/else construction[39;49;00m[90m[39;49;00m
        [94massert[39;49;00m constructor_name [95min[39;49;00m ([33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor_name == [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            disp = Display.from_estimator(clf, X, y, name=clf_name)[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
>           disp = Display.from_predictions(y, y_pred, name=clf_name)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:158: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:575: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay object at 0x70902e115d20>
ax = None, name = 'my hand-crafted name', plot_chance_level = False
chance_level_kw = None, despine = False, kwargs = {}
default_line_kwargs = {'drawstyle': 'steps-post', 'label': 'my hand-crafted name (AP = 1.00)'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name of precision recall curve for labeling. If `None`, use[39;49;00m
    [33m        `name` if not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level. The chance level is the prevalence[39;49;00m
    [33m        of the positive label computed from the data passed during[39;49;00m
    [33m        :meth:`from_estimator` or :meth:`from_predictions` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.PrecisionRecallDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m[39;49;00m
    [33m    Notes[39;49;00m
    [33m    -----[39;49;00m
    [33m    The average precision (cf. :func:`~sklearn.metrics.average_precision_score`)[39;49;00m
    [33m    in scikit-learn is computed without any interpolation. To be consistent[39;49;00m
    [33m    with this metric, the precision-recall curve is plotted without any[39;49;00m
    [33m    interpolation as well (step-wise style).[39;49;00m
    [33m[39;49;00m
    [33m    You can change this style by passing the keyword argument[39;49;00m
    [33m    `drawstyle="default"`. However, the curve will not be strictly[39;49;00m
    [33m    consistent with the reported average precision.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mdrawstyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33msteps-post[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = ([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mname[33m}[39;49;00m[33m (AP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94melif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mAP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
    [90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:217: NameError
[31m[1m_ test_display_curve_estimator_name_multiple_calls[from_predictions-RocCurveDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>
constructor_name = 'from_predictions'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mconstructor_name[39;49;00m[33m"[39;49;00m, [[33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_estimator_name_multiple_calls[39;49;00m([90m[39;49;00m
        pyplot,[90m[39;49;00m
        data_binary,[90m[39;49;00m
        Display,[90m[39;49;00m
        constructor_name,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that passing `name` when calling `plot` will overwrite the original name[39;49;00m
    [33m    in the legend."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        clf_name = [33m"[39;49;00m[33mmy hand-crafted name[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        clf = LogisticRegression().fit(X, y)[90m[39;49;00m
        y_pred = clf.predict_proba(X)[:, [94m1[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
        [90m# safe guard for the binary if/else construction[39;49;00m[90m[39;49;00m
        [94massert[39;49;00m constructor_name [95min[39;49;00m ([33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor_name == [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            disp = Display.from_estimator(clf, X, y, name=clf_name)[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
>           disp = Display.from_predictions(y, y_pred, name=clf_name)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:158: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902e192ad0>
ax = None, name = ['my hand-crafted name']
curve_kwargs = [{'label': 'my hand-crafted name (AUC = 1.00)'}]
plot_chance_level = False, chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0., 0., 0., 1.])], tpr = [array([0.  , 0.02, 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m__ test_display_curve_not_fitted_errors_old_name[PrecisionRecallDisplay-clf0] __[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = LogisticRegression()
Display = <class 'sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors_old_name[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not[39;49;00m
    [33m    fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:196: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:408: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:575: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay object at 0x70902e06ac80>
ax = None, name = 'LogisticRegression', plot_chance_level = False
chance_level_kw = None, despine = False, kwargs = {}
default_line_kwargs = {'drawstyle': 'steps-post', 'label': 'LogisticRegression (AP = 1.00)'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name of precision recall curve for labeling. If `None`, use[39;49;00m
    [33m        `name` if not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level. The chance level is the prevalence[39;49;00m
    [33m        of the positive label computed from the data passed during[39;49;00m
    [33m        :meth:`from_estimator` or :meth:`from_predictions` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.PrecisionRecallDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m[39;49;00m
    [33m    Notes[39;49;00m
    [33m    -----[39;49;00m
    [33m    The average precision (cf. :func:`~sklearn.metrics.average_precision_score`)[39;49;00m
    [33m    in scikit-learn is computed without any interpolation. To be consistent[39;49;00m
    [33m    with this metric, the precision-recall curve is plotted without any[39;49;00m
    [33m    interpolation as well (step-wise style).[39;49;00m
    [33m[39;49;00m
    [33m    You can change this style by passing the keyword argument[39;49;00m
    [33m    `drawstyle="default"`. However, the curve will not be strictly[39;49;00m
    [33m    consistent with the reported average precision.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mdrawstyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33msteps-post[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = ([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mname[33m}[39;49;00m[33m (AP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94melif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mAP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
    [90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:217: NameError
[31m[1m__ test_display_curve_not_fitted_errors_old_name[PrecisionRecallDisplay-clf1] __[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = Pipeline(steps=[('standardscaler', StandardScaler()),
                ('logisticregression', LogisticRegression())])
Display = <class 'sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors_old_name[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not[39;49;00m
    [33m    fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:196: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:408: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:575: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay object at 0x70902e092950>
ax = None, name = 'Pipeline', plot_chance_level = False, chance_level_kw = None
despine = False, kwargs = {}
default_line_kwargs = {'drawstyle': 'steps-post', 'label': 'Pipeline (AP = 1.00)'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name of precision recall curve for labeling. If `None`, use[39;49;00m
    [33m        `name` if not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level. The chance level is the prevalence[39;49;00m
    [33m        of the positive label computed from the data passed during[39;49;00m
    [33m        :meth:`from_estimator` or :meth:`from_predictions` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.PrecisionRecallDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m[39;49;00m
    [33m    Notes[39;49;00m
    [33m    -----[39;49;00m
    [33m    The average precision (cf. :func:`~sklearn.metrics.average_precision_score`)[39;49;00m
    [33m    in scikit-learn is computed without any interpolation. To be consistent[39;49;00m
    [33m    with this metric, the precision-recall curve is plotted without any[39;49;00m
    [33m    interpolation as well (step-wise style).[39;49;00m
    [33m[39;49;00m
    [33m    You can change this style by passing the keyword argument[39;49;00m
    [33m    `drawstyle="default"`. However, the curve will not be strictly[39;49;00m
    [33m    consistent with the reported average precision.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mdrawstyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33msteps-post[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = ([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mname[33m}[39;49;00m[33m (AP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94melif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mAP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
    [90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:217: NameError
[31m[1m__ test_display_curve_not_fitted_errors_old_name[PrecisionRecallDisplay-clf2] __[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = Pipeline(steps=[('columntransformer',
                 ColumnTransformer(transformers=[('standardscaler',
            ...                           StandardScaler(), [0, 1])])),
                ('logisticregression', LogisticRegression())])
Display = <class 'sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors_old_name[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not[39;49;00m
    [33m    fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:196: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:408: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:575: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay object at 0x70902e0f3220>
ax = None, name = 'Pipeline', plot_chance_level = False, chance_level_kw = None
despine = False, kwargs = {}
default_line_kwargs = {'drawstyle': 'steps-post', 'label': 'Pipeline (AP = 1.00)'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name of precision recall curve for labeling. If `None`, use[39;49;00m
    [33m        `name` if not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level. The chance level is the prevalence[39;49;00m
    [33m        of the positive label computed from the data passed during[39;49;00m
    [33m        :meth:`from_estimator` or :meth:`from_predictions` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.PrecisionRecallDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m[39;49;00m
    [33m    Notes[39;49;00m
    [33m    -----[39;49;00m
    [33m    The average precision (cf. :func:`~sklearn.metrics.average_precision_score`)[39;49;00m
    [33m    in scikit-learn is computed without any interpolation. To be consistent[39;49;00m
    [33m    with this metric, the precision-recall curve is plotted without any[39;49;00m
    [33m    interpolation as well (step-wise style).[39;49;00m
    [33m[39;49;00m
    [33m    You can change this style by passing the keyword argument[39;49;00m
    [33m    `drawstyle="default"`. However, the curve will not be strictly[39;49;00m
    [33m    consistent with the reported average precision.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mdrawstyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33msteps-post[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = ([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mname[33m}[39;49;00m[33m (AP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94melif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mAP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
    [90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:217: NameError
[31m[1m_____ test_display_curve_not_fitted_errors_old_name[RocCurveDisplay-clf0] ______[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = LogisticRegression()
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors_old_name[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not[39;49;00m
    [33m    fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:196: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902e0f0fa0>
ax = None, name = ['LogisticRegression']
curve_kwargs = [{'label': 'LogisticRegression (AUC = 1.00)'}]
plot_chance_level = False, chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0., 0., 0., 1.])], tpr = [array([0.  , 0.02, 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m_____ test_display_curve_not_fitted_errors_old_name[RocCurveDisplay-clf1] ______[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = Pipeline(steps=[('standardscaler', StandardScaler()),
                ('logisticregression', LogisticRegression())])
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors_old_name[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not[39;49;00m
    [33m    fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:196: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902e0ef4f0>
ax = None, name = ['Pipeline']
curve_kwargs = [{'label': 'Pipeline (AUC = 1.00)'}], plot_chance_level = False
chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0., 0., 0., 1.])], tpr = [array([0.  , 0.02, 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m_____ test_display_curve_not_fitted_errors_old_name[RocCurveDisplay-clf2] ______[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = Pipeline(steps=[('columntransformer',
                 ColumnTransformer(transformers=[('standardscaler',
            ...                           StandardScaler(), [0, 1])])),
                ('logisticregression', LogisticRegression())])
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [DetCurveDisplay, PrecisionRecallDisplay, RocCurveDisplay][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors_old_name[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not[39;49;00m
    [33m    fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:196: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902df1a890>
ax = None, name = ['Pipeline']
curve_kwargs = [{'label': 'Pipeline (AUC = 1.00)'}], plot_chance_level = False
chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  ,
       0.  , 0.  , 0.  , 0.  , 0.04, 0.08, 0.14, 0.22, 0.4 , 0.48, 0.54,
       0.66, 0.7 , 0.74, 0.82, 0.88, 1.  ])]
tpr = [array([0.  , 0.02, 0.22, 0.26, 0.3 , 0.34, 0.44, 0.48, 0.52, 0.56, 0.7 ,
       0.74, 0.88, 0.92, 1.  , 1.  , 1.  , 1.  , 1.  , 1.  , 1.  , 1.  ,
       1.  , 1.  , 1.  , 1.  , 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m__________ test_display_curve_not_fitted_errors[RocCurveDisplay-clf0] __________[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = LogisticRegression()
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [RocCurveDisplay])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:225: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902e092500>
ax = None, name = ['LogisticRegression']
curve_kwargs = [{'label': 'LogisticRegression (AUC = 1.00)'}]
plot_chance_level = False, chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0., 0., 0., 1.])], tpr = [array([0.  , 0.02, 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m__________ test_display_curve_not_fitted_errors[RocCurveDisplay-clf1] __________[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = Pipeline(steps=[('standardscaler', StandardScaler()),
                ('logisticregression', LogisticRegression())])
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [RocCurveDisplay])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:225: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902e050a90>
ax = None, name = ['Pipeline']
curve_kwargs = [{'label': 'Pipeline (AUC = 1.00)'}], plot_chance_level = False
chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0., 0., 0., 1.])], tpr = [array([0.  , 0.02, 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m__________ test_display_curve_not_fitted_errors[RocCurveDisplay-clf2] __________[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
clf = Pipeline(steps=[('columntransformer',
                 ColumnTransformer(transformers=[('standardscaler',
            ...                           StandardScaler(), [0, 1])])),
                ('logisticregression', LogisticRegression())])
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mclf[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            LogisticRegression(),[90m[39;49;00m
            make_pipeline(StandardScaler(), LogisticRegression()),[90m[39;49;00m
            make_pipeline([90m[39;49;00m
                make_column_transformer((StandardScaler(), [[94m0[39;49;00m, [94m1[39;49;00m])), LogisticRegression()[90m[39;49;00m
            ),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m, [RocCurveDisplay])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_curve_not_fitted_errors[39;49;00m(pyplot, data_binary, clf, Display):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that a proper error is raised when the classifier is not fitted."""[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
        [90m# clone since we parametrize the test and the classifier will be fitted[39;49;00m[90m[39;49;00m
        [90m# when testing the second and subsequent plotting function[39;49;00m[90m[39;49;00m
        model = clone(clf)[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(NotFittedError):[90m[39;49;00m
            Display.from_estimator(model, X, y)[90m[39;49;00m
        model.fit(X, y)[90m[39;49;00m
>       disp = Display.from_estimator(model, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:225: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.roc_curve.RocCurveDisplay object at 0x70902df8d0f0>
ax = None, name = ['Pipeline']
curve_kwargs = [{'label': 'Pipeline (AUC = 1.00)'}], plot_chance_level = False
chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  , 0.  ,
       0.  , 0.  , 0.  , 0.  , 0.04, 0.08, 0.14, 0.22, 0.4 , 0.48, 0.54,
       0.66, 0.7 , 0.74, 0.82, 0.88, 1.  ])]
tpr = [array([0.  , 0.02, 0.22, 0.26, 0.3 , 0.34, 0.44, 0.48, 0.52, 0.56, 0.7 ,
       0.74, 0.88, 0.92, 1.  , 1.  , 1.  , 1.  , 1.  , 1.  , 1.  , 1.  ,
       1.  , 1.  , 1.  , 1.  , 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_predictions-CalibrationDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.calibration.CalibrationDisplay'>
constructor = 'from_predictions'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
>           curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:298: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/calibration.py[0m:1694: in from_predictions
    [0m[94mreturn[39;49;00m disp.plot(ax=ax, ref_line=ref_line, **kwargs)[90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay object at 0x70902df84640>
ax = None, name = 'Classifier', ref_line = True, kwargs = {}
info_pos_label = '(Positive class: 1)'
default_line_kwargs = {'label': 'Classifier', 'linestyle': '-', 'marker': 's'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([96mself[39;49;00m, *, ax=[94mNone[39;49;00m, name=[94mNone[39;49;00m, ref_line=[94mTrue[39;49;00m, **kwargs):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to[39;49;00m
    [33m    :func:`matplotlib.pyplot.plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name for labeling curve. If `None`, use `estimator_name` if[39;49;00m
    [33m        not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    ref_line : bool, default=True[39;49;00m
    [33m        If `True`, plots a reference line representing a perfectly[39;49;00m
    [33m        calibrated classifier.[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to :func:`matplotlib.pyplot.plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.calibration.CalibrationDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        info_pos_label = ([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m(Positive class: [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.pos_label[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m [94mif[39;49;00m [96mself[39;49;00m.pos_label [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [33m"[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mmarker[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33ms[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m-[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/calibration.py[0m:1441: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_predictions-PrecisionRecallDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay'>
constructor = 'from_predictions'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
>           curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:298: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:575: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay object at 0x70902df19b70>
ax = None, name = 'Classifier', plot_chance_level = False
chance_level_kw = None, despine = False, kwargs = {}
default_line_kwargs = {'drawstyle': 'steps-post', 'label': 'Classifier (AP = 1.00)'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name of precision recall curve for labeling. If `None`, use[39;49;00m
    [33m        `name` if not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level. The chance level is the prevalence[39;49;00m
    [33m        of the positive label computed from the data passed during[39;49;00m
    [33m        :meth:`from_estimator` or :meth:`from_predictions` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.PrecisionRecallDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m[39;49;00m
    [33m    Notes[39;49;00m
    [33m    -----[39;49;00m
    [33m    The average precision (cf. :func:`~sklearn.metrics.average_precision_score`)[39;49;00m
    [33m    in scikit-learn is computed without any interpolation. To be consistent[39;49;00m
    [33m    with this metric, the precision-recall curve is plotted without any[39;49;00m
    [33m    interpolation as well (step-wise style).[39;49;00m
    [33m[39;49;00m
    [33m    You can change this style by passing the keyword argument[39;49;00m
    [33m    `drawstyle="default"`. However, the curve will not be strictly[39;49;00m
    [33m    consistent with the reported average precision.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mdrawstyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33msteps-post[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = ([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mname[33m}[39;49;00m[33m (AP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94melif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mAP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
    [90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:217: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_predictions-RocCurveDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>
constructor = 'from_predictions'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
>           curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:298: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay object at 0x70902df46f20>
ax = None, name = ['Classifier']
curve_kwargs = [{'label': 'Classifier (AUC = 1.00)'}], plot_chance_level = False
chance_level_kw = {}, despine = False, kwargs = {}, fpr = [array([0., 0., 1.])]
tpr = [array([0., 1., 1.])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_predictions-ConfusionMatrixDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay'>
constructor = 'from_predictions'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
>           curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:298: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay'>
y_true = array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,...1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])
y_pred = array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,...1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

    [0m[37m@classmethod[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mfrom_predictions[39;49;00m([90m[39;49;00m
        [96mcls[39;49;00m,[90m[39;49;00m
        y_true,[90m[39;49;00m
        y_pred,[90m[39;49;00m
        *,[90m[39;49;00m
        labels=[94mNone[39;49;00m,[90m[39;49;00m
        sample_weight=[94mNone[39;49;00m,[90m[39;49;00m
        normalize=[94mNone[39;49;00m,[90m[39;49;00m
        display_labels=[94mNone[39;49;00m,[90m[39;49;00m
        include_values=[94mTrue[39;49;00m,[90m[39;49;00m
        xticks_rotation=[33m"[39;49;00m[33mhorizontal[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        values_format=[94mNone[39;49;00m,[90m[39;49;00m
        cmap=[33m"[39;49;00m[33mviridis[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        colorbar=[94mTrue[39;49;00m,[90m[39;49;00m
        im_kw=[94mNone[39;49;00m,[90m[39;49;00m
        text_kw=[94mNone[39;49;00m,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot Confusion Matrix given true and predicted labels.[39;49;00m
    [33m[39;49;00m
    [33m    For general information regarding `scikit-learn` visualization tools, see[39;49;00m
    [33m    the :ref:`Visualization Guide <visualizations>`.[39;49;00m
    [33m    For guidance on interpreting these plots, refer to the[39;49;00m
    [33m    :ref:`Model Evaluation Guide <confusion_matrix>`.[39;49;00m
    [33m[39;49;00m
    [33m    .. versionadded:: 1.0[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    y_true : array-like of shape (n_samples,)[39;49;00m
    [33m        True labels.[39;49;00m
    [33m[39;49;00m
    [33m    y_pred : array-like of shape (n_samples,)[39;49;00m
    [33m        The predicted labels given by the method `predict` of an[39;49;00m
    [33m        classifier.[39;49;00m
    [33m[39;49;00m
    [33m    labels : array-like of shape (n_classes,), default=None[39;49;00m
    [33m        List of labels to index the confusion matrix. This may be used to[39;49;00m
    [33m        reorder or select a subset of labels. If `None` is given, those[39;49;00m
    [33m        that appear at least once in `y_true` or `y_pred` are used in[39;49;00m
    [33m        sorted order.[39;49;00m
    [33m[39;49;00m
    [33m    sample_weight : array-like of shape (n_samples,), default=None[39;49;00m
    [33m        Sample weights.[39;49;00m
    [33m[39;49;00m
    [33m    normalize : {'true', 'pred', 'all'}, default=None[39;49;00m
    [33m        Either to normalize the counts display in the matrix:[39;49;00m
    [33m[39;49;00m
    [33m        - if `'true'`, the confusion matrix is normalized over the true[39;49;00m
    [33m          conditions (e.g. rows);[39;49;00m
    [33m        - if `'pred'`, the confusion matrix is normalized over the[39;49;00m
    [33m          predicted conditions (e.g. columns);[39;49;00m
    [33m        - if `'all'`, the confusion matrix is normalized by the total[39;49;00m
    [33m          number of samples;[39;49;00m
    [33m        - if `None` (default), the confusion matrix will not be normalized.[39;49;00m
    [33m[39;49;00m
    [33m    display_labels : array-like of shape (n_classes,), default=None[39;49;00m
    [33m        Target names used for plotting. By default, `labels` will be used[39;49;00m
    [33m        if it is defined, otherwise the unique labels of `y_true` and[39;49;00m
    [33m        `y_pred` will be used.[39;49;00m
    [33m[39;49;00m
    [33m    include_values : bool, default=True[39;49;00m
    [33m        Includes values in confusion matrix.[39;49;00m
    [33m[39;49;00m
    [33m    xticks_rotation : {'vertical', 'horizontal'} or float, \[39;49;00m
    [33m            default='horizontal'[39;49;00m
    [33m        Rotation of xtick labels.[39;49;00m
    [33m[39;49;00m
    [33m    values_format : str, default=None[39;49;00m
    [33m        Format specification for values in confusion matrix. If `None`, the[39;49;00m
    [33m        format specification is 'd' or '.2g' whichever is shorter.[39;49;00m
    [33m[39;49;00m
    [33m    cmap : str or matplotlib Colormap, default='viridis'[39;49;00m
    [33m        Colormap recognized by matplotlib.[39;49;00m
    [33m[39;49;00m
    [33m    ax : matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    colorbar : bool, default=True[39;49;00m
    [33m        Whether or not to add a colorbar to the plot.[39;49;00m
    [33m[39;49;00m
    [33m    im_kw : dict, default=None[39;49;00m
    [33m        Dict with keywords passed to `matplotlib.pyplot.imshow` call.[39;49;00m
    [33m[39;49;00m
    [33m    text_kw : dict, default=None[39;49;00m
    [33m        Dict with keywords passed to `matplotlib.pyplot.text` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.2[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.ConfusionMatrixDisplay`[39;49;00m
    [33m[39;49;00m
    [33m    See Also[39;49;00m
    [33m    --------[39;49;00m
    [33m    ConfusionMatrixDisplay.from_estimator : Plot the confusion matrix[39;49;00m
    [33m        given an estimator, the data, and the label.[39;49;00m
    [33m[39;49;00m
    [33m    Examples[39;49;00m
    [33m    --------[39;49;00m
    [33m    >>> import matplotlib.pyplot as plt[39;49;00m
    [33m    >>> from sklearn.datasets import make_classification[39;49;00m
    [33m    >>> from sklearn.metrics import ConfusionMatrixDisplay[39;49;00m
    [33m    >>> from sklearn.model_selection import train_test_split[39;49;00m
    [33m    >>> from sklearn.svm import SVC[39;49;00m
    [33m    >>> X, y = make_classification(random_state=0)[39;49;00m
    [33m    >>> X_train, X_test, y_train, y_test = train_test_split([39;49;00m
    [33m    ...         X, y, random_state=0)[39;49;00m
    [33m    >>> clf = SVC(random_state=0)[39;49;00m
    [33m    >>> clf.fit(X_train, y_train)[39;49;00m
    [33m    SVC(random_state=0)[39;49;00m
    [33m    >>> y_pred = clf.predict(X_test)[39;49;00m
    [33m    >>> ConfusionMatrixDisplay.from_predictions([39;49;00m
    [33m    ...    y_test, y_pred)[39;49;00m
    [33m    <...>[39;49;00m
    [33m    >>> plt.show()[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
>       check_matplotlib_support([33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m[96mcls[39;49;00m.[91m__name__[39;49;00m[33m}[39;49;00m[33m.from_predictions[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
[1m[31mE       NameError: name 'check_matplotlib_support' is not defined[0m

[1m[31msklearn/metrics/_plot/confusion_matrix.py[0m:472: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_estimator-CalibrationDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.calibration.CalibrationDisplay'>
constructor = 'from_estimator'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m
        [94melse[39;49;00m:  [90m# constructor == "from_estimator"[39;49;00m[90m[39;49;00m
>           curve = SubclassOfDisplay.from_estimator(classifier, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:300: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/calibration.py[0m:1570: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/calibration.py[0m:1694: in from_predictions
    [0m[94mreturn[39;49;00m disp.plot(ax=ax, ref_line=ref_line, **kwargs)[90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay object at 0x70902e116920>
ax = None, name = 'LogisticRegression', ref_line = True, kwargs = {}
info_pos_label = '(Positive class: 1)'
default_line_kwargs = {'label': 'LogisticRegression', 'linestyle': '-', 'marker': 's'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([96mself[39;49;00m, *, ax=[94mNone[39;49;00m, name=[94mNone[39;49;00m, ref_line=[94mTrue[39;49;00m, **kwargs):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to[39;49;00m
    [33m    :func:`matplotlib.pyplot.plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name for labeling curve. If `None`, use `estimator_name` if[39;49;00m
    [33m        not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    ref_line : bool, default=True[39;49;00m
    [33m        If `True`, plots a reference line representing a perfectly[39;49;00m
    [33m        calibrated classifier.[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to :func:`matplotlib.pyplot.plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.calibration.CalibrationDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        info_pos_label = ([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m(Positive class: [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.pos_label[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m [94mif[39;49;00m [96mself[39;49;00m.pos_label [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [33m"[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mmarker[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33ms[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m-[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/calibration.py[0m:1441: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_estimator-PrecisionRecallDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.precision_recall_curve.PrecisionRecallDisplay'>
constructor = 'from_estimator'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m
        [94melse[39;49;00m:  [90m# constructor == "from_estimator"[39;49;00m[90m[39;49;00m
>           curve = SubclassOfDisplay.from_estimator(classifier, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:300: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:408: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:575: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay object at 0x70902e0f1ae0>
ax = None, name = 'LogisticRegression', plot_chance_level = False
chance_level_kw = None, despine = False, kwargs = {}
default_line_kwargs = {'drawstyle': 'steps-post', 'label': 'LogisticRegression (AP = 1.00)'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Extra keyword arguments will be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : Matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str, default=None[39;49;00m
    [33m        Name of precision recall curve for labeling. If `None`, use[39;49;00m
    [33m        `name` if not `None`, otherwise no labeling is shown.[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level. The chance level is the prevalence[39;49;00m
    [33m        of the positive label computed from the data passed during[39;49;00m
    [33m        :meth:`from_estimator` or :meth:`from_predictions` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.PrecisionRecallDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m[39;49;00m
    [33m    Notes[39;49;00m
    [33m    -----[39;49;00m
    [33m    The average precision (cf. :func:`~sklearn.metrics.average_precision_score`)[39;49;00m
    [33m    in scikit-learn is computed without any interpolation. To be consistent[39;49;00m
    [33m    with this metric, the precision-recall curve is plotted without any[39;49;00m
    [33m    interpolation as well (step-wise style).[39;49;00m
    [33m[39;49;00m
    [33m    You can change this style by passing the keyword argument[39;49;00m
    [33m    `drawstyle="default"`. However, the curve will not be strictly[39;49;00m
    [33m    consistent with the reported average precision.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [96mself[39;49;00m.ax_, [96mself[39;49;00m.figure_, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
    [90m[39;49;00m
        default_line_kwargs = {[33m"[39;49;00m[33mdrawstyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33msteps-post[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = ([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mname[33m}[39;49;00m[33m (AP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94melif[39;49;00m [96mself[39;49;00m.average_precision [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mAP = [39;49;00m[33m{[39;49;00m[96mself[39;49;00m.average_precision[33m:[39;49;00m[33m0.2f[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m name [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            default_line_kwargs[[33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m] = name[90m[39;49;00m
    [90m[39;49;00m
>       line_kwargs = _validate_style_kwargs(default_line_kwargs, kwargs)[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/precision_recall_curve.py[0m:217: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_estimator-RocCurveDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.roc_curve.RocCurveDisplay'>
constructor = 'from_estimator'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m
        [94melse[39;49;00m:  [90m# constructor == "from_estimator"[39;49;00m[90m[39;49;00m
>           curve = SubclassOfDisplay.from_estimator(classifier, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:300: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:441: in from_estimator
    [0m[94mreturn[39;49;00m [96mcls[39;49;00m.from_predictions([90m[39;49;00m
[1m[31msklearn/metrics/_plot/roc_curve.py[0m:607: in from_predictions
    [0m[94mreturn[39;49;00m viz.plot([90m[39;49;00m
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay object at 0x70902dfc6d70>
ax = None, name = ['LogisticRegression']
curve_kwargs = [{'label': 'LogisticRegression (AUC = 1.00)'}]
plot_chance_level = False, chance_level_kw = {}, despine = False, kwargs = {}
fpr = [array([0., 0., 0., 1.])], tpr = [array([0.  , 0.02, 1.  , 1.  ])]

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mplot[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name=[94mNone[39;49;00m,[90m[39;49;00m
        curve_kwargs=[94mNone[39;49;00m,[90m[39;49;00m
        plot_chance_level=[94mFalse[39;49;00m,[90m[39;49;00m
        chance_level_kw=[94mNone[39;49;00m,[90m[39;49;00m
        despine=[94mFalse[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot visualization.[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    ax : matplotlib axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    name : str or list of str, default=None[39;49;00m
    [33m        Name for labeling legend entries. The number of legend entries[39;49;00m
    [33m        is determined by `curve_kwargs`, and is not affected by `name`.[39;49;00m
    [33m        To label each curve, provide a list of strings. To avoid labeling[39;49;00m
    [33m        individual curves that have the same appearance, a list cannot be used in[39;49;00m
    [33m        conjunction with `curve_kwargs` being a dictionary or None. If a[39;49;00m
    [33m        string is provided, it will be used to either label the single legend entry[39;49;00m
    [33m        or if there are multiple legend entries, label each individual curve with[39;49;00m
    [33m        the same name. If `None`, set to `name` provided at `RocCurveDisplay`[39;49;00m
    [33m        initialization. If still `None`, no name is shown in the legend.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    curve_kwargs : dict or list of dict, default=None[39;49;00m
    [33m        Keywords arguments to be passed to matplotlib's `plot` function[39;49;00m
    [33m        to draw individual ROC curves. For single curve plotting, should be[39;49;00m
    [33m        a dictionary. For multi-curve plotting, if a list is provided the[39;49;00m
    [33m        parameters are applied to the ROC curves of each CV fold[39;49;00m
    [33m        sequentially and a legend entry is added for each curve.[39;49;00m
    [33m        If a single dictionary is provided, the same parameters are applied[39;49;00m
    [33m        to all ROC curves and a single legend entry for all curves is added,[39;49;00m
    [33m        labeled with the mean ROC AUC score.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.7[39;49;00m
    [33m[39;49;00m
    [33m    plot_chance_level : bool, default=False[39;49;00m
    [33m        Whether to plot the chance level.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    chance_level_kw : dict, default=None[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot` for rendering[39;49;00m
    [33m        the chance level line.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.3[39;49;00m
    [33m[39;49;00m
    [33m    despine : bool, default=False[39;49;00m
    [33m        Whether to remove the top and right spines from the plot.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.6[39;49;00m
    [33m[39;49;00m
    [33m    **kwargs : dict[39;49;00m
    [33m        Keyword arguments to be passed to matplotlib's `plot`.[39;49;00m
    [33m[39;49;00m
    [33m        .. deprecated:: 1.7[39;49;00m
    [33m            kwargs is deprecated and will be removed in 1.9. Pass matplotlib[39;49;00m
    [33m            arguments to `curve_kwargs` as a dictionary instead.[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.RocCurveDisplay`[39;49;00m
    [33m        Object that stores computed values.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        fpr, tpr, roc_auc, name = [96mself[39;49;00m._validate_plot_params(ax=ax, name=name)[90m[39;49;00m
        n_curves = [96mlen[39;49;00m(fpr)[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(curve_kwargs, [96mlist[39;49;00m) [95mand[39;49;00m n_curves > [94m1[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m roc_auc:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: np.mean(roc_auc), [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: np.std(roc_auc)}[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                legend_metric = {[33m"[39;49;00m[33mmean[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m, [33m"[39;49;00m[33mstd[39;49;00m[33m"[39;49;00m: [94mNone[39;49;00m}[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            roc_auc = roc_auc [94mif[39;49;00m roc_auc [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m [[94mNone[39;49;00m] * n_curves[90m[39;49;00m
            legend_metric = {[33m"[39;49;00m[33mmetric[39;49;00m[33m"[39;49;00m: roc_auc}[90m[39;49;00m
    [90m[39;49;00m
        curve_kwargs = [96mself[39;49;00m._validate_curve_kwargs([90m[39;49;00m
            n_curves,[90m[39;49;00m
            name,[90m[39;49;00m
            legend_metric,[90m[39;49;00m
            [33m"[39;49;00m[33mAUC[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            curve_kwargs=curve_kwargs,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        default_chance_level_line_kw = {[90m[39;49;00m
            [33m"[39;49;00m[33mlabel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mChance level (AUC = 0.5)[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcolor[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mk[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mlinestyle[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m--[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m chance_level_kw [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            chance_level_kw = {}[90m[39;49;00m
    [90m[39;49;00m
>       chance_level_kw = _validate_style_kwargs([90m[39;49;00m
            default_chance_level_line_kw, chance_level_kw[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name '_validate_style_kwargs' is not defined[0m

[1m[31msklearn/metrics/_plot/roc_curve.py[0m:268: NameError
[31m[1m_ test_classifier_display_curve_named_constructor_return_type[from_estimator-ConfusionMatrixDisplay] _[0m

pyplot = <module 'matplotlib.pyplot' from '/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/pyplot.py'>
data_binary = (array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
 ...,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1]))
Display = <class 'sklearn.metrics._plot.confusion_matrix.ConfusionMatrixDisplay'>
constructor = 'from_estimator'

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mDisplay[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            CalibrationDisplay,[90m[39;49;00m
            DetCurveDisplay,[90m[39;49;00m
            PrecisionRecallDisplay,[90m[39;49;00m
            RocCurveDisplay,[90m[39;49;00m
            PredictionErrorDisplay,[90m[39;49;00m
            ConfusionMatrixDisplay,[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mconstructor[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mfrom_estimator[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_classifier_display_curve_named_constructor_return_type[39;49;00m([90m[39;49;00m
        pyplot, data_binary, Display, constructor[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Check that named constructors return the correct type when subclassed.[39;49;00m
    [33m[39;49;00m
    [33m    Non-regression test for:[39;49;00m
    [33m    https://github.com/scikit-learn/scikit-learn/pull/27675[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        X, y = data_binary[90m[39;49;00m
    [90m[39;49;00m
        [90m# This can be anything - we just need to check the named constructor return[39;49;00m[90m[39;49;00m
        [90m# type so the only requirement here is instantiating the class without error[39;49;00m[90m[39;49;00m
        y_pred = y[90m[39;49;00m
    [90m[39;49;00m
        classifier = LogisticRegression().fit(X, y)[90m[39;49;00m
    [90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mSubclassOfDisplay[39;49;00m(Display):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m constructor == [33m"[39;49;00m[33mfrom_predictions[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            curve = SubclassOfDisplay.from_predictions(y, y_pred)[90m[39;49;00m
        [94melse[39;49;00m:  [90m# constructor == "from_estimator"[39;49;00m[90m[39;49;00m
>           curve = SubclassOfDisplay.from_estimator(classifier, X, y)[90m[39;49;00m

[1m[31msklearn/metrics/_plot/tests/test_common_curve_display.py[0m:300: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'sklearn.metrics._plot.tests.test_common_curve_display.test_classifier_display_curve_named_constructor_return_type.<locals>.SubclassOfDisplay'>
estimator = LogisticRegression()
X = array([[5.1, 3.5, 1.4, 0.2],
       [4.9, 3. , 1.4, 0.2],
       [4.7, 3.2, 1.3, 0.2],
       [4.6, 3.1, 1.5, 0.2],
  ...],
       [5.7, 2.9, 4.2, 1.3],
       [6.2, 2.9, 4.3, 1.3],
       [5.1, 2.5, 3. , 1.1],
       [5.7, 2.8, 4.1, 1.3]])
y = array([0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
       0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,...1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
       1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1])

    [0m[37m@classmethod[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mfrom_estimator[39;49;00m([90m[39;49;00m
        [96mcls[39;49;00m,[90m[39;49;00m
        estimator,[90m[39;49;00m
        X,[90m[39;49;00m
        y,[90m[39;49;00m
        *,[90m[39;49;00m
        labels=[94mNone[39;49;00m,[90m[39;49;00m
        sample_weight=[94mNone[39;49;00m,[90m[39;49;00m
        normalize=[94mNone[39;49;00m,[90m[39;49;00m
        display_labels=[94mNone[39;49;00m,[90m[39;49;00m
        include_values=[94mTrue[39;49;00m,[90m[39;49;00m
        xticks_rotation=[33m"[39;49;00m[33mhorizontal[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        values_format=[94mNone[39;49;00m,[90m[39;49;00m
        cmap=[33m"[39;49;00m[33mviridis[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        ax=[94mNone[39;49;00m,[90m[39;49;00m
        colorbar=[94mTrue[39;49;00m,[90m[39;49;00m
        im_kw=[94mNone[39;49;00m,[90m[39;49;00m
        text_kw=[94mNone[39;49;00m,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Plot Confusion Matrix given an estimator and some data.[39;49;00m
    [33m[39;49;00m
    [33m    For general information regarding `scikit-learn` visualization tools, see[39;49;00m
    [33m    the :ref:`Visualization Guide <visualizations>`.[39;49;00m
    [33m    For guidance on interpreting these plots, refer to the[39;49;00m
    [33m    :ref:`Model Evaluation Guide <confusion_matrix>`.[39;49;00m
    [33m[39;49;00m
    [33m    .. versionadded:: 1.0[39;49;00m
    [33m[39;49;00m
    [33m    Parameters[39;49;00m
    [33m    ----------[39;49;00m
    [33m    estimator : estimator instance[39;49;00m
    [33m        Fitted classifier or a fitted :class:`~sklearn.pipeline.Pipeline`[39;49;00m
    [33m        in which the last estimator is a classifier.[39;49;00m
    [33m[39;49;00m
    [33m    X : {array-like, sparse matrix} of shape (n_samples, n_features)[39;49;00m
    [33m        Input values.[39;49;00m
    [33m[39;49;00m
    [33m    y : array-like of shape (n_samples,)[39;49;00m
    [33m        Target values.[39;49;00m
    [33m[39;49;00m
    [33m    labels : array-like of shape (n_classes,), default=None[39;49;00m
    [33m        List of labels to index the confusion matrix. This may be used to[39;49;00m
    [33m        reorder or select a subset of labels. If `None` is given, those[39;49;00m
    [33m        that appear at least once in `y_true` or `y_pred` are used in[39;49;00m
    [33m        sorted order.[39;49;00m
    [33m[39;49;00m
    [33m    sample_weight : array-like of shape (n_samples,), default=None[39;49;00m
    [33m        Sample weights.[39;49;00m
    [33m[39;49;00m
    [33m    normalize : {'true', 'pred', 'all'}, default=None[39;49;00m
    [33m        Either to normalize the counts display in the matrix:[39;49;00m
    [33m[39;49;00m
    [33m        - if `'true'`, the confusion matrix is normalized over the true[39;49;00m
    [33m          conditions (e.g. rows);[39;49;00m
    [33m        - if `'pred'`, the confusion matrix is normalized over the[39;49;00m
    [33m          predicted conditions (e.g. columns);[39;49;00m
    [33m        - if `'all'`, the confusion matrix is normalized by the total[39;49;00m
    [33m          number of samples;[39;49;00m
    [33m        - if `None` (default), the confusion matrix will not be normalized.[39;49;00m
    [33m[39;49;00m
    [33m    display_labels : array-like of shape (n_classes,), default=None[39;49;00m
    [33m        Target names used for plotting. By default, `labels` will be used[39;49;00m
    [33m        if it is defined, otherwise the unique labels of `y_true` and[39;49;00m
    [33m        `y_pred` will be used.[39;49;00m
    [33m[39;49;00m
    [33m    include_values : bool, default=True[39;49;00m
    [33m        Includes values in confusion matrix.[39;49;00m
    [33m[39;49;00m
    [33m    xticks_rotation : {'vertical', 'horizontal'} or float, \[39;49;00m
    [33m            default='horizontal'[39;49;00m
    [33m        Rotation of xtick labels.[39;49;00m
    [33m[39;49;00m
    [33m    values_format : str, default=None[39;49;00m
    [33m        Format specification for values in confusion matrix. If `None`, the[39;49;00m
    [33m        format specification is 'd' or '.2g' whichever is shorter.[39;49;00m
    [33m[39;49;00m
    [33m    cmap : str or matplotlib Colormap, default='viridis'[39;49;00m
    [33m        Colormap recognized by matplotlib.[39;49;00m
    [33m[39;49;00m
    [33m    ax : matplotlib Axes, default=None[39;49;00m
    [33m        Axes object to plot on. If `None`, a new figure and axes is[39;49;00m
    [33m        created.[39;49;00m
    [33m[39;49;00m
    [33m    colorbar : bool, default=True[39;49;00m
    [33m        Whether or not to add a colorbar to the plot.[39;49;00m
    [33m[39;49;00m
    [33m    im_kw : dict, default=None[39;49;00m
    [33m        Dict with keywords passed to `matplotlib.pyplot.imshow` call.[39;49;00m
    [33m[39;49;00m
    [33m    text_kw : dict, default=None[39;49;00m
    [33m        Dict with keywords passed to `matplotlib.pyplot.text` call.[39;49;00m
    [33m[39;49;00m
    [33m        .. versionadded:: 1.2[39;49;00m
    [33m[39;49;00m
    [33m    Returns[39;49;00m
    [33m    -------[39;49;00m
    [33m    display : :class:`~sklearn.metrics.ConfusionMatrixDisplay`[39;49;00m
    [33m[39;49;00m
    [33m    See Also[39;49;00m
    [33m    --------[39;49;00m
    [33m    ConfusionMatrixDisplay.from_predictions : Plot the confusion matrix[39;49;00m
    [33m        given the true and predicted labels.[39;49;00m
    [33m[39;49;00m
    [33m    Examples[39;49;00m
    [33m    --------[39;49;00m
    [33m    >>> import matplotlib.pyplot as plt[39;49;00m
    [33m    >>> from sklearn.datasets import make_classification[39;49;00m
    [33m    >>> from sklearn.metrics import ConfusionMatrixDisplay[39;49;00m
    [33m    >>> from sklearn.model_selection import train_test_split[39;49;00m
    [33m    >>> from sklearn.svm import SVC[39;49;00m
    [33m    >>> X, y = make_classification(random_state=0)[39;49;00m
    [33m    >>> X_train, X_test, y_train, y_test = train_test_split([39;49;00m
    [33m    ...         X, y, random_state=0)[39;49;00m
    [33m    >>> clf = SVC(random_state=0)[39;49;00m
    [33m    >>> clf.fit(X_train, y_train)[39;49;00m
    [33m    SVC(random_state=0)[39;49;00m
    [33m    >>> ConfusionMatrixDisplay.from_estimator([39;49;00m
    [33m    ...     clf, X_test, y_test)[39;49;00m
    [33m    <...>[39;49;00m
    [33m    >>> plt.show()[39;49;00m
    [33m[39;49;00m
    [33m    For a detailed example of using a confusion matrix to evaluate a[39;49;00m
    [33m    Support Vector Classifier, please see[39;49;00m
    [33m    :ref:`sphx_glr_auto_examples_model_selection_plot_confusion_matrix.py`[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        method_name = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m[96mcls[39;49;00m.[91m__name__[39;49;00m[33m}[39;49;00m[33m.from_estimator[39;49;00m[33m"[39;49;00m[90m[39;49;00m
>       check_matplotlib_support(method_name)[90m[39;49;00m
[1m[31mE       NameError: name 'check_matplotlib_support' is not defined[0m

[1m[31msklearn/metrics/_plot/confusion_matrix.py[0m:331: NameError
[36m[1m=========================== short test summary info ============================[0m
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_estimator_name_multiple_calls[from_estimator-PrecisionRecallDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_estimator_name_multiple_calls[from_estimator-RocCurveDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_estimator_name_multiple_calls[from_predictions-PrecisionRecallDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_estimator_name_multiple_calls[from_predictions-RocCurveDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors_old_name[PrecisionRecallDisplay-clf0][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors_old_name[PrecisionRecallDisplay-clf1][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors_old_name[PrecisionRecallDisplay-clf2][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors_old_name[RocCurveDisplay-clf0][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors_old_name[RocCurveDisplay-clf1][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors_old_name[RocCurveDisplay-clf2][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors[RocCurveDisplay-clf0][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors[RocCurveDisplay-clf1][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_display_curve_not_fitted_errors[RocCurveDisplay-clf2][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_predictions-CalibrationDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_predictions-PrecisionRecallDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_predictions-RocCurveDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_predictions-ConfusionMatrixDisplay][0m - NameError: name 'check_matplotlib_support' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_estimator-CalibrationDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_estimator-PrecisionRecallDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_estimator-RocCurveDisplay][0m - NameError: name '_validate_style_kwargs' is not defined
[31mFAILED[0m sklearn/metrics/_plot/tests/test_common_curve_display.py::[1mtest_classifier_display_curve_named_constructor_return_type[from_estimator-ConfusionMatrixDisplay][0m - NameError: name 'check_matplotlib_support' is not defined
[31m[31m[1m21 failed[0m, [32m37 passed[0m[31m in 1.03s[0m[0m
```

## 原始行 54 · file_change

```
{
  "id": "item_36",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/sklearn/calibration.py",
      "kind": "update"
    },
    {
      "path": "/testbed/sklearn/metrics/_plot/confusion_matrix.py",
      "kind": "update"
    },
    {
      "path": "/testbed/sklearn/metrics/_plot/precision_recall_curve.py",
      "kind": "update"
    },
    {
      "path": "/testbed/sklearn/metrics/_plot/roc_curve.py",
      "kind": "update"
    },
    {
      "path": "/testbed/sklearn/model_selection/_plot.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 57 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest sklearn/metrics/_plot/tests/test_common_curve_display.py -q'
```

退出码：`0`

输出：
```
[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m               [100%][0m
[32m[32m[1m58 passed[0m[32m in 0.77s[0m[0m
```

## 原始行 59 · agent_message

```
The shared-helper restoration exposed missing imports in several existing plotting consumers; those are now repaired, and the visible common display suite passes. I’m moving on to focused behavioral checks for both plot modes, deterministic subsampling, style precedence, estimator errors, and exact artist/axis attributes.
```

## 原始行 61 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.metrics import PredictionErrorDisplay
from sklearn.tree import DecisionTreeRegressor

y_true=np.array([-2., 1., 4., 8.])
y_pred=np.array([-1., 2., 3., 7.])
for kind in ['actual_vs_predicted','residual_vs_predicted']:
    d=PredictionErrorDisplay.from_predictions(y_true,y_pred,kind=kind,subsample=None)
    print(kind)
    print('offsets', d.scatter_.get_offsets().tolist())
    print('line', d.line_.get_xdata().tolist(), d.line_.get_ydata().tolist())
    print('labels',d.ax_.get_xlabel(),d.ax_.get_ylabel(),'aspect',d.ax_.get_aspect())
    print('ticks',d.ax_.get_xticks().tolist(),d.ax_.get_yticks().tolist())
    print('styles',d.scatter_.get_alpha(),d.line_.get_alpha(),d.line_.get_linestyle())
    plt.close(d.figure_)

d1=PredictionErrorDisplay.from_predictions(np.arange(20),np.arange(20)+1,subsample=0.25,random_state=42)
d2=PredictionErrorDisplay.from_predictions(np.arange(20),np.arange(20)+1,subsample=5,random_state=42)
print('samples equal',np.array_equal(d1.y_true,d2.y_true),d1.y_true)
plt.close('all')

d=PredictionErrorDisplay.from_predictions(y_true,y_pred,scatter_kwargs={'c':'red','alpha':.2},line_kwargs={'c':'green','ls':':'})
print('custom',d.scatter_.get_facecolor(),d.scatter_.get_alpha(),d.line_.get_color(),d.line_.get_linestyle())
try:
 PredictionErrorDisplay(y_true=y_true,y_pred=y_pred).plot(kind='bad')
except Exception as e: print('bad kind',type(e).__name__,str(e))
try:
 PredictionErrorDisplay.from_predictions(y_true,y_pred,subsample=-2)
except Exception as e: print('bad sample',type(e).__name__,str(e))
try:
 PredictionErrorDisplay.from_predictions(y_true,y_pred,scatter_kwargs={'c':'r','color':'b'})
except Exception as e: print('bad style',type(e).__name__,str(e))
PY"
```

退出码：`0`

输出：
```
actual_vs_predicted
offsets [[-1.0, -2.0], [2.0, 1.0], [3.0, 4.0], [7.0, 8.0]]
line [-2.0, 8.0] [-2.0, 8.0]
labels Predicted values Actual values aspect 1.0
ticks [-2.0, 0.5, 3.0, 5.5, 8.0] [-2.0, 0.5, 3.0, 5.5, 8.0]
styles 0.8 0.7 --
residual_vs_predicted
offsets [[-1.0, -1.0], [2.0, -1.0], [3.0, 1.0], [7.0, 1.0]]
line [-1.0, 7.0] [0, 0]
labels Predicted values Residuals (actual - predicted) aspect auto
ticks [-2.0, -1.0, 0.0, 1.0, 2.0, 3.0, 4.0, 5.0, 6.0, 7.0, 8.0] [-1.25, -1.0, -0.75, -0.5, -0.25, 0.0, 0.25, 0.5, 0.75, 1.0, 1.25]
styles 0.8 0.7 --
samples equal True [ 0 17 15  1  8]
custom [[1.  0.  0.  0.2]] 0.2 green :
bad kind ValueError `kind` must be one of ('actual_vs_predicted', 'residual_vs_predicted'). Got 'bad' instead.
bad sample ValueError When an integer, subsample=-2 should be positive.
bad style TypeError Got both c and color, which are aliases of one another
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc 'ruff check sklearn/metrics/_plot/regression.py sklearn/utils/_plotting.py sklearn/utils/_optional_dependencies.py sklearn/calibration.py sklearn/metrics/_plot/confusion_matrix.py sklearn/metrics/_plot/precision_recall_curve.py sklearn/metrics/_plot/roc_curve.py sklearn/model_selection/_plot.py'
```

退出码：`127`

输出：
```
/bin/bash: line 1: ruff: command not found
```

## 原始行 68 · command_execution

命令：
```
/bin/bash -lc 'python -m black --check sklearn/metrics/_plot/regression.py sklearn/utils/_plotting.py sklearn/utils/_optional_dependencies.py sklearn/calibration.py sklearn/metrics/_plot/confusion_matrix.py sklearn/metrics/_plot/precision_recall_curve.py sklearn/metrics/_plot/roc_curve.py sklearn/model_selection/_plot.py'
```

退出码：`1`

输出：
```
/opt/miniconda3/envs/testbed/bin/python: No module named black
```

## 原始行 71 · command_execution

命令：
```
/bin/bash -lc 'git diff --check && git diff --stat && git diff -- sklearn/metrics/_plot/regression.py sklearn/utils/_plotting.py sklearn/utils/_optional_dependencies.py'
```

退出码：`0`

输出：
```
 sklearn/calibration.py                          |   7 +-
 sklearn/metrics/_plot/confusion_matrix.py       |   4 +-
 sklearn/metrics/_plot/precision_recall_curve.py |   8 +-
 sklearn/metrics/_plot/regression.py             | 178 +++++++++++++++++++++++-
 sklearn/metrics/_plot/roc_curve.py              |  10 +-
 sklearn/model_selection/_plot.py                |   1 +
 sklearn/utils/_optional_dependencies.py         |  26 +++-
 sklearn/utils/_plotting.py                      |  37 ++++-
 8 files changed, 259 insertions(+), 12 deletions(-)
diff --git a/sklearn/metrics/_plot/regression.py b/sklearn/metrics/_plot/regression.py
index 6af5a9c..bf82940 100644
--- a/sklearn/metrics/_plot/regression.py
+++ b/sklearn/metrics/_plot/regression.py
@@ -6,8 +6,8 @@ import numbers
 import numpy as np
 
 from sklearn.utils import _safe_indexing, check_random_state
-
-
+from sklearn.utils._optional_dependencies import check_matplotlib_support
+from sklearn.utils._plotting import _validate_style_kwargs
 
 
 class PredictionErrorDisplay:
@@ -78,3 +78,177 @@ class PredictionErrorDisplay:
     >>> plt.show()
     """
 
+    def __init__(self, *, y_true, y_pred):
+        """Store the true and predicted target values."""
+        self.y_true = y_true
+        self.y_pred = y_pred
+
+    def plot(
+        self,
+        ax=None,
+        *,
+        kind="residual_vs_predicted",
+        scatter_kwargs=None,
+        line_kwargs=None,
+    ):
+        """Plot the prediction error.
+
+        Parameters
+        ----------
+        ax : matplotlib axes, default=None
+            Axes object to plot on. If `None`, a new figure and axes is
+            created.
+
+        kind : {"actual_vs_predicted", "residual_vs_predicted"}, \
+                default="residual_vs_predicted"
+            The type of plot to draw.
+
+        scatter_kwargs : dict, default=None
+            Dictionary with keywords passed to :meth:`matplotlib.axes.Axes.scatter`.
+
+        line_kwargs : dict, default=None
+            Dictionary with keywords passed to :meth:`matplotlib.axes.Axes.plot`.
+
+        Returns
+        -------
+        display : :class:`~sklearn.metrics.PredictionErrorDisplay`
+            Returns the display instance.
+        """
+        check_matplotlib_support(f"{self.__class__.__name__}.plot")
+        import matplotlib.pyplot as plt
+
+        valid_kinds = ("actual_vs_predicted", "residual_vs_predicted")
+        if kind not in valid_kinds:
+            raise ValueError(
+                f"`kind` must be one of {valid_kinds}. Got {kind!r} instead."
+            )
+
+        if ax is None:
+            _, ax = plt.subplots()
+
+        scatter_kwargs = _validate_style_kwargs(
+            {"color": "tab:blue", "alpha": 0.8},
+            {} if scatter_kwargs is None else scatter_kwargs,
+        )
+        line_kwargs = _validate_style_kwargs(
+            {"color": "black", "alpha": 0.7, "linestyle": "--"},
+            {} if line_kwargs is None else line_kwargs,
+        )
+
+        if kind == "actual_vs_predicted":
+            min_value = min(np.min(self.y_true), np.min(self.y_pred))
+            max_value = max(np.max(self.y_true), np.max(self.y_pred))
+
+            self.scatter_ = ax.scatter(self.y_pred, self.y_true, **scatter_kwargs)
+            self.line_ = ax.plot(
+                [min_value, max_value],
+                [min_value, max_value],
+                **line_kwargs,
+            )[0]
+            ax.set(
+                xlabel="Predicted values",
+                ylabel="Actual values",
+            )
+            ax.set_aspect("equal", adjustable="datalim")
+            ticks = np.linspace(min_value, max_value, num=5)
+            ax.set_xticks(ticks)
+            ax.set_yticks(ticks)
+        else:
+            residuals = self.y_true - self.y_pred
+            min_value = np.min(self.y_pred)
+            max_value = np.max(self.y_pred)
+
+            self.scatter_ = ax.scatter(self.y_pred, residuals, **scatter_kwargs)
+            self.line_ = ax.plot(
+                [min_value, max_value], [0, 0], **line_kwargs
+            )[0]
+            ax.set(
+                xlabel="Predicted values",
+                ylabel="Residuals (actual - predicted)",
+            )
+
+        self.ax_ = ax
+        self.figure_ = ax.figure
+        return self
+
+    @classmethod
+    def from_estimator(
+        cls,
+        estimator,
+        X,
+        y,
+        *,
+        kind="residual_vs_predicted",
+        subsample=1000,
+        random_state=None,
+        ax=None,
+        scatter_kwargs=None,
+        line_kwargs=None,
+    ):
+        """Plot the prediction error given a regressor and some data."""
+        y_pred = estimator.predict(X)
+        return cls.from_predictions(
+            y_true=y,
+            y_pred=y_pred,
+            kind=kind,
+            subsample=subsample,
+            random_state=random_state,
+            ax=ax,
+            scatter_kwargs=scatter_kwargs,
+            line_kwargs=line_kwargs,
+        )
+
+    @classmethod
+    def from_predictions(
+        cls,
+        y_true,
+        y_pred,
+        *,
+        kind="residual_vs_predicted",
+        subsample=1000,
+        random_state=None,
+        ax=None,
+        scatter_kwargs=None,
+        line_kwargs=None,
+    ):
+        """Plot the prediction error given true and predicted targets."""
+        check_matplotlib_support(f"{cls.__name__}.from_predictions")
+
+        if isinstance(subsample, numbers.Integral):
+            if subsample <= 0:
+                raise ValueError(
+                    f"When an integer, subsample={subsample} should be positive."
+                )
+        elif isinstance(subsample, numbers.Real):
+            if subsample <= 0 or subsample >= 1:
+                raise ValueError(
+                    f"When a floating-point, subsample={subsample} should be in "
+                    "the (0, 1) range."
+                )
+        elif subsample is not None:
+            raise TypeError(
+                "`subsample` must be an int, a float in the (0, 1) range, or None."
+            )
+
+        y_true = np.asarray(y_true)
+        y_pred = np.asarray(y_pred)
+
+        if subsample is not None:
+            n_samples = y_true.shape[0]
+            if isinstance(subsample, numbers.Integral):
+                n_samples_to_plot = subsample
+            else:
+                n_samples_to_plot = int(n_samples * subsample)
+
+            if n_samples_to_plot < n_samples:
+                rng = check_random_state(random_state)
+                indices = rng.choice(n_samples, size=n_samples_to_plot, replace=False)
+                y_true = _safe_indexing(y_true, indices)
+                y_pred = _safe_indexing(y_pred, indices)
+
+        return cls(y_true=y_true, y_pred=y_pred).plot(
+            ax=ax,
+            kind=kind,
+            scatter_kwargs=scatter_kwargs,
+            line_kwargs=line_kwargs,
+        )
diff --git a/sklearn/utils/_optional_dependencies.py b/sklearn/utils/_optional_dependencies.py
index d884843..003a94b 100644
--- a/sklearn/utils/_optional_dependencies.py
+++ b/sklearn/utils/_optional_dependencies.py
@@ -2,6 +2,30 @@
 # SPDX-License-Identifier: BSD-3-Clause
 
 
+def check_matplotlib_support(caller_name):
+    """Raise an informative error when matplotlib is unavailable.
+
+    Parameters
+    ----------
+    caller_name : str
+        Name of the caller that requires matplotlib.
+
+    Returns
+    -------
+    matplotlib
+        The imported matplotlib module.
+    """
+    try:
+        import matplotlib
+
+        return matplotlib
+    except ImportError as e:
+        raise ImportError(
+            f"{caller_name} requires matplotlib. You can install matplotlib with "
+            "`pip install matplotlib`"
+        ) from e
+
+
 
 
 
@@ -43,4 +67,4 @@ def check_pandas_support(caller_name):
 
         return pandas
     except ImportError as e:
-        raise ImportError("{} requires pandas.".format(caller_name)) from e
\ No newline at end of file
+        raise ImportError("{} requires pandas.".format(caller_name)) from e
diff --git a/sklearn/utils/_plotting.py b/sklearn/utils/_plotting.py
index d3fdd7f..2b21336 100644
--- a/sklearn/utils/_plotting.py
+++ b/sklearn/utils/_plotting.py
@@ -6,7 +6,7 @@ from collections.abc import Mapping
 import numpy as np
 
 from sklearn.utils import check_consistent_length
-
+from sklearn.utils._optional_dependencies import check_matplotlib_support
 from sklearn.utils._response import _get_response_values_binary
 from sklearn.utils.fixes import parse_version
 from sklearn.utils.multiclass import type_of_target
@@ -279,6 +279,39 @@ def _interval_max_min_ratio(data):
     return diff.max() / diff.min()
 
 
+def _validate_style_kwargs(default_style_kwargs, user_style_kwargs):
+    """Merge matplotlib style keywords, accounting for common aliases.
+
+    User-provided values take precedence over defaults. Short matplotlib
+    aliases are normalized to their canonical spelling so that an alias also
+    overrides a default expressed with the long spelling.
+    """
+    invalid_to_valid_kw = {
+        "ls": "linestyle",
+        "c": "color",
+        "ec": "edgecolor",
+        "fc": "facecolor",
+        "lw": "linewidth",
+        "mec": "markeredgecolor",
+        "mfc": "markerfacecolor",
+        "mfcalt": "markerfacecoloralt",
+        "ms": "markersize",
+    }
+
+    for invalid_key, valid_key in invalid_to_valid_kw.items():
+        if invalid_key in user_style_kwargs and valid_key in user_style_kwargs:
+            raise TypeError(
+                f"Got both {invalid_key} and {valid_key}, which are aliases of one "
+                "another"
+            )
+
+    valid_style_kwargs = default_style_kwargs.copy()
+    for key, value in user_style_kwargs.items():
+        valid_style_kwargs[invalid_to_valid_kw.get(key, key)] = value
+
+    return valid_style_kwargs
+
+
 
 
 
@@ -431,4 +464,4 @@ def _deprecate_y_pred_parameter(y_score, y_pred, version):
         )
         return y_pred
 
-    return y_score
\ No newline at end of file
+    return y_score
```

## 原始行 74 · command_execution

命令：
```
/bin/bash -lc 'git diff -- sklearn/calibration.py sklearn/metrics/_plot/confusion_matrix.py sklearn/metrics/_plot/precision_recall_curve.py sklearn/metrics/_plot/roc_curve.py sklearn/model_selection/_plot.py'
```

退出码：`0`

输出：
```
diff --git a/sklearn/calibration.py b/sklearn/calibration.py
index 81d68d3..984c904 100644
--- a/sklearn/calibration.py
+++ b/sklearn/calibration.py
@@ -43,9 +43,10 @@ from sklearn.utils._param_validation import (
     StrOptions,
     validate_params,
 )
-from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin
-
-
+from sklearn.utils._plotting import (
+    _BinaryClassifierCurveDisplayMixin,
+    _validate_style_kwargs,
+)
 
 from sklearn.utils._response import _get_response_values, _process_predict_proba
 from sklearn.utils.extmath import softmax
diff --git a/sklearn/metrics/_plot/confusion_matrix.py b/sklearn/metrics/_plot/confusion_matrix.py
index faef4d2..a39e595 100644
--- a/sklearn/metrics/_plot/confusion_matrix.py
+++ b/sklearn/metrics/_plot/confusion_matrix.py
@@ -7,8 +7,8 @@ import numpy as np
 
 from sklearn.base import is_classifier
 from sklearn.metrics import confusion_matrix
-
-
+from sklearn.utils._optional_dependencies import check_matplotlib_support
+from sklearn.utils._plotting import _validate_style_kwargs
 from sklearn.utils.multiclass import unique_labels
 
 
diff --git a/sklearn/metrics/_plot/precision_recall_curve.py b/sklearn/metrics/_plot/precision_recall_curve.py
index cc983d4..c0ebb76 100644
--- a/sklearn/metrics/_plot/precision_recall_curve.py
+++ b/sklearn/metrics/_plot/precision_recall_curve.py
@@ -4,7 +4,13 @@
 from collections import Counter
 
 from sklearn.metrics._ranking import average_precision_score, precision_recall_curve
-from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin, _deprecate_estimator_name, _deprecate_y_pred_parameter, _despine
+from sklearn.utils._plotting import (
+    _BinaryClassifierCurveDisplayMixin,
+    _deprecate_estimator_name,
+    _deprecate_y_pred_parameter,
+    _despine,
+    _validate_style_kwargs,
+)
 
 
 
diff --git a/sklearn/metrics/_plot/roc_curve.py b/sklearn/metrics/_plot/roc_curve.py
index 03017a3..21af87a 100644
--- a/sklearn/metrics/_plot/roc_curve.py
+++ b/sklearn/metrics/_plot/roc_curve.py
@@ -6,7 +6,15 @@ import numpy as np
 
 from sklearn.metrics._ranking import auc, roc_curve
 from sklearn.utils import _safe_indexing
-from sklearn.utils._plotting import _BinaryClassifierCurveDisplayMixin, _check_param_lengths, _convert_to_list_leaving_none, _deprecate_estimator_name, _deprecate_y_pred_parameter, _despine
+from sklearn.utils._plotting import (
+    _BinaryClassifierCurveDisplayMixin,
+    _check_param_lengths,
+    _convert_to_list_leaving_none,
+    _deprecate_estimator_name,
+    _deprecate_y_pred_parameter,
+    _despine,
+    _validate_style_kwargs,
+)
 
 
 
diff --git a/sklearn/model_selection/_plot.py b/sklearn/model_selection/_plot.py
index 2a0cac6..6d7ef1c 100644
--- a/sklearn/model_selection/_plot.py
+++ b/sklearn/model_selection/_plot.py
@@ -5,6 +5,7 @@ import numpy as np
 
 from sklearn.model_selection._validation import learning_curve, validation_curve
 
+from sklearn.utils._optional_dependencies import check_matplotlib_support
 from sklearn.utils._plotting import _interval_max_min_ratio, _validate_score_name
```

## 原始行 77 · command_execution

命令：
```
/bin/bash -lc "find sklearn -path '*tests*' -name '*.py' -print | xargs grep -l 'check_matplotlib_support\\|requires matplotlib' | head -30; find sklearn -path '*tests*' -name '*.py' -print | xargs grep -n 'check_pandas_support' | head -20"
```

退出码：`0`

输出：
```
sklearn/datasets/tests/test_openml.py:25:from sklearn.utils._optional_dependencies import check_pandas_support
sklearn/datasets/tests/test_openml.py:997:        check_pandas_support("test_fetch_openml_requires_pandas")
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest sklearn/metrics/_plot/tests -q'
```

退出码：`0`

输出：
```
[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 20%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 40%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 60%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 80%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m   [100%][0m
[32m[32m[1m358 passed[0m[32m in 4.88s[0m[0m
```

## 原始行 85 · file_change

```
{
  "id": "item_58",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/sklearn/metrics/_plot/regression.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 88 · command_execution

命令：
```
/bin/bash -lc "find sklearn/model_selection sklearn -path '*tests*' -name '*.py' -print | grep -E 'test_plot|test_calibration' | sort -u | head -30"
```

退出码：`0`

输出：
```
sklearn/inspection/_plot/tests/test_plot_partial_dependence.py
sklearn/model_selection/tests/test_plot.py
sklearn/tests/test_calibration.py
sklearn/utils/tests/test_plotting.py
```

## 原始行 90 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest sklearn/model_selection/tests/test_plot.py sklearn/tests/test_calibration.py -q'
```

退出码：`0`

输出：
```
[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m [ 31%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[33m [ 62%]
[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33m [ 93%]
[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33m                                                          [100%][0m
[33m[32m142 passed[0m, [33m[1m89 skipped[0m, [33m[1m38 warnings[0m[33m in 12.07s[0m[0m
```

## 原始行 93 · command_execution

命令：
```
/bin/bash -lc "for f in sklearn/metrics/_plot/regression.py sklearn/utils/_plotting.py sklearn/utils/_optional_dependencies.py sklearn/calibration.py sklearn/metrics/_plot/confusion_matrix.py sklearn/metrics/_plot/precision_recall_curve.py sklearn/metrics/_plot/roc_curve.py sklearn/model_selection/_plot.py; do awk 'length("'$0)>88 {print FNR ":" length($0) ":" $0}'"' \""'$f" | head -20 | sed "s#''^#$f:#"; done'
```

退出码：`0`

输出：
```

```

## 原始行 96 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
for seed in [0,42]:
 a=np.random.RandomState(seed).choice(20,size=5,replace=False)
 b=np.random.RandomState(seed).choice(np.arange(20),size=5,replace=False)
 print(seed,a,b,np.array_equal(a,b))
PY
python -m compileall -q sklearn/metrics/_plot/regression.py sklearn/utils/_plotting.py sklearn/utils/_optional_dependencies.py sklearn/calibration.py sklearn/metrics/_plot/confusion_matrix.py sklearn/metrics/_plot/precision_recall_curve.py sklearn/metrics/_plot/roc_curve.py sklearn/model_selection/_plot.py
git status --short"
```

退出码：`0`

输出：
```
0 [18  1 19  8 10] [18  1 19  8 10] True
42 [ 0 17 15  1  8] [ 0 17 15  1  8] True
 M sklearn/calibration.py
 M sklearn/metrics/_plot/confusion_matrix.py
 M sklearn/metrics/_plot/precision_recall_curve.py
 M sklearn/metrics/_plot/regression.py
 M sklearn/metrics/_plot/roc_curve.py
 M sklearn/model_selection/_plot.py
 M sklearn/utils/_optional_dependencies.py
 M sklearn/utils/_plotting.py
```

## 原始行 100 · file_change

```
{
  "id": "item_68",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/sklearn/utils/_optional_dependencies.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 103 · command_execution

命令：
```
/bin/bash -lc "grep -R -l \"check_matplotlib_support\" sklearn --include='*.py' | while read f; do grep -qE '"'^(from .* import check_matplotlib_support|def check_matplotlib_support)'"' \""'$f" || echo "missing check import: $f"; done
grep -R -l "_validate_style_kwargs" sklearn --include='"'*.py' | while read f; do grep -qE '(_validate_style_kwargs,|import _validate_style_kwargs|def _validate_style_kwargs)' \""'$f" || echo "missing style import: $f"; done
git diff --check
python -m pytest sklearn/utils/tests/test_plotting.py sklearn/metrics/_plot/tests sklearn/model_selection/tests/test_plot.py -q'
```

退出码：`0`

输出：
```
[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 14%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 29%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 43%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 58%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 73%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 87%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m              [100%][0m
[32m[32m[1m491 passed[0m[32m in 6.33s[0m[0m
```

## 原始行 106 · command_execution

命令：
```
/bin/bash -lc 'find .. -name AGENTS.md -print'
```

退出码：`1`

输出：
```
find: ‘../proc/2571/task/2571/net’: Invalid argument
find: ‘../proc/2571/net’: Invalid argument
find: ‘../proc/2572/task/2572/net’: Invalid argument
find: ‘../proc/2572/net’: Invalid argument
```

## 原始行 109 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from sklearn.metrics import PredictionErrorDisplay
for name in ['__init__','plot','from_estimator','from_predictions']:
 print(name, inspect.signature(getattr(PredictionErrorDisplay,name)))
PY
git diff --check
git status --short"
```

退出码：`0`

输出：
```
__init__ (self, *, y_true, y_pred)
plot (self, ax=None, *, kind='residual_vs_predicted', scatter_kwargs=None, line_kwargs=None)
from_estimator (estimator, X, y, *, kind='residual_vs_predicted', subsample=1000, random_state=None, ax=None, scatter_kwargs=None, line_kwargs=None)
from_predictions (y_true, y_pred, *, kind='residual_vs_predicted', subsample=1000, random_state=None, ax=None, scatter_kwargs=None, line_kwargs=None)
 M sklearn/calibration.py
 M sklearn/metrics/_plot/confusion_matrix.py
 M sklearn/metrics/_plot/precision_recall_curve.py
 M sklearn/metrics/_plot/regression.py
 M sklearn/metrics/_plot/roc_curve.py
 M sklearn/model_selection/_plot.py
 M sklearn/utils/_optional_dependencies.py
 M sklearn/utils/_plotting.py
```

## 原始行 112 · agent_message

```
The focused implementation checks are clean: both modes produce the specified coordinates, reference lines, labels, equal scaling/ticks, defaults, and overrides; deterministic integer/fractional subsampling also matches. The combined plotting/utilities/model-selection verification suite passes 491 tests.
```

## 原始行 114 · agent_message

```
Implemented `PredictionErrorDisplay` in [regression.py](/testbed/sklearn/metrics/_plot/regression.py) with:

- Actual-vs-predicted and residual-vs-predicted modes
- Estimator and direct-prediction constructors
- Deterministic integer/fractional subsampling
- Matplotlib customization, reference lines, labels, scaling, and ticks
- Artist attributes and subclass-compatible constructors
- Validation for plot kinds, subsampling, and conflicting style aliases
- Restored required shared plotting helpers and imports

Verification: 491 focused tests passed, plus 142 calibration/model-selection tests passed.
```
