# Codex baseline: astropy__astropy.b0db0daa.test_compression_failures.48dc420b.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the current FITS implementation and targeted tests first, then patch only the missing helpers and run the relevant test subsets.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc 'git status --short && rg -n "def (__contains__|_cardindex|_haswildcard|_relativeinsert|_set_slice|_update|get|insert|remove|_convert_fits2record|_parse_ascii_tformat|_parse_tformat)|def comments|class _DelayedHeader|def _has_data" astropy/io/fits/header.py astropy/io/fits/hdu/base.py astropy/io/fits/column.py'
```

退出码：`127`

输出：
```
/bin/bash: line 1: rg: command not found
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc 'git status --short
grep -nE "def (__contains__|_cardindex|_haswildcard|_relativeinsert|_set_slice|_update|get|insert|remove|_convert_fits2record|_parse_ascii_tformat|_parse_tformat)|def comments|class _DelayedHeader|def _has_data" astropy/io/fits/header.py astropy/io/fits/hdu/base.py astropy/io/fits/column.py'
```

退出码：`0`

输出：
```
astropy/io/fits/header.py:1805:    def _updateindices(self, idx, increment=True):
astropy/io/fits/header.py:1920:class _DelayedHeader:
astropy/io/fits/hdu/base.py:1334:    def _update_checksum(self, checksum_keyword="CHECKSUM", datasum_keyword="DATASUM"):
astropy/io/fits/column.py:1763:    def __contains__(self, key):
astropy/io/fits/column.py:1807:    def _update_column_attribute_changed(self, column, attr, old_value, new_value):
astropy/io/fits/column.py:2046:    def _update_field_metrics(self):
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,360p' astropy/io/fits/header.py
sed -n '360,820p' astropy/io/fits/header.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import collections
import copy
import itertools
import numbers
import os
import re
import warnings

import numpy as np

from astropy.utils.exceptions import AstropyUserWarning

from ._utils import parse_header
from .card import KEYWORD_LENGTH, UNDEFINED, Card, _pad
from .file import _File
from .util import (
    decode_ascii,
    encode_ascii,
    fileobj_closed,
    fileobj_is_binary,
    path_like,
)

BLOCK_SIZE = 2880  # the FITS block size

# This regular expression can match a *valid* END card which just consists of
# the string 'END' followed by all spaces, or an *invalid* end card which
# consists of END, followed by any character that is *not* a valid character
# for a valid FITS keyword (that is, this is not a keyword like 'ENDER' which
# starts with 'END' but is not 'END'), followed by any arbitrary bytes.  An
# invalid end card may also consist of just 'END' with no trailing bytes.
HEADER_END_RE = re.compile(
    encode_ascii(r"(?:(?P<valid>END {77}) *)|(?P<invalid>END$|END {0,76}[^A-Z0-9_-])")
)


# According to the FITS standard the only characters that may appear in a
# header record are the restricted ASCII chars from 0x20 through 0x7E.
VALID_HEADER_CHARS = set(map(chr, range(0x20, 0x7F)))
END_CARD = "END" + " " * 77

_commentary_keywords = Card._commentary_keywords

__doctest_skip__ = [
    "Header",
    "Header.comments",
    "Header.fromtextfile",
    "Header.totextfile",
    "Header.update",
]


class Header:
    """
    FITS header class.  This class exposes both a dict-like interface and a
    list-like interface to FITS headers.

    The header may be indexed by keyword and, like a dict, the associated value
    will be returned.  When the header contains cards with duplicate keywords,
    only the value of the first card with the given keyword will be returned.
    It is also possible to use a 2-tuple as the index in the form (keyword,
    n)--this returns the n-th value with that keyword, in the case where there
    are duplicate keywords.

    For example::

        >>> header['NAXIS']
        0
        >>> header[('FOO', 1)]  # Return the value of the second FOO keyword
        'foo'

    The header may also be indexed by card number::

        >>> header[0]  # Return the value of the first card in the header
        'T'

    Commentary keywords such as HISTORY and COMMENT are special cases: When
    indexing the Header object with either 'HISTORY' or 'COMMENT' a list of all
    the HISTORY/COMMENT values is returned::

        >>> header['HISTORY']
        This is the first history entry in this header.
        This is the second history entry in this header.
        ...

    See the Astropy documentation for more details on working with headers.

    Notes
    -----
    Although FITS keywords must be exclusively upper case, retrieving an item
    in a `Header` object is case insensitive.
    """

    def __init__(self, cards=[], copy=False):
        """
        Construct a `Header` from an iterable and/or text file.

        Parameters
        ----------
        cards : list of `Card`, optional
            The cards to initialize the header with. Also allowed are other
            `Header` (or `dict`-like) objects.

            .. versionchanged:: 1.2
                Allowed ``cards`` to be a `dict`-like object.

        copy : bool, optional

            If ``True`` copies the ``cards`` if they were another `Header`
            instance.
            Default is ``False``.

            .. versionadded:: 1.3
        """
        self.clear()

        if isinstance(cards, Header):
            if copy:
                cards = cards.copy()
            cards = cards.cards
        elif isinstance(cards, dict):
            cards = cards.items()

        for card in cards:
            self.append(card, end=True)

        self._modified = False

    def __len__(self):
        return len(self._cards)

    def __iter__(self):
        for card in self._cards:
            yield card.keyword














    def __getitem__(self, key):
        if isinstance(key, slice):
            return self.__class__([copy.copy(c) for c in self._cards[key]])
        elif self._haswildcard(key):
            return self.__class__(
                [copy.copy(self._cards[idx]) for idx in self._wildcardmatch(key)]
            )
        elif isinstance(key, str):
            key = key.strip()
            if key.upper() in _commentary_keywords:
                key = key.upper()
                # Special case for commentary cards
                return _HeaderCommentaryCards(self, key)

        if isinstance(key, tuple):
            keyword = key[0]
        else:
            keyword = key

        card = self._cards[self._cardindex(key)]

        if card.field_specifier is not None and keyword == card.rawkeyword:
            # This is RVKC; if only the top-level keyword was specified return
            # the raw value, not the parsed out float value
            return card.rawvalue

        value = card.value
        if value == UNDEFINED:
            return None
        return value

    def __setitem__(self, key, value):
        if self._set_slice(key, value, self):
            return

        if isinstance(value, tuple):
            if len(value) > 2:
                raise ValueError(
                    "A Header item may be set with either a scalar value, "
                    "a 1-tuple containing a scalar value, or a 2-tuple "
                    "containing a scalar value and comment string."
                )
            if len(value) == 1:
                value, comment = value[0], None
                if value is None:
                    value = UNDEFINED
            elif len(value) == 2:
                value, comment = value
                if value is None:
                    value = UNDEFINED
                if comment is None:
                    comment = ""
        else:
            comment = None

        card = None
        if isinstance(key, numbers.Integral):
            card = self._cards[key]
        elif isinstance(key, tuple):
            card = self._cards[self._cardindex(key)]
        if value is None:
            value = UNDEFINED
        if card:
            card.value = value
            if comment is not None:
                card.comment = comment
            if card._modified:
                self._modified = True
        else:
            # If we get an IndexError that should be raised; we don't allow
            # assignment to non-existing indices
            self._update((key, value, comment))

    def __delitem__(self, key):
        if isinstance(key, slice) or self._haswildcard(key):
            # This is very inefficient but it's not a commonly used feature.
            # If someone out there complains that they make heavy use of slice
            # deletions and it's too slow, well, we can worry about it then
            # [the solution is not too complicated--it would be wait 'til all
            # the cards are deleted before updating _keyword_indices rather
            # than updating it once for each card that gets deleted]
            if isinstance(key, slice):
                indices = range(*key.indices(len(self)))
                # If the slice step is backwards we want to reverse it, because
                # it will be reversed in a few lines...
                if key.step and key.step < 0:
                    indices = reversed(indices)
            else:
                indices = self._wildcardmatch(key)
            for idx in reversed(indices):
                del self[idx]
            return
        elif isinstance(key, str):
            # delete ALL cards with the same keyword name
            key = Card.normalize_keyword(key)
            indices = self._keyword_indices
            if key not in self._keyword_indices:
                indices = self._rvkc_indices

            if key not in indices:
                # if keyword is not present raise KeyError.
                # To delete keyword without caring if they were present,
                # Header.remove(Keyword) can be used with optional argument ignore_missing as True
                raise KeyError(f"Keyword '{key}' not found.")

            for idx in reversed(indices[key]):
                # Have to copy the indices list since it will be modified below
                del self[idx]
            return

        idx = self._cardindex(key)
        card = self._cards[idx]
        keyword = card.keyword
        del self._cards[idx]
        keyword = Card.normalize_keyword(keyword)
        indices = self._keyword_indices[keyword]
        indices.remove(idx)
        if not indices:
            del self._keyword_indices[keyword]

        # Also update RVKC indices if necessary :/
        if card.field_specifier is not None:
            indices = self._rvkc_indices[card.rawkeyword]
            indices.remove(idx)
            if not indices:
                del self._rvkc_indices[card.rawkeyword]

        # We also need to update all other indices
        self._updateindices(idx, increment=False)
        self._modified = True

    def __repr__(self):
        return self.tostring(sep="\n", endcard=False, padding=False)

    def __str__(self):
        return self.tostring()

    def __eq__(self, other):
        """
        Two Headers are equal only if they have the exact same string
        representation.
        """
        return str(self) == str(other)

    def __add__(self, other):
        temp = self.copy(strip=False)
        temp.extend(other)
        return temp

    def __iadd__(self, other):
        self.extend(other)
        return self

    def _ipython_key_completions_(self):
        return self.__iter__()

    @property
    def cards(self):
        """
        The underlying physical cards that make up this Header; it can be
        looked at, but it should not be modified directly.
        """
        return _CardAccessor(self)


















    @property
    def _modified(self):
        """
        Whether or not the header has been modified; this is a property so that
        it can also check each card for modifications--cards may have been
        modified directly without the header containing it otherwise knowing.
        """
        modified_cards = any(c._modified for c in self._cards)
        if modified_cards:
            # If any cards were modified then by definition the header was
            # modified
            self.__dict__["_modified"] = True

        return self.__dict__["_modified"]

    @_modified.setter
    def _modified(self, val):
        self.__dict__["_modified"] = val

    @classmethod
    def fromstring(cls, data, sep=""):
        """
        Creates an HDU header from a byte string containing the entire header
        data.

        Parameters
        ----------
        data : str or bytes
           String or bytes containing the entire header.  In the case of bytes
           String or bytes containing the entire header.  In the case of bytes
           they will be decoded using latin-1 (only plain ASCII characters are
           allowed in FITS headers but latin-1 allows us to retain any invalid
           bytes that might appear in malformatted FITS files).

        sep : str, optional
            The string separating cards from each other, such as a newline.  By
            default there is no card separator (as is the case in a raw FITS
            file).  In general this is only used in cases where a header was
            printed as text (e.g. with newlines after each card) and you want
            to create a new `Header` from it by copy/pasting.

        Examples
        --------
        >>> from astropy.io.fits import Header
        >>> hdr = Header({'SIMPLE': True})
        >>> Header.fromstring(hdr.tostring()) == hdr
        True

        If you want to create a `Header` from printed text it's not necessary
        to have the exact binary structure as it would appear in a FITS file,
        with the full 80 byte card length.  Rather, each "card" can end in a
        newline and does not have to be padded out to a full card length as
        long as it "looks like" a FITS header:

        >>> hdr = Header.fromstring(\"\"\"\\
        ... SIMPLE  =                    T / conforms to FITS standard
        ... BITPIX  =                    8 / array data type
        ... NAXIS   =                    0 / number of array dimensions
        ... EXTEND  =                    T
        ... \"\"\", sep='\\n')
        >>> hdr['SIMPLE']
        True
        >>> hdr['BITPIX']
        8
        >>> len(hdr)
        4

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        cards = []

        # If the card separator contains characters that may validly appear in
        # a card, the only way to unambiguously distinguish between cards is to
        # require that they be Card.length long.  However, if the separator
        # contains non-valid characters (namely \n) the cards may be split
        # immediately at the separator
        require_full_cardlength = set(sep).issubset(VALID_HEADER_CHARS)

        if isinstance(data, bytes):
            # FITS supports only ASCII, but decode as latin1 and just take all
            # bytes for now; if it results in mojibake due to e.g. UTF-8
            # encoded data in a FITS header that's OK because it shouldn't be
            # there in the first place--accepting it here still gives us the
            # opportunity to display warnings later during validation
            CONTINUE = b"CONTINUE"
            END = b"END"
            end_card = END_CARD.encode("ascii")
            sep = sep.encode("latin1")
            empty = b""
        else:
            CONTINUE = "CONTINUE"
            END = "END"
            end_card = END_CARD
            empty = ""

        # Split the header into individual cards
        idx = 0
        image = []

        while idx < len(data):
            if require_full_cardlength:
                end_idx = idx + Card.length
            else:
                try:
                    end_idx = data.index(sep, idx)
                except ValueError:
                    end_idx = len(data)

            next_image = data[idx:end_idx]
            idx = end_idx + len(sep)

            if image:
                if next_image[:8] == CONTINUE:
                    image.append(next_image)
                    continue
                cards.append(Card.fromstring(empty.join(image)))

            if require_full_cardlength:
                if next_image == end_card:
                    image = []
                    break
            else:
                if next_image.split(sep)[0].rstrip() == END:
                    image = []
                    break

            image = [next_image]

        # Add the last image that was found before the end, if any
        if image:
            cards.append(Card.fromstring(empty.join(image)))

        return cls._fromcards(cards)

    @classmethod
    def fromfile(cls, fileobj, sep="", endcard=True, padding=True):
        """
        Similar to :meth:`Header.fromstring`, but reads the header string from
        a given file-like object or filename.

        Parameters
        ----------
        fileobj : str, file-like
            A filename or an open file-like object from which a FITS header is
            to be read.  For open file handles the file pointer must be at the
            beginning of the header.

        sep : str, optional
            The string separating cards from each other, such as a newline.  By
            default there is no card separator (as is the case in a raw FITS
            file).

        endcard : bool, optional
            If True (the default) the header must end with an END card in order
            to be considered valid.  If an END card is not found an
            `OSError` is raised.

        padding : bool, optional
            If True (the default) the header will be required to be padded out
            to a multiple of 2880, the FITS header block size.  Otherwise any
            padding, or lack thereof, is ignored.

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        close_file = False

        if isinstance(fileobj, path_like):
            # If sep is non-empty we are trying to read a header printed to a
            # text file, so open in text mode by default to support newline
            # handling; if a binary-mode file object is passed in, the user is
            # then on their own w.r.t. newline handling.
            #
            # Otherwise assume we are reading from an actual FITS file and open
            # in binary mode.
            fileobj = os.path.expanduser(fileobj)
            if sep:
                fileobj = open(fileobj, encoding="latin1")
            else:
                fileobj = open(fileobj, "rb")

            close_file = True

        try:
            is_binary = fileobj_is_binary(fileobj)

            def block_iter(nbytes):
                while True:
                    data = fileobj.read(nbytes)

                    if data:
                        yield data
                    else:
                        break

            return cls._from_blocks(block_iter, is_binary, sep, endcard, padding)[1]
        finally:
            if close_file:
                fileobj.close()

    @classmethod
    def _fromcards(cls, cards):
        header = cls()
        for idx, card in enumerate(cards):
            header._cards.append(card)
            keyword = Card.normalize_keyword(card.keyword)
            header._keyword_indices[keyword].append(idx)
            if card.field_specifier is not None:
                header._rvkc_indices[card.rawkeyword].append(idx)

        header._modified = False
        return header

    @classmethod
    def _from_blocks(cls, block_iter, is_binary, sep, endcard, padding):
        """
        The meat of `Header.fromfile`; in a separate method so that
        `Header.fromfile` itself is just responsible for wrapping file
        handling.  Also used by `_BaseHDU.fromstring`.

        ``block_iter`` should be a callable which, given a block size n
        (typically 2880 bytes as used by the FITS standard) returns an iterator
        of byte strings of that block size.

        ``is_binary`` specifies whether the returned blocks are bytes or text

        Returns both the entire header *string*, and the `Header` object
        returned by Header.fromstring on that string.
        """
        actual_block_size = _block_size(sep)
        clen = Card.length + len(sep)

        blocks = block_iter(actual_block_size)

        # Read the first header block.
        try:
            block = next(blocks)
        except StopIteration:
            raise EOFError()

        if not is_binary:
            # TODO: There needs to be error handling at *this* level for
            # non-ASCII characters; maybe at this stage decoding latin-1 might
            # be safer
            block = encode_ascii(block)

        read_blocks = []
        is_eof = False
        end_found = False

        # continue reading header blocks until END card or EOF is reached
        while True:
            # find the END card
            end_found, block = cls._find_end_card(block, clen)

            read_blocks.append(decode_ascii(block))

            if end_found:
                break

            try:
                block = next(blocks)
            except StopIteration:
                is_eof = True
                break

            if not block:
                is_eof = True
                break

            if not is_binary:
                block = encode_ascii(block)

        header_str = "".join(read_blocks)
        _check_padding(header_str, actual_block_size, is_eof, check_block_size=padding)

        if not end_found and is_eof and endcard:
            # TODO: Pass this error to validation framework as an ERROR,
            # rather than raising an exception
            raise OSError("Header missing END card.")

        return header_str, cls.fromstring(header_str, sep=sep)

    @classmethod
    def _find_end_card(cls, block, card_len):
        """
        Utility method to search a header block for the END card and handle
        invalid END cards.

        This method can also returned a modified copy of the input header block
        in case an invalid end card needs to be sanitized.
        """
        for mo in HEADER_END_RE.finditer(block):
            # Ensure the END card was found, and it started on the
            # boundary of a new card (see ticket #142)
            if mo.start() % card_len != 0:
                continue

            # This must be the last header block, otherwise the
            # file is malformatted
            if mo.group("invalid"):
                offset = mo.start()
                trailing = block[offset + 3 : offset + card_len - 3].rstrip()
                if trailing:
                    trailing = repr(trailing).lstrip("ub")
                    # TODO: Pass this warning up to the validation framework
                    warnings.warn(
                        f"Unexpected bytes trailing END keyword: {trailing}; these "
                        "bytes will be replaced with spaces on write.",
                        AstropyUserWarning,
                    )
                else:
                    # TODO: Pass this warning up to the validation framework
                    warnings.warn(
                        "Missing padding to end of the FITS block after the "
                        "END keyword; additional spaces will be appended to "
                        f"the file upon writing to pad out to {BLOCK_SIZE} bytes.",
                        AstropyUserWarning,
                    )

                # Sanitize out invalid END card now that the appropriate
                # warnings have been issued
                block = (
                    block[:offset]
                    + encode_ascii(END_CARD)
                    + block[offset + len(END_CARD) :]
                )

            return True, block

        return False, block

    def tostring(self, sep="", endcard=True, padding=True):
        r"""
        Returns a string representation of the header.

        By default this uses no separator between cards, adds the END card, and
        pads the string with spaces to the next multiple of 2880 bytes.  That
        is, it returns the header exactly as it would appear in a FITS file.

        Parameters
        ----------
        sep : str, optional
            The character or string with which to separate cards.  By default
            there is no separator, but one could use ``'\\n'``, for example, to
            separate each card with a new line

        endcard : bool, optional
            If True (default) adds the END card to the end of the header
            string

        padding : bool, optional
            If True (default) pads the string with spaces out to the next
            multiple of 2880 characters

        Returns
        -------
        str
            A string representing a FITS header.
        """
        lines = []
        for card in self._cards:
            s = str(card)
            # Cards with CONTINUE cards may be longer than 80 chars; so break
            # them into multiple lines
            while s:
                lines.append(s[: Card.length])
                s = s[Card.length :]

        s = sep.join(lines)
        if endcard:
            s += sep + _pad("END")
        if padding:
            s += " " * _pad_length(len(s))
        return s

    def tofile(self, fileobj, sep="", endcard=True, padding=True, overwrite=False):
        r"""
        Writes the header to file or file-like object.

        By default this writes the header exactly as it would be written to a
        FITS file, with the END card included and padding to the next multiple
        of 2880 bytes.  However, aspects of this may be controlled.

        Parameters
        ----------
        fileobj : path-like or file-like, optional
            Either the pathname of a file, or an open file handle or file-like
            object.

        sep : str, optional
            The character or string with which to separate cards.  By default
            there is no separator, but one could use ``'\\n'``, for example, to
            separate each card with a new line

        endcard : bool, optional
            If `True` (default) adds the END card to the end of the header
            string

        padding : bool, optional
            If `True` (default) pads the string with spaces out to the next
            multiple of 2880 characters

        overwrite : bool, optional
            If ``True``, overwrite the output file if it exists. Raises an
            ``OSError`` if ``False`` and the output file exists. Default is
            ``False``.
        """
        close_file = fileobj_closed(fileobj)

        if not isinstance(fileobj, _File):
            fileobj = _File(fileobj, mode="ostream", overwrite=overwrite)

        try:
            blocks = self.tostring(sep=sep, endcard=endcard, padding=padding)
            actual_block_size = _block_size(sep)
            if padding and len(blocks) % actual_block_size != 0:
                raise OSError(
                    f"Header size ({len(blocks) - actual_block_size + BLOCK_SIZE}) "
                    f"is not a multiple of block size ({BLOCK_SIZE})."
                )

            fileobj.flush()
            fileobj.write(blocks.encode("ascii"))
            fileobj.flush()
        finally:
            if close_file:
                fileobj.close()

    @classmethod
    def fromtextfile(cls, fileobj, endcard=False):
        """
        Read a header from a simple text file or file-like object.

        Equivalent to::

            >>> Header.fromfile(fileobj, sep='\\n', endcard=False,
            ...                 padding=False)

        See Also
        --------
        fromfile
        """
        return cls.fromfile(fileobj, sep="\n", endcard=endcard, padding=False)

    def totextfile(self, fileobj, endcard=False, overwrite=False):
        """
        Write the header as text to a file or a file-like object.

        Equivalent to::

            >>> Header.tofile(fileobj, sep='\\n', endcard=False,
            ...               padding=False, overwrite=overwrite)

        See Also
        --------
        tofile
        """
        self.tofile(
            fileobj, sep="\n", endcard=endcard, padding=False, overwrite=overwrite
        )

    def clear(self):
        """
        Remove all cards from the header.
        """
        self._cards = []
        self._keyword_indices = collections.defaultdict(list)
        self._rvkc_indices = collections.defaultdict(list)

    def copy(self, strip=False):
        """
        Make a copy of the :class:`Header`.

        .. versionchanged:: 1.3
            `copy.copy` and `copy.deepcopy` on a `Header` will call this
            method.

        Parameters
        ----------
        strip : bool, optional
            If `True`, strip any headers that are specific to one of the
            standard HDU types, so that this header can be used in a different
            HDU.
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "sed -n '820,1450p' astropy/io/fits/header.py
sed -n '1450,1995p' astropy/io/fits/header.py"
```

退出码：`0`

输出：
```

        Returns
        -------
        `Header`
            A new :class:`Header` instance.
        """
        tmp = self.__class__(copy.copy(card) for card in self._cards)
        if strip:
            tmp.strip()
        return tmp

    def __copy__(self):
        return self.copy()

    def __deepcopy__(self, *args, **kwargs):
        return self.copy()

    @classmethod
    def fromkeys(cls, iterable, value=None):
        """
        Similar to :meth:`dict.fromkeys`--creates a new `Header` from an
        iterable of keywords and an optional default value.

        This method is not likely to be particularly useful for creating real
        world FITS headers, but it is useful for testing.

        Parameters
        ----------
        iterable
            Any iterable that returns strings representing FITS keywords.

        value : optional
            A default value to assign to each keyword; must be a valid type for
            FITS keywords.

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        d = cls()
        if not isinstance(value, tuple):
            value = (value,)
        for key in iterable:
            d.append((key,) + value)
        return d


























    def set(self, keyword, value=None, comment=None, before=None, after=None):
        """
        Set the value and/or comment and/or position of a specified keyword.

        If the keyword does not already exist in the header, a new keyword is
        created in the specified position, or appended to the end of the header
        if no position is specified.

        This method is similar to :meth:`Header.update` prior to Astropy v0.1.

        .. note::
            It should be noted that ``header.set(keyword, value)`` and
            ``header.set(keyword, value, comment)`` are equivalent to
            ``header[keyword] = value`` and
            ``header[keyword] = (value, comment)`` respectively.

        Parameters
        ----------
        keyword : str
            A header keyword

        value : str, optional
            The value to set for the given keyword; if None the existing value
            is kept, but '' may be used to set a blank value

        comment : str, optional
            The comment to set for the given keyword; if None the existing
            comment is kept, but ``''`` may be used to set a blank comment

        before : str, int, optional
            Name of the keyword, or index of the `Card` before which this card
            should be located in the header.  The argument ``before`` takes
            precedence over ``after`` if both specified.

        after : str, int, optional
            Name of the keyword, or index of the `Card` after which this card
            should be located in the header.

        """
        # Create a temporary card that looks like the one being set; if the
        # temporary card turns out to be a RVKC this will make it easier to
        # deal with the idiosyncrasies thereof
        # Don't try to make a temporary card though if they keyword looks like
        # it might be a HIERARCH card or is otherwise invalid--this step is
        # only for validating RVKCs.
        if (
            len(keyword) <= KEYWORD_LENGTH
            and Card._keywd_FSC_RE.match(keyword)
            and keyword not in self._keyword_indices
        ):
            new_card = Card(keyword, value, comment)
            new_keyword = new_card.keyword
        else:
            new_keyword = keyword

        if new_keyword not in _commentary_keywords and new_keyword in self:
            if comment is None:
                comment = self.comments[keyword]
            if value is None:
                value = self[keyword]

            self[keyword] = (value, comment)

            if before is not None or after is not None:
                card = self._cards[self._cardindex(keyword)]
                self._relativeinsert(card, before=before, after=after, replace=True)
        elif before is not None or after is not None:
            self._relativeinsert((keyword, value, comment), before=before, after=after)
        else:
            self[keyword] = (value, comment)

    def items(self):
        """Like :meth:`dict.items`."""
        for card in self._cards:
            yield card.keyword, None if card.value == UNDEFINED else card.value

    def keys(self):
        """
        Like :meth:`dict.keys`--iterating directly over the `Header`
        instance has the same behavior.
        """
        for card in self._cards:
            yield card.keyword

    def values(self):
        """Like :meth:`dict.values`."""
        for card in self._cards:
            yield None if card.value == UNDEFINED else card.value

    def pop(self, *args):
        """
        Works like :meth:`list.pop` if no arguments or an index argument are
        supplied; otherwise works like :meth:`dict.pop`.
        """
        if len(args) > 2:
            raise TypeError(f"Header.pop expected at most 2 arguments, got {len(args)}")

        if len(args) == 0:
            key = -1
        else:
            key = args[0]

        try:
            value = self[key]
        except (KeyError, IndexError):
            if len(args) == 2:
                return args[1]
            raise

        del self[key]
        return value

    def popitem(self):
        """Similar to :meth:`dict.popitem`."""
        try:
            k, v = next(self.items())
        except StopIteration:
            raise KeyError("Header is empty")
        del self[k]
        return k, v

    def setdefault(self, key, default=None):
        """Similar to :meth:`dict.setdefault`."""
        try:
            return self[key]
        except (KeyError, IndexError):
            self[key] = default
        return default

    def update(self, *args, **kwargs):
        """
        Update the Header with new keyword values, updating the values of
        existing keywords and appending new keywords otherwise; similar to
        `dict.update`.

        `update` accepts either a dict-like object or an iterable.  In the
        former case the keys must be header keywords and the values may be
        either scalar values or (value, comment) tuples.  In the case of an
        iterable the items must be (keyword, value) tuples or (keyword, value,
        comment) tuples.

        Arbitrary arguments are also accepted, in which case the update() is
        called again with the kwargs dict as its only argument.  That is,

        ::

            >>> header.update(NAXIS1=100, NAXIS2=100)

        is equivalent to::

            header.update({'NAXIS1': 100, 'NAXIS2': 100})

        """
        if args:
            other = args[0]
        else:
            other = None

        def update_from_dict(k, v):
            if not isinstance(v, tuple):
                card = Card(k, v)
            elif 0 < len(v) <= 2:
                card = Card(*((k,) + v))
            else:
                raise ValueError(
                    f"Header update value for key {k!r} is invalid; the "
                    "value must be either a scalar, a 1-tuple "
                    "containing the scalar value, or a 2-tuple "
                    "containing the value and a comment string."
                )
            self._update(card)

        if other is None:
            pass
        elif isinstance(other, Header):
            for card in other.cards:
                self._update(card)
        elif hasattr(other, "items"):
            for k, v in other.items():
                update_from_dict(k, v)
        elif hasattr(other, "keys"):
            for k in other.keys():
                update_from_dict(k, other[k])
        else:
            for idx, card in enumerate(other):
                if isinstance(card, Card):
                    self._update(card)
                elif isinstance(card, tuple) and (1 < len(card) <= 3):
                    self._update(Card(*card))
                else:
                    raise ValueError(
                        f"Header update sequence item #{idx} is invalid; "
                        "the item must either be a 2-tuple containing "
                        "a keyword and value, or a 3-tuple containing "
                        "a keyword, value, and comment string."
                    )
        if kwargs:
            self.update(kwargs)

    def append(self, card=None, useblanks=True, bottom=False, end=False):
        """
        Appends a new keyword+value card to the end of the Header, similar
        to `list.append`.

        By default if the last cards in the Header have commentary keywords,
        this will append the new keyword before the commentary (unless the new
        keyword is also commentary).

        Also differs from `list.append` in that it can be called with no
        arguments: In this case a blank card is appended to the end of the
        Header.  In the case all the keyword arguments are ignored.

        Parameters
        ----------
        card : str, tuple
            A keyword or a (keyword, value, [comment]) tuple representing a
            single header card; the comment is optional in which case a
            2-tuple may be used

        useblanks : bool, optional
            If there are blank cards at the end of the Header, replace the
            first blank card so that the total number of cards in the Header
            does not increase.  Otherwise preserve the number of blank cards.

        bottom : bool, optional
            If True, instead of appending after the last non-commentary card,
            append after the last non-blank card.

        end : bool, optional
            If True, ignore the useblanks and bottom options, and append at the
            very end of the Header.

        """
        if isinstance(card, str):
            card = Card(card)
        elif isinstance(card, tuple):
            card = Card(*card)
        elif card is None:
            card = Card()
        elif not isinstance(card, Card):
            raise ValueError(
                "The value appended to a Header must be either a keyword or "
                f"(keyword, value, [comment]) tuple; got: {card!r}"
            )

        if not end and card.is_blank:
            # Blank cards should always just be appended to the end
            end = True

        if end:
            self._cards.append(card)
            idx = len(self._cards) - 1
        else:
            idx = len(self._cards) - 1
            while idx >= 0 and self._cards[idx].is_blank:
                idx -= 1

            if not bottom and card.keyword not in _commentary_keywords:
                while idx >= 0 and self._cards[idx].keyword in _commentary_keywords:
                    idx -= 1

            idx += 1
            self._cards.insert(idx, card)
            self._updateindices(idx)

        keyword = Card.normalize_keyword(card.keyword)
        self._keyword_indices[keyword].append(idx)
        if card.field_specifier is not None:
            self._rvkc_indices[card.rawkeyword].append(idx)

        if not end:
            # If the appended card was a commentary card, and it was appended
            # before existing cards with the same keyword, the indices for
            # cards with that keyword may have changed
            if not bottom and card.keyword in _commentary_keywords:
                self._keyword_indices[keyword].sort()

            # Finally, if useblanks, delete a blank cards from the end
            if useblanks and self._countblanks():
                # Don't do this unless there is at least one blanks at the end
                # of the header; we need to convert the card to its string
                # image to see how long it is.  In the vast majority of cases
                # this will just be 80 (Card.length) but it may be longer for
                # CONTINUE cards
                self._useblanks(len(str(card)) // Card.length)

        self._modified = True

    def extend(
        self,
        cards,
        strip=True,
        unique=False,
        update=False,
        update_first=False,
        useblanks=True,
        bottom=False,
        end=False,
    ):
        """
        Appends multiple keyword+value cards to the end of the header, similar
        to `list.extend`.

        Parameters
        ----------
        cards : iterable
            An iterable of (keyword, value, [comment]) tuples; see
            `Header.append`.

        strip : bool, optional
            Remove any keywords that have meaning only to specific types of
            HDUs, so that only more general keywords are added from extension
            Header or Card list (default: `True`).

        unique : bool, optional
            If `True`, ensures that no duplicate keywords are appended;
            keywords already in this header are simply discarded.  The
            exception is commentary keywords (COMMENT, HISTORY, etc.): they are
            only treated as duplicates if their values match.

        update : bool, optional
            If `True`, update the current header with the values and comments
            from duplicate keywords in the input header.  This supersedes the
            ``unique`` argument.  Commentary keywords are treated the same as
            if ``unique=True``.

        update_first : bool, optional
            If the first keyword in the header is 'SIMPLE', and the first
            keyword in the input header is 'XTENSION', the 'SIMPLE' keyword is
            replaced by the 'XTENSION' keyword.  Likewise if the first keyword
            in the header is 'XTENSION' and the first keyword in the input
            header is 'SIMPLE', the 'XTENSION' keyword is replaced by the
            'SIMPLE' keyword.  This behavior is otherwise dumb as to whether or
            not the resulting header is a valid primary or extension header.
            This is mostly provided to support backwards compatibility with the
            old ``Header.fromTxtFile`` method, and only applies if
            ``update=True``.

        useblanks, bottom, end : bool, optional
            These arguments are passed to :meth:`Header.append` while appending
            new cards to the header.
        """
        temp = self.__class__(cards)
        if strip:
            temp.strip()

        if len(self):
            first = self._cards[0].keyword
        else:
            first = None

        # We don't immediately modify the header, because first we need to sift
        # out any duplicates in the new header prior to adding them to the
        # existing header, but while *allowing* duplicates from the header
        # being extended from (see ticket #156)
        extend_cards = []

        for idx, card in enumerate(temp.cards):
            keyword = card.keyword
            if keyword not in _commentary_keywords:
                if unique and not update and keyword in self:
                    continue
                elif update:
                    if idx == 0 and update_first:
                        # Dumbly update the first keyword to either SIMPLE or
                        # XTENSION as the case may be, as was in the case in
                        # Header.fromTxtFile
                        if (keyword == "SIMPLE" and first == "XTENSION") or (
                            keyword == "XTENSION" and first == "SIMPLE"
                        ):
                            del self[0]
                            self.insert(0, card)
                        else:
                            self[keyword] = (card.value, card.comment)
                    elif keyword in self:
                        self[keyword] = (card.value, card.comment)
                    else:
                        extend_cards.append(card)
                else:
                    extend_cards.append(card)
            else:
                if (unique or update) and keyword in self:
                    if card.is_blank:
                        extend_cards.append(card)
                        continue

                    for value in self[keyword]:
                        if value == card.value:
                            break
                    else:
                        extend_cards.append(card)
                else:
                    extend_cards.append(card)

        for card in extend_cards:
            self.append(card, useblanks=useblanks, bottom=bottom, end=end)

    def count(self, keyword):
        """
        Returns the count of the given keyword in the header, similar to
        `list.count` if the Header object is treated as a list of keywords.

        Parameters
        ----------
        keyword : str
            The keyword to count instances of in the header

        """
        keyword = Card.normalize_keyword(keyword)

        # We have to look before we leap, since otherwise _keyword_indices,
        # being a defaultdict, will create an entry for the nonexistent keyword
        if keyword not in self._keyword_indices:
            raise KeyError(f"Keyword {keyword!r} not found.")

        return len(self._keyword_indices[keyword])

    def index(self, keyword, start=None, stop=None):
        """
        Returns the index if the first instance of the given keyword in the
        header, similar to `list.index` if the Header object is treated as a
        list of keywords.

        Parameters
        ----------
        keyword : str
            The keyword to look up in the list of all keywords in the header

        start : int, optional
            The lower bound for the index

        stop : int, optional
            The upper bound for the index

        """
        if start is None:
            start = 0

        if stop is None:
            stop = len(self._cards)

        if stop < start:
            step = -1
        else:
            step = 1

        norm_keyword = Card.normalize_keyword(keyword)

        for idx in range(start, stop, step):
            if self._cards[idx].keyword.upper() == norm_keyword:
                return idx
        raise ValueError(f"The keyword {keyword!r} is not in the  header.")









































































































































    def rename_keyword(self, oldkeyword, newkeyword, force=False):
        """
        Rename a card's keyword in the header.

        Parameters
        ----------
        oldkeyword : str or int
            Old keyword or card index

        newkeyword : str
            New keyword

        force : bool, optional
            When `True`, if the new keyword already exists in the header, force
            the creation of a duplicate keyword. Otherwise a
            `ValueError` is raised.
        """
        old = Card.normalize_keyword(oldkeyword)
        new = Card.normalize_keyword(newkeyword)

        if new == "CONTINUE":
            raise ValueError("Can not rename to CONTINUE")

        if new in _commentary_keywords or old in _commentary_keywords:
            if not (new in _commentary_keywords and old in _commentary_keywords):
                raise ValueError(
                    "Regular and commentary keys can not be renamed to each other."
                )
        elif not force and new in self:
            raise ValueError(f"Intended keyword {new} already exists in header.")

        idx = self.index(old)
        card = self._cards[idx]
        del self[idx]
        self.insert(idx, (new, card.value, card.comment))

    def add_history(self, value, before=None, after=None):
        """
        Add a ``HISTORY`` card.

        Parameters
        ----------
        value : str
            History text to be added.

        before : str or int, optional
            Same as in `Header.update`

        after : str or int, optional
            Same as in `Header.update`
        """
        self._add_commentary("HISTORY", value, before=before, after=after)

    def add_comment(self, value, before=None, after=None):
        """
        Add a ``COMMENT`` card.

        Parameters
        ----------
        value : str
            Text to be added.

        before : str or int, optional
            Same as in `Header.update`

        after : str or int, optional
            Same as in `Header.update`
        """
        self._add_commentary("COMMENT", value, before=before, after=after)

    def add_blank(self, value="", before=None, after=None):
        """
        Add a blank card.

        Parameters
        ----------
        value : str, optional
            Text to be added.

        before : str or int, optional
            Same as in `Header.update`

        after : str or int, optional
            Same as in `Header.update`
        """
        self._add_commentary("", value, before=before, after=after)

    def strip(self):
        """
        Strip cards specific to a certain kind of header.

        Strip cards like ``SIMPLE``, ``BITPIX``, etc. so the rest of
        the header can be used to reconstruct another kind of header.
        """
        # TODO: Previously this only deleted some cards specific to an HDU if
        # _hdutype matched that type.  But it seemed simple enough to just
        # delete all desired cards anyways, and just ignore the KeyErrors if
        # they don't exist.
        # However, it might be desirable to make this extendable somehow--have
        # a way for HDU classes to specify some headers that are specific only
        # to that type, and should be removed otherwise.

        naxis = self.get("NAXIS", 0)
        tfields = self.get("TFIELDS", 0)

        for idx in range(naxis):
            self.remove("NAXIS" + str(idx + 1), ignore_missing=True)

        for name in (
            "TFORM",
            "TSCAL",
            "TZERO",
            "TNULL",
            "TTYPE",
            "TUNIT",
            "TDISP",
            "TDIM",
            "THEAP",
            "TBCOL",
        ):
            for idx in range(tfields):
                self.remove(name + str(idx + 1), ignore_missing=True)

        for name in (
            "SIMPLE",
            "XTENSION",
            "BITPIX",
            "NAXIS",
            "EXTEND",
            "PCOUNT",
            "GCOUNT",
            "GROUPS",
            "BSCALE",
            "BZERO",
            "TFIELDS",
        ):
            self.remove(name, ignore_missing=True)

    @property
    def data_size(self):
        """
        Return the size (in bytes) of the data portion following the `Header`.
        """
        return _hdr_data_size(self)

    @property
    def data_size_padded(self):
        """
        Return the size (in bytes) of the data portion following the `Header`
        including padding.
        """
        size = self.data_size
        return size + _pad_length(size)































































































    def _keyword_from_index(self, idx):
        """
        Given an integer index, return the (keyword, repeat) tuple that index
        refers to.  For most keywords the repeat will always be zero, but it
        may be greater than zero for keywords that are duplicated (especially
        commentary keywords).

        In a sense this is the inverse of self.index, except that it also
        supports duplicates.
        """
        if idx < 0:
            idx += len(self._cards)

        keyword = self._cards[idx].keyword
        keyword = Card.normalize_keyword(keyword)
        repeat = self._keyword_indices[keyword].index(idx)
        return keyword, repeat




























































    def _updateindices(self, idx, increment=True):
        """
        For all cards with index above idx, increment or decrement its index
        value in the keyword_indices dict.
        """
        if idx > len(self._cards):
            # Save us some effort
            return

        increment = 1 if increment else -1

        for index_sets in (self._keyword_indices, self._rvkc_indices):
            for indices in index_sets.values():
                for jdx, keyword_index in enumerate(indices):
                    if keyword_index >= idx:
                        indices[jdx] += increment

    def _countblanks(self):
        """Returns the number of blank cards at the end of the Header."""
        for idx in range(1, len(self._cards)):
            if not self._cards[-idx].is_blank:
                return idx - 1
        return 0














    def _wildcardmatch(self, pattern):
        """
        Returns a list of indices of the cards matching the given wildcard
        pattern.

         * '*' matches 0 or more characters
         * '?' matches a single character
         * '...' matches 0 or more of any non-whitespace character
        """
        pattern = pattern.replace("*", r".*").replace("?", r".")
        pattern = pattern.replace("...", r"\S*") + "$"
        match_pattern = re.compile(pattern, re.IGNORECASE).match
        return [i for i, card in enumerate(self._cards) if match_pattern(card.keyword)]





















    def _splitcommentary(self, keyword, value):
        """
        Given a commentary keyword and value, returns a list of the one or more
        cards needed to represent the full value.  This is primarily used to
        create the multiple commentary cards needed to represent a long value
        that won't fit into a single commentary card.
        """
        # The maximum value in each card can be the maximum card length minus
        # the maximum key length (which can include spaces if they key length
        # less than 8
        maxlen = Card.length - KEYWORD_LENGTH
        valuestr = str(value)

        if len(valuestr) <= maxlen:
            # The value can fit in a single card
            cards = [Card(keyword, value)]
        else:
            # The value must be split across multiple consecutive commentary
            # cards
            idx = 0
            cards = []
            while idx < len(valuestr):
                cards.append(Card(keyword, valuestr[idx : idx + maxlen]))
                idx += maxlen
        return cards

    def _add_commentary(self, key, value, before=None, after=None):
        """
        Add a commentary card.

        If ``before`` and ``after`` are `None`, add to the last occurrence
        of cards of the same name (except blank card).  If there is no
        card (or blank card), append at the end.
        """
        if before is not None or after is not None:
            self._relativeinsert((key, value), before=before, after=after)
        else:
            self[key] = value


collections.abc.MutableSequence.register(Header)
collections.abc.MutableMapping.register(Header)


class _DelayedHeader:
    """
    Descriptor used to create the Header object from the header string that
    was stored in HDU._header_str when parsing the file.
    """
















    def __set__(self, obj, val):
        obj.__dict__["_header"] = val

    def __delete__(self, obj):
        del obj.__dict__["_header"]


class _BasicHeaderCards:
    """
    This class allows to access cards with the _BasicHeader.cards attribute.

    This is needed because during the HDU class detection, some HDUs uses
    the .cards interface.  Cards cannot be modified here as the _BasicHeader
    object will be deleted once the HDU object is created.

    """

    def __init__(self, header):
        self.header = header

    def __getitem__(self, key):
        # .cards is a list of cards, so key here is an integer.
        # get the keyword name from its index.
        key = self.header._keys[key]
        # then we get the card from the _BasicHeader._cards list, or parse it
        # if needed.
        try:
            return self.header._cards[key]
        except KeyError:
            cardstr = self.header._raw_cards[key]
            card = Card.fromstring(cardstr)
            self.header._cards[key] = card
            return card


class _BasicHeader(collections.abc.Mapping):
    """This class provides a fast header parsing, without all the additional
    features of the Header class. Here only standard keywords are parsed, no
    support for CONTINUE, HIERARCH, COMMENT, HISTORY, or rvkc.

    The raw card images are stored and parsed only if needed. The idea is that
    to create the HDU objects, only a small subset of standard cards is needed.
    Once a card is parsed, which is deferred to the Card class, the Card object
    is kept in a cache. This is useful because a small subset of cards is used
    a lot in the HDU creation process (NAXIS, XTENSION, ...).

    """

    def __init__(self, cards):
        # dict of (keywords, card images)
        self._raw_cards = cards
        self._keys = list(cards.keys())
        # dict of (keyword, Card object) storing the parsed cards
        self._cards = {}
        # the _BasicHeaderCards object allows to access Card objects from
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/header.py | sed -n '100,300p'
nl -ba astropy/io/fits/header.py | sed -n '820,1040p'
nl -ba astropy/io/fits/header.py | sed -n '1370,1900p'"
```

退出码：`0`

输出：
```
   100	        Parameters
   101	        ----------
   102	        cards : list of `Card`, optional
   103	            The cards to initialize the header with. Also allowed are other
   104	            `Header` (or `dict`-like) objects.
   105	
   106	            .. versionchanged:: 1.2
   107	                Allowed ``cards`` to be a `dict`-like object.
   108	
   109	        copy : bool, optional
   110	
   111	            If ``True`` copies the ``cards`` if they were another `Header`
   112	            instance.
   113	            Default is ``False``.
   114	
   115	            .. versionadded:: 1.3
   116	        """
   117	        self.clear()
   118	
   119	        if isinstance(cards, Header):
   120	            if copy:
   121	                cards = cards.copy()
   122	            cards = cards.cards
   123	        elif isinstance(cards, dict):
   124	            cards = cards.items()
   125	
   126	        for card in cards:
   127	            self.append(card, end=True)
   128	
   129	        self._modified = False
   130	
   131	    def __len__(self):
   132	        return len(self._cards)
   133	
   134	    def __iter__(self):
   135	        for card in self._cards:
   136	            yield card.keyword
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	    def __getitem__(self, key):
   152	        if isinstance(key, slice):
   153	            return self.__class__([copy.copy(c) for c in self._cards[key]])
   154	        elif self._haswildcard(key):
   155	            return self.__class__(
   156	                [copy.copy(self._cards[idx]) for idx in self._wildcardmatch(key)]
   157	            )
   158	        elif isinstance(key, str):
   159	            key = key.strip()
   160	            if key.upper() in _commentary_keywords:
   161	                key = key.upper()
   162	                # Special case for commentary cards
   163	                return _HeaderCommentaryCards(self, key)
   164	
   165	        if isinstance(key, tuple):
   166	            keyword = key[0]
   167	        else:
   168	            keyword = key
   169	
   170	        card = self._cards[self._cardindex(key)]
   171	
   172	        if card.field_specifier is not None and keyword == card.rawkeyword:
   173	            # This is RVKC; if only the top-level keyword was specified return
   174	            # the raw value, not the parsed out float value
   175	            return card.rawvalue
   176	
   177	        value = card.value
   178	        if value == UNDEFINED:
   179	            return None
   180	        return value
   181	
   182	    def __setitem__(self, key, value):
   183	        if self._set_slice(key, value, self):
   184	            return
   185	
   186	        if isinstance(value, tuple):
   187	            if len(value) > 2:
   188	                raise ValueError(
   189	                    "A Header item may be set with either a scalar value, "
   190	                    "a 1-tuple containing a scalar value, or a 2-tuple "
   191	                    "containing a scalar value and comment string."
   192	                )
   193	            if len(value) == 1:
   194	                value, comment = value[0], None
   195	                if value is None:
   196	                    value = UNDEFINED
   197	            elif len(value) == 2:
   198	                value, comment = value
   199	                if value is None:
   200	                    value = UNDEFINED
   201	                if comment is None:
   202	                    comment = ""
   203	        else:
   204	            comment = None
   205	
   206	        card = None
   207	        if isinstance(key, numbers.Integral):
   208	            card = self._cards[key]
   209	        elif isinstance(key, tuple):
   210	            card = self._cards[self._cardindex(key)]
   211	        if value is None:
   212	            value = UNDEFINED
   213	        if card:
   214	            card.value = value
   215	            if comment is not None:
   216	                card.comment = comment
   217	            if card._modified:
   218	                self._modified = True
   219	        else:
   220	            # If we get an IndexError that should be raised; we don't allow
   221	            # assignment to non-existing indices
   222	            self._update((key, value, comment))
   223	
   224	    def __delitem__(self, key):
   225	        if isinstance(key, slice) or self._haswildcard(key):
   226	            # This is very inefficient but it's not a commonly used feature.
   227	            # If someone out there complains that they make heavy use of slice
   228	            # deletions and it's too slow, well, we can worry about it then
   229	            # [the solution is not too complicated--it would be wait 'til all
   230	            # the cards are deleted before updating _keyword_indices rather
   231	            # than updating it once for each card that gets deleted]
   232	            if isinstance(key, slice):
   233	                indices = range(*key.indices(len(self)))
   234	                # If the slice step is backwards we want to reverse it, because
   235	                # it will be reversed in a few lines...
   236	                if key.step and key.step < 0:
   237	                    indices = reversed(indices)
   238	            else:
   239	                indices = self._wildcardmatch(key)
   240	            for idx in reversed(indices):
   241	                del self[idx]
   242	            return
   243	        elif isinstance(key, str):
   244	            # delete ALL cards with the same keyword name
   245	            key = Card.normalize_keyword(key)
   246	            indices = self._keyword_indices
   247	            if key not in self._keyword_indices:
   248	                indices = self._rvkc_indices
   249	
   250	            if key not in indices:
   251	                # if keyword is not present raise KeyError.
   252	                # To delete keyword without caring if they were present,
   253	                # Header.remove(Keyword) can be used with optional argument ignore_missing as True
   254	                raise KeyError(f"Keyword '{key}' not found.")
   255	
   256	            for idx in reversed(indices[key]):
   257	                # Have to copy the indices list since it will be modified below
   258	                del self[idx]
   259	            return
   260	
   261	        idx = self._cardindex(key)
   262	        card = self._cards[idx]
   263	        keyword = card.keyword
   264	        del self._cards[idx]
   265	        keyword = Card.normalize_keyword(keyword)
   266	        indices = self._keyword_indices[keyword]
   267	        indices.remove(idx)
   268	        if not indices:
   269	            del self._keyword_indices[keyword]
   270	
   271	        # Also update RVKC indices if necessary :/
   272	        if card.field_specifier is not None:
   273	            indices = self._rvkc_indices[card.rawkeyword]
   274	            indices.remove(idx)
   275	            if not indices:
   276	                del self._rvkc_indices[card.rawkeyword]
   277	
   278	        # We also need to update all other indices
   279	        self._updateindices(idx, increment=False)
   280	        self._modified = True
   281	
   282	    def __repr__(self):
   283	        return self.tostring(sep="\n", endcard=False, padding=False)
   284	
   285	    def __str__(self):
   286	        return self.tostring()
   287	
   288	    def __eq__(self, other):
   289	        """
   290	        Two Headers are equal only if they have the exact same string
   291	        representation.
   292	        """
   293	        return str(self) == str(other)
   294	
   295	    def __add__(self, other):
   296	        temp = self.copy(strip=False)
   297	        temp.extend(other)
   298	        return temp
   299	
   300	    def __iadd__(self, other):
   820	
   821	        Returns
   822	        -------
   823	        `Header`
   824	            A new :class:`Header` instance.
   825	        """
   826	        tmp = self.__class__(copy.copy(card) for card in self._cards)
   827	        if strip:
   828	            tmp.strip()
   829	        return tmp
   830	
   831	    def __copy__(self):
   832	        return self.copy()
   833	
   834	    def __deepcopy__(self, *args, **kwargs):
   835	        return self.copy()
   836	
   837	    @classmethod
   838	    def fromkeys(cls, iterable, value=None):
   839	        """
   840	        Similar to :meth:`dict.fromkeys`--creates a new `Header` from an
   841	        iterable of keywords and an optional default value.
   842	
   843	        This method is not likely to be particularly useful for creating real
   844	        world FITS headers, but it is useful for testing.
   845	
   846	        Parameters
   847	        ----------
   848	        iterable
   849	            Any iterable that returns strings representing FITS keywords.
   850	
   851	        value : optional
   852	            A default value to assign to each keyword; must be a valid type for
   853	            FITS keywords.
   854	
   855	        Returns
   856	        -------
   857	        `Header`
   858	            A new `Header` instance.
   859	        """
   860	        d = cls()
   861	        if not isinstance(value, tuple):
   862	            value = (value,)
   863	        for key in iterable:
   864	            d.append((key,) + value)
   865	        return d
   866	
   867	
   868	
   869	
   870	
   871	
   872	
   873	
   874	
   875	
   876	
   877	
   878	
   879	
   880	
   881	
   882	
   883	
   884	
   885	
   886	
   887	
   888	
   889	
   890	
   891	
   892	    def set(self, keyword, value=None, comment=None, before=None, after=None):
   893	        """
   894	        Set the value and/or comment and/or position of a specified keyword.
   895	
   896	        If the keyword does not already exist in the header, a new keyword is
   897	        created in the specified position, or appended to the end of the header
   898	        if no position is specified.
   899	
   900	        This method is similar to :meth:`Header.update` prior to Astropy v0.1.
   901	
   902	        .. note::
   903	            It should be noted that ``header.set(keyword, value)`` and
   904	            ``header.set(keyword, value, comment)`` are equivalent to
   905	            ``header[keyword] = value`` and
   906	            ``header[keyword] = (value, comment)`` respectively.
   907	
   908	        Parameters
   909	        ----------
   910	        keyword : str
   911	            A header keyword
   912	
   913	        value : str, optional
   914	            The value to set for the given keyword; if None the existing value
   915	            is kept, but '' may be used to set a blank value
   916	
   917	        comment : str, optional
   918	            The comment to set for the given keyword; if None the existing
   919	            comment is kept, but ``''`` may be used to set a blank comment
   920	
   921	        before : str, int, optional
   922	            Name of the keyword, or index of the `Card` before which this card
   923	            should be located in the header.  The argument ``before`` takes
   924	            precedence over ``after`` if both specified.
   925	
   926	        after : str, int, optional
   927	            Name of the keyword, or index of the `Card` after which this card
   928	            should be located in the header.
   929	
   930	        """
   931	        # Create a temporary card that looks like the one being set; if the
   932	        # temporary card turns out to be a RVKC this will make it easier to
   933	        # deal with the idiosyncrasies thereof
   934	        # Don't try to make a temporary card though if they keyword looks like
   935	        # it might be a HIERARCH card or is otherwise invalid--this step is
   936	        # only for validating RVKCs.
   937	        if (
   938	            len(keyword) <= KEYWORD_LENGTH
   939	            and Card._keywd_FSC_RE.match(keyword)
   940	            and keyword not in self._keyword_indices
   941	        ):
   942	            new_card = Card(keyword, value, comment)
   943	            new_keyword = new_card.keyword
   944	        else:
   945	            new_keyword = keyword
   946	
   947	        if new_keyword not in _commentary_keywords and new_keyword in self:
   948	            if comment is None:
   949	                comment = self.comments[keyword]
   950	            if value is None:
   951	                value = self[keyword]
   952	
   953	            self[keyword] = (value, comment)
   954	
   955	            if before is not None or after is not None:
   956	                card = self._cards[self._cardindex(keyword)]
   957	                self._relativeinsert(card, before=before, after=after, replace=True)
   958	        elif before is not None or after is not None:
   959	            self._relativeinsert((keyword, value, comment), before=before, after=after)
   960	        else:
   961	            self[keyword] = (value, comment)
   962	
   963	    def items(self):
   964	        """Like :meth:`dict.items`."""
   965	        for card in self._cards:
   966	            yield card.keyword, None if card.value == UNDEFINED else card.value
   967	
   968	    def keys(self):
   969	        """
   970	        Like :meth:`dict.keys`--iterating directly over the `Header`
   971	        instance has the same behavior.
   972	        """
   973	        for card in self._cards:
   974	            yield card.keyword
   975	
   976	    def values(self):
   977	        """Like :meth:`dict.values`."""
   978	        for card in self._cards:
   979	            yield None if card.value == UNDEFINED else card.value
   980	
   981	    def pop(self, *args):
   982	        """
   983	        Works like :meth:`list.pop` if no arguments or an index argument are
   984	        supplied; otherwise works like :meth:`dict.pop`.
   985	        """
   986	        if len(args) > 2:
   987	            raise TypeError(f"Header.pop expected at most 2 arguments, got {len(args)}")
   988	
   989	        if len(args) == 0:
   990	            key = -1
   991	        else:
   992	            key = args[0]
   993	
   994	        try:
   995	            value = self[key]
   996	        except (KeyError, IndexError):
   997	            if len(args) == 2:
   998	                return args[1]
   999	            raise
  1000	
  1001	        del self[key]
  1002	        return value
  1003	
  1004	    def popitem(self):
  1005	        """Similar to :meth:`dict.popitem`."""
  1006	        try:
  1007	            k, v = next(self.items())
  1008	        except StopIteration:
  1009	            raise KeyError("Header is empty")
  1010	        del self[k]
  1011	        return k, v
  1012	
  1013	    def setdefault(self, key, default=None):
  1014	        """Similar to :meth:`dict.setdefault`."""
  1015	        try:
  1016	            return self[key]
  1017	        except (KeyError, IndexError):
  1018	            self[key] = default
  1019	        return default
  1020	
  1021	    def update(self, *args, **kwargs):
  1022	        """
  1023	        Update the Header with new keyword values, updating the values of
  1024	        existing keywords and appending new keywords otherwise; similar to
  1025	        `dict.update`.
  1026	
  1027	        `update` accepts either a dict-like object or an iterable.  In the
  1028	        former case the keys must be header keywords and the values may be
  1029	        either scalar values or (value, comment) tuples.  In the case of an
  1030	        iterable the items must be (keyword, value) tuples or (keyword, value,
  1031	        comment) tuples.
  1032	
  1033	        Arbitrary arguments are also accepted, in which case the update() is
  1034	        called again with the kwargs dict as its only argument.  That is,
  1035	
  1036	        ::
  1037	
  1038	            >>> header.update(NAXIS1=100, NAXIS2=100)
  1039	
  1040	        is equivalent to::
  1370	
  1371	
  1372	
  1373	
  1374	
  1375	
  1376	
  1377	
  1378	
  1379	
  1380	
  1381	
  1382	
  1383	
  1384	
  1385	
  1386	
  1387	
  1388	
  1389	
  1390	
  1391	
  1392	
  1393	
  1394	
  1395	
  1396	
  1397	
  1398	
  1399	
  1400	
  1401	
  1402	
  1403	
  1404	
  1405	
  1406	
  1407	
  1408	
  1409	
  1410	
  1411	
  1412	
  1413	
  1414	
  1415	
  1416	
  1417	
  1418	
  1419	
  1420	
  1421	
  1422	
  1423	
  1424	
  1425	
  1426	
  1427	
  1428	
  1429	
  1430	
  1431	
  1432	
  1433	
  1434	
  1435	
  1436	
  1437	
  1438	
  1439	
  1440	
  1441	
  1442	
  1443	
  1444	
  1445	
  1446	
  1447	
  1448	
  1449	
  1450	
  1451	
  1452	
  1453	
  1454	
  1455	
  1456	
  1457	
  1458	
  1459	
  1460	
  1461	
  1462	
  1463	
  1464	
  1465	
  1466	
  1467	
  1468	
  1469	
  1470	
  1471	
  1472	
  1473	
  1474	
  1475	
  1476	
  1477	
  1478	
  1479	
  1480	    def rename_keyword(self, oldkeyword, newkeyword, force=False):
  1481	        """
  1482	        Rename a card's keyword in the header.
  1483	
  1484	        Parameters
  1485	        ----------
  1486	        oldkeyword : str or int
  1487	            Old keyword or card index
  1488	
  1489	        newkeyword : str
  1490	            New keyword
  1491	
  1492	        force : bool, optional
  1493	            When `True`, if the new keyword already exists in the header, force
  1494	            the creation of a duplicate keyword. Otherwise a
  1495	            `ValueError` is raised.
  1496	        """
  1497	        old = Card.normalize_keyword(oldkeyword)
  1498	        new = Card.normalize_keyword(newkeyword)
  1499	
  1500	        if new == "CONTINUE":
  1501	            raise ValueError("Can not rename to CONTINUE")
  1502	
  1503	        if new in _commentary_keywords or old in _commentary_keywords:
  1504	            if not (new in _commentary_keywords and old in _commentary_keywords):
  1505	                raise ValueError(
  1506	                    "Regular and commentary keys can not be renamed to each other."
  1507	                )
  1508	        elif not force and new in self:
  1509	            raise ValueError(f"Intended keyword {new} already exists in header.")
  1510	
  1511	        idx = self.index(old)
  1512	        card = self._cards[idx]
  1513	        del self[idx]
  1514	        self.insert(idx, (new, card.value, card.comment))
  1515	
  1516	    def add_history(self, value, before=None, after=None):
  1517	        """
  1518	        Add a ``HISTORY`` card.
  1519	
  1520	        Parameters
  1521	        ----------
  1522	        value : str
  1523	            History text to be added.
  1524	
  1525	        before : str or int, optional
  1526	            Same as in `Header.update`
  1527	
  1528	        after : str or int, optional
  1529	            Same as in `Header.update`
  1530	        """
  1531	        self._add_commentary("HISTORY", value, before=before, after=after)
  1532	
  1533	    def add_comment(self, value, before=None, after=None):
  1534	        """
  1535	        Add a ``COMMENT`` card.
  1536	
  1537	        Parameters
  1538	        ----------
  1539	        value : str
  1540	            Text to be added.
  1541	
  1542	        before : str or int, optional
  1543	            Same as in `Header.update`
  1544	
  1545	        after : str or int, optional
  1546	            Same as in `Header.update`
  1547	        """
  1548	        self._add_commentary("COMMENT", value, before=before, after=after)
  1549	
  1550	    def add_blank(self, value="", before=None, after=None):
  1551	        """
  1552	        Add a blank card.
  1553	
  1554	        Parameters
  1555	        ----------
  1556	        value : str, optional
  1557	            Text to be added.
  1558	
  1559	        before : str or int, optional
  1560	            Same as in `Header.update`
  1561	
  1562	        after : str or int, optional
  1563	            Same as in `Header.update`
  1564	        """
  1565	        self._add_commentary("", value, before=before, after=after)
  1566	
  1567	    def strip(self):
  1568	        """
  1569	        Strip cards specific to a certain kind of header.
  1570	
  1571	        Strip cards like ``SIMPLE``, ``BITPIX``, etc. so the rest of
  1572	        the header can be used to reconstruct another kind of header.
  1573	        """
  1574	        # TODO: Previously this only deleted some cards specific to an HDU if
  1575	        # _hdutype matched that type.  But it seemed simple enough to just
  1576	        # delete all desired cards anyways, and just ignore the KeyErrors if
  1577	        # they don't exist.
  1578	        # However, it might be desirable to make this extendable somehow--have
  1579	        # a way for HDU classes to specify some headers that are specific only
  1580	        # to that type, and should be removed otherwise.
  1581	
  1582	        naxis = self.get("NAXIS", 0)
  1583	        tfields = self.get("TFIELDS", 0)
  1584	
  1585	        for idx in range(naxis):
  1586	            self.remove("NAXIS" + str(idx + 1), ignore_missing=True)
  1587	
  1588	        for name in (
  1589	            "TFORM",
  1590	            "TSCAL",
  1591	            "TZERO",
  1592	            "TNULL",
  1593	            "TTYPE",
  1594	            "TUNIT",
  1595	            "TDISP",
  1596	            "TDIM",
  1597	            "THEAP",
  1598	            "TBCOL",
  1599	        ):
  1600	            for idx in range(tfields):
  1601	                self.remove(name + str(idx + 1), ignore_missing=True)
  1602	
  1603	        for name in (
  1604	            "SIMPLE",
  1605	            "XTENSION",
  1606	            "BITPIX",
  1607	            "NAXIS",
  1608	            "EXTEND",
  1609	            "PCOUNT",
  1610	            "GCOUNT",
  1611	            "GROUPS",
  1612	            "BSCALE",
  1613	            "BZERO",
  1614	            "TFIELDS",
  1615	        ):
  1616	            self.remove(name, ignore_missing=True)
  1617	
  1618	    @property
  1619	    def data_size(self):
  1620	        """
  1621	        Return the size (in bytes) of the data portion following the `Header`.
  1622	        """
  1623	        return _hdr_data_size(self)
  1624	
  1625	    @property
  1626	    def data_size_padded(self):
  1627	        """
  1628	        Return the size (in bytes) of the data portion following the `Header`
  1629	        including padding.
  1630	        """
  1631	        size = self.data_size
  1632	        return size + _pad_length(size)
  1633	
  1634	
  1635	
  1636	
  1637	
  1638	
  1639	
  1640	
  1641	
  1642	
  1643	
  1644	
  1645	
  1646	
  1647	
  1648	
  1649	
  1650	
  1651	
  1652	
  1653	
  1654	
  1655	
  1656	
  1657	
  1658	
  1659	
  1660	
  1661	
  1662	
  1663	
  1664	
  1665	
  1666	
  1667	
  1668	
  1669	
  1670	
  1671	
  1672	
  1673	
  1674	
  1675	
  1676	
  1677	
  1678	
  1679	
  1680	
  1681	
  1682	
  1683	
  1684	
  1685	
  1686	
  1687	
  1688	
  1689	
  1690	
  1691	
  1692	
  1693	
  1694	
  1695	
  1696	
  1697	
  1698	
  1699	
  1700	
  1701	
  1702	
  1703	
  1704	
  1705	
  1706	
  1707	
  1708	
  1709	
  1710	
  1711	
  1712	
  1713	
  1714	
  1715	
  1716	
  1717	
  1718	
  1719	
  1720	
  1721	
  1722	
  1723	
  1724	
  1725	
  1726	
  1727	
  1728	    def _keyword_from_index(self, idx):
  1729	        """
  1730	        Given an integer index, return the (keyword, repeat) tuple that index
  1731	        refers to.  For most keywords the repeat will always be zero, but it
  1732	        may be greater than zero for keywords that are duplicated (especially
  1733	        commentary keywords).
  1734	
  1735	        In a sense this is the inverse of self.index, except that it also
  1736	        supports duplicates.
  1737	        """
  1738	        if idx < 0:
  1739	            idx += len(self._cards)
  1740	
  1741	        keyword = self._cards[idx].keyword
  1742	        keyword = Card.normalize_keyword(keyword)
  1743	        repeat = self._keyword_indices[keyword].index(idx)
  1744	        return keyword, repeat
  1745	
  1746	
  1747	
  1748	
  1749	
  1750	
  1751	
  1752	
  1753	
  1754	
  1755	
  1756	
  1757	
  1758	
  1759	
  1760	
  1761	
  1762	
  1763	
  1764	
  1765	
  1766	
  1767	
  1768	
  1769	
  1770	
  1771	
  1772	
  1773	
  1774	
  1775	
  1776	
  1777	
  1778	
  1779	
  1780	
  1781	
  1782	
  1783	
  1784	
  1785	
  1786	
  1787	
  1788	
  1789	
  1790	
  1791	
  1792	
  1793	
  1794	
  1795	
  1796	
  1797	
  1798	
  1799	
  1800	
  1801	
  1802	
  1803	
  1804	
  1805	    def _updateindices(self, idx, increment=True):
  1806	        """
  1807	        For all cards with index above idx, increment or decrement its index
  1808	        value in the keyword_indices dict.
  1809	        """
  1810	        if idx > len(self._cards):
  1811	            # Save us some effort
  1812	            return
  1813	
  1814	        increment = 1 if increment else -1
  1815	
  1816	        for index_sets in (self._keyword_indices, self._rvkc_indices):
  1817	            for indices in index_sets.values():
  1818	                for jdx, keyword_index in enumerate(indices):
  1819	                    if keyword_index >= idx:
  1820	                        indices[jdx] += increment
  1821	
  1822	    def _countblanks(self):
  1823	        """Returns the number of blank cards at the end of the Header."""
  1824	        for idx in range(1, len(self._cards)):
  1825	            if not self._cards[-idx].is_blank:
  1826	                return idx - 1
  1827	        return 0
  1828	
  1829	
  1830	
  1831	
  1832	
  1833	
  1834	
  1835	
  1836	
  1837	
  1838	
  1839	
  1840	
  1841	
  1842	    def _wildcardmatch(self, pattern):
  1843	        """
  1844	        Returns a list of indices of the cards matching the given wildcard
  1845	        pattern.
  1846	
  1847	         * '*' matches 0 or more characters
  1848	         * '?' matches a single character
  1849	         * '...' matches 0 or more of any non-whitespace character
  1850	        """
  1851	        pattern = pattern.replace("*", r".*").replace("?", r".")
  1852	        pattern = pattern.replace("...", r"\S*") + "$"
  1853	        match_pattern = re.compile(pattern, re.IGNORECASE).match
  1854	        return [i for i, card in enumerate(self._cards) if match_pattern(card.keyword)]
  1855	
  1856	
  1857	
  1858	
  1859	
  1860	
  1861	
  1862	
  1863	
  1864	
  1865	
  1866	
  1867	
  1868	
  1869	
  1870	
  1871	
  1872	
  1873	
  1874	
  1875	
  1876	    def _splitcommentary(self, keyword, value):
  1877	        """
  1878	        Given a commentary keyword and value, returns a list of the one or more
  1879	        cards needed to represent the full value.  This is primarily used to
  1880	        create the multiple commentary cards needed to represent a long value
  1881	        that won't fit into a single commentary card.
  1882	        """
  1883	        # The maximum value in each card can be the maximum card length minus
  1884	        # the maximum key length (which can include spaces if they key length
  1885	        # less than 8
  1886	        maxlen = Card.length - KEYWORD_LENGTH
  1887	        valuestr = str(value)
  1888	
  1889	        if len(valuestr) <= maxlen:
  1890	            # The value can fit in a single card
  1891	            cards = [Card(keyword, value)]
  1892	        else:
  1893	            # The value must be split across multiple consecutive commentary
  1894	            # cards
  1895	            idx = 0
  1896	            cards = []
  1897	            while idx < len(valuestr):
  1898	                cards.append(Card(keyword, valuestr[idx : idx + maxlen]))
  1899	                idx += maxlen
  1900	        return cards
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc 'grep -n "''^class _Header'"\\|"'^class _CardAccessor'"\\|"'^    def _useblanks" astropy/io/fits/header.py
sed -n '"'1990,2350p' astropy/io/fits/header.py
sed -n '1,380p' astropy/io/fits/column.py"
```

退出码：`0`

输出：
```
2057:class _CardAccessor:
2120:class _HeaderComments(_CardAccessor):
2172:class _HeaderCommentaryCards(_CardAccessor):
        # dict of (keywords, card images)
        self._raw_cards = cards
        self._keys = list(cards.keys())
        # dict of (keyword, Card object) storing the parsed cards
        self._cards = {}
        # the _BasicHeaderCards object allows to access Card objects from
        # keyword indices
        self.cards = _BasicHeaderCards(self)

        self._modified = False

    def __getitem__(self, key):
        if isinstance(key, numbers.Integral):
            key = self._keys[key]

        try:
            return self._cards[key].value
        except KeyError:
            # parse the Card and store it
            cardstr = self._raw_cards[key]
            self._cards[key] = card = Card.fromstring(cardstr)
            return card.value

    def __len__(self):
        return len(self._raw_cards)

    def __iter__(self):
        return iter(self._raw_cards)

    def index(self, keyword):
        return self._keys.index(keyword)

    @property
    def data_size(self):
        """
        Return the size (in bytes) of the data portion following the `Header`.
        """
        return _hdr_data_size(self)

    @property
    def data_size_padded(self):
        """
        Return the size (in bytes) of the data portion following the `Header`
        including padding.
        """
        size = self.data_size
        return size + _pad_length(size)

    @classmethod
    def fromfile(cls, fileobj):
        """The main method to parse a FITS header from a file. The parsing is
        done with the parse_header function implemented in Cython.
        """
        close_file = False
        if isinstance(fileobj, str):
            fileobj = open(fileobj, "rb")
            close_file = True

        try:
            header_str, cards = parse_header(fileobj)
            _check_padding(header_str, BLOCK_SIZE, False)
            return header_str, cls(cards)
        finally:
            if close_file:
                fileobj.close()


class _CardAccessor:
    """
    This is a generic class for wrapping a Header in such a way that you can
    use the header's slice/filtering capabilities to return a subset of cards
    and do something with them.

    This is sort of the opposite notion of the old CardList class--whereas
    Header used to use CardList to get lists of cards, this uses Header to get
    lists of cards.
    """

    # TODO: Consider giving this dict/list methods like Header itself
    def __init__(self, header):
        self._header = header

    def __repr__(self):
        return "\n".join(repr(c) for c in self._header._cards)

    def __len__(self):
        return len(self._header._cards)

    def __iter__(self):
        return iter(self._header._cards)

    def __eq__(self, other):
        # If the `other` item is a scalar we will still treat it as equal if
        # this _CardAccessor only contains one item
        if not np.iterable(other) or isinstance(other, str):
            if len(self) == 1:
                other = [other]
            else:
                return False

        return all(a == b for a, b in itertools.zip_longest(self, other))

    def __ne__(self, other):
        return not (self == other)

    def __getitem__(self, item):
        if isinstance(item, slice) or self._header._haswildcard(item):
            return self.__class__(self._header[item])

        idx = self._header._cardindex(item)
        return self._header._cards[idx]

    def _setslice(self, item, value):
        """
        Helper for implementing __setitem__ on _CardAccessor subclasses; slices
        should always be handled in this same way.
        """
        if isinstance(item, slice) or self._header._haswildcard(item):
            if isinstance(item, slice):
                indices = range(*item.indices(len(self)))
            else:
                indices = self._header._wildcardmatch(item)
            if isinstance(value, str) or not np.iterable(value):
                value = itertools.repeat(value, len(indices))
            for idx, val in zip(indices, value):
                self[idx] = val
            return True
        return False


class _HeaderComments(_CardAccessor):
    """
    A class used internally by the Header class for the Header.comments
    attribute access.

    This object can be used to display all the keyword comments in the Header,
    or look up the comments on specific keywords.  It allows all the same forms
    of keyword lookup as the Header class itself, but returns comments instead
    of values.
    """

    def __iter__(self):
        for card in self._header._cards:
            yield card.comment

    def __repr__(self):
        """Returns a simple list of all keywords and their comments."""
        keyword_length = KEYWORD_LENGTH
        for card in self._header._cards:
            keyword_length = max(keyword_length, len(card.keyword))
        return "\n".join(
            "{:>{len}}  {}".format(c.keyword, c.comment, len=keyword_length)
            for c in self._header._cards
        )

    def __getitem__(self, item):
        """
        Slices and filter strings return a new _HeaderComments containing the
        returned cards.  Otherwise the comment of a single card is returned.
        """
        item = super().__getitem__(item)
        if isinstance(item, _HeaderComments):
            # The item key was a slice
            return item
        return item.comment

    def __setitem__(self, item, comment):
        """
        Set/update the comment on specified card or cards.

        Slice/filter updates work similarly to how Header.__setitem__ works.
        """
        if self._header._set_slice(item, comment, self):
            return

        # In this case, key/index errors should be raised; don't update
        # comments of nonexistent cards
        idx = self._header._cardindex(item)
        value = self._header[idx]
        self._header[idx] = (value, comment)


class _HeaderCommentaryCards(_CardAccessor):
    """
    This is used to return a list-like sequence over all the values in the
    header for a given commentary keyword, such as HISTORY.
    """

    def __init__(self, header, keyword=""):
        super().__init__(header)
        self._keyword = keyword
        self._count = self._header.count(self._keyword)
        self._indices = slice(self._count).indices(self._count)

    # __len__ and __iter__ need to be overridden from the base class due to the
    # different approach this class has to take for slicing
    def __len__(self):
        return len(range(*self._indices))

    def __iter__(self):
        for idx in range(*self._indices):
            yield self._header[(self._keyword, idx)]

    def __repr__(self):
        return "\n".join(str(x) for x in self)

    def __getitem__(self, idx):
        if isinstance(idx, slice):
            n = self.__class__(self._header, self._keyword)
            n._indices = idx.indices(self._count)
            return n
        elif not isinstance(idx, numbers.Integral):
            raise ValueError(f"{self._keyword} index must be an integer")

        idx = list(range(*self._indices))[idx]
        return self._header[(self._keyword, idx)]

    def __setitem__(self, item, value):
        """
        Set the value of a specified commentary card or cards.

        Slice/filter updates work similarly to how Header.__setitem__ works.
        """
        if self._header._set_slice(item, value, self):
            return

        # In this case, key/index errors should be raised; don't update
        # comments of nonexistent cards
        self._header[(self._keyword, item)] = value


def _block_size(sep):
    """
    Determine the size of a FITS header block if a non-blank separator is used
    between cards.
    """
    return BLOCK_SIZE + (len(sep) * (BLOCK_SIZE // Card.length - 1))


def _pad_length(stringlen):
    """Bytes needed to pad the input stringlen to the next FITS block."""
    return (BLOCK_SIZE - (stringlen % BLOCK_SIZE)) % BLOCK_SIZE


def _check_padding(header_str, block_size, is_eof, check_block_size=True):
    # Strip any zero-padding (see ticket #106)
    if header_str and header_str[-1] == "\0":
        if is_eof and header_str.strip("\0") == "":
            # TODO: Pass this warning to validation framework
            warnings.warn(
                "Unexpected extra padding at the end of the file.  This "
                "padding may not be preserved when saving changes.",
                AstropyUserWarning,
            )
            raise EOFError()
        else:
            # Replace the illegal null bytes with spaces as required by
            # the FITS standard, and issue a nasty warning
            # TODO: Pass this warning to validation framework
            warnings.warn(
                "Header block contains null bytes instead of spaces for "
                "padding, and is not FITS-compliant. Nulls may be "
                "replaced with spaces upon writing.",
                AstropyUserWarning,
            )
            header_str.replace("\0", " ")

    if check_block_size and (len(header_str) % block_size) != 0:
        # This error message ignores the length of the separator for
        # now, but maybe it shouldn't?
        actual_len = len(header_str) - block_size + BLOCK_SIZE
        # TODO: Pass this error to validation framework
        raise ValueError(f"Header size is not multiple of {BLOCK_SIZE}: {actual_len}")


def _hdr_data_size(header):
    """Calculate the data size (in bytes) following the given `Header`."""
    size = 0
    naxis = header.get("NAXIS", 0)
    if naxis > 0:
        size = 1
        for idx in range(naxis):
            size = size * header["NAXIS" + str(idx + 1)]
        bitpix = header["BITPIX"]
        gcount = header.get("GCOUNT", 1)
        pcount = header.get("PCOUNT", 0)
        size = abs(bitpix) * gcount * (pcount + size) // 8
    return size# Licensed under a 3-clause BSD style license - see PYFITS.rst

import copy
import numbers
import operator
import re
import sys
import warnings
import weakref
from collections import OrderedDict
from contextlib import suppress
from functools import reduce
from itertools import pairwise
from textwrap import indent

import numpy as np
from numpy import char as chararray

from astropy.utils import lazyproperty
from astropy.utils.exceptions import AstropyUserWarning

from .card import CARD_LENGTH, Card
from .util import NotifierMixin, _convert_array, cmp, encode_ascii
from .verify import VerifyError, VerifyWarning

__all__ = ["ColDefs", "Column", "Delayed"]


# mapping from TFORM data type to numpy data type (code)
# L: Logical (Boolean)
# B: Unsigned Byte
# I: 16-bit Integer
# J: 32-bit Integer
# K: 64-bit Integer
# E: Single-precision Floating Point
# D: Double-precision Floating Point
# C: Single-precision Complex
# M: Double-precision Complex
# A: Character
FITS2NUMPY = {
    "L": "i1",
    "B": "u1",
    "I": "i2",
    "J": "i4",
    "K": "i8",
    "E": "f4",
    "D": "f8",
    "C": "c8",
    "M": "c16",
    "A": "S",
}

# the inverse dictionary of the above
NUMPY2FITS = {val: key for key, val in FITS2NUMPY.items()}
# Normally booleans are represented as ints in Astropy, but if passed in a numpy
# boolean array, that should be supported
NUMPY2FITS["b1"] = "L"
# Add unsigned types, which will be stored as signed ints with a TZERO card.
NUMPY2FITS["u2"] = "I"
NUMPY2FITS["u4"] = "J"
NUMPY2FITS["u8"] = "K"
# Add half precision floating point numbers which will be up-converted to
# single precision.
NUMPY2FITS["f2"] = "E"

# This is the order in which values are converted to FITS types
# Note that only double precision floating point/complex are supported
FORMATORDER = ["L", "B", "I", "J", "K", "D", "M", "A"]

# Convert single precision floating point/complex to double precision.
FITSUPCONVERTERS = {"E": "D", "C": "M"}

# mapping from ASCII table TFORM data type to numpy data type
# A: Character
# I: Integer (32-bit)
# J: Integer (64-bit; non-standard)
# F: Float (64-bit; fixed decimal notation)
# E: Float (64-bit; exponential notation)
# D: Float (64-bit; exponential notation, always 64-bit by convention)
ASCII2NUMPY = {"A": "S", "I": "i4", "J": "i8", "F": "f8", "E": "f8", "D": "f8"}

# Maps FITS ASCII column format codes to the appropriate Python string
# formatting codes for that type.
ASCII2STR = {"A": "", "I": "d", "J": "d", "F": "f", "E": "E", "D": "E"}

# For each ASCII table format code, provides a default width (and decimal
# precision) for when one isn't given explicitly in the column format
ASCII_DEFAULT_WIDTHS = {
    "A": (1, 0),
    "I": (10, 0),
    "J": (15, 0),
    "E": (15, 7),
    "F": (16, 7),
    "D": (25, 17),
}

# TDISPn for both ASCII and Binary tables
TDISP_RE_DICT = {}
TDISP_RE_DICT["F"] = re.compile(
    r"(?:(?P<formatc>[F])(?:(?P<width>[0-9]+)\.{1}(?P<precision>[0-9]+))+)|"
)
TDISP_RE_DICT["A"] = TDISP_RE_DICT["L"] = re.compile(
    r"(?:(?P<formatc>[AL])(?P<width>[0-9]+)+)|"
)
TDISP_RE_DICT["I"] = TDISP_RE_DICT["B"] = TDISP_RE_DICT["O"] = TDISP_RE_DICT["Z"] = (
    re.compile(
        r"(?:(?P<formatc>[IBOZ])(?:(?P<width>[0-9]+)"
        r"(?:\.{0,1}(?P<precision>[0-9]+))?))|"
    )
)
TDISP_RE_DICT["E"] = TDISP_RE_DICT["G"] = TDISP_RE_DICT["D"] = re.compile(
    r"(?:(?P<formatc>[EGD])(?:(?P<width>[0-9]+)\."
    r"(?P<precision>[0-9]+))+)"
    r"(?:E{0,1}(?P<exponential>[0-9]+)?)|"
)
TDISP_RE_DICT["EN"] = TDISP_RE_DICT["ES"] = re.compile(
    r"(?:(?P<formatc>E[NS])(?:(?P<width>[0-9]+)\.{1}(?P<precision>[0-9]+))+)"
)

# mapping from TDISP format to python format
# A: Character
# L: Logical (Boolean)
# I: 16-bit Integer
#    Can't predefine zero padding and space padding before hand without
#    knowing the value being formatted, so grabbing precision and using that
#    to zero pad, ignoring width. Same with B, O, and Z
# B: Binary Integer
# O: Octal Integer
# Z: Hexadecimal Integer
# F: Float (64-bit; fixed decimal notation)
# EN: Float (engineering fortran format, exponential multiple of thee
# ES: Float (scientific, same as EN but non-zero leading digit
# E: Float, exponential notation
#    Can't get exponential restriction to work without knowing value
#    before hand, so just using width and precision, same with D, G, EN, and
#    ES formats
# D: Double-precision Floating Point with exponential
#    (E but for double precision)
# G: Double-precision Floating Point, may or may not show exponent
TDISP_FMT_DICT = {
    "I": "{{:{width}d}}",
    "B": "{{:{width}b}}",
    "O": "{{:{width}o}}",
    "Z": "{{:{width}x}}",
    "F": "{{:{width}.{precision}f}}",
    "G": "{{:{width}.{precision}g}}",
}
TDISP_FMT_DICT["A"] = TDISP_FMT_DICT["L"] = "{{:>{width}}}"
TDISP_FMT_DICT["E"] = TDISP_FMT_DICT["D"] = TDISP_FMT_DICT["EN"] = TDISP_FMT_DICT[
    "ES"
] = "{{:{width}.{precision}e}}"

# tuple of column/field definition common names and keyword names, make
# sure to preserve the one-to-one correspondence when updating the list(s).
# Use lists, instead of dictionaries so the names can be displayed in a
# preferred order.
KEYWORD_NAMES = (
    "TTYPE",
    "TFORM",
    "TUNIT",
    "TNULL",
    "TSCAL",
    "TZERO",
    "TDISP",
    "TBCOL",
    "TDIM",
    "TCTYP",
    "TCUNI",
    "TCRPX",
    "TCRVL",
    "TCDLT",
    "TRPOS",
)
KEYWORD_ATTRIBUTES = (
    "name",
    "format",
    "unit",
    "null",
    "bscale",
    "bzero",
    "disp",
    "start",
    "dim",
    "coord_type",
    "coord_unit",
    "coord_ref_point",
    "coord_ref_value",
    "coord_inc",
    "time_ref_pos",
)
"""This is a list of the attributes that can be set on `Column` objects."""


KEYWORD_TO_ATTRIBUTE = OrderedDict(zip(KEYWORD_NAMES, KEYWORD_ATTRIBUTES))

ATTRIBUTE_TO_KEYWORD = OrderedDict(zip(KEYWORD_ATTRIBUTES, KEYWORD_NAMES))


# TODO: Define a list of default comments to associate with each table keyword

# TFORMn regular expression
TFORMAT_RE = re.compile(
    r"(?P<repeat>^[0-9]*)(?P<format>[LXBIJKAEDCMPQ])(?P<option>[!-~]*)", re.IGNORECASE
)

# TFORMn for ASCII tables; two different versions depending on whether
# the format is floating-point or not; allows empty values for width
# in which case defaults are used
TFORMAT_ASCII_RE = re.compile(
    r"(?:(?P<format>[AIJ])(?P<width>[0-9]+)?)|"
    r"(?:(?P<formatf>[FED])"
    r"(?:(?P<widthf>[0-9]+)(?:\."
    r"(?P<precision>[0-9]+))?)?)"
)

TTYPE_RE = re.compile(r"[0-9a-zA-Z_]+")
"""
Regular expression for valid table column names.  See FITS Standard v3.0 section 7.2.2.
"""

# table definition keyword regular expression
TDEF_RE = re.compile(r"(?P<label>^T[A-Z]*)(?P<num>[1-9][0-9 ]*$)")

# table dimension keyword regular expression (fairly flexible with whitespace)
TDIM_RE = re.compile(r"\(\s*(?P<dims>(?:\d+\s*)(?:,\s*\d+\s*)*\s*)\)\s*")

# value for ASCII table cell with value = TNULL
# this can be reset by user.
ASCIITNULL = 0

# The default placeholder to use for NULL values in ASCII tables when
# converting from binary to ASCII tables
DEFAULT_ASCII_TNULL = "---"


class Delayed:
    """Delayed file-reading data."""

    def __init__(self, hdu=None, field=None):
        self.hdu = weakref.proxy(hdu)
        self.field = field

    def __getitem__(self, key):
        # This forces the data for the HDU to be read, which will replace
        # the corresponding Delayed objects in the Tables Columns to be
        # transformed into ndarrays.  It will also return the value of the
        # requested data element.
        return self.hdu.data[key][self.field]


class _BaseColumnFormat(str):
    """
    Base class for binary table column formats (just called _ColumnFormat)
    and ASCII table column formats (_AsciiColumnFormat).
    """

    def __eq__(self, other):
        if not other:
            return False

        if isinstance(other, str):
            if not isinstance(other, self.__class__):
                try:
                    other = self.__class__(other)
                except ValueError:
                    return False
        else:
            return False

        return self.canonical == other.canonical

    def __hash__(self):
        return hash(self.canonical)

    @lazyproperty
    def dtype(self):
        """
        The Numpy dtype object created from the format's associated recformat.
        """
        return np.dtype(self.recformat)

    @classmethod
    def from_column_format(cls, format):
        """Creates a column format object from another column format object
        regardless of their type.

        That is, this can convert a _ColumnFormat to an _AsciiColumnFormat
        or vice versa at least in cases where a direct translation is possible.
        """
        return cls.from_recformat(format.recformat)


class _ColumnFormat(_BaseColumnFormat):
    """
    Represents a FITS binary table column format.

    This is an enhancement over using a normal string for the format, since the
    repeat count, format code, and option are available as separate attributes,
    and smart comparison is used.  For example 1J == J.
    """

    def __new__(cls, format):
        self = super().__new__(cls, format)
        self.repeat, self.format, self.option = _parse_tformat(format)
        self.format = self.format.upper()
        if self.format in ("P", "Q"):
            # TODO: There should be a generic factory that returns either
            # _FormatP or _FormatQ as appropriate for a given TFORMn
            if self.format == "P":
                recformat = _FormatP.from_tform(format)
            else:
                recformat = _FormatQ.from_tform(format)
            # Format of variable length arrays
            self.p_format = recformat.format
        else:
            self.p_format = None
        return self

    @classmethod
    def from_recformat(cls, recformat):
        """Creates a column format from a Numpy record dtype format."""
        return cls(_convert_format(recformat, reverse=True))

    @lazyproperty
    def recformat(self):
        """Returns the equivalent Numpy record format string."""
        return _convert_format(self)

    @lazyproperty
    def canonical(self):
        """
        Returns a 'canonical' string representation of this format.

        This is in the proper form of rTa where T is the single character data
        type code, a is the optional part, and r is the repeat.  If repeat == 1
        (the default) it is left out of this representation.
        """
        if self.repeat == 1:
            repeat = ""
        else:
            repeat = str(self.repeat)

        return f"{repeat}{self.format}{self.option}"


class _AsciiColumnFormat(_BaseColumnFormat):
    """Similar to _ColumnFormat but specifically for columns in ASCII tables.

    The formats of ASCII table columns and binary table columns are inherently
    incompatible in FITS.  They don't support the same ranges and types of
    values, and even reuse format codes in subtly different ways.  For example
    the format code 'Iw' in ASCII columns refers to any integer whose string
    representation is at most w characters wide, so 'I' can represent
    effectively any integer that will fit in a FITS columns.  Whereas for
    binary tables 'I' very explicitly refers to a 16-bit signed integer.

    Conversions between the two column formats can be performed using the
    ``to/from_binary`` methods on this class, or the ``to/from_ascii``
    methods on the `_ColumnFormat` class.  But again, not all conversions are
    possible and may result in a `ValueError`.
    """

    def __new__(cls, format, strict=False):
        self = super().__new__(cls, format)
        self.format, self.width, self.precision = _parse_ascii_tformat(format, strict)

        # If no width has been specified, set the dtype here to default as well
        if format == self.format:
            self.recformat = ASCII2NUMPY[format]

        # This is to support handling logical (boolean) data from binary tables
        # in an ASCII table
        self._pseudo_logical = False
        return self

    @classmethod
    def from_column_format(cls, format):
        inst = cls.from_recformat(format.recformat)
        # Hack
        if format.format == "L":
```

## 原始行 24 · command_execution

命令：
```
/bin/bash -lc "grep -n \"_convert_fits2record\\|_parse_ascii_tformat\\|_parse_tformat\\|class _Format\" astropy/io/fits/column.py
nl -ba astropy/io/fits/column.py | sed -n '2200,2460p'
grep -n \"_has_data\\|_data_loaded\" astropy/io/fits/hdu/base.py | head -30
nl -ba astropy/io/fits/hdu/base.py | sed -n '180,300p'"
```

退出码：`0`

输出：
```
304:        self.repeat, self.format, self.option = _parse_tformat(format)
365:        self.format, self.width, self.precision = _parse_ascii_tformat(format, strict)
410:class _FormatX(str):
431:class _FormatP(str):
473:class _FormatQ(_FormatP):
2540:        return _convert_fits2record(format)
2577:        format, width, precision = _parse_ascii_tformat(format)
  2200	    """
  2201	    output[...] = 0  # reset the output
  2202	    nbytes = ((repeat - 1) // 8) + 1
  2203	    unused = nbytes * 8 - repeat
  2204	    for i in range(nbytes):
  2205	        _min = i * 8
  2206	        _max = min((i + 1) * 8, repeat)
  2207	        for j in range(_min, _max):
  2208	            if j != _min:
  2209	                np.left_shift(output[..., i], 1, output[..., i])
  2210	            np.add(output[..., i], input[..., j], output[..., i])
  2211	
  2212	    # shift the unused bits
  2213	    np.left_shift(output[..., i], unused, output[..., i])
  2214	
  2215	
  2216	def _makep(array, descr_output, format, nrows=None):
  2217	    """
  2218	    Construct the P (or Q) format column array, both the data descriptors and
  2219	    the data.  It returns the output "data" array of data type `dtype`.
  2220	
  2221	    The descriptor location will have a zero offset for all columns
  2222	    after this call.  The final offset will be calculated when the file
  2223	    is written.
  2224	
  2225	    Parameters
  2226	    ----------
  2227	    array
  2228	        input object array
  2229	
  2230	    descr_output
  2231	        output "descriptor" array of data type int32 (for P format arrays) or
  2232	        int64 (for Q format arrays)--must be nrows long in its first dimension
  2233	
  2234	    format
  2235	        the _FormatP object representing the format of the variable array
  2236	
  2237	    nrows : int, optional
  2238	        number of rows to create in the column; defaults to the number of rows
  2239	        in the input array
  2240	    """
  2241	    # TODO: A great deal of this is redundant with FITS_rec._convert_p; see if
  2242	    # we can merge the two somehow.
  2243	
  2244	    _offset = 0
  2245	
  2246	    if not nrows:
  2247	        nrows = len(array)
  2248	
  2249	    data_output = _VLF([None] * nrows, dtype=format.dtype)
  2250	
  2251	    if format.dtype == "S":
  2252	        _nbytes = 1
  2253	    else:
  2254	        _nbytes = np.array([], dtype=format.dtype).itemsize
  2255	
  2256	    for idx in range(nrows):
  2257	        if idx < len(array):
  2258	            rowval = array[idx]
  2259	        else:
  2260	            if format.dtype == "S":
  2261	                rowval = " " * data_output.max
  2262	            else:
  2263	                rowval = [0] * data_output.max
  2264	        if format.dtype == "S":
  2265	            data_output[idx] = chararray.array(encode_ascii(rowval), itemsize=1)
  2266	        else:
  2267	            data_output[idx] = np.array(rowval, dtype=format.dtype)
  2268	
  2269	        nelem = data_output[idx].shape
  2270	        descr_output[idx, 0] = np.prod(nelem)
  2271	        descr_output[idx, 1] = _offset
  2272	
  2273	        # detect overflow when using P format
  2274	        if (
  2275	            descr_output.dtype == np.int32
  2276	            and int(descr_output[idx, 0]) * _nbytes >= 2**31
  2277	        ):
  2278	            raise ValueError(
  2279	                "The heapsize limit for 'P' format has been reached. "
  2280	                "Please consider using the 'Q' format for your file."
  2281	            )
  2282	        _offset += descr_output[idx, 0] * _nbytes
  2283	
  2284	    return data_output
  2285	
  2286	
  2287	
  2288	
  2289	
  2290	
  2291	
  2292	
  2293	
  2294	
  2295	
  2296	
  2297	
  2298	
  2299	
  2300	
  2301	
  2302	
  2303	
  2304	
  2305	
  2306	
  2307	
  2308	
  2309	
  2310	
  2311	
  2312	
  2313	
  2314	
  2315	
  2316	
  2317	
  2318	
  2319	
  2320	
  2321	
  2322	
  2323	
  2324	
  2325	
  2326	
  2327	
  2328	
  2329	
  2330	
  2331	
  2332	
  2333	
  2334	
  2335	
  2336	
  2337	
  2338	
  2339	
  2340	
  2341	
  2342	
  2343	
  2344	
  2345	
  2346	
  2347	
  2348	
  2349	
  2350	
  2351	
  2352	
  2353	
  2354	
  2355	
  2356	
  2357	
  2358	
  2359	
  2360	
  2361	
  2362	
  2363	
  2364	
  2365	
  2366	
  2367	
  2368	
  2369	
  2370	
  2371	
  2372	
  2373	
  2374	
  2375	
  2376	
  2377	
  2378	
  2379	
  2380	
  2381	def _parse_tdim(tdim):
  2382	    """Parse the ``TDIM`` value into a tuple (may return an empty tuple if
  2383	    the value ``TDIM`` value is empty or invalid).
  2384	    """
  2385	    m = tdim and TDIM_RE.match(tdim)
  2386	    if m:
  2387	        dims = m.group("dims")
  2388	        return tuple(int(d.strip()) for d in dims.split(","))[::-1]
  2389	
  2390	    # Ignore any dim values that don't specify a multidimensional column
  2391	    return ()
  2392	
  2393	
  2394	def _scalar_to_format(value):
  2395	    """
  2396	    Given a scalar value or string, returns the minimum FITS column format
  2397	    that can represent that value.  'minimum' is defined by the order given in
  2398	    FORMATORDER.
  2399	    """
  2400	    # First, if value is a string, try to convert to the appropriate scalar
  2401	    # value
  2402	    for type_ in (int, float, complex):
  2403	        try:
  2404	            value = type_(value)
  2405	            break
  2406	        except ValueError:
  2407	            continue
  2408	
  2409	    numpy_dtype_str = np.min_scalar_type(value).str
  2410	    numpy_dtype_str = numpy_dtype_str[1:]  # Strip endianness
  2411	
  2412	    try:
  2413	        fits_format = NUMPY2FITS[numpy_dtype_str]
  2414	        return FITSUPCONVERTERS.get(fits_format, fits_format)
  2415	    except KeyError:
  2416	        return "A" + str(len(value))
  2417	
  2418	
  2419	def _cmp_recformats(f1, f2):
  2420	    """
  2421	    Compares two numpy recformats using the ordering given by FORMATORDER.
  2422	    """
  2423	    if f1[0] == "S" and f2[0] == "S":
  2424	        return cmp(int(f1[1:]), int(f2[1:]))
  2425	    else:
  2426	        f1, f2 = NUMPY2FITS[f1], NUMPY2FITS[f2]
  2427	        return cmp(FORMATORDER.index(f1), FORMATORDER.index(f2))
  2428	
  2429	
  2430	
  2431	
  2432	
  2433	
  2434	
  2435	
  2436	
  2437	
  2438	
  2439	
  2440	
  2441	
  2442	
  2443	
  2444	
  2445	
  2446	
  2447	
  2448	
  2449	
  2450	
  2451	
  2452	
  2453	
  2454	
  2455	
  2456	
  2457	
  2458	
  2459	
  2460	
186:                if self._file is not None and self._data_loaded:
274:    def _data_loaded(self):
581:        if self._data_loaded or self._data_needs_rescale:
687:        if self._data_loaded:
718:        if closed and self._data_loaded and _get_array_mmap(self.data) is not None:
1342:        modified = self._header._modified or self._data_loaded
1380:        if not self._data_loaded:
   180	        data_prop = cls.__dict__.get("data", None)
   181	        if isinstance(data_prop, (lazyproperty, property)) and data_prop.fdel is None:
   182	            # Don't do anything if the class has already explicitly
   183	            # set the deleter for its data property
   184	            def data(self):
   185	                # The deleter
   186	                if self._file is not None and self._data_loaded:
   187	                    # sys.getrefcount is CPython specific and not on PyPy.
   188	                    has_getrefcount = hasattr(sys, "getrefcount")
   189	                    if has_getrefcount:
   190	                        data_refcount = sys.getrefcount(self.data)
   191	
   192	                    # Manually delete *now* so that FITS_rec.__del__
   193	                    # cleanup can happen if applicable
   194	                    del self.__dict__["data"]
   195	
   196	                    # Don't even do this unless the *only* reference to the
   197	                    # .data array was the one we're deleting by deleting
   198	                    # this attribute; if any other references to the array
   199	                    # are hanging around (perhaps the user ran ``data =
   200	                    # hdu.data``) don't even consider this:
   201	                    if has_getrefcount and data_refcount == 2:
   202	                        self._file._maybe_close_mmap()
   203	
   204	            cls.data = data_prop.deleter(data)
   205	
   206	        super().__init_subclass__(**kwargs)
   207	
   208	    @property
   209	    def header(self):
   210	        return self._header
   211	
   212	    @header.setter
   213	    def header(self, value):
   214	        self._header = value
   215	
   216	    @property
   217	    def name(self):
   218	        # Convert the value to a string to be flexible in some pathological
   219	        # cases (see ticket #96)
   220	        return str(self._header.get("EXTNAME", self._default_name))
   221	
   222	    @name.setter
   223	    def name(self, value):
   224	        if not isinstance(value, str):
   225	            raise TypeError("'name' attribute must be a string")
   226	        if not conf.extension_name_case_sensitive:
   227	            value = value.upper()
   228	        if "EXTNAME" in self._header:
   229	            self._header["EXTNAME"] = value
   230	        else:
   231	            self._header["EXTNAME"] = (value, "extension name")
   232	
   233	    @property
   234	    def ver(self):
   235	        return self._header.get("EXTVER", 1)
   236	
   237	    @ver.setter
   238	    def ver(self, value):
   239	        if not _is_int(value):
   240	            raise TypeError("'ver' attribute must be an integer")
   241	        if "EXTVER" in self._header:
   242	            self._header["EXTVER"] = value
   243	        else:
   244	            self._header["EXTVER"] = (value, "extension value")
   245	
   246	    @property
   247	    def level(self):
   248	        return self._header.get("EXTLEVEL", 1)
   249	
   250	    @level.setter
   251	    def level(self, value):
   252	        if not _is_int(value):
   253	            raise TypeError("'level' attribute must be an integer")
   254	        if "EXTLEVEL" in self._header:
   255	            self._header["EXTLEVEL"] = value
   256	        else:
   257	            self._header["EXTLEVEL"] = (value, "extension level")
   258	
   259	    @property
   260	    def is_image(self):
   261	        return self.name == "PRIMARY" or (
   262	            "XTENSION" in self._header
   263	            and (
   264	                self._header["XTENSION"] == "IMAGE"
   265	                or (
   266	                    self._header["XTENSION"] == "BINTABLE"
   267	                    and "ZIMAGE" in self._header
   268	                    and self._header["ZIMAGE"] is True
   269	                )
   270	            )
   271	        )
   272	
   273	    @property
   274	    def _data_loaded(self):
   275	        return "data" in self.__dict__ and self.data is not DELAYED
   276	
   277	
   278	
   279	
   280	
   281	    @classmethod
   282	    def register_hdu(cls, hducls):
   283	        cls._hdu_registry.add(hducls)
   284	
   285	    @classmethod
   286	    def unregister_hdu(cls, hducls):
   287	        if hducls in cls._hdu_registry:
   288	            cls._hdu_registry.remove(hducls)
   289	
   290	    @classmethod
   291	    def match_header(cls, header):
   292	        raise NotImplementedError
   293	
   294	    @classmethod
   295	    def fromstring(cls, data, checksum=False, ignore_missing_end=False, **kwargs):
   296	        """
   297	        Creates a new HDU object of the appropriate type from a string
   298	        containing the HDU's entire header and, optionally, its data.
   299	
   300	        Note: When creating a new HDU from a string without a backing file
```

## 原始行 27 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/column.py | sed -n '380,510p'
nl -ba astropy/io/fits/column.py | sed -n '2280,2620p'
nl -ba astropy/io/fits/hdu/base.py | sed -n '120,290p'"
```

退出码：`0`

输出：
```
   380	        if format.format == "L":
   381	            inst._pseudo_logical = True
   382	        return inst
   383	
   384	    @classmethod
   385	    def from_recformat(cls, recformat):
   386	        """Creates a column format from a Numpy record dtype format."""
   387	        return cls(_convert_ascii_format(recformat, reverse=True))
   388	
   389	    @lazyproperty
   390	    def recformat(self):
   391	        """Returns the equivalent Numpy record format string."""
   392	        return _convert_ascii_format(self)
   393	
   394	    @lazyproperty
   395	    def canonical(self):
   396	        """
   397	        Returns a 'canonical' string representation of this format.
   398	
   399	        This is in the proper form of Tw.d where T is the single character data
   400	        type code, w is the width in characters for this field, and d is the
   401	        number of digits after the decimal place (for format codes 'E', 'F',
   402	        and 'D' only).
   403	        """
   404	        if self.format in ("E", "F", "D"):
   405	            return f"{self.format}{self.width}.{self.precision}"
   406	
   407	        return f"{self.format}{self.width}"
   408	
   409	
   410	class _FormatX(str):
   411	    """For X format in binary tables."""
   412	
   413	    def __new__(cls, repeat=1):
   414	        nbytes = ((repeat - 1) // 8) + 1
   415	        # use an array, even if it is only ONE u1 (i.e. use tuple always)
   416	        obj = super().__new__(cls, repr((nbytes,)) + "u1")
   417	        obj.repeat = repeat
   418	        return obj
   419	
   420	    def __getnewargs__(self):
   421	        return (self.repeat,)
   422	
   423	    @property
   424	    def tform(self):
   425	        return f"{self.repeat}X"
   426	
   427	
   428	# TODO: Table column formats need to be verified upon first reading the file;
   429	# as it is, an invalid P format will raise a VerifyError from some deep,
   430	# unexpected place
   431	class _FormatP(str):
   432	    """For P format in variable length table."""
   433	
   434	    # As far as I can tell from my reading of the FITS standard, a type code is
   435	    # *required* for P and Q formats; there is no default
   436	    _format_re_template = (
   437	        r"(?P<repeat>\d+)?{}(?P<dtype>[LXBIJKAEDCM])(?:\((?P<max>\d*)\))?"
   438	    )
   439	    _format_code = "P"
   440	    _format_re = re.compile(_format_re_template.format(_format_code))
   441	    _descriptor_format = "2i4"
   442	
   443	    def __new__(cls, dtype, repeat=None, max=None):
   444	        obj = super().__new__(cls, cls._descriptor_format)
   445	        obj.format = NUMPY2FITS[dtype]
   446	        obj.dtype = dtype
   447	        obj.repeat = repeat
   448	        obj.max = max
   449	        return obj
   450	
   451	    def __getnewargs__(self):
   452	        return (self.dtype, self.repeat, self.max)
   453	
   454	    @classmethod
   455	    def from_tform(cls, format):
   456	        m = cls._format_re.match(format)
   457	        if not m or m.group("dtype") not in FITS2NUMPY:
   458	            raise VerifyError(f"Invalid column format: {format}")
   459	        repeat = m.group("repeat")
   460	        array_dtype = m.group("dtype")
   461	        max = m.group("max")
   462	        if not max:
   463	            max = None
   464	        return cls(FITS2NUMPY[array_dtype], repeat=repeat, max=max)
   465	
   466	    @property
   467	    def tform(self):
   468	        repeat = "" if self.repeat is None else self.repeat
   469	        max = "" if self.max is None else self.max
   470	        return f"{repeat}{self._format_code}{self.format}({max})"
   471	
   472	
   473	class _FormatQ(_FormatP):
   474	    """Carries type description of the Q format for variable length arrays.
   475	
   476	    The Q format is like the P format but uses 64-bit integers in the array
   477	    descriptors, allowing for heaps stored beyond 2GB into a file.
   478	    """
   479	
   480	    _format_code = "Q"
   481	    _format_re = re.compile(_FormatP._format_re_template.format(_format_code))
   482	    _descriptor_format = "2i8"
   483	
   484	
   485	class ColumnAttribute:
   486	    """
   487	    Descriptor for attributes of `Column` that are associated with keywords
   488	    in the FITS header and describe properties of the column as specified in
   489	    the FITS standard.
   490	
   491	    Each `ColumnAttribute` may have a ``validator`` method defined on it.
   492	    This validates values set on this attribute to ensure that they meet the
   493	    FITS standard.  Invalid values will raise a warning and will not be used in
   494	    formatting the column.  The validator should take two arguments--the
   495	    `Column` it is being assigned to, and the new value for the attribute, and
   496	    it must raise an `AssertionError` if the value is invalid.
   497	
   498	    The `ColumnAttribute` itself is a decorator that can be used to define the
   499	    ``validator`` for each column attribute.  For example::
   500	
   501	        @ColumnAttribute('TTYPE')
   502	        def name(col, name):
   503	            if not isinstance(name, str):
   504	                raise AssertionError
   505	
   506	    The actual object returned by this decorator is the `ColumnAttribute`
   507	    instance though, not the ``name`` function.  As such ``name`` is not a
   508	    method of the class it is defined in.
   509	
   510	    The setter for `ColumnAttribute` also updates the header of any table
  2280	                "Please consider using the 'Q' format for your file."
  2281	            )
  2282	        _offset += descr_output[idx, 0] * _nbytes
  2283	
  2284	    return data_output
  2285	
  2286	
  2287	
  2288	
  2289	
  2290	
  2291	
  2292	
  2293	
  2294	
  2295	
  2296	
  2297	
  2298	
  2299	
  2300	
  2301	
  2302	
  2303	
  2304	
  2305	
  2306	
  2307	
  2308	
  2309	
  2310	
  2311	
  2312	
  2313	
  2314	
  2315	
  2316	
  2317	
  2318	
  2319	
  2320	
  2321	
  2322	
  2323	
  2324	
  2325	
  2326	
  2327	
  2328	
  2329	
  2330	
  2331	
  2332	
  2333	
  2334	
  2335	
  2336	
  2337	
  2338	
  2339	
  2340	
  2341	
  2342	
  2343	
  2344	
  2345	
  2346	
  2347	
  2348	
  2349	
  2350	
  2351	
  2352	
  2353	
  2354	
  2355	
  2356	
  2357	
  2358	
  2359	
  2360	
  2361	
  2362	
  2363	
  2364	
  2365	
  2366	
  2367	
  2368	
  2369	
  2370	
  2371	
  2372	
  2373	
  2374	
  2375	
  2376	
  2377	
  2378	
  2379	
  2380	
  2381	def _parse_tdim(tdim):
  2382	    """Parse the ``TDIM`` value into a tuple (may return an empty tuple if
  2383	    the value ``TDIM`` value is empty or invalid).
  2384	    """
  2385	    m = tdim and TDIM_RE.match(tdim)
  2386	    if m:
  2387	        dims = m.group("dims")
  2388	        return tuple(int(d.strip()) for d in dims.split(","))[::-1]
  2389	
  2390	    # Ignore any dim values that don't specify a multidimensional column
  2391	    return ()
  2392	
  2393	
  2394	def _scalar_to_format(value):
  2395	    """
  2396	    Given a scalar value or string, returns the minimum FITS column format
  2397	    that can represent that value.  'minimum' is defined by the order given in
  2398	    FORMATORDER.
  2399	    """
  2400	    # First, if value is a string, try to convert to the appropriate scalar
  2401	    # value
  2402	    for type_ in (int, float, complex):
  2403	        try:
  2404	            value = type_(value)
  2405	            break
  2406	        except ValueError:
  2407	            continue
  2408	
  2409	    numpy_dtype_str = np.min_scalar_type(value).str
  2410	    numpy_dtype_str = numpy_dtype_str[1:]  # Strip endianness
  2411	
  2412	    try:
  2413	        fits_format = NUMPY2FITS[numpy_dtype_str]
  2414	        return FITSUPCONVERTERS.get(fits_format, fits_format)
  2415	    except KeyError:
  2416	        return "A" + str(len(value))
  2417	
  2418	
  2419	def _cmp_recformats(f1, f2):
  2420	    """
  2421	    Compares two numpy recformats using the ordering given by FORMATORDER.
  2422	    """
  2423	    if f1[0] == "S" and f2[0] == "S":
  2424	        return cmp(int(f1[1:]), int(f2[1:]))
  2425	    else:
  2426	        f1, f2 = NUMPY2FITS[f1], NUMPY2FITS[f2]
  2427	        return cmp(FORMATORDER.index(f1), FORMATORDER.index(f2))
  2428	
  2429	
  2430	
  2431	
  2432	
  2433	
  2434	
  2435	
  2436	
  2437	
  2438	
  2439	
  2440	
  2441	
  2442	
  2443	
  2444	
  2445	
  2446	
  2447	
  2448	
  2449	
  2450	
  2451	
  2452	
  2453	
  2454	
  2455	
  2456	
  2457	
  2458	
  2459	
  2460	
  2461	
  2462	
  2463	
  2464	
  2465	
  2466	
  2467	def _convert_record2fits(format):
  2468	    """
  2469	    Convert record format spec to FITS format spec.
  2470	    """
  2471	    recformat, kind, dtype = _dtype_to_recformat(format)
  2472	    shape = dtype.shape
  2473	    itemsize = dtype.base.itemsize
  2474	    if dtype.char == "U" or (
  2475	        dtype.subdtype is not None and dtype.subdtype[0].char == "U"
  2476	    ):
  2477	        # Unicode dtype--itemsize is 4 times actual ASCII character length,
  2478	        # which what matters for FITS column formats
  2479	        # Use dtype.base and dtype.subdtype --dtype for multi-dimensional items
  2480	        itemsize = itemsize // 4
  2481	
  2482	    option = str(itemsize)
  2483	
  2484	    ndims = len(shape)
  2485	    repeat = 1
  2486	    if ndims > 0:
  2487	        nel = np.array(shape, dtype="i8").prod()
  2488	        if nel > 1:
  2489	            repeat = nel
  2490	
  2491	    if kind == "S":
  2492	        # This is a kludge that will place string arrays into a
  2493	        # single field, so at least we won't lose data.  Need to
  2494	        # use a TDIM keyword to fix this, declaring as (slength,
  2495	        # dim1, dim2, ...)  as mwrfits does
  2496	
  2497	        ntot = int(repeat) * int(option)
  2498	
  2499	        output_format = str(ntot) + "A"
  2500	    elif recformat in NUMPY2FITS:  # record format
  2501	        if repeat != 1:
  2502	            repeat = str(repeat)
  2503	        else:
  2504	            repeat = ""
  2505	        output_format = repeat + NUMPY2FITS[recformat]
  2506	    else:
  2507	        raise ValueError(f"Illegal format `{format}`.")
  2508	
  2509	    return output_format
  2510	
  2511	
  2512	def _dtype_to_recformat(dtype):
  2513	    """
  2514	    Utility function for converting a dtype object or string that instantiates
  2515	    a dtype (e.g. 'float32') into one of the two character Numpy format codes
  2516	    that have been traditionally used by Astropy.
  2517	    """
  2518	    if not isinstance(dtype, np.dtype):
  2519	        dtype = np.dtype(dtype)
  2520	
  2521	    kind = dtype.base.kind
  2522	
  2523	    if kind in ("U", "S"):
  2524	        recformat = kind = "S"
  2525	    else:
  2526	        itemsize = dtype.base.itemsize
  2527	        recformat = kind + str(itemsize)
  2528	
  2529	    return recformat, kind, dtype
  2530	
  2531	
  2532	def _convert_format(format, reverse=False):
  2533	    """
  2534	    Convert FITS format spec to record format spec.  Do the opposite if
  2535	    reverse=True.
  2536	    """
  2537	    if reverse:
  2538	        return _convert_record2fits(format)
  2539	    else:
  2540	        return _convert_fits2record(format)
  2541	
  2542	
  2543	def _convert_ascii_format(format, reverse=False):
  2544	    """Convert ASCII table format spec to record format spec."""
  2545	    if reverse:
  2546	        recformat, kind, dtype = _dtype_to_recformat(format)
  2547	        itemsize = dtype.itemsize
  2548	
  2549	        if kind == "S":
  2550	            return "A" + str(itemsize)
  2551	        elif NUMPY2FITS.get(recformat) == "L":
  2552	            # Special case for logical/boolean types--for ASCII tables we
  2553	            # represent these as single character columns containing 'T' or 'F'
  2554	            # (a la the storage format for Logical columns in binary tables)
  2555	            return "A1"
  2556	        elif kind == "i":
  2557	            # Use for the width the maximum required to represent integers
  2558	            # of that byte size plus 1 for signs, but use a minimum of the
  2559	            # default width (to keep with existing behavior)
  2560	            width = 1 + len(str(2 ** (itemsize * 8)))
  2561	            width = max(width, ASCII_DEFAULT_WIDTHS["I"][0])
  2562	            return "I" + str(width)
  2563	        elif kind == "f":
  2564	            # This is tricky, but go ahead and use D if float-64, and E
  2565	            # if float-32 with their default widths
  2566	            if itemsize >= 8:
  2567	                format = "D"
  2568	            else:
  2569	                format = "E"
  2570	            width = ".".join(str(w) for w in ASCII_DEFAULT_WIDTHS[format])
  2571	            return format + width
  2572	        # TODO: There may be reasonable ways to represent other Numpy types so
  2573	        # let's see what other possibilities there are besides just 'S', 'i',
  2574	        # and 'f'.  If it doesn't have a reasonable ASCII representation then
  2575	        # raise an exception
  2576	    else:
  2577	        format, width, precision = _parse_ascii_tformat(format)
  2578	
  2579	        # This gives a sensible "default" dtype for a given ASCII
  2580	        # format code
  2581	        recformat = ASCII2NUMPY[format]
  2582	
  2583	        # The following logic is taken from CFITSIO:
  2584	        # For integers, if the width <= 4 we can safely use 16-bit ints for all
  2585	        # values, if width >= 10 we may need to accommodate 64-bit ints.
  2586	        # values [for the non-standard J format code just always force 64-bit]
  2587	        if format == "I":
  2588	            if width <= 4:
  2589	                recformat = "i2"
  2590	            elif width > 9:
  2591	                recformat = "i8"
  2592	        elif format == "A":
  2593	            recformat += str(width)
  2594	
  2595	        return recformat
  2596	
  2597	
  2598	def _parse_tdisp_format(tdisp):
  2599	    """
  2600	    Parse the ``TDISPn`` keywords for ASCII and binary tables into a
  2601	    ``(format, width, precision, exponential)`` tuple (the TDISP values
  2602	    for ASCII and binary are identical except for 'Lw',
  2603	    which is only present in BINTABLE extensions.
  2604	
  2605	    Parameters
  2606	    ----------
  2607	    tdisp : str
  2608	        TDISPn FITS Header keyword.  Used to specify display formatting.
  2609	
  2610	    Returns
  2611	    -------
  2612	    formatc: str
  2613	        The format characters from TDISPn
  2614	    width: str
  2615	        The width int value from TDISPn
  2616	    precision: str
  2617	        The precision int value from TDISPn
  2618	    exponential: str
  2619	        The exponential int value from TDISPn
  2620	
   120	                )
   121	                warnings.warn(
   122	                    "The HDU will be treated as corrupted.", AstropyUserWarning
   123	                )
   124	                klass = _CorruptedHDU
   125	                del exc
   126	                break
   127	
   128	    return klass
   129	
   130	
   131	# TODO: Come up with a better __repr__ for HDUs (and for HDULists, for that
   132	# matter)
   133	class _BaseHDU:
   134	    """Base class for all HDU (header data unit) classes."""
   135	
   136	    _hdu_registry = set()
   137	
   138	    # This HDU type is part of the FITS standard
   139	    _standard = True
   140	
   141	    # Byte to use for padding out blocks
   142	    _padding_byte = "\x00"
   143	
   144	    _default_name = ""
   145	
   146	    # _header uses a descriptor to delay the loading of the fits.Header object
   147	    # until it is necessary.
   148	    _header = _DelayedHeader()
   149	
   150	    def __init__(self, data=None, header=None, *args, **kwargs):
   151	        if header is None:
   152	            header = Header()
   153	        self._header = header
   154	        self._header_str = None
   155	        self._file = None
   156	        self._buffer = None
   157	        self._header_offset = None
   158	        self._data_offset = None
   159	        self._data_size = None
   160	
   161	        # This internal variable is used to track whether the data attribute
   162	        # still points to the same data array as when the HDU was originally
   163	        # created (this does not track whether the data is actually the same
   164	        # content-wise)
   165	        self._data_replaced = False
   166	        self._data_needs_rescale = False
   167	        self._new = True
   168	        self._output_checksum = False
   169	
   170	        if "DATASUM" in self._header and "CHECKSUM" not in self._header:
   171	            self._output_checksum = "datasum"
   172	        elif "CHECKSUM" in self._header:
   173	            self._output_checksum = True
   174	
   175	    def __init_subclass__(cls, **kwargs):
   176	        # Add the same data.deleter to all HDUs with a data property.
   177	        # It's unfortunate, but there's otherwise no straightforward way
   178	        # that a property can inherit setters/deleters of the property of the
   179	        # same name on base classes.
   180	        data_prop = cls.__dict__.get("data", None)
   181	        if isinstance(data_prop, (lazyproperty, property)) and data_prop.fdel is None:
   182	            # Don't do anything if the class has already explicitly
   183	            # set the deleter for its data property
   184	            def data(self):
   185	                # The deleter
   186	                if self._file is not None and self._data_loaded:
   187	                    # sys.getrefcount is CPython specific and not on PyPy.
   188	                    has_getrefcount = hasattr(sys, "getrefcount")
   189	                    if has_getrefcount:
   190	                        data_refcount = sys.getrefcount(self.data)
   191	
   192	                    # Manually delete *now* so that FITS_rec.__del__
   193	                    # cleanup can happen if applicable
   194	                    del self.__dict__["data"]
   195	
   196	                    # Don't even do this unless the *only* reference to the
   197	                    # .data array was the one we're deleting by deleting
   198	                    # this attribute; if any other references to the array
   199	                    # are hanging around (perhaps the user ran ``data =
   200	                    # hdu.data``) don't even consider this:
   201	                    if has_getrefcount and data_refcount == 2:
   202	                        self._file._maybe_close_mmap()
   203	
   204	            cls.data = data_prop.deleter(data)
   205	
   206	        super().__init_subclass__(**kwargs)
   207	
   208	    @property
   209	    def header(self):
   210	        return self._header
   211	
   212	    @header.setter
   213	    def header(self, value):
   214	        self._header = value
   215	
   216	    @property
   217	    def name(self):
   218	        # Convert the value to a string to be flexible in some pathological
   219	        # cases (see ticket #96)
   220	        return str(self._header.get("EXTNAME", self._default_name))
   221	
   222	    @name.setter
   223	    def name(self, value):
   224	        if not isinstance(value, str):
   225	            raise TypeError("'name' attribute must be a string")
   226	        if not conf.extension_name_case_sensitive:
   227	            value = value.upper()
   228	        if "EXTNAME" in self._header:
   229	            self._header["EXTNAME"] = value
   230	        else:
   231	            self._header["EXTNAME"] = (value, "extension name")
   232	
   233	    @property
   234	    def ver(self):
   235	        return self._header.get("EXTVER", 1)
   236	
   237	    @ver.setter
   238	    def ver(self, value):
   239	        if not _is_int(value):
   240	            raise TypeError("'ver' attribute must be an integer")
   241	        if "EXTVER" in self._header:
   242	            self._header["EXTVER"] = value
   243	        else:
   244	            self._header["EXTVER"] = (value, "extension value")
   245	
   246	    @property
   247	    def level(self):
   248	        return self._header.get("EXTLEVEL", 1)
   249	
   250	    @level.setter
   251	    def level(self, value):
   252	        if not _is_int(value):
   253	            raise TypeError("'level' attribute must be an integer")
   254	        if "EXTLEVEL" in self._header:
   255	            self._header["EXTLEVEL"] = value
   256	        else:
   257	            self._header["EXTLEVEL"] = (value, "extension level")
   258	
   259	    @property
   260	    def is_image(self):
   261	        return self.name == "PRIMARY" or (
   262	            "XTENSION" in self._header
   263	            and (
   264	                self._header["XTENSION"] == "IMAGE"
   265	                or (
   266	                    self._header["XTENSION"] == "BINTABLE"
   267	                    and "ZIMAGE" in self._header
   268	                    and self._header["ZIMAGE"] is True
   269	                )
   270	            )
   271	        )
   272	
   273	    @property
   274	    def _data_loaded(self):
   275	        return "data" in self.__dict__ and self.data is not DELAYED
   276	
   277	
   278	
   279	
   280	
   281	    @classmethod
   282	    def register_hdu(cls, hducls):
   283	        cls._hdu_registry.add(hducls)
   284	
   285	    @classmethod
   286	    def unregister_hdu(cls, hducls):
   287	        if hducls in cls._hdu_registry:
   288	            cls._hdu_registry.remove(hducls)
   289	
   290	    @classmethod
```

## 原始行 29 · agent_message

```
The repository has deliberate blank regions where the requested methods should be; surrounding code and the project’s own FITS tests provide enough behavioral constraints. I’m mapping those tests now, especially duplicate/RVKC indexing and table-format error cases.
```

## 原始行 31 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"_parse_tformat|_parse_ascii_tformat|_convert_fits2record|_has_data|_DelayedHeader|\\.comments|wildcard|remove_all|ignore_missing|header\\.insert|Header.*insert|_cardindex|_relativeinsert\" astropy/io/fits/tests | head -500"
```

退出码：`0`

输出：
```
astropy/io/fits/tests/test_core.py:162:        assert header.comments["BITPIX"] == comment
astropy/io/fits/tests/test_core.py:166:        assert header.comments["BITPIX"] == ""
astropy/io/fits/tests/test_groups.py:251:            assert hdul[0].header.comments["GROUPS"] == "not a groups HDU"
astropy/io/fits/tests/test_diff.py:90:        hb.comments["C"] = "comment 2"
astropy/io/fits/tests/test_diff.py:294:        hb.comments["B"] = "D"
astropy/io/fits/tests/test_diff.py:295:        hb.comments["C"] = "E"
astropy/io/fits/tests/test_header.py:79:        assert header.comments["B"] == "C"
astropy/io/fits/tests/test_header.py:89:        assert header.comments[key] == "C"
astropy/io/fits/tests/test_header.py:91:        header.remove(key, ignore_missing=False)
astropy/io/fits/tests/test_header.py:279:        assert header.comments["B"] == "comment"
astropy/io/fits/tests/test_header.py:286:        assert header.comments["HELLO"] == "this is a comment"
astropy/io/fits/tests/test_header.py:296:        assert hdul[0].header.comments["FOO"] == "BAZ"
astropy/io/fits/tests/test_header.py:305:        hdul[0].header.comments["FOO"] = "QUX"
astropy/io/fits/tests/test_header.py:309:        assert hdul[0].header.comments["FOO"] == "QUX"
astropy/io/fits/tests/test_header.py:851:            header.insert(2, ("abcdefghij", 10))
astropy/io/fits/tests/test_header.py:856:            header.insert(2, ("abcdefghij", 10))
astropy/io/fits/tests/test_header.py:1003:        assert header.comments[0] == ""
astropy/io/fits/tests/test_header.py:1004:        assert header.comments["FOO"] == ""
astropy/io/fits/tests/test_header.py:1013:        assert header.comments[0] == "BAZ"
astropy/io/fits/tests/test_header.py:1014:        assert header.comments["FOO"] == "BAZ"
astropy/io/fits/tests/test_header.py:1015:        assert header.comments["FOO2"] == ""
astropy/io/fits/tests/test_header.py:1066:        assert header.comments["A"] == "D"
astropy/io/fits/tests/test_header.py:1126:    def test_wildcard_slice(self):
astropy/io/fits/tests/test_header.py:1127:        """Test selecting a subsection of a header via wildcard matching."""
astropy/io/fits/tests/test_header.py:1137:    def test_wildcard_with_hyphen(self):
astropy/io/fits/tests/test_header.py:1139:        Regression test for issue where wildcards did not work on keywords
astropy/io/fits/tests/test_header.py:1148:    def test_wildcard_slice_assignment(self):
astropy/io/fits/tests/test_header.py:1149:        """Test assigning to a header slice selected via wildcard matching."""
astropy/io/fits/tests/test_header.py:1171:    def test_wildcard_slice_deletion(self):
astropy/io/fits/tests/test_header.py:1172:        """Test deleting cards from a header that match a wildcard pattern."""
astropy/io/fits/tests/test_header.py:1215:        assert header.comments["A"] == ""
astropy/io/fits/tests/test_header.py:1218:        assert header.comments["B"] == ""
astropy/io/fits/tests/test_header.py:1224:        assert header.comments["A"] == ""
astropy/io/fits/tests/test_header.py:1227:        assert header.comments["B"] == ""
astropy/io/fits/tests/test_header.py:1233:        assert header.comments["A"] == "C"
astropy/io/fits/tests/test_header.py:1554:        assert header.comments["E"] == ""
astropy/io/fits/tests/test_header.py:1564:        assert header.comments[""] == ""
astropy/io/fits/tests/test_header.py:1574:        header.insert(1, ("E", "F"))
astropy/io/fits/tests/test_header.py:1581:        header.insert(1, ("G", "H"), useblanks=False)
astropy/io/fits/tests/test_header.py:1599:        header.insert("NAXIS1", ("NAXIS", 2, "Number of axes"))
astropy/io/fits/tests/test_header.py:1602:        assert header.comments[0] == "Number of axes"
astropy/io/fits/tests/test_header.py:1604:        header.insert("NAXIS1", ("NAXIS2", 20), after=True)
astropy/io/fits/tests/test_header.py:1609:        header.insert(("COMMENT", 1), ("COMMENT", "Comment 2"))
astropy/io/fits/tests/test_header.py:1612:        header.insert(("COMMENT", 2), ("COMMENT", "Comment 4"), after=True)
astropy/io/fits/tests/test_header.py:1615:        header.insert(-1, ("TEST1", True))
astropy/io/fits/tests/test_header.py:1618:        header.insert(-1, ("TEST2", True), after=True)
astropy/io/fits/tests/test_header.py:1631:        # When keyword is not present in the header and ignore_missing is
astropy/io/fits/tests/test_header.py:1636:        # When keyword is not present and ignore_missing is True, KeyError
astropy/io/fits/tests/test_header.py:1638:        header.remove("F", ignore_missing=True)
astropy/io/fits/tests/test_header.py:1643:        header.remove("A", remove_all=True)
astropy/io/fits/tests/test_header.py:1651:        assert repr(header.comments) == "       A  C\n     DEF  H"
astropy/io/fits/tests/test_header.py:1655:        s = header.comments[1:]
astropy/io/fits/tests/test_header.py:1657:        s = header.comments[::-1]
astropy/io/fits/tests/test_header.py:1659:        s = header.comments["A*"]
astropy/io/fits/tests/test_header.py:1664:        header.comments[1:] = "L"
astropy/io/fits/tests/test_header.py:1665:        assert list(header.comments) == ["D", "L", "L"]
astropy/io/fits/tests/test_header.py:1670:        header.comments[::-1] = header.comments[:]
astropy/io/fits/tests/test_header.py:1671:        assert list(header.comments) == ["L", "L", "D"]
astropy/io/fits/tests/test_header.py:1673:        header.comments["A*"] = ["M", "N"]
astropy/io/fits/tests/test_header.py:1674:        assert list(header.comments) == ["M", "L", "N"]
astropy/io/fits/tests/test_header.py:1697:        header.insert(0, ("A", "B", "C"))
astropy/io/fits/tests/test_header.py:1927:        pytest.raises(ValueError, header.insert, len(header), "END")
astropy/io/fits/tests/test_header.py:2222:        # Case insensitivity of wildcards
astropy/io/fits/tests/test_header.py:2331:        assert h.comments["FOO"] == "BAZ"
astropy/io/fits/tests/test_header.py:2734:        header.insert(idx, ("D", 42))
astropy/io/fits/tests/test_header.py:3161:        # Can we use wildcards for keywords?
astropy/io/fits/tests/test_header.py:3258:    assert my_header.comments["a"] == "first"
astropy/io/fits/tests/test_header.py:3259:    assert my_header.comments["b"] == "second"
astropy/io/fits/tests/test_header.py:3260:    assert my_header.comments["c"] == "no comment"
astropy/io/fits/tests/test_header.py:3264:    assert slice_.comments["b"] == "second"
astropy/io/fits/tests/test_header.py:3265:    assert slice_.comments["c"] == "no comment"
astropy/io/fits/tests/test_header.py:3268:    assert selection.comments["c"] == "no comment"
astropy/io/fits/tests/test_header.py:3271:    assert copy_.comments["b"] == "second"
astropy/io/fits/tests/test_header.py:3272:    assert copy_.comments["c"] == "no comment"
astropy/io/fits/tests/test_header.py:3274:    assert my_header.comments["d"] == "no comment"
astropy/io/fits/tests/test_fitsdiff.py:192:    def test_wildcard(self):
astropy/io/fits/tests/test_fitstime.py:235:            assert hdr.comments[key] == value[1]
astropy/io/fits/tests/test_hdulist.py:1074:        with fits.open(filename, ignore_missing_simple=True) as hdul:
astropy/io/fits/tests/test_hdulist.py:1106:        with fits.open(filename, ignore_missing_simple=True) as hdul:
astropy/io/fits/tests/test_hdulist.py:1162:        # whether ignore_missing_end is True or False).
astropy/io/fits/tests/test_hdulist.py:1171:                fits.open(f, ignore_missing_end=False)
astropy/io/fits/tests/test_hdulist.py:1177:                fits.open(f, ignore_missing_end=True)
astropy/io/fits/tests/test_hdulist.py:1182:            fits.open(filename, ignore_missing_end=False)
astropy/io/fits/tests/test_hdulist.py:1185:            fits.open(filename, ignore_missing_end=True)
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,340p' astropy/io/fits/tests/test_header.py
sed -n '960,1250p' astropy/io/fits/tests/test_header.py
sed -n '1500,1720p' astropy/io/fits/tests/test_header.py
sed -n '2180,2360p' astropy/io/fits/tests/test_header.py
sed -n '2680,2770p' astropy/io/fits/tests/test_header.py
sed -n '3120,3290p' astropy/io/fits/tests/test_header.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import collections
import copy
import warnings
from io import BytesIO, StringIO

import numpy as np
import pytest

from astropy.io import fits
from astropy.io.fits.card import _pad
from astropy.io.fits.header import _pad_length
from astropy.io.fits.scripts import fitsheader
from astropy.io.fits.util import encode_ascii
from astropy.io.fits.verify import VerifyError, VerifyWarning
from astropy.utils.exceptions import AstropyUserWarning
from astropy.utils.misc import _NOT_OVERWRITING_MSG_MATCH

from .conftest import FitsTestCase


def test_shallow_copy():
    """Make sure that operations on a shallow copy do not alter the original.
    #4990."""
    original_header = fits.Header([("a", 1), ("b", 1)])
    copied_header = copy.copy(original_header)

    # Modifying the original dict should not alter the copy
    original_header["c"] = 100
    assert "c" not in copied_header

    # and changing the copy should not change the original.
    copied_header["a"] = 0
    assert original_header["a"] == 1


def test_init_with_header():
    """Make sure that creating a Header from another Header makes a copy if
    copy is True."""

    original_header = fits.Header([("a", 10)])
    new_header = fits.Header(original_header, copy=True)
    original_header["a"] = 20
    assert new_header["a"] == 10

    new_header["a"] = 0
    assert original_header["a"] == 20


def test_init_with_dict():
    dict1 = {"a": 11, "b": 12, "c": 13, "d": 14, "e": 15}
    h1 = fits.Header(dict1)
    for i, expected in dict1.items():
        assert h1[i] == expected


def test_init_with_ordereddict():
    # Create a list of tuples. Each tuple consisting of a letter and the number
    list1 = [(i, j) for j, i in enumerate("abcdefghijklmnopqrstuvwxyz")]
    # Create an ordered dictionary and a header from this dictionary
    dict1 = collections.OrderedDict(list1)
    h1 = fits.Header(dict1)
    # Check that the order is preserved of the initial list
    assert all(h1[val] == list1[i][1] for i, val in enumerate(h1))


class TestHeaderFunctions(FitsTestCase):
    """Test Header and Card objects."""

    def test_rename_keyword(self):
        """Test renaming keyword with rename_keyword."""
        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])
        header.rename_keyword("A", "B")
        assert "A" not in header
        assert "B" in header
        assert header[0] == "B"
        assert header["B"] == "B"
        assert header.comments["B"] == "C"

    @pytest.mark.parametrize("key", ["A", "a"])
    def test_indexing_case(self, key):
        """Check that indexing is case insensitive"""
        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])
        assert key in header
        assert header[key] == "B"
        assert header.get(key) == "B"
        assert header.index(key) == 0
        assert header.comments[key] == "C"
        assert header.count(key) == 1
        header.remove(key, ignore_missing=False)

    def test_card_constructor_default_args(self):
        """Test Card constructor with default argument values."""

        c = fits.Card()
        assert c.keyword == ""

    def test_card_from_bytes(self):
        """
        Test loading a Card from a `bytes` object (assuming latin-1 encoding).
        """

        c = fits.Card.fromstring(b"ABC     = 'abc'")
        assert c.keyword == "ABC"
        assert c.value == "abc"

    def test_string_value_card(self):
        """Test Card constructor with string value"""

        c = fits.Card("abc", "<8 ch")
        assert str(c) == _pad("ABC     = '<8 ch   '")
        c = fits.Card("nullstr", "")
        assert str(c) == _pad("NULLSTR = ''")

    def test_boolean_value_card(self):
        """Test Card constructor with boolean value"""

        c = fits.Card("abc", True)
        assert str(c) == _pad("ABC     =                    T")

        c = fits.Card.fromstring("ABC     = F")
        assert c.value is False

    def test_long_integer_value_card(self):
        """Test Card constructor with long integer value"""

        c = fits.Card("long_int", -467374636747637647347374734737437)
        assert str(c) == _pad("LONG_INT= -467374636747637647347374734737437")

    def test_floating_point_value_card(self):
        """Test Card constructor with floating point value"""

        c = fits.Card("floatnum", -467374636747637647347374734737437.0)

        if str(c) != _pad("FLOATNUM= -4.6737463674763E+32") and str(c) != _pad(
            "FLOATNUM= -4.6737463674763E+032"
        ):
            assert str(c) == _pad("FLOATNUM= -4.6737463674763E+32")

    def test_floating_point_string_representation_card(self):
        """
        Ensures Card formats float values with the correct precision, avoiding
        comment truncation

        Regression test for https://github.com/astropy/astropy/issues/14507
        """
        k = "HIERARCH ABC DEF GH IJKLMN"
        com = "[m] abcdef ghijklm nopqrstu vw xyzab"
        c = fits.Card(k, 0.009125, com)
        expected_str = f"{k} = 0.009125 / {com}"
        assert str(c)[: len(expected_str)] == expected_str

        c = fits.Card(k, 8.95, com)
        expected_str = f"{k} = 8.95 / {com}"
        assert str(c)[: len(expected_str)] == expected_str

        c = fits.Card(k, -99.9, com)
        expected_str = f"{k} = -99.9 / {com}"
        assert str(c)[: len(expected_str)] == expected_str

    def test_complex_value_card(self):
        """Test Card constructor with complex value"""

        c = fits.Card("abc", (1.2345377437887837487e88 + 6324767364763746367e-33j))
        f1 = _pad("ABC     = (1.23453774378878E+88, 6.32476736476374E-15)")
        f2 = _pad("ABC     = (1.2345377437887E+088, 6.3247673647637E-015)")
        f3 = _pad("ABC     = (1.23453774378878E+88, 6.32476736476374E-15)")
        if str(c) != f1 and str(c) != f2:
            assert str(c) == f3

    def test_card_image_constructed_too_long(self):
        """Test that over-long cards truncate the comment"""

        # card image constructed from key/value/comment is too long
        # (non-string value)
        c = fits.Card("abc", 9, "abcde" * 20)
        with pytest.warns(fits.verify.VerifyWarning):
            assert (
                str(c) == "ABC     =                    9 "
                "/ abcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeabcdeab"
            )
        c = fits.Card("abc", "a" * 68, "abcdefg")
        with pytest.warns(fits.verify.VerifyWarning):
            assert str(c) == f"ABC     = '{'a' * 68}'"

    def test_constructor_filter_illegal_data_structures(self):
        """Test that Card constructor raises exceptions on bad arguments"""

        pytest.raises(ValueError, fits.Card, ("abc",), {"value": (2, 3)})
        pytest.raises(ValueError, fits.Card, "key", [], "comment")

    def test_keyword_too_long(self):
        """Test that long Card keywords are allowed, but with a warning"""
        with pytest.warns(
            UserWarning,
            match=(
                r"^Keyword name 'abcdefghi' is greater than 8 characters or contains "
                r"characters not allowed by the FITS standard; a HIERARCH card will be created\.$"
            ),
        ):
            fits.Card("abcdefghi", "long")

    def test_illegal_characters_in_key(self):
        """
        Test that Card constructor allows illegal characters in the keyword,
        but creates a HIERARCH card.
        """

        # This test used to check that a ValueError was raised, because a
        # keyword like 'abc+' was simply not allowed.  Now it should create a
        # HIERARCH card.

        with pytest.warns(AstropyUserWarning) as w:
            c = fits.Card("abc+", 9)
        assert len(w) == 1
        assert c.image == _pad("HIERARCH abc+ =                    9")

    def test_add_history(self):
        header = fits.Header(
            [
                ("A", "B", "C"),
                ("HISTORY", 1),
                ("HISTORY", 2),
                ("HISTORY", 3),
                ("", "", ""),
                ("", "", ""),
            ]
        )
        header.add_history(4)
        # One of the blanks should get used, so the length shouldn't change
        assert len(header) == 6
        assert header.cards[4].value == 4
        assert header["HISTORY"] == [1, 2, 3, 4]
        assert repr(header["HISTORY"]) == "1\n2\n3\n4"

        header.add_history(0, after="A")
        assert len(header) == 6
        assert header.cards[1].value == 0
        assert header["HISTORY"] == [0, 1, 2, 3, 4]

    def test_add_blank(self):
        header = fits.Header(
            [("A", "B", "C"), ("", 1), ("", 2), ("", 3), ("", "", ""), ("", "", "")]
        )
        header.add_blank(4)
        # This time a new blank should be added, and the existing blanks don't
        # get used... (though this is really kinda sketchy--there's a
        # distinction between truly blank cards, and cards with blank keywords
        # that isn't currently made int he code)
        assert len(header) == 7
        assert header.cards[6].value == 4
        assert header[""] == [1, 2, 3, "", "", 4]
        assert repr(header[""]) == "1\n2\n3\n\n\n4"

        header.add_blank(0, after="A")
        assert len(header) == 8
        assert header.cards[1].value == 0
        assert header[""] == [0, 1, 2, 3, "", "", 4]

        header[""] = 5
        header[" "] = 6
        assert header[""] == [0, 1, 2, 3, "", "", 4, 5, 6]
        assert header[" "] == [0, 1, 2, 3, "", "", 4, 5, 6]

    def test_update(self):
        class FakeHeader(list):
            def keys(self):
                return [l[0] for l in self]

            def __getitem__(self, key):
                return next(l[1:] for l in self if l[0] == key)

        header = fits.Header()
        header.update({"FOO": ("BAR", "BAZ")})
        header.update(FakeHeader([("A", 1), ("B", 2, "comment")]))

        assert set(header.keys()) == {"FOO", "A", "B"}
        assert header.comments["B"] == "comment"

        # test that comments are preserved
        tmphdr = fits.Header()
        tmphdr["HELLO"] = (1, "this is a comment")
        header.update(tmphdr)
        assert set(header.keys()) == {"FOO", "A", "B", "HELLO"}
        assert header.comments["HELLO"] == "this is a comment"

        header.update(NAXIS1=100, NAXIS2=100)
        assert set(header.keys()) == {"FOO", "A", "B", "HELLO", "NAXIS1", "NAXIS2"}
        assert tuple(header.values()) == ("BAR", 1, 2, 1, 100, 100)

    def test_update_comment(self):
        hdul = fits.open(self.data("arange.fits"))
        hdul[0].header.update({"FOO": ("BAR", "BAZ")})
        assert hdul[0].header["FOO"] == "BAR"
        assert hdul[0].header.comments["FOO"] == "BAZ"

        with pytest.raises(ValueError):
            hdul[0].header.update({"FOO2": ("BAR", "BAZ", "EXTRA")})

        hdul.writeto(self.temp("test.fits"))
        hdul.close()

        hdul = fits.open(self.temp("test.fits"), mode="update")
        hdul[0].header.comments["FOO"] = "QUX"
        hdul.close()

        hdul = fits.open(self.temp("test.fits"))
        assert hdul[0].header.comments["FOO"] == "QUX"

        hdul[0].header.add_comment(0, after="FOO")
        assert str(hdul[0].header.cards[-1]).strip() == "COMMENT 0"
        hdul.close()

    def test_commentary_cards(self):
        # commentary cards
        val = "A commentary card's value has no quotes around it."
        c = fits.Card("HISTORY", val)
        assert str(c) == _pad("HISTORY " + val)
        val = "A commentary card has no comment."
        c = fits.Card("COMMENT", val, "comment")
        assert str(c) == _pad("COMMENT " + val)

    def test_commentary_card_created_by_fromstring(self):
        # commentary card created by fromstring()
        c = fits.Card.fromstring(
            "COMMENT card has no comments. "
            "/ text after slash is still part of the value."
        )
        assert (
            c.value == "card has no comments. "
            "/ text after slash is still part of the value."
        )
        assert c.comment == ""

    def test_commentary_card_will_not_parse_numerical_value(self):
        # commentary card will not parse the numerical value
        c = fits.Card.fromstring("HISTORY  (1, 2)")
        assert str(c) == _pad("HISTORY  (1, 2)")

        with pytest.warns(VerifyWarning) as w:
            # Create a HIERARCH card containing invalid characters without
            # explicitly stating 'HIERARCH'
            header.update({"BLA BLA": "TESTA"})
            print([x.category for x in w])
            assert len(w) == 1
            assert msg in str(w[0].message)

            header.update({"HIERARCH BLA BLA": "TESTB"})
            assert len(w) == 1
            assert header["BLA BLA"], "TESTB"

            # Update without explicitly stating 'HIERARCH':
            header.update({"BLA BLA": "TESTC"})
            assert len(w) == 2
            assert header["BLA BLA"], "TESTC"

            # Test case-insensitivity
            header.update({"HIERARCH bla bla": "TESTD"})
            assert len(w) == 2
            assert len(header) == 1
            assert header["bla bla"], "TESTD"

            header.update({"bla bla": "TESTE"})
            assert len(w) == 3
            assert len(header) == 1
            assert header["bla bla"], "TESTE"

    def test_header_setitem_invalid(self):
        header = fits.Header()

        def test():
            header["FOO"] = ("bar", "baz", "qux")

        pytest.raises(ValueError, test)

    def test_header_setitem_1tuple(self):
        header = fits.Header()
        header["FOO"] = ("BAR",)
        header["FOO2"] = (None,)
        assert header["FOO"] == "BAR"
        assert header["FOO2"] is None
        assert header[0] == "BAR"
        assert header.comments[0] == ""
        assert header.comments["FOO"] == ""

    def test_header_setitem_2tuple(self):
        header = fits.Header()
        header["FOO"] = ("BAR", "BAZ")
        header["FOO2"] = (None, None)
        assert header["FOO"] == "BAR"
        assert header["FOO2"] is None
        assert header[0] == "BAR"
        assert header.comments[0] == "BAZ"
        assert header.comments["FOO"] == "BAZ"
        assert header.comments["FOO2"] == ""

    def test_header_set_value_to_none(self):
        """
        Setting the value of a card to None should simply give that card an
        undefined value.  Undefined value should map to None.
        """

        header = fits.Header()
        header["FOO"] = "BAR"
        assert header["FOO"] == "BAR"
        header["FOO"] = None
        assert header["FOO"] is None

        # Create a header that contains an undefined value and a defined
        # value.
        hstr = "UNDEF   = \nDEFINED = 42"
        header = fits.Header.fromstring(hstr, sep="\n")

        # Explicitly add a card with an UNDEFINED value
        c = fits.Card("UNDEF2", fits.card.UNDEFINED)
        header.extend([c])

        # And now assign an undefined value to the header through setitem
        header["UNDEF3"] = fits.card.UNDEFINED

        # Tuple assignment
        header.append(("UNDEF5", None, "Undefined value"), end=True)
        header.append("UNDEF6")

        assert header["DEFINED"] == 42
        assert header["UNDEF"] is None
        assert header["UNDEF2"] is None
        assert header["UNDEF3"] is None
        assert header["UNDEF5"] is None
        assert header["UNDEF6"] is None

        # Assign an undefined value to a new card
        header["UNDEF4"] = None

        # Overwrite an existing value with None
        header["DEFINED"] = None

        # All headers now should be undefined
        for c in header.cards:
            assert c.value == fits.card.UNDEFINED

    def test_set_comment_only(self):
        header = fits.Header([("A", "B", "C")])
        header.set("A", comment="D")
        assert header["A"] == "B"
        assert header.comments["A"] == "D"

    def test_header_iter(self):
        header = fits.Header([("A", "B"), ("C", "D")])
        assert list(header) == ["A", "C"]

    def test_header_slice(self):
        header = fits.Header([("A", "B"), ("C", "D"), ("E", "F")])
        newheader = header[1:]
        assert len(newheader) == 2
        assert "A" not in newheader
        assert "C" in newheader
        assert "E" in newheader

        newheader = header[::-1]
        assert len(newheader) == 3
        assert newheader[0] == "F"
        assert newheader[1] == "D"
        assert newheader[2] == "B"

        newheader = header[::2]
        assert len(newheader) == 2
        assert "A" in newheader
        assert "C" not in newheader
        assert "E" in newheader

    def test_header_slice_assignment(self):
        """
        Assigning to a slice should just assign new values to the cards
        included in the slice.
        """

        header = fits.Header([("A", "B"), ("C", "D"), ("E", "F")])

        # Test assigning slice to the same value; this works similarly to numpy
        # arrays
        header[1:] = 1
        assert header[1] == 1
        assert header[2] == 1

        # Though strings are iterable they should be treated as a scalar value
        header[1:] = "GH"
        assert header[1] == "GH"
        assert header[2] == "GH"

        # Now assign via an iterable
        header[1:] = ["H", "I"]
        assert header[1] == "H"
        assert header[2] == "I"

    def test_header_slice_delete(self):
        """Test deleting a slice of cards from the header."""

        header = fits.Header([("A", "B"), ("C", "D"), ("E", "F")])
        del header[1:]
        assert len(header) == 1
        assert header[0] == "B"
        del header[:]
        assert len(header) == 0

    def test_wildcard_slice(self):
        """Test selecting a subsection of a header via wildcard matching."""

        header = fits.Header(
            [("ABC", 0), ("DEF", 1), ("ABD", 2)]  # codespell:ignore abd
        )
        newheader = header["AB*"]
        assert len(newheader) == 2
        assert newheader[0] == 0
        assert newheader[1] == 2

    def test_wildcard_with_hyphen(self):
        """
        Regression test for issue where wildcards did not work on keywords
        containing hyphens.
        """

        header = fits.Header([("DATE", 1), ("DATE-OBS", 2), ("DATE-FOO", 3)])
        assert len(header["DATE*"]) == 3
        assert len(header["DATE?*"]) == 2
        assert len(header["DATE-*"]) == 2

    def test_wildcard_slice_assignment(self):
        """Test assigning to a header slice selected via wildcard matching."""

        header = fits.Header(
            [("ABC", 0), ("DEF", 1), ("ABD", 2)]  # codespell:ignore abd
        )

        # Test assigning slice to the same value; this works similarly to numpy
        # arrays
        header["AB*"] = 1
        assert header[0] == 1
        assert header[2] == 1

        # Though strings are iterable they should be treated as a scalar value
        header["AB*"] = "GH"
        assert header[0] == "GH"
        assert header[2] == "GH"

        # Now assign via an iterable
        header["AB*"] = ["H", "I"]
        assert header[0] == "H"
        assert header[2] == "I"

    def test_wildcard_slice_deletion(self):
        """Test deleting cards from a header that match a wildcard pattern."""

        header = fits.Header(
            [("ABC", 0), ("DEF", 1), ("ABD", 2)]  # codespell:ignore abd
        )
        del header["AB*"]
        assert len(header) == 1
        assert header[0] == 1

    def test_header_history(self):
        header = fits.Header(
            [
                ("ABC", 0),
                ("HISTORY", 1),
                ("HISTORY", 2),
                ("DEF", 3),
                ("HISTORY", 4),
                ("HISTORY", 5),
            ]
        )
        assert header["HISTORY"] == [1, 2, 4, 5]

    def test_header_clear(self):
        header = fits.Header([("A", "B"), ("C", "D")])
        header.clear()
        assert "A" not in header
        assert "C" not in header
        assert len(header) == 0

    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
    def test_header_clear_write(self, fitsext):
        hdulist = fits.HDUList([fits.PrimaryHDU(), fitsext])
        hdulist[1].header["FOO"] = "BAR"
        hdulist[1].header.clear()
        with pytest.raises(VerifyError) as err:
            hdulist.writeto(self.temp("temp.fits"), overwrite=True)
        err_msg = "'XTENSION' card does not exist."
        assert err_msg in str(err.value)

    def test_header_fromkeys(self):
        header = fits.Header.fromkeys(["A", "B"])
        assert "A" in header
        assert header["A"] is None
        assert header.comments["A"] == ""
        assert "B" in header
        assert header["B"] is None
        assert header.comments["B"] == ""

    def test_header_fromkeys_with_value(self):
        header = fits.Header.fromkeys(["A", "B"], "C")
        assert "A" in header
        assert header["A"] == "C"
        assert header.comments["A"] == ""
        assert "B" in header
        assert header["B"] == "C"
        assert header.comments["B"] == ""

    def test_header_fromkeys_with_value_and_comment(self):
        header = fits.Header.fromkeys(["A"], ("B", "C"))
        assert "A" in header
        assert header["A"] == "B"
        assert header.comments["A"] == "C"

    def test_header_fromkeys_with_duplicates(self):
        header = fits.Header.fromkeys(["A", "B", "A"], "C")
        assert "A" in header
        assert ("A", 0) in header
        assert ("A", 1) in header
        assert ("A", 2) not in header
        assert header[0] == "C"
        assert header["A"] == "C"
        assert header[("A", 0)] == "C"
        assert header[2] == "C"
        assert header[("A", 1)] == "C"

    def test_header_items(self):
        header = fits.Header([("A", "B"), ("C", "D")])
        assert list(header.items()) == [("A", "B"), ("C", "D")]


        header = fits.getheader(self.data("test0.fits"))
        header2 = fits.Header()
        header2.extend(header, strip=False, end=True)
        assert header == header2

    def test_header_count(self):
        header = fits.Header([("A", "B"), ("C", "D"), ("E", "F")])
        assert header.count("A") == 1
        assert header.count("C") == 1
        assert header.count("E") == 1
        header["HISTORY"] = "a"
        header["HISTORY"] = "b"
        assert header.count("HISTORY") == 2
        pytest.raises(KeyError, header.count, "G")

    def test_header_append_use_blanks(self):
        """
        Tests that blank cards can be appended, and that future appends will
        use blank cards when available (unless useblanks=False)
        """

        header = fits.Header([("A", "B"), ("C", "D")])

        # Append a couple blanks
        header.append()
        header.append()
        assert len(header) == 4
        assert header[-1] == ""
        assert header[-2] == ""

        # New card should fill the first blank by default
        header.append(("E", "F"))
        assert len(header) == 4
        assert header[-2] == "F"
        assert header[-1] == ""

        # This card should not use up a blank spot
        header.append(("G", "H"), useblanks=False)
        assert len(header) == 5
        assert header[-1] == ""
        assert header[-2] == "H"

    def test_header_append_keyword_only(self):
        """
        Test appending a new card with just the keyword, and no value or
        comment given.
        """

        header = fits.Header([("A", "B"), ("C", "D")])
        header.append("E")
        assert len(header) == 3
        assert list(header)[-1] == "E"
        assert header[-1] is None
        assert header.comments["E"] == ""

        # Try appending a blank--normally this can be accomplished with just
        # header.append(), but header.append('') should also work (and is maybe
        # a little more clear)
        header.append("")
        assert len(header) == 4

        assert list(header)[-1] == ""
        assert header[""] == ""
        assert header.comments[""] == ""

    def test_header_insert_use_blanks(self):
        header = fits.Header([("A", "B"), ("C", "D")])

        # Append a couple blanks
        header.append()
        header.append()

        # Insert a new card; should use up one of the blanks
        header.insert(1, ("E", "F"))
        assert len(header) == 4
        assert header[1] == "F"
        assert header[-1] == ""
        assert header[-2] == "D"

        # Insert a new card without using blanks
        header.insert(1, ("G", "H"), useblanks=False)
        assert len(header) == 5
        assert header[1] == "H"
        assert header[-1] == ""

    def test_header_insert_before_keyword(self):
        """
        Test that a keyword name or tuple can be used to insert new keywords.

        Also tests the ``after`` keyword argument.

        Regression test for https://github.com/spacetelescope/PyFITS/issues/12
        """

        header = fits.Header(
            [("NAXIS1", 10), ("COMMENT", "Comment 1"), ("COMMENT", "Comment 3")]
        )

        header.insert("NAXIS1", ("NAXIS", 2, "Number of axes"))
        assert list(header.keys())[0] == "NAXIS"
        assert header[0] == 2
        assert header.comments[0] == "Number of axes"

        header.insert("NAXIS1", ("NAXIS2", 20), after=True)
        assert list(header.keys())[1] == "NAXIS1"
        assert list(header.keys())[2] == "NAXIS2"
        assert header[2] == 20

        header.insert(("COMMENT", 1), ("COMMENT", "Comment 2"))
        assert header["COMMENT"] == ["Comment 1", "Comment 2", "Comment 3"]

        header.insert(("COMMENT", 2), ("COMMENT", "Comment 4"), after=True)
        assert header["COMMENT"] == ["Comment 1", "Comment 2", "Comment 3", "Comment 4"]

        header.insert(-1, ("TEST1", True))
        assert list(header.keys())[-2] == "TEST1"

        header.insert(-1, ("TEST2", True), after=True)
        assert list(header.keys())[-1] == "TEST2"
        assert list(header.keys())[-3] == "TEST1"

    def test_remove(self):
        header = fits.Header([("A", "B"), ("C", "D")])

        # When keyword is present in the header it should be removed.
        header.remove("C")
        assert len(header) == 1
        assert list(header) == ["A"]
        assert "C" not in header

        # When keyword is not present in the header and ignore_missing is
        # False, KeyError should be raised
        with pytest.raises(KeyError):
            header.remove("F")

        # When keyword is not present and ignore_missing is True, KeyError
        # will be ignored
        header.remove("F", ignore_missing=True)
        assert len(header) == 1

        # Test for removing all instances of a keyword
        header = fits.Header([("A", "B"), ("C", "D"), ("A", "F")])
        header.remove("A", remove_all=True)
        assert "A" not in header
        assert len(header) == 1
        assert list(header) == ["C"]
        assert header[0] == "D"

    def test_header_comments(self):
        header = fits.Header([("A", "B", "C"), ("DEF", "G", "H")])
        assert repr(header.comments) == "       A  C\n     DEF  H"

    def test_comment_slices_and_filters(self):
        header = fits.Header([("AB", "C", "D"), ("EF", "G", "H"), ("AI", "J", "K")])
        s = header.comments[1:]
        assert list(s) == ["H", "K"]
        s = header.comments[::-1]
        assert list(s) == ["K", "H", "D"]
        s = header.comments["A*"]
        assert list(s) == ["D", "K"]

    def test_comment_slice_filter_assign(self):
        header = fits.Header([("AB", "C", "D"), ("EF", "G", "H"), ("AI", "J", "K")])
        header.comments[1:] = "L"
        assert list(header.comments) == ["D", "L", "L"]
        assert header.cards[header.index("AB")].comment == "D"
        assert header.cards[header.index("EF")].comment == "L"
        assert header.cards[header.index("AI")].comment == "L"

        header.comments[::-1] = header.comments[:]
        assert list(header.comments) == ["L", "L", "D"]

        header.comments["A*"] = ["M", "N"]
        assert list(header.comments) == ["M", "L", "N"]

    def test_commentary_slicing(self):
        header = fits.Header()

        indices = list(range(5))

        for idx in indices:
            header["HISTORY"] = idx

        # Just a few sample slice types; this won't get all corner cases but if
        # these all work we should be in good shape
        assert header["HISTORY"][1:] == indices[1:]
        assert header["HISTORY"][:3] == indices[:3]
        assert header["HISTORY"][:6] == indices[:6]
        assert header["HISTORY"][:-2] == indices[:-2]
        assert header["HISTORY"][::-1] == indices[::-1]
        assert header["HISTORY"][1::-1] == indices[1::-1]
        assert header["HISTORY"][1:5:2] == indices[1:5:2]

        # Same tests, but copy the values first; as it turns out this is
        # different from just directly doing an __eq__ as in the first set of
        # assertions
        header.insert(0, ("A", "B", "C"))
        header.append(("D", "E", "F"), end=True)
        assert list(header["HISTORY"][1:]) == indices[1:]
        assert list(header["HISTORY"][:3]) == indices[:3]
        assert list(header["HISTORY"][:6]) == indices[:6]
        assert list(header["HISTORY"][:-2]) == indices[:-2]
        assert list(header["HISTORY"][::-1]) == indices[::-1]
        assert list(header["HISTORY"][1::-1]) == indices[1::-1]
        assert list(header["HISTORY"][1:5:2]) == indices[1:5:2]

    def test_update_commentary(self):
        header = fits.Header()
        header["FOO"] = "BAR"
        header["HISTORY"] = "ABC"
        header["FRED"] = "BARNEY"
        header["HISTORY"] = "DEF"
        header["HISTORY"] = "GHI"

        assert header["HISTORY"] == ["ABC", "DEF", "GHI"]

        # Single value update
        header["HISTORY"][0] = "FOO"
        assert header["HISTORY"] == ["FOO", "DEF", "GHI"]

        barimg = _pad("BAR     =                    F")
        h = fits.Header()
        h["FOO"] = True
        h["BAR"] = False
        assert h["FOO"] is True
        assert h["BAR"] is False
        assert str(h.cards["FOO"]) == fooimg
        assert str(h.cards["BAR"]) == barimg

        h = fits.Header()
        h["FOO"] = np.bool_(True)
        h["BAR"] = np.bool_(False)
        assert h["FOO"] is True
        assert h["BAR"] is False
        assert str(h.cards["FOO"]) == fooimg
        assert str(h.cards["BAR"]) == barimg

        h = fits.Header()
        h.append(fits.Card.fromstring(fooimg))
        h.append(fits.Card.fromstring(barimg))
        assert h["FOO"] is True
        assert h["BAR"] is False
        assert str(h.cards["FOO"]) == fooimg
        assert str(h.cards["BAR"]) == barimg

    def test_header_method_keyword_normalization(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/149

        Basically ensures that all public Header methods are case-insensitive
        w.r.t. keywords.

        Provides a reasonably comprehensive test of several methods at once.
        """

        h = fits.Header([("abC", 1), ("Def", 2), ("GeH", 3)])
        assert list(h) == ["ABC", "DEF", "GEH"]
        assert "abc" in h
        assert "dEf" in h

        assert h["geh"] == 3

        # Case insensitivity of wildcards
        assert len(h["g*"]) == 1

        h["aBc"] = 2
        assert h["abc"] == 2
        # ABC already existed so assigning to aBc should not have added any new
        # cards
        assert len(h) == 3

        del h["gEh"]
        assert list(h) == ["ABC", "DEF"]
        assert len(h) == 2
        assert h.get("def") == 2

        h.set("Abc", 3)
        assert h["ABC"] == 3
        h.set("gEh", 3, before="Abc")
        assert list(h) == ["GEH", "ABC", "DEF"]

        assert h.pop("abC") == 3
        assert len(h) == 2

        assert h.setdefault("def", 3) == 2
        assert len(h) == 2
        assert h.setdefault("aBc", 1) == 1
        assert len(h) == 3
        assert list(h) == ["GEH", "DEF", "ABC"]

        h.update({"GeH": 1, "iJk": 4})
        assert len(h) == 4
        assert list(h) == ["GEH", "DEF", "ABC", "IJK"]
        assert h["GEH"] == 1

        assert h.count("ijk") == 1
        assert h.index("ijk") == 3

        h.remove("Def")
        assert len(h) == 3
        assert list(h) == ["GEH", "ABC", "IJK"]

    def test_end_in_comment(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/142

        Tests a case where the comment of a card ends with END, and is followed
        by several blank cards.
        """

        data = np.arange(100).reshape(10, 10)
        hdu = fits.PrimaryHDU(data=data)
        hdu.header["TESTKW"] = ("Test val", "This is the END")
        # Add a couple blanks after the END string
        hdu.header.append()
        hdu.header.append()
        hdu.writeto(self.temp("test.fits"))

        with fits.open(self.temp("test.fits"), memmap=False) as hdul:
            # memmap = False to avoid leaving open a mmap to the file when we
            # access the data--this causes problems on Windows when we try to
            # overwrite the file later
            assert "TESTKW" in hdul[0].header
            assert hdul[0].header == hdu.header
            assert (hdul[0].data == data).all()

        # Add blanks until the header is extended to two block sizes
        while len(hdu.header) < 36:
            hdu.header.append()
        hdu.writeto(self.temp("test.fits"), overwrite=True)

        with fits.open(self.temp("test.fits")) as hdul:
            assert "TESTKW" in hdul[0].header
            assert hdul[0].header == hdu.header
            assert (hdul[0].data == data).all()

        # Test parsing the same header when it's written to a text file
        hdu.header.totextfile(self.temp("test.hdr"))
        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
        assert hdu.header == header2

    def test_assign_unicode(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/134

        Assigning a unicode literal as a header value should not fail silently.
        If the value can be converted to ASCII then it should just work.
        Otherwise it should fail with an appropriate value error.

        Also tests unicode for keywords and comments.
        """

        erikku = "\u30a8\u30ea\u30c3\u30af"

        def assign(keyword, val):
            h[keyword] = val

        h = fits.Header()
        h["FOO"] = "BAR"
        assert "FOO" in h
        assert h["FOO"] == "BAR"
        assert repr(h) == _pad("FOO     = 'BAR     '")
        pytest.raises(ValueError, assign, erikku, "BAR")

        h["FOO"] = "BAZ"
        assert h["FOO"] == "BAZ"
        assert repr(h) == _pad("FOO     = 'BAZ     '")
        pytest.raises(ValueError, assign, "FOO", erikku)

        h["FOO"] = ("BAR", "BAZ")
        assert h["FOO"] == "BAR"
        assert h.comments["FOO"] == "BAZ"
        assert repr(h) == _pad("FOO     = 'BAR     '           / BAZ")

        pytest.raises(ValueError, assign, "FOO", ("BAR", erikku))
        pytest.raises(ValueError, assign, "FOO", (erikku, "BAZ"))
        pytest.raises(ValueError, assign, "FOO", (erikku, erikku))

    def test_assign_non_ascii(self):
        """
        First regression test for
        https://github.com/spacetelescope/PyFITS/issues/37

        Although test_assign_unicode ensures that `str` objects containing
        non-ASCII characters cannot be assigned to headers.

        It should not be possible to assign bytes to a header at all.
        """

        h = fits.Header()
        with pytest.raises(ValueError, match="Illegal value: b'Hello'."):
            h.set("TEST", b"Hello")

    def test_header_strip_whitespace(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/146, and
        for the solution that is optional stripping of whitespace from the end
        of a header value.

        By default extra whitespace is stripped off, but if
        `fits.conf.strip_header_whitespace` = False it should not be
        assert hdr["KEY2"] == 4
        assert hdr["KEY2 "] == 4

    def test_strip(self):
        hdr = fits.getheader(self.data("tb.fits"), ext=1)
        hdr["FOO"] = "bar"
        hdr.strip()
        assert set(hdr) == {"HISTORY", "FOO"}

        hdr = fits.getheader(self.data("tb.fits"), ext=1)
        hdr["FOO"] = "bar"
        hdr = hdr.copy(strip=True)
        assert set(hdr) == {"HISTORY", "FOO"}

    def test_update_invalid_card(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/5408

        Tests updating the value of a card that is malformatted (with an
        invalid value literal).

        This tests two ways of reproducing the problem, one working with a
        Card object directly, and one when reading/writing a header containing
        such an invalid card.
        """

        card = fits.Card.fromstring("KW      = INF  / Comment")
        card.value = "FIXED"
        assert tuple(card) == ("KW", "FIXED", "Comment")
        card.verify("fix")
        assert tuple(card) == ("KW", "FIXED", "Comment")

        card = fits.Card.fromstring("KW      = INF")
        hdu = fits.PrimaryHDU()
        # This is a loophole to write a header containing a malformatted card
        card._verified = True
        hdu.header.append(card)
        hdu.header.tofile(self.temp("bogus.fits"))

        with fits.open(self.temp("bogus.fits")) as hdul:
            hdul[0].header["KW"] = -1
            hdul.writeto(self.temp("bogus_fixed.fits"))

        with fits.open(self.temp("bogus_fixed.fits")) as hdul:
            assert hdul[0].header["KW"] == -1

    def test_index_numpy_int(self):
        header = fits.Header([("A", "FOO"), ("B", 2), ("C", "BAR")])
        idx = np.int8(2)
        assert header[idx] == "BAR"

        header[idx] = "BAZ"
        assert header[idx] == "BAZ"

        header.insert(idx, ("D", 42))
        assert header[idx] == 42

        header.add_comment("HELLO")
        header.add_comment("WORLD")
        assert header["COMMENT"][np.int64(1)] == "WORLD"

        header.append(("C", "BAZBAZ"))
        assert header[("C", np.int16(0))] == "BAZ"
        assert header[("C", np.uint32(1))] == "BAZBAZ"

    def test_header_data_size(self):
        """
        Tests data size calculation (w/o padding) given a Header.
        """
        hdu = fits.PrimaryHDU()
        header = hdu.header
        assert header.data_size == 0

        header["BITPIX"] = 32
        header["NAXIS"] = 2
        header["NAXIS1"] = 100
        header["NAXIS2"] = 100
        assert header.data_size == 40000
        assert header.data_size_padded == 40320


class TestRecordValuedKeywordCards(FitsTestCase):
    """
    Tests for handling of record-valued keyword cards as used by the
    `FITS WCS distortion paper
    <https://www.atnf.csiro.au/people/mcalabre/WCS/dcs_20040422.pdf>`__.

    These tests are derived primarily from the release notes for PyFITS 1.4 (in
    which this feature was first introduced.
    Note that extra leading spaces in the `value` fields should be parsed on input,
    but will be stripped in the cards.
        Ensures that looking up a RVKC by keyword only (without the
        field-specifier) in a header returns the full string value of that card
        without parsing it as a RVKC.  Also ensures that a full field-specifier
        is required to match a RVKC--a partial field-specifier that doesn't
        explicitly match any record-valued keyword should result in a KeyError.
        """

        c1 = fits.Card.fromstring("FOO     = 'AXIS.1: 2'")
        c2 = fits.Card.fromstring("FOO     = 'AXIS.2: 4'")
        h = fits.Header([c1, c2])
        assert h["FOO"] == "AXIS.1: 2"
        assert h[("FOO", 1)] == "AXIS.2: 4"
        assert h["FOO.AXIS.1"] == 2.0
        assert h["FOO.AXIS.2"] == 4.0
        assert "FOO.AXIS" not in h
        assert "FOO.AXIS." not in h
        assert "FOO." not in h
        pytest.raises(KeyError, lambda: h["FOO.AXIS"])
        pytest.raises(KeyError, lambda: h["FOO.AXIS."])
        pytest.raises(KeyError, lambda: h["FOO."])

    def test_fitsheader_script(self):
        """Tests the basic functionality of the `fitsheader` script."""
        # Can an extension by specified by the EXTNAME keyword?
        hf = fitsheader.HeaderFormatter(self.data("zerowidth.fits"))
        output = hf.parse(extensions=["AIPS FQ"])
        assert "EXTNAME = 'AIPS FQ" in output
        assert "BITPIX" in output

        # Can we limit the display to one specific keyword?
        output = hf.parse(extensions=["AIPS FQ"], keywords=["EXTNAME"])
        assert "EXTNAME = 'AIPS FQ" in output
        assert "BITPIX  =" not in output
        assert len(output.split("\n")) == 3

        # Can we limit the display to two specific keywords?
        output = hf.parse(extensions=[1], keywords=["EXTNAME", "BITPIX"])
        assert "EXTNAME =" in output
        assert "BITPIX  =" in output
        assert len(output.split("\n")) == 4

        # Can we use wildcards for keywords?
        output = hf.parse(extensions=[1], keywords=["NAXIS*"])
        assert "NAXIS   =" in output
        assert "NAXIS1  =" in output
        assert "NAXIS2  =" in output
        hf.close()

        # Can an extension by specified by the EXTNAME+EXTVER keywords?
        hf = fitsheader.HeaderFormatter(self.data("test0.fits"))
        assert "EXTNAME = 'SCI" in hf.parse(extensions=["SCI,2"])
        hf.close()

        # Can we print the original header before decompression?
        hf = fitsheader.HeaderFormatter(self.data("comp.fits"))
        assert "XTENSION= 'IMAGE" in hf.parse(extensions=[1], compressed=False)
        assert "XTENSION= 'BINTABLE" in hf.parse(extensions=[1], compressed=True)
        hf.close()

    def test_fitsheader_compressed_from_primary_image_ext(self):
        """Regression test for issue https://github.com/astropy/astropy/issues/7312"""
        data = np.arange(2 * 2, dtype=np.int8).reshape((2, 2))
        phdu = fits.PrimaryHDU(data=data)
        chdu = fits.CompImageHDU(data=phdu.data, header=phdu.header)
        chdu.writeto(self.temp("tmp2.fits"), overwrite=True)
        with fits.open(self.temp("tmp2.fits")) as hdul:
            assert "XTENSION" not in hdul[1].header
            assert "PCOUNT" not in hdul[1].header
            assert "GCOUNT" not in hdul[1].header

    def test_fitsheader_table_feature(self):
        """Tests the `--table` feature of the `fitsheader` script."""
        test_filename = self.data("zerowidth.fits")

        formatter = fitsheader.TableHeaderFormatter(test_filename)

        with fits.open(test_filename) as fitsobj:
            # Does the table contain the expected number of rows?
            mytable = formatter.parse([0])
            assert len(mytable) == len(fitsobj[0].header)
            # Repeat the above test when multiple HDUs are requested
            mytable = formatter.parse(extensions=["AIPS FQ", 2, "4"])
            assert len(mytable) == (
                len(fitsobj["AIPS FQ"].header)
                + len(fitsobj[2].header)
                + len(fitsobj[4].header)
            )

        # Can we recover the filename and extension name from the table?
        mytable = formatter.parse(extensions=["AIPS FQ"])
        assert np.all(mytable["filename"] == test_filename)
        assert np.all(mytable["hdu"] == "AIPS FQ")
        assert mytable["value"][mytable["keyword"] == "EXTNAME"] == "AIPS FQ"

        # Can we specify a single extension/keyword?
        mytable = formatter.parse(extensions=["AIPS FQ"], keywords=["EXTNAME"])
        assert len(mytable) == 1
        assert mytable["hdu"][0] == "AIPS FQ"
        assert mytable["keyword"][0] == "EXTNAME"
        assert mytable["value"][0] == "AIPS FQ"

        # Is an incorrect extension dealt with gracefully?
        mytable = formatter.parse(extensions=["DOES_NOT_EXIST"])
        assert mytable is None
        # Is an incorrect keyword dealt with gracefully?
        mytable = formatter.parse(extensions=["AIPS FQ"], keywords=["DOES_NOT_EXIST"])
        assert mytable is None
        formatter.close()

    @pytest.mark.parametrize("mode", ["wb", "wb+", "ab", "ab+"])
    def test_hdu_writeto_mode(self, mode):
        with open(self.temp("mode.fits"), mode=mode) as ff:
            hdu = fits.ImageHDU(data=np.ones(5))
            hdu.writeto(ff)


def test_subclass():
    """Check that subclasses don't get ignored on slicing and copying."""

    class MyHeader(fits.Header):
        def append(self, card, *args, **kwargs):
            if isinstance(card, tuple) and len(card) == 2:
                # Just for our checks we add a comment if there is none.
                card += ("no comment",)

            return super().append(card, *args, **kwargs)

    my_header = MyHeader(
        (
            ("a", 1.0, "first"),
            ("b", 2.0, "second"),
            (
                "c",
                3.0,
            ),
        )
    )

    assert my_header.comments["a"] == "first"
    assert my_header.comments["b"] == "second"
    assert my_header.comments["c"] == "no comment"

    slice_ = my_header[1:]
    assert type(slice_) is MyHeader
    assert slice_.comments["b"] == "second"
    assert slice_.comments["c"] == "no comment"
    selection = my_header["c*"]
    assert type(selection) is MyHeader
    assert selection.comments["c"] == "no comment"
    copy_ = my_header.copy()
    assert type(copy_) is MyHeader
    assert copy_.comments["b"] == "second"
    assert copy_.comments["c"] == "no comment"
    my_header.extend((("d", 4.0),))
    assert my_header.comments["d"] == "no comment"
```

## 原始行 37 · command_execution

命令：
```
/bin/bash -lc 'grep -RInE "parse_tformat|parse_ascii|convert_fits2record|ColumnFormat|Invalid column format|ASCII_DEFAULT" astropy/io/fits/tests astropy/table/tests | head -500
grep -RIn "_has_data" astropy/io/fits/tests | head -100
grep -RIn "_header_str" astropy/io/fits/tests | head -100'
```

退出码：`0`

输出：
```
astropy/io/fits/tests/test_header.py:2353:    def test_header_strip_whitespace(self):
```

## 原始行 40 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=20'
```

退出码：`2`

输出：
```
Internet access disabled

==================================== ERRORS ====================================
____________ ERROR collecting astropy/io/fits/tests/test_header.py _____________
astropy/io/fits/tests/test_header.py:68: in <module>
    class TestHeaderFunctions(FitsTestCase):
astropy/io/fits/tests/test_header.py:1201: in TestHeaderFunctions
    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
                                         ^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1242: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:101: in __init__
    self._bzero = self._header.get("BZERO", 0)
                  ^^^^^^^^^^^^^^^^
E   AttributeError: 'Header' object has no attribute 'get'
____________ ERROR collecting astropy/io/fits/tests/test_header.py _____________
astropy/io/fits/tests/test_header.py:68: in <module>
    class TestHeaderFunctions(FitsTestCase):
astropy/io/fits/tests/test_header.py:1201: in TestHeaderFunctions
    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
                                         ^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1242: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:101: in __init__
    self._bzero = self._header.get("BZERO", 0)
                  ^^^^^^^^^^^^^^^^
E   AttributeError: 'Header' object has no attribute 'get'
=========================== short test summary info ============================
ERROR astropy/io/fits/tests/test_header.py - AttributeError: 'Header' object ...
ERROR astropy/io/fits/tests/test_header.py - AttributeError: 'Header' object ...
!!!!!!!!!!!!!!!!!!! Interrupted: 2 errors during collection !!!!!!!!!!!!!!!!!!!!
2 errors in 0.55s
```

## 原始行 44 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"A '.*' keyword already exists\\|Duplicate keyword\\|duplicate keyword\\|Invalid column format\\|Format .* is not recognized\\|ASCII table\" astropy/io/fits/tests | head -300
sed -n '1530,1650p' astropy/io/fits/tests/test_header.py
sed -n '3000,3160p' astropy/io/fits/tests/test_header.py
find astropy/io/fits/tests -maxdepth 1 -type f -name '*column*' -o -name '*table*'"
```

退出码：`0`

输出：
```
astropy/io/fits/tests/test_table.py:291:        # ASCII table
astropy/io/fits/tests/test_table.py:2533:        Blank values in numerical columns of ASCII tables should be replaced
astropy/io/fits/tests/test_table.py:2975:        Test correct integer dtypes according to ASCII table field widths.
astropy/io/fits/tests/test_table.py:3467:        # also valid common ASCII table formats
astropy/io/fits/tests/test_table.py:3507:        # table format, and is not strictly a valid ASCII table format but
astropy/io/fits/tests/test_table.py:3509:        # will only happen either when creating an ASCII table or when
astropy/io/fits/tests/test_table.py:3783:        Test the validation of the column start position option (ASCII table only),
astropy/io/fits/tests/data/ascii.fits:1:SIMPLE  =                    T / file does conform to FITS standard             BITPIX  =                   16 / number of bits per data pixel                  NAXIS   =                    0 / number of data axes                            EXTEND  =                    T / FITS dataset may contain extensions            COMMENT   FITS (Flexible Image Transport System) format defined in Astronomy andCOMMENT   Astrophysics Supplement Series v44/p363, v44/p371, v73/p359, v73/p365.COMMENT   Contact the NASA Science Office of Standards and Technology for the   COMMENT   FITS Definition document #100 and other FITS information.             END                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             XTENSION= 'TABLE   '           / ASCII table extension                          BITPIX  =                    8 / 8-bit ASCII characters                         NAXIS   =                    2 / 2-dimensional ASCII table                      NAXIS1  =                   16 / width of table in characters                   NAXIS2  =                    5                                                  PCOUNT  =                    0 / no group parameters (required keyword)         GCOUNT  =                    1 / one data group (required)                      TFIELDS =                    2                                                  TTYPE1  = 'a       '           / label for field   1                            TBCOL1  =                    1 / beginning column of field   1                  TFORM1  = 'E10.4   '           / Fortran-77 format of field                     TUNIT1  = 'pixels  '           / physical unit of field                         TTYPE2  = 'b       '           / label for field   2                            TBCOL2  =                   12 / beginning column of field   2                  TFORM2  = 'I5      '           / Fortran-77 format of field                     TUNIT2  = 'counts  '           / physical unit of field                         TNULL1  = '*       '           / string representing an undefined value         TNULL2  = '*       '           / string representing an undefined value         HISTORY   This FITS file was created by the FCREATE task.                       HISTORY   fcreate3.0d at 23/4/97 9:21:56.                                       END                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             .10123E+02    37.52000E+01    23.15610E+02    17*          *    .34500E+03   345                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
astropy/io/fits/tests/data/ascii_i4-i20.fits:1:SIMPLE  =                    T / conforms to FITS standard                      BITPIX  =                    8 / array data type                                NAXIS   =                    0 / number of array dimensions                     EXTEND  =                    T                                                  END                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                             XTENSION= 'TABLE   '           / ASCII table extension                          BITPIX  =                    8 / array data type                                NAXIS   =                    2 / number of array dimensions                     NAXIS1  =                   50 / length of dimension 1                          NAXIS2  =                    5 / length of dimension 2                          PCOUNT  =                    0 / number of group parameters                     GCOUNT  =                    1 / number of groups                               TFIELDS =                    5 / number of table fields                         TTYPE1  = 'col0    '                                                            TFORM1  = 'I8      '                                                            TBCOL1  =                    1                                                  TTYPE2  = 'col1    '                                                            TFORM2  = 'I8      '                                                            TBCOL2  =                    9                                                  TTYPE3  = 'col2    '                                                            TFORM3  = 'I10     '                                                            TBCOL3  =                   17                                                  TTYPE4  = 'col3    '                                                            TFORM4  = 'I20     '                                                            TBCOL4  =                   27                                                  TTYPE5  = 'col4    '                                                            TFORM5  = 'I4      '                                                            TBCOL5  =                   47                                                  END                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    8      16       256               65536 256 8388608167772162147483647 92233720368547758078192-4194304-8388608-536870912-9223372036854775808-512      10      20        30                  40  50 8388608167772162147483647 92233720368547758078192                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                      

        # New card should fill the first blank by default
        header.append(("E", "F"))
        assert len(header) == 4
        assert header[-2] == "F"
        assert header[-1] == ""

        # This card should not use up a blank spot
        header.append(("G", "H"), useblanks=False)
        assert len(header) == 5
        assert header[-1] == ""
        assert header[-2] == "H"

    def test_header_append_keyword_only(self):
        """
        Test appending a new card with just the keyword, and no value or
        comment given.
        """

        header = fits.Header([("A", "B"), ("C", "D")])
        header.append("E")
        assert len(header) == 3
        assert list(header)[-1] == "E"
        assert header[-1] is None
        assert header.comments["E"] == ""

        # Try appending a blank--normally this can be accomplished with just
        # header.append(), but header.append('') should also work (and is maybe
        # a little more clear)
        header.append("")
        assert len(header) == 4

        assert list(header)[-1] == ""
        assert header[""] == ""
        assert header.comments[""] == ""

    def test_header_insert_use_blanks(self):
        header = fits.Header([("A", "B"), ("C", "D")])

        # Append a couple blanks
        header.append()
        header.append()

        # Insert a new card; should use up one of the blanks
        header.insert(1, ("E", "F"))
        assert len(header) == 4
        assert header[1] == "F"
        assert header[-1] == ""
        assert header[-2] == "D"

        # Insert a new card without using blanks
        header.insert(1, ("G", "H"), useblanks=False)
        assert len(header) == 5
        assert header[1] == "H"
        assert header[-1] == ""

    def test_header_insert_before_keyword(self):
        """
        Test that a keyword name or tuple can be used to insert new keywords.

        Also tests the ``after`` keyword argument.

        Regression test for https://github.com/spacetelescope/PyFITS/issues/12
        """

        header = fits.Header(
            [("NAXIS1", 10), ("COMMENT", "Comment 1"), ("COMMENT", "Comment 3")]
        )

        header.insert("NAXIS1", ("NAXIS", 2, "Number of axes"))
        assert list(header.keys())[0] == "NAXIS"
        assert header[0] == 2
        assert header.comments[0] == "Number of axes"

        header.insert("NAXIS1", ("NAXIS2", 20), after=True)
        assert list(header.keys())[1] == "NAXIS1"
        assert list(header.keys())[2] == "NAXIS2"
        assert header[2] == 20

        header.insert(("COMMENT", 1), ("COMMENT", "Comment 2"))
        assert header["COMMENT"] == ["Comment 1", "Comment 2", "Comment 3"]

        header.insert(("COMMENT", 2), ("COMMENT", "Comment 4"), after=True)
        assert header["COMMENT"] == ["Comment 1", "Comment 2", "Comment 3", "Comment 4"]

        header.insert(-1, ("TEST1", True))
        assert list(header.keys())[-2] == "TEST1"

        header.insert(-1, ("TEST2", True), after=True)
        assert list(header.keys())[-1] == "TEST2"
        assert list(header.keys())[-3] == "TEST1"

    def test_remove(self):
        header = fits.Header([("A", "B"), ("C", "D")])

        # When keyword is present in the header it should be removed.
        header.remove("C")
        assert len(header) == 1
        assert list(header) == ["A"]
        assert "C" not in header

        # When keyword is not present in the header and ignore_missing is
        # False, KeyError should be raised
        with pytest.raises(KeyError):
            header.remove("F")

        # When keyword is not present and ignore_missing is True, KeyError
        # will be ignored
        header.remove("F", ignore_missing=True)
        assert len(header) == 1

        # Test for removing all instances of a keyword
        header = fits.Header([("A", "B"), ("C", "D"), ("A", "F")])
        header.remove("A", remove_all=True)
        assert "A" not in header
        assert len(header) == 1
        assert list(header) == ["C"]
        assert header[0] == "D"

    def test_header_comments(self):
        header = fits.Header([("A", "B", "C"), ("DEF", "G", "H")])
            "DP1     = 'NAUX: 2'",
        ]

        cl = self._test_header["DP1.AUX..."]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

        cl = self._test_header["DP?.NAXIS"]
        assert [str(c).strip() for c in cl.cards] == ["DP1     = 'NAXIS: 2'"]

        cl = self._test_header["DP1.A*S.*"]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AXIS.1: 1'",
            "DP1     = 'AXIS.2: 2'",
        ]

    def test_pattern_matching_key_deletion(self):
        """Deletion by filter strings should work."""

        del self._test_header["DP1.A*..."]
        assert len(self._test_header) == 2
        assert list(self._test_header)[0] == "DP1.NAXIS"
        assert self._test_header[0] == 2
        assert list(self._test_header)[1] == "DP1.NAUX"
        assert self._test_header[1] == 2

    def test_successive_pattern_matching(self):
        """
        A card list returned via a filter string should be further filterable.
        """

        cl = self._test_header["DP1.A*..."]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AXIS.1: 1'",
            "DP1     = 'AXIS.2: 2'",
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

        cl2 = cl["*.*AUX..."]
        assert [str(c).strip() for c in cl2.cards] == [
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

    def test_rvkc_in_cardlist_keys(self):
        """
        The CardList.keys() method should return full keyword/field-spec values
        for RVKCs.
        """

        cl = self._test_header["DP1.AXIS.*"]
        assert list(cl) == ["DP1.AXIS.1", "DP1.AXIS.2"]

    def test_rvkc_in_cardlist_values(self):
        """
        The CardList.values() method should return the values of all RVKCs as
        floating point values.
        """

        cl = self._test_header["DP1.AXIS.*"]
        assert list(cl.values()) == [1.0, 2.0]

    def test_rvkc_value_attribute(self):
        """
        Individual card values should be accessible by the .value attribute
        (which should return a float).
        """

        cl = self._test_header["DP1.AXIS.*"]
        assert cl.cards[0].value == 1.0
        assert isinstance(cl.cards[0].value, float)

    def test_overly_permissive_parsing(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/183

        Ensures that cards with standard commentary keywords are never treated
        as RVKCs.  Also ensures that cards not strictly matching the RVKC
        pattern are not treated as such.
        """

        h = fits.Header()
        h["HISTORY"] = "AXIS.1: 2"
        h["HISTORY"] = "AXIS.2: 2"
        assert "HISTORY.AXIS" not in h
        assert "HISTORY.AXIS.1" not in h
        assert "HISTORY.AXIS.2" not in h
        assert h["HISTORY"] == ["AXIS.1: 2", "AXIS.2: 2"]

        # This is an example straight out of the ticket where everything after
        # the '2012' in the date value was being ignored, allowing the value to
        # successfully be parsed as a "float"
        h = fits.Header()
        h["HISTORY"] = "Date: 2012-09-19T13:58:53.756061"
        assert "HISTORY.Date" not in h
        assert str(h.cards[0]) == _pad("HISTORY Date: 2012-09-19T13:58:53.756061")

        c = fits.Card.fromstring("        'Date: 2012-09-19T13:58:53.756061'")
        assert c.keyword == ""
        assert c.value == "'Date: 2012-09-19T13:58:53.756061'"
        assert c.field_specifier is None

        h = fits.Header()
        h["FOO"] = "Date: 2012-09-19T13:58:53.756061"
        assert "FOO.Date" not in h
        assert str(h.cards[0]) == _pad("FOO     = 'Date: 2012-09-19T13:58:53.756061'")

    def test_overly_aggressive_rvkc_lookup(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/184

        Ensures that looking up a RVKC by keyword only (without the
        field-specifier) in a header returns the full string value of that card
        without parsing it as a RVKC.  Also ensures that a full field-specifier
        is required to match a RVKC--a partial field-specifier that doesn't
        explicitly match any record-valued keyword should result in a KeyError.
        """

        c1 = fits.Card.fromstring("FOO     = 'AXIS.1: 2'")
        c2 = fits.Card.fromstring("FOO     = 'AXIS.2: 4'")
        h = fits.Header([c1, c2])
        assert h["FOO"] == "AXIS.1: 2"
        assert h[("FOO", 1)] == "AXIS.2: 4"
        assert h["FOO.AXIS.1"] == 2.0
        assert h["FOO.AXIS.2"] == 4.0
        assert "FOO.AXIS" not in h
        assert "FOO.AXIS." not in h
        assert "FOO." not in h
        pytest.raises(KeyError, lambda: h["FOO.AXIS"])
        pytest.raises(KeyError, lambda: h["FOO.AXIS."])
        pytest.raises(KeyError, lambda: h["FOO."])

    def test_fitsheader_script(self):
        """Tests the basic functionality of the `fitsheader` script."""
        # Can an extension by specified by the EXTNAME keyword?
        hf = fitsheader.HeaderFormatter(self.data("zerowidth.fits"))
        output = hf.parse(extensions=["AIPS FQ"])
        assert "EXTNAME = 'AIPS FQ" in output
        assert "BITPIX" in output

        # Can we limit the display to one specific keyword?
        output = hf.parse(extensions=["AIPS FQ"], keywords=["EXTNAME"])
        assert "EXTNAME = 'AIPS FQ" in output
        assert "BITPIX  =" not in output
        assert len(output.split("\n")) == 3

        # Can we limit the display to two specific keywords?
        output = hf.parse(extensions=[1], keywords=["EXTNAME", "BITPIX"])
        assert "EXTNAME =" in output
        assert "BITPIX  =" in output
        assert len(output.split("\n")) == 4

astropy/io/fits/tests/test_table.py
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "sed -n '3400,3540p' astropy/io/fits/tests/test_table.py
sed -n '2940,3015p' astropy/io/fits/tests/test_table.py
grep -RIn \"Invalid column format\\|Illegal format\\|strict=True\\|format.*width\\|precision.*width\\|TFORM\" astropy/io/fits/tests/test_table.py | tail -100"
```

退出码：`0`

输出：
```
        with fits.open(filename) as hdul:
            hdu = hdul[1]
            arr = hdu.data[:1]["var"]
            assert arr.tolist() == [[45, 56]]
            assert arr[0].dtype == np.int16

    def test_vla_slice2(self):
        filename = self.data("theap-gap.fits")

        # slicing the VLA array
        with fits.open(filename) as hdul:
            hdu = hdul[1]
            arr = hdu.data["arr"][:3]
            assert arr.tolist() == [[], [0], [0, 1]]
            assert arr[1].dtype == np.int32

        # slicing .data
        with fits.open(filename) as hdul:
            hdu = hdul[1]
            arr = hdu.data[:3]["arr"]
            assert arr.tolist() == [[], [0], [0, 1]]
            assert arr[1].dtype == np.int32

    def test_vla_update(self):
        """Check that heap is correctly updated after a VLA is modified.

        Regression test for https://github.com/astropy/astropy/issues/18479

        """
        filename = self.data("variable_length_table.fits")
        with fits.open(filename) as hdul:
            for _v in hdul[1].data["var"]:
                _v[:] = 0
            hdul.writeto(self.temp("test.fits"), checksum=True)

        with fits.open(self.temp("test.fits"), checksum=True) as hdul:
            np.testing.assert_array_equal(hdul[1].data["var"][0], 0)
            np.testing.assert_array_equal(hdul[1].data["var"][1], 0)
            assert hdul[1].header["DATASUM"] == "1507344"


# These are tests that solely test the Column and ColDefs interfaces and
# related functionality without directly involving full tables; currently there
# are few of these but I expect there to be more as I improve the test coverage
class TestColumnFunctions(FitsTestCase):
    def test_column_format_interpretation(self):
        """
        Test to ensure that when Numpy-style record formats are passed in to
        the Column constructor for the format argument, they are recognized so
        long as it's unambiguous (where "unambiguous" here is questionable
        since Numpy is case insensitive when parsing the format codes.  But
        their "proper" case is lower-case, so we can accept that.  Basically,
        actually, any key in the NUMPY2FITS dict should be accepted.
        """

        for recformat, fitsformat in NUMPY2FITS.items():
            if recformat == "S":
                fitsformat = "0A"
            c = fits.Column("TEST", np.dtype(recformat))
            assert c.format == fitsformat
            c = fits.Column("TEST", recformat)
            assert c.format == fitsformat
            c = fits.Column("TEST", fitsformat)
            assert c.format == fitsformat

        # Test a few cases that are ambiguous in that they *are* valid binary
        # table formats though not ones that are likely to be used, but are
        # also valid common ASCII table formats
        c = fits.Column("TEST", "I4")
        assert c.format == "I4"
        assert c.format.format == "I"
        assert c.format.width == 4

        c = fits.Column("TEST", "F15.8")
        assert c.format == "F15.8"
        assert c.format.format == "F"
        assert c.format.width == 15
        assert c.format.precision == 8

        c = fits.Column("TEST", "E15.8")
        assert c.format.format == "E"
        assert c.format.width == 15
        assert c.format.precision == 8

        c = fits.Column("TEST", "D15.8")
        assert c.format.format == "D"
        assert c.format.width == 15
        assert c.format.precision == 8

        # zero-precision should be allowed as well, for float types
        # https://github.com/astropy/astropy/issues/3422
        c = fits.Column("TEST", "F10.0")
        assert c.format.format == "F"
        assert c.format.width == 10
        assert c.format.precision == 0

        c = fits.Column("TEST", "E10.0")
        assert c.format.format == "E"
        assert c.format.width == 10
        assert c.format.precision == 0

        c = fits.Column("TEST", "D10.0")
        assert c.format.format == "D"
        assert c.format.width == 10
        assert c.format.precision == 0

        # These are a couple cases where the format code is a valid binary
        # table format, and is not strictly a valid ASCII table format but
        # could be *interpreted* as one by appending a default width.  This
        # will only happen either when creating an ASCII table or when
        # explicitly specifying ascii=True when the column is created
        c = fits.Column("TEST", "I")
        assert c.format == "I"
        assert c.format.recformat == "i2"
        c = fits.Column("TEST", "I", ascii=True)
        assert c.format == "I10"
        assert c.format.recformat == "i4"

        # With specified widths, integer precision should be set appropriately
        c = fits.Column("TEST", "I4", ascii=True)
        assert c.format == "I4"
        assert c.format.recformat == "i2"
        c = fits.Column("TEST", "I9", ascii=True)
        assert c.format == "I9"
        assert c.format.recformat == "i4"
        c = fits.Column("TEST", "I12", ascii=True)
        assert c.format == "I12"
        assert c.format.recformat == "i8"

        c = fits.Column("TEST", "E")
        assert c.format == "E"
        assert c.format.recformat == "f4"
        c = fits.Column("TEST", "E", ascii=True)
        assert c.format == "E15.7"

        # F is not a valid binary table format so it should be unambiguously
        # treated as an ASCII column
        c = fits.Column("TEST", "F")
        assert c.format == "F16.7"

        c = fits.Column("TEST", "D")
            assert hdu.data["A"].dtype == np.dtype("uint32")
            assert np.all(hdu.data["A"] == [99, 2, 3])

    def test_column_with_scaling(self):
        """Check that a scaled column if correctly saved once it is modified.
        Regression test for https://github.com/astropy/astropy/issues/6887
        """
        c1 = fits.Column(
            name="c1",
            array=np.array([1], dtype=">i2"),
            format="1I",
            bscale=1,
            bzero=32768,
        )
        S = fits.HDUList([fits.PrimaryHDU(), fits.BinTableHDU.from_columns([c1])])

        # Change value in memory
        S[1].data["c1"][0] = 2
        S.writeto(self.temp("a.fits"))
        assert S[1].data["c1"] == 2

        # Read and change value in memory
        with fits.open(self.temp("a.fits")) as X:
            X[1].data["c1"][0] = 10
            assert X[1].data["c1"][0] == 10

            # Write back to file
            X.writeto(self.temp("b.fits"))

        # Now check the file
        with fits.open(self.temp("b.fits")) as hdul:
            assert hdul[1].data["c1"][0] == 10

    def test_ascii_inttypes(self):
        """
        Test correct integer dtypes according to ASCII table field widths.
        Regression for https://github.com/astropy/astropy/issues/9899
        """
        i08 = np.array([2**3, 2**23, -(2**22), 10, 2**23], dtype="i4")
        i10 = np.array([2**8, 2**31 - 1, -(2**29), 30, 2**31 - 1], dtype="i8")
        i20 = np.array([2**16, 2**63 - 1, -(2**63), 40, 2**63 - 1], dtype="i8")
        i02 = np.array([2**8, 2**13, -(2**9), 50, 2**13], dtype="i2")
        t0 = Table([i08, i08 * 2, i10, i20, i02])

        t1 = Table.read(self.data("ascii_i4-i20.fits"))
        assert t1.dtype == t0.dtype
        assert comparerecords(t1, t0)

    def test_ascii_floattypes(self):
        """Test different float formats."""
        col1 = fits.Column(
            name="a", format="D", array=np.array([11.1, 12.2]), ascii=True
        )
        col2 = fits.Column(
            name="b", format="D16", array=np.array([15.5, 16.6]), ascii=True
        )
        col3 = fits.Column(
            name="c", format="D16.7", array=np.array([1.1, 2.2]), ascii=True
        )
        hdu = fits.TableHDU.from_columns([col1, col2, col3])
        hdu.writeto(self.temp("foo.fits"))

        with fits.open(self.temp("foo.fits"), memmap=False) as hdul:
            assert comparerecords(hdul[1].data, hdu.data)


@contextlib.contextmanager
def _refcounting(type_):
    """
    Perform the body of a with statement with reference counting for the
    given type (given by class name)--raises an assertion error if there
    are more unfreed objects of the given type than when we entered the
    with statement.
    """

    gc.collect()
350:        # Test Integer precision according to width
2140:        but TFORM1 = 6I), then instead of this being an outright error we are
2171:            assert tbhdu2.header["TFORM1"] == "12A"
2237:        must be less than or equal to the repeat count in the TFORMn keyword.
2257:            assert h[1].header["TFORM1"] == "20I"
2258:            assert h[1].header["TFORM2"] == "4I"
2515:            h[1].header["TFORM1"] = "E3"
3180:            assert h[1].header["TFORM2"] == "PJ(255)"
3181:            assert h[2].header["TFORM2"] == "PJ(255)"
3471:        assert c.format.width == 4
3476:        assert c.format.width == 15
3481:        assert c.format.width == 15
3486:        assert c.format.width == 15
3493:        assert c.format.width == 10
3498:        assert c.format.width == 10
3503:        assert c.format.width == 10
3557:            assert hdul[1].header["TFORM1"] == "F5.0"
3766:            "TFORM",
3810:            {"TFORM": "Z", "TDISP": "E"},
3811:            {"TFORM": "2", "TDISP": "2E"},
3812:            {"TFORM": 3, "TDISP": 6.3},
3813:            {"TFORM": float, "TDISP": np.float64},
3814:            {"TFORM": "", "TDISP": "E.5"},
3819:        Additional tests for verification of 'TFORM' and 'TDISP' keyword
3823:            _ = fits.Column("col", format=keys["TFORM"], disp=keys["TDISP"])
```

## 原始行 49 · command_execution

命令：
```
/bin/bash -lc "sed -n '3460,3590p' astropy/io/fits/tests/test_table.py
sed -n '3730,3850p' astropy/io/fits/tests/test_table.py
sed -n '300,370p' astropy/io/fits/tests/test_table.py"
```

退出码：`0`

输出：
```
            c = fits.Column("TEST", recformat)
            assert c.format == fitsformat
            c = fits.Column("TEST", fitsformat)
            assert c.format == fitsformat

        # Test a few cases that are ambiguous in that they *are* valid binary
        # table formats though not ones that are likely to be used, but are
        # also valid common ASCII table formats
        c = fits.Column("TEST", "I4")
        assert c.format == "I4"
        assert c.format.format == "I"
        assert c.format.width == 4

        c = fits.Column("TEST", "F15.8")
        assert c.format == "F15.8"
        assert c.format.format == "F"
        assert c.format.width == 15
        assert c.format.precision == 8

        c = fits.Column("TEST", "E15.8")
        assert c.format.format == "E"
        assert c.format.width == 15
        assert c.format.precision == 8

        c = fits.Column("TEST", "D15.8")
        assert c.format.format == "D"
        assert c.format.width == 15
        assert c.format.precision == 8

        # zero-precision should be allowed as well, for float types
        # https://github.com/astropy/astropy/issues/3422
        c = fits.Column("TEST", "F10.0")
        assert c.format.format == "F"
        assert c.format.width == 10
        assert c.format.precision == 0

        c = fits.Column("TEST", "E10.0")
        assert c.format.format == "E"
        assert c.format.width == 10
        assert c.format.precision == 0

        c = fits.Column("TEST", "D10.0")
        assert c.format.format == "D"
        assert c.format.width == 10
        assert c.format.precision == 0

        # These are a couple cases where the format code is a valid binary
        # table format, and is not strictly a valid ASCII table format but
        # could be *interpreted* as one by appending a default width.  This
        # will only happen either when creating an ASCII table or when
        # explicitly specifying ascii=True when the column is created
        c = fits.Column("TEST", "I")
        assert c.format == "I"
        assert c.format.recformat == "i2"
        c = fits.Column("TEST", "I", ascii=True)
        assert c.format == "I10"
        assert c.format.recformat == "i4"

        # With specified widths, integer precision should be set appropriately
        c = fits.Column("TEST", "I4", ascii=True)
        assert c.format == "I4"
        assert c.format.recformat == "i2"
        c = fits.Column("TEST", "I9", ascii=True)
        assert c.format == "I9"
        assert c.format.recformat == "i4"
        c = fits.Column("TEST", "I12", ascii=True)
        assert c.format == "I12"
        assert c.format.recformat == "i8"

        c = fits.Column("TEST", "E")
        assert c.format == "E"
        assert c.format.recformat == "f4"
        c = fits.Column("TEST", "E", ascii=True)
        assert c.format == "E15.7"

        # F is not a valid binary table format so it should be unambiguously
        # treated as an ASCII column
        c = fits.Column("TEST", "F")
        assert c.format == "F16.7"

        c = fits.Column("TEST", "D")
        assert c.format == "D"
        assert c.format.recformat == "f8"
        c = fits.Column("TEST", "D", ascii=True)
        assert c.format == "D25.17"

    def test_zero_precision_float_column(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/3422
        """

        c = fits.Column("TEST", "F5.0", array=[1.1, 2.2, 3.3])
        # The decimal places will be clipped
        t = fits.TableHDU.from_columns([c])
        t.writeto(self.temp("test.fits"))

        with fits.open(self.temp("test.fits")) as hdul:
            assert hdul[1].header["TFORM1"] == "F5.0"
            assert hdul[1].data["TEST"].dtype == np.dtype("float64")
            assert np.all(hdul[1].data["TEST"] == [1.0, 2.0, 3.0])

            # Check how the raw data looks
            raw = np.rec.recarray.field(hdul[1].data, "TEST")
            assert raw.tobytes() == b"   1.   2.   3."

    def test_column_array_type_mismatch(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/218"""

        arr = [-99] * 20
        col = fits.Column("mag", format="E", array=arr)
        assert (arr == col.array).all()

    def test_new_coldefs_with_invalid_seqence(self):
        """Test that a TypeError is raised when a ColDefs is instantiated with
        a sequence of non-Column objects.
        """

        pytest.raises(TypeError, fits.ColDefs, [1, 2, 3])

    def test_coldefs_init_from_array(self):
        """Test that ColDefs._init_from_array works with single element data-
        types as well as multi-element data-types
        """
        nd_array = np.ndarray((1,), dtype=[("A", "<u4", (2,)), ("B", ">u2")])
        col_defs = fits.column.ColDefs(nd_array)
        assert 2**31 == col_defs["A"].bzero
        assert 2**15 == col_defs["B"].bzero

    def test_pickle(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/1597
        assert np.all(c2.array[0] == c.array[0])
        assert np.all(c2.array[1] == c.array[1])

        c3 = fits.Column("qcol", format="QJ", array=[[1, 2], [3, 4, 5]])
        c4 = copy.deepcopy(c3)
        assert c4.name == c3.name
        assert c4.format == c3.format
        assert np.all(c4.array[0] == c3.array[0])
        assert np.all(c4.array[1] == c3.array[1])

    def test_column_verify_keywords(self):
        """
        Test that the keyword arguments used to initialize a Column, specifically
        those that typically read from a FITS header (so excluding array),
        are verified to have a valid value.
        """

        with pytest.raises(AssertionError) as err:
            _ = fits.Column(1, format="I", array=[1, 2, 3, 4, 5])
        assert "Column name must be a string able to fit" in str(err.value)

        with pytest.raises(VerifyError) as err:
            _ = fits.Column(
                "col",
                format=0,
                null="Nan",
                disp=1,
                coord_type=1,
                coord_unit=2,
                coord_inc="1",
                time_ref_pos=1,
                coord_ref_point="1",
                coord_ref_value="1",
            )
        err_msgs = [
            "keyword arguments to Column were invalid",
            "TFORM",
            "TNULL",
            "TDISP",
            "TCTYP",
            "TCUNI",
            "TCRPX",
            "TCRVL",
            "TCDLT",
            "TRPOS",
        ]
        for msg in err_msgs:
            assert msg in str(err.value)

    def test_column_verify_start(self):
        """
        Regression test for https://github.com/astropy/astropy/pull/6359

        Test the validation of the column start position option (ASCII table only),
        corresponding to ``TBCOL`` keyword.
        Test whether the VerifyError message generated is the one with highest priority,
        i.e. the order of error messages to be displayed is maintained.
        """

        with pytest.raises(VerifyError) as err:
            _ = fits.Column("a", format="B", start="a", array=[1, 2, 3])
        assert "start option (TBCOLn) is not allowed for binary table columns" in str(
            err.value
        )

        with pytest.raises(VerifyError) as err:
            _ = fits.Column("a", format="I", start="a", array=[1, 2, 3])
        assert "start option (TBCOLn) must be a positive integer (got 'a')." in str(
            err.value
        )

        with pytest.raises(VerifyError) as err:
            _ = fits.Column("a", format="I", start="-56", array=[1, 2, 3])
        assert "start option (TBCOLn) must be a positive integer (got -56)." in str(
            err.value
        )

    @pytest.mark.parametrize(
        "keys",
        [
            {"TFORM": "Z", "TDISP": "E"},
            {"TFORM": "2", "TDISP": "2E"},
            {"TFORM": 3, "TDISP": 6.3},
            {"TFORM": float, "TDISP": np.float64},
            {"TFORM": "", "TDISP": "E.5"},
        ],
    )
    def test_column_verify_formats(self, keys):
        """
        Additional tests for verification of 'TFORM' and 'TDISP' keyword
        arguments used to initialize a Column.
        """
        with pytest.raises(VerifyError) as err:
            _ = fits.Column("col", format=keys["TFORM"], disp=keys["TDISP"])

        for key in keys.keys():
            assert key in str(err.value)
            assert str(keys[key]) in str(err.value)


def test_regression_5383():
    # Regression test for an undefined variable

    x = np.array([1, 2, 3])
    col = fits.Column(name="a", array=x, format="E")
    hdu = fits.BinTableHDU.from_columns([col])
    del hdu._header["TTYPE1"]
    hdu.columns[0].name = "b"


def test_table_to_hdu():
    table = Table(
        [[1, 2, 3], ["a", "b", "c"], [2.3, 4.5, 6.7]],
        names=["a", "b", "c"],
        dtype=["i", "U1", "f"],
    )
    table["a"].unit = "m/s"
    table["b"].unit = "not-a-unit"
    table.meta["foo"] = "bar"

    with pytest.warns(
            ],
            names="c1, c2",
        )
        assert comparerecords(a[1].data, ra1)

        # Test slicing
        a2 = a[1].data[2:][2:]
        ra2 = np.rec.array([(345.0, 345)], names="c1, c2")

        assert comparerecords(a2, ra2)

        assert (a2.field(1) == np.array([345])).all()

        ra3 = np.rec.array(
            [(10.123000144958496, 37), (15.609999656677246, 17), (345.0, 345)],
            names="c1, c2",
        )

        assert comparerecords(a[1].data[::2], ra3)

        # Test Start Column

        a1 = chararray.array(["abcd", "def"])
        r1 = np.array([11.0, 12.0])
        c1 = fits.Column(name="abc", format="A3", start=19, array=a1)
        c2 = fits.Column(name="def", format="E", start=3, array=r1)
        c3 = fits.Column(name="t1", format="I", array=[91, 92, 93])
        hdu = fits.TableHDU.from_columns([c2, c1, c3])

        assert dict(hdu.data.dtype.fields) == {
            "abc": (np.dtype("|S3"), 18),
            "def": (np.dtype("|S15"), 2),
            "t1": (np.dtype("|S10"), 21),
        }
        hdu.writeto(self.temp("toto.fits"), overwrite=True)
        hdul = fits.open(self.temp("toto.fits"))
        assert comparerecords(hdu.data, hdul[1].data)
        hdul.close()

        # Test Scaling

        r1 = np.array([11.0, 12.0])
        c2 = fits.Column(name="def", format="D", array=r1, bscale=2.3, bzero=0.6)
        hdu = fits.TableHDU.from_columns([c2])
        hdu.writeto(self.temp("toto.fits"), overwrite=True)
        with open(self.temp("toto.fits")) as f:
            assert "4.95652173913043548D+00" in f.read()
        with fits.open(self.temp("toto.fits")) as hdul:
            assert comparerecords(hdu.data, hdul[1].data)

        # Test Integer precision according to width

        c1 = fits.Column(name="t2", format="I2", array=[91, 92, 93])
        c2 = fits.Column(name="t4", format="I5", array=[91, 92, 93])
        c3 = fits.Column(name="t8", format="I10", array=[91, 92, 93])
        hdu = fits.TableHDU.from_columns([c1, c2, c3])

        assert c1.array.dtype == np.int16
        assert c2.array.dtype == np.int32
        assert c3.array.dtype == np.int64
        hdu.writeto(self.temp("toto.fits"), overwrite=True)
        with fits.open(self.temp("toto.fits")) as hdul:
            assert comparerecords(hdu.data, hdul[1].data)

        a.close()

    def test_endianness(self):
        x = np.ndarray((1,), dtype=object)
        channelsIn = np.array([3], dtype="uint8")
        x[0] = channelsIn
        col = fits.Column(name="Channels", format="PB()", array=x)
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc "sed -n '510,850p' astropy/io/fits/column.py
sed -n '2430,2475p' astropy/io/fits/column.py
sed -n '2280,2385p' astropy/io/fits/column.py | sed -n '/["'^[:space:]]/p'"'"
```

退出码：`0`

输出：
```
    The setter for `ColumnAttribute` also updates the header of any table
    HDU this column is attached to in order to reflect the change.  The
    ``validator`` should ensure that the value is valid for inclusion in a FITS
    header.
    """

    def __init__(self, keyword):
        self._keyword = keyword
        self._validator = None

        # The name of the attribute associated with this keyword is currently
        # determined from the KEYWORD_NAMES/ATTRIBUTES lists.  This could be
        # make more flexible in the future, for example, to support custom
        # column attributes.
        self._attr = "_" + KEYWORD_TO_ATTRIBUTE[self._keyword]

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        else:
            return getattr(obj, self._attr)

    def __set__(self, obj, value):
        if self._validator is not None:
            self._validator(obj, value)

        old_value = getattr(obj, self._attr, None)
        setattr(obj, self._attr, value)
        obj._notify("column_attribute_changed", obj, self._attr[1:], old_value, value)

    def __call__(self, func):
        """
        Set the validator for this column attribute.

        Returns ``self`` so that this can be used as a decorator, as described
        in the docs for this class.
        """
        self._validator = func

        return self

    def __repr__(self):
        return f"{self.__class__.__name__}('{self._keyword}')"


class Column(NotifierMixin):
    """
    Class which contains the definition of one column, e.g.  ``ttype``,
    ``tform``, etc. and the array containing values for the column.
    """

    def __init__(
        self,
        name=None,
        format=None,
        unit=None,
        null=None,
        bscale=None,
        bzero=None,
        disp=None,
        start=None,
        dim=None,
        array=None,
        ascii=None,
        coord_type=None,
        coord_unit=None,
        coord_ref_point=None,
        coord_ref_value=None,
        coord_inc=None,
        time_ref_pos=None,
    ):
        """
        Construct a `Column` by specifying attributes.  All attributes
        except ``format`` can be optional; see :ref:`astropy:column_creation`
        and :ref:`astropy:creating_ascii_table` for more information regarding
        ``TFORM`` keyword.

        Parameters
        ----------
        name : str, optional
            column name, corresponding to ``TTYPE`` keyword

        format : str
            column format, corresponding to ``TFORM`` keyword

        unit : str, optional
            column unit, corresponding to ``TUNIT`` keyword

        null : str, optional
            null value, corresponding to ``TNULL`` keyword

        bscale : int-like, optional
            bscale value, corresponding to ``TSCAL`` keyword

        bzero : int-like, optional
            bzero value, corresponding to ``TZERO`` keyword

        disp : str, optional
            display format, corresponding to ``TDISP`` keyword

        start : int, optional
            column starting position (ASCII table only), corresponding
            to ``TBCOL`` keyword

        dim : str, optional
            column dimension corresponding to ``TDIM`` keyword

        array : iterable, optional
            a `list`, `numpy.ndarray` (or other iterable that can be used to
            initialize an ndarray) providing initial data for this column.
            The array will be automatically converted, if possible, to the data
            format of the column.  In the case were non-trivial ``bscale``
            and/or ``bzero`` arguments are given, the values in the array must
            be the *physical* values--that is, the values of column as if the
            scaling has already been applied (the array stored on the column
            object will then be converted back to its storage values).

        ascii : bool, optional
            set `True` if this describes a column for an ASCII table; this
            may be required to disambiguate the column format

        coord_type : str, optional
            coordinate/axis type corresponding to ``TCTYP`` keyword

        coord_unit : str, optional
            coordinate/axis unit corresponding to ``TCUNI`` keyword

        coord_ref_point : int-like, optional
            pixel coordinate of the reference point corresponding to ``TCRPX``
            keyword

        coord_ref_value : int-like, optional
            coordinate value at reference point corresponding to ``TCRVL``
            keyword

        coord_inc : int-like, optional
            coordinate increment at reference point corresponding to ``TCDLT``
            keyword

        time_ref_pos : str, optional
            reference position for a time coordinate column corresponding to
            ``TRPOS`` keyword
        """
        if format is None:
            raise ValueError("Must specify format to construct Column.")

        # any of the input argument (except array) can be a Card or just
        # a number/string
        kwargs = {"ascii": ascii}
        for attr in KEYWORD_ATTRIBUTES:
            value = locals()[attr]  # get the argument's value

            if isinstance(value, Card):
                value = value.value

            kwargs[attr] = value

        valid_kwargs, invalid_kwargs = self._verify_keywords(**kwargs)

        if invalid_kwargs:
            msg = ["The following keyword arguments to Column were invalid:"]

            for val in invalid_kwargs.values():
                msg.append(indent(val[1], 4 * " "))

            raise VerifyError("\n".join(msg))

        for attr in KEYWORD_ATTRIBUTES:
            setattr(self, attr, valid_kwargs.get(attr))

        # TODO: Try to eliminate the following two special cases
        # for recformat and dim:
        # This is not actually stored as an attribute on columns for some
        # reason
        recformat = valid_kwargs["recformat"]

        # The 'dim' keyword's original value is stored in self.dim, while
        # *only* the tuple form is stored in self._dims.
        self._dims = self.dim
        self.dim = dim

        # Awful hack to use for now to keep track of whether the column holds
        # pseudo-unsigned int data
        self._pseudo_unsigned_ints = False

        # if the column data is not ndarray, make it to be one, i.e.
        # input arrays can be just list or tuple, not required to be ndarray
        # does not include Object array because there is no guarantee
        # the elements in the object array are consistent.
        if not isinstance(array, (np.ndarray, chararray.chararray, Delayed)):
            try:  # try to convert to a ndarray first
                if array is not None:
                    array = np.array(array)
            except Exception:
                try:  # then try to convert it to a strings array
                    itemsize = int(recformat[1:])
                    array = chararray.array(array, itemsize=itemsize)
                except ValueError:
                    # then try variable length array
                    # Note: This includes _FormatQ by inheritance
                    if isinstance(recformat, _FormatP):
                        array = _VLF(array, dtype=recformat.dtype)
                    else:
                        raise ValueError(
                            f"Data is inconsistent with the format `{format}`."
                        )

        array = self._convert_to_valid_data_type(array)

        # We have required (through documentation) that arrays passed in to
        # this constructor are already in their physical values, so we make
        # note of that here
        if isinstance(array, np.ndarray):
            self._physical_values = True
        else:
            self._physical_values = False

        self._parent_fits_rec = None
        self.array = array

    def __repr__(self):
        text = ""
        for attr in KEYWORD_ATTRIBUTES:
            value = getattr(self, attr)
            if value is not None:
                text += attr + " = " + repr(value) + "; "
        return text[:-2]

    def __eq__(self, other):
        """
        Two columns are equal if their name and format are the same.  Other
        attributes aren't taken into account at this time.
        """
        # According to the FITS standard column names must be case-insensitive
        a = (self.name.lower(), self.format)
        b = (other.name.lower(), other.format)
        return a == b

    def __hash__(self):
        """
        Like __eq__, the hash of a column should be based on the unique column
        name and format, and be case-insensitive with respect to the column
        name.
        """
        return hash((self.name.lower(), self.format))

    @property
    def array(self):
        """
        The Numpy `~numpy.ndarray` associated with this `Column`.

        If the column was instantiated with an array passed to the ``array``
        argument, this will return that array.  However, if the column is
        later added to a table, such as via `BinTableHDU.from_columns` as
        is typically the case, this attribute will be updated to reference
        the associated field in the table, which may no longer be the same
        array.
        """
        # Ideally the .array attribute never would have existed in the first
        # place, or would have been internal-only.  This is a legacy of the
        # older design from Astropy that needs to have continued support, for
        # now.

        # One of the main problems with this design was that it created a
        # reference cycle.  When the .array attribute was updated after
        # creating a FITS_rec from the column (as explained in the docstring) a
        # reference cycle was created.  This is because the code in BinTableHDU
        # (and a few other places) does essentially the following:
        #
        # data._coldefs = columns  # The ColDefs object holding this Column
        # for col in columns:
        #     col.array = data.field(col.name)
        #
        # This way each columns .array attribute now points to the field in the
        # table data.  It's actually a pretty confusing interface (since it
        # replaces the array originally pointed to by .array), but it's the way
        # things have been for a long, long time.
        #
        # However, this results, in *many* cases, in a reference cycle.
        # Because the array returned by data.field(col.name), while sometimes
        # an array that owns its own data, is usually like a slice of the
        # original data.  It has the original FITS_rec as the array .base.
        # This results in the following reference cycle (for the n-th column):
        #
        #    data -> data._coldefs -> data._coldefs[n] ->
        #     data._coldefs[n].array -> data._coldefs[n].array.base -> data
        #
        # Because ndarray objects do not handled by Python's garbage collector
        # the reference cycle cannot be broken.  Therefore the FITS_rec's
        # refcount never goes to zero, its __del__ is never called, and its
        # memory is never freed.  This didn't occur in *all* cases, but it did
        # occur in many cases.
        #
        # To get around this, Column.array is no longer a simple attribute
        # like it was previously.  Now each Column has a ._parent_fits_rec
        # attribute which is a weakref to a FITS_rec object.  Code that
        # previously assigned each col.array to field in a FITS_rec (as in
        # the example a few paragraphs above) is still used, however now
        # array.setter checks if a reference cycle will be created.  And if
        # so, instead of saving directly to the Column's __dict__, it creates
        # the ._prent_fits_rec weakref, and all lookups of the column's .array
        # go through that instead.
        #
        # This alone does not fully solve the problem.  Because
        # _parent_fits_rec is a weakref, if the user ever holds a reference to
        # the Column, but deletes all references to the underlying FITS_rec,
        # the .array attribute would suddenly start returning None instead of
        # the array data.  This problem is resolved on FITS_rec's end.  See the
        # note in the FITS_rec._coldefs property for the rest of the story.

        # If the Columns's array is not a reference to an existing FITS_rec,
        # then it is just stored in self.__dict__; otherwise check the
        # _parent_fits_rec reference if it 's still available.
        if "array" in self.__dict__:
            return self.__dict__["array"]
        elif self._parent_fits_rec is not None:
            parent = self._parent_fits_rec()
            if parent is not None:
                return parent[self.name]
        else:
            return None

    @array.setter
    def array(self, array):
        # The following looks over the bases of the given array to check if it
        # has a ._coldefs attribute (i.e. is a FITS_rec) and that that _coldefs
        # contains this Column itself, and would create a reference cycle if we
        # stored the array directly in self.__dict__.
        # In this case it instead sets up the _parent_fits_rec weakref to the
        # underlying FITS_rec, so that array.getter can return arrays through
        # self._parent_fits_rec().field(self.name), rather than storing a
        # hard reference to the field like it used to.
        base = array
        while True:
            if hasattr(base, "_coldefs") and isinstance(base._coldefs, ColDefs):
                for col in base._coldefs:
                    if col is self and self._parent_fits_rec is None:
                        self._parent_fits_rec = weakref.ref(base)

                        # Just in case the user already set .array to their own
                        # array.





































def _convert_record2fits(format):
    """
    Convert record format spec to FITS format spec.
    """
    recformat, kind, dtype = _dtype_to_recformat(format)
    shape = dtype.shape
    itemsize = dtype.base.itemsize
    if dtype.char == "U" or (
        dtype.subdtype is not None and dtype.subdtype[0].char == "U"
                "Please consider using the 'Q' format for your file."
            )
        _offset += descr_output[idx, 0] * _nbytes
    return data_output
def _parse_tdim(tdim):
    """Parse the ``TDIM`` value into a tuple (may return an empty tuple if
    the value ``TDIM`` value is empty or invalid).
    """
    m = tdim and TDIM_RE.match(tdim)
```

## 原始行 55 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/header.py | sed -n '290,390p'
nl -ba astropy/io/fits/header.py | sed -n '850,930p'
nl -ba astropy/io/fits/header.py | sed -n '1280,1500p'
nl -ba astropy/io/fits/header.py | sed -n '1620,1885p'
nl -ba astropy/io/fits/header.py | sed -n '1900,1955p'"
```

退出码：`0`

输出：
```
   290	        Two Headers are equal only if they have the exact same string
   291	        representation.
   292	        """
   293	        return str(self) == str(other)
   294	
   295	    def __add__(self, other):
   296	        temp = self.copy(strip=False)
   297	        temp.extend(other)
   298	        return temp
   299	
   300	    def __iadd__(self, other):
   301	        self.extend(other)
   302	        return self
   303	
   304	    def _ipython_key_completions_(self):
   305	        return self.__iter__()
   306	
   307	    @property
   308	    def cards(self):
   309	        """
   310	        The underlying physical cards that make up this Header; it can be
   311	        looked at, but it should not be modified directly.
   312	        """
   313	        return _CardAccessor(self)
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	    @property
   333	    def _modified(self):
   334	        """
   335	        Whether or not the header has been modified; this is a property so that
   336	        it can also check each card for modifications--cards may have been
   337	        modified directly without the header containing it otherwise knowing.
   338	        """
   339	        modified_cards = any(c._modified for c in self._cards)
   340	        if modified_cards:
   341	            # If any cards were modified then by definition the header was
   342	            # modified
   343	            self.__dict__["_modified"] = True
   344	
   345	        return self.__dict__["_modified"]
   346	
   347	    @_modified.setter
   348	    def _modified(self, val):
   349	        self.__dict__["_modified"] = val
   350	
   351	    @classmethod
   352	    def fromstring(cls, data, sep=""):
   353	        """
   354	        Creates an HDU header from a byte string containing the entire header
   355	        data.
   356	
   357	        Parameters
   358	        ----------
   359	        data : str or bytes
   360	           String or bytes containing the entire header.  In the case of bytes
   361	           they will be decoded using latin-1 (only plain ASCII characters are
   362	           allowed in FITS headers but latin-1 allows us to retain any invalid
   363	           bytes that might appear in malformatted FITS files).
   364	
   365	        sep : str, optional
   366	            The string separating cards from each other, such as a newline.  By
   367	            default there is no card separator (as is the case in a raw FITS
   368	            file).  In general this is only used in cases where a header was
   369	            printed as text (e.g. with newlines after each card) and you want
   370	            to create a new `Header` from it by copy/pasting.
   371	
   372	        Examples
   373	        --------
   374	        >>> from astropy.io.fits import Header
   375	        >>> hdr = Header({'SIMPLE': True})
   376	        >>> Header.fromstring(hdr.tostring()) == hdr
   377	        True
   378	
   379	        If you want to create a `Header` from printed text it's not necessary
   380	        to have the exact binary structure as it would appear in a FITS file,
   381	        with the full 80 byte card length.  Rather, each "card" can end in a
   382	        newline and does not have to be padded out to a full card length as
   383	        long as it "looks like" a FITS header:
   384	
   385	        >>> hdr = Header.fromstring(\"\"\"\\
   386	        ... SIMPLE  =                    T / conforms to FITS standard
   387	        ... BITPIX  =                    8 / array data type
   388	        ... NAXIS   =                    0 / number of array dimensions
   389	        ... EXTEND  =                    T
   390	        ... \"\"\", sep='\\n')
   850	
   851	        value : optional
   852	            A default value to assign to each keyword; must be a valid type for
   853	            FITS keywords.
   854	
   855	        Returns
   856	        -------
   857	        `Header`
   858	            A new `Header` instance.
   859	        """
   860	        d = cls()
   861	        if not isinstance(value, tuple):
   862	            value = (value,)
   863	        for key in iterable:
   864	            d.append((key,) + value)
   865	        return d
   866	
   867	
   868	
   869	
   870	
   871	
   872	
   873	
   874	
   875	
   876	
   877	
   878	
   879	
   880	
   881	
   882	
   883	
   884	
   885	
   886	
   887	
   888	
   889	
   890	
   891	
   892	    def set(self, keyword, value=None, comment=None, before=None, after=None):
   893	        """
   894	        Set the value and/or comment and/or position of a specified keyword.
   895	
   896	        If the keyword does not already exist in the header, a new keyword is
   897	        created in the specified position, or appended to the end of the header
   898	        if no position is specified.
   899	
   900	        This method is similar to :meth:`Header.update` prior to Astropy v0.1.
   901	
   902	        .. note::
   903	            It should be noted that ``header.set(keyword, value)`` and
   904	            ``header.set(keyword, value, comment)`` are equivalent to
   905	            ``header[keyword] = value`` and
   906	            ``header[keyword] = (value, comment)`` respectively.
   907	
   908	        Parameters
   909	        ----------
   910	        keyword : str
   911	            A header keyword
   912	
   913	        value : str, optional
   914	            The value to set for the given keyword; if None the existing value
   915	            is kept, but '' may be used to set a blank value
   916	
   917	        comment : str, optional
   918	            The comment to set for the given keyword; if None the existing
   919	            comment is kept, but ``''`` may be used to set a blank comment
   920	
   921	        before : str, int, optional
   922	            Name of the keyword, or index of the `Card` before which this card
   923	            should be located in the header.  The argument ``before`` takes
   924	            precedence over ``after`` if both specified.
   925	
   926	        after : str, int, optional
   927	            Name of the keyword, or index of the `Card` after which this card
   928	            should be located in the header.
   929	
   930	        """
  1280	                            break
  1281	                    else:
  1282	                        extend_cards.append(card)
  1283	                else:
  1284	                    extend_cards.append(card)
  1285	
  1286	        for card in extend_cards:
  1287	            self.append(card, useblanks=useblanks, bottom=bottom, end=end)
  1288	
  1289	    def count(self, keyword):
  1290	        """
  1291	        Returns the count of the given keyword in the header, similar to
  1292	        `list.count` if the Header object is treated as a list of keywords.
  1293	
  1294	        Parameters
  1295	        ----------
  1296	        keyword : str
  1297	            The keyword to count instances of in the header
  1298	
  1299	        """
  1300	        keyword = Card.normalize_keyword(keyword)
  1301	
  1302	        # We have to look before we leap, since otherwise _keyword_indices,
  1303	        # being a defaultdict, will create an entry for the nonexistent keyword
  1304	        if keyword not in self._keyword_indices:
  1305	            raise KeyError(f"Keyword {keyword!r} not found.")
  1306	
  1307	        return len(self._keyword_indices[keyword])
  1308	
  1309	    def index(self, keyword, start=None, stop=None):
  1310	        """
  1311	        Returns the index if the first instance of the given keyword in the
  1312	        header, similar to `list.index` if the Header object is treated as a
  1313	        list of keywords.
  1314	
  1315	        Parameters
  1316	        ----------
  1317	        keyword : str
  1318	            The keyword to look up in the list of all keywords in the header
  1319	
  1320	        start : int, optional
  1321	            The lower bound for the index
  1322	
  1323	        stop : int, optional
  1324	            The upper bound for the index
  1325	
  1326	        """
  1327	        if start is None:
  1328	            start = 0
  1329	
  1330	        if stop is None:
  1331	            stop = len(self._cards)
  1332	
  1333	        if stop < start:
  1334	            step = -1
  1335	        else:
  1336	            step = 1
  1337	
  1338	        norm_keyword = Card.normalize_keyword(keyword)
  1339	
  1340	        for idx in range(start, stop, step):
  1341	            if self._cards[idx].keyword.upper() == norm_keyword:
  1342	                return idx
  1343	        raise ValueError(f"The keyword {keyword!r} is not in the  header.")
  1344	
  1345	
  1346	
  1347	
  1348	
  1349	
  1350	
  1351	
  1352	
  1353	
  1354	
  1355	
  1356	
  1357	
  1358	
  1359	
  1360	
  1361	
  1362	
  1363	
  1364	
  1365	
  1366	
  1367	
  1368	
  1369	
  1370	
  1371	
  1372	
  1373	
  1374	
  1375	
  1376	
  1377	
  1378	
  1379	
  1380	
  1381	
  1382	
  1383	
  1384	
  1385	
  1386	
  1387	
  1388	
  1389	
  1390	
  1391	
  1392	
  1393	
  1394	
  1395	
  1396	
  1397	
  1398	
  1399	
  1400	
  1401	
  1402	
  1403	
  1404	
  1405	
  1406	
  1407	
  1408	
  1409	
  1410	
  1411	
  1412	
  1413	
  1414	
  1415	
  1416	
  1417	
  1418	
  1419	
  1420	
  1421	
  1422	
  1423	
  1424	
  1425	
  1426	
  1427	
  1428	
  1429	
  1430	
  1431	
  1432	
  1433	
  1434	
  1435	
  1436	
  1437	
  1438	
  1439	
  1440	
  1441	
  1442	
  1443	
  1444	
  1445	
  1446	
  1447	
  1448	
  1449	
  1450	
  1451	
  1452	
  1453	
  1454	
  1455	
  1456	
  1457	
  1458	
  1459	
  1460	
  1461	
  1462	
  1463	
  1464	
  1465	
  1466	
  1467	
  1468	
  1469	
  1470	
  1471	
  1472	
  1473	
  1474	
  1475	
  1476	
  1477	
  1478	
  1479	
  1480	    def rename_keyword(self, oldkeyword, newkeyword, force=False):
  1481	        """
  1482	        Rename a card's keyword in the header.
  1483	
  1484	        Parameters
  1485	        ----------
  1486	        oldkeyword : str or int
  1487	            Old keyword or card index
  1488	
  1489	        newkeyword : str
  1490	            New keyword
  1491	
  1492	        force : bool, optional
  1493	            When `True`, if the new keyword already exists in the header, force
  1494	            the creation of a duplicate keyword. Otherwise a
  1495	            `ValueError` is raised.
  1496	        """
  1497	        old = Card.normalize_keyword(oldkeyword)
  1498	        new = Card.normalize_keyword(newkeyword)
  1499	
  1500	        if new == "CONTINUE":
  1620	        """
  1621	        Return the size (in bytes) of the data portion following the `Header`.
  1622	        """
  1623	        return _hdr_data_size(self)
  1624	
  1625	    @property
  1626	    def data_size_padded(self):
  1627	        """
  1628	        Return the size (in bytes) of the data portion following the `Header`
  1629	        including padding.
  1630	        """
  1631	        size = self.data_size
  1632	        return size + _pad_length(size)
  1633	
  1634	
  1635	
  1636	
  1637	
  1638	
  1639	
  1640	
  1641	
  1642	
  1643	
  1644	
  1645	
  1646	
  1647	
  1648	
  1649	
  1650	
  1651	
  1652	
  1653	
  1654	
  1655	
  1656	
  1657	
  1658	
  1659	
  1660	
  1661	
  1662	
  1663	
  1664	
  1665	
  1666	
  1667	
  1668	
  1669	
  1670	
  1671	
  1672	
  1673	
  1674	
  1675	
  1676	
  1677	
  1678	
  1679	
  1680	
  1681	
  1682	
  1683	
  1684	
  1685	
  1686	
  1687	
  1688	
  1689	
  1690	
  1691	
  1692	
  1693	
  1694	
  1695	
  1696	
  1697	
  1698	
  1699	
  1700	
  1701	
  1702	
  1703	
  1704	
  1705	
  1706	
  1707	
  1708	
  1709	
  1710	
  1711	
  1712	
  1713	
  1714	
  1715	
  1716	
  1717	
  1718	
  1719	
  1720	
  1721	
  1722	
  1723	
  1724	
  1725	
  1726	
  1727	
  1728	    def _keyword_from_index(self, idx):
  1729	        """
  1730	        Given an integer index, return the (keyword, repeat) tuple that index
  1731	        refers to.  For most keywords the repeat will always be zero, but it
  1732	        may be greater than zero for keywords that are duplicated (especially
  1733	        commentary keywords).
  1734	
  1735	        In a sense this is the inverse of self.index, except that it also
  1736	        supports duplicates.
  1737	        """
  1738	        if idx < 0:
  1739	            idx += len(self._cards)
  1740	
  1741	        keyword = self._cards[idx].keyword
  1742	        keyword = Card.normalize_keyword(keyword)
  1743	        repeat = self._keyword_indices[keyword].index(idx)
  1744	        return keyword, repeat
  1745	
  1746	
  1747	
  1748	
  1749	
  1750	
  1751	
  1752	
  1753	
  1754	
  1755	
  1756	
  1757	
  1758	
  1759	
  1760	
  1761	
  1762	
  1763	
  1764	
  1765	
  1766	
  1767	
  1768	
  1769	
  1770	
  1771	
  1772	
  1773	
  1774	
  1775	
  1776	
  1777	
  1778	
  1779	
  1780	
  1781	
  1782	
  1783	
  1784	
  1785	
  1786	
  1787	
  1788	
  1789	
  1790	
  1791	
  1792	
  1793	
  1794	
  1795	
  1796	
  1797	
  1798	
  1799	
  1800	
  1801	
  1802	
  1803	
  1804	
  1805	    def _updateindices(self, idx, increment=True):
  1806	        """
  1807	        For all cards with index above idx, increment or decrement its index
  1808	        value in the keyword_indices dict.
  1809	        """
  1810	        if idx > len(self._cards):
  1811	            # Save us some effort
  1812	            return
  1813	
  1814	        increment = 1 if increment else -1
  1815	
  1816	        for index_sets in (self._keyword_indices, self._rvkc_indices):
  1817	            for indices in index_sets.values():
  1818	                for jdx, keyword_index in enumerate(indices):
  1819	                    if keyword_index >= idx:
  1820	                        indices[jdx] += increment
  1821	
  1822	    def _countblanks(self):
  1823	        """Returns the number of blank cards at the end of the Header."""
  1824	        for idx in range(1, len(self._cards)):
  1825	            if not self._cards[-idx].is_blank:
  1826	                return idx - 1
  1827	        return 0
  1828	
  1829	
  1830	
  1831	
  1832	
  1833	
  1834	
  1835	
  1836	
  1837	
  1838	
  1839	
  1840	
  1841	
  1842	    def _wildcardmatch(self, pattern):
  1843	        """
  1844	        Returns a list of indices of the cards matching the given wildcard
  1845	        pattern.
  1846	
  1847	         * '*' matches 0 or more characters
  1848	         * '?' matches a single character
  1849	         * '...' matches 0 or more of any non-whitespace character
  1850	        """
  1851	        pattern = pattern.replace("*", r".*").replace("?", r".")
  1852	        pattern = pattern.replace("...", r"\S*") + "$"
  1853	        match_pattern = re.compile(pattern, re.IGNORECASE).match
  1854	        return [i for i, card in enumerate(self._cards) if match_pattern(card.keyword)]
  1855	
  1856	
  1857	
  1858	
  1859	
  1860	
  1861	
  1862	
  1863	
  1864	
  1865	
  1866	
  1867	
  1868	
  1869	
  1870	
  1871	
  1872	
  1873	
  1874	
  1875	
  1876	    def _splitcommentary(self, keyword, value):
  1877	        """
  1878	        Given a commentary keyword and value, returns a list of the one or more
  1879	        cards needed to represent the full value.  This is primarily used to
  1880	        create the multiple commentary cards needed to represent a long value
  1881	        that won't fit into a single commentary card.
  1882	        """
  1883	        # The maximum value in each card can be the maximum card length minus
  1884	        # the maximum key length (which can include spaces if they key length
  1885	        # less than 8
  1900	        return cards
  1901	
  1902	    def _add_commentary(self, key, value, before=None, after=None):
  1903	        """
  1904	        Add a commentary card.
  1905	
  1906	        If ``before`` and ``after`` are `None`, add to the last occurrence
  1907	        of cards of the same name (except blank card).  If there is no
  1908	        card (or blank card), append at the end.
  1909	        """
  1910	        if before is not None or after is not None:
  1911	            self._relativeinsert((key, value), before=before, after=after)
  1912	        else:
  1913	            self[key] = value
  1914	
  1915	
  1916	collections.abc.MutableSequence.register(Header)
  1917	collections.abc.MutableMapping.register(Header)
  1918	
  1919	
  1920	class _DelayedHeader:
  1921	    """
  1922	    Descriptor used to create the Header object from the header string that
  1923	    was stored in HDU._header_str when parsing the file.
  1924	    """
  1925	
  1926	
  1927	
  1928	
  1929	
  1930	
  1931	
  1932	
  1933	
  1934	
  1935	
  1936	
  1937	
  1938	
  1939	
  1940	
  1941	    def __set__(self, obj, val):
  1942	        obj.__dict__["_header"] = val
  1943	
  1944	    def __delete__(self, obj):
  1945	        del obj.__dict__["_header"]
  1946	
  1947	
  1948	class _BasicHeaderCards:
  1949	    """
  1950	    This class allows to access cards with the _BasicHeader.cards attribute.
  1951	
  1952	    This is needed because during the HDU class detection, some HDUs uses
  1953	    the .cards interface.  Cards cannot be modified here as the _BasicHeader
  1954	    object will be deleted once the HDU object is created.
  1955
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"def _useblanks\" astropy || true
grep -RIn \"_useblanks\" astropy/io/fits | head -20
grep -RIn \"def _cardindex\\|def _relativeinsert\\|def _set_slice\\|def _update(\" astropy || true
awk 'NF {print NR \":\" "'$0}'"' astropy/io/fits/header.py | sed -n '580,760p'"
```

退出码：`0`

输出：
```
astropy/io/fits/header.py:1176:                self._useblanks(len(str(card)) // Card.length)
732:            If `True` (default) adds the END card to the end of the header
733:            string
735:        padding : bool, optional
736:            If `True` (default) pads the string with spaces out to the next
737:            multiple of 2880 characters
739:        overwrite : bool, optional
740:            If ``True``, overwrite the output file if it exists. Raises an
741:            ``OSError`` if ``False`` and the output file exists. Default is
742:            ``False``.
743:        """
744:        close_file = fileobj_closed(fileobj)
746:        if not isinstance(fileobj, _File):
747:            fileobj = _File(fileobj, mode="ostream", overwrite=overwrite)
749:        try:
750:            blocks = self.tostring(sep=sep, endcard=endcard, padding=padding)
751:            actual_block_size = _block_size(sep)
752:            if padding and len(blocks) % actual_block_size != 0:
753:                raise OSError(
754:                    f"Header size ({len(blocks) - actual_block_size + BLOCK_SIZE}) "
755:                    f"is not a multiple of block size ({BLOCK_SIZE})."
756:                )
758:            fileobj.flush()
759:            fileobj.write(blocks.encode("ascii"))
760:            fileobj.flush()
761:        finally:
762:            if close_file:
763:                fileobj.close()
765:    @classmethod
766:    def fromtextfile(cls, fileobj, endcard=False):
767:        """
768:        Read a header from a simple text file or file-like object.
770:        Equivalent to::
772:            >>> Header.fromfile(fileobj, sep='\\n', endcard=False,
773:            ...                 padding=False)
775:        See Also
776:        --------
777:        fromfile
778:        """
779:        return cls.fromfile(fileobj, sep="\n", endcard=endcard, padding=False)
781:    def totextfile(self, fileobj, endcard=False, overwrite=False):
782:        """
783:        Write the header as text to a file or a file-like object.
785:        Equivalent to::
787:            >>> Header.tofile(fileobj, sep='\\n', endcard=False,
788:            ...               padding=False, overwrite=overwrite)
790:        See Also
791:        --------
792:        tofile
793:        """
794:        self.tofile(
795:            fileobj, sep="\n", endcard=endcard, padding=False, overwrite=overwrite
796:        )
798:    def clear(self):
799:        """
800:        Remove all cards from the header.
801:        """
802:        self._cards = []
803:        self._keyword_indices = collections.defaultdict(list)
804:        self._rvkc_indices = collections.defaultdict(list)
806:    def copy(self, strip=False):
807:        """
808:        Make a copy of the :class:`Header`.
810:        .. versionchanged:: 1.3
811:            `copy.copy` and `copy.deepcopy` on a `Header` will call this
812:            method.
814:        Parameters
815:        ----------
816:        strip : bool, optional
817:            If `True`, strip any headers that are specific to one of the
818:            standard HDU types, so that this header can be used in a different
819:            HDU.
821:        Returns
822:        -------
823:        `Header`
824:            A new :class:`Header` instance.
825:        """
826:        tmp = self.__class__(copy.copy(card) for card in self._cards)
827:        if strip:
828:            tmp.strip()
829:        return tmp
831:    def __copy__(self):
832:        return self.copy()
834:    def __deepcopy__(self, *args, **kwargs):
835:        return self.copy()
837:    @classmethod
838:    def fromkeys(cls, iterable, value=None):
839:        """
840:        Similar to :meth:`dict.fromkeys`--creates a new `Header` from an
841:        iterable of keywords and an optional default value.
843:        This method is not likely to be particularly useful for creating real
844:        world FITS headers, but it is useful for testing.
846:        Parameters
847:        ----------
848:        iterable
849:            Any iterable that returns strings representing FITS keywords.
851:        value : optional
852:            A default value to assign to each keyword; must be a valid type for
853:            FITS keywords.
855:        Returns
856:        -------
857:        `Header`
858:            A new `Header` instance.
859:        """
860:        d = cls()
861:        if not isinstance(value, tuple):
862:            value = (value,)
863:        for key in iterable:
864:            d.append((key,) + value)
865:        return d
892:    def set(self, keyword, value=None, comment=None, before=None, after=None):
893:        """
894:        Set the value and/or comment and/or position of a specified keyword.
896:        If the keyword does not already exist in the header, a new keyword is
897:        created in the specified position, or appended to the end of the header
898:        if no position is specified.
900:        This method is similar to :meth:`Header.update` prior to Astropy v0.1.
902:        .. note::
903:            It should be noted that ``header.set(keyword, value)`` and
904:            ``header.set(keyword, value, comment)`` are equivalent to
905:            ``header[keyword] = value`` and
906:            ``header[keyword] = (value, comment)`` respectively.
908:        Parameters
909:        ----------
910:        keyword : str
911:            A header keyword
913:        value : str, optional
914:            The value to set for the given keyword; if None the existing value
915:            is kept, but '' may be used to set a blank value
917:        comment : str, optional
918:            The comment to set for the given keyword; if None the existing
919:            comment is kept, but ``''`` may be used to set a blank comment
921:        before : str, int, optional
922:            Name of the keyword, or index of the `Card` before which this card
923:            should be located in the header.  The argument ``before`` takes
924:            precedence over ``after`` if both specified.
926:        after : str, int, optional
927:            Name of the keyword, or index of the `Card` after which this card
928:            should be located in the header.
930:        """
931:        # Create a temporary card that looks like the one being set; if the
932:        # temporary card turns out to be a RVKC this will make it easier to
933:        # deal with the idiosyncrasies thereof
934:        # Don't try to make a temporary card though if they keyword looks like
935:        # it might be a HIERARCH card or is otherwise invalid--this step is
936:        # only for validating RVKCs.
937:        if (
938:            len(keyword) <= KEYWORD_LENGTH
939:            and Card._keywd_FSC_RE.match(keyword)
940:            and keyword not in self._keyword_indices
941:        ):
942:            new_card = Card(keyword, value, comment)
943:            new_keyword = new_card.keyword
944:        else:
945:            new_keyword = keyword
947:        if new_keyword not in _commentary_keywords and new_keyword in self:
948:            if comment is None:
949:                comment = self.comments[keyword]
950:            if value is None:
951:                value = self[keyword]
953:            self[keyword] = (value, comment)
955:            if before is not None or after is not None:
956:                card = self._cards[self._cardindex(keyword)]
957:                self._relativeinsert(card, before=before, after=after, replace=True)
958:        elif before is not None or after is not None:
959:            self._relativeinsert((keyword, value, comment), before=before, after=after)
960:        else:
961:            self[keyword] = (value, comment)
963:    def items(self):
964:        """Like :meth:`dict.items`."""
965:        for card in self._cards:
966:            yield card.keyword, None if card.value == UNDEFINED else card.value
968:    def keys(self):
969:        """
970:        Like :meth:`dict.keys`--iterating directly over the `Header`
971:        instance has the same behavior.
972:        """
973:        for card in self._cards:
974:            yield card.keyword
976:    def values(self):
977:        """Like :meth:`dict.values`."""
978:        for card in self._cards:
```

## 原始行 61 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def normalize_keyword\\|field_specifier\\|rawkeyword\\|rawvalue\\|_commentary_keywords\" astropy/io/fits/card.py | head -80
sed -n '150,280p' astropy/io/fits/card.py
sed -n '500,700p' astropy/io/fits/card.py"
```

退出码：`0`

输出：
```
133:    _rvkc_field_specifier_s = rf"{_rvkc_field}(\.{_rvkc_field})*"
134:    _rvkc_field_specifier_val = (
135:        rf"(?P<keyword>{_rvkc_field_specifier_s}): +(?P<val>{_numr_FSC})"
137:    _rvkc_keyword_val = rf"\'(?P<rawval>{_rvkc_field_specifier_val})\'"
140:    _rvkc_field_specifier_val_RE = re.compile(_rvkc_field_specifier_val + "$")
146:        rf"(?P<keyword>{_rvkc_identifier})\.(?P<field_specifier>{_rvkc_field_specifier_s})$"
154:    _commentary_keywords = {"", "COMMENT", "HISTORY", "END"}
155:    _special_keywords = _commentary_keywords.union(["CONTINUE"])
185:        self._field_specifier = None
188:        self._rawkeyword = None
189:        self._rawvalue = None
287:        if self.field_specifier:
375:            self._rawvalue = None
379:            if self.field_specifier:
393:        if not self.field_specifier:
401:    def rawkeyword(self):
406:        if self._rawkeyword is not None:
407:            return self._rawkeyword
408:        elif self.field_specifier is not None:
409:            self._rawkeyword = self.keyword.split(".", 1)[0]
410:            return self._rawkeyword
415:    def rawvalue(self):
420:        if self._rawvalue is not None:
421:            return self._rawvalue
422:        elif self.field_specifier is not None:
423:            self._rawvalue = f"{self.field_specifier}: {self.value}"
424:            return self._rawvalue
483:    def field_specifier(self):
489:        # internal _field_specifier attribute if this is a RVKC.
491:            return self._field_specifier
495:    @field_specifier.setter
496:    def field_specifier(self, field_specifier):
497:        if not field_specifier:
501:        elif not self.field_specifier:
504:                "setting the field_specifier attribute"
506:        elif field_specifier != self.field_specifier:
507:            self._field_specifier = field_specifier
510:            self._keyword = f"{keyword}.{field_specifier}"
513:    @field_specifier.deleter
514:    def field_specifier(self):
516:            "The field_specifier attribute may not be "
575:    def normalize_keyword(cls, keyword):
596:                (match.group("keyword").strip().upper(), match.group("field_specifier"))
618:        If the check passes the ._keyword, ._value, and .field_specifier
638:            if keyword in self._commentary_keywords:
643:                    match.group("keyword"), match.group("field_specifier"), None, value
650:                match = self._rvkc_field_specifier_val_RE.match(value)
693:    def _init_rvkc(self, keyword, field_specifier, field, value):
699:        self._keyword = f"{keyword_upper}.{field_specifier}"
700:        self._rawkeyword = keyword_upper
701:        self._field_specifier = field_specifier
703:        self._rawvalue = field
754:        if self.keyword.upper() in self._commentary_keywords or self._invalid:
808:        if self.keyword in Card._commentary_keywords or self._invalid:
850:                if keyword in self._commentary_keywords:
869:            if keyword in self._commentary_keywords:
897:        if self.field_specifier:
898:            keyword, field_specifier = self._keyword.split(".", 1)
899:            self._keyword = f"{keyword.upper()}.{field_specifier}"
945:            if self.field_specifier:
965:        if self.keyword in self._commentary_keywords:
976:        elif self.field_specifier:
978:            value = f"'{self.field_specifier}: {value}'"
983:        if not self.field_specifier and len(self.keyword) > KEYWORD_LENGTH:
998:        is_commentary = keyword.strip() in self._commentary_keywords
1050:        if self.keyword in Card._commentary_keywords:
1120:        if self.keyword not in self._commentary_keywords and (
1157:            if self.field_specifier:
1167:        if self.keyword in self._commentary_keywords:
    # from the string value of a record value keyword card
    # (ex "'AXIS.1: 1' / a comment")
    _rvkc_keyword_val_comm_RE = re.compile(_rvkc_keyword_val_comm)

    _commentary_keywords = {"", "COMMENT", "HISTORY", "END"}
    _special_keywords = _commentary_keywords.union(["CONTINUE"])

    # The default value indicator; may be changed if required by a convention
    # (namely HIERARCH cards)
    _value_indicator = VALUE_INDICATOR

    def __init__(self, keyword=None, value=None, comment=None, **kwargs):
        # For backwards compatibility, support the 'key' keyword argument:
        if keyword is None and "key" in kwargs:
            keyword = kwargs["key"]

        self._keyword = None
        self._value = None
        self._comment = None
        self._valuestring = None
        self._image = None

        # This attribute is set to False when creating the card from a card
        # image to ensure that the contents of the image get verified at some
        # point
        self._verified = True

        # A flag to conveniently mark whether or not this was a valid HIERARCH
        # card
        self._hierarch = False

        # If the card could not be parsed according the FITS standard or
        # any recognized non-standard conventions, this will be True
        self._invalid = False

        self._field_specifier = None

        # These are used primarily only by RVKCs
        self._rawkeyword = None
        self._rawvalue = None

        if not (
            keyword is not None
            and value is not None
            and self._check_if_rvkc(keyword, value)
        ):
            # If _check_if_rvkc passes, it will handle setting the keyword and
            # value
            if keyword is not None:
                self.keyword = keyword
            if value is not None:
                self.value = value

        if comment is not None:
            self.comment = comment

        self._modified = False
        self._valuemodified = False

    def __repr__(self):
        return repr((self.keyword, self.value, self.comment))

    def __str__(self):
        return self.image

    def __len__(self):
        return 3

    def __getitem__(self, index):
        return (self.keyword, self.value, self.comment)[index]

    @property
    def keyword(self):
        """Returns the keyword name parsed from the card image."""
        if self._keyword is not None:
            return self._keyword
        elif self._image:
            self._keyword = self._parse_keyword()
            return self._keyword
        else:
            self.keyword = ""
            return ""

    @keyword.setter
    def keyword(self, keyword):
        """Set the key attribute; once set it cannot be modified."""
        if self._keyword is not None:
            raise AttributeError("Once set, the Card keyword may not be modified")
        elif isinstance(keyword, str):
            # Be nice and remove trailing whitespace--some FITS code always
            # pads keywords out with spaces; leading whitespace, however,
            # should be strictly disallowed.
            keyword = keyword.rstrip()
            keyword_upper = keyword.upper()
            if len(keyword) <= KEYWORD_LENGTH and self._keywd_FSC_RE.match(
                keyword_upper
            ):
                # For keywords with length > 8 they will be HIERARCH cards,
                # and can have arbitrary case keywords
                if keyword_upper == "END":
                    raise ValueError("Keyword 'END' not allowed.")
                keyword = keyword_upper
            elif self._keywd_hierarch_RE.match(keyword):
                # In prior versions of PyFITS (*) HIERARCH cards would only be
                # created if the user-supplied keyword explicitly started with
                # 'HIERARCH '.  Now we will create them automatically for long
                # keywords, but we still want to support the old behavior too;
                # the old behavior makes it possible to create HIERARCH cards
                # that would otherwise be recognized as RVKCs
                # (*) This has never affected Astropy, because it was changed
                # before PyFITS was merged into Astropy!
                self._hierarch = True
                self._value_indicator = HIERARCH_VALUE_INDICATOR

                if keyword_upper[:9] == "HIERARCH ":
                    # The user explicitly asked for a HIERARCH card, so don't
                    # bug them about it...
                    keyword = keyword[9:].strip()
                else:
                    # We'll gladly create a HIERARCH card, but a warning is
                    # also displayed
                    warnings.warn(
                        f"Keyword name {keyword!r} is greater than 8 characters or "
                        "contains characters not allowed by the FITS "
                        "standard; a HIERARCH card will be created.",
                        VerifyWarning,
                    )
            else:
                raise ValueError(f"Illegal keyword name: {keyword!r}.")
            self._keyword = keyword
            self._modified = True
            )
        elif not self.field_specifier:
            raise AttributeError(
                "Cannot coerce cards to be record-valued keyword cards by "
                "setting the field_specifier attribute"
            )
        elif field_specifier != self.field_specifier:
            self._field_specifier = field_specifier
            # The keyword need also be updated
            keyword = self._keyword.split(".", 1)[0]
            self._keyword = f"{keyword}.{field_specifier}"
            self._modified = True

    @field_specifier.deleter
    def field_specifier(self):
        raise AttributeError(
            "The field_specifier attribute may not be "
            "deleted from record-valued keyword cards."
        )

    @property
    def image(self):
        """
        The card "image", that is, the 80 byte character string that represents
        this card in an actual FITS header.
        """
        if self._image and not self._verified:
            self.verify("fix+warn")
        if self._image is None or self._modified:
            self._image = self._format_image()
        return self._image

    @property
    def is_blank(self):
        """
        `True` if the card is completely blank--that is, it has no keyword,
        value, or comment.  It appears in the header as 80 spaces.

        Returns `False` otherwise.
        """
        if not self._verified:
            # The card image has not been parsed yet; compare directly with the
            # string representation of a blank card
            return self._image == BLANK_CARD

        # If the keyword, value, and comment are all empty (for self.value
        # explicitly check that it is a string value, since a blank value is
        # returned as '')
        return (
            not self.keyword
            and (isinstance(self.value, str) and not self.value)
            and not self.comment
        )

    @classmethod
    def fromstring(cls, image):
        """
        Construct a `Card` object from a (raw) string. It will pad the string
        if it is not the length of a card image (80 columns).  If the card
        image is longer than 80 columns, assume it contains ``CONTINUE``
        card(s).
        """
        card = cls()
        if isinstance(image, bytes):
            # FITS supports only ASCII, but decode as latin1 and just take all
            # bytes for now; if it results in mojibake due to e.g. UTF-8
            # encoded data in a FITS header that's OK because it shouldn't be
            # there in the first place
            image = image.decode("latin1")

        card._image = _pad(image)
        card._verified = False
        return card

    @classmethod
    def normalize_keyword(cls, keyword):
        """
        `classmethod` to convert a keyword value that may contain a
        field-specifier to uppercase.  The effect is to raise the key to
        uppercase and leave the field specifier in its original case.

        Parameters
        ----------
        keyword : or str
            A keyword value or a ``keyword.field-specifier`` value
        """
        # Test first for the most common case: a standard FITS keyword provided
        # in standard all-caps
        if len(keyword) <= KEYWORD_LENGTH and cls._keywd_FSC_RE.match(keyword):
            return keyword

        # Test if this is a record-valued keyword
        match = cls._rvkc_keyword_name_RE.match(keyword)

        if match:
            return ".".join(
                (match.group("keyword").strip().upper(), match.group("field_specifier"))
            )
        elif len(keyword) > 9 and keyword[:9].upper() == "HIERARCH ":
            # Remove 'HIERARCH' from HIERARCH keywords; this could lead to
            # ambiguity if there is actually a keyword card containing
            # "HIERARCH HIERARCH", but shame on you if you do that.
            return keyword[9:].strip().upper()
        else:
            # A normal FITS keyword, but provided in non-standard case
            return keyword.strip().upper()

    def _check_if_rvkc(self, *args):
        """
        Determine whether or not the card is a record-valued keyword card.

        If one argument is given, that argument is treated as a full card image
        and parsed as such.  If two arguments are given, the first is treated
        as the card keyword (including the field-specifier if the card is
        intended as a RVKC), and the second as the card value OR the first value
        can be the base keyword, and the second value the 'field-specifier:
        value' string.

        If the check passes the ._keyword, ._value, and .field_specifier
        keywords are set.

        Examples
        --------
        ::

            self._check_if_rvkc('DP1', 'AXIS.1: 2')
            self._check_if_rvkc('DP1.AXIS.1', 2)
            self._check_if_rvkc('DP1     = AXIS.1: 2')
        """
        if not conf.enable_record_valued_keyword_cards:
            return False

        if len(args) == 1:
            return self._check_if_rvkc_image(*args)
        elif len(args) == 2:
            keyword, value = args
            if not isinstance(keyword, str):
                return False
            if keyword in self._commentary_keywords:
                return False
            match = self._rvkc_keyword_name_RE.match(keyword)
            if match and isinstance(value, (int, float)):
                self._init_rvkc(
                    match.group("keyword"), match.group("field_specifier"), None, value
                )
                return True

            # Testing for ': ' is a quick way to avoid running the full regular
            # expression, speeding this up for the majority of cases
            if isinstance(value, str) and value.find(": ") > 0:
                match = self._rvkc_field_specifier_val_RE.match(value)
                if match and self._keywd_FSC_RE.match(keyword):
                    self._init_rvkc(
                        keyword, match.group("keyword"), value, match.group("val")
                    )
                    return True

    def _check_if_rvkc_image(self, *args):
        """
        Implements `Card._check_if_rvkc` for the case of an unparsed card
        image.  If given one argument this is the full intact image.  If given
        two arguments the card has already been split between keyword and
        value+comment at the standard value indicator '= '.
        """
        if len(args) == 1:
            image = args[0]
            eq_idx = image.find(VALUE_INDICATOR)
            if eq_idx < 0 or eq_idx > 9:
                return False
            keyword = image[:eq_idx]
            rest = image[eq_idx + VALUE_INDICATOR_LEN :]
        else:
            keyword, rest = args

        rest = rest.lstrip()

        # This test allows us to skip running the full regular expression for
        # the majority of cards that do not contain strings or that definitely
        # do not contain RVKC field-specifiers; it's very much a
        # micro-optimization but it does make a measurable difference
        if not rest or rest[0] != "'" or rest.find(": ") < 2:
            return False

        match = self._rvkc_keyword_val_comm_RE.match(rest)
        if match:
            self._init_rvkc(
                keyword,
                match.group("keyword"),
                match.group("rawval"),
                match.group("val"),
            )
            return True

    def _init_rvkc(self, keyword, field_specifier, field, value):
        """
        Sort of addendum to Card.__init__ to set the appropriate internal
        attributes if the card was determined to be a RVKC.
        """
        keyword_upper = keyword.upper()
        self._keyword = f"{keyword_upper}.{field_specifier}"
        self._rawkeyword = keyword_upper
```

## 原始行 64 · command_execution

命令：
```
/bin/bash -lc "grep -n \"duplicate\\|Duplicate\\|warns\" astropy/io/fits/tests/test_header.py | head -120
sed -n '780,890p' astropy/io/fits/tests/test_header.py
sed -n '1880,1950p' astropy/io/fits/tests/test_header.py
sed -n '2860,3070p' astropy/io/fits/tests/test_header.py"
```

退出码：`0`

输出：
```
178:        with pytest.warns(fits.verify.VerifyWarning):
184:        with pytest.warns(fits.verify.VerifyWarning):
195:        with pytest.warns(
214:        with pytest.warns(AstropyUserWarning) as w:
369:        with pytest.warns(fits.verify.VerifyWarning) as w:
381:        with pytest.warns(fits.verify.VerifyWarning) as w:
407:        with pytest.warns(fits.verify.VerifyWarning) as w:
419:        with pytest.warns(AstropyUserWarning, match=r"header keyword is invalid"):
425:        with pytest.warns(AstropyUserWarning, match=r"header keyword is invalid"):
431:        with pytest.warns(AstropyUserWarning) as w:
443:        with pytest.warns(fits.verify.VerifyWarning) as w:
591:        with pytest.warns(fits.verify.VerifyWarning) as w:
662:        with pytest.warns(
708:        # Check that it still warns if we do not use HIERARCH
709:        with pytest.warns(
742:        with pytest.warns(fits.verify.VerifyWarning, match="greater than 8"):
756:        with pytest.warns(fits.verify.VerifyWarning, match="greater than 8"):
771:        with pytest.warns(fits.verify.VerifyWarning, match="greater than 8"):
842:        with pytest.warns(
848:        with pytest.warns(
853:        with pytest.warns(
870:        with pytest.warns(VerifyWarning) as w:
933:        with pytest.warns(VerifyWarning) as w:
960:        with pytest.warns(VerifyWarning) as w:
1235:    def test_header_fromkeys_with_duplicates(self):
1497:        header can exactly duplicate that header, given strip=False and
1963:        with pytest.warns(
1974:        with pytest.warns(
1983:        with pytest.warns(
1995:        with pytest.warns(
2023:        with pytest.warns(
2086:        with pytest.warns(fits.verify.VerifyWarning) as w:
2090:        with pytest.warns(fits.verify.VerifyWarning) as w:
2100:        with pytest.warns(fits.verify.VerifyWarning) as w:
2104:        with pytest.warns(fits.verify.VerifyWarning) as w:
2139:            pytest.warns(AstropyUserWarning) as w,
2384:    def test_keep_duplicate_history_in_orig_header(self):
2389:        FITS file, if the original header contains duplicate HISTORY values
2390:        those duplicates should be preserved just as in the original header.
2433:        with pytest.warns(AstropyUserWarning) as w:
2441:        with pytest.warns(AstropyUserWarning) as w:
2470:        with pytest.warns(fits.verify.VerifyWarning) as w:
2832:        with pytest.warns(fits.verify.VerifyWarning):

    def test_verify_mixed_case_hierarch(self):
        """Regression test for
        https://github.com/spacetelescope/PyFITS/issues/7

        Assures that HIERARCH keywords with lower-case characters and other
        normally invalid keyword characters are not considered invalid.
        """

        c = fits.Card("HIERARCH WeirdCard.~!@#_^$%&", "The value", "a comment")
        # This should not raise any exceptions
        c.verify("exception")
        assert c.keyword == "WeirdCard.~!@#_^$%&"
        assert c.value == "The value"
        assert c.comment == "a comment"

        # Test also the specific case from the original bug report
        header = fits.Header(
            [
                ("simple", True),
                ("BITPIX", 8),
                ("NAXIS", 0),
                ("EXTEND", True, "May contain datasets"),
                ("HIERARCH key.META_0", "detRow"),
            ]
        )
        hdu = fits.PrimaryHDU(header=header)
        hdu.writeto(self.temp("test.fits"))
        with fits.open(self.temp("test.fits")) as hdul:
            header2 = hdul[0].header
            assert str(header.cards[header.index("key.META_0")]) == str(
                header2.cards[header2.index("key.META_0")]
            )

    def test_missing_keyword(self):
        """Test that accessing a non-existent keyword raises a KeyError."""

        header = fits.Header()
        # De-referencing header through the inline function should behave
        # identically to accessing it in the pytest.raises context below.
        pytest.raises(KeyError, lambda k: header[k], "NAXIS")
        # Test exception with message
        with pytest.raises(KeyError, match=r"Keyword 'NAXIS' not found."):
            header["NAXIS"]

    def test_hierarch_card_lookup(self):
        header = fits.Header()
        header["hierarch abcdefghi"] = 10
        assert "abcdefghi" in header
        assert header["abcdefghi"] == 10
        # This used to be assert_false, but per ticket
        # https://aeon.stsci.edu/ssb/trac/pyfits/ticket/155 hierarch keywords
        # should be treated case-insensitively when performing lookups
        assert "ABCDEFGHI" in header

    def test_hierarch_card_delete(self):
        header = fits.Header()
        header["hierarch abcdefghi"] = 10
        del header["hierarch abcdefghi"]

    def test_hierarch_card_insert_delete(self):
        header = fits.Header()
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header["abcdefghi"] = 10
        header["abcdefgh"] = 10
        header["abcdefg"] = 10
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header.insert(2, ("abcdefghij", 10))
        del header["abcdefghij"]
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header.insert(2, ("abcdefghij", 10))
        del header[2]
        assert list(header.keys())[2] == "abcdefg".upper()

    def test_hierarch_create_and_update(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/158

        Tests several additional use cases for working with HIERARCH cards.
        """

        msg = "a HIERARCH card will be created"

        header = fits.Header()
        with pytest.warns(VerifyWarning) as w:
            header.update({"HIERARCH BLAH BLAH": "TESTA"})
            assert len(w) == 0
            assert "BLAH BLAH" in header
            assert header["BLAH BLAH"] == "TESTA"

            header.update({"HIERARCH BLAH BLAH": "TESTB"})
            assert len(w) == 0
            assert header["BLAH BLAH"], "TESTB"

            # Update without explicitly stating 'HIERARCH':
            header.update({"BLAH BLAH": "TESTC"})
            assert len(w) == 1
            assert len(header) == 1
            assert header["BLAH BLAH"], "TESTC"

            # Test case-insensitivity
            header.update({"HIERARCH blah blah": "TESTD"})
            assert len(w) == 1
            assert len(header) == 1
            assert header["blah blah"], "TESTD"
        header["B"] = ("C", "D")
        header["C"] = ("D", "E")

        with open(self.temp("test.hdr"), "w") as f:
            f.write("\n".join(str(c).strip() for c in header.cards))

        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
        assert header == header2

    def test_header_fromtextfile_with_end_card(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/154

        Make sure that when a Header is read from a text file that the END card
        is ignored.
        """

        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])

        # We don't use header.totextfile here because it writes each card with
        # trailing spaces to pad them out to 80 characters.  But this bug only
        # presents itself when each card ends immediately with a newline, and
        # no trailing spaces
        with open(self.temp("test.hdr"), "w") as f:
            f.write("\n".join(str(c).strip() for c in header.cards))
            f.write("\nEND")

        new_header = fits.Header.fromtextfile(self.temp("test.hdr"))

        assert "END" not in new_header
        assert header == new_header

    def test_append_end_card(self):
        """
        Regression test 2 for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/154

        Manually adding an END card to a header should simply result in a
        ValueError (as was the case in PyFITS 3.0 and earlier).
        """

        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])

        def setitem(k, v):
            header[k] = v

        pytest.raises(ValueError, setitem, "END", "")
        pytest.raises(ValueError, header.append, "END")
        pytest.raises(ValueError, header.append, "END", end=True)
        pytest.raises(ValueError, header.insert, len(header), "END")
        pytest.raises(ValueError, header.set, "END")

    def test_invalid_end_cards(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/217

        This tests the case where the END card looks like a normal card like
        'END = ' and other similar oddities.  As long as a card starts with END
        and looks like it was intended to be the END card we allow it, but with
        a warning.
        """

        horig = fits.PrimaryHDU(data=np.arange(100)).header

        def invalid_header(end, pad):
            # Build up a goofy invalid header
            # Start from a seemingly normal header
            s = horig.tostring(sep="", endcard=False, padding=False)
            # append the bogus end card
            s += end
            # add additional padding if requested
            if pad:
                s += " " * _pad_length(len(s))
        assert c.keyword == "DP1.NAXIS1"
        assert c.value == 2.0
        assert c.comment == "A comment"
        assert str(c).rstrip() == "DP1     = 'NAXIS1: 2' / A comment"

    def test_field_specifier_case_senstivity(self):
        """
        The keyword portion of an RVKC should still be case-insensitive, but
        the field-specifier portion should be case-sensitive.
        """

        header = fits.Header()
        header.set("abc.def", 1)
        header.set("abc.DEF", 2)
        assert header["abc.def"] == 1
        assert header["ABC.def"] == 1
        assert header["aBc.def"] == 1
        assert header["ABC.DEF"] == 2
        assert "ABC.dEf" not in header

    def test_get_rvkc_by_index(self):
        """
        Returning a RVKC from a header via index lookup should return the
        float value of the card.
        """

        assert self._test_header[0] == 2.0
        assert isinstance(self._test_header[0], float)
        assert self._test_header[1] == 1.0
        assert isinstance(self._test_header[1], float)

    def test_get_rvkc_by_keyword(self):
        """
        Returning a RVKC just via the keyword name should return the full value
        string of the first card with that keyword.

        This test was changed to reflect the requirement in ticket
        https://aeon.stsci.edu/ssb/trac/pyfits/ticket/184--previously it required
        _test_header['DP1'] to return the parsed float value.
        """

        assert self._test_header["DP1"] == "NAXIS: 2"

    def test_get_rvkc_by_keyword_and_field_specifier(self):
        """
        Returning a RVKC via the full keyword/field-specifier combination
        should return the floating point value associated with the RVKC.
        """

        assert self._test_header["DP1.NAXIS"] == 2.0
        assert isinstance(self._test_header["DP1.NAXIS"], float)
        assert self._test_header["DP1.AUX.1.COEFF.1"] == 0.00048828125

    def test_access_nonexistent_rvkc(self):
        """
        Accessing a nonexistent RVKC should raise an IndexError for
        index-based lookup, or a KeyError for keyword lookup (like a normal
        card).
        """

        pytest.raises(IndexError, lambda x: self._test_header[x], 8)
        # Test exception with message
        with pytest.raises(KeyError, match=r"Keyword 'DP1\.AXIS\.3' not found."):
            self._test_header["DP1.AXIS.3"]

    def test_update_rvkc(self):
        """A RVKC can be updated either via index or keyword access."""

        self._test_header[0] = 3
        assert self._test_header["DP1.NAXIS"] == 3.0
        assert isinstance(self._test_header["DP1.NAXIS"], float)

        self._test_header["DP1.AXIS.1"] = 1.1
        assert self._test_header["DP1.AXIS.1"] == 1.1

    def test_update_rvkc_2(self):
        """Regression test for an issue that appeared after SVN r2412."""

        h = fits.Header()
        h["D2IM1.EXTVER"] = 1
        assert h["D2IM1.EXTVER"] == 1.0
        h["D2IM1.EXTVER"] = 2
        assert h["D2IM1.EXTVER"] == 2.0

    def test_raw_keyword_value(self):
        c = fits.Card.fromstring("DP1     = 'NAXIS: 2' / A comment")
        assert c.rawkeyword == "DP1"
        assert c.rawvalue == "NAXIS: 2"

        c = fits.Card("DP1.NAXIS", 2)
        assert c.rawkeyword == "DP1"
        assert c.rawvalue == "NAXIS: 2.0"

        c = fits.Card("DP1.NAXIS", 2.0)
        assert c.rawkeyword == "DP1"
        assert c.rawvalue == "NAXIS: 2.0"

    def test_rvkc_insert_after(self):
        """
        It should be possible to insert a new RVKC after an existing one
        specified by the full keyword/field-specifier combination."""

        self._test_header.set("DP1", "AXIS.3: 1", "a comment", after="DP1.AXIS.2")
        assert self._test_header[3] == 1
        assert self._test_header["DP1.AXIS.3"] == 1

    def test_rvkc_delete(self):
        """
        Deleting a RVKC should work as with a normal card by using the full
        keyword/field-spcifier combination.
        """

        del self._test_header["DP1.AXIS.1"]
        assert len(self._test_header) == 7
        assert list(self._test_header)[0] == "DP1.NAXIS"
        assert self._test_header[0] == 2
        assert list(self._test_header)[1] == "DP1.AXIS.2"

        # Perform a subsequent delete to make sure all the index mappings were
        # updated
        del self._test_header["DP1.AXIS.2"]
        assert len(self._test_header) == 6
        assert list(self._test_header)[0] == "DP1.NAXIS"
        assert self._test_header[0] == 2
        assert list(self._test_header)[1] == "DP1.NAUX"
        assert self._test_header[1] == 2

    def test_pattern_matching_keys(self):
        """Test the keyword filter strings with RVKCs."""

        cl = self._test_header["DP1.AXIS.*"]
        assert isinstance(cl, fits.Header)
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AXIS.1: 1'",
            "DP1     = 'AXIS.2: 2'",
        ]

        cl = self._test_header["DP1.N*"]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'NAXIS: 2'",
            "DP1     = 'NAUX: 2'",
        ]

        cl = self._test_header["DP1.AUX..."]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

        cl = self._test_header["DP?.NAXIS"]
        assert [str(c).strip() for c in cl.cards] == ["DP1     = 'NAXIS: 2'"]

        cl = self._test_header["DP1.A*S.*"]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AXIS.1: 1'",
            "DP1     = 'AXIS.2: 2'",
        ]

    def test_pattern_matching_key_deletion(self):
        """Deletion by filter strings should work."""

        del self._test_header["DP1.A*..."]
        assert len(self._test_header) == 2
        assert list(self._test_header)[0] == "DP1.NAXIS"
        assert self._test_header[0] == 2
        assert list(self._test_header)[1] == "DP1.NAUX"
        assert self._test_header[1] == 2

    def test_successive_pattern_matching(self):
        """
        A card list returned via a filter string should be further filterable.
        """

        cl = self._test_header["DP1.A*..."]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AXIS.1: 1'",
            "DP1     = 'AXIS.2: 2'",
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

        cl2 = cl["*.*AUX..."]
        assert [str(c).strip() for c in cl2.cards] == [
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

    def test_rvkc_in_cardlist_keys(self):
        """
        The CardList.keys() method should return full keyword/field-spec values
        for RVKCs.
        """

        cl = self._test_header["DP1.AXIS.*"]
        assert list(cl) == ["DP1.AXIS.1", "DP1.AXIS.2"]

    def test_rvkc_in_cardlist_values(self):
        """
        The CardList.values() method should return the values of all RVKCs as
        floating point values.
        """

        cl = self._test_header["DP1.AXIS.*"]
        assert list(cl.values()) == [1.0, 2.0]
```

## 原始行 67 · command_execution

命令：
```
/bin/bash -lc "sed -n '820,865p' astropy/io/fits/tests/test_header.py
sed -n '1210,1265p' astropy/io/fits/tests/test_header.py
sed -n '2750,2860p' astropy/io/fits/tests/test_header.py"
```

退出码：`0`

输出：
```
        pytest.raises(KeyError, lambda k: header[k], "NAXIS")
        # Test exception with message
        with pytest.raises(KeyError, match=r"Keyword 'NAXIS' not found."):
            header["NAXIS"]

    def test_hierarch_card_lookup(self):
        header = fits.Header()
        header["hierarch abcdefghi"] = 10
        assert "abcdefghi" in header
        assert header["abcdefghi"] == 10
        # This used to be assert_false, but per ticket
        # https://aeon.stsci.edu/ssb/trac/pyfits/ticket/155 hierarch keywords
        # should be treated case-insensitively when performing lookups
        assert "ABCDEFGHI" in header

    def test_hierarch_card_delete(self):
        header = fits.Header()
        header["hierarch abcdefghi"] = 10
        del header["hierarch abcdefghi"]

    def test_hierarch_card_insert_delete(self):
        header = fits.Header()
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header["abcdefghi"] = 10
        header["abcdefgh"] = 10
        header["abcdefg"] = 10
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header.insert(2, ("abcdefghij", 10))
        del header["abcdefghij"]
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header.insert(2, ("abcdefghij", 10))
        del header[2]
        assert list(header.keys())[2] == "abcdefg".upper()

    def test_hierarch_create_and_update(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/158

        Tests several additional use cases for working with HIERARCH cards.
        """

    def test_header_fromkeys(self):
        header = fits.Header.fromkeys(["A", "B"])
        assert "A" in header
        assert header["A"] is None
        assert header.comments["A"] == ""
        assert "B" in header
        assert header["B"] is None
        assert header.comments["B"] == ""

    def test_header_fromkeys_with_value(self):
        header = fits.Header.fromkeys(["A", "B"], "C")
        assert "A" in header
        assert header["A"] == "C"
        assert header.comments["A"] == ""
        assert "B" in header
        assert header["B"] == "C"
        assert header.comments["B"] == ""

    def test_header_fromkeys_with_value_and_comment(self):
        header = fits.Header.fromkeys(["A"], ("B", "C"))
        assert "A" in header
        assert header["A"] == "B"
        assert header.comments["A"] == "C"

    def test_header_fromkeys_with_duplicates(self):
        header = fits.Header.fromkeys(["A", "B", "A"], "C")
        assert "A" in header
        assert ("A", 0) in header
        assert ("A", 1) in header
        assert ("A", 2) not in header
        assert header[0] == "C"
        assert header["A"] == "C"
        assert header[("A", 0)] == "C"
        assert header[2] == "C"
        assert header[("A", 1)] == "C"

    def test_header_items(self):
        header = fits.Header([("A", "B"), ("C", "D")])
        assert list(header.items()) == [("A", "B"), ("C", "D")]

    def test_header_iterkeys(self):
        header = fits.Header([("A", "B"), ("C", "D")])
        for a, b in zip(header.keys(), header):
            assert a == b

    def test_header_itervalues(self):
        header = fits.Header([("A", "B"), ("C", "D")])
        for a, b in zip(header.values(), ["B", "D"]):
            assert a == b

    def test_header_keys(self):
        with fits.open(self.data("arange.fits")) as hdul:
            assert list(hdul[0].header) == [
                "SIMPLE",
                "BITPIX",
        header = hdu.header
        assert header.data_size == 0

        header["BITPIX"] = 32
        header["NAXIS"] = 2
        header["NAXIS1"] = 100
        header["NAXIS2"] = 100
        assert header.data_size == 40000
        assert header.data_size_padded == 40320


class TestRecordValuedKeywordCards(FitsTestCase):
    """
    Tests for handling of record-valued keyword cards as used by the
    `FITS WCS distortion paper
    <https://www.atnf.csiro.au/people/mcalabre/WCS/dcs_20040422.pdf>`__.

    These tests are derived primarily from the release notes for PyFITS 1.4 (in
    which this feature was first introduced.
    Note that extra leading spaces in the `value` fields should be parsed on input,
    but will be stripped in the cards.
    """

    def setup_method(self):
        super().setup_method()
        self._test_header = fits.Header()
        self._test_header.set("DP1", "NAXIS: 2")
        self._test_header.set("DP1", "AXIS.1: 1")
        self._test_header.set("DP1", "AXIS.2: 2")
        self._test_header.set("DP1", "NAUX:   2")
        self._test_header.set("DP1", "AUX.1.COEFF.0: 0")
        self._test_header.set("DP1", "AUX.1.POWER.0: 1")
        self._test_header.set("DP1", "AUX.1.COEFF.1: 0.00048828125")
        self._test_header.set("DP1", "AUX.1.POWER.1:  1")

    def test_initialize_rvkc(self):
        """
        Test different methods for initializing a card that should be
        recognized as a RVKC
        """

        c = fits.Card.fromstring("DP1     = 'NAXIS: 2' / A comment")
        assert c.keyword == "DP1.NAXIS"
        assert c.value == 2.0
        assert c.field_specifier == "NAXIS"
        assert c.comment == "A comment"

        c = fits.Card.fromstring("DP1     = 'NAXIS:  2.1'")
        assert c.keyword == "DP1.NAXIS"
        assert c.value == 2.1
        assert c.field_specifier == "NAXIS"

        c = fits.Card.fromstring("DP1     = 'NAXIS: a'")
        assert c.keyword == "DP1"
        assert c.value == "NAXIS: a"
        assert c.field_specifier is None

        c = fits.Card("DP1", "NAXIS: 2")
        assert c.keyword == "DP1.NAXIS"
        assert c.value == 2.0
        assert c.field_specifier == "NAXIS"

        c = fits.Card("DP1", "NAXIS:  2.0")
        assert c.keyword == "DP1.NAXIS"
        assert c.value == 2.0
        assert c.field_specifier == "NAXIS"

        c = fits.Card("DP1", "NAXIS: a")
        assert c.keyword == "DP1"
        assert c.value == "NAXIS: a"
        assert c.field_specifier is None

        c = fits.Card("DP1.NAXIS", 2)
        assert c.keyword == "DP1.NAXIS"
        assert c.value == 2.0
        assert c.field_specifier == "NAXIS"

        c = fits.Card("DP1.NAXIS", 2.0)
        assert c.keyword == "DP1.NAXIS"
        assert c.value == 2.0
        assert c.field_specifier == "NAXIS"

        with pytest.warns(fits.verify.VerifyWarning):
            c = fits.Card("DP1.NAXIS", "a")
        assert c.keyword == "DP1.NAXIS"
        assert c.value == "a"
        assert c.field_specifier is None

    def test_parse_field_specifier(self):
        """
        Tests that the field_specifier can accessed from a card read from a
        string before any other attributes are accessed.
        """

        c = fits.Card.fromstring("DP1     = 'NAXIS: 2' / A comment")
        assert c.field_specifier == "NAXIS"
        assert c.keyword == "DP1.NAXIS"
        assert c.value == 2.0
        assert c.comment == "A comment"

    def test_update_field_specifier(self):
        """
        Test setting the field_specifier attribute and updating the card image
        to reflect the new value.
        """

        c = fits.Card.fromstring("DP1     = 'NAXIS: 2' / A comment")
        assert c.field_specifier == "NAXIS"
        c.field_specifier = "NAXIS1"
        assert c.field_specifier == "NAXIS1"
        assert c.keyword == "DP1.NAXIS1"
```

## 原始行 70 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"Inserting duplicate\\|already exists in this header\\|duplicate keyword\" astropy | head -100
find . -path './.git' -prune -o -name 'header.py' -print"
```

退出码：`0`

输出：
```
astropy/wcs/wcs.py:499:    3. When the header includes duplicate keywords, in most cases the
astropy/io/fits/diff.py:821:    # except in the case of duplicate keywords.  The order should be checked
astropy/io/fits/diff.py:894:                    # If there are duplicate keywords we need to be able to
astropy/io/fits/header.py:61:    will be returned.  When the header contains cards with duplicate keywords,
astropy/io/fits/header.py:65:    are duplicate keywords.
astropy/io/fits/header.py:1207:            If `True`, ensures that no duplicate keywords are appended;
astropy/io/fits/header.py:1214:            from duplicate keywords in the input header.  This supersedes the
astropy/io/fits/header.py:1494:            the creation of a duplicate keyword. Otherwise a
astropy/io/fits/hdu/compressed/tests/test_compressed.py:685:        # append the duplicate keyword
astropy/io/fits/hdu/compressed/tests/test_compressed.py:695:            # There's no good reason to have a duplicate keyword, but
./astropy/io/fits/header.py
./astropy/io/fits/hdu/compressed/header.py
```

## 原始行 73 · command_execution

命令：
```
/bin/bash -lc "sed -n '630,730p' astropy/io/fits/hdu/compressed/tests/test_compressed.py
sed -n '1,300p' astropy/io/fits/hdu/compressed/header.py
grep -RIn \"_has_data\" astropy/io/fits/hdu/compressed astropy/io/fits/tests | head -100"
```

退出码：`0`

输出：
```
            assert tblhdr.index("BAR") == tblhdr.index("OBJECT") + 1
            assert tblhdr["FOO"] == 2
            assert tblhdr["BAR"] == 3

    def test_compression_header_append_commentary(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/2363
        """

        hdu = fits.CompImageHDU(np.array([0], dtype=np.int32))
        hdu.header["COMMENT"] = "hello world"
        assert hdu.header["COMMENT"] == ["hello world"]
        hdu.writeto(self.temp("test.fits"))

        with fits.open(self.temp("test.fits")) as hdul:
            assert hdul[1].header["COMMENT"] == ["hello world"]

    def test_compression_with_gzip_column(self):
        """
        Regression test for https://github.com/spacetelescope/PyFITS/issues/71
        """

        arr = np.zeros((2, 7000), dtype="float32")

        # The first row (which will be the first compressed tile) has a very
        # wide range of values that will be difficult to quantize, and should
        # result in use of a GZIP_COMPRESSED_DATA column
        arr[0] = np.linspace(0, 1, 7000)
        arr[1] = np.random.normal(size=7000)

        hdu = fits.CompImageHDU(data=arr)
        hdu.writeto(self.temp("test.fits"))

        with fits.open(self.temp("test.fits")) as hdul:
            comp_hdu = hdul[1]

            # GZIP-compressed tile should compare exactly
            assert np.all(comp_hdu.data[0] == arr[0])
            # The second tile uses lossy compression and may be somewhat off,
            # so we don't bother comparing it exactly

    def test_duplicate_compression_header_keywords(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/2750

        Tests that the fake header (for the compressed image) can still be read
        even if the real header contained a duplicate ZTENSION keyword (the
        issue applies to any keyword specific to the compression convention,
        however).
        """

        arr = np.arange(100, dtype=np.int32)
        hdu = fits.CompImageHDU(data=arr)
        hdu.writeto(self.temp("test1.fits"))

        # append the duplicate keyword
        with fits.open(
            self.temp("test1.fits"), disable_image_compression=True
        ) as hdulc:
            hdulc[1].header.append(("ZTENSION", "IMAGE"))
            header = hdulc[1].header
            hdulc.writeto(self.temp("test2.fits"))

        with fits.open(self.temp("test2.fits")) as hdul:
            assert header == hdul[1]._bintable.header
            # There's no good reason to have a duplicate keyword, but
            # technically it isn't invalid either :/
            assert hdul[1]._bintable.header.count("ZTENSION") == 2

    def test_scale_bzero_with_compressed_int_data(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/4600
        and https://github.com/astropy/astropy/issues/4588

        Identical to test_scale_bzero_with_int_data() but uses a compressed
        image.
        """

        a = np.arange(100, 200, dtype=np.int16)

        hdu1 = fits.CompImageHDU(data=a.copy())
        hdu2 = fits.CompImageHDU(data=a.copy())
        # Previously the following line would throw a TypeError,
        # now it should be identical to the integer bzero case
        hdu1.scale("int16", bzero=99.0)
        hdu2.scale("int16", bzero=99)
        assert np.allclose(hdu1.data, hdu2.data)

    def test_scale_back_compressed_uint_assignment(self):
        """
        Extend fix for #4600 to assignment to data

        Identical to test_scale_back_uint_assignment() but uses a compressed
        image.

        Suggested by:
        https://github.com/astropy/astropy/pull/4602#issuecomment-208713748
        """

        a = np.arange(100, 200, dtype=np.uint16)
        fits.CompImageHDU(a).writeto(self.temp("test.fits"))
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import re
import warnings

from astropy.io.fits.column import KEYWORD_NAMES as TABLE_KEYWORD_NAMES
from astropy.io.fits.column import TDEF_RE, ColDefs, Column
from astropy.io.fits.hdu.compressed.compbintable import _CompBinTableHDU
from astropy.io.fits.header import Header
from astropy.io.fits.verify import VerifyWarning
from astropy.utils.exceptions import AstropyDeprecationWarning, AstropyUserWarning

from .settings import (
    CMTYPE_ALIASES,
    COMPRESSION_TYPES,
    DEFAULT_BLOCK_SIZE,
    DEFAULT_BYTE_PIX,
    DEFAULT_COMPRESSION_TYPE,
    DEFAULT_DITHER_SEED,
    DEFAULT_QUANTIZE_METHOD,
    NO_DITHER,
    QUANTIZE_METHOD_NAMES,
    SUBTRACTIVE_DITHER_1,
    SUBTRACTIVE_DITHER_2,
)
from .utils import _validate_tile_shape

__all__ = [
    "CompImageHeader",
    "_bintable_header_to_image_header",
    "_image_header_to_empty_bintable",
]

ZDEF_RE = re.compile(r"(?P<label>^[Zz][a-zA-Z]*)(?P<num>[1-9][0-9 ]*$)?")
INDEXED_COMPRESSION_KEYWORDS = {
    "ZNAXIS",
    "ZTILE",
    "ZNAME",
    "ZVAL",
}
REMAPPED_KEYWORDS = {
    "SIMPLE": "ZSIMPLE",
    "XTENSION": "ZTENSION",
    "BITPIX": "ZBITPIX",
    "NAXIS": "ZNAXIS",
    "EXTEND": "ZEXTEND",
    "BLOCKED": "ZBLOCKED",
    "PCOUNT": "ZPCOUNT",
    "GCOUNT": "ZGCOUNT",
    "CHECKSUM": "ZHECKSUM",
    "DATASUM": "ZDATASUM",
}
COMPRESSION_KEYWORDS = set(REMAPPED_KEYWORDS.values()).union(
    {
        "ZIMAGE",
        "ZCMPTYPE",
        "ZMASKCMP",
        "ZQUANTIZ",
        "ZDITHER0",
        "ZBLANK",
        "ZSCALE",
        "ZZERO",
    }
)


class CompImageHeader(Header):
    def __init__(self, *args, **kwargs):
        warnings.warn(
            "The CompImageHeader class is deprecated and will be removed in future",
            AstropyDeprecationWarning,
        )
        super().__init__(*args, **kwargs)


def _is_reserved_table_keyword(keyword):
    m = TDEF_RE.match(keyword)
    return keyword in ("TFIELDS", "THEAP") or (
        m and m.group("label").upper() in TABLE_KEYWORD_NAMES
    )


def _is_reserved_compression_keyword(keyword):
    m = ZDEF_RE.match(keyword)
    return keyword in COMPRESSION_KEYWORDS or (
        m and m.group("label").upper() in INDEXED_COMPRESSION_KEYWORDS
    )


def _is_reserved_keyword(keyword):
    return _is_reserved_table_keyword(keyword) or _is_reserved_compression_keyword(
        keyword
    )


def _bintable_header_to_image_header(bintable_header):
    # Start with a copy of the table header.
    image_header = bintable_header.copy()

    bscale = image_header.get("BSCALE")
    bzero = image_header.get("BZERO")

    # Strip out special keywords
    image_header.strip()

    # Delete cards that are related to the table.  And move
    # the values of those cards that relate to the image from
    # their corresponding table cards.  These include
    # ZBITPIX -> BITPIX, ZNAXIS -> NAXIS, and ZNAXISn -> NAXISn.
    # (Note: Used set here instead of list in case there are any duplicate
    # keywords, which there may be in some pathological cases:
    # https://github.com/astropy/astropy/issues/2750
    for keyword in set(image_header):
        if _is_reserved_keyword(keyword) or keyword in ("CHECKSUM", "DATASUM"):
            del image_header[keyword]

    if bscale:
        image_header["BSCALE"] = bscale
    if bzero:
        image_header["BZERO"] = bzero

    hcomments = bintable_header.comments

    if "ZSIMPLE" in bintable_header:
        image_header.set(
            "SIMPLE", bintable_header["ZSIMPLE"], hcomments["ZSIMPLE"], before=0
        )
    elif "ZTENSION" in bintable_header:
        if bintable_header["ZTENSION"] != "IMAGE":
            warnings.warn(
                "ZTENSION keyword in compressed extension != 'IMAGE'",
                AstropyUserWarning,
            )
        image_header.set("XTENSION", "IMAGE", hcomments["ZTENSION"], before=0)
    else:
        image_header.set("XTENSION", "IMAGE", before=0)

    image_header.set(
        "BITPIX", bintable_header["ZBITPIX"], hcomments["ZBITPIX"], before=1
    )

    image_header.set("NAXIS", bintable_header["ZNAXIS"], hcomments["ZNAXIS"], before=2)

    last_naxis = "NAXIS"
    for idx in range(image_header["NAXIS"]):
        znaxis = "ZNAXIS" + str(idx + 1)
        naxis = znaxis[1:]
        image_header.set(
            naxis, bintable_header[znaxis], hcomments[znaxis], after=last_naxis
        )
        last_naxis = naxis

    # Delete any other spurious NAXISn keywords:
    naxis = image_header["NAXIS"]
    for keyword in list(image_header["NAXIS?*"]):
        try:
            n = int(keyword[5:])
        except Exception:
            continue

        if n > naxis:
            del image_header[keyword]

    # Although PCOUNT and GCOUNT are considered mandatory for IMAGE HDUs,
    # ZPCOUNT and ZGCOUNT are optional, probably because for IMAGE HDUs
    # their values are always 0 and 1 respectively
    if "ZPCOUNT" in bintable_header:
        image_header.set(
            "PCOUNT",
            bintable_header["ZPCOUNT"],
            hcomments["ZPCOUNT"],
            after=last_naxis,
        )
    else:
        image_header.set("PCOUNT", 0, after=last_naxis)

    if "ZGCOUNT" in bintable_header:
        image_header.set(
            "GCOUNT", bintable_header["ZGCOUNT"], hcomments["ZGCOUNT"], after="PCOUNT"
        )
    else:
        image_header.set("GCOUNT", 1, after="PCOUNT")

    if "ZEXTEND" in bintable_header:
        image_header.set("EXTEND", bintable_header["ZEXTEND"], hcomments["ZEXTEND"])

    if "ZBLOCKED" in bintable_header:
        image_header.set("BLOCKED", bintable_header["ZBLOCKED"], hcomments["ZBLOCKED"])

    # Move the ZHECKSUM and ZDATASUM cards to the image header
    # as CHECKSUM and DATASUM
    if "ZHECKSUM" in bintable_header:
        image_header.set("CHECKSUM", bintable_header["ZHECKSUM"], hcomments["ZHECKSUM"])

    if "ZDATASUM" in bintable_header:
        image_header.set("DATASUM", bintable_header["ZDATASUM"], hcomments["ZDATASUM"])

    # Remove the EXTNAME card if the value in the table header
    # is the default value of COMPRESSED_IMAGE.
    if "EXTNAME" in image_header and image_header["EXTNAME"] == "COMPRESSED_IMAGE":
        del image_header["EXTNAME"]

    # Remove the PCOUNT GCOUNT cards if the uncompressed header is
    # from a primary HDU
    if "SIMPLE" in image_header:
        del image_header["PCOUNT"]
        del image_header["GCOUNT"]

    # Fill in BLANK keyword if necessary
    if image_header["BITPIX"] > 0 and "BLANK" not in image_header:
        if "ZBLANK" in bintable_header:
            image_header["BLANK"] = bintable_header["ZBLANK"]
        else:
            # check for column named "ZBLANK"
            for i in range(1, bintable_header["TFIELDS"] + 1):
                if bintable_header[f"TTYPE{i}"] == "ZBLANK":
                    # required BLANK keyword is missing
                    # use most negative value as default
                    image_header["BLANK"] = -(1 << (image_header["BITPIX"] - 1))
                    warnings.warn(
                        f"Setting default value {image_header['BLANK']} for "
                        "missing BLANK keyword in compressed extension",
                        AstropyUserWarning,
                    )
                    break

    # Look to see if there are any blank cards in the table
    # header.  If there are, there should be the same number
    # of blank cards in the image header.  Add blank cards to
    # the image header to make it so.
    table_blanks = bintable_header._countblanks()
    image_blanks = image_header._countblanks()

    for _ in range(table_blanks - image_blanks):
        image_header.append()

    return image_header


def _image_header_to_empty_bintable(
    image_header,
    name=None,
    huge_hdu=False,
    compression_type=None,
    tile_shape=None,
    hcomp_scale=None,
    hcomp_smooth=None,
    quantize_level=None,
    quantize_method=None,
    dither_seed=None,
    axes=None,
    generate_dither_seed=None,
):
    bintable = _CompBinTableHDU()

    # NOTE: image_header is the header that a user would see as the image
    # header which they might have set things like BSCALE and BZERO on, or
    # added history or comments to.

    # Update the extension name in the table header
    bintable.header.set(
        "EXTNAME",
        name,
        "name of this binary table extension",
        after="TFIELDS",
    )

    # Set the compression type in the table header.
    if compression_type:
        if compression_type not in COMPRESSION_TYPES:
            warnings.warn(
                "Unknown compression type provided (supported are {}). "
                "Default ({}) compression will be used.".format(
                    ", ".join(map(repr, COMPRESSION_TYPES)),
                    DEFAULT_COMPRESSION_TYPE,
                ),
                AstropyUserWarning,
            )
            compression_type = DEFAULT_COMPRESSION_TYPE

        bintable.header.set(
            "ZCMPTYPE", compression_type, "compression algorithm", after="TFIELDS"
        )
    else:
        compression_type = CMTYPE_ALIASES.get(compression_type, compression_type)

    # If the input image header had BSCALE/BZERO cards, then insert
    # them in the table header.

    bzero = image_header.get("BZERO", 0.0)
    bscale = image_header.get("BSCALE", 1.0)
    after_keyword = "EXTNAME"

    if bscale != 1.0:
        bintable.header.set("BSCALE", bscale, after=after_keyword)
        after_keyword = "BSCALE"

    if bzero != 0.0:
        bintable.header.set("BZERO", bzero, after=after_keyword)

astropy/io/fits/hdu/compressed/compressed.py:432:        if self._has_data:
astropy/io/fits/hdu/compressed/compressed.py:558:            and not self._has_data
```

## 原始行 81 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _verify_keywords\\|Column format\" astropy/io/fits/column.py | head -30
sed -n '930,1130p' astropy/io/fits/column.py"
```

退出码：`0`

输出：
```
997:    def _verify_keywords(
1033:                f"Column format option (TFORMn) failed verification: {err!s} "
1040:                "Column format option (TFORMn) must be a string with a valid "
            )

    @ColumnAttribute("TCDLT")
    def coord_inc(col, coord_inc):
        if coord_inc is not None and not isinstance(coord_inc, numbers.Real):
            raise AssertionError("Coordinate increment must be real floating type.")

    @ColumnAttribute("TRPOS")
    def time_ref_pos(col, time_ref_pos):
        if time_ref_pos is not None and not isinstance(time_ref_pos, str):
            raise AssertionError("Time reference position must be a string.")

    format = ColumnAttribute("TFORM")
    unit = ColumnAttribute("TUNIT")
    null = ColumnAttribute("TNULL")
    bscale = ColumnAttribute("TSCAL")
    bzero = ColumnAttribute("TZERO")
    disp = ColumnAttribute("TDISP")
    start = ColumnAttribute("TBCOL")
    dim = ColumnAttribute("TDIM")

    @lazyproperty
    def ascii(self):
        """Whether this `Column` represents a column in an ASCII table."""
        return isinstance(self.format, _AsciiColumnFormat)

    @lazyproperty
    def dtype(self):
        return self.format.dtype

    def copy(self):
        """
        Return a copy of this `Column`.
        """
        tmp = Column(format="I")  # just use a throw-away format
        tmp.__dict__ = self.__dict__.copy()
        return tmp

    @staticmethod
    def _convert_format(format, cls):
        """The format argument to this class's initializer may come in many
        forms.  This uses the given column format class ``cls`` to convert
        to a format of that type.

        TODO: There should be an abc base class for column format classes
        """
        # Short circuit in case we're already a _BaseColumnFormat--there is at
        # least one case in which this can happen
        if isinstance(format, _BaseColumnFormat):
            return format, format.recformat

        if format in NUMPY2FITS:
            with suppress(VerifyError):
                # legit recarray format?
                recformat = format
                format = cls.from_recformat(format)

        try:
            # legit FITS format?
            format = cls(format)
            recformat = format.recformat
        except VerifyError:
            raise VerifyError(f"Illegal format `{format}`.")

        return format, recformat

    @classmethod
    def _verify_keywords(
        cls,
        name=None,
        format=None,
        unit=None,
        null=None,
        bscale=None,
        bzero=None,
        disp=None,
        start=None,
        dim=None,
        ascii=None,
        coord_type=None,
        coord_unit=None,
        coord_ref_point=None,
        coord_ref_value=None,
        coord_inc=None,
        time_ref_pos=None,
    ):
        """
        Given the keyword arguments used to initialize a Column, specifically
        those that typically read from a FITS header (so excluding array),
        verify that each keyword has a valid value.

        Returns a 2-tuple of dicts.  The first maps valid keywords to their
        values.  The second maps invalid keywords to a 2-tuple of their value,
        and a message explaining why they were found invalid.
        """
        valid = {}
        invalid = {}

        try:
            format, recformat = cls._determine_formats(format, start, dim, ascii)
            valid.update(format=format, recformat=recformat)
        except (ValueError, VerifyError) as err:
            msg = (
                f"Column format option (TFORMn) failed verification: {err!s} "
                "The invalid value will be ignored for the purpose of "
                "formatting the data in this column."
            )
            invalid["format"] = (format, msg)
        except AttributeError as err:
            msg = (
                "Column format option (TFORMn) must be a string with a valid "
                f"FITS table format (got {format!s}: {err!s}). "
                "The invalid value will be ignored for the purpose of "
                "formatting the data in this column."
            )
            invalid["format"] = (format, msg)

        # Currently we don't have any validation for name, unit, bscale, or
        # bzero so include those by default
        # TODO: Add validation for these keywords, obviously
        valid |= {
            k: v
            for k, v in [
                ("name", name),
                ("unit", unit),
                ("bscale", bscale),
                ("bzero", bzero),
            ]
            if (v is not None and v != "")
        }

        # Validate null option
        # Note: Enough code exists that thinks empty strings are sensible
        # inputs for these options that we need to treat '' as None
        if null is not None and null != "":
            msg = None
            if isinstance(format, _AsciiColumnFormat):
                null = str(null)
                if len(null) > format.width:
                    msg = (
                        "ASCII table null option (TNULLn) is longer than "
                        "the column's character width and will be truncated "
                        f"(got {null!r})."
                    )
            else:
                tnull_formats = ("B", "I", "J", "K")

                if not _is_int(null):
                    # Make this an exception instead of a warning, since any
                    # non-int value is meaningless
                    msg = (
                        "Column null option (TNULLn) must be an integer for "
                        f"binary table columns (got {null!r}).  The invalid value "
                        "will be ignored for the purpose of formatting "
                        "the data in this column."
                    )

                elif not (
                    format.format in tnull_formats
                    or (
                        format.format in ("P", "Q") and format.p_format in tnull_formats
                    )
                ):
                    # TODO: We should also check that TNULLn's integer value
                    # is in the range allowed by the column's format
                    msg = (
                        "Column null option (TNULLn) is invalid for binary "
                        f"table columns of type {format!r} (got {null!r}).  "
                        "The invalid value will be ignored for the purpose of "
                        "formatting the data in this column."
                    )

            if msg is None:
                valid["null"] = null
            else:
                invalid["null"] = (null, msg)

        # Validate the disp option
        # TODO: Add full parsing and validation of TDISPn keywords
        if disp is not None and disp != "":
            msg = None
            if not isinstance(disp, str):
                msg = (
                    "Column disp option (TDISPn) must be a string (got "
                    f"{disp!r}). The invalid value will be ignored for the "
                    "purpose of formatting the data in this column."
                )

            elif isinstance(format, _AsciiColumnFormat) and disp[0].upper() == "L":
                # disp is at least one character long and has the 'L' format
                # which is not recognized for ASCII tables
                msg = (
                    "Column disp option (TDISPn) may not use the 'L' format "
                    "with ASCII table columns.  The invalid value will be "
                    "ignored for the purpose of formatting the data in this "
                    "column."
                )

            if msg is None:
                try:
                    _parse_tdisp_format(disp)
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _determine_formats\" astropy/io/fits/column.py
sed -n '850,940p' astropy/io/fits/column.py"
```

退出码：`0`

输出：
```
1289:    def _determine_formats(cls, format, start, dim, ascii):
                        # array.
                        if "array" in self.__dict__:
                            del self.__dict__["array"]
                        return

            if getattr(base, "base", None) is not None:
                base = base.base
            else:
                break

        self.__dict__["array"] = array

    @array.deleter
    def array(self):
        try:
            del self.__dict__["array"]
        except KeyError:
            pass

        self._parent_fits_rec = None

    @ColumnAttribute("TTYPE")
    def name(col, name):
        if name is None:
            # Allow None to indicate deleting the name, or to just indicate an
            # unspecified name (when creating a new Column).
            return

        # Check that the name meets the recommended standard--other column
        # names are *allowed*, but will be discouraged
        if isinstance(name, str) and not TTYPE_RE.match(name):
            warnings.warn(
                "It is strongly recommended that column names contain only "
                "upper and lower-case ASCII letters, digits, or underscores "
                "for maximum compatibility with other software "
                f"(got {name!r}).",
                VerifyWarning,
            )

        # This ensures that the new name can fit into a single FITS card
        # without any special extension like CONTINUE cards or the like.
        if not isinstance(name, str) or len(str(Card("TTYPE", name))) != CARD_LENGTH:
            raise AssertionError(
                "Column name must be a string able to fit in a single "
                "FITS card--typically this means a maximum of 68 "
                "characters, though it may be fewer if the string "
                "contains special characters like quotes."
            )

    @ColumnAttribute("TCTYP")
    def coord_type(col, coord_type):
        if coord_type is None:
            return

        if not isinstance(coord_type, str) or len(coord_type) > 8:
            raise AssertionError(
                "Coordinate/axis type must be a string of at most 8 characters."
            )

    @ColumnAttribute("TCUNI")
    def coord_unit(col, coord_unit):
        if coord_unit is not None and not isinstance(coord_unit, str):
            raise AssertionError("Coordinate/axis unit must be a string.")

    @ColumnAttribute("TCRPX")
    def coord_ref_point(col, coord_ref_point):
        if coord_ref_point is not None and not isinstance(
            coord_ref_point, numbers.Real
        ):
            raise AssertionError(
                "Pixel coordinate of the reference point must be real floating type."
            )

    @ColumnAttribute("TCRVL")
    def coord_ref_value(col, coord_ref_value):
        if coord_ref_value is not None and not isinstance(
            coord_ref_value, numbers.Real
        ):
            raise AssertionError(
                "Coordinate value at reference point must be real floating type."
            )

    @ColumnAttribute("TCDLT")
    def coord_inc(col, coord_inc):
        if coord_inc is not None and not isinstance(coord_inc, numbers.Real):
            raise AssertionError("Coordinate increment must be real floating type.")

    @ColumnAttribute("TRPOS")
    def time_ref_pos(col, time_ref_pos):
        if time_ref_pos is not None and not isinstance(time_ref_pos, str):
            raise AssertionError("Time reference position must be a string.")
```

## 原始行 85 · command_execution

命令：
```
/bin/bash -lc "sed -n '1270,1355p' astropy/io/fits/column.py"
```

退出码：`0`

输出：
```
                    invalid[k] = (v, msg)

        if time_ref_pos is not None and time_ref_pos != "":
            msg = None
            if not isinstance(time_ref_pos, str):
                msg = (
                    "Time coordinate reference position option (TRPOSn) must be "
                    f"a string (got {time_ref_pos!r}). The invalid keyword will be "
                    "ignored for the purpose of formatting this column."
                )

            if msg is None:
                valid["time_ref_pos"] = time_ref_pos
            else:
                invalid["time_ref_pos"] = (time_ref_pos, msg)

        return valid, invalid

    @classmethod
    def _determine_formats(cls, format, start, dim, ascii):
        """
        Given a format string and whether or not the Column is for an
        ASCII table (ascii=None means unspecified, but lean toward binary table
        where ambiguous) create an appropriate _BaseColumnFormat instance for
        the column's format, and determine the appropriate recarray format.

        The values of the start and dim keyword arguments are also useful, as
        the former is only valid for ASCII tables and the latter only for
        BINARY tables.
        """
        # If the given format string is unambiguously a Numpy dtype or one of
        # the Numpy record format type specifiers supported by Astropy then that
        # should take priority--otherwise assume it is a FITS format
        if isinstance(format, np.dtype):
            format, _, _ = _dtype_to_recformat(format)

        # check format
        if ascii is None and not isinstance(format, _BaseColumnFormat):
            # We're just give a string which could be either a Numpy format
            # code, or a format for a binary column array *or* a format for an
            # ASCII column array--there may be many ambiguities here.  Try our
            # best to guess what the user intended.
            format, recformat = cls._guess_format(format, start, dim)
        elif not ascii and not isinstance(format, _BaseColumnFormat):
            format, recformat = cls._convert_format(format, _ColumnFormat)
        elif ascii and not isinstance(format, _AsciiColumnFormat):
            format, recformat = cls._convert_format(format, _AsciiColumnFormat)
        else:
            # The format is already acceptable and unambiguous
            recformat = format.recformat

        return format, recformat

    @classmethod
    def _guess_format(cls, format, start, dim):
        if start and dim:
            # This is impossible; this can't be a valid FITS column
            raise ValueError(
                "Columns cannot have both a start (TCOLn) and dim "
                "(TDIMn) option, since the former is only applies to "
                "ASCII tables, and the latter is only valid for binary tables."
            )
        elif start:
            # Only ASCII table columns can have a 'start' option
            guess_format = _AsciiColumnFormat
        elif dim:
            # Only binary tables can have a dim option
            guess_format = _ColumnFormat
        else:
            # If the format is *technically* a valid binary column format
            # (i.e. it has a valid format code followed by arbitrary
            # "optional" codes), but it is also strictly a valid ASCII
            # table format, then assume an ASCII table column was being
            # requested (the more likely case, after all).
            with suppress(VerifyError):
                format = _AsciiColumnFormat(format, strict=True)

            # A safe guess which reflects the existing behavior of previous
            # Astropy versions
            guess_format = _ColumnFormat

        try:
            format, recformat = cls._convert_format(format, guess_format)
        except VerifyError:
            # For whatever reason our guess was wrong (for example if we got
            # just 'F' that's not a valid binary format, but it an ASCII format
```

## 原始行 87 · command_execution

命令：
```
/bin/bash -lc "sed -n '1355,1388p' astropy/io/fits/column.py"
```

退出码：`0`

输出：
```
            # just 'F' that's not a valid binary format, but it an ASCII format
            # code albeit with the width/precision omitted
            guess_format = (
                _AsciiColumnFormat if guess_format is _ColumnFormat else _ColumnFormat
            )
            # If this fails too we're out of options--it is truly an invalid
            # format, or at least not supported
            format, recformat = cls._convert_format(format, guess_format)

        return format, recformat

    def _convert_to_valid_data_type(self, array):
        # Convert the format to a type we understand
        if isinstance(array, Delayed):
            return array
        elif array is None:
            return array
        else:
            format = self.format
            dims = self._dims
            if dims and format.format not in "PQ":
                shape = dims[:-1] if "A" in format else dims
                shape = (len(array),) + shape
                array = array.reshape(shape)

            if "P" in format or "Q" in format:
                return array
            elif "A" in format:
                if array.dtype.char in "SU":
                    if dims:
                        # The 'last' dimension (first in the order given
                        # in the TDIMn keyword itself) is the number of
                        # characters in each string
                        fsize = dims[-1]
```

## 原始行 91 · command_execution

命令：
```
/bin/bash -lc "grep -n \"class VerifyError\" astropy/io/fits/verify.py
sed -n '10,45p' astropy/io/fits/verify.py"
```

退出码：`0`

输出：
```
10:class VerifyError(Exception):
class VerifyError(Exception):
    """
    Verify exception class.
    """


class VerifyWarning(AstropyUserWarning):
    """
    Verify warning class.
    """


VERIFY_OPTIONS = [
    "ignore",
    "warn",
    "exception",
    "fix",
    "silentfix",
    "fix+ignore",
    "fix+warn",
    "fix+exception",
    "silentfix+ignore",
    "silentfix+warn",
    "silentfix+exception",
]


class _Verify:
    """
    Shared methods for verification.
    """

    def run_option(
        self, option="warn", err_text="", fix_text="Fixed.", fix=None, fixable=True
    ):
        """
```

## 原始行 93 · agent_message

```
I’ve identified one additional erased helper, `_useblanks`, that is required by the requested insertion/update paths. I’ll restore it as part of the same narrowly scoped patch so header mutations remain internally consistent.
```

## 原始行 96 · file_change

```
{
  "id": "item_64",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 99 · file_change

```
{
  "id": "item_66",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 102 · file_change

```
{
  "id": "item_68",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 105 · file_change

```
{
  "id": "item_70",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 108 · file_change

```
{
  "id": "item_72",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 111 · file_change

```
{
  "id": "item_74",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 113 · file_change

```
{
  "id": "item_75",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 116 · command_execution

命令：
```
/bin/bash -lc "python -m compileall -q astropy/io/fits/header.py astropy/io/fits/hdu/base.py astropy/io/fits/column.py
python - <<'PY'
from astropy.io import fits
from astropy.io.fits.column import _parse_tformat, _parse_ascii_tformat, _convert_fits2record
h=fits.Header([('A',1,'x'),('A',2,'y'),('COMMENT','z')])
print('header', list(h), h['A'], h[('A',1)], h.comments['A'], ('A',1) in h)
print(_parse_tformat('2J'), _parse_ascii_tformat('F8.2'), _convert_fits2record('10A'), _convert_fits2record('2J'))
print(fits.ImageHDU().header)
PY"
```

退出码：`1`

输出：
```
header ['A', 'A', 'COMMENT'] 1 2 x True
(2, 'J', '') ('F', 8, 2) S10 2i4
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
  File "/testbed/astropy/io/fits/header.py", line 280, in __str__
    return self.tostring()
           ^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/header.py", line 679, in tostring
    s = str(card)
        ^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 213, in __str__
    return self.image
           ^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 529, in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 997, in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 980, in _format_value
    value = _format_value(value)
            ^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 1284, in _format_value
    elif _is_int(value):
         ^^^^^^^
NameError: name '_is_int' is not defined
```

## 原始行 119 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _is_int\\|_is_int\" astropy/io/fits/card.py astropy/io/fits/util.py astropy/io/fits/hdu/base.py | head -50
grep -RIn \"def _is_int\" astropy/io/fits | head -20
git diff --stat
git status --short"
```

退出码：`0`

输出：
```
astropy/io/fits/card.py:1284:    elif _is_int(value):
astropy/io/fits/hdu/base.py:239:        if not _is_int(value):
astropy/io/fits/hdu/base.py:252:        if not _is_int(value):
astropy/io/fits/hdu/base.py:973:            "BITPIX", 1, lambda v: (_is_int(v) and is_valid(v)), 8, option, errs
astropy/io/fits/hdu/base.py:976:            "NAXIS", 2, lambda v: (_is_int(v) and 0 <= v <= 999), 0, option, errs
astropy/io/fits/hdu/base.py:986:                    lambda v: (_is_int(v) and v >= 0),
astropy/io/fits/hdu/base.py:1108:        if _is_int(pos):
astropy/io/fits/hdu/base.py:1553:            "PCOUNT", naxis + 3, lambda v: (_is_int(v) and v >= 0), 0, option, errs
astropy/io/fits/hdu/base.py:1556:            "GCOUNT", naxis + 4, lambda v: (_is_int(v) and v == 1), 1, option, errs
 astropy/io/fits/column.py   |  91 ++++++++++++++-
 astropy/io/fits/hdu/base.py |   6 +-
 astropy/io/fits/header.py   | 273 +++++++++++++++++++++++++++++++++++---------
 3 files changed, 312 insertions(+), 58 deletions(-)
 M astropy/io/fits/column.py
 M astropy/io/fits/hdu/base.py
 M astropy/io/fits/header.py
```

## 原始行 122 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,120p' astropy/io/fits/card.py
sed -n '1,90p' astropy/io/fits/hdu/base.py
grep -RIn \"_is_int =\\|isinstance.*numbers.Integral\" astropy/io/fits/card.py astropy/io/fits/hdu/base.py | head -40"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import re
import warnings

import numpy as np

from astropy.utils.exceptions import AstropyUserWarning

from . import conf
from .util import _str_to_num, _words_group, translate
from .verify import VerifyError, VerifyWarning, _ErrList, _Verify

__all__ = ["Card", "Undefined"]


FIX_FP_TABLE = str.maketrans("de", "DE")
FIX_FP_TABLE2 = str.maketrans("dD", "eE")


CARD_LENGTH = 80
BLANK_CARD = " " * CARD_LENGTH
KEYWORD_LENGTH = 8  # The max length for FITS-standard keywords

VALUE_INDICATOR = "= "  # The standard FITS value indicator
VALUE_INDICATOR_LEN = len(VALUE_INDICATOR)
HIERARCH_VALUE_INDICATOR = "="  # HIERARCH cards may use a shortened indicator


class Undefined:
    """Undefined value."""

    def __init__(self):
        # This __init__ is required to be here for Sphinx documentation
        pass


UNDEFINED = Undefined()


class Card(_Verify):
    length = CARD_LENGTH
    """The length of a Card image; should always be 80 for valid FITS files."""

    # String for a FITS standard compliant (FSC) keyword.
    _keywd_FSC_RE = re.compile(r"^[A-Z0-9_-]{0,%d}$" % KEYWORD_LENGTH)  # noqa: UP031, RUF100
    # This will match any printable ASCII character excluding '='
    _keywd_hierarch_RE = re.compile(
        r"^(?:HIERARCH +)?(?:^[ -<>-~]+ ?)+$", re.IGNORECASE
    )

    # A number sub-string, either an integer or a float in fixed or
    # scientific notation.  One for FSC and one for non-FSC (NFSC) format:
    # NFSC allows lower case of DE for exponent, allows space between sign,
    # digits, exponent sign, and exponents
    _digits_FSC = r"(\.\d+|\d+(\.\d*)?)([DE][+-]?\d+)?"
    _digits_NFSC = r"(\.\d+|\d+(\.\d*)?) *([deDE] *[+-]? *\d+)?"
    _numr_FSC = r"[+-]?" + _digits_FSC
    _numr_NFSC = r"[+-]? *" + _digits_NFSC

    # This regex helps delete leading zeros from numbers, otherwise
    # Python might evaluate them as octal values (this is not-greedy, however,
    # so it may not strip leading zeros from a float, which is fine)
    _number_FSC_RE = re.compile(rf"(?P<sign>[+-])?0*?(?P<digt>{_digits_FSC})")
    _number_NFSC_RE = re.compile(rf"(?P<sign>[+-])? *0*?(?P<digt>{_digits_NFSC})")

    # Used in cards using the CONTINUE convention which expect a string
    # followed by an optional comment
    _strg = r"\'(?P<strg>([ -~]+?|\'\'|) *?)\'(?=$|/| )"
    _comm_field = r"(?P<comm_field>(?P<sepr>/ *)(?P<comm>(.|\n)*))"
    _strg_comment_RE = re.compile(f"({_strg})? *{_comm_field}?$")

    # FSC commentary card string which must contain printable ASCII characters.
    # Note: \Z matches the end of the string without allowing newlines
    _ascii_text_re = re.compile(r"[ -~]*\Z")

    # Checks for a valid value/comment string.  It returns a match object
    # for a valid value/comment string.
    # The value group will return a match if a FITS string, boolean,
    # number, or complex value is found, otherwise it will return
    # None, meaning the keyword is undefined.  The comment field will
    # return a match if the comment separator is found, though the
    # comment maybe an empty string.
    # fmt: off
    _value_FSC_RE = re.compile(
        r'(?P<value_field> *'
            r'(?P<value>'

                #  The <strg> regex is not correct for all cases, but
                #  it comes pretty darn close.  It appears to find the
                #  end of a string rather well, but will accept
                #  strings with an odd number of single quotes,
                #  instead of issuing an error.  The FITS standard
                #  appears vague on this issue and only states that a
                #  string should not end with two single quotes,
                #  whereas it should not end with an even number of
                #  quotes to be precise.
                #
                #  Note that a non-greedy match is done for a string,
                #  since a greedy match will find a single-quote after
                #  the comment separator resulting in an incorrect
                #  match.
                rf'{_strg}|'
                r'(?P<bool>[FT])|'
                r'(?P<numr>' + _numr_FSC + r')|'
                r'(?P<cplx>\( *'
                    r'(?P<real>' + _numr_FSC + r') *, *'
                    r'(?P<imag>' + _numr_FSC + r') *\))'
            r')? *)'
        r'(?P<comm_field>'
            r'(?P<sepr>/ *)'
            r'(?P<comm>[!-~][ -~]*)?'
        r')?$'
    )
    # fmt: on

    # fmt: off
    _value_NFSC_RE = re.compile(
        r'(?P<value_field> *'
            r'(?P<value>'
# Licensed under a 3-clause BSD style license - see PYFITS.rst


import datetime
import numbers
import os
import sys
import warnings
from contextlib import suppress
from inspect import Parameter, signature

import numpy as np

from astropy.io.fits import conf
from astropy.io.fits.file import _File
from astropy.io.fits.header import Header, _BasicHeader, _DelayedHeader, _pad_length
from astropy.io.fits.util import _extract_number, _free_space_check, _get_array_mmap, decode_ascii, first, itersubclasses








from astropy.io.fits.verify import _ErrList, _Verify
from astropy.utils import lazyproperty
from astropy.utils.exceptions import AstropyUserWarning

__all__ = [
    "DELAYED",
    "ExtensionHDU",
    # classes
    "InvalidHDUException",
    "NonstandardExtHDU",
]


class _Delayed:
    pass


DELAYED = _Delayed()


BITPIX2DTYPE = {
    8: "uint8",
    16: "int16",
    32: "int32",
    64: "int64",
    -32: "float32",
    -64: "float64",
}
"""Maps FITS BITPIX values to Numpy dtype names."""

DTYPE2BITPIX = {
    "int8": 8,
    "uint8": 8,
    "int16": 16,
    "uint16": 16,
    "int32": 32,
    "uint32": 32,
    "int64": 64,
    "uint64": 64,
    "float32": -32,
    "float64": -64,
}
"""
Maps Numpy dtype names to FITS BITPIX values (this includes unsigned
integers, with the assumption that the pseudo-unsigned integer convention
will be used in this case.
"""


class InvalidHDUException(Exception):
    """
    A custom exception class used mainly to signal to _BaseHDU.__new__ that
    an HDU cannot possibly be considered valid, and must be assumed to be
    corrupted.
    """


def _hdu_class_from_header(cls, header):
    """
    Iterates through the subclasses of _BaseHDU and uses that class's
    match_header() method to determine which subclass to instantiate.

    It's important to be aware that the class hierarchy is traversed in a
    depth-last order.  Each match_header() should identify an HDU type as
    uniquely as possible.  Abstract types may choose to simply return False
astropy/io/fits/hdu/base.py:550:        if isinstance(shape, numbers.Integral):
```

## 原始行 125 · command_execution

命令：
```
/bin/bash -lc 'grep -RIn "def _is_int" astropy/io/fits astropy | head -50
grep -RIn "_is_int" astropy/io/fits | head -100'
```

退出码：`0`

输出：
```
astropy/nddata/bitmask.py:48:def _is_int(n):
astropy/io/fits/card.py:1284:    elif _is_int(value):
astropy/io/fits/column.py:1077:                if not _is_int(null):
astropy/io/fits/column.py:1159:                if not _is_int(start) or start < 1:
astropy/io/fits/column.py:1758:        if _is_int(key):
astropy/io/fits/column.py:2145:    if _is_int(key):
astropy/io/fits/convenience.py:1073:        if _is_int(args[0]) or (isinstance(ext, tuple) and len(ext) == 2):
astropy/io/fits/convenience.py:1097:        _is_int(ext)
astropy/io/fits/convenience.py:1102:            and _is_int(ext[1])
astropy/io/fits/convenience.py:1111:    if extver is not None and not _is_int(extver):
astropy/io/fits/hdu/base.py:239:        if not _is_int(value):
astropy/io/fits/hdu/base.py:252:        if not _is_int(value):
astropy/io/fits/hdu/base.py:973:            "BITPIX", 1, lambda v: (_is_int(v) and is_valid(v)), 8, option, errs
astropy/io/fits/hdu/base.py:976:            "NAXIS", 2, lambda v: (_is_int(v) and 0 <= v <= 999), 0, option, errs
astropy/io/fits/hdu/base.py:986:                    lambda v: (_is_int(v) and v >= 0),
astropy/io/fits/hdu/base.py:1108:        if _is_int(pos):
astropy/io/fits/hdu/base.py:1553:            "PCOUNT", naxis + 3, lambda v: (_is_int(v) and v >= 0), 0, option, errs
astropy/io/fits/hdu/base.py:1556:            "GCOUNT", naxis + 4, lambda v: (_is_int(v) and v == 1), 1, option, errs
astropy/io/fits/hdu/image.py:594:        if not _is_int(self._blank):
astropy/io/fits/hdu/image.py:1021:            if not _is_int(key[idx]):
astropy/io/fits/hdu/image.py:1270:            "PCOUNT", naxis + 3, lambda v: (_is_int(v) and v == 0), 0, option, errs
astropy/io/fits/hdu/image.py:1277:        if _is_int(index):
astropy/io/fits/hdu/hdulist.py:422:            if _is_int(_key):
astropy/io/fits/hdu/hdulist.py:824:        if _is_int(key):
astropy/io/fits/hdu/compressed/compressed.py:609:        if not _is_int(seed):
astropy/io/fits/hdu/table.py:540:                lambda v: (_is_int(v) and v >= 0 and v <= 999),
astropy/io/fits/hdu/table.py:793:            self.req_cards("TBCOL" + str(idx + 1), None, _is_int, None, option, errs)
astropy/io/fits/hdu/groups.py:42:        if _is_int(parname):
astropy/io/fits/hdu/groups.py:62:        if _is_int(parname):
astropy/io/fits/hdu/groups.py:249:        if _is_int(parname):
astropy/io/fits/hdu/groups.py:511:            "NAXIS", 2, lambda v: (_is_int(v) and 1 <= v <= 999), 1, option, errs
astropy/io/fits/hdu/groups.py:513:        self.req_cards("NAXIS1", 3, lambda v: (_is_int(v) and v == 0), 0, option, errs)
astropy/io/fits/hdu/groups.py:518:        self.req_cards("GCOUNT", pos, _is_int, 1, option, errs)
astropy/io/fits/hdu/groups.py:519:        self.req_cards("PCOUNT", pos, _is_int, 0, option, errs)
```

## 原始行 128 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _extract_number\\|def _is_int\\|__all__\" astropy/io/fits/util.py | head -40
sed -n '1,110p' astropy/io/fits/util.py
grep -RIn \"from .* import .*_is_int\" astropy/io/fits | head -100"
```

退出码：`0`

输出：
```
811:def _extract_number(value, default):
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import gzip
import io
import mmap
import operator
import os
import platform
import signal
import sys
import tempfile
import textwrap
import threading
import warnings
import weakref
from contextlib import contextmanager, suppress
from functools import wraps

import numpy as np
from packaging.version import Version

from astropy.utils import data
from astropy.utils.compat.optional_deps import HAS_DASK
from astropy.utils.exceptions import AstropyUserWarning

path_like = (str, bytes, os.PathLike)

cmp = lambda a, b: (a > b) - (a < b)

all_integer_types = (int, np.integer)


class NotifierMixin:
    """
    Mixin class that provides services by which objects can register
    listeners to changes on that object.

    All methods provided by this class are underscored, since this is intended
    for internal use to communicate between classes in a generic way, and is
    not machinery that should be exposed to users of the classes involved.

    Use the ``_add_listener`` method to register a listener on an instance of
    the notifier.  This registers the listener with a weak reference, so if
    no other references to the listener exist it is automatically dropped from
    the list and does not need to be manually removed.

    Call the ``_notify`` method on the notifier to update all listeners
    upon changes.  ``_notify('change_type', *args, **kwargs)`` results
    in calling ``listener._update_change_type(*args, **kwargs)`` on all
    listeners subscribed to that notifier.

    If a particular listener does not have the appropriate update method
    it is ignored.

    Examples
    --------
    >>> class Widget(NotifierMixin):
    ...     state = 1
    ...     def __init__(self, name):
    ...         self.name = name
    ...     def update_state(self):
    ...         self.state += 1
    ...         self._notify('widget_state_changed', self)
    ...
    >>> class WidgetListener:
    ...     def _update_widget_state_changed(self, widget):
    ...         print('Widget {0} changed state to {1}'.format(
    ...             widget.name, widget.state))
    ...
    >>> widget = Widget('fred')
    >>> listener = WidgetListener()
    >>> widget._add_listener(listener)
    >>> widget.update_state()
    Widget fred changed state to 2
    """

    _listeners = None

    def _add_listener(self, listener):
        """
        Add an object to the list of listeners to notify of changes to this
        object.  This adds a weakref to the list of listeners that is
        removed from the listeners list when the listener has no other
        references to it.
        """
        if self._listeners is None:
            self._listeners = weakref.WeakValueDictionary()

        self._listeners[id(listener)] = listener

    def _remove_listener(self, listener):
        """
        Removes the specified listener from the listeners list.  This relies
        on object identity (i.e. the ``is`` operator).
        """
        if self._listeners is None:
            return

        with suppress(KeyError):
            del self._listeners[id(listener)]

    def _notify(self, notification, *args, **kwargs):
        """
        Notify all listeners of some particular state change by calling their
        ``_update_<notification>`` method with the given ``*args`` and
        ``**kwargs``.

        The notification does not by default include the object that actually
        changed (``self``), but it certainly may if required.
        """
```

## 原始行 131 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,70p' astropy/io/fits/convenience.py
sed -n '1,55p' astropy/io/fits/hdu/image.py
sed -n '1,45p' astropy/io/fits/hdu/hdulist.py
grep -RIn \"all_integer_types\" astropy/io/fits | head -50"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

"""Convenience functions for working with FITS files.

Convenience functions
=====================

The functions in this module provide shortcuts for some of the most basic
operations on FITS files, such as reading and updating the header.  They are
included directly in the 'astropy.io.fits' namespace so that they can be used
like::

    astropy.io.fits.getheader(...)

These functions are primarily for convenience when working with FITS files in
the command-line interpreter.  If performing several operations on the same
file, such as in a script, it is better to *not* use these functions, as each
one must open and re-parse the file.  In such cases it is better to use
:func:`astropy.io.fits.open` and work directly with the
:class:`astropy.io.fits.HDUList` object and underlying HDU objects.

Several of the convenience functions, such as `getheader` and `getdata` support
special arguments for selecting which HDU to use when working with a
multi-extension FITS file.  There are a few supported argument formats for
selecting the HDU.  See the documentation for `getdata` for an
explanation of all the different formats.

.. warning::
    All arguments to convenience functions other than the filename that are
    *not* for selecting the HDU should be passed in as keyword
    arguments.  This is to avoid ambiguity and conflicts with the
    HDU arguments.  For example, to set NAXIS=1 on the Primary HDU:

    Wrong::

        astropy.io.fits.setval('myimage.fits', 'NAXIS', 1)

    The above example will try to set the NAXIS value on the first extension
    HDU to blank.  That is, the argument '1' is assumed to specify an
    HDU.

    Right::

        astropy.io.fits.setval('myimage.fits', 'NAXIS', value=1)

    This will set the NAXIS keyword to 1 on the primary HDU (the default).  To
    specify the first extension HDU use::

        astropy.io.fits.setval('myimage.fits', 'NAXIS', value=1, ext=1)

    This complexity arises out of the attempt to simultaneously support
    multiple argument formats that were used in past versions of PyFITS.
    Unfortunately, it is not possible to support all formats without
    introducing some ambiguity.  A future Astropy release may standardize
    around a single format and officially deprecate the other formats.
"""

import operator
import os
import warnings

import numpy as np

from astropy.utils.exceptions import AstropyUserWarning

from .diff import FITSDiff, HDUDiff
from .file import FILE_MODES, _File
from .hdu.base import _BaseHDU, _ValidHDU
from .hdu.hdulist import HDUList, fitsopen
from .hdu.image import ImageHDU, PrimaryHDU
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import mmap
import sys
import warnings

import numpy as np

from astropy.io.fits.header import Header
from astropy.io.fits.util import _is_dask_array, _pseudo_zero





from astropy.io.fits.verify import VerifyWarning
from astropy.utils import lazyproperty

from .base import BITPIX2DTYPE, DELAYED, DTYPE2BITPIX, ExtensionHDU, _ValidHDU

__all__ = ["ImageHDU", "PrimaryHDU", "Section"]


class _ImageBaseHDU(_ValidHDU):
    """FITS image HDU base class.

    Attributes
    ----------
    header
        image header

    data
        image data
    """

    standard_keyword_comments = {
        "SIMPLE": "conforms to FITS standard",
        "XTENSION": "Image extension",
        "BITPIX": "array data type",
        "NAXIS": "number of array dimensions",
        "GROUPS": "has groups",
        "PCOUNT": "number of parameters",
        "GCOUNT": "number of groups",
    }

    def __init__(
        self,
        data=None,
        header=None,
        do_not_scale_image_data=False,
        uint=True,
        scale_back=False,
        ignore_blank=False,
        **kwargs,
    ):
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import gzip
import itertools
import os
import re
import shutil
import sys
import warnings
from textwrap import indent

import numpy as np

from astropy.io.fits.file import FILE_MODES, _File
from astropy.io.fits.header import _pad_length
from astropy.io.fits.util import _free_space_check, _get_array_mmap, _tmp_name, fileobj_closed, fileobj_mode, ignore_sigint, isfile









from astropy.io.fits.verify import VerifyError, VerifyWarning, _ErrList, _Verify
from astropy.utils.compat.numpycompat import NUMPY_LT_2_0

# NOTE: Python can be built without bz2.
from astropy.utils.exceptions import AstropyUserWarning

from .base import ExtensionHDU, _BaseHDU, _NonstandardHDU, _ValidHDU
from .compressed.compressed import CompImageHDU
from .groups import GroupsHDU
from .image import ImageHDU, PrimaryHDU
from .table import BinTableHDU

__all__ = ["HDUList", "fitsopen"]

# FITS file signature as per RFC 4047
FITS_SIGNATURE = b"SIMPLE  =                    T"


def fitsopen(
    name,
astropy/io/fits/util.py:30:all_integer_types = (int, np.integer)
```

## 原始行 134 · command_execution

命令：
```
/bin/bash -lc 'grep -n "from .*util import" astropy/io/fits/convenience.py astropy/io/fits/hdu/{image,hdulist,table,groups}.py astropy/io/fits/hdu/compressed/compressed.py'
```

退出码：`0`

输出：
```
astropy/io/fits/convenience.py:73:from .util import _is_dask_array, fileobj_closed, fileobj_mode, fileobj_name, path_like
astropy/io/fits/hdu/image.py:10:from astropy.io.fits.util import _is_dask_array, _pseudo_zero
astropy/io/fits/hdu/hdulist.py:16:from astropy.io.fits.util import _free_space_check, _get_array_mmap, _tmp_name, fileobj_closed, fileobj_mode, ignore_sigint, isfile
astropy/io/fits/hdu/table.py:38:from astropy.io.fits.util import _str_to_num, path_like
astropy/io/fits/hdu/groups.py:9:from astropy.io.fits.util import _pseudo_zero
```

## 原始行 137 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,60p' astropy/io/fits/hdu/compressed/compressed.py
sed -n '1,55p' astropy/io/fits/hdu/table.py
sed -n '1,25p' astropy/io/fits/hdu/groups.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import ctypes
import math
import time
import warnings

import numpy as np

from astropy.io.fits.fitsrec import FITS_rec
from astropy.io.fits.hdu.base import BITPIX2DTYPE, DELAYED
from astropy.io.fits.hdu.compressed._quantization import DITHER_METHODS
from astropy.io.fits.hdu.compressed._tiled_compression import (
    _get_compression_setting,
    compress_image_data,
)
from astropy.io.fits.hdu.compressed.utils import _tile_shape, _validate_tile_shape
from astropy.io.fits.hdu.image import ImageHDU
from astropy.io.fits.header import Header

from astropy.io.fits.verify import _ErrList
from astropy.utils.decorators import lazyproperty
from astropy.utils.exceptions import AstropyUserWarning

from .header import (
    _bintable_header_to_image_header,
    _image_header_to_empty_bintable,
)
from .section import CompImageSection
from .settings import (
    CMTYPE_ALIASES,
    COMPRESSION_TYPES,
    DEFAULT_COMPRESSION_TYPE,
    DEFAULT_DITHER_SEED,
    DEFAULT_HCOMP_SCALE,
    DEFAULT_HCOMP_SMOOTH,
    DEFAULT_QUANTIZE_LEVEL,
    DEFAULT_QUANTIZE_METHOD,
    DITHER_SEED_CHECKSUM,
    DITHER_SEED_CLOCK,
)

__all__ = ["CompImageHDU"]


class CompImageHDU(ImageHDU):
    """
    Compressed Image HDU class.
    """

    _default_name = "COMPRESSED_IMAGE"

    def __init__(
        self,
        data=None,
        header=None,
        name=None,
        compression_type=DEFAULT_COMPRESSION_TYPE,
        tile_shape=None,
        hcomp_scale=DEFAULT_HCOMP_SCALE,
# Licensed under a 3-clause BSD style license - see PYFITS.rst


import contextlib
import csv
import operator
import os
import re
import sys
import textwrap
from contextlib import suppress

import numpy as np
from numpy import char as chararray

# This module may have many dependencies on astropy.io.fits.column, but
# astropy.io.fits.column has fewer dependencies overall, so it's easier to
# keep table/column-related utilities in astropy.io.fits.column
from astropy.io.fits.column import ATTRIBUTE_TO_KEYWORD, FITS2NUMPY, KEYWORD_NAMES, KEYWORD_TO_ATTRIBUTE, TDEF_RE, ColDefs, Column, _AsciiColDefs, _cmp_recformats, _convert_format, _FormatP, _FormatQ, _makep, _scalar_to_format
















from astropy.io.fits.fitsrec import FITS_rec, _get_recarray_field, _has_unicode_fields
from astropy.io.fits.header import Header, _pad_length
from astropy.io.fits.util import _str_to_num, path_like
from astropy.utils import lazyproperty

from .base import DELAYED, ExtensionHDU, _ValidHDU


class FITSTableDumpDialect(csv.excel):
    """
    A CSV dialect for the Astropy format of ASCII dumps of FITS tables.
    """

    delimiter = " "
    lineterminator = "\n"
    quotechar = '"'
    quoting = csv.QUOTE_ALL
    skipinitialspace = True


# Licensed under a 3-clause BSD style license - see PYFITS.rst

import sys

import numpy as np

from astropy.io.fits.column import FITS2NUMPY, ColDefs, Column
from astropy.io.fits.fitsrec import FITS_rec, FITS_record
from astropy.io.fits.util import _pseudo_zero
from astropy.utils import lazyproperty

from .base import DELAYED, DTYPE2BITPIX
from .image import PrimaryHDU
from .table import _TableLikeHDU


class Group(FITS_record):
    """
    One group of the random group data.
    """

    def __init__(self, input, row=0, start=None, end=None, step=None, base=None):
        super().__init__(input, row, start, end, step, base)

    @property
```

## 原始行 139 · agent_message

```
A baseline helper used throughout FITS (`_is_int`) is also absent, causing even basic card serialization to fail before the requested code can be exercised. I’m restoring that small shared predicate and its existing consumers, then I’ll return to behavioral test failures.
```

## 原始行 141 · file_change

```
{
  "id": "item_94",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/card.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/convenience.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/compressed/compressed.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/groups.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/hdulist.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/image.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 143 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io import fits
h=fits.ImageHDU()
print(list(h.header), h._has_data)
print(str(h.header)[:80])
PY
python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=20"
```

退出码：`1`

输出：
```
['XTENSION', 'BITPIX', 'NAXIS', 'PCOUNT', 'GCOUNT'] False
XTENSION= 'IMAGE   '           / Image extension                                
Internet access disabled
............FFF.....F................................................... [ 40%]
.......FF...........................................FFF.F...F........F.. [ 80%]
...................F.F......F.FFFF.                                      [100%]
=================================== FAILURES ===================================
______________ TestHeaderFunctions.test_floating_point_value_card ______________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec561390>

    def test_floating_point_value_card(self):
        """Test Card constructor with floating point value"""
    
        c = fits.Card("floatnum", -467374636747637647347374734737437.0)
    
>       if str(c) != _pad("FLOATNUM= -4.6737463674763E+32") and str(c) != _pad(
           ^^^^^^
            "FLOATNUM= -4.6737463674763E+032"
        ):

astropy/io/fits/tests/test_header.py:136: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/card.py:213: in __str__
    return self.image
           ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:997: in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:980: in _format_value
    value = _format_value(value)
            ^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

value = -4.673746367476376e+32

    def _format_value(value):
        """
        Converts a card value to its appropriate string representation as
        defined by the FITS format.
        """
        # string value should occupies at least 8 columns, unless it is
        # a null string
        if isinstance(value, str):
            if value == "":
                return "''"
            else:
                exp_val_str = value.replace("'", "''")
                val_str = f"'{exp_val_str:8}'"
                return f"{val_str:20}"
    
        # must be before int checking since bool is also int
        elif isinstance(value, (bool, np.bool_)):
            return f"{repr(value)[0]:>20}"  # T or F
    
        elif _is_int(value):
            return f"{value:>20d}"
    
        elif isinstance(value, (float, np.floating)):
>           return f"{_format_float(value):>20}"
                      ^^^^^^^^^^^^^
E           NameError: name '_format_float' is not defined

astropy/io/fits/card.py:1288: NameError
______ TestHeaderFunctions.test_floating_point_string_representation_card ______

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec562b10>

    def test_floating_point_string_representation_card(self):
        """
        Ensures Card formats float values with the correct precision, avoiding
        comment truncation
    
        Regression test for https://github.com/astropy/astropy/issues/14507
        """
        k = "HIERARCH ABC DEF GH IJKLMN"
        com = "[m] abcdef ghijklm nopqrstu vw xyzab"
        c = fits.Card(k, 0.009125, com)
        expected_str = f"{k} = 0.009125 / {com}"
>       assert str(c)[: len(expected_str)] == expected_str
               ^^^^^^

astropy/io/fits/tests/test_header.py:152: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/card.py:213: in __str__
    return self.image
           ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:997: in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:980: in _format_value
    value = _format_value(value)
            ^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

value = 0.009125

    def _format_value(value):
        """
        Converts a card value to its appropriate string representation as
        defined by the FITS format.
        """
        # string value should occupies at least 8 columns, unless it is
        # a null string
        if isinstance(value, str):
            if value == "":
                return "''"
            else:
                exp_val_str = value.replace("'", "''")
                val_str = f"'{exp_val_str:8}'"
                return f"{val_str:20}"
    
        # must be before int checking since bool is also int
        elif isinstance(value, (bool, np.bool_)):
            return f"{repr(value)[0]:>20}"  # T or F
    
        elif _is_int(value):
            return f"{value:>20d}"
    
        elif isinstance(value, (float, np.floating)):
>           return f"{_format_float(value):>20}"
                      ^^^^^^^^^^^^^
E           NameError: name '_format_float' is not defined

astropy/io/fits/card.py:1288: NameError
_________________ TestHeaderFunctions.test_complex_value_card __________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec562e50>

    def test_complex_value_card(self):
        """Test Card constructor with complex value"""
    
        c = fits.Card("abc", (1.2345377437887837487e88 + 6324767364763746367e-33j))
        f1 = _pad("ABC     = (1.23453774378878E+88, 6.32476736476374E-15)")
        f2 = _pad("ABC     = (1.2345377437887E+088, 6.3247673647637E-015)")
        f3 = _pad("ABC     = (1.23453774378878E+88, 6.32476736476374E-15)")
>       if str(c) != f1 and str(c) != f2:
           ^^^^^^

astropy/io/fits/tests/test_header.py:169: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/card.py:213: in __str__
    return self.image
           ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:997: in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:980: in _format_value
    value = _format_value(value)
            ^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

value = (1.2345377437887837e+88+6.3247673647637465e-15j)

    def _format_value(value):
        """
        Converts a card value to its appropriate string representation as
        defined by the FITS format.
        """
        # string value should occupies at least 8 columns, unless it is
        # a null string
        if isinstance(value, str):
            if value == "":
                return "''"
            else:
                exp_val_str = value.replace("'", "''")
                val_str = f"'{exp_val_str:8}'"
                return f"{val_str:20}"
    
        # must be before int checking since bool is also int
        elif isinstance(value, (bool, np.bool_)):
            return f"{repr(value)[0]:>20}"  # T or F
    
        elif _is_int(value):
            return f"{value:>20d}"
    
        elif isinstance(value, (float, np.floating)):
            return f"{_format_float(value):>20}"
    
        elif isinstance(value, (complex, np.complexfloating)):
>           val_str = f"({_format_float(value.real)}, {_format_float(value.imag)})"
                          ^^^^^^^^^^^^^
E           NameError: name '_format_float' is not defined

astropy/io/fits/card.py:1291: NameError
______________________ TestHeaderFunctions.test_add_blank ______________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec568dd0>

    def test_add_blank(self):
        header = fits.Header(
            [("A", "B", "C"), ("", 1), ("", 2), ("", 3), ("", "", ""), ("", "", "")]
        )
        header.add_blank(4)
        # This time a new blank should be added, and the existing blanks don't
        # get used... (though this is really kinda sketchy--there's a
        # distinction between truly blank cards, and cards with blank keywords
        # that isn't currently made int he code)
>       assert len(header) == 7
E       AssertionError: assert 6 == 7
E        +  where 6 = len(A       = 'B       '           / C                                              \n        1                            ...                                      \n                                                                                )

astropy/io/fits/tests/test_header.py:251: AssertionError
____________ TestHeaderFunctions.test_header_clear_write[fitsext0] _____________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec5981d0>
fitsext = <astropy.io.fits.hdu.image.ImageHDU object at 0x7539ec6fe950>

    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
    def test_header_clear_write(self, fitsext):
        hdulist = fits.HDUList([fits.PrimaryHDU(), fitsext])
        hdulist[1].header["FOO"] = "BAR"
        hdulist[1].header.clear()
        with pytest.raises(VerifyError) as err:
>           hdulist.writeto(self.temp("temp.fits"), overwrite=True)

astropy/io/fits/tests/test_header.py:1207: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:1038: in writeto
    self.verify(option=output_verify)
astropy/io/fits/verify.py:82: in verify
    errs = self._verify(opt)
           ^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:1442: in _verify
    result = hdu._verify(option)
             ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1264: in _verify
    errs = super()._verify(option=option)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:579: in _verify
    self.update_header()
astropy/io/fits/hdu/image.py:342: in update_header
    self._header.set("BITPIX", self._bitpix, bitpix_comment, after=0)
astropy/io/fits/header.py:921: in set
    self._relativeinsert((keyword, value, comment), before=before, after=after)
astropy/io/fits/header.py:1658: in _relativeinsert
    idx = self._cardindex(reference)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = , key = 0

    def _cardindex(self, key):
        """Return the physical card index represented by *key*."""
        if isinstance(key, slice):
            return key
    
        if isinstance(key, numbers.Integral):
            idx = int(key)
            if idx < 0:
                idx += len(self._cards)
            if idx < 0 or idx >= len(self._cards):
>               raise IndexError("Header index out of range.")
E               IndexError: Header index out of range.

astropy/io/fits/header.py:1688: IndexError
____________ TestHeaderFunctions.test_header_clear_write[fitsext1] _____________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec596810>
fitsext = <astropy.io.fits.hdu.compressed.compressed.CompImageHDU object at 0x7539ec6fea10>

    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
    def test_header_clear_write(self, fitsext):
        hdulist = fits.HDUList([fits.PrimaryHDU(), fitsext])
        hdulist[1].header["FOO"] = "BAR"
        hdulist[1].header.clear()
        with pytest.raises(VerifyError) as err:
>           hdulist.writeto(self.temp("temp.fits"), overwrite=True)

astropy/io/fits/tests/test_header.py:1207: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:1038: in writeto
    self.verify(option=output_verify)
astropy/io/fits/verify.py:82: in verify
    errs = self._verify(opt)
           ^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:1442: in _verify
    result = hdu._verify(option)
             ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/compressed/compressed.py:675: in _verify
    errs = super()._verify(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1264: in _verify
    errs = super()._verify(option=option)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:579: in _verify
    self.update_header()
astropy/io/fits/hdu/image.py:342: in update_header
    self._header.set("BITPIX", self._bitpix, bitpix_comment, after=0)
astropy/io/fits/header.py:921: in set
    self._relativeinsert((keyword, value, comment), before=before, after=after)
astropy/io/fits/header.py:1658: in _relativeinsert
    idx = self._cardindex(reference)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = , key = 0

    def _cardindex(self, key):
        """Return the physical card index represented by *key*."""
        if isinstance(key, slice):
            return key
    
        if isinstance(key, numbers.Integral):
            idx = int(key)
            if idx < 0:
                idx += len(self._cards)
            if idx < 0 or idx >= len(self._cards):
>               raise IndexError("Header index out of range.")
E               IndexError: Header index out of range.

astropy/io/fits/header.py:1688: IndexError
__________________ TestHeaderFunctions.test_invalid_end_cards __________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec5af910>

    def test_invalid_end_cards(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/217
    
        This tests the case where the END card looks like a normal card like
        'END = ' and other similar oddities.  As long as a card starts with END
        and looks like it was intended to be the END card we allow it, but with
        a warning.
        """
    
>       horig = fits.PrimaryHDU(data=np.arange(100)).header
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:1940: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1127: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:1155: in update_header
    super().update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.PrimaryHDU object at 0x7539ec127d10>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
_________________ TestHeaderFunctions.test_invalid_characters __________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec5aff50>

    def test_invalid_characters(self):
        """
        Test header with invalid characters
        """
    
        # Generate invalid file with non-ASCII character
        h = fits.Header()
        h["FOO"] = "BAR"
        h["COMMENT"] = "hello"
>       hdul = fits.PrimaryHDU(header=h, data=np.arange(5))
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:2013: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1127: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:1155: in update_header
    super().update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.PrimaryHDU object at 0x7539ec124790>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
__________________ TestHeaderFunctions.test_unnecessary_move ___________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec5b45d0>

    def test_unnecessary_move(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/125
    
        Ensures that a header is not modified when setting the position of a
        keyword that's already in its correct position.
        """
    
        header = fits.Header([("A", "B"), ("B", "C"), ("C", "D")])
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", after=0)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", before="C")
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", after="A")
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        # 123 is well past the end, and C is already at the end, so it's in the
        # right place already
>       header.set("C", before=123)

astropy/io/fits/tests/test_header.py:2064: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/header.py:919: in set
    self._relativeinsert(card, before=before, after=after, replace=True)
astropy/io/fits/header.py:1658: in _relativeinsert
    idx = self._cardindex(reference)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = A       = 'B       '                                                            
B       = 'C       '                 ...                                      
C       = 'D       '                                                            
key = 123

    def _cardindex(self, key):
        """Return the physical card index represented by *key*."""
        if isinstance(key, slice):
            return key
    
        if isinstance(key, numbers.Integral):
            idx = int(key)
            if idx < 0:
                idx += len(self._cards)
            if idx < 0 or idx >= len(self._cards):
>               raise IndexError("Header index out of range.")
E               IndexError: Header index out of range.

astropy/io/fits/header.py:1688: IndexError
________________ TestHeaderFunctions.test_invalid_float_cards2 _________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec5b52d0>
capsys = <_pytest.capture.CaptureFixture object at 0x7539ec5da550>

    def test_invalid_float_cards2(self, capsys):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/140
        """
    
        # The example for this test requires creating a FITS file containing a
        # slightly misformatted float value.  I can't actually even find a way
        # to do that directly through Astropy--it won't let me.
        hdu = fits.PrimaryHDU()
        hdu.header["TEST"] = 5.0022221e-07
>       hdu.writeto(self.temp("test.fits"))

astropy/io/fits/tests/test_header.py:2130: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:417: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1038: in writeto
    self.verify(option=output_verify)
astropy/io/fits/verify.py:82: in verify
    errs = self._verify(opt)
           ^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:1442: in _verify
    result = hdu._verify(option)
             ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1166: in _verify
    errs = super()._verify(option=option)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:582: in _verify
    return super()._verify(option)
           ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:1042: in _verify
    errs.append(card._verify(option))
                ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:1166: in _verify
    keyword, valuecomment = self._split()
                            ^^^^^^^^^^^^^
astropy/io/fits/card.py:837: in _split
    image = self.image
            ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:997: in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:980: in _format_value
    value = _format_value(value)
            ^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

value = 5.0022221e-07

    def _format_value(value):
        """
        Converts a card value to its appropriate string representation as
        defined by the FITS format.
        """
        # string value should occupies at least 8 columns, unless it is
        # a null string
        if isinstance(value, str):
            if value == "":
                return "''"
            else:
                exp_val_str = value.replace("'", "''")
                val_str = f"'{exp_val_str:8}'"
                return f"{val_str:20}"
    
        # must be before int checking since bool is also int
        elif isinstance(value, (bool, np.bool_)):
            return f"{repr(value)[0]:>20}"  # T or F
    
        elif _is_int(value):
            return f"{value:>20d}"
    
        elif isinstance(value, (float, np.floating)):
>           return f"{_format_float(value):>20}"
                      ^^^^^^^^^^^^^
E           NameError: name '_format_float' is not defined

astropy/io/fits/card.py:1288: NameError
___________________ TestHeaderFunctions.test_end_in_comment ____________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec5b6bd0>

    def test_end_in_comment(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/142
    
        Tests a case where the comment of a card ends with END, and is followed
        by several blank cards.
        """
    
        data = np.arange(100).reshape(10, 10)
>       hdu = fits.PrimaryHDU(data=data)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:2271: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1127: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:1155: in update_header
    super().update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.PrimaryHDU object at 0x7539ebb35410>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
___________________ TestHeaderFunctions.test_update_numeric ____________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7539ec5bc990>

    def test_update_numeric(self):
        """
        Regression test for https://github.com/spacetelescope/PyFITS/issues/49
    
        Ensure that numeric values can be upcast/downcast between int, float,
        and complex by assigning values that compare equal to the existing
        value but are a different type.
        """
    
        h = fits.Header()
        h["TEST"] = 1
    
        # int -> float
        h["TEST"] = 1.0
        assert isinstance(h["TEST"], float)
>       assert str(h).startswith("TEST    =                  1.0")
               ^^^^^^

astropy/io/fits/tests/test_header.py:2534: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/header.py:280: in __str__
    return self.tostring()
           ^^^^^^^^^^^^^^^
astropy/io/fits/header.py:679: in tostring
    s = str(card)
        ^^^^^^^^^
astropy/io/fits/card.py:213: in __str__
    return self.image
           ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:997: in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:980: in _format_value
    value = _format_value(value)
            ^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

value = 1.0

    def _format_value(value):
        """
        Converts a card value to its appropriate string representation as
        defined by the FITS format.
        """
        # string value should occupies at least 8 columns, unless it is
        # a null string
        if isinstance(value, str):
            if value == "":
                return "''"
            else:
                exp_val_str = value.replace("'", "''")
                val_str = f"'{exp_val_str:8}'"
                return f"{val_str:20}"
    
        # must be before int checking since bool is also int
        elif isinstance(value, (bool, np.bool_)):
            return f"{repr(value)[0]:>20}"  # T or F
    
        elif _is_int(value):
            return f"{value:>20d}"
    
        elif isinstance(value, (float, np.floating)):
>           return f"{_format_float(value):>20}"
                      ^^^^^^^^^^^^^
E           NameError: name '_format_float' is not defined

astropy/io/fits/card.py:1288: NameError
___________ TestRecordValuedKeywordCards.test_pattern_matching_keys ____________

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x7539ec5c7150>

    def test_pattern_matching_keys(self):
        """Test the keyword filter strings with RVKCs."""
    
        cl = self._test_header["DP1.AXIS.*"]
        assert isinstance(cl, fits.Header)
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'AXIS.1: 1'",
            "DP1     = 'AXIS.2: 2'",
        ]
    
        cl = self._test_header["DP1.N*"]
        assert [str(c).strip() for c in cl.cards] == [
            "DP1     = 'NAXIS: 2'",
            "DP1     = 'NAUX: 2'",
        ]
    
        cl = self._test_header["DP1.AUX..."]
>       assert [str(c).strip() for c in cl.cards] == [
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

astropy/io/fits/tests/test_header.py:3004: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/tests/test_header.py:3004: in <listcomp>
    assert [str(c).strip() for c in cl.cards] == [
            ^^^^^^
astropy/io/fits/card.py:213: in __str__
    return self.image
           ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:997: in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:977: in _format_value
    value = _format_value(self._value).strip()
            ^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

value = 0.00048828125

    def _format_value(value):
        """
        Converts a card value to its appropriate string representation as
        defined by the FITS format.
        """
        # string value should occupies at least 8 columns, unless it is
        # a null string
        if isinstance(value, str):
            if value == "":
                return "''"
            else:
                exp_val_str = value.replace("'", "''")
                val_str = f"'{exp_val_str:8}'"
                return f"{val_str:20}"
    
        # must be before int checking since bool is also int
        elif isinstance(value, (bool, np.bool_)):
            return f"{repr(value)[0]:>20}"  # T or F
    
        elif _is_int(value):
            return f"{value:>20d}"
    
        elif isinstance(value, (float, np.floating)):
>           return f"{_format_float(value):>20}"
                      ^^^^^^^^^^^^^
E           NameError: name '_format_float' is not defined

astropy/io/fits/card.py:1288: NameError
________ TestRecordValuedKeywordCards.test_successive_pattern_matching _________

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x7539ec5c7dd0>

    def test_successive_pattern_matching(self):
        """
        A card list returned via a filter string should be further filterable.
        """
    
        cl = self._test_header["DP1.A*..."]
>       assert [str(c).strip() for c in cl.cards] == [
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            "DP1     = 'AXIS.1: 1'",
            "DP1     = 'AXIS.2: 2'",
            "DP1     = 'AUX.1.COEFF.0: 0'",
            "DP1     = 'AUX.1.POWER.0: 1'",
            "DP1     = 'AUX.1.COEFF.1: 0.00048828125'",
            "DP1     = 'AUX.1.POWER.1: 1'",
        ]

astropy/io/fits/tests/test_header.py:3036: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/tests/test_header.py:3036: in <listcomp>
    assert [str(c).strip() for c in cl.cards] == [
            ^^^^^^
astropy/io/fits/card.py:213: in __str__
    return self.image
           ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:997: in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/card.py:977: in _format_value
    value = _format_value(self._value).strip()
            ^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

value = 0.00048828125

    def _format_value(value):
        """
        Converts a card value to its appropriate string representation as
        defined by the FITS format.
        """
        # string value should occupies at least 8 columns, unless it is
        # a null string
        if isinstance(value, str):
            if value == "":
                return "''"
            else:
                exp_val_str = value.replace("'", "''")
                val_str = f"'{exp_val_str:8}'"
                return f"{val_str:20}"
    
        # must be before int checking since bool is also int
        elif isinstance(value, (bool, np.bool_)):
            return f"{repr(value)[0]:>20}"  # T or F
    
        elif _is_int(value):
            return f"{value:>20d}"
    
        elif isinstance(value, (float, np.floating)):
>           return f"{_format_float(value):>20}"
                      ^^^^^^^^^^^^^
E           NameError: name '_format_float' is not defined

astropy/io/fits/card.py:1288: NameError
_ TestRecordValuedKeywordCards.test_fitsheader_compressed_from_primary_image_ext _

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x7539ec5c6890>

    def test_fitsheader_compressed_from_primary_image_ext(self):
        """Regression test for issue https://github.com/astropy/astropy/issues/7312"""
        data = np.arange(2 * 2, dtype=np.int8).reshape((2, 2))
>       phdu = fits.PrimaryHDU(data=data)
               ^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:3182: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1127: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:1155: in update_header
    super().update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.PrimaryHDU object at 0x7539ec148090>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
____________ TestRecordValuedKeywordCards.test_hdu_writeto_mode[wb] ____________

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x7539ec5d0350>
mode = 'wb'

    @pytest.mark.parametrize("mode", ["wb", "wb+", "ab", "ab+"])
    def test_hdu_writeto_mode(self, mode):
        with open(self.temp("mode.fits"), mode=mode) as ff:
>           hdu = fits.ImageHDU(data=np.ones(5))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:3232: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1242: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.ImageHDU object at 0x7539ec54d7d0>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
___________ TestRecordValuedKeywordCards.test_hdu_writeto_mode[wb+] ____________

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x7539ec5d2810>
mode = 'wb+'

    @pytest.mark.parametrize("mode", ["wb", "wb+", "ab", "ab+"])
    def test_hdu_writeto_mode(self, mode):
        with open(self.temp("mode.fits"), mode=mode) as ff:
>           hdu = fits.ImageHDU(data=np.ones(5))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:3232: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1242: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.ImageHDU object at 0x7539ec467450>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
____________ TestRecordValuedKeywordCards.test_hdu_writeto_mode[ab] ____________

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x7539ec5d2950>
mode = 'ab'

    @pytest.mark.parametrize("mode", ["wb", "wb+", "ab", "ab+"])
    def test_hdu_writeto_mode(self, mode):
        with open(self.temp("mode.fits"), mode=mode) as ff:
>           hdu = fits.ImageHDU(data=np.ones(5))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:3232: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1242: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.ImageHDU object at 0x7539ebfd0390>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
___________ TestRecordValuedKeywordCards.test_hdu_writeto_mode[ab+] ____________

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x7539ec5d2a90>
mode = 'ab+'

    @pytest.mark.parametrize("mode", ["wb", "wb+", "ab", "ab+"])
    def test_hdu_writeto_mode(self, mode):
        with open(self.temp("mode.fits"), mode=mode) as ff:
>           hdu = fits.ImageHDU(data=np.ones(5))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:3232: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/image.py:1242: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:150: in __init__
    self.data = data
    ^^^^^^^^^
astropy/utils/decorators.py:960: in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:296: in data
    self.update_header()
astropy/io/fits/hdu/image.py:382: in update_header
    self._update_pseudo_int_scale_keywords()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.image.ImageHDU object at 0x7539ec057390>

    def _update_pseudo_int_scale_keywords(self):
        """
        If the data is signed int 8, unsigned int 16, 32, or 64,
        add BSCALE/BZERO cards to header.
        """
>       if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                                 ^^^^^^^^^^^^^^^^^^
E       NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/image.py:422: NameError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_floating_point_value_card
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_floating_point_string_representation_card
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_complex_value_card
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_add_blank
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_clear_write[fitsext0]
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_clear_write[fitsext1]
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_invalid_end_cards
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_invalid_characters
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_invalid_float_cards2
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_end_in_comment
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_update_numeric
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_pattern_matching_keys
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_successive_pattern_matching
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_fitsheader_compressed_from_primary_image_ext
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_hdu_writeto_mode[wb]
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_hdu_writeto_mode[wb+]
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_hdu_writeto_mode[ab]
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_hdu_writeto_mode[ab+]
19 failed, 160 passed in 2.12s
```

## 原始行 146 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/card.py | sed -n '1180,1320p'
grep -RIn \"format_float\\|pseudo_integer\" astropy/io/fits/tests | head -100
grep -RIn \"def _pseudo_zero\\|def _is_pseudo\" astropy/io/fits/util.py astropy/io/fits | head -50"
```

退出码：`0`

输出：
```
  1180	        else:
  1181	            if not self._valuemodified:
  1182	                m = self._value_FSC_RE.match(valuecomment)
  1183	                # If the value of a card was replaced before the card was ever
  1184	                # even verified, the new value can be considered valid, so we
  1185	                # don't bother verifying the old value.  See
  1186	                # https://github.com/astropy/astropy/issues/5408
  1187	                if m is None:
  1188	                    errs.append(
  1189	                        {
  1190	                            "err_text": (
  1191	                                f"Card {self.keyword!r} is not FITS standard "
  1192	                                f"(invalid value string: {valuecomment!r})."
  1193	                            ),
  1194	                            "fix_text": fix_text,
  1195	                            "fix": self._fix_value,
  1196	                        }
  1197	                    )
  1198	
  1199	        # verify the comment (string), it is never fixable
  1200	        m = self._value_NFSC_RE.match(valuecomment)
  1201	        if m is not None:
  1202	            comment = m.group("comm")
  1203	            if comment is not None:
  1204	                if not self._ascii_text_re.match(comment):
  1205	                    errs.append(
  1206	                        {
  1207	                            "err_text": (
  1208	                                f"Unprintable string {comment!r}; header comments "
  1209	                                "may only contain printable ASCII characters"
  1210	                            ),
  1211	                            "fixable": False,
  1212	                        }
  1213	                    )
  1214	
  1215	        errs = _ErrList([self.run_option(option, **err) for err in errs])
  1216	        self._verified = True
  1217	        return errs
  1218	
  1219	    def _itersubcards(self):
  1220	        """
  1221	        If the card image is greater than 80 characters, it should consist of a
  1222	        normal card followed by one or more CONTINUE card.  This method returns
  1223	        the subcards that make up this logical card.
  1224	
  1225	        This can also support the case where a HISTORY or COMMENT card has a
  1226	        long value that is stored internally as multiple concatenated card
  1227	        images.
  1228	        """
  1229	        ncards = len(self._image) // Card.length
  1230	
  1231	        for idx in range(0, Card.length * ncards, Card.length):
  1232	            card = Card.fromstring(self._image[idx : idx + Card.length])
  1233	            if idx > 0 and card.keyword.upper() not in self._special_keywords:
  1234	                raise VerifyError(
  1235	                    "Long card images must have CONTINUE cards after "
  1236	                    "the first card or have commentary keywords like "
  1237	                    "HISTORY or COMMENT."
  1238	                )
  1239	
  1240	            if not isinstance(card.value, str):
  1241	                raise VerifyError("CONTINUE cards must have string values.")
  1242	
  1243	            yield card
  1244	
  1245	
  1246	def _int_or_float(s):
  1247	    """
  1248	    Converts an a string to an int if possible, or to a float.
  1249	
  1250	    If the string is neither a string or a float a value error is raised.
  1251	    """
  1252	    if isinstance(s, float):
  1253	        # Already a float so just pass through
  1254	        return s
  1255	
  1256	    try:
  1257	        return int(s)
  1258	    except (ValueError, TypeError):
  1259	        try:
  1260	            return float(s)
  1261	        except (ValueError, TypeError) as e:
  1262	            raise ValueError(str(e))
  1263	
  1264	
  1265	def _format_value(value):
  1266	    """
  1267	    Converts a card value to its appropriate string representation as
  1268	    defined by the FITS format.
  1269	    """
  1270	    # string value should occupies at least 8 columns, unless it is
  1271	    # a null string
  1272	    if isinstance(value, str):
  1273	        if value == "":
  1274	            return "''"
  1275	        else:
  1276	            exp_val_str = value.replace("'", "''")
  1277	            val_str = f"'{exp_val_str:8}'"
  1278	            return f"{val_str:20}"
  1279	
  1280	    # must be before int checking since bool is also int
  1281	    elif isinstance(value, (bool, np.bool_)):
  1282	        return f"{repr(value)[0]:>20}"  # T or F
  1283	
  1284	    elif _is_int(value):
  1285	        return f"{value:>20d}"
  1286	
  1287	    elif isinstance(value, (float, np.floating)):
  1288	        return f"{_format_float(value):>20}"
  1289	
  1290	    elif isinstance(value, (complex, np.complexfloating)):
  1291	        val_str = f"({_format_float(value.real)}, {_format_float(value.imag)})"
  1292	        return f"{val_str:>20}"
  1293	
  1294	    elif isinstance(value, Undefined):
  1295	        return ""
  1296	    else:
  1297	        return ""
  1298	
  1299	
  1300	
  1301	
  1302	
  1303	
  1304	
  1305	
  1306	
  1307	
  1308	
  1309	
  1310	
  1311	
  1312	
  1313	
  1314	
  1315	
  1316	
  1317	def _pad(input):
  1318	    """Pad blank space to the input string to be multiple of 80."""
  1319	    _len = len(input)
  1320	    if _len == Card.length:
astropy/io/fits/util.py:687:def _pseudo_zero(dtype):
astropy/io/fits/util.py:687:def _pseudo_zero(dtype):
```

## 原始行 149 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
x=-467374636747637647347374734737437.0
for p in range(17,10,-1):
 s=f'{x:.{p}G}'.replace('E+0','E+').replace('E-0','E-')
 print(p,s,len(s))
for x in [0.009125,8.95,-99.9,1.2345377437887837487e88,6324767364763746367e-33]: print(x, format(x,'.16G'))
PY"
```

退出码：`0`

输出：
```
17 -4.6737463674763763E+32 23
16 -4.673746367476376E+32 22
15 -4.67374636747638E+32 21
14 -4.6737463674764E+32 20
13 -4.673746367476E+32 19
12 -4.67374636748E+32 18
11 -4.6737463675E+32 17
0.009125 0.009124999999999999
8.95 8.949999999999999
-99.9 -99.90000000000001
1.2345377437887837e+88 1.234537743788784E+88
6.3247673647637465e-15 6.324767364763747E-15
```

## 原始行 152 · command_execution

命令：
```
/bin/bash -lc "sed -n '650,715p' astropy/io/fits/util.py
nl -ba astropy/io/fits/hdu/image.py | sed -n '1,25p'"
```

退出码：`0`

输出：
```


def _write_string(f, s):
    """
    Write a string to a file, encoding to ASCII if the file is open in binary
    mode, or decoding if the file is open in text mode.
    """
    # Assume if the file object doesn't have a specific mode, that the mode is
    # binary
    binmode = fileobj_is_binary(f)

    if binmode and isinstance(s, str):
        s = encode_ascii(s)
    elif not binmode and not isinstance(f, str):
        s = decode_ascii(s)

    f.write(s)


def _convert_array(array, dtype):
    """
    Converts an array to a new dtype--if the itemsize of the new dtype is
    the same as the old dtype and both types are not numeric, a view is
    returned.  Otherwise a new array must be created.
    """
    if array.dtype == dtype:
        return array
    elif array.dtype.itemsize == dtype.itemsize and not (
        np.issubdtype(array.dtype, np.number) and np.issubdtype(dtype, np.number)
    ):
        # Includes a special case when both dtypes are at least numeric to
        # account for old Trac ticket 218 (now inaccessible).
        return array.view(dtype)
    else:
        return array.astype(dtype)


def _pseudo_zero(dtype):
    """
    Given a numpy dtype, finds its "zero" point, which is exactly in the
    middle of its range.
    """
    # special case for int8
    if dtype.kind == "i" and dtype.itemsize == 1:
        return -128

    assert dtype.kind == "u"
    return 1 << (dtype.itemsize * 8 - 1)












def _str_to_num(val):
    """Converts a given string to either an int or a float if necessary."""
    try:
        num = int(val)
    except ValueError:
        # If this fails then an exception should be raised anyways
     1	# Licensed under a 3-clause BSD style license - see PYFITS.rst
     2	
     3	import mmap
     4	import sys
     5	import warnings
     6	
     7	import numpy as np
     8	
     9	from astropy.io.fits.header import Header
    10	from astropy.io.fits.util import _is_dask_array, _is_int, _pseudo_zero
    11	
    12	
    13	
    14	
    15	
    16	from astropy.io.fits.verify import VerifyWarning
    17	from astropy.utils import lazyproperty
    18	
    19	from .base import BITPIX2DTYPE, DELAYED, DTYPE2BITPIX, ExtensionHDU, _ValidHDU
    20	
    21	__all__ = ["ImageHDU", "PrimaryHDU", "Section"]
    22	
    23	
    24	class _ImageBaseHDU(_ValidHDU):
    25	    """FITS image HDU base class.
```

## 原始行 156 · file_change

```
{
  "id": "item_104",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/card.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/image.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 159 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
.............F.......................................................... [ 40%]
........................................................F............... [ 80%]
............................F......                                      [100%]
=================================== FAILURES ===================================
______ TestHeaderFunctions.test_floating_point_string_representation_card ______

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x720e7cc0e810>

    def test_floating_point_string_representation_card(self):
        """
        Ensures Card formats float values with the correct precision, avoiding
        comment truncation
    
        Regression test for https://github.com/astropy/astropy/issues/14507
        """
        k = "HIERARCH ABC DEF GH IJKLMN"
        com = "[m] abcdef ghijklm nopqrstu vw xyzab"
        c = fits.Card(k, 0.009125, com)
        expected_str = f"{k} = 0.009125 / {com}"
>       assert str(c)[: len(expected_str)] == expected_str
               ^^^^^^

astropy/io/fits/tests/test_header.py:152: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/card.py:213: in __str__
    return self.image
           ^^^^^^^^^^
astropy/io/fits/card.py:529: in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = ('ABC DEF GH IJKLMN', 0.009125, '[m] abcdef ghijklm nopqrstu vw xyzab')

    def _format_image(self):
        keyword = self._format_keyword()
    
        value = self._format_value()
        is_commentary = keyword.strip() in self._commentary_keywords
        if is_commentary:
            comment = ""
        else:
            comment = self._format_comment()
    
        # equal sign string
        # by default use the standard value indicator even for HIERARCH cards;
        # later we may abbreviate it if necessary
        delimiter = VALUE_INDICATOR
        if is_commentary:
            delimiter = ""
    
        # put all parts together
        output = f"{keyword}{delimiter}{value}{comment}"
    
        # For HIERARCH cards we can save a bit of space if necessary by
        # removing the space between the keyword and the equals sign; I'm
        # guessing this is part of the HIEARCH card specification
        keywordvalue_length = len(keyword) + len(delimiter) + len(value)
        if (
            keywordvalue_length == self.length + 1
            and keyword.startswith("HIERARCH")
            and keyword[-1] == " "
        ):
            output = "".join([keyword[:-1], delimiter, value, comment])
    
        if len(output) <= self.length:
            output = f"{output:80}"
        else:
            # longstring case (CONTINUE card)
            # try not to use CONTINUE if the string value can fit in one line.
            # Instead, just truncate the comment
            if isinstance(self.value, str) and len(value) > (
                self.length - len(keyword) - 2
            ):
                output = self._format_long_image()
            else:
>               warnings.warn(
                    "Card is too long, comment will be truncated.", VerifyWarning
                )
E               astropy.io.fits.verify.VerifyWarning: Card is too long, comment will be truncated.

astropy/io/fits/card.py:1036: VerifyWarning
________________ TestHeaderFunctions.test_invalid_float_cards2 _________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x720e7cc5ce90>
capsys = <_pytest.capture.CaptureFixture object at 0x720e7cbc5c50>

    def test_invalid_float_cards2(self, capsys):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/140
        """
    
        # The example for this test requires creating a FITS file containing a
        # slightly misformatted float value.  I can't actually even find a way
        # to do that directly through Astropy--it won't let me.
        hdu = fits.PrimaryHDU()
        hdu.header["TEST"] = 5.0022221e-07
        hdu.writeto(self.temp("test.fits"))
    
        # Here we manually make the file invalid
        with open(self.temp("test.fits"), "rb+") as f:
            f.seek(346)  # Location of the exponent 'E' symbol
            f.write(encode_ascii("e"))
    
        with (
            fits.open(self.temp("test.fits")) as hdul,
            pytest.warns(AstropyUserWarning) as w,
        ):
            hdul.writeto(self.temp("temp.fits"), output_verify="warn")
        assert len(w) == 5
        # The first two warnings are just the headers to the actual warning
        # message (HDU 0, Card 4).  I'm still not sure things like that
        # should be output as separate warning messages, but that's
        # something to think about...
        msg = str(w[3].message)
>       assert "(invalid value string: '5.0022221e-07')" in msg
E       assert "(invalid value string: '5.0022221e-07')" in "        Card 'TEST' is not FITS standard (invalid value string: '5.002222eE-7')."

astropy/io/fits/tests/test_header.py:2148: AssertionError
_ TestRecordValuedKeywordCards.test_fitsheader_compressed_from_primary_image_ext _

self = <astropy.io.fits.tests.test_header.TestRecordValuedKeywordCards object at 0x720e7cc6eb90>

    def test_fitsheader_compressed_from_primary_image_ext(self):
        """Regression test for issue https://github.com/astropy/astropy/issues/7312"""
        data = np.arange(2 * 2, dtype=np.int8).reshape((2, 2))
        phdu = fits.PrimaryHDU(data=data)
        chdu = fits.CompImageHDU(data=phdu.data, header=phdu.header)
>       chdu.writeto(self.temp("tmp2.fits"), overwrite=True)

astropy/io/fits/tests/test_header.py:3184: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:1553: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1068: in writeto
    hdu._prewriteto()
astropy/io/fits/hdu/compressed/compressed.py:573: in _prewriteto
    self._add_data_to_bintable(self._tmp_bintable)
astropy/io/fits/hdu/compressed/compressed.py:538: in _add_data_to_bintable
    heap = compress_image_data(
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

image_data = array([[0, 1],
       [2, 3]], dtype=int8)
compression_type = 'RICE_1'
compressed_header = XTENSION= 'BINTABLE'           / binary table extension                         
BITPIX  =                    8 / arra...                                      
BSCALE  =                    1                                                  
compressed_coldefs = ColDefs(
    name = 'COMPRESSED_DATA'; format = '1PB'
)

    def compress_image_data(
        image_data,
        compression_type,
        compressed_header,
        compressed_coldefs,
    ):
        """
        Compress the data in a `~astropy.io.fits.CompImageHDU`.
    
        The input HDU is expected to have a uncompressed numpy array as it's
        ``.data`` attribute.
    
        Parameters
        ----------
        image_data : `~numpy.ndarray`
            The image data to compress
        compression_type : str
            The compression algorithm
        compressed_header : `~astropy.io.fits.Header`
            The header of the compressed binary table
        compressed_coldefs : `~astropy.io.fits.ColDefs`
            The ColDefs object for the compressed binary table
    
        Returns
        -------
        nbytes : `int`
            The number of bytes of the heap.
        heap : `bytes`
            The bytes of the FITS table heap.
        """
        if not isinstance(image_data, np.ndarray):
            raise TypeError("Image data must be a numpy.ndarray")
    
>       _check_compressed_header(compressed_header)
        ^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_check_compressed_header' is not defined

astropy/io/fits/hdu/compressed/_tiled_compression.py:507: NameError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_floating_point_string_representation_card
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_invalid_float_cards2
FAILED astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_fitsheader_compressed_from_primary_image_ext
3 failed, 176 passed in 0.48s
```

## 原始行 163 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/hdu/compressed/_tiled_compression.py | sed -n '1,180p'
grep -n \"check_compressed\\|"'^def " astropy/io/fits/hdu/compressed/_tiled_compression.py'
```

退出码：`0`

输出：
```
     1	"""
     2	This module contains low level helper functions for compressing and
     3	decompressing buffer for the Tiled Table Compression algorithms as specified in
     4	the FITS 4 standard.
     5	"""
     6	
     7	import sys
     8	from math import prod
     9	
    10	import numpy as np
    11	
    12	from astropy.io.fits.hdu.base import BITPIX2DTYPE
    13	
    14	from ._codecs import PLIO1, Gzip1, Gzip2, HCompress1, NoCompress, Rice1
    15	from ._quantization import DITHER_METHODS, QuantizationFailedException, Quantize
    16	from .utils import _data_shape, _iter_array_tiles, _tile_shape
    17	
    18	ALGORITHMS = {
    19	    "GZIP_1": Gzip1,
    20	    "GZIP_2": Gzip2,
    21	    "RICE_1": Rice1,
    22	    "RICE_ONE": Rice1,
    23	    "PLIO_1": PLIO1,
    24	    "HCOMPRESS_1": HCompress1,
    25	    "NOCOMPRESS": NoCompress,
    26	}
    27	
    28	DEFAULT_ZBLANK = -2147483648
    29	
    30	
    31	__all__ = [
    32	    "compress_image_data",
    33	    "decompress_image_data_section",
    34	]
    35	
    36	
    37	def _decompress_tile(buf, *, algorithm: str, **settings):
    38	    """
    39	    Decompress the buffer of a tile using the given compression algorithm.
    40	
    41	    Parameters
    42	    ----------
    43	    buf
    44	        The compressed buffer to be decompressed.
    45	    algorithm
    46	        A supported decompression algorithm.
    47	    settings
    48	        Any parameters for the given compression algorithm
    49	    """
    50	    return ALGORITHMS[algorithm](**settings).decode(buf)
    51	
    52	
    53	def _compress_tile(buf, *, algorithm: str, **settings):
    54	    """
    55	    Compress the buffer of a tile using the given compression algorithm.
    56	
    57	    Parameters
    58	    ----------
    59	    buf
    60	        The decompressed buffer to be compressed.
    61	    algorithm
    62	        A supported compression algorithm.
    63	    settings
    64	        Any parameters for the given compression algorithm
    65	    """
    66	    return ALGORITHMS[algorithm](**settings).encode(buf)
    67	
    68	
    69	def _header_to_settings(header):
    70	    """
    71	    Extract the settings which are constant given a header
    72	    """
    73	    settings = {}
    74	    compression_type = header["ZCMPTYPE"]
    75	    if compression_type == "GZIP_2":
    76	        settings["itemsize"] = abs(header["ZBITPIX"]) // 8
    77	    elif compression_type in ("RICE_1", "RICE_ONE"):
    78	        settings["blocksize"] = _get_compression_setting(header, "BLOCKSIZE", 32)
    79	        settings["bytepix"] = _get_compression_setting(header, "BYTEPIX", 4)
    80	    elif compression_type == "HCOMPRESS_1":
    81	        settings["bytepix"] = 8
    82	        settings["scale"] = int(_get_compression_setting(header, "SCALE", 0))
    83	        settings["smooth"] = _get_compression_setting(header, "SMOOTH", 0)
    84	
    85	    return settings
    86	
    87	
    88	def _update_tile_settings(settings, compression_type, actual_tile_shape):
    89	    """
    90	    Update the settings with tile-specific settings
    91	    """
    92	    if compression_type in ("PLIO_1", "RICE_1", "RICE_ONE"):
    93	        # We have to calculate the tilesize from the shape of the tile not the
    94	        # header, so that it's correct for edge tiles etc.
    95	        settings["tilesize"] = prod(actual_tile_shape)
    96	    elif compression_type == "HCOMPRESS_1":
    97	        # HCOMPRESS requires 2D tiles, so to find the shape of the 2D tile we
    98	        # need to ignore all length 1 tile dimensions
    99	        # Also cfitsio expects the tile shape in C order
   100	        shape_2d = tuple(nd for nd in actual_tile_shape if nd != 1)
   101	        if len(shape_2d) != 2:
   102	            raise ValueError(f"HCOMPRESS expects two dimensional tiles, got {shape_2d}")
   103	        settings["nx"] = shape_2d[0]
   104	        settings["ny"] = shape_2d[1]
   105	
   106	    return settings
   107	
   108	
   109	def _finalize_array(tile_buffer, *, bitpix, tile_shape, algorithm, lossless):
   110	    """
   111	    Convert a buffer to an array.
   112	
   113	    This is a helper function which takes a raw buffer (as output by .decode)
   114	    and translates it into a numpy array with the correct dtype, endianness and
   115	    shape.
   116	    """
   117	    tile_size = prod(tile_shape)
   118	
   119	    if algorithm.startswith("GZIP") or algorithm == "NOCOMPRESS":
   120	        # This algorithm is taken from fitsio
   121	        # https://github.com/astropy/astropy/blob/a8cb1668d4835562b89c0d0b3448ac72ca44db63/cextern/cfitsio/lib/imcompress.c#L6345-L6388
   122	        tile_bytesize = len(tile_buffer)
   123	        if tile_bytesize == tile_size * 2:
   124	            dtype = ">i2"
   125	        elif tile_bytesize == tile_size * 4:
   126	            if bitpix < 0 and lossless:
   127	                dtype = ">f4"
   128	            else:
   129	                dtype = ">i4"
   130	        elif tile_bytesize == tile_size * 8:
   131	            if bitpix < 0 and lossless:
   132	                dtype = ">f8"
   133	            else:
   134	                dtype = ">i8"
   135	        else:
   136	            # Just return the raw bytes
   137	            dtype = ">u1"
   138	        tile_data = np.asarray(tile_buffer).view(dtype).reshape(tile_shape)
   139	    else:
   140	        # For RICE_1 compression the tiles that are on the edge can end up
   141	        # being padded, so we truncate excess values
   142	        if algorithm in ("RICE_1", "RICE_ONE", "PLIO_1") and tile_size < len(
   143	            tile_buffer
   144	        ):
   145	            tile_buffer = tile_buffer[:tile_size]
   146	
   147	        if tile_buffer.data.format == "b":
   148	            # NOTE: this feels like a Numpy bug - need to investigate
   149	            tile_data = np.asarray(tile_buffer, dtype=np.uint8).reshape(tile_shape)
   150	        else:
   151	            tile_data = np.asarray(tile_buffer).reshape(tile_shape)
   152	
   153	    return tile_data
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
37:def _decompress_tile(buf, *, algorithm: str, **settings):
53:def _compress_tile(buf, *, algorithm: str, **settings):
69:def _header_to_settings(header):
88:def _update_tile_settings(settings, compression_type, actual_tile_shape):
109:def _finalize_array(tile_buffer, *, bitpix, tile_shape, algorithm, lossless):
242:def _get_compression_setting(header, name, default):
257:def _column_dtype(compressed_coldefs, column_name):
268:def _get_data_from_heap(hdu, size, offset, dtype, heap_cache=None):
280:def decompress_image_data_section(
314:    _check_compressed_header(compressed_header)
474:def compress_image_data(
507:    _check_compressed_header(compressed_header)
```

## 原始行 166 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"compressed header\\|ZBITPIX\\|ZCMPTYPE\\|_check_compressed_header\\|compression failure\\|fails.*compress\\|decompress.*raise\" astropy/io/fits/hdu/compressed/tests | head -300
sed -n '280,540p' astropy/io/fits/hdu/compressed/_tiled_compression.py"
```

退出码：`0`

输出：
```
astropy/io/fits/hdu/compressed/tests/test_fitsio.py:130:        # fitsio fails with a compression error
astropy/io/fits/hdu/compressed/tests/test_fitsio.py:189:        assert hdul[1].header["ZCMPTYPE"].replace("ONE", "1") == compression_type
astropy/io/fits/hdu/compressed/tests/test_fitsio.py:222:    assert header["ZCMPTYPE"] == compression_type
astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py:161:            # ensure that the uncompressed header is created with BLANK keyword
astropy/io/fits/hdu/compressed/tests/test_compressed.py:503:            hdr["ZCMPTYPE"] = "ASDF"
astropy/io/fits/hdu/compressed/tests/test_compressed.py:509:                ("TFIELDS", "THEAP", "TTYPE1", "ZCMPTYPE", "ZVAL1")
astropy/io/fits/hdu/compressed/tests/test_compressed.py:599:            imghdr.set("ZBITPIX", 77, "asdf", after="GCOUNT")
astropy/io/fits/hdu/compressed/tests/test_compressed.py:601:            with pytest.warns(UserWarning, match="Keyword 'ZBITPIX' is reserved"):
astropy/io/fits/hdu/compressed/tests/test_compressed.py:609:            assert tblhdr.count("ZBITPIX") == 1
astropy/io/fits/hdu/compressed/tests/test_compressed.py:610:            assert tblhdr["ZBITPIX"] != 77
astropy/io/fits/hdu/compressed/tests/test_compressed.py:1379:                "ZCMPTYPE": "RICE_1",
astropy/io/fits/hdu/compressed/tests/test_compressed.py:1393:                "ZCMPTYPE": "RICE_1",
astropy/io/fits/hdu/compressed/tests/test_compressed.py:1407:                "ZCMPTYPE": "RICE_1",
astropy/io/fits/hdu/compressed/tests/test_compressed.py:1421:                "ZCMPTYPE": "RICE_1",
astropy/io/fits/hdu/compressed/tests/test_compressed.py:1450:    # not be correctly stripped from the compressed header when decompressing
def decompress_image_data_section(
    compressed_data,
    compression_type,
    compressed_header,
    bintable,
    image_header,
    first_tile_index,
    last_tile_index,
):
    """
    Decompress the data in a `~astropy.io.fits.CompImageHDU`.

    Parameters
    ----------
    compressed_data : `~astropy.io.fits.FITS_rec`
        The compressed data
    compression_type : str
        The compression algorithm
    compressed_header : `~astropy.io.fits.Header`
        The header of the compressed binary table
    bintable : `~astropy.io.fits.BinTableHDU`
        The binary table HDU, used to access the raw heap data
    first_tile_index : iterable
        The indices of the first tile to decompress along each dimension
    last_tile_index : iterable
        The indices of the last tile to decompress along each dimension

    Returns
    -------
    data : `numpy.ndarray`
        The decompressed data array.
    """
    compressed_coldefs = compressed_data._coldefs

    _check_compressed_header(compressed_header)

    tile_shape = _tile_shape(compressed_header)
    data_shape = _data_shape(compressed_header)

    first_array_index = first_tile_index * tile_shape
    last_array_index = (last_tile_index + 1) * tile_shape

    last_array_index = np.minimum(data_shape, last_array_index)

    buffer_shape = tuple((last_array_index - first_array_index).astype(int))

    image_data = np.empty(
        buffer_shape, dtype=BITPIX2DTYPE[compressed_header["ZBITPIX"]]
    )

    quantized = "ZSCALE" in compressed_data.dtype.names

    if image_data.size == 0:
        return image_data

    settings = _header_to_settings(compressed_header)
    zbitpix = compressed_header["ZBITPIX"]
    dither_method = DITHER_METHODS[compressed_header.get("ZQUANTIZ", "NO_DITHER")]
    dither_seed = compressed_header.get("ZDITHER0", 0)

    # NOTE: in the following and below we convert the column to a Numpy array
    # for performance reasons, as accessing rows from a FITS_rec column is
    # otherwise slow.
    compressed_data_column = np.array(compressed_data["COMPRESSED_DATA"])
    compressed_data_dtype = _column_dtype(compressed_coldefs, "COMPRESSED_DATA")

    if "ZBLANK" in compressed_coldefs.dtype.names:
        zblank_column = np.array(compressed_data["ZBLANK"])
    else:
        zblank_column = None

    if "ZSCALE" in compressed_coldefs.dtype.names:
        zscale_column = np.array(compressed_data["ZSCALE"])
    else:
        zscale_column = None

    if "ZZERO" in compressed_coldefs.dtype.names:
        zzero_column = np.array(compressed_data["ZZERO"])
    else:
        zzero_column = None

    zblank_header = compressed_header.get("ZBLANK", image_header.get("BLANK", None))

    gzip_compressed_data_column = None
    gzip_compressed_data_dtype = None

    # If all the data is requested, read in all the heap.
    if tuple(buffer_shape) == tuple(data_shape):
        heap_cache = bintable._get_raw_data(
            compressed_header["PCOUNT"],
            np.uint8,
            bintable._data_offset + bintable._theap,
        )
    else:
        heap_cache = None

    for row_index, tile_slices in _iter_array_tiles(
        data_shape, tile_shape, first_tile_index, last_tile_index
    ):
        # For tiles near the edge, the tile shape from the header might not be
        # correct so we have to pass the shape manually.
        actual_tile_shape = image_data[tile_slices].shape

        settings = _update_tile_settings(settings, compression_type, actual_tile_shape)

        if compressed_data_column[row_index][0] == 0:
            if gzip_compressed_data_column is None:
                gzip_compressed_data_column = np.array(
                    compressed_data["GZIP_COMPRESSED_DATA"]
                )
                gzip_compressed_data_dtype = _column_dtype(
                    compressed_coldefs, "GZIP_COMPRESSED_DATA"
                )

            # When quantizing floating point data, sometimes the data will not
            # quantize efficiently. In these cases the raw floating point data can
            # be losslessly GZIP compressed and stored in the `GZIP_COMPRESSED_DATA`
            # column.

            cdata = _get_data_from_heap(
                bintable,
                *gzip_compressed_data_column[row_index],
                gzip_compressed_data_dtype,
                heap_cache=heap_cache,
            )

            tile_buffer = _decompress_tile(cdata, algorithm="GZIP_1")

            tile_data = _finalize_array(
                tile_buffer,
                bitpix=zbitpix,
                tile_shape=actual_tile_shape,
                algorithm="GZIP_1",
                lossless=True,
            )

        else:
            cdata = _get_data_from_heap(
                bintable,
                *compressed_data_column[row_index],
                compressed_data_dtype,
                heap_cache=heap_cache,
            )

            if compression_type == "GZIP_2":
                # Decompress with GZIP_1 just to find the total number of
                # elements in the uncompressed data.
                # TODO: find a way to avoid doing this for all tiles
                tile_data = np.asarray(_decompress_tile(cdata, algorithm="GZIP_1"))
                settings["itemsize"] = tile_data.size // int(prod(actual_tile_shape))

            tile_buffer = _decompress_tile(
                cdata, algorithm=compression_type, **settings
            )

            tile_data = _finalize_array(
                tile_buffer,
                bitpix=zbitpix,
                tile_shape=actual_tile_shape,
                algorithm=compression_type,
                lossless=not quantized,
            )

            if zblank_column is None:
                zblank = zblank_header
            else:
                zblank = zblank_column[row_index]

            if zblank is not None:
                blank_mask = tile_data == zblank

            if quantized:
                q = Quantize(
                    row=(row_index + dither_seed) if dither_method != -1 else 0,
                    dither_method=dither_method,
                    quantize_level=None,
                    bitpix=zbitpix,
                )
                tile_data = np.asarray(
                    q.decode_quantized(
                        tile_data, zscale_column[row_index], zzero_column[row_index]
                    )
                ).reshape(actual_tile_shape)

            if zblank is not None:
                if not tile_data.flags.writeable:
                    tile_data = tile_data.copy()
                tile_data[blank_mask] = zblank_header if zbitpix > 0 else np.nan

        image_data[tile_slices] = tile_data

    return image_data


def compress_image_data(
    image_data,
    compression_type,
    compressed_header,
    compressed_coldefs,
):
    """
    Compress the data in a `~astropy.io.fits.CompImageHDU`.

    The input HDU is expected to have a uncompressed numpy array as it's
    ``.data`` attribute.

    Parameters
    ----------
    image_data : `~numpy.ndarray`
        The image data to compress
    compression_type : str
        The compression algorithm
    compressed_header : `~astropy.io.fits.Header`
        The header of the compressed binary table
    compressed_coldefs : `~astropy.io.fits.ColDefs`
        The ColDefs object for the compressed binary table

    Returns
    -------
    nbytes : `int`
        The number of bytes of the heap.
    heap : `bytes`
        The bytes of the FITS table heap.
    """
    if not isinstance(image_data, np.ndarray):
        raise TypeError("Image data must be a numpy.ndarray")

    _check_compressed_header(compressed_header)

    # TODO: This implementation is memory inefficient as it generates all the
    # compressed bytes before forming them into the heap, leading to 2x the
    # potential memory usage. Directly storing the compressed bytes into an
    # expanding heap would fix this.

    tile_shape = _tile_shape(compressed_header)
    data_shape = _data_shape(compressed_header)

    compressed_bytes = []
    gzip_fallback = []
    scales = []
    zeros = []
    zblank = None

    noisebit = _get_compression_setting(compressed_header, "noisebit", 0)

    settings = _header_to_settings(compressed_header)

    for irow, tile_slices in _iter_array_tiles(data_shape, tile_shape):
        tile_data = image_data[tile_slices]

        if tile_data.dtype.kind == "u":
            if tile_data.dtype.itemsize == 4:
                tile_data = (tile_data.astype(np.int64) - 2**31).astype(np.int32)
            elif tile_data.dtype.itemsize == 2:
                tile_data = (tile_data.astype(np.int32) - 2**15).astype(np.int16)

        settings = _update_tile_settings(settings, compression_type, tile_data.shape)

        quantize = "ZSCALE" in compressed_coldefs.dtype.names

        if tile_data.dtype.kind == "f" and quantize:
```

## 原始行 169 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py
sed -n '1360,1445p' astropy/io/fits/hdu/compressed/tests/test_compressed.py"
```

退出码：`0`

输出：
```
import hashlib
from pathlib import Path

import numpy as np
import pytest
from numpy.testing import assert_allclose, assert_equal

from astropy.io import fits
from astropy.io.fits.hdu.compressed._codecs import PLIO1
from astropy.io.fits.hdu.compressed._compression import CfitsioException
from astropy.utils.exceptions import AstropyUserWarning

from .conftest import fitsio_param_to_astropy_param


@pytest.fixture
def canonical_data_base_path():
    return Path(__file__).parent / "data"


@pytest.fixture(
    params=(Path(__file__).parent / "data").glob("m13_*.fits"), ids=lambda x: x.name
)
def canonical_int_hdus(request):
    """
    This fixture provides 4 files downloaded from https://fits.gsfc.nasa.gov/registry/tilecompression.html

    Which are used as canonical tests of data not compressed by Astropy.
    """
    with fits.open(request.param) as hdul:
        yield hdul[1]


@pytest.fixture
def original_int_hdu(canonical_data_base_path):
    with fits.open(canonical_data_base_path / "m13.fits") as hdul:
        yield hdul[0]


def test_canonical_data(original_int_hdu, canonical_int_hdus):
    assert_allclose(original_int_hdu.data, canonical_int_hdus.data)


def test_zblank_support(canonical_data_base_path, tmp_path):
    # This uses a test 12x12 image which contains a NaN value in the [1, 1]
    # pixel - it was compressed using fpack which automatically added a ZBLANK
    # header keyword

    # First, check that the ZBLANK keyword is indeed present in the original
    # compressed FITS file
    with fits.open(
        canonical_data_base_path / "compressed_with_nan.fits",
        disable_image_compression=True,
    ) as hduc:
        assert hduc[1].header["ZBLANK"] == -2147483647

    reference = np.arange(144).reshape((12, 12)).astype(float)
    reference[1, 1] = np.nan

    with fits.open(canonical_data_base_path / "compressed_with_nan.fits") as hdul:
        assert_equal(np.round(hdul[1].data), reference)

    # Now generate a file ourselves and check that the output has the ZBLANK
    # keyword set automatically

    hdu = fits.CompImageHDU(
        data=reference, compression_type="RICE_1", tile_shape=(6, 6)
    )

    hdu.writeto(tmp_path / "test_zblank.fits")

    with fits.open(
        tmp_path / "test_zblank.fits", disable_image_compression=True
    ) as hduc:
        # The ZBLANK value is different from before as we don't preserve it,
        # instead we always write out with the default ZBLANK
        assert hduc[1].header["ZBLANK"] == -2147483648

    with fits.open(tmp_path / "test_zblank.fits") as hdul:
        assert_equal(np.round(hdul[1].data), reference)


def test_integer_blank_support(canonical_data_base_path, tmp_path):
    # This uses a test 64x64 section of the m13 image to which three NaN values are added.
    # It is converted to an integer image with blank values and compressed.
    # Then 3 variations of the BLANK/ZBLANK specification are created by
    # editing the header and compressed data table.
    # When these are read in, the result is a float image that should be the same
    # as the original (including NaNs for blanks).

    with fits.open(canonical_data_base_path / "m13.fits") as hdul:
        # pick a 64x64 pixel subset
        data = hdul[0].data[116:180, 116:180]
        header = hdul[0].header.copy()
        del header["CHECKSUM"]
        del header["DATASUM"]

    # float version of image with NaNs as blanks
    reference = data.astype(np.float32)
    reference[[1, 2, 3], [1, 2, 3]] = np.nan

    # set blanks in the int16 image and BLANK keyword in header
    # choose a blank value that differs from the default
    blank = -16384
    data[np.isnan(reference)] = blank
    header["BLANK"] = blank

    # create the compressed file
    cfile1 = tmp_path / "compressed_with_blank.fits"
    hdu = fits.CompImageHDU(
        data=data, header=header, compression_type="RICE_1", tile_shape=(16, 16)
    )
    hdu.writeto(cfile1, overwrite=True, checksum=False)

    # replace BLANK keyword in header with ZBLANK keyword
    cfile2 = tmp_path / "compressed_with_zblank.fits"
    with fits.open(cfile1, disable_image_compression=True) as hdul:
        assert "ZBLANK" not in hdul[1].header
        hdul[1].header["ZBLANK"] = hdul[1].header["BLANK"]
        del hdul[1].header["BLANK"]
        hdul.writeto(cfile2, overwrite=True, checksum=False)

    # replace ZBLANK in header with with ZBLANK in table column
    # This creates a file structure that is unlikely to be encountered in the wild
    # but that is apparently allowed by the FITS standard.
    # Two versions are created, one without the BLANK keyword and one with it.
    cfile3 = tmp_path / "compressed_with_zblank_column.fits"
    cfile4 = tmp_path / "compressed_with_zblank_column_and_blank.fits"
    with fits.open(cfile2, disable_image_compression=True) as hdul:
        phdu = hdul[0]
        thdu = hdul[1]
        orig_table = hdul[1].data
        orig_cols = orig_table.columns
        zblank = thdu.header["ZBLANK"]
        new_cols = fits.ColDefs(
            [
                fits.Column(
                    name="COMPRESSED_DATA",
                    format="1PB()",
                    array=thdu.data.field("COMPRESSED_DATA"),
                ),
                fits.Column(
                    name="ZBLANK",
                    format="I",
                    array=np.zeros(len(orig_table), dtype=np.int32) + zblank,
                ),
            ]
        )
        new_thdu = fits.BinTableHDU.from_columns(new_cols, header=thdu.header)
        del new_thdu.header["ZBLANK"]
        new_hdul = fits.HDUList([phdu, new_thdu])
        new_hdul.writeto(cfile3, overwrite=True, checksum=False)
        new_thdu.header["BLANK"] = blank
        new_hdul = fits.HDUList([phdu, new_thdu])
        new_hdul.writeto(cfile4, overwrite=True, checksum=False)

    # now test the 4 files to confirm they all uncompress correctly
    for filename in (cfile1, cfile2, cfile4):
        with fits.open(canonical_data_base_path / filename) as hdul:
            assert_equal(hdul[1].data, reference)
            # ensure that the uncompressed header is created with BLANK keyword
            assert hdul[1].header.get("BLANK") == blank

    # this one generates an expected warning
    with pytest.warns(
        AstropyUserWarning,
        match="Setting default value -32768 for missing BLANK keyword in compressed extension",
    ):
        with fits.open(cfile3) as hdul:
            assert_equal(hdul[1].data, reference)
            assert hdul[1].header.get("BLANK") == -32768


@pytest.mark.parametrize(
    ("shape", "tile_shape"),
    (
        ([10, 10], [5, 5]),  # something for HCOMPRESS
        ([5, 5, 5], [5, 5, 5]),
        # ([5, 5, 5], [5, 5, 1]),  # something for HCOMPRESS
        ([10, 15, 20], [5, 5, 5]),
        ([10, 5, 12], [5, 5, 5]),
        # TODO: There's a stupid bit of code in CompImageHDU which stops this working.
        # ([2, 3, 4, 5], [1, 1, 2, 3]),
        ([2, 3, 4, 5], [5, 5, 1, 1]),
    ),
)
def test_roundtrip_high_D(
    numpy_rng, compression_type, compression_param, tmp_path, dtype, shape, tile_shape
):
    if compression_type == "HCOMPRESS_1" and (
        # We don't have at least a 2D image
        len(shape) < 2
        or
        # We don't have 2D tiles
        np.count_nonzero(np.array(tile_shape) != 1) != 2
        or
        # TODO: The following restrictions can be lifted with some extra work.
        # The tile is not the first two dimensions of the data
        tile_shape[0] == 1
        or tile_shape[1] == 1
        or
        # The tile dimensions not an integer multiple of the array dims
        np.count_nonzero(np.array(shape[:2]) % tile_shape[:2]) != 0
    ):
        pytest.xfail("HCOMPRESS requires 2D tiles.")
    random = numpy_rng.uniform(high=255, size=shape)
    # Set first value to be exactly zero as zero values require special treatment
    # for SUBTRACTIVE_DITHER_2
    random.ravel()[0] = 0.0
    original_data = random.astype(dtype)

    dtype_sanitizer = {
        ">": "big",
        "<": "little",
        "=": "native",
    }
    filename = (
        tmp_path / f"{compression_type}_{dtype[1:]}_{dtype_sanitizer[dtype[0]]}.fits"
    )

    param = fitsio_param_to_astropy_param(compression_param)
    hdu = fits.CompImageHDU(
        data=original_data,
        compression_type=compression_type,
        tile_shape=tile_shape,
        **param,
    )
    hdu.writeto(filename)

    atol = 0
    if compression_param.get("qmethod", None) is not None:
        # This is a horrific hack We are comparing quantized data to unquantized
        # data here, so there can be pretty large differences.  What this test
        # is really checking for is arrays which are *completely* different,
        # which would indicate the compression has not worked.
        atol = 17

    with fits.open(filename) as hdul:
        a = hdul[1].data
        np.testing.assert_allclose(original_data, hdul[1].data, atol=atol)
        with fits.open(fileobj) as hdulist:
            for idx in range(6):
                assert_equal(hdulist[idx + 1].data, idx)
                assert hdulist[idx + 1].data.shape == (2**idx, 2**idx)
                fileobj.seek(0)


@pytest.mark.parametrize(
    "init_kwargs, expected_zflags",
    [
        pytest.param(
            dict(quantize_level=-32, data=np.array([0.0])),
            {
                "ZNAME1": "BLOCKSIZE",
                "ZVAL1": 32,
                "ZNAME2": "BYTEPIX",
                "ZVAL2": 4,
                "ZNAME3": "NOISEBIT",
                "ZVAL3": -32,
                "ZCMPTYPE": "RICE_1",
                "ZQUANTIZ": "NO_DITHER",
            },
            id="quantize_level_w_data",
        ),
        pytest.param(
            dict(quantize_level=-32),
            {
                "ZNAME1": "BLOCKSIZE",
                "ZVAL1": 32,
                "ZNAME2": "BYTEPIX",
                "ZVAL2": 4,
                "ZNAME3": "NOISEBIT",
                "ZVAL3": -32,
                "ZCMPTYPE": "RICE_1",
                "ZQUANTIZ": "NO_DITHER",
            },
            id="quantize_level_wo_data",
        ),
        pytest.param(
            dict(quantize_method=2, dither_seed=1, data=np.array([0.0])),
            {
                "ZNAME1": "BLOCKSIZE",
                "ZVAL1": 32,
                "ZNAME2": "BYTEPIX",
                "ZVAL2": 4,
                "ZNAME3": "NOISEBIT",
                "ZVAL3": 16,
                "ZCMPTYPE": "RICE_1",
                "ZQUANTIZ": "SUBTRACTIVE_DITHER_2",
            },
            id="quantize_level_dither_seed_w_data",
        ),
        pytest.param(
            dict(quantize_method=2, dither_seed=1),
            {
                "ZNAME1": "BLOCKSIZE",
                "ZVAL1": 32,
                "ZNAME2": "BYTEPIX",
                "ZVAL2": 4,
                "ZNAME3": "NOISEBIT",
                "ZVAL3": 16,
                "ZCMPTYPE": "RICE_1",
                "ZQUANTIZ": "SUBTRACTIVE_DITHER_2",
            },
            id="quantize_level_dither_seed_wo_data",
        ),
    ],
)
def test_compression_options_with_mutated_data(
    init_kwargs,
    expected_zflags,
    tmp_path,
):
    # see https://github.com/astropy/astropy/issues/12216
    prng = np.random.default_rng(seed=0)
    data = prng.random((50, 30)).astype("float32")

    hdu = fits.CompImageHDU(**init_kwargs)
    hdu.data = data

    hdu.writeto(tmp_path / "t.fits")

    hdr = fits.getheader(tmp_path / "t.fits", ext=1, disable_image_compression=True)

    zflags = {k: hdr[k] for k in expected_zflags}
    assert zflags == expected_zflags
```

## 原始行 172 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"raises(.*Runtime\\|raises(.*Value\\|CfitsioException\\|Corrupt\\|invalid.*compress\\|Invalid.*compress\" astropy/io/fits/hdu/compressed/tests | head -300"
```

退出码：`0`

输出：
```
astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py:10:from astropy.io.fits.hdu.compressed._compression import CfitsioException
astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py:247:    with pytest.raises(ValueError):
astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py:278:            CfitsioException,
```

## 原始行 174 · command_execution

命令：
```
/bin/bash -lc "sed -n '230,300p' astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py
sed -n '145,255p' astropy/io/fits/hdu/compressed/_tiled_compression.py"
```

退出码：`0`

输出：
```
    atol = 0
    if compression_param.get("qmethod", None) is not None:
        # This is a horrific hack We are comparing quantized data to unquantized
        # data here, so there can be pretty large differences.  What this test
        # is really checking for is arrays which are *completely* different,
        # which would indicate the compression has not worked.
        atol = 17

    with fits.open(filename) as hdul:
        a = hdul[1].data
        np.testing.assert_allclose(original_data, hdul[1].data, atol=atol)


def test_plio_1_out_of_range():
    pc = PLIO1(tilesize=10)
    data = np.arange(-10, 0).astype(np.int32)

    with pytest.raises(ValueError):
        pc.encode(data)


def test_invalid_tile(tmp_path):
    # Regression test for a bug that caused a segmentation fault if the data
    # for a tile would have resulted in a warning

    m13_rice_path = Path(__file__).parent / "data" / "m13_rice.fits"

    # For this test, we will change the length of the first chunk so that it is
    # invalid. To do this, we just change the bytes directly so we first check
    # a checksum of the file to make sure it is as we expect to start with.

    with open(m13_rice_path, "rb") as f:
        content = f.read()

    assert hashlib.sha256(content).hexdigest()[:8] == "de6d2f69"

    # We change bytes 8640 to 8643 which are the length of the first tile:

    assert content[8640:8644] == b"\x00\x00\x00\x96"

    with open(tmp_path / "m13_corrupted.fits", "wb") as f:
        f.write(content[:8640])
        f.write(b"\x00\x00\x00\x95")
        f.write(content[8644:])

    with fits.open(tmp_path / "m13_corrupted.fits") as hdulist:
        # Access the data to make sure we decompress it
        with pytest.raises(
            CfitsioException,
            match="decompression error: hit end of compressed byte stream",
        ):
            hdulist[1].data.sum()
            tile_buffer = tile_buffer[:tile_size]

        if tile_buffer.data.format == "b":
            # NOTE: this feels like a Numpy bug - need to investigate
            tile_data = np.asarray(tile_buffer, dtype=np.uint8).reshape(tile_shape)
        else:
            tile_data = np.asarray(tile_buffer).reshape(tile_shape)

    return tile_data
























































































def _get_compression_setting(header, name, default):
    # Settings for the various compression algorithms are stored in pairs of
    # keywords called ZNAME? and ZVAL? - a given compression setting could be
    # in any ZNAME? so we need to check through all the possible ZNAMEs which
    # one matches the required setting.

    for i in range(1, 1000):
        if f"ZNAME{i}" not in header:
            break
        if header[f"ZNAME{i}"].lower() == name.lower():
            return header[f"ZVAL{i}"]

    return default
```

## 原始行 177 · file_change

```
{
  "id": "item_118",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/card.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/compressed/_tiled_compression.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 179 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=5'
```

退出码：`0`

输出：
```
Internet access disabled
........................................................................ [ 40%]
........................................................................ [ 80%]
...................................                                      [100%]
179 passed in 0.39s
```

## 原始行 181 · agent_message

```
The full header suite now passes (179 tests). Next I’m validating table-format conversions and the compressed-image failure path; these are the areas most likely to expose exact parsing or exception mismatches.
```

## 原始行 183 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_table.py -q --disable-warnings --maxfail=20'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 36%]
......................................................F................s [ 72%]
ss.....F...........ss......F............................                 [100%]
=================================== FAILURES ===================================
__________________ TestTableFunctions.test_load_guess_format ___________________

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x75c886508310>

    def test_load_guess_format(self):
        """
        Tests loading a table dump with no supplied coldefs or header, so that
        the table format has to be guessed at.  There is of course no exact
        science to this; the table that's produced simply uses sensible guesses
        for that format.  Ideally this should never have to be used.
        """
    
        # Create a table containing a variety of data types.
        a0 = np.array([False, True, False], dtype=bool)
        c0 = fits.Column(name="c0", format="L", array=a0)
    
        # Format X currently not supported by the format
        # a1 = np.array([[0], [1], [0]], dtype=np.uint8)
        # c1 = fits.Column(name='c1', format='X', array=a1)
    
        a2 = np.array([1, 128, 255], dtype=np.uint8)
        c2 = fits.Column(name="c2", format="B", array=a2)
        a3 = np.array([-30000, 1, 256], dtype=np.int16)
        c3 = fits.Column(name="c3", format="I", array=a3)
        a4 = np.array([-123123123, 1234, 123123123], dtype=np.int32)
        c4 = fits.Column(name="c4", format="J", array=a4)
        a5 = np.array(["a", "abc", "ab"])
        c5 = fits.Column(name="c5", format="A3", array=a5)
        a6 = np.array([1.1, 2.2, 3.3], dtype=np.float64)
        c6 = fits.Column(name="c6", format="D", array=a6)
        a7 = np.array([1.1 + 2.2j, 3.3 + 4.4j, 5.5 + 6.6j], dtype=np.complex128)
        c7 = fits.Column(name="c7", format="M", array=a7)
        a8 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]], dtype=np.int32)
        c8 = fits.Column(name="c8", format="PJ()", array=a8)
    
        tbhdu = fits.BinTableHDU.from_columns([c0, c2, c3, c4, c5, c6, c7, c8])
    
        datafile = self.temp("data.txt")
>       tbhdu.dump(datafile)

astropy/io/fits/tests/test_table.py:2421: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/table.py:1087: in dump
    self._dump_data(datafile)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.table.BinTableHDU object at 0x75c886c4a550>
fileobj = <_io.TextIOWrapper name='/tmp/fits-test-mjyxdw1u/data.txt' mode='w' encoding='UTF-8'>

    def _dump_data(self, fileobj):
        """
        Write the table data in the ASCII format read by BinTableHDU.load()
        to fileobj.
        """
        if not fileobj and self._file:
            root = os.path.splitext(self._file.name)[0]
            fileobj = root + ".txt"
    
        close_file = False
    
        if isinstance(fileobj, str):
            fileobj = open(fileobj, "w")
            close_file = True
    
        linewriter = csv.writer(fileobj, dialect=FITSTableDumpDialect)
    
        # Process each row of the table and output one row at a time
        def format_value(val, format):
            if format[0] == "S":
                itemsize = int(format[1:])
                return "{:{size}}".format(val, size=itemsize)
            elif format in np.typecodes["AllInteger"]:
                # output integer
                return f"{val:21d}"
            elif format in np.typecodes["Complex"]:
                return f"{val.real:21.15g}+{val.imag:.15g}j"
            elif format in np.typecodes["Float"]:
                # output floating point
                return f"{val:#21.15g}"
    
        for row in self.data:
            line = []  # the line for this row of the table
    
            # Process each column of the row.
            for column in self.columns:
                # format of data in a variable length array
                # where None means it is not a VLA:
                vla_format = None
                format = _convert_format(column.format)
    
                if isinstance(format, _FormatP):
                    # P format means this is a variable length array so output
                    # the length of the array for this row and set the format
                    # for the VLA data
                    line.append("VLA_Length=")
                    line.append(f"{len(row[column.name]):21d}")
>                   _, dtype, option = _parse_tformat(column.format)
                                       ^^^^^^^^^^^^^^
E                   NameError: name '_parse_tformat' is not defined

astropy/io/fits/hdu/table.py:1231: NameError
___________________ TestTableFunctions.test_ascii_floattypes ___________________

self = <[ValueError("could not convert string to float: np.bytes_(b'   1.550000E+01.'); the header may be missing the necessary TNULL2 keyword or the table contains invalid data") raised in repr()] FITS_rec object at 0x75c885818550>
column = name = 'b'; format = 'D16'; start = 26
field = chararray([b'   1.550000D+01.', b'   1.660000D+01.'], dtype='|S16')

    def _convert_ascii(self, column, field):
        """
        Special handling for ASCII table columns to convert columns containing
        numeric types to actual numeric arrays from the string representation.
        """
        format = column.format
        recformat = getattr(format, "recformat", ASCII2NUMPY[format[0]])
        # if the string = TNULL, return ASCIITNULL
        nullval = str(column.null).strip().encode("ascii")
        if len(nullval) > format.width:
            nullval = nullval[: format.width]
    
        # Before using .replace make sure that any trailing bytes in each
        # column are filled with spaces, and *not*, say, nulls; this causes
        # functions like replace to potentially leave gibberish bytes in the
        # array buffer.
        dummy = np.char.ljust(field, format.width)
        dummy = np.char.replace(dummy, encode_ascii("D"), encode_ascii("E"))
        null_fill = encode_ascii(str(ASCIITNULL).rjust(format.width))
    
        # Convert all fields equal to the TNULL value (nullval) to empty fields.
        # TODO: These fields really should be converted to NaN or something else undefined.
        # Currently they are converted to empty fields, which are then set to zero.
        dummy = np.where(np.char.strip(dummy) == nullval, null_fill, dummy)
    
        # always replace empty fields, see https://github.com/astropy/astropy/pull/5394
        if nullval != b"":
            dummy = np.where(np.char.strip(dummy) == b"", null_fill, dummy)
    
        try:
>           dummy = np.array(dummy, dtype=recformat)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E           ValueError: could not convert string to float: np.bytes_(b'   1.550000E+01.')

astropy/io/fits/fitsrec.py:893: ValueError

During handling of the above exception, another exception occurred:

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x75c8864f9650>

    def test_ascii_floattypes(self):
        """Test different float formats."""
        col1 = fits.Column(
            name="a", format="D", array=np.array([11.1, 12.2]), ascii=True
        )
        col2 = fits.Column(
            name="b", format="D16", array=np.array([15.5, 16.6]), ascii=True
        )
        col3 = fits.Column(
            name="c", format="D16.7", array=np.array([1.1, 2.2]), ascii=True
        )
        hdu = fits.TableHDU.from_columns([col1, col2, col3])
        hdu.writeto(self.temp("foo.fits"))
    
        with fits.open(self.temp("foo.fits"), memmap=False) as hdul:
>           assert comparerecords(hdul[1].data, hdu.data)
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_table.py:3003: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/tests/test_table.py:77: in comparerecords
    fielda = a.field(i)
             ^^^^^^^^^^
astropy/io/fits/fitsrec.py:743: in field
    converted = self._convert_other(column, field, recformat)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/fitsrec.py:926: in _convert_other
    field = self._convert_ascii(column, field)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[ValueError("could not convert string to float: np.bytes_(b'   1.550000E+01.'); the header may be missing the necessary TNULL2 keyword or the table contains invalid data") raised in repr()] FITS_rec object at 0x75c885818550>
column = name = 'b'; format = 'D16'; start = 26
field = chararray([b'   1.550000D+01.', b'   1.660000D+01.'], dtype='|S16')

    def _convert_ascii(self, column, field):
        """
        Special handling for ASCII table columns to convert columns containing
        numeric types to actual numeric arrays from the string representation.
        """
        format = column.format
        recformat = getattr(format, "recformat", ASCII2NUMPY[format[0]])
        # if the string = TNULL, return ASCIITNULL
        nullval = str(column.null).strip().encode("ascii")
        if len(nullval) > format.width:
            nullval = nullval[: format.width]
    
        # Before using .replace make sure that any trailing bytes in each
        # column are filled with spaces, and *not*, say, nulls; this causes
        # functions like replace to potentially leave gibberish bytes in the
        # array buffer.
        dummy = np.char.ljust(field, format.width)
        dummy = np.char.replace(dummy, encode_ascii("D"), encode_ascii("E"))
        null_fill = encode_ascii(str(ASCIITNULL).rjust(format.width))
    
        # Convert all fields equal to the TNULL value (nullval) to empty fields.
        # TODO: These fields really should be converted to NaN or something else undefined.
        # Currently they are converted to empty fields, which are then set to zero.
        dummy = np.where(np.char.strip(dummy) == nullval, null_fill, dummy)
    
        # always replace empty fields, see https://github.com/astropy/astropy/pull/5394
        if nullval != b"":
            dummy = np.where(np.char.strip(dummy) == b"", null_fill, dummy)
    
        try:
            dummy = np.array(dummy, dtype=recformat)
        except ValueError as exc:
>           raise ValueError(
                f"{exc}; the header may be missing the necessary "
                f"TNULL{self.names.index(column.name) + 1} keyword or the table "
                "contains invalid data"
            )
E           ValueError: could not convert string to float: np.bytes_(b'   1.550000E+01.'); the header may be missing the necessary TNULL2 keyword or the table contains invalid data

astropy/io/fits/fitsrec.py:895: ValueError
____________ TestColumnFunctions.test_column_format_interpretation _____________

self = <astropy.io.fits.tests.test_table.TestColumnFunctions object at 0x75c8864f94d0>

    def test_column_format_interpretation(self):
        """
        Test to ensure that when Numpy-style record formats are passed in to
        the Column constructor for the format argument, they are recognized so
        long as it's unambiguous (where "unambiguous" here is questionable
        since Numpy is case insensitive when parsing the format codes.  But
        their "proper" case is lower-case, so we can accept that.  Basically,
        actually, any key in the NUMPY2FITS dict should be accepted.
        """
    
        for recformat, fitsformat in NUMPY2FITS.items():
            if recformat == "S":
                fitsformat = "0A"
            c = fits.Column("TEST", np.dtype(recformat))
>           assert c.format == fitsformat
                   ^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_table.py:3459: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/column.py:264: in __eq__
    other = self.__class__(other)
            ^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/column.py:365: in __new__
    self.format, self.width, self.precision = _parse_ascii_tformat(format, strict)
                                              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

tform = 'L', strict = False

    def _parse_ascii_tformat(tform, strict=False):
        """Parse an ASCII-table ``TFORMn`` value."""
        if not isinstance(tform, str):
            raise VerifyError(f"Format {tform!r} is not recognized.")
    
        value = tform.upper()
        match = TFORMAT_ASCII_RE.match(value)
        if match is None or match.end() != len(value):
>           raise VerifyError(f"Format {tform!r} is not recognized.")
E           astropy.io.fits.verify.VerifyError: Format 'L' is not recognized.

astropy/io/fits/column.py:2312: VerifyError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_load_guess_format
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_ascii_floattypes
FAILED astropy/io/fits/tests/test_table.py::TestColumnFunctions::test_column_format_interpretation
3 failed, 192 passed, 5 skipped in 2.09s
```

## 原始行 186 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"ASCII2STR\\|format.precision\\|precision}\" astropy/io/fits | head -100
sed -n '1540,1640p' astropy/io/fits/fitsrec.py
sed -n '1420,1510p' astropy/io/fits/fitsrec.py"
```

退出码：`0`

输出：
```
astropy/io/fits/fitsrec.py:18:    ASCII2STR,
astropy/io/fits/fitsrec.py:1318:        fmt = "".join([_pc, format[1:], ASCII2STR[format[0]], "}", (" " * trail)])
astropy/io/fits/fitsrec.py:1320:        # Even if the format precision is 0, we should output a decimal point
astropy/io/fits/fitsrec.py:1323:        trailing_decimal = format.precision == 0 and format.format in ("F", "E", "D")
astropy/io/fits/column.py:84:ASCII2STR = {"A": "", "I": "d", "J": "d", "F": "f", "E": "E", "D": "E"}
astropy/io/fits/column.py:145:    "F": "{{:{width}.{precision}f}}",
astropy/io/fits/column.py:146:    "G": "{{:{width}.{precision}g}}",
astropy/io/fits/column.py:151:] = "{{:{width}.{precision}e}}"
astropy/io/fits/column.py:405:            return f"{self.format}{self.width}.{self.precision}"
astropy/io/fits/column.py:2338:            f"Decimal precision ({precision}) must be less than the column width ({width})."
astropy/io/fits/tests/test_table.py:3477:        assert c.format.precision == 8
astropy/io/fits/tests/test_table.py:3482:        assert c.format.precision == 8
astropy/io/fits/tests/test_table.py:3487:        assert c.format.precision == 8
astropy/io/fits/tests/test_table.py:3494:        assert c.format.precision == 0
astropy/io/fits/tests/test_table.py:3499:        assert c.format.precision == 0
astropy/io/fits/tests/test_table.py:3504:        assert c.format.precision == 0
```

## 原始行 188 · command_execution

命令：
```
/bin/bash -lc "sed -n '1285,1335p' astropy/io/fits/fitsrec.py"
```

退出码：`0`

输出：
```
        spans = self._coldefs.spans
        format = self._coldefs[col_idx].format

        # The index of the "end" column of the record, beyond
        # which we can't write
        end = super().field(-1).itemsize
        starts.append(end + starts[-1])

        if col_idx > 0:
            lead = starts[col_idx] - starts[col_idx - 1] - spans[col_idx - 1]
        else:
            lead = 0

        if lead < 0:
            warnings.warn(
                f"Column {col_idx + 1} starting point overlaps the previous column."
            )

        trail = starts[col_idx + 1] - starts[col_idx] - spans[col_idx]

        if trail < 0:
            warnings.warn(
                f"Column {col_idx + 1} ending point overlaps the next column."
            )

        # TODO: It would be nice if these string column formatting
        # details were left to a specialized class, as is the case
        # with FormatX and FormatP
        if "A" in format:
            _pc = "{:"
        else:
            _pc = "{:>"

        fmt = "".join([_pc, format[1:], ASCII2STR[format[0]], "}", (" " * trail)])

        # Even if the format precision is 0, we should output a decimal point
        # as long as there is space to do so--not including a decimal point in
        # a float value is discouraged by the FITS Standard
        trailing_decimal = format.precision == 0 and format.format in ("F", "E", "D")

        # not using numarray.strings's num2char because the
        # result is not allowed to expand (as C/Python does).
        for jdx, value in enumerate(input_field):
            value = fmt.format(value)
            if len(value) > starts[col_idx + 1] - starts[col_idx]:
                raise ValueError(
                    f"Value {value!r} does not fit into the output's itemsize of "
                    f"{spans[col_idx]}."
                )

            if trailing_decimal and value[0] == " ":
```

## 原始行 191 · file_change

```
{
  "id": "item_127",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 194 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_table.py -q --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 36%]
......................................................F................s [ 72%]
ss.................ss......F............................                 [100%]
=================================== FAILURES ===================================
__________________ TestTableFunctions.test_load_guess_format ___________________

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x79f996087f90>

    def test_load_guess_format(self):
        """
        Tests loading a table dump with no supplied coldefs or header, so that
        the table format has to be guessed at.  There is of course no exact
        science to this; the table that's produced simply uses sensible guesses
        for that format.  Ideally this should never have to be used.
        """
    
        # Create a table containing a variety of data types.
        a0 = np.array([False, True, False], dtype=bool)
        c0 = fits.Column(name="c0", format="L", array=a0)
    
        # Format X currently not supported by the format
        # a1 = np.array([[0], [1], [0]], dtype=np.uint8)
        # c1 = fits.Column(name='c1', format='X', array=a1)
    
        a2 = np.array([1, 128, 255], dtype=np.uint8)
        c2 = fits.Column(name="c2", format="B", array=a2)
        a3 = np.array([-30000, 1, 256], dtype=np.int16)
        c3 = fits.Column(name="c3", format="I", array=a3)
        a4 = np.array([-123123123, 1234, 123123123], dtype=np.int32)
        c4 = fits.Column(name="c4", format="J", array=a4)
        a5 = np.array(["a", "abc", "ab"])
        c5 = fits.Column(name="c5", format="A3", array=a5)
        a6 = np.array([1.1, 2.2, 3.3], dtype=np.float64)
        c6 = fits.Column(name="c6", format="D", array=a6)
        a7 = np.array([1.1 + 2.2j, 3.3 + 4.4j, 5.5 + 6.6j], dtype=np.complex128)
        c7 = fits.Column(name="c7", format="M", array=a7)
        a8 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]], dtype=np.int32)
        c8 = fits.Column(name="c8", format="PJ()", array=a8)
    
        tbhdu = fits.BinTableHDU.from_columns([c0, c2, c3, c4, c5, c6, c7, c8])
    
        datafile = self.temp("data.txt")
        tbhdu.dump(datafile)
    
        new_tbhdu = fits.BinTableHDU.load(datafile)
    
        # In this particular case the record data at least should be equivalent
>       assert comparerecords(tbhdu.data, new_tbhdu.data)
E       AssertionError: assert False
E        +  where False = comparerecords(FITS_rec([(False, 1, -30000, -123123123, 'a', 1.1, 1.1+2.2j, [1, 2, 3]),\n          (True, 128, 1, 1234, 'abc', 2.2, 3.... 'i1'), ('c2', 'u1'), ('c3', '<i2'), ('c4', '<i4'), ('c5', 'S3'), ('c6', '<f8'), ('c7', '<c16'), ('c8', '<i4', (2,))])), FITS_rec([(0, 1, -30000, -123123123, 'a', 1.1, 1.1+2.2j, [1, 2, 3]),\n          (1, 128, 1, 1234, 'a', 2.2, 3.3+4.4j, [..., 'u1'), ('f1', 'u1'), ('f2', '<i2'), ('f3', '<i4'), ('f4', 'S1'), ('f5', '<f8'), ('f6', '<c16'), ('f7', 'u1', (3,))])))
E        +    where FITS_rec([(False, 1, -30000, -123123123, 'a', 1.1, 1.1+2.2j, [1, 2, 3]),\n          (True, 128, 1, 1234, 'abc', 2.2, 3.... 'i1'), ('c2', 'u1'), ('c3', '<i2'), ('c4', '<i4'), ('c5', 'S3'), ('c6', '<f8'), ('c7', '<c16'), ('c8', '<i4', (2,))])) = <astropy.io.fits.hdu.table.BinTableHDU object at 0x79f995fab890>.data
E        +    and   FITS_rec([(0, 1, -30000, -123123123, 'a', 1.1, 1.1+2.2j, [1, 2, 3]),\n          (1, 128, 1, 1234, 'a', 2.2, 3.3+4.4j, [..., 'u1'), ('f1', 'u1'), ('f2', '<i2'), ('f3', '<i4'), ('f4', 'S1'), ('f5', '<f8'), ('f6', '<c16'), ('f7', 'u1', (3,))])) = <astropy.io.fits.hdu.table.BinTableHDU object at 0x79f995fa1b90>.data

astropy/io/fits/tests/test_table.py:2426: AssertionError
----------------------------- Captured stdout call -----------------------------
fielda:  ['a' 'abc' 'ab']
fieldb:  ['a' 'a' 'a']
field 4 differs
____________ TestColumnFunctions.test_column_format_interpretation _____________

self = <astropy.io.fits.tests.test_table.TestColumnFunctions object at 0x79f99609e9d0>

    def test_column_format_interpretation(self):
        """
        Test to ensure that when Numpy-style record formats are passed in to
        the Column constructor for the format argument, they are recognized so
        long as it's unambiguous (where "unambiguous" here is questionable
        since Numpy is case insensitive when parsing the format codes.  But
        their "proper" case is lower-case, so we can accept that.  Basically,
        actually, any key in the NUMPY2FITS dict should be accepted.
        """
    
        for recformat, fitsformat in NUMPY2FITS.items():
            if recformat == "S":
                fitsformat = "0A"
            c = fits.Column("TEST", np.dtype(recformat))
>           assert c.format == fitsformat
E           AssertionError: assert 'i1' == 'L'
E             
E             - L
E             + i1

astropy/io/fits/tests/test_table.py:3459: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_load_guess_format
FAILED astropy/io/fits/tests/test_table.py::TestColumnFunctions::test_column_format_interpretation
2 failed, 193 passed, 5 skipped in 1.32s
```

## 原始行 197 · command_execution

命令：
```
/bin/bash -lc "grep -n \"_scalar_to_format\\|guess.*format\\|_cmp_recformats\" astropy/io/fits/hdu/table.py | head -50
sed -n '1250,1400p' astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```
19:from astropy.io.fits.column import ATTRIBUTE_TO_KEYWORD, FITS2NUMPY, KEYWORD_NAMES, KEYWORD_TO_ATTRIBUTE, TDEF_RE, ColDefs, Column, _AsciiColDefs, _cmp_recformats, _convert_format, _FormatP, _FormatQ, _makep, _parse_tformat, _scalar_to_format
1310:            fitsformat = _scalar_to_format(value)
1315:                if _cmp_recformats(recformats[idx], recformat) < 0:
                    else:
                        line.append(format_value(row[column.name], array_format))
            linewriter.writerow(line)
        if close_file:
            fileobj.close()

    def _dump_coldefs(self, fileobj):
        """
        Write the column definition parameters in the ASCII format read by
        BinTableHDU.load() to fileobj.
        """
        close_file = False

        if isinstance(fileobj, str):
            fileobj = open(fileobj, "w")
            close_file = True

        # Process each column of the table and output the result to the
        # file one at a time
        for column in self.columns:
            line = [column.name, column.format]
            attrs = ["disp", "unit", "dim", "null", "bscale", "bzero"]
            line += [
                "{!s:16s}".format(value if value else '""')
                for value in (getattr(column, attr) for attr in attrs)
            ]
            fileobj.write(" ".join(line))
            fileobj.write("\n")

        if close_file:
            fileobj.close()

    @classmethod
    def _load_data(cls, fileobj, coldefs=None):
        """
        Read the table data from the ASCII file output by BinTableHDU.dump().
        """
        close_file = False

        if isinstance(fileobj, path_like):
            fileobj = os.path.expanduser(fileobj)
            fileobj = open(fileobj)
            close_file = True

        initialpos = fileobj.tell()  # We'll be returning here later
        linereader = csv.reader(fileobj, dialect=FITSTableDumpDialect)

        # First we need to do some preprocessing on the file to find out how
        # much memory we'll need to reserve for the table.  This is necessary
        # even if we already have the coldefs in order to determine how many
        # rows to reserve memory for
        vla_lengths = []
        recformats = []
        names = []
        nrows = 0
        if coldefs is not None:
            recformats = coldefs._recformats
            names = coldefs.names

        def update_recformats(value, idx):
            fitsformat = _scalar_to_format(value)
            recformat = _convert_format(fitsformat)
            if idx >= len(recformats):
                recformats.append(recformat)
            else:
                if _cmp_recformats(recformats[idx], recformat) < 0:
                    recformats[idx] = recformat

        # TODO: The handling of VLAs could probably be simplified a bit
        for row in linereader:
            nrows += 1
            if coldefs is not None:
                continue
            col = 0
            idx = 0
            while idx < len(row):
                if row[idx] == "VLA_Length=":
                    if col < len(vla_lengths):
                        vla_length = vla_lengths[col]
                    else:
                        vla_length = int(row[idx + 1])
                        vla_lengths.append(vla_length)
                    idx += 2
                    while vla_length:
                        update_recformats(row[idx], col)
                        vla_length -= 1
                        idx += 1
                    col += 1
                else:
                    if col >= len(vla_lengths):
                        vla_lengths.append(None)
                    update_recformats(row[idx], col)
                    col += 1
                    idx += 1

        # Update the recformats for any VLAs
        for idx, length in enumerate(vla_lengths):
            if length is not None:
                recformats[idx] = str(length) + recformats[idx]

        dtype = np.rec.format_parser(recformats, names, None).dtype

        # TODO: In the future maybe enable loading a bit at a time so that we
        # can convert from this format to an actual FITS file on disk without
        # needing enough physical memory to hold the entire thing at once
        hdu = BinTableHDU.from_columns(
            np.recarray(shape=1, dtype=dtype), nrows=nrows, fill=True
        )

        # TODO: It seems to me a lot of this could/should be handled from
        # within the FITS_rec class rather than here.
        data = hdu.data
        for idx, length in enumerate(vla_lengths):
            if length is not None:
                arr = data.columns._arrays[idx]
                dt = recformats[idx][len(str(length)) :]

                # NOTE: FormatQ not supported here; it's hard to determine
                # whether or not it will be necessary to use a wider descriptor
                # type. The function documentation will have to serve as a
                # warning that this is not supported.
                recformats[idx] = _FormatP(dt, max=length)
                data.columns._recformats[idx] = recformats[idx]
                name = data.columns.names[idx]
                data._cache_field(name, _makep(arr, arr, recformats[idx]))

        def format_value(col, val):
            # Special formatting for a couple particular data types
            if recformats[col] == FITS2NUMPY["L"]:
                return bool(int(val))
            elif recformats[col] == FITS2NUMPY["M"]:
                # For some reason, in arrays/fields where numpy expects a
                # complex it's not happy to take a string representation
                # (though it's happy to do that in other contexts), so we have
                # to convert the string representation for it:
                return complex(val)
            else:
                return val

        # Jump back to the start of the data and create a new line reader
        fileobj.seek(initialpos)
        linereader = csv.reader(fileobj, dialect=FITSTableDumpDialect)
        for row, line in enumerate(linereader):
            col = 0
            idx = 0
            while idx < len(line):
                if line[idx] == "VLA_Length=":
                    vla_len = vla_lengths[col]
                    idx += 2
                    slice_ = slice(idx, idx + vla_len)
                    data[row][col][:] = line[idx : idx + vla_len]
```

## 原始行 200 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile
import numpy as np
from astropy.io import fits
from astropy.io.fits.hdu.table import BinTableHDU
from astropy.io.fits.column import _scalar_to_format, _convert_format, _cmp_recformats
c=fits.Column(name='c',format='A3',array=np.array(['a','abc','ab']))
h=fits.BinTableHDU.from_columns([c])
p=tempfile.mktemp(); h.dump(p); print(open(p).read())
for v in ['a','abc','ab']:
 f=_scalar_to_format(v); print(v,f,_convert_format(f))
n=BinTableHDU.load(p); print(n.data,n.data.dtype)
PY"
```

退出码：`0`

输出：
```
"a  "
"abc"
"ab "

a A1 S1
abc A3 S1
ab A2 S1
[('a',) ('a',) ('a',)] (numpy.record, [('f0', 'S1')])
```

## 原始行 204 · file_change

```
{
  "id": "item_136",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 206 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_table.py -q --disable-warnings --maxfail=10'
```

退出码：`0`

输出：
```
Internet access disabled
........................................................................ [ 36%]
.......................................................................s [ 72%]
ss.................ss...................................                 [100%]
195 passed, 5 skipped in 1.14s
```

## 原始行 209 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py::test_invalid_tile -q --disable-warnings
python -m pytest astropy/io/fits/hdu/compressed/tests/test_compressed.py -q --disable-warnings --maxfail=20'
```

退出码：`1`

输出：
```
Internet access disabled
.                                                                        [100%]
1 passed in 0.08s
Internet access disabled
...........s.....s....F........................................F........ [ 78%]
....................                                                     [100%]
=================================== FAILURES ===================================
______________ TestCompressedImage.test_compression_column_tforms ______________

self = <astropy.io.fits.hdu.compressed.tests.test_compressed.TestCompressedImage object at 0x7cd978039c10>

    def test_compression_column_tforms(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/199"""
    
        # Some interestingly tiled data so that some of it is quantized and
        # some of it ends up just getting gzip-compressed
        data2 = (np.arange(1, 8, dtype=np.float32) * 10)[:, np.newaxis] + np.arange(
            1, 7
        )
        np.random.seed(1337)
        data1 = np.random.uniform(size=(6 * 4, 7 * 4))
        data1[: data2.shape[0], : data2.shape[1]] = data2
        chdu = fits.CompImageHDU(data1, compression_type="RICE_1", tile_shape=(6, 7))
        chdu.writeto(self.temp("test.fits"))
    
        with fits.open(self.temp("test.fits"), disable_image_compression=True) as h:
>           assert re.match(r"^1PB\(\d+\)$", h[1].header["TFORM1"])
E           AssertionError: assert None
E            +  where None = <function match at 0x7cd9a5946b60>('^1PB\\(\\d+\\)$', 'PB(55)')
E            +    where <function match at 0x7cd9a5946b60> = re.match

astropy/io/fits/hdu/compressed/tests/test_compressed.py:427: AssertionError
__________ TestCompressedImage.test_compressed_optional_prefix_tform ___________

self = <astropy.io.fits.hdu.compressed.tests.test_compressed.TestCompressedImage object at 0x7cd978012690>
tmp_path = PosixPath('/tmp/pytest-of-root/pytest-4/test_compressed_optional_prefi0')

    def test_compressed_optional_prefix_tform(self, tmp_path):
        # Regression test for a bug that caused an error if a
        # compressed file had TFORM missing the optional 1 prefix
    
        data = np.zeros((3, 4, 5))
    
        hdu1 = fits.CompImageHDU(data=data)
        hdu1.writeto(tmp_path / "compressed.fits")
    
        with fits.open(
            tmp_path / "compressed.fits", disable_image_compression=True, mode="update"
        ) as hdul:
>           assert hdul[1].header["TFORM1"] == "1PB(0)"
E           AssertionError: assert 'PB(0)' == '1PB(0)'
E             
E             - 1PB(0)
E             ? -
E             + PB(0)

astropy/io/fits/hdu/compressed/tests/test_compressed.py:917: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/hdu/compressed/tests/test_compressed.py::TestCompressedImage::test_compression_column_tforms
FAILED astropy/io/fits/hdu/compressed/tests/test_compressed.py::TestCompressedImage::test_compressed_optional_prefix_tform
2 failed, 88 passed, 2 skipped in 4.82s
```

## 原始行 212 · file_change

```
{
  "id": "item_141",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 215 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/hdu/compressed/tests/test_compressed.py::TestCompressedImage::test_compression_column_tforms astropy/io/fits/hdu/compressed/tests/test_compressed.py::TestCompressedImage::test_compressed_optional_prefix_tform -q --disable-warnings'
```

退出码：`0`

输出：
```
Internet access disabled
..                                                                       [100%]
2 passed in 0.15s
```

## 原始行 219 · command_execution

命令：
```
/bin/bash -lc "grep -n \"comment.*preserv\\|update({.*A\\|update.*comment\" astropy/io/fits/tests/test_header.py | head -80
grep -RIn \"Header.*_DelayedHeader\\|_header_str =\\|del .*_header\" astropy/io/fits/tests | head -100"
```

退出码：`0`

输出：
```
275:        header.update({"FOO": ("BAR", "BAZ")})
276:        header.update(FakeHeader([("A", 1), ("B", 2, "comment")]))
281:        # test that comments are preserved
292:    def test_update_comment(self):
294:        hdul[0].header.update({"FOO": ("BAR", "BAZ")})
299:            hdul[0].header.update({"FOO2": ("BAR", "BAZ", "EXTRA")})
871:            header.update({"HIERARCH BLAH BLAH": "TESTA"})
876:            header.update({"HIERARCH BLAH BLAH": "TESTB"})
881:            header.update({"BLAH BLAH": "TESTC"})
887:            header.update({"HIERARCH blah blah": "TESTD"})
899:            header.update({"BLAH BLAH BLAH": "TESTA"})
903:            header.update({"HIERARCH BLAH BLAH BLAH": "TESTB"})
908:            header.update({"BLAH BLAH BLAH": "TESTC"})
913:            header.update({"HIERARCH blah blah blah": "TESTD"})
934:            header.update({"HIERARCH BLA BLA": "TESTA"})
939:            header.update({"HIERARCH BLA BLA": "TESTB"})
944:            header.update({"BLA BLA": "TESTC"})
949:            header.update({"HIERARCH bla bla": "TESTD"})
963:            header.update({"BLA BLA": "TESTA"})
968:            header.update({"HIERARCH BLA BLA": "TESTB"})
973:            header.update({"BLA BLA": "TESTC"})
978:            header.update({"HIERARCH bla bla": "TESTD"})
1350:        header.update({"A": "E", "F": "G"})
1475:    def test_header_extend_update_commentary(self):
1707:    def test_update_commentary(self):
1765:        header.update({"FOO": "BAR"})
1766:        header.update({"BAZ": "QUX"})
1769:        header.update({"FRED": "BARNEY"})
astropy/io/fits/tests/test_table.py:3836:    del hdu._header["TTYPE1"]
astropy/io/fits/tests/test_header.py:2972:        del self._test_header["DP1.AXIS.1"]
astropy/io/fits/tests/test_header.py:2980:        del self._test_header["DP1.AXIS.2"]
astropy/io/fits/tests/test_header.py:3023:        del self._test_header["DP1.A*..."]
```

## 原始行 223 · file_change

```
{
  "id": "item_149",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 226 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py astropy/io/fits/tests/test_header.py astropy/io/fits/tests/test_table.py astropy/io/fits/hdu/compressed/tests -q --disable-warnings --maxfail=20'
```

退出码：`0`

输出：
```
Internet access disabled
......................................s................ssss............. [  7%]
........................................................................ [ 15%]
........................................................................ [ 23%]
........................................................................ [ 31%]
........................................................................ [ 38%]
....................................................................sss. [ 46%]
................ss..................................................s... [ 54%]
..s..................................................................... [ 62%]
........................................................................ [ 69%]
..............................xxxx.xxxx.xxxx.xxxx.xxxx.xxxx............. [ 77%]
........................................................................ [ 85%]
........................................................................ [ 93%]
........................xxxx.xxxx.xxxx.xxxx.xxxx.xxxx.xxxx.xxxx..        [100%]
861 passed, 14 skipped, 56 xfailed in 7.67s
```

## 原始行 228 · agent_message

```
All targeted FITS header, table, core, and compressed-image suites pass: 861 passed, 14 skipped, 56 expected failures. I’m doing a final diff/API audit now for edge cases not covered visibly, especially exact exception behavior and delayed-loading caching.
```

## 原始行 230 · command_execution

命令：
```
/bin/bash -lc "git status --short
git diff --check
git diff --stat
python - <<'PY'
from astropy.io.fits.header import Header, _DelayedHeader
from astropy.io.fits.hdu.base import DELAYED, _BaseHDU

class Lazy:
    _header = _DelayedHeader()

obj = Lazy()
obj._header_str = Header([('A', 1)]).tostring()
first = obj._header
assert first['A'] == 1 and obj._header is first and obj._header_str is None

hdu = object.__new__(_BaseHDU)
assert not hdu._has_data
hdu.__dict__['data'] = DELAYED
assert not hdu._has_data
hdu.__dict__['data'] = None
assert not hdu._has_data
hdu.__dict__['data'] = 0
assert hdu._has_data
print('descriptor/data checks passed')
PY"
```

退出码：`0`

输出：
```
 M astropy/io/fits/card.py
 M astropy/io/fits/column.py
 M astropy/io/fits/convenience.py
 M astropy/io/fits/hdu/base.py
 M astropy/io/fits/hdu/compressed/_tiled_compression.py
 M astropy/io/fits/hdu/compressed/compressed.py
 M astropy/io/fits/hdu/groups.py
 M astropy/io/fits/hdu/hdulist.py
 M astropy/io/fits/hdu/image.py
 M astropy/io/fits/hdu/table.py
 M astropy/io/fits/header.py
 M astropy/io/fits/util.py
 astropy/io/fits/card.py                            |  18 +-
 astropy/io/fits/column.py                          | 104 +++++++-
 astropy/io/fits/convenience.py                     |   9 +-
 astropy/io/fits/hdu/base.py                        |  16 +-
 .../io/fits/hdu/compressed/_tiled_compression.py   |  32 ++-
 astropy/io/fits/hdu/compressed/compressed.py       |   1 +
 astropy/io/fits/hdu/groups.py                      |   2 +-
 astropy/io/fits/hdu/hdulist.py                     |  11 +-
 astropy/io/fits/hdu/image.py                       |   9 +-
 astropy/io/fits/hdu/table.py                       |   4 +-
 astropy/io/fits/header.py                          | 291 +++++++++++++++++----
 astropy/io/fits/util.py                            |  17 +-
 12 files changed, 442 insertions(+), 72 deletions(-)
descriptor/data checks passed
```

## 原始行 233 · command_execution

命令：
```
/bin/bash -lc 'ruff check astropy/io/fits/header.py astropy/io/fits/column.py astropy/io/fits/card.py astropy/io/fits/util.py astropy/io/fits/hdu/base.py astropy/io/fits/hdu/image.py astropy/io/fits/hdu/table.py astropy/io/fits/hdu/hdulist.py astropy/io/fits/hdu/groups.py astropy/io/fits/hdu/compressed/compressed.py astropy/io/fits/hdu/compressed/_tiled_compression.py astropy/io/fits/convenience.py'
```

退出码：`127`

输出：
```
/bin/bash: line 1: ruff: command not found
```

## 原始行 237 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits -q --disable-warnings --maxfail=20'
```

退出码：`1`

输出：
```
Internet access disabled
................s.....s................................................. [  4%]
........................................................................ [  9%]
..................................................xxxx.xxxx.xxxx.xxxx.xx [ 14%]
xx.xxxx................................................................. [ 19%]
........................................................................ [ 23%]
............................................xxxx.xxxx.xxxx.xxxx.xxxx.xxx [ 28%]
x.xxxx.xxxx........F.................................................... [ 33%]
........................................................................ [ 38%]
.................ssss......ss........................ss.xxxxx........... [ 43%]
........................................................................ [ 47%]
.......s................ssss............................................ [ 52%]
........................................................................ [ 57%]
........s..s..................F.............................F.sss......F [ 62%]
FFF..................................................................... [ 67%]
........................................................................ [ 71%]
........................................................................ [ 76%]
........................................................................ [ 81%]
........................................................................ [ 86%]
........................................................................ [ 91%]
.......................sss.................ss........................... [ 95%]
..............................................................           [100%]
=================================== FAILURES ===================================
__________________ TestChecksumFunctions.test_groups_hdu_data __________________

self = <astropy.io.fits.tests.test_checksum.TestChecksumFunctions object at 0x75b40414a610>

    def test_groups_hdu_data(self):
        imdata = np.arange(100.0).reshape((10, 1, 1, 2, 5))
        pdata1 = np.arange(10) + 0.1
        pdata2 = 42
        x = fits.hdu.groups.GroupData(
            imdata, parnames=["abc", "xyz"], pardata=[pdata1, pdata2], bitpix=-32
        )
        hdu = fits.GroupsHDU(x)
>       hdu.writeto(self.temp("tmp.fits"), overwrite=True, checksum=True)

astropy/io/fits/tests/test_checksum.py:136: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:417: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1069: in writeto
    hdu._writeto(hdulist._file)
astropy/io/fits/hdu/base.py:658: in _writeto
    self._writeto_internal(fileobj, inplace, copy)
astropy/io/fits/hdu/base.py:664: in _writeto_internal
    data_offset, data_size = self._writedata(fileobj)
                             ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:595: in _writedata
    size += self._writedata_internal(fileobj)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.groups.GroupsHDU object at 0x75b40441ed90>
fileobj = <astropy.io.fits.file._File <_io.BufferedWriter name='/tmp/fits-test-rgvd8rij/tmp.fits'>>

    def _writedata_internal(self, fileobj):
        """
        Basically copy/pasted from `_ImageBaseHDU._writedata_internal()`, but
        we have to get the data's byte order a different way...
    
        TODO: Might be nice to store some indication of the data's byte order
        as an attribute or function so that we don't have to do this.
        """
        size = 0
    
        if self.data is not None:
            self.data._scale_back()
    
            # Based on the system type, determine the byteorders that
            # would need to be swapped to get to big-endian output
            if sys.byteorder == "little":
                swap_types = ("<", "=")
            else:
                swap_types = ("<",)
            # deal with unsigned integer 16, 32 and 64 data
>           if _is_pseudo_integer(self.data.dtype):
               ^^^^^^^^^^^^^^^^^^
E           NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/groups.py:476: NameError
__________________ TestFitsTime.test_time_to_fits_loc[Table] ___________________

files = None

    def update_leap_seconds(files=None):
        """If the current ERFA leap second table is out of date, try to update it.
    
        Uses `astropy.utils.iers.LeapSeconds.auto_open` to try to find an
        up-to-date table.  See that routine for the definition of "out of date".
    
        In order to make it safe to call this any time, all exceptions are turned
        into warnings,
    
        Parameters
        ----------
        files : list of path-like, optional
            List of files/URLs to attempt to open.  By default, uses defined by
            `astropy.utils.iers.LeapSeconds.auto_open`, which includes the table
            used by ERFA itself, so if that is up to date, nothing will happen.
    
        Returns
        -------
        n_update : int
            Number of items updated.
    
        """
        try:
            from astropy.utils import iers
    
>           table = iers.LeapSeconds.auto_open(files)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/time/core.py:3406: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.utils.iers.iers.LeapSeconds'>
files = ['erfa', '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/astropy_iers_data/data/Leap_Second.dat', 'https://hpiers.obspm.fr/iers/bul/bulc/Leap_Second.dat', 'https://data.iana.org/time-zones/data/leap-seconds.list']

    @classmethod
    def auto_open(cls, files=None):
        """Attempt to get an up-to-date leap-second list.
    
        The routine will try the files in sequence until it finds one
        whose expiration date is "good enough" (see below).  If none
        are good enough, it returns the one with the most recent expiration
        date, warning if that file is expired.
    
        For remote files that are cached already, the cached file is tried
        first before attempting to retrieve it again.
    
        Parameters
        ----------
        files : list of path-like, optional
            List of files/URLs to attempt to open.  By default, uses
            ``cls._auto_open_files``.
    
        Returns
        -------
        leap_seconds : `~astropy.utils.iers.LeapSeconds`
            Up to date leap-second table
    
        Notes
        -----
        Bulletin C is released about 10 days after a possible leap second is
        introduced, i.e., mid-January or mid-July.  Expiration days are thus
        generally at least 150 days after the present.  We look for a file
        that expires more than 180 - `~astropy.utils.iers.Conf.auto_max_age`
        after the present.
        """
        offset = 180 - (30 if conf.auto_max_age is None else conf.auto_max_age)
        good_enough = cls._today() + TimeDelta(offset, format="jd")
    
        if files is None:
            # Basic files to go over (entries in _auto_open_files can be
            # configuration items, which we want to be sure are up to date).
            files = [getattr(conf, f, f) for f in cls._auto_open_files]
    
        # Remove empty entries and normalize Path objects to string
        files = [os.fspath(f) for f in files if f]
    
        # Our trials start with normal files and remote ones that are
        # already in cache.  The bools here indicate that the cache
        # should be used.
        trials = [
            (f, True) for f in files if not urlparse(f).netloc or is_url_in_cache(f)
        ]
        # If we are allowed to download, we try downloading new versions
        # if none of the above worked.
        if conf.auto_download:
            trials += [(f, False) for f in files if urlparse(f).netloc]
    
        self = None
        err_list = []
        # Go through all entries, and return the first one that
        # is not expired, or the most up to date one.
        for f, allow_cache in trials:
            if not allow_cache:
                clear_download_cache(f)
    
            try:
                trial = cls.open(f, cache=True)
            except Exception as exc:
                err_list.append(exc)
                continue
    
            if self is None or trial.expires > self.expires:
                self = trial
                self.meta["data_url"] = str(f)
                if self.expires > good_enough:
                    break
    
        if self is None:
            raise ValueError(
                "none of the files could be read. The "
                f"following errors were raised:\n {err_list}"
            )
    
        if self.expires < self._today() and conf.auto_max_age is not None:
>           warn("leap-second file is expired.", IERSStaleWarning)
E           astropy.utils.iers.iers.IERSStaleWarning: leap-second file is expired.

astropy/utils/iers/iers.py:1207: IERSStaleWarning

During handling of the above exception, another exception occurred:

self = <astropy.io.fits.tests.test_fitstime.TestFitsTime object at 0x75b40389de50>
table_types = <class 'astropy.table.table.Table'>

    @pytest.mark.parametrize("table_types", (Table, QTable))
    def test_time_to_fits_loc(self, table_types):
        """
        Test all the unusual conditions for locations of ``Time``
        columns in a ``Table``.
        """
        t = table_types()
        # Check that vectorized location is stored using Green Bank convention
        t["a"] = Time(
            self.time,
            format="isot",
            scale="utc",
            location=EarthLocation([1.0, 2.0], [2.0, 3.0], [3.0, 4.0], unit="Mm"),
        )
        t["b"] = Time(self.time, format="isot", scale="tt")
    
        with pytest.warns(
            AstropyUserWarning,
            match=r'Time Column "b" has no '
            r"specified location, but global Time Position is present",
        ):
            table, hdr = time_to_fits(t)
        assert (table["OBSGEO-X"] == t["a"].location.x.to_value(unit="m")).all()
        assert (table["OBSGEO-Y"] == t["a"].location.y.to_value(unit="m")).all()
        assert (table["OBSGEO-Z"] == t["a"].location.z.to_value(unit="m")).all()
    
        with pytest.warns(
            AstropyUserWarning,
            match=r'Time Column "b" has no '
            r"specified location, but global Time Position is present",
        ):
            t.write(self.temp("time.fits"), format="fits", overwrite=True)
    
        # Check that a blank value for the "TRPOSn" keyword is not generated
        hdr = fits.getheader(self.temp("time.fits"), 1)
        assert hdr.get("TRPOS2", None) is None
    
        with pytest.warns(
            AstropyUserWarning,
            match=r"Time column reference position "
            r'"TRPOSn" is not specified. The default value for it is '
            r'"TOPOCENTER", and the observatory position has been specified.',
        ):
            tm = table_types.read(
                self.temp("time.fits"), format="fits", astropy_native=True
            )
    
        assert (tm["a"].location == t["a"].location).all()
        assert tm["b"].location == t["b"].location
    
        # Check that multiple Time columns with different locations raise an exception
        t["a"] = Time(
            self.time, format="isot", scale="utc", location=EarthLocation(1, 2, 3)
        )
        t["b"] = Time(
            self.time, format="isot", scale="tt", location=EarthLocation(2, 3, 4)
        )
    
        with pytest.raises(ValueError) as err:
            table, hdr = time_to_fits(t)
            assert "Multiple Time Columns with different geocentric" in str(err.value)
    
        # Check that Time column with no location specified will assume global location
        t["b"] = Time(self.time, format="isot", scale="tt", location=None)
    
        with pytest.warns(
            AstropyUserWarning,
            match=(
                'Time Column "b" has no specified '
                "location, but global Time Position is present"
            ),
        ) as w:
            table, hdr = time_to_fits(t)
        assert len(w) == 1
    
        # Check that multiple Time columns with same location can be written
        t["b"] = Time(
            self.time, format="isot", scale="tt", location=EarthLocation(1, 2, 3)
        )
    
        table, hdr = time_to_fits(t)
    
        # Check compatibility of Time Scales and Reference Positions
    
        for scale in BARYCENTRIC_SCALES:
>           t.replace_column("a", getattr(t["a"], scale))
                                  ^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_fitstime.py:123: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/time/core.py:1768: in __getattr__
    tm._set_scale(attr)
astropy/time/core.py:797: in _set_scale
    _check_leapsec()
astropy/time/core.py:3377: in _check_leapsec
    update_leap_seconds()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

files = None

    def update_leap_seconds(files=None):
        """If the current ERFA leap second table is out of date, try to update it.
    
        Uses `astropy.utils.iers.LeapSeconds.auto_open` to try to find an
        up-to-date table.  See that routine for the definition of "out of date".
    
        In order to make it safe to call this any time, all exceptions are turned
        into warnings,
    
        Parameters
        ----------
        files : list of path-like, optional
            List of files/URLs to attempt to open.  By default, uses defined by
            `astropy.utils.iers.LeapSeconds.auto_open`, which includes the table
            used by ERFA itself, so if that is up to date, nothing will happen.
    
        Returns
        -------
        n_update : int
            Number of items updated.
    
        """
        try:
            from astropy.utils import iers
    
            table = iers.LeapSeconds.auto_open(files)
            return erfa.leap_seconds.update(table)
    
        except Exception as exc:
>           warn(
                f"leap-second auto-update failed due to the following exception: {exc!r}",
                AstropyWarning,
            )
E           astropy.utils.exceptions.AstropyWarning: leap-second auto-update failed due to the following exception: IERSStaleWarning('leap-second file is expired.')

astropy/time/core.py:3410: AstropyWarning
_____________________________ test_fsspec_cutout2d _____________________________

    @pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
    def test_fsspec_cutout2d():
        """Does Cutout2D work with data loaded lazily using fsspec and .section?"""
        fn = get_pkg_data_filename("data/test0.fits")
        with fits.open(fn, use_fsspec=True) as hdul:
            position = (10, 20)
            size = (2, 3)
            cutout1 = Cutout2D(hdul[1].data, position, size)
>           cutout2 = Cutout2D(hdul[1].section, position, size)
                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_fsspec.py:57: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/nddata/utils.py:651: in __init__
    cutout_data, input_position_cutout = extract_array(
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

array_large = <astropy.io.fits.hdu.image.Section object at 0x75b403ccef10>
shape = (np.int64(2), np.int64(3)), position = (20, 10), mode = 'trim'
fill_value = nan, return_position = True

    def extract_array(
        array_large,
        shape,
        position,
        mode="partial",
        fill_value=np.nan,
        return_position=False,
        *,
        limit_rounding_method=np.ceil,
    ):
        """
        Extract a smaller array of the given shape and position from a
        larger array.
    
        Parameters
        ----------
        array_large : ndarray
            The array from which to extract the small array.
        shape : int or tuple thereof
            The shape of the extracted array (for 1D arrays, this can be an
            `int`).  See the ``mode`` keyword for additional details.
        position : number or tuple thereof
            The position of the small array's center with respect to the
            large array.  The pixel coordinates should be in the same order
            as the array shape.  Integer positions are at the pixel centers
            (for 1D arrays, this can be a number).
        mode : {'partial', 'trim', 'strict'}, optional
            The mode used for extracting the small array.  For the
            ``'partial'`` and ``'trim'`` modes, a partial overlap of the
            small array and the large array is sufficient.  For the
            ``'strict'`` mode, the small array has to be fully contained
            within the large array, otherwise an
            `~astropy.nddata.utils.PartialOverlapError` is raised.   In all
            modes, non-overlapping arrays will raise a
            `~astropy.nddata.utils.NoOverlapError`.  In ``'partial'`` mode,
            positions in the small array that do not overlap with the large
            array will be filled with ``fill_value``.  In ``'trim'`` mode
            only the overlapping elements are returned, thus the resulting
            small array may be smaller than the requested ``shape``.
        fill_value : number, optional
            If ``mode='partial'``, the value to fill pixels in the extracted
            small array that do not overlap with the input ``array_large``.
            ``fill_value`` will be changed to have the same ``dtype`` as the
            ``array_large`` array, with one exception. If ``array_large``
            has integer type and ``fill_value`` is ``np.nan``, then a
            `ValueError` will be raised.
        return_position : bool, optional
            If `True`, return the coordinates of ``position`` in the
            coordinate system of the returned array.
        limit_rounding_method : callable
            The rounding method when calculating the minimum and maximum pixel indices.
            This must be a callable function. Examples: `~numpy.ceil`, `~numpy.floor`,
            `~numpy.round`. Default is `~numpy.ceil`.
    
        Returns
        -------
        array_small : ndarray
            The extracted array.
        new_position : tuple
            If ``return_position`` is true, this tuple will contain the
            coordinates of the input ``position`` in the coordinate system
            of ``array_small``. Note that for partially overlapping arrays,
            ``new_position`` might actually be outside of the
            ``array_small``; ``array_small[new_position]`` might give wrong
            results if any element in ``new_position`` is negative.
    
        Examples
        --------
        We consider a large array with the shape 11x10, from which we extract
        a small array of shape 3x5:
    
        >>> import numpy as np
        >>> from astropy.nddata.utils import extract_array
        >>> large_array = np.arange(110).reshape((11, 10))
        >>> extract_array(large_array, (3, 5), (7, 7))
        array([[65, 66, 67, 68, 69],
               [75, 76, 77, 78, 79],
               [85, 86, 87, 88, 89]])
        """
        if np.isscalar(shape):
            shape = (shape,)
        if np.isscalar(position):
            position = (position,)
    
        if mode not in ["partial", "trim", "strict"]:
            raise ValueError("Valid modes are 'partial', 'trim', and 'strict'.")
    
        large_slices, small_slices = overlap_slices(
>           array_large.shape,
            ^^^^^^^^^^^^^^^^^
            shape,
            position,
            mode=mode,
            limit_rounding_method=limit_rounding_method,
        )
E       AttributeError: 'Section' object has no attribute 'shape'

astropy/nddata/utils.py:263: AttributeError
_________________ TestGroupsFunctions.test_create_groupdata[] __________________

self = <astropy.io.fits.tests.test_groups.TestGroupsFunctions object at 0x75b40375c310>
home_is_temp = None

    def test_create_groupdata(self, home_is_temp):
        """
        Basic test for creating GroupData from scratch.
        """
    
        imdata = np.arange(100.0).reshape((10, 1, 1, 2, 5))
        pdata1 = np.arange(10, dtype=np.float32) + 0.1
        pdata2 = 42.0
        x = fits.hdu.groups.GroupData(
            imdata, parnames=["abc", "xyz"], pardata=[pdata1, pdata2], bitpix=-32
        )
        assert x.parnames == ["abc", "xyz"]
        assert (x.par("abc") == pdata1).all()
        assert (x.par("xyz") == ([pdata2] * len(x))).all()
        assert (x.data == imdata).all()
    
        # Test putting the data into a GroupsHDU and round-tripping it
        ghdu = fits.GroupsHDU(data=x)
        assert ghdu.parnames == ["abc", "xyz"]
        assert ghdu.header["GCOUNT"] == 10
    
        filename = self.temp("test.fits")
>       ghdu.writeto(filename)

astropy/io/fits/tests/test_groups.py:170: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:417: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1069: in writeto
    hdu._writeto(hdulist._file)
astropy/io/fits/hdu/base.py:658: in _writeto
    self._writeto_internal(fileobj, inplace, copy)
astropy/io/fits/hdu/base.py:664: in _writeto_internal
    data_offset, data_size = self._writedata(fileobj)
                             ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:595: in _writedata
    size += self._writedata_internal(fileobj)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.groups.GroupsHDU object at 0x75b402905e10>
fileobj = <astropy.io.fits.file._File <_io.BufferedWriter name='/tmp/fits-test-64g56iuf/test.fits'>>

    def _writedata_internal(self, fileobj):
        """
        Basically copy/pasted from `_ImageBaseHDU._writedata_internal()`, but
        we have to get the data's byte order a different way...
    
        TODO: Might be nice to store some indication of the data's byte order
        as an attribute or function so that we don't have to do this.
        """
        size = 0
    
        if self.data is not None:
            self.data._scale_back()
    
            # Based on the system type, determine the byteorders that
            # would need to be swapped to get to big-endian output
            if sys.byteorder == "little":
                swap_types = ("<", "=")
            else:
                swap_types = ("<",)
            # deal with unsigned integer 16, 32 and 64 data
>           if _is_pseudo_integer(self.data.dtype):
               ^^^^^^^^^^^^^^^^^^
E           NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/groups.py:476: NameError
___________ TestGroupsFunctions.test_create_groupdata[home_is_data] ____________

self = <astropy.io.fits.tests.test_groups.TestGroupsFunctions object at 0x75b40375cb50>
home_is_temp = None

    def test_create_groupdata(self, home_is_temp):
        """
        Basic test for creating GroupData from scratch.
        """
    
        imdata = np.arange(100.0).reshape((10, 1, 1, 2, 5))
        pdata1 = np.arange(10, dtype=np.float32) + 0.1
        pdata2 = 42.0
        x = fits.hdu.groups.GroupData(
            imdata, parnames=["abc", "xyz"], pardata=[pdata1, pdata2], bitpix=-32
        )
        assert x.parnames == ["abc", "xyz"]
        assert (x.par("abc") == pdata1).all()
        assert (x.par("xyz") == ([pdata2] * len(x))).all()
        assert (x.data == imdata).all()
    
        # Test putting the data into a GroupsHDU and round-tripping it
        ghdu = fits.GroupsHDU(data=x)
        assert ghdu.parnames == ["abc", "xyz"]
        assert ghdu.header["GCOUNT"] == 10
    
        filename = self.temp("test.fits")
>       ghdu.writeto(filename)

astropy/io/fits/tests/test_groups.py:170: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:417: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1069: in writeto
    hdu._writeto(hdulist._file)
astropy/io/fits/hdu/base.py:658: in _writeto
    self._writeto_internal(fileobj, inplace, copy)
astropy/io/fits/hdu/base.py:664: in _writeto_internal
    data_offset, data_size = self._writedata(fileobj)
                             ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:595: in _writedata
    size += self._writedata_internal(fileobj)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.groups.GroupsHDU object at 0x75b402524210>
fileobj = <astropy.io.fits.file._File <_io.BufferedWriter name='/tmp/fits-test-vz0cvccs/test.fits'>>

    def _writedata_internal(self, fileobj):
        """
        Basically copy/pasted from `_ImageBaseHDU._writedata_internal()`, but
        we have to get the data's byte order a different way...
    
        TODO: Might be nice to store some indication of the data's byte order
        as an attribute or function so that we don't have to do this.
        """
        size = 0
    
        if self.data is not None:
            self.data._scale_back()
    
            # Based on the system type, determine the byteorders that
            # would need to be swapped to get to big-endian output
            if sys.byteorder == "little":
                swap_types = ("<", "=")
            else:
                swap_types = ("<",)
            # deal with unsigned integer 16, 32 and 64 data
>           if _is_pseudo_integer(self.data.dtype):
               ^^^^^^^^^^^^^^^^^^
E           NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/groups.py:476: NameError
_______ TestGroupsFunctions.test_create_groupdata[home_is_data, pathlib] _______

self = <astropy.io.fits.tests.test_groups.TestGroupsFunctions object at 0x75b40375c510>
home_is_temp = None

    def test_create_groupdata(self, home_is_temp):
        """
        Basic test for creating GroupData from scratch.
        """
    
        imdata = np.arange(100.0).reshape((10, 1, 1, 2, 5))
        pdata1 = np.arange(10, dtype=np.float32) + 0.1
        pdata2 = 42.0
        x = fits.hdu.groups.GroupData(
            imdata, parnames=["abc", "xyz"], pardata=[pdata1, pdata2], bitpix=-32
        )
        assert x.parnames == ["abc", "xyz"]
        assert (x.par("abc") == pdata1).all()
        assert (x.par("xyz") == ([pdata2] * len(x))).all()
        assert (x.data == imdata).all()
    
        # Test putting the data into a GroupsHDU and round-tripping it
        ghdu = fits.GroupsHDU(data=x)
        assert ghdu.parnames == ["abc", "xyz"]
        assert ghdu.header["GCOUNT"] == 10
    
        filename = self.temp("test.fits")
>       ghdu.writeto(filename)

astropy/io/fits/tests/test_groups.py:170: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:417: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1069: in writeto
    hdu._writeto(hdulist._file)
astropy/io/fits/hdu/base.py:658: in _writeto
    self._writeto_internal(fileobj, inplace, copy)
astropy/io/fits/hdu/base.py:664: in _writeto_internal
    data_offset, data_size = self._writedata(fileobj)
                             ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:595: in _writedata
    size += self._writedata_internal(fileobj)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.groups.GroupsHDU object at 0x75b402528390>
fileobj = <astropy.io.fits.file._File <_io.BufferedWriter name='/tmp/fits-test-exh30am0/test.fits'>>

    def _writedata_internal(self, fileobj):
        """
        Basically copy/pasted from `_ImageBaseHDU._writedata_internal()`, but
        we have to get the data's byte order a different way...
    
        TODO: Might be nice to store some indication of the data's byte order
        as an attribute or function so that we don't have to do this.
        """
        size = 0
    
        if self.data is not None:
            self.data._scale_back()
    
            # Based on the system type, determine the byteorders that
            # would need to be swapped to get to big-endian output
            if sys.byteorder == "little":
                swap_types = ("<", "=")
            else:
                swap_types = ("<",)
            # deal with unsigned integer 16, 32 and 64 data
>           if _is_pseudo_integer(self.data.dtype):
               ^^^^^^^^^^^^^^^^^^
E           NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/groups.py:476: NameError
_________________ TestGroupsFunctions.test_duplicate_parameter _________________

self = <astropy.io.fits.tests.test_groups.TestGroupsFunctions object at 0x75b40375ecd0>

    def test_duplicate_parameter(self):
        """
        Tests support for multiple parameters of the same name, and ensures
        that the data in duplicate parameters are returned as a single summed
        value.
        """
    
        imdata = np.arange(100.0).reshape((10, 1, 1, 2, 5))
        pdata1 = np.arange(10, dtype=np.float32) + 1
        pdata2 = 42.0
        x = fits.hdu.groups.GroupData(
            imdata,
            parnames=["abc", "xyz", "abc"],
            pardata=[pdata1, pdata2, pdata1],
            bitpix=-32,
        )
    
        assert x.parnames == ["abc", "xyz", "abc"]
        assert (x.par("abc") == pdata1 * 2).all()
        assert x[0].par("abc") == 2
    
        # Test setting a parameter
        x[0].setpar(0, 2)
        assert x[0].par("abc") == 3
        pytest.raises(ValueError, x[0].setpar, "abc", 2)
        x[0].setpar("abc", (2, 3))
        assert x[0].par("abc") == 5
        assert x.par("abc")[0] == 5
        assert (x.par("abc")[1:] == pdata1[1:] * 2).all()
    
        # Test round-trip
        ghdu = fits.GroupsHDU(data=x)
>       ghdu.writeto(self.temp("test.fits"))

astropy/io/fits/tests/test_groups.py:222: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:417: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1069: in writeto
    hdu._writeto(hdulist._file)
astropy/io/fits/hdu/base.py:658: in _writeto
    self._writeto_internal(fileobj, inplace, copy)
astropy/io/fits/hdu/base.py:664: in _writeto_internal
    data_offset, data_size = self._writedata(fileobj)
                             ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:595: in _writedata
    size += self._writedata_internal(fileobj)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.groups.GroupsHDU object at 0x75b40375f090>
fileobj = <astropy.io.fits.file._File <_io.BufferedWriter name='/tmp/fits-test-s12pve6v/test.fits'>>

    def _writedata_internal(self, fileobj):
        """
        Basically copy/pasted from `_ImageBaseHDU._writedata_internal()`, but
        we have to get the data's byte order a different way...
    
        TODO: Might be nice to store some indication of the data's byte order
        as an attribute or function so that we don't have to do this.
        """
        size = 0
    
        if self.data is not None:
            self.data._scale_back()
    
            # Based on the system type, determine the byteorders that
            # would need to be swapped to get to big-endian output
            if sys.byteorder == "little":
                swap_types = ("<", "=")
            else:
                swap_types = ("<",)
            # deal with unsigned integer 16, 32 and 64 data
>           if _is_pseudo_integer(self.data.dtype):
               ^^^^^^^^^^^^^^^^^^
E           NameError: name '_is_pseudo_integer' is not defined

astropy/io/fits/hdu/groups.py:476: NameError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_checksum.py::TestChecksumFunctions::test_groups_hdu_data
FAILED astropy/io/fits/tests/test_fitstime.py::TestFitsTime::test_time_to_fits_loc[Table]
FAILED astropy/io/fits/tests/test_fsspec.py::test_fsspec_cutout2d - Attribute...
FAILED astropy/io/fits/tests/test_groups.py::TestGroupsFunctions::test_create_groupdata[]
FAILED astropy/io/fits/tests/test_groups.py::TestGroupsFunctions::test_create_groupdata[home_is_data]
FAILED astropy/io/fits/tests/test_groups.py::TestGroupsFunctions::test_create_groupdata[home_is_data, pathlib]
FAILED astropy/io/fits/tests/test_groups.py::TestGroupsFunctions::test_duplicate_parameter
7 failed, 1409 passed, 29 skipped, 61 xfailed in 15.92s
```

## 原始行 240 · file_change

```
{
  "id": "item_161",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/groups.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 243 · command_execution

命令：
```
/bin/bash -lc "grep -n \"class Section\\|def shape\\|def dtype\" astropy/io/fits/hdu/image.py | tail -30
nl -ba astropy/io/fits/hdu/image.py | sed -n '940,1065p'"
```

退出码：`0`

输出：
```
216:    def shape(self):
957:class Section:
981:    def dtype(self):
   940	            cs = self._compute_checksum(d.ravel().view(np.uint8))
   941	
   942	            # If the data was byteswapped in this method then return it to
   943	            # its original little-endian order.
   944	            if byteswapped and not _is_pseudo_integer(self.data.dtype):
   945	                d.byteswap(True)
   946	                d = d.view(d.dtype.newbyteorder("<"))
   947	
   948	            return cs
   949	        else:
   950	            # This is the case where the data has not been read from the file
   951	            # yet.  We can handle that in a generic manner so we do it in the
   952	            # base class.  The other possibility is that there is no data at
   953	            # all.  This can also be handled in a generic manner.
   954	            return super()._calculate_datasum()
   955	
   956	
   957	class Section:
   958	    """
   959	    Class enabling subsets of ImageHDU data to be loaded lazily via slicing.
   960	
   961	    Slices of this object load the corresponding section of an image array from
   962	    the underlying FITS file, and applies any BSCALE/BZERO factors.
   963	
   964	    Section slices cannot be assigned to, and modifications to a section are
   965	    not saved back to the underlying file.
   966	
   967	    See the :ref:`astropy:data-sections` section of the Astropy documentation
   968	    for more details.
   969	    """
   970	
   971	    def __init__(self, hdu):
   972	        self.hdu = hdu
   973	
   974	
   975	
   976	
   977	
   978	
   979	
   980	    @property
   981	    def dtype(self):
   982	        # Implementing `.dtype` enables `astropy.nddata.Cutout2D` to accept
   983	        # `ImageHDU.section` in place of `.data`.
   984	        if not self.hdu._do_not_scale_image_data and (
   985	            self.hdu._orig_bscale != 1 or self.hdu._orig_bzero != 0
   986	        ):
   987	            return self.hdu._dtype_for_bitpix()
   988	        else:
   989	            return np.dtype(BITPIX2DTYPE[self.hdu._bitpix])
   990	
   991	    def __getitem__(self, key):
   992	        """Returns a slice of HDU data specified by `key`.
   993	
   994	        If the image HDU is backed by a file handle, this method will only read
   995	        the chunks of the file needed to extract `key`, which is useful in
   996	        situations where the file is located on a slow or remote file system
   997	        (e.g., cloud storage).
   998	        """
   999	        if not isinstance(key, tuple):
  1000	            key = (key,)
  1001	        naxis = len(self.hdu.shape)
  1002	        return_scalar = (
  1003	            all(isinstance(k, (int, np.integer)) for k in key) and len(key) == naxis
  1004	        )
  1005	        if not any(k is Ellipsis for k in key):
  1006	            # We can always add a ... at the end, after making note of whether
  1007	            # to return a scalar.
  1008	            key += (Ellipsis,)
  1009	        ellipsis_count = len([k for k in key if k is Ellipsis])
  1010	        if len(key) - ellipsis_count > naxis or ellipsis_count > 1:
  1011	            raise IndexError("too many indices for array")
  1012	        # Insert extra dimensions as needed.
  1013	        idx = next(i for i, k in enumerate(key + (Ellipsis,)) if k is Ellipsis)
  1014	        key = key[:idx] + (slice(None),) * (naxis - len(key) + 1) + key[idx + 1 :]
  1015	        return_0dim = (
  1016	            all(isinstance(k, (int, np.integer)) for k in key) and len(key) == naxis
  1017	        )
  1018	
  1019	        dims = []
  1020	        offset = 0
  1021	        # Find all leading axes for which a single point is used.
  1022	        for idx in range(naxis):
  1023	            axis = self.hdu.shape[idx]
  1024	            index = _IndexInfo(key[idx], axis)
  1025	            offset = offset * axis + index.offset
  1026	            if not _is_int(key[idx]):
  1027	                dims.append(index.npts)
  1028	                break
  1029	
  1030	        is_contiguous = index.contiguous
  1031	        for jdx in range(idx + 1, naxis):
  1032	            axis = self.hdu.shape[jdx]
  1033	            index = _IndexInfo(key[jdx], axis)
  1034	            dims.append(index.npts)
  1035	            if index.npts == axis and index.contiguous:
  1036	                # The offset needs to multiply the length of all remaining axes
  1037	                offset *= axis
  1038	            else:
  1039	                is_contiguous = False
  1040	
  1041	        if is_contiguous:
  1042	            dims = tuple(dims) or (1,)
  1043	            bitpix = self.hdu._orig_bitpix
  1044	            offset = self.hdu._data_offset + offset * abs(bitpix) // 8
  1045	            # Note: the actual file read operations are delegated to
  1046	            # `util._array_from_file` via `ImageHDU._get_scaled_image_data`
  1047	            data = self.hdu._get_scaled_image_data(offset, dims)
  1048	        else:
  1049	            data = self._getdata(key)
  1050	
  1051	        if return_scalar:
  1052	            data = data.item()
  1053	        elif return_0dim:
  1054	            data = data.squeeze()
  1055	        return data
  1056	
  1057	    def _getdata(self, keys):
  1058	        for idx, (key, axis) in enumerate(zip(keys, self.hdu.shape)):
  1059	            if isinstance(key, slice):
  1060	                ks = range(*key.indices(axis))
  1061	                break
  1062	
  1063	            if np.iterable(key):
  1064	                # Handle both integer and boolean arrays.
  1065	                ks = np.arange(axis, dtype=int)[key]
```

## 原始行 246 · file_change

```
{
  "id": "item_165",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/image.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 248 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_groups.py astropy/io/fits/tests/test_checksum.py::TestChecksumFunctions::test_groups_hdu_data astropy/io/fits/tests/test_fsspec.py::test_fsspec_cutout2d -q --disable-warnings'
```

退出码：`0`

输出：
```
Internet access disabled
..............                                                           [100%]
14 passed in 1.21s
```

## 原始行 251 · command_execution

命令：
```
/bin/bash -lc "python -m pytest astropy/io/fits -q --disable-warnings --maxfail=1 -k 'not test_time_to_fits_loc'"
```

退出码：`1`

输出：
```
Internet access disabled
................s.....s................................................. [  4%]
........................................................................ [  9%]
..................................................xxxx.xxxx.xxxx.xxxx.xx [ 14%]
xx.xxxx................................................................. [ 19%]
........................................................................ [ 24%]
............................................xxxx.xxxx.xxxx.xxxx.xxxx.xxx [ 28%]
x.xxxx.xxxx............................................................. [ 33%]
........................................................................ [ 38%]
.................ssss......ss........................ss.xxxxx........... [ 43%]
........................................................................ [ 48%]
.......s................ssss............................................ [ 52%]
........................................................................ [ 57%]
........s..s....................F
=================================== FAILURES ===================================
__ TestFitsTime.test_time_to_fits_serialize_method[jd1_jd2-mask1-MaskedArray] __

files = None

    def update_leap_seconds(files=None):
        """If the current ERFA leap second table is out of date, try to update it.
    
        Uses `astropy.utils.iers.LeapSeconds.auto_open` to try to find an
        up-to-date table.  See that routine for the definition of "out of date".
    
        In order to make it safe to call this any time, all exceptions are turned
        into warnings,
    
        Parameters
        ----------
        files : list of path-like, optional
            List of files/URLs to attempt to open.  By default, uses defined by
            `astropy.utils.iers.LeapSeconds.auto_open`, which includes the table
            used by ERFA itself, so if that is up to date, nothing will happen.
    
        Returns
        -------
        n_update : int
            Number of items updated.
    
        """
        try:
            from astropy.utils import iers
    
>           table = iers.LeapSeconds.auto_open(files)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/time/core.py:3406: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.utils.iers.iers.LeapSeconds'>
files = ['erfa', '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/astropy_iers_data/data/Leap_Second.dat', 'https://hpiers.obspm.fr/iers/bul/bulc/Leap_Second.dat', 'https://data.iana.org/time-zones/data/leap-seconds.list']

    @classmethod
    def auto_open(cls, files=None):
        """Attempt to get an up-to-date leap-second list.
    
        The routine will try the files in sequence until it finds one
        whose expiration date is "good enough" (see below).  If none
        are good enough, it returns the one with the most recent expiration
        date, warning if that file is expired.
    
        For remote files that are cached already, the cached file is tried
        first before attempting to retrieve it again.
    
        Parameters
        ----------
        files : list of path-like, optional
            List of files/URLs to attempt to open.  By default, uses
            ``cls._auto_open_files``.
    
        Returns
        -------
        leap_seconds : `~astropy.utils.iers.LeapSeconds`
            Up to date leap-second table
    
        Notes
        -----
        Bulletin C is released about 10 days after a possible leap second is
        introduced, i.e., mid-January or mid-July.  Expiration days are thus
        generally at least 150 days after the present.  We look for a file
        that expires more than 180 - `~astropy.utils.iers.Conf.auto_max_age`
        after the present.
        """
        offset = 180 - (30 if conf.auto_max_age is None else conf.auto_max_age)
        good_enough = cls._today() + TimeDelta(offset, format="jd")
    
        if files is None:
            # Basic files to go over (entries in _auto_open_files can be
            # configuration items, which we want to be sure are up to date).
            files = [getattr(conf, f, f) for f in cls._auto_open_files]
    
        # Remove empty entries and normalize Path objects to string
        files = [os.fspath(f) for f in files if f]
    
        # Our trials start with normal files and remote ones that are
        # already in cache.  The bools here indicate that the cache
        # should be used.
        trials = [
            (f, True) for f in files if not urlparse(f).netloc or is_url_in_cache(f)
        ]
        # If we are allowed to download, we try downloading new versions
        # if none of the above worked.
        if conf.auto_download:
            trials += [(f, False) for f in files if urlparse(f).netloc]
    
        self = None
        err_list = []
        # Go through all entries, and return the first one that
        # is not expired, or the most up to date one.
        for f, allow_cache in trials:
            if not allow_cache:
                clear_download_cache(f)
    
            try:
                trial = cls.open(f, cache=True)
            except Exception as exc:
                err_list.append(exc)
                continue
    
            if self is None or trial.expires > self.expires:
                self = trial
                self.meta["data_url"] = str(f)
                if self.expires > good_enough:
                    break
    
        if self is None:
            raise ValueError(
                "none of the files could be read. The "
                f"following errors were raised:\n {err_list}"
            )
    
        if self.expires < self._today() and conf.auto_max_age is not None:
>           warn("leap-second file is expired.", IERSStaleWarning)
E           astropy.utils.iers.iers.IERSStaleWarning: leap-second file is expired.

astropy/utils/iers/iers.py:1207: IERSStaleWarning

During handling of the above exception, another exception occurred:

self = <astropy.time.formats.TimeCxcSec object at 0x72665bc995d0>
parent = <Time object: scale='utc' format='cxcsec' value=63115264.184>
kwargs = {}

    def to_value(self, parent=None, **kwargs):
        # Make sure that scale is the same as epoch scale so we can just
        # subtract the epoch and convert
        if self.scale != self.epoch_scale:
            if parent is None:
                raise ValueError("cannot compute value without parent Time object")
            try:
>               tm = getattr(parent, self.epoch_scale)
                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/time/formats.py:817: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/time/core.py:1768: in __getattr__
    tm._set_scale(attr)
astropy/time/core.py:797: in _set_scale
    _check_leapsec()
astropy/time/core.py:3377: in _check_leapsec
    update_leap_seconds()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

files = None

    def update_leap_seconds(files=None):
        """If the current ERFA leap second table is out of date, try to update it.
    
        Uses `astropy.utils.iers.LeapSeconds.auto_open` to try to find an
        up-to-date table.  See that routine for the definition of "out of date".
    
        In order to make it safe to call this any time, all exceptions are turned
        into warnings,
    
        Parameters
        ----------
        files : list of path-like, optional
            List of files/URLs to attempt to open.  By default, uses defined by
            `astropy.utils.iers.LeapSeconds.auto_open`, which includes the table
            used by ERFA itself, so if that is up to date, nothing will happen.
    
        Returns
        -------
        n_update : int
            Number of items updated.
    
        """
        try:
            from astropy.utils import iers
    
            table = iers.LeapSeconds.auto_open(files)
            return erfa.leap_seconds.update(table)
    
        except Exception as exc:
>           warn(
                f"leap-second auto-update failed due to the following exception: {exc!r}",
                AstropyWarning,
            )
E           astropy.utils.exceptions.AstropyWarning: leap-second auto-update failed due to the following exception: IERSStaleWarning('leap-second file is expired.')

astropy/time/core.py:3410: AstropyWarning

The above exception was the direct cause of the following exception:

self = <astropy.io.fits.tests.test_fitstime.TestFitsTime object at 0x72665d0f7150>
serialize_method = 'jd1_jd2', mask = [True, False]
masked_cls = <class 'numpy.ma.MaskedArray'>

    @pytest.mark.parametrize("masked_cls", (np.ma.MaskedArray, Masked))
    @pytest.mark.parametrize("mask", (False, [True, False]))
    @pytest.mark.parametrize("serialize_method", ("jd1_jd2", "formatted_value"))
    def test_time_to_fits_serialize_method(self, serialize_method, mask, masked_cls):
        """
        Test the data returned by ``time_to_fits`` for masked values.
        """
        a = Time(masked_cls(self.time, mask=mask))
>       b = Time(
            masked_cls([[1, 2], [3, 4]], mask=np.broadcast_to(mask, (2, 2))),
            format="cxcsec",
        )

astropy/io/fits/tests/test_fitstime.py:180: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/time/core.py:1984: in __init__
    self._init_from_vals(
astropy/time/core.py:559: in _init_from_vals
    self._time = self._get_time_fmt(
astropy/time/core.py:634: in _get_time_fmt
    val, val2 = cls._fill_masked_values(oval, oval2, mask, in_subfmt)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/time/formats.py:502: in _fill_masked_values
    fill_value = cls.fill_value(in_subfmt)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/time/formats.py:259: in fill_value
    return tm.to_value(format=cls.name, subfmt=subfmt)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/time/core.py:1054: in to_value
    value = tm._time.to_value(parent=tm, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.time.formats.TimeCxcSec object at 0x72665bc995d0>
parent = <Time object: scale='utc' format='cxcsec' value=63115264.184>
kwargs = {}

    def to_value(self, parent=None, **kwargs):
        # Make sure that scale is the same as epoch scale so we can just
        # subtract the epoch and convert
        if self.scale != self.epoch_scale:
            if parent is None:
                raise ValueError("cannot compute value without parent Time object")
            try:
                tm = getattr(parent, self.epoch_scale)
            except Exception as err:
>               raise ScaleValueError(
                    f"Cannot convert from '{self.name}' epoch scale "
                    f"'{self.epoch_scale}' to specified scale '{self.scale}', "
                    f"got error:\n{err}"
                ) from err
E               astropy.time.core.ScaleValueError: Cannot convert from 'cxcsec' epoch scale 'tt' to specified scale 'utc', got error:
E               leap-second auto-update failed due to the following exception: IERSStaleWarning('leap-second file is expired.')

astropy/time/formats.py:819: ScaleValueError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_fitstime.py::TestFitsTime::test_time_to_fits_serialize_method[jd1_jd2-mask1-MaskedArray]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 818 passed, 21 skipped, 2 deselected, 61 xfailed in 10.26s
```

## 原始行 254 · command_execution

命令：
```
/bin/bash -lc 'python -m black --version 2>/dev/null || true
python -m isort --version-number 2>/dev/null || true
git diff --check'
```

退出码：`0`

输出：
```

```

## 原始行 259 · file_change

```
{
  "id": "item_174",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 262 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.fits.column import _convert_fits2record
from astropy.io.fits.verify import VerifyError
for value in ('E','10A','A3','2J','8X','1PJ(12)','1QJ(12)','F'):
 out=_convert_fits2record(value); print(value, repr(out), type(out).__name__)
try: _convert_fits2record('Z')
except Exception as e: print(type(e).__name__, e)
PY
python -m pytest astropy/io/fits/tests/test_header.py astropy/io/fits/tests/test_table.py astropy/io/fits/hdu/compressed/tests/test_tiled_compression.py::test_invalid_tile -q --disable-warnings --maxfail=5"
```

退出码：`0`

输出：
```
E 'f4' str
10A 'S10' str
A3 'S3' str
2J '2i4' str
8X '(1,)u1' _FormatX
1PJ(12) '2i4' _FormatP
1QJ(12) '2i8' _FormatQ
F 'f8' str
ValueError Illegal format `Z`.
Internet access disabled
........................................................................ [ 18%]
........................................................................ [ 37%]
........................................................................ [ 56%]
........................................................................ [ 75%]
..................................sss.................ss................ [ 94%]
....................                                                     [100%]
375 passed, 5 skipped in 1.46s
```

## 原始行 265 · command_execution

命令：
```
/bin/bash -lc "git diff --check
git status --short
git diff -- astropy/io/fits/header.py | sed -n '1,520p'"
```

退出码：`0`

输出：
```
 M astropy/io/fits/card.py
 M astropy/io/fits/column.py
 M astropy/io/fits/convenience.py
 M astropy/io/fits/hdu/base.py
 M astropy/io/fits/hdu/compressed/_tiled_compression.py
 M astropy/io/fits/hdu/compressed/compressed.py
 M astropy/io/fits/hdu/groups.py
 M astropy/io/fits/hdu/hdulist.py
 M astropy/io/fits/hdu/image.py
 M astropy/io/fits/hdu/table.py
 M astropy/io/fits/header.py
 M astropy/io/fits/util.py
diff --git a/astropy/io/fits/header.py b/astropy/io/fits/header.py
index 8ac5953..5496fc7 100644
--- a/astropy/io/fits/header.py
+++ b/astropy/io/fits/header.py
@@ -135,19 +135,13 @@ class Header:
         for card in self._cards:
             yield card.keyword
 
-
-
-
-
-
-
-
-
-
-
-
-
-
+    def __contains__(self, keyword):
+        """Return whether *keyword* identifies a card in this header."""
+        try:
+            self._cardindex(keyword)
+        except (KeyError, IndexError, TypeError, ValueError):
+            return False
+        return True
     def __getitem__(self, key):
         if isinstance(key, slice):
             return self.__class__([copy.copy(c) for c in self._cards[key]])
@@ -312,23 +306,10 @@ class Header:
         """
         return _CardAccessor(self)
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+    @property
+    def comments(self):
+        """A mapping-like view of the comments on this header's cards."""
+        return _HeaderComments(self)
     @property
     def _modified(self):
         """
@@ -864,31 +845,12 @@ class Header:
             d.append((key,) + value)
         return d
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+    def get(self, key, default=None):
+        """Return the value for *key*, or *default* if it is absent."""
+        try:
+            return self[key]
+        except (KeyError, IndexError):
+            return default
     def set(self, keyword, value=None, comment=None, before=None, after=None):
         """
         Set the value and/or comment and/or position of a specified keyword.
@@ -1342,6 +1304,73 @@ class Header:
                 return idx
         raise ValueError(f"The keyword {keyword!r} is not in the  header.")
 
+    def insert(self, key, card, useblanks=True, after=False):
+        """Insert a card before (or, with ``after=True``, after) *key*."""
+        if isinstance(card, str):
+            card = Card(card)
+        elif isinstance(card, tuple):
+            card = Card(*card)
+        elif not isinstance(card, Card):
+            raise ValueError(
+                "The value inserted into a Header must be either a keyword or "
+                f"(keyword, value, [comment]) tuple; got: {card!r}"
+            )
+
+        if isinstance(key, numbers.Integral):
+            idx = int(key)
+            if idx < 0:
+                idx = max(0, len(self._cards) + idx)
+            else:
+                idx = min(idx, len(self._cards))
+        else:
+            idx = self._cardindex(key)
+
+        if after:
+            idx = min(idx + 1, len(self._cards))
+
+        if card.keyword in _commentary_keywords:
+            cards = self._splitcommentary(card.keyword, card.value)
+        else:
+            cards = [card]
+            if card.keyword in self:
+                warnings.warn(
+                    f"A {card.keyword!r} keyword already exists in this header.  "
+                    "Inserting duplicate keyword.",
+                    AstropyUserWarning,
+                )
+
+        for offset, new_card in enumerate(cards):
+            insert_at = idx + offset
+            self._updateindices(insert_at)
+            self._cards.insert(insert_at, new_card)
+
+            keyword = Card.normalize_keyword(new_card.keyword)
+            self._keyword_indices[keyword].append(insert_at)
+            self._keyword_indices[keyword].sort()
+            if new_card.field_specifier is not None:
+                self._rvkc_indices[new_card.rawkeyword].append(insert_at)
+                self._rvkc_indices[new_card.rawkeyword].sort()
+
+        if useblanks:
+            nblocks = sum(len(str(new_card)) // Card.length for new_card in cards)
+            self._useblanks(nblocks)
+        self._modified = True
+
+    def remove(self, keyword, ignore_missing=False, remove_all=False):
+        """Remove the first, or all, occurrences of *keyword*."""
+        removed = False
+        while True:
+            try:
+                idx = self._cardindex(keyword)
+            except (KeyError, IndexError):
+                if ignore_missing or (remove_all and removed):
+                    return
+                raise
+            del self[idx]
+            removed = True
+            if not remove_all:
+                return
+
 
 
 
@@ -1631,6 +1660,81 @@ class Header:
         size = self.data_size
         return size + _pad_length(size)
 
+    def _relativeinsert(self, card, before=None, after=None, replace=False):
+        """Insert *card* relative to another card, optionally moving it."""
+        reference = before if before is not None else after
+        if isinstance(reference, numbers.Integral):
+            idx = int(reference)
+            if idx < 0:
+                idx = max(0, len(self._cards) + idx)
+            else:
+                idx = min(idx, len(self._cards))
+        else:
+            idx = self._cardindex(reference)
+        if before is None:
+            idx = min(idx + 1, len(self._cards))
+
+        if replace:
+            try:
+                old_idx = next(
+                    i for i, old_card in enumerate(self._cards) if old_card is card
+                )
+            except StopIteration:
+                old_idx = self._cardindex(card.keyword)
+
+            if old_idx < idx:
+                idx -= 1
+            if old_idx == idx:
+                return
+            del self[old_idx]
+
+        self.insert(idx, card)
+
+    def _cardindex(self, key):
+        """Return the physical card index represented by *key*."""
+        if isinstance(key, slice):
+            return key
+
+        if isinstance(key, numbers.Integral):
+            idx = int(key)
+            if idx < 0:
+                idx += len(self._cards)
+            if idx < 0 or idx >= len(self._cards):
+                raise IndexError("Header index out of range.")
+            return idx
+
+        repeat = 0
+        if isinstance(key, tuple):
+            if (
+                len(key) != 2
+                or not isinstance(key[0], str)
+                or not isinstance(key[1], numbers.Integral)
+            ):
+                raise ValueError(
+                    "Header indices must be either a string, a 2-tuple of "
+                    "(keyword, index), or an integer."
+                )
+            key, repeat = key[0], int(key[1])
+        elif not isinstance(key, str):
+            raise ValueError(
+                "Header indices must be either a string, a 2-tuple of "
+                "(keyword, index), or an integer."
+            )
+
+        keyword = Card.normalize_keyword(key)
+        indices = self._keyword_indices
+        if keyword not in indices:
+            indices = self._rvkc_indices
+        if keyword not in indices:
+            raise KeyError(f"Keyword {keyword!r} not found.")
+
+        try:
+            return indices[keyword][repeat]
+        except IndexError:
+            raise IndexError(
+                f"There are only {len(indices[keyword])} '{keyword}' cards in the header."
+            ) from None
+
 
 
 
@@ -1743,6 +1847,55 @@ class Header:
         repeat = self._keyword_indices[keyword].index(idx)
         return keyword, repeat
 
+    def _set_slice(self, key, value, target):
+        """Implement assignment through slices and wildcard selections."""
+        if isinstance(key, slice):
+            indices = range(*key.indices(len(target)))
+        elif self._haswildcard(key):
+            indices = self._wildcardmatch(key)
+        else:
+            return False
+
+        if isinstance(value, str) or not np.iterable(value):
+            value = itertools.repeat(value, len(indices))
+        for idx, val in zip(indices, value):
+            target[idx] = val
+        return True
+
+    def _update(self, card):
+        """Update the first matching card, or append a new card."""
+        comment_supplied = True
+        if isinstance(card, tuple):
+            if len(card) != 3:
+                raise ValueError("Header._update expects a Card or a 3-tuple.")
+            keyword, value, comment = card
+            comment_supplied = comment is not None
+            card = Card(keyword, value, comment)
+        elif not isinstance(card, Card):
+            raise ValueError("Header._update expects a Card or a 3-tuple.")
+
+        keyword = card.keyword
+        if keyword in _commentary_keywords:
+            for commentary_card in self._splitcommentary(keyword, card.value):
+                if keyword == "":
+                    self.append(commentary_card, end=True)
+                else:
+                    self.append(commentary_card)
+            return
+
+        try:
+            idx = self._cardindex(keyword)
+        except KeyError:
+            self.append(card)
+            return
+
+        old_card = self._cards[idx]
+        old_card.value = card.value
+        if comment_supplied:
+            old_card.comment = card.comment
+        if old_card._modified:
+            self._modified = True
+
 
 
 
@@ -1826,6 +1979,12 @@ class Header:
                 return idx - 1
         return 0
 
+    def _haswildcard(self, keyword):
+        """Return whether a string contains a supported wildcard."""
+        return isinstance(keyword, str) and (
+            "*" in keyword or "?" in keyword or keyword.endswith("...")
+        )
+
 
 
 
@@ -1852,6 +2011,11 @@ class Header:
         pattern = pattern.replace("...", r"\S*") + "$"
         match_pattern = re.compile(pattern, re.IGNORECASE).match
         return [i for i, card in enumerate(self._cards) if match_pattern(card.keyword)]
+
+    def _useblanks(self, blank_count):
+        """Consume up to *blank_count* blank cards from the header tail."""
+        for _ in range(min(blank_count, self._countblanks())):
+            del self[-1]
 
 
 
@@ -1923,6 +2087,21 @@ class _DelayedHeader:
     was stored in HDU._header_str when parsing the file.
     """
 
+    def __get__(self, obj, owner=None):
+        try:
+            return obj.__dict__["_header"]
+        except KeyError:
+            pass
+
+        header_str = obj._header_str
+        if header_str is None:
+            raise AttributeError("Header has not been initialized.")
+
+        header = Header.fromstring(header_str)
+        obj.__dict__["_header"] = header
+        obj._header_str = None
+        return header
+
 
 
 
@@ -2274,4 +2453,4 @@ def _hdr_data_size(header):
         gcount = header.get("GCOUNT", 1)
         pcount = header.get("PCOUNT", 0)
         size = abs(bitpix) * gcount * (pcount + size) // 8
-    return size
\ No newline at end of file
+    return size
```

## 原始行 268 · command_execution

命令：
```
/bin/bash -lc "sed -n '128,160p' astropy/io/fits/header.py
sed -n '295,325p' astropy/io/fits/header.py
sed -n '836,865p' astropy/io/fits/header.py"
```

退出码：`0`

输出：
```

        self._modified = False

    def __len__(self):
        return len(self._cards)

    def __iter__(self):
        for card in self._cards:
            yield card.keyword

    def __contains__(self, keyword):
        """Return whether *keyword* identifies a card in this header."""
        try:
            self._cardindex(keyword)
        except (KeyError, IndexError, TypeError, ValueError):
            return False
        return True
    def __getitem__(self, key):
        if isinstance(key, slice):
            return self.__class__([copy.copy(c) for c in self._cards[key]])
        elif self._haswildcard(key):
            return self.__class__(
                [copy.copy(self._cards[idx]) for idx in self._wildcardmatch(key)]
            )
        elif isinstance(key, str):
            key = key.strip()
            if key.upper() in _commentary_keywords:
                key = key.upper()
                # Special case for commentary cards
                return _HeaderCommentaryCards(self, key)

        if isinstance(key, tuple):
            keyword = key[0]
        self.extend(other)
        return self

    def _ipython_key_completions_(self):
        return self.__iter__()

    @property
    def cards(self):
        """
        The underlying physical cards that make up this Header; it can be
        looked at, but it should not be modified directly.
        """
        return _CardAccessor(self)

    @property
    def comments(self):
        """A mapping-like view of the comments on this header's cards."""
        return _HeaderComments(self)
    @property
    def _modified(self):
        """
        Whether or not the header has been modified; this is a property so that
        it can also check each card for modifications--cards may have been
        modified directly without the header containing it otherwise knowing.
        """
        modified_cards = any(c._modified for c in self._cards)
        if modified_cards:
            # If any cards were modified then by definition the header was
            # modified
            self.__dict__["_modified"] = True

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        d = cls()
        if not isinstance(value, tuple):
            value = (value,)
        for key in iterable:
            d.append((key,) + value)
        return d

    def get(self, key, default=None):
        """Return the value for *key*, or *default* if it is absent."""
        try:
            return self[key]
        except (KeyError, IndexError):
            return default
    def set(self, keyword, value=None, comment=None, before=None, after=None):
        """
        Set the value and/or comment and/or position of a specified keyword.

        If the keyword does not already exist in the header, a new keyword is
        created in the specified position, or appended to the end of the header
        if no position is specified.

        This method is similar to :meth:`Header.update` prior to Astropy v0.1.

        .. note::
            It should be noted that ``header.set(keyword, value)`` and
```

## 原始行 271 · file_change

```
{
  "id": "item_182",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 274 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from pathlib import Path
for filename in ['astropy/io/fits/header.py','astropy/io/fits/column.py','astropy/io/fits/card.py','astropy/io/fits/util.py','astropy/io/fits/hdu/base.py','astropy/io/fits/hdu/image.py']:
 lines=Path(filename).read_text().splitlines()
 for i,line in enumerate(lines[:-1]):
  if line.startswith('    def ') or line.startswith('def ') or line.startswith('    @property'):
   pass
 print(filename)
PY
git diff --check
python -m compileall -q astropy/io/fits"
```

退出码：`0`

输出：
```
astropy/io/fits/header.py
astropy/io/fits/column.py
astropy/io/fits/card.py
astropy/io/fits/util.py
astropy/io/fits/hdu/base.py
astropy/io/fits/hdu/image.py
```

## 原始行 277 · command_execution

命令：
```
/bin/bash -lc "git diff -- astropy/io/fits/column.py astropy/io/fits/hdu/base.py astropy/io/fits/card.py astropy/io/fits/util.py astropy/io/fits/hdu/compressed/_tiled_compression.py | sed -n '1,700p'"
```

退出码：`0`

输出：
```
diff --git a/astropy/io/fits/card.py b/astropy/io/fits/card.py
index 6d62e97..739bd5c 100644
--- a/astropy/io/fits/card.py
+++ b/astropy/io/fits/card.py
@@ -8,7 +8,7 @@ import numpy as np
 from astropy.utils.exceptions import AstropyUserWarning
 
 from . import conf
-from .util import _str_to_num, _words_group, translate
+from .util import _is_int, _str_to_num, _words_group, translate
 from .verify import VerifyError, VerifyWarning, _ErrList, _Verify
 
 __all__ = ["Card", "Undefined"]
@@ -1297,6 +1297,20 @@ def _format_value(value):
         return ""
 
 
+def _format_float(value):
+    """Format a floating-point value for a FITS card value field."""
+    value_str = str(value).upper()
+
+    if "E" in value_str:
+        if len(value_str) > 20:
+            exponent = value_str[value_str.index("E") :]
+            value_str = value_str[: 20 - len(exponent)] + exponent
+    elif "." not in value_str:
+        value_str += ".0"
+
+    return value_str
+
+
 
 
 
@@ -1329,4 +1343,4 @@ def _pad(input):
     # minimum length is 80
     else:
         strlen = _len % Card.length
-        return input + " " * (Card.length - strlen)
\ No newline at end of file
+        return input + " " * (Card.length - strlen)
diff --git a/astropy/io/fits/column.py b/astropy/io/fits/column.py
index 4f6ddfa..81e4f25 100644
--- a/astropy/io/fits/column.py
+++ b/astropy/io/fits/column.py
@@ -20,7 +20,7 @@ from astropy.utils import lazyproperty
 from astropy.utils.exceptions import AstropyUserWarning
 
 from .card import CARD_LENGTH, Card
-from .util import NotifierMixin, _convert_array, cmp, encode_ascii
+from .util import NotifierMixin, _convert_array, _is_int, cmp, encode_ascii
 from .verify import VerifyError, VerifyWarning
 
 __all__ = ["ColDefs", "Column", "Delayed"]
@@ -262,7 +262,7 @@ class _BaseColumnFormat(str):
             if not isinstance(other, self.__class__):
                 try:
                     other = self.__class__(other)
-                except ValueError:
+                except (ValueError, VerifyError):
                     return False
         else:
             return False
@@ -2284,6 +2284,71 @@ def _makep(array, descr_output, format, nrows=None):
     return data_output
 
 
+def _parse_tformat(tform):
+    """Parse a binary-table ``TFORMn`` value."""
+    if not isinstance(tform, str):
+        raise VerifyError(f"Format {tform!r} is not recognized.")
+
+    match = TFORMAT_RE.match(tform)
+    if match is None or match.end() != len(tform):
+        raise VerifyError(f"Format {tform!r} is not recognized.")
+
+    repeat = match.group("repeat")
+    return (
+        int(repeat) if repeat else 1,
+        match.group("format").upper(),
+        match.group("option"),
+    )
+
+
+def _parse_ascii_tformat(tform, strict=False):
+    """Parse an ASCII-table ``TFORMn`` value."""
+    if not isinstance(tform, str):
+        raise VerifyError(f"Format {tform!r} is not recognized.")
+
+    value = tform
+    match = TFORMAT_ASCII_RE.match(value)
+    if match is None or match.end() != len(value):
+        raise VerifyError(f"Format {tform!r} is not recognized.")
+
+    format_code = (match.group("format") or match.group("formatf")).upper()
+    width_text = match.group("width") or match.group("widthf")
+    precision_text = match.group("precision")
+
+    if strict and (
+        width_text is None
+        or (format_code in ("E", "F", "D") and precision_text is None)
+    ):
+        raise VerifyError(f"Format {tform!r} is not recognized.")
+
+    default_width, default_precision = ASCII_DEFAULT_WIDTHS[format_code]
+    if width_text is None:
+        width = default_width
+        precision = default_precision
+    else:
+        width = int(width_text)
+        precision = (
+            int(precision_text)
+            if precision_text is not None
+            else default_precision
+        )
+
+    if width <= 0:
+        raise VerifyError(
+            f"Column width must be a positive integer (got {width!r})."
+        )
+    if (
+        format_code in ("E", "F", "D")
+        and precision_text is not None
+        and precision >= width
+    ):
+        raise VerifyError(
+            f"Decimal precision ({precision}) must be less than the column width ({width})."
+        )
+
+    return format_code, width, precision
+
+
 
 
 
@@ -2427,6 +2492,39 @@ def _cmp_recformats(f1, f2):
         return cmp(FORMATORDER.index(f1), FORMATORDER.index(f2))
 
 
+def _convert_fits2record(format):
+    """Convert a binary-table FITS format to a NumPy record format."""
+    if isinstance(format, str):
+        legacy = re.fullmatch(r"(?P<repeat>[0-9]*)F", format, re.IGNORECASE)
+    else:
+        legacy = None
+    if legacy is not None:
+        repeat = int(legacy.group("repeat") or 1)
+        return "f8" if repeat == 1 else f"{repeat}f8"
+
+    try:
+        repeat, format_code, option = _parse_tformat(format)
+        normalized = format.upper()
+
+        if format_code == "X":
+            return _FormatX(repeat)
+        if format_code == "P":
+            return _FormatP.from_tform(normalized)
+        if format_code == "Q":
+            return _FormatQ.from_tform(normalized)
+
+        recformat = FITS2NUMPY[format_code]
+    except (KeyError, VerifyError):
+        raise ValueError(f"Illegal format `{format}`.") from None
+
+    if format_code == "A":
+        width = int(option) if option.isdigit() else repeat
+        return f"S{width}"
+    if repeat != 1:
+        return f"{repeat}{recformat}"
+    return recformat
+
+
 
 
 
@@ -2768,4 +2866,4 @@ def python_to_tdisp(format_string, logical_dtype=False):
     if logical_dtype:
         ftype = "L"
 
-    return ftype + width + sep + precision
\ No newline at end of file
+    return ftype + width + sep + precision
diff --git a/astropy/io/fits/hdu/base.py b/astropy/io/fits/hdu/base.py
index a5171da..ce8684f 100644
--- a/astropy/io/fits/hdu/base.py
+++ b/astropy/io/fits/hdu/base.py
@@ -14,7 +14,15 @@ import numpy as np
 from astropy.io.fits import conf
 from astropy.io.fits.file import _File
 from astropy.io.fits.header import Header, _BasicHeader, _DelayedHeader, _pad_length
-from astropy.io.fits.util import _extract_number, _free_space_check, _get_array_mmap, decode_ascii, first, itersubclasses
+from astropy.io.fits.util import (
+    _extract_number,
+    _free_space_check,
+    _get_array_mmap,
+    _is_int,
+    decode_ascii,
+    first,
+    itersubclasses,
+)
 
 
 
@@ -274,6 +282,10 @@ class _BaseHDU:
     def _data_loaded(self):
         return "data" in self.__dict__ and self.data is not DELAYED
 
+    @property
+    def _has_data(self):
+        return self._data_loaded and self.data is not None
+
 
 
 
@@ -1596,4 +1608,4 @@ class NonstandardExtHDU(ExtensionHDU):
         """
         Return the file data.
         """
-        return self._get_raw_data(self.size, "ubyte", self._data_offset)
\ No newline at end of file
+        return self._get_raw_data(self.size, "ubyte", self._data_offset)
diff --git a/astropy/io/fits/hdu/compressed/_tiled_compression.py b/astropy/io/fits/hdu/compressed/_tiled_compression.py
index e159d14..e352ff0 100644
--- a/astropy/io/fits/hdu/compressed/_tiled_compression.py
+++ b/astropy/io/fits/hdu/compressed/_tiled_compression.py
@@ -153,6 +153,36 @@ def _finalize_array(tile_buffer, *, bitpix, tile_shape, algorithm, lossless):
     return tile_data
 
 
+def _check_compressed_header(header):
+    """Validate header values needed by the tiled-compression machinery."""
+    required = ("ZBITPIX", "ZNAXIS", "ZCMPTYPE")
+    missing = [keyword for keyword in required if keyword not in header]
+    if missing:
+        raise ValueError(
+            "Compressed image header is missing required keyword(s): "
+            + ", ".join(missing)
+        )
+
+    if header["ZBITPIX"] not in BITPIX2DTYPE:
+        raise ValueError(f"Invalid value for ZBITPIX: {header['ZBITPIX']!r}")
+
+    znaxis = header["ZNAXIS"]
+    if not isinstance(znaxis, (int, np.integer)) or znaxis < 0:
+        raise ValueError(f"Invalid value for ZNAXIS: {znaxis!r}")
+
+    compression_type = header["ZCMPTYPE"]
+    if compression_type not in ALGORITHMS:
+        raise ValueError(f"Unsupported compression algorithm: {compression_type!r}")
+
+    for axis in range(1, znaxis + 1):
+        dimension = header.get(f"ZNAXIS{axis}")
+        tile = header.get(f"ZTILE{axis}", dimension)
+        if not isinstance(dimension, (int, np.integer)) or dimension < 0:
+            raise ValueError(f"Invalid value for ZNAXIS{axis}: {dimension!r}")
+        if not isinstance(tile, (int, np.integer)) or tile <= 0:
+            raise ValueError(f"Invalid value for ZTILE{axis}: {tile!r}")
+
+
 
 
 
@@ -645,4 +675,4 @@ def compress_image_data(
 
     table_bytes = table.tobytes()
 
-    return table.tobytes() + compressed_bytes
\ No newline at end of file
+    return table.tobytes() + compressed_bytes
diff --git a/astropy/io/fits/util.py b/astropy/io/fits/util.py
index 75515f4..6b3445b 100644
--- a/astropy/io/fits/util.py
+++ b/astropy/io/fits/util.py
@@ -30,6 +30,13 @@ cmp = lambda a, b: (a > b) - (a < b)
 all_integer_types = (int, np.integer)
 
 
+def _is_int(value):
+    """Return True for Python and NumPy integer scalars, excluding booleans."""
+    return isinstance(value, all_integer_types) and not isinstance(
+        value, (bool, np.bool_)
+    )
+
+
 class NotifierMixin:
     """
     Mixin class that provides services by which objects can register
@@ -690,6 +697,14 @@ def _pseudo_zero(dtype):
     return 1 << (dtype.itemsize * 8 - 1)
 
 
+def _is_pseudo_integer(dtype):
+    """Whether *dtype* uses FITS' pseudo-unsigned integer convention."""
+    dtype = np.dtype(dtype)
+    return (dtype.kind == "i" and dtype.itemsize == 1) or (
+        dtype.kind == "u" and dtype.itemsize in (2, 4, 8)
+    )
+
+
 
 
 
@@ -897,4 +912,4 @@ def _is_dask_array(data):
 
     from dask.array import Array
 
-    return isinstance(data, Array)
\ No newline at end of file
+    return isinstance(data, Array)
```

## 原始行 281 · file_change

```
{
  "id": "item_189",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 284 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.fits.column import _parse_ascii_tformat
print(_parse_ascii_tformat('e12.5'))
PY
python -m pytest astropy/io/fits/tests/test_table.py::TestColumnFunctions::test_column_format_interpretation astropy/io/fits/tests/test_table.py::TestTableFunctions::test_load_guess_format -q --disable-warnings"
```

退出码：`0`

输出：
```
('E', 12, 5)
Internet access disabled
..                                                                       [100%]
2 passed in 0.12s
```

## 原始行 287 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py astropy/io/fits/tests/test_header.py astropy/io/fits/tests/test_table.py astropy/io/fits/hdu/compressed/tests -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
......................................s................ssss............. [  7%]
........................................................................ [ 15%]
........................................................................ [ 23%]
........................................................................ [ 31%]
........................................................................ [ 38%]
....................................................................sss. [ 46%]
................ss..................................................s... [ 54%]
..s..................................................................... [ 62%]
........................................................................ [ 69%]
..............................xxxx.xxxx.xxxx.xxxx.xxxx.xxxx............. [ 77%]
........................................................................ [ 85%]
........................................................................ [ 93%]
........................xxxx.xxxx.xxxx.xxxx.xxxx.xxxx.xxxx.xxxx..        [100%]
861 passed, 14 skipped, 56 xfailed in 8.04s
```

## 原始行 290 · command_execution

命令：
```
/bin/bash -lc 'git diff --check && git status --short'
```

退出码：`0`

输出：
```
 M astropy/io/fits/card.py
 M astropy/io/fits/column.py
 M astropy/io/fits/convenience.py
 M astropy/io/fits/hdu/base.py
 M astropy/io/fits/hdu/compressed/_tiled_compression.py
 M astropy/io/fits/hdu/compressed/compressed.py
 M astropy/io/fits/hdu/groups.py
 M astropy/io/fits/hdu/hdulist.py
 M astropy/io/fits/hdu/image.py
 M astropy/io/fits/hdu/table.py
 M astropy/io/fits/header.py
 M astropy/io/fits/util.py
```

## 原始行 292 · agent_message

```
Implemented all requested FITS header, delayed loading, HDU data-presence, and table-format helpers under `/testbed`.

Also restored missing supporting FITS utilities required by compression and serialization paths.

Validation:

- 861 passed
- 14 skipped
- 56 expected failures
- `git diff --check` passed cleanly
```
