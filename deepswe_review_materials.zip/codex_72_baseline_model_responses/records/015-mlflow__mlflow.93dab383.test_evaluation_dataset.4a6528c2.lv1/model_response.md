# Codex baseline: mlflow__mlflow.93dab383.test_evaluation_dataset.4a6528c2.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the two target modules and their nearby tests/consumers, then implement the smallest compatible change and run focused tests.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' mlflow/data/dataset.py && sed -n '1,220p' mlflow/data/dataset_source.py && rg -n \"Dataset\\(|\\.to_json\\(\\)|source_type|DEFAULT.*dataset|name.*dataset\" tests mlflow/data --glob '*.py'"
```

退出码：`127`

输出：
```
import json
from abc import abstractmethod
from typing import Any

from mlflow.data.dataset_source import DatasetSource
from mlflow.entities import Dataset as DatasetEntity


class Dataset:
    """
    Represents a dataset for use with MLflow Tracking, including the name, digest (hash),
    schema, and profile of the dataset as well as source information (e.g. the S3 bucket or
    managed Delta table from which the dataset was derived). Most datasets expose features
    and targets for training and evaluation as well.
    """











    @abstractmethod
    def _compute_digest(self) -> str:
        """Computes a digest for the dataset. Called if the user doesn't supply
        a digest when constructing the dataset.

        Returns:
            A string digest for the dataset. We recommend a maximum digest length
            of 10 characters with an ideal length of 8 characters.

        """

















    def to_json(self) -> str:
        """
        Obtains a JSON string representation of the :py:class:`Dataset
        <mlflow.data.dataset.Dataset>`.

        Returns:
            A JSON string representation of the :py:class:`Dataset <mlflow.data.dataset.Dataset>`.
        """

        return json.dumps(self.to_dict())

    def _get_source_type(self) -> str:
        """Returns the type of the dataset's underlying source."""

        return self.source._get_source_type()


















    @property
    def source(self) -> DatasetSource:
        """
        Information about the dataset's source, represented as an instance of
        :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`. For example, this
        may be the S3 location or the name of the managed Delta Table from which the dataset
        was derived.
        """
        return self._source

    @property
    @abstractmethod
    def profile(self) -> Any | None:
        """
        Optional summary statistics for the dataset, such as the number of rows in a table, the
        mean / median / std of each table column, etc.
        """

    @property
    @abstractmethod
    def schema(self) -> Any | None:
        """
        Optional dataset schema, such as an instance of :py:class:`mlflow.types.Schema` representing
        the features and targets of the dataset.
        """

    def _to_mlflow_entity(self) -> DatasetEntity:
        """
        Returns:
            A `mlflow.entities.Dataset` instance representing the dataset.
        """
        dataset_dict = self.to_dict()
        return DatasetEntity(
            name=dataset_dict["name"],
            digest=dataset_dict["digest"],
            source_type=dataset_dict["source_type"],
            source=dataset_dict["source"],
            schema=dataset_dict.get("schema"),
            profile=dataset_dict.get("profile"),
        )import json
from abc import abstractmethod
from typing import Any


class DatasetSource:
    """
    Represents the source of a dataset used in MLflow Tracking, providing information such as
    cloud storage location, delta table name / version, etc.
    """

    @staticmethod
    @abstractmethod
    def _get_source_type() -> str:
        """Obtains a string representing the source type of the dataset.

        Returns:
            A string representing the source type of the dataset, e.g. "s3", "delta_table", ...

        """

    @abstractmethod
    def load(self) -> Any:
        """
        Loads files / objects referred to by the DatasetSource. For example, depending on the type
        of :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`, this may download
        source CSV files from S3 to the local filesystem, load a source Delta Table as a Spark
        DataFrame, etc.

        Returns:
            The downloaded source, e.g. a local filesystem path, a Spark DataFrame, etc.

        """

    @staticmethod
    @abstractmethod
    def _can_resolve(raw_source: Any) -> bool:
        """Determines whether this type of DatasetSource can be resolved from a specified raw source
        object. For example, an S3DatasetSource can be resolved from an S3 URI like
        "s3://mybucket/path/to/iris/data" but not from an Azure Blob Storage URI like
        "wasbs:/account@host.blob.core.windows.net".

        Args:
            raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data".

        Returns:
            True if this DatasetSource can resolve the raw source, False otherwise.

        """

    @classmethod
    @abstractmethod
    def _resolve(cls, raw_source: Any) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a raw source object, such as a
        string URI like "s3://mybucket/path/to/iris/data" or a delta table identifier
        like "my.delta.table@2".

        Args:
            raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data".

        Returns:
            A DatasetSource instance derived from the raw_source.

        """

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """Obtains a JSON-compatible dictionary representation of the DatasetSource.

        Returns:
            A JSON-compatible dictionary representation of the DatasetSource.

        """












    @classmethod
    @abstractmethod
    def from_dict(cls, source_dict: dict[Any, Any]) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a dictionary representation.

        Args:
            source_dict: A dictionary representation of the DatasetSource.

        Returns:
            A DatasetSource instance.

        """

    @classmethod
    def from_json(cls, source_json: str) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a JSON string representation.

        Args:
            source_json: A JSON string representation of the DatasetSource.

        Returns:
            A DatasetSource instance.

        """
        return cls.from_dict(json.loads(source_json))/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
The target files are intentionally missing the requested methods; the surrounding serialization/entity hooks are intact. Since `rg` is unavailable here, I’m using scoped `find`/`grep` searches within the repository to confirm expected behavior and avoid unrelated changes.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "git status --short && find tests -type f -name '*.py' -print | grep -E 'data|dataset' | head -100 && grep -RInE 'class .*Dataset|DatasetSource|to_dict\\(\\).*source_type|\"source_type\"|default.*dataset' tests mlflow/data --include='*.py' | head -300"
```

退出码：`0`

输出：
```
tests/langchain/test_langchain_databricks_integration.py
tests/langchain/test_langchain_databricks_dependency_extraction.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_order.py
tests/spark/autologging/datasource/test_spark_datasource_autologging.py
tests/spark/autologging/datasource/test_autologging_behavior_without_spark_session.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_crossframework.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_missing_jar.py
tests/spark/autologging/datasource/__init__.py
tests/spark/autologging/datasource/conftest.py
tests/spark/autologging/datasource/test_spark_datasource_autologging_unit.py
tests/spark/autologging/datasource/test_spark_disable_autologging.py
tests/generate_ui_test_data.py
tests/pyfunc/test_model_export_with_loader_module_and_data_path.py
tests/tracing/test_databricks.py
tests/tensorflow/iris_data_utils.py
tests/genai/judges/adapters/test_databricks_adapter.py
tests/genai/utils/test_data_validation.py
tests/genai/datasets/test_databricks_evaluation_dataset_source.py
tests/genai/datasets/test_fluent.py
tests/genai/datasets/test_evaluation_dataset.py
tests/genai/datasets/__init__.py
tests/tracking/context/test_databricks_cluster_context.py
tests/tracking/context/test_databricks_repo_context.py
tests/tracking/context/test_databricks_command_context.py
tests/tracking/context/test_databricks_notebook_context.py
tests/tracking/context/test_databricks_job_context.py
tests/tracking/request_header/test_databricks_request_header_provider.py
tests/tracking/default_experiment/test_databricks_notebook_experiment_provider.py
tests/projects/test_databricks.py
tests/pytorch/iris_data_module.py
tests/utils/test_databricks_tracing_utils.py
tests/utils/test_data.py
tests/utils/test_databricks_utils.py
tests/test_skinny_client_omits_data_science_libs.py
tests/entities/test_dataset.py
tests/entities/test_dataset_record_source.py
tests/entities/test_dataset_input.py
tests/entities/test_trace_data.py
tests/entities/test_dataset_record.py
tests/entities/test_run_data.py
tests/deployments/databricks/test_databricks.py
tests/deployments/databricks/__init__.py
tests/data/test_dataset.py
tests/data/test_huggingface_dataset_and_source.py
tests/data/test_dataset_source_registry.py
tests/data/test_dataset_registry.py
tests/data/test_polars_dataset.py
tests/data/test_numpy_dataset.py
tests/data/test_http_dataset_source.py
tests/data/test_pandas_dataset.py
tests/data/test_artifact_dataset_sources.py
tests/data/test_tensorflow_dataset.py
tests/data/test_spark_dataset_source.py
tests/data/test_dataset_source.py
tests/data/test_spark_dataset.py
tests/data/test_meta_dataset.py
tests/data/__init__.py
tests/data/test_delta_dataset_source.py
tests/data/test_code_dataset_source.py
tests/resources/mlflow-test-plugin/mlflow_test_plugin/dummy_dataset_source.py
tests/resources/mlflow-test-plugin/mlflow_test_plugin/dummy_dataset.py
tests/resources/data/dataset_source.py
tests/resources/data/dataset.py
tests/resources/data/__init__.py
tests/store/artifact/test_databricks_artifact_repo.py
tests/store/artifact/test_databricks_sdk_models_artifact_repo.py
tests/store/artifact/test_databricks_logged_model_artifact_repo.py
tests/store/artifact/test_azure_data_lake_artifact_repo.py
tests/store/artifact/test_databricks_run_artifact_repo.py
tests/store/artifact/test_databricks_models_artifact_repo.py
tests/store/tracking/test_databricks_rest_store.py
tests/store/model_registry/test_databricks_workspace_model_registry_store.py
tests/langchain/test_langchain_databricks_dependency_extraction.py:442:            resource_name = resource.to_dict()[resource_type][0]["name"]
tests/test_cli.py:831:    # default and datasets
tests/tracing/test_assessment.py:619:@pytest.mark.parametrize("source_type", ["AI_JUDGE", AssessmentSourceType.AI_JUDGE])
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:6:    DatabricksEvaluationDatasetSource,
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:11:    source = DatabricksEvaluationDatasetSource(
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:19:    assert DatabricksEvaluationDatasetSource._get_source_type() == "databricks_evaluation_dataset"
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:23:    source = DatabricksEvaluationDatasetSource(
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:34:    source = DatabricksEvaluationDatasetSource.from_dict(source_dict)
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:40:    source = DatabricksEvaluationDatasetSource(
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:50:    source = DatabricksEvaluationDatasetSource.from_json(json_str)
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:56:    source = DatabricksEvaluationDatasetSource(
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:68:    assert DatabricksEvaluationDatasetSource._can_resolve({}) is False
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:69:    assert DatabricksEvaluationDatasetSource._can_resolve({"table_name": "test"}) is False
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:76:        DatabricksEvaluationDatasetSource._resolve({})
tests/genai/datasets/test_fluent.py:898:        assert record.get("source_type") == "TRACE"
tests/genai/datasets/test_fluent.py:989:        assert "source_type" in row
tests/genai/datasets/test_fluent.py:990:        assert row["source_type"] == "TRACE"
tests/genai/datasets/test_fluent.py:1068:    assert mlflow_record["source_type"] == "TRACE"
tests/genai/datasets/test_fluent.py:1165:    assert ml_record["source_type"] == "TRACE"
tests/genai/datasets/test_fluent.py:1172:        assert record.get("source_type") != "TRACE"
tests/genai/datasets/test_fluent.py:1307:    trace_records = final_df[final_df["source_type"] == "TRACE"]
tests/genai/datasets/test_fluent.py:1310:    manual_records = final_df[final_df["source_type"] != "TRACE"]
tests/genai/datasets/test_fluent.py:1798:    human_sources = df[df["source_type"] == DatasetRecordSourceType.HUMAN.value]
tests/genai/datasets/test_fluent.py:1805:    code_sources = df[df["source_type"] == DatasetRecordSourceType.CODE.value]
tests/genai/datasets/test_fluent.py:1813:                "source_type": DatasetRecordSourceType.DOCUMENT.value,
tests/genai/datasets/test_fluent.py:1821:    doc_sources = df[df["source_type"] == DatasetRecordSourceType.DOCUMENT.value]
tests/genai/datasets/test_fluent.py:1830:    assert last_record["source_type"] not in [
tests/genai/datasets/test_fluent.py:1839:                "source_type": DatasetRecordSourceType.TRACE.value,
tests/genai/datasets/test_fluent.py:1847:    trace_sources = df[df["source_type"] == DatasetRecordSourceType.TRACE.value]
tests/genai/datasets/test_fluent.py:1851:    source_counts = df["source_type"].value_counts()
tests/genai/datasets/test_fluent.py:1888:    trace_sources = df[df["source_type"] == DatasetRecordSourceType.TRACE.value]
tests/genai/datasets/test_fluent.py:1904:    trace_sources2 = df2[df2["source_type"] == DatasetRecordSourceType.TRACE.value]
tests/genai/datasets/test_fluent.py:1916:    trace_sources3 = df3[df3["source_type"] == DatasetRecordSourceType.TRACE.value]
tests/genai/datasets/test_evaluation_dataset.py:12:from mlflow.data.spark_dataset_source import SparkDatasetSource
tests/genai/datasets/test_evaluation_dataset.py:14:    DatabricksEvaluationDatasetSource,
tests/genai/datasets/test_evaluation_dataset.py:15:    DatabricksUCTableDatasetSource,
tests/genai/datasets/test_evaluation_dataset.py:76:    assert isinstance(dataset.source, DatabricksEvaluationDatasetSource)
tests/genai/datasets/test_evaluation_dataset.py:84:    assert isinstance(dataset.source, DatabricksEvaluationDatasetSource)
tests/genai/datasets/test_evaluation_dataset.py:92:    assert isinstance(dataset.source, DatabricksEvaluationDatasetSource)
tests/genai/datasets/test_evaluation_dataset.py:98:    existing_source = DatabricksEvaluationDatasetSource(
tests/genai/datasets/test_evaluation_dataset.py:103:    assert isinstance(dataset.source, DatabricksEvaluationDatasetSource)
tests/genai/datasets/test_evaluation_dataset.py:107:    spark_source = SparkDatasetSource(table_name="spark.table")
tests/genai/datasets/test_evaluation_dataset.py:110:    assert isinstance(dataset.source, DatabricksEvaluationDatasetSource)
tests/genai/datasets/test_evaluation_dataset.py:140:    existing_source = DatabricksEvaluationDatasetSource(
tests/genai/datasets/test_evaluation_dataset.py:199:    register_dataset_source(DatabricksUCTableDatasetSource)
tests/genai/datasets/test_evaluation_dataset.py:204:    assert isinstance(source, DatabricksUCTableDatasetSource)
tests/genai/evaluate/test_evaluation.py:433:        class MockDatasetClient:
tests/server/test_handlers.py:1312:            "source_type": "TRACE",
tests/tracking/fluent/test_fluent.py:25:from mlflow.data.http_dataset_source import HTTPDatasetSource
tests/tracking/fluent/test_fluent.py:1415:    source = HTTPDatasetSource(url=source_uri)
tests/tracking/fluent/test_fluent.py:2397:        dataset_source = HTTPDatasetSource(url="some_uri")
tests/tracking/fluent/test_fluent.py:2412:        dataset_source = HTTPDatasetSource(url="another_uri")
tests/tracking/test_rest_tracking.py:3315:            "source": {"source_type": "HUMAN", "source_id": "evaluator@company.com"},
tests/tracking/test_rest_tracking.py:3333:    assert assessment["source"]["source_type"] == "HUMAN"
tests/tracking/test_rest_tracking.py:3373:            "source": {"source_type": "HUMAN", "source_id": "senior_evaluator@company.com"},
tests/tracking/test_rest_tracking.py:3425:            "source": {"source_type": "CODE", "source_id": "automated_test"},
tests/tracking/test_rest_tracking.py:3442:    assert expectation["source"]["source_type"] == "CODE"
tests/utils/test_jsonpath_utils.py:231:                    "source": {"source_type": "HUMAN", "source_id": "user@example.com"},
tests/telemetry/test_tracked_events.py:300:        {"type": "feedback", "source_type": "CODE"},
tests/telemetry/test_tracked_events.py:307:        {"type": "feedback", "source_type": "CODE"},
tests/telemetry/test_tracked_events.py:321:        {"type": "expectation", "source_type": "HUMAN"},
tests/telemetry/test_tracked_events.py:328:        {"type": "expectation", "source_type": "HUMAN"},
tests/transformers/test_transformers_autolog.py:95:    class CustomDataset(torch.utils.data.Dataset):
tests/transformers/test_transformers_autolog.py:140:    class CustomDataset(torch.utils.data.Dataset):
tests/transformers/test_transformers_autolog.py:223:    class CustomDataset(torch.utils.data.Dataset):
tests/transformers/test_transformers_model_export.py:3653:    class DummyDataset(torch.utils.data.Dataset):
tests/entities/test_trace_info.py:81:                "source": {"source_type": "HUMAN", "source_id": "user_1"},
tests/entities/test_trace_info.py:96:                "source": {"source_type": "HUMAN", "source_id": "user_1"},
tests/entities/test_assessment_source.py:30:        "source_type": "HUMAN",
tests/entities/test_dataset.py:27:        "source_type": source_type,
tests/entities/test_dataset.py:53:        "source_type": source_type,
tests/entities/test_dataset_record_source.py:178:    assert data == {"source_type": "CODE", "source_data": {"file": "example.py", "line": 42}}
tests/entities/test_dataset_record_source.py:186:    trace_data = {"source_type": "TRACE", "source_data": {"trace_id": "trace123"}}
tests/entities/test_dataset_record_source.py:191:    human_data = {"source_type": "HUMAN", "source_data": {"user_id": "user123"}}
tests/entities/test_dataset_record_source.py:196:    doc_data = {"source_type": "DOCUMENT", "source_data": {"doc_uri": "file.txt"}}
tests/entities/test_run_inputs.py:33:                    "source_type": "my_source_type",
tests/entities/test_assessment.py:254:    assert dict["source"].get("source_type") == source.source_type
tests/entities/test_run.py:86:                        "source_type": "my_source_type",
tests/entities/test_dataset_record.py:67:        "source_type",
tests/entities/test_dataset_record.py:110:        kwargs["source_type"] = explicit_source_type
tests/entities/test_dataset_record.py:140:    assert json.loads(proto.source) == {"source_type": "HUMAN", "source_data": {"user_id": "user1"}}
tests/entities/test_dataset_record.py:205:    assert data["source"] == {"source_type": "HUMAN", "source_data": {"user_id": "user1"}}
tests/entities/test_dataset_record.py:207:    assert data["source_type"] == "HUMAN"
tests/entities/test_dataset_record.py:288:                "source": {"source_type": "TRACE", "source_data": {"trace_id": "trace123"}},
tests/entities/test_dataset_record.py:290:            {"source_type": "TRACE", "source_data": {"trace_id": "trace123"}},
tests/entities/test_dataset_record.py:306:                "source_type": "EXPLICIT_TYPE",
tests/entities/test_dataset_record.py:435:        "source": {"source_type": "TRACE", "source_data": {"trace_id": "trace123"}},
tests/cli/test_traces.py:81:        (param for param in log_feedback_cmd.params if param.name == "source_type"), None
tests/data/test_dataset.py:6:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_dataset.py:11:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_dataset.py:16:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_dataset.py:20:    assert parsed_json["source_type"] == dataset.source._get_source_type()
tests/data/test_dataset.py:29:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_dataset.py:36:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_huggingface_dataset_and_source.py:12:from mlflow.data.code_dataset_source import CodeDatasetSource
tests/data/test_huggingface_dataset_and_source.py:16:from mlflow.data.huggingface_dataset_source import HuggingFaceDatasetSource
tests/data/test_huggingface_dataset_and_source.py:22:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_huggingface_dataset_and_source.py:64:    assert isinstance(mlflow_ds.source, HuggingFaceDatasetSource)
tests/data/test_huggingface_dataset_and_source.py:68:        # `HuggingFaceDatasetSource` and `kwargs`.
tests/data/test_huggingface_dataset_and_source.py:116:    assert isinstance(mlflow_ds.source, HuggingFaceDatasetSource)
tests/data/test_huggingface_dataset_and_source.py:145:    assert isinstance(mlflow_ds.source, HuggingFaceDatasetSource)
tests/data/test_huggingface_dataset_and_source.py:204:    assert isinstance(mlflow_ds.source, CodeDatasetSource)
tests/data/test_huggingface_dataset_and_source.py:214:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_huggingface_dataset_and_source.py:218:    assert parsed_json["source_type"] == mlflow_ds.source._get_source_type()
tests/data/test_huggingface_dataset_and_source.py:247:    reloaded_source = HuggingFaceDatasetSource.from_json(source_json)
tests/data/test_huggingface_dataset_and_source.py:253:    assert isinstance(reloaded_source, HuggingFaceDatasetSource)
tests/data/test_huggingface_dataset_and_source.py:272:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_dataset_source_registry.py:6:from mlflow.data.dataset_source_registry import DatasetSourceRegistry
tests/data/test_dataset_source_registry.py:9:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_dataset_source_registry.py:15:    from mlflow_test_plugin.dummy_dataset_source import DummyDatasetSource
tests/data/test_dataset_source_registry.py:17:    registry = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:22:    assert isinstance(resolved_source, DummyDatasetSource)
tests/data/test_dataset_source_registry.py:23:    # Verify that the DummyDatasetSource is constructed with the correct URI
tests/data/test_dataset_source_registry.py:28:    registry = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:29:    registry.register(SampleDatasetSource)
tests/data/test_dataset_source_registry.py:33:    assert isinstance(resolved_source, SampleDatasetSource)
tests/data/test_dataset_source_registry.py:34:    # Verify that the SampleDatasetSource is constructed with the correct URI
tests/data/test_dataset_source_registry.py:39:    registry = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:40:    registry.register(SampleDatasetSource)
tests/data/test_dataset_source_registry.py:50:    registry = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:51:    registry.register(SampleDatasetSource)
tests/data/test_dataset_source_registry.py:56:    class CandidateDatasetSource1(SampleDatasetSource):
tests/data/test_dataset_source_registry.py:65:    class CandidateDatasetSource2(CandidateDatasetSource1):
tests/data/test_dataset_source_registry.py:74:    registry = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:75:    registry.register(SampleDatasetSource)
tests/data/test_dataset_source_registry.py:76:    registry.register(CandidateDatasetSource1)
tests/data/test_dataset_source_registry.py:77:    registry.register(CandidateDatasetSource2)
tests/data/test_dataset_source_registry.py:80:    registry.resolve("test:" + str(tmp_path), candidate_sources=[SampleDatasetSource])
tests/data/test_dataset_source_registry.py:82:        # SampleDatasetSource is the only source that can resolve raw sources with scheme "test",
tests/data/test_dataset_source_registry.py:83:        # and SampleDatasetSource is not a subclass of CandidateDatasetSource1
tests/data/test_dataset_source_registry.py:84:        registry.resolve("test:" + str(tmp_path), candidate_sources=[CandidateDatasetSource1])
tests/data/test_dataset_source_registry.py:87:    registry.resolve("candidate1:" + str(tmp_path), candidate_sources=[CandidateDatasetSource1])
tests/data/test_dataset_source_registry.py:88:    # CandidateDatasetSource1 is a subclass of SampleDatasetSource and is therefore considered
tests/data/test_dataset_source_registry.py:90:    registry.resolve("candidate1:" + str(tmp_path), candidate_sources=[SampleDatasetSource])
tests/data/test_dataset_source_registry.py:92:        # CandidateDatasetSource2 is not a superclass of CandidateDatasetSource1 or
tests/data/test_dataset_source_registry.py:93:        # SampleDatasetSource and cannot resolve raw sources with scheme "candidate1"
tests/data/test_dataset_source_registry.py:94:        registry.resolve("candidate1:" + str(tmp_path), candidate_sources=[CandidateDatasetSource2])
tests/data/test_dataset_source_registry.py:100:    from mlflow_test_plugin.dummy_dataset_source import DummyDatasetSource
tests/data/test_dataset_source_registry.py:102:    class SampleDatasetSourceCopy1(SampleDatasetSource):
tests/data/test_dataset_source_registry.py:105:    class SampleDatasetSourceCopy2(SampleDatasetSource):
tests/data/test_dataset_source_registry.py:108:    registry1 = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:109:    registry1.register(SampleDatasetSource)
tests/data/test_dataset_source_registry.py:110:    registry1.register(SampleDatasetSourceCopy1)
tests/data/test_dataset_source_registry.py:111:    registry1.register(SampleDatasetSourceCopy2)
tests/data/test_dataset_source_registry.py:113:    assert isinstance(source1, SampleDatasetSourceCopy2)
tests/data/test_dataset_source_registry.py:115:    registry2 = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:116:    registry2.register(SampleDatasetSource)
tests/data/test_dataset_source_registry.py:117:    registry2.register(SampleDatasetSourceCopy2)
tests/data/test_dataset_source_registry.py:118:    registry2.register(SampleDatasetSourceCopy1)
tests/data/test_dataset_source_registry.py:120:    assert isinstance(source2, SampleDatasetSourceCopy1)
tests/data/test_dataset_source_registry.py:124:        "test:/" + str(tmp_path), candidate_sources=[SampleDatasetSourceCopy2]
tests/data/test_dataset_source_registry.py:126:    assert isinstance(source3, SampleDatasetSourceCopy2)
tests/data/test_dataset_source_registry.py:129:    class DummyDatasetSourceCopy(DummyDatasetSource):
tests/data/test_dataset_source_registry.py:132:    registry3 = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:133:    registry3.register(DummyDatasetSourceCopy)
tests/data/test_dataset_source_registry.py:135:    assert isinstance(source4, DummyDatasetSourceCopy)
tests/data/test_dataset_source_registry.py:138:    assert isinstance(source5, DummyDatasetSource)
tests/data/test_dataset_source_registry.py:142:    class SampleDatasetSourceCopy1(SampleDatasetSource):
tests/data/test_dataset_source_registry.py:145:    class SampleDatasetSourceCopy2(SampleDatasetSource):
tests/data/test_dataset_source_registry.py:148:    registry1 = DatasetSourceRegistry()
tests/data/test_dataset_source_registry.py:149:    registry1.register(SampleDatasetSource)
tests/data/test_dataset_source_registry.py:150:    registry1.register(SampleDatasetSourceCopy1)
tests/data/test_dataset_source_registry.py:151:    registry1.register(SampleDatasetSourceCopy2)
tests/data/test_dataset_source_registry.py:162:            "SampleDatasetSource, SampleDatasetSourceCopy1, SampleDatasetSourceCopy2"
tests/data/test_dataset_source_registry.py:166:            "MLflow will assume that this is a SampleDatasetSourceCopy2 source"
tests/data/test_dataset_source_registry.py:172:    from mlflow.data.sources import LocalArtifactDatasetSource
tests/data/test_dataset_source_registry.py:174:    src = LocalArtifactDatasetSource(tmp_path)
tests/data/test_dataset_source_registry.py:178:    from mlflow.data.sources import DeltaDatasetSource
tests/data/test_dataset_source_registry.py:180:    src = DeltaDatasetSource(path=tmp_path)
tests/data/test_dataset_registry.py:8:from mlflow.data.dataset_source_registry import DatasetSourceRegistry, resolve_dataset_source
tests/data/test_dataset_registry.py:12:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_dataset_registry.py:17:    registry = DatasetSourceRegistry()
tests/data/test_dataset_registry.py:101:        # Use a DummyDatasetSource URI from mlflow_test_plugin.dummy_dataset_source, which
tests/data/test_dataset_registry.py:114:    dataset_source_registry.register(SampleDatasetSource)
tests/data/test_dataset_registry.py:117:        resolved_source: SampleDatasetSource = resolve_dataset_source(
tests/data/test_dataset_registry.py:118:            source, candidate_sources=[SampleDatasetSource]
tests/data/test_dataset_registry.py:127:        # Use a SampleDatasetSourceURI
tests/data/test_dataset_registry.py:139:        # Use a SampleDatasetSourceURI
tests/data/test_polars_dataset.py:12:from mlflow.data.code_dataset_source import CodeDatasetSource
tests/data/test_polars_dataset.py:14:from mlflow.data.filesystem_dataset_source import FileSystemDatasetSource
tests/data/test_polars_dataset.py:20:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_polars_dataset.py:24:def sample_source() -> SampleDatasetSource:
tests/data/test_polars_dataset.py:26:    return SampleDatasetSource._resolve(source_uri)
tests/data/test_polars_dataset.py:104:def test_conversion_to_json(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:112:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_polars_dataset.py:116:    assert parsed_json["source_type"] == dataset.source._get_source_type()
tests/data/test_polars_dataset.py:123:def test_digest_property_has_expected_value(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:130:def test_digest_consistent(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:142:def test_digest_change(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:154:def test_df_property(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:160:def test_targets_none(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:166:def test_targets_not_none(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:172:def test_targets_invalid(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:181:def test_to_pyfunc_wo_outputs(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:193:def test_to_pyfunc_with_outputs(source: SampleDatasetSource) -> None:
tests/data/test_polars_dataset.py:236:    assert isinstance(mlflow_df.source, FileSystemDatasetSource)
tests/data/test_polars_dataset.py:245:    assert isinstance(mlflow_df.source, CodeDatasetSource)
tests/data/test_polars_dataset.py:249:def test_to_evaluation_dataset(source: SampleDatasetSource) -> None:
tests/data/test_numpy_dataset.py:8:from mlflow.data.code_dataset_source import CodeDatasetSource
tests/data/test_numpy_dataset.py:10:from mlflow.data.filesystem_dataset_source import FileSystemDatasetSource
tests/data/test_numpy_dataset.py:16:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_numpy_dataset.py:21:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:26:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_numpy_dataset.py:30:    assert parsed_json["source_type"] == dataset.source._get_source_type()
tests/data/test_numpy_dataset.py:68:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:73:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_numpy_dataset.py:77:    assert parsed_json["source_type"] == dataset.source._get_source_type()
tests/data/test_numpy_dataset.py:114:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:150:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:168:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:176:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:189:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:197:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_numpy_dataset.py:222:    assert isinstance(mlflow_features.source, FileSystemDatasetSource)
tests/data/test_numpy_dataset.py:247:    assert isinstance(mlflow_ds.source, FileSystemDatasetSource)
tests/data/test_numpy_dataset.py:256:    assert isinstance(mlflow_features.source, CodeDatasetSource)
tests/data/test_http_dataset_source.py:9:from mlflow.data.http_dataset_source import HTTPDatasetSource
tests/data/test_http_dataset_source.py:17:    source = HTTPDatasetSource(url)
tests/data/test_http_dataset_source.py:23:    assert isinstance(reloaded_source, HTTPDatasetSource)
tests/data/test_http_dataset_source.py:30:        "http://mywebsite.com/path/to/my/dataset.txt", candidate_sources=[HTTPDatasetSource]
tests/data/test_http_dataset_source.py:32:    assert isinstance(source1, HTTPDatasetSource)
tests/data/test_http_dataset_source.py:36:        "https://otherwebsite.net", candidate_sources=[HTTPDatasetSource]
tests/data/test_http_dataset_source.py:38:    assert isinstance(source2, HTTPDatasetSource)
tests/data/test_http_dataset_source.py:42:        resolve_dataset_source("s3://mybucket", candidate_sources=[HTTPDatasetSource])
tests/data/test_http_dataset_source.py:45:        resolve_dataset_source("otherscheme://mybucket", candidate_sources=[HTTPDatasetSource])
tests/data/test_http_dataset_source.py:48:        resolve_dataset_source("htp://mybucket", candidate_sources=[HTTPDatasetSource])
tests/data/test_http_dataset_source.py:52:    source1 = HTTPDatasetSource(
tests/data/test_http_dataset_source.py:71:    source2 = HTTPDatasetSource(
tests/data/test_http_dataset_source.py:80:    source3 = HTTPDatasetSource("https://github.com/")
tests/data/test_http_dataset_source.py:85:    source4 = HTTPDatasetSource("https://github.com")
tests/data/test_http_dataset_source.py:95:    source5 = HTTPDatasetSource("https://nonexistentwebsitebuiltbythemlflowteam112312.com")
tests/data/test_http_dataset_source.py:128:        source = HTTPDatasetSource(
tests/data/test_http_dataset_source.py:156:        source = HTTPDatasetSource(
tests/data/test_http_dataset_source.py:182:        source = HTTPDatasetSource(
tests/data/test_pandas_dataset.py:7:from mlflow.data.code_dataset_source import CodeDatasetSource
tests/data/test_pandas_dataset.py:8:from mlflow.data.delta_dataset_source import DeltaDatasetSource
tests/data/test_pandas_dataset.py:10:from mlflow.data.filesystem_dataset_source import FileSystemDatasetSource
tests/data/test_pandas_dataset.py:13:from mlflow.data.spark_dataset_source import SparkDatasetSource
tests/data/test_pandas_dataset.py:18:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_pandas_dataset.py:39:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:49:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_pandas_dataset.py:53:    assert parsed_json["source_type"] == dataset.source._get_source_type()
tests/data/test_pandas_dataset.py:62:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:74:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:86:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:106:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:122:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:134:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:173:    assert isinstance(mlflow_df.source, FileSystemDatasetSource)
tests/data/test_pandas_dataset.py:182:    spark_datasource = SparkDatasetSource(path=path)
tests/data/test_pandas_dataset.py:193:    assert isinstance(mlflow_df.source, SparkDatasetSource)
tests/data/test_pandas_dataset.py:202:    delta_datasource = DeltaDatasetSource(path=path)
tests/data/test_pandas_dataset.py:213:    assert isinstance(mlflow_df.source, DeltaDatasetSource)
tests/data/test_pandas_dataset.py:222:    assert isinstance(mlflow_df.source, CodeDatasetSource)
tests/data/test_pandas_dataset.py:230:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:249:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_pandas_dataset.py:268:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_artifact_dataset_sources.py:8:from mlflow.data.filesystem_dataset_source import FileSystemDatasetSource
tests/data/test_artifact_dataset_sources.py:13:    ("source_uri", "source_type", "source_class_name"),
tests/data/test_artifact_dataset_sources.py:15:        ("/tmp/path/to/my/local/file.txt", "local", "LocalArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:16:        ("file:///tmp/path/to/my/local/directory", "local", "LocalArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:17:        ("s3://mybucket/path/to/my/file.txt", "s3", "S3ArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:18:        ("gs://mybucket/path/to/my/dir", "gs", "GCSArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:19:        ("wasbs://user@host.blob.core.windows.net/dir", "wasbs", "AzureBlobArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:20:        ("ftp://mysite.com/path/to/my/file.txt", "ftp", "FTPArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:21:        ("sftp://mysite.com/path/to/my/dir", "sftp", "SFTPArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:22:        ("hdfs://host_name:8020/hdfs/path/to/my/file.txt", "hdfs", "HdfsArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:23:        ("viewfs://host_name:8020/path/to/my/dir", "viewfs", "HdfsArtifactDatasetSource"),
tests/data/test_artifact_dataset_sources.py:30:    assert isinstance(dataset_source, FileSystemDatasetSource)
tests/data/test_artifact_dataset_sources.py:38:    ("source_uri", "source_type"),
tests/data/test_artifact_dataset_sources.py:62:    assert isinstance(reloaded_source, FileSystemDatasetSource)
tests/data/test_artifact_dataset_sources.py:68:    ("source_uri", "source_type"),
tests/data/test_tensorflow_dataset.py:8:from mlflow.data.code_dataset_source import CodeDatasetSource
tests/data/test_tensorflow_dataset.py:16:from tests.resources.data.dataset_source import SampleDatasetSource
tests/data/test_tensorflow_dataset.py:83:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:88:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_tensorflow_dataset.py:92:    assert parsed_json["source_type"] == dataset.source._get_source_type()
tests/data/test_tensorflow_dataset.py:148:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:153:    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
tests/data/test_tensorflow_dataset.py:157:    assert parsed_json["source_type"] == dataset.source._get_source_type()
tests/data/test_tensorflow_dataset.py:178:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:212:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:242:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:252:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:261:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:270:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:281:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:292:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:303:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:319:    source = SampleDatasetSource._resolve(source_uri)
tests/data/test_tensorflow_dataset.py:401:    assert isinstance(mlflow_ds.source, CodeDatasetSource)
tests/data/test_spark_dataset_source.py:7:from mlflow.data.spark_dataset_source import SparkDatasetSource
tests/data/test_spark_dataset_source.py:33:    spark_datasource = SparkDatasetSource(path=path)
tests/data/test_spark_dataset_source.py:41:    assert isinstance(reloaded_source, SparkDatasetSource)
tests/data/test_spark_dataset_source.py:51:    spark_datasource = SparkDatasetSource(table_name="temp")
tests/data/test_spark_dataset_source.py:59:    assert isinstance(reloaded_source, SparkDatasetSource)
tests/data/test_spark_dataset_source.py:69:    spark_datasource = SparkDatasetSource(sql="SELECT * FROM temp_sql")
tests/data/test_spark_dataset_source.py:77:    assert isinstance(reloaded_source, SparkDatasetSource)
tests/data/test_spark_dataset_source.py:90:        SparkDatasetSource(path=tmp_path, table_name="temp")
tests/data/test_dataset_source.py:9:from tests.resources.data.dataset_source import SampleDatasetSource
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' tests/data/test_dataset.py && sed -n '1,180p' tests/data/test_dataset_source.py && sed -n '1,220p' tests/resources/data/dataset.py && sed -n '1,220p' tests/resources/data/dataset_source.py && grep -RIn 'super().__init__(source' mlflow/data tests/resources tests/data --include='*.py' | head -100"
```

退出码：`0`

输出：
```
import json

from mlflow.types.schema import Schema

from tests.resources.data.dataset import SampleDataset
from tests.resources.data.dataset_source import SampleDatasetSource


def test_conversion_to_json():
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)
    dataset = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")

    dataset_json = dataset.to_json()
    parsed_json = json.loads(dataset_json)
    assert parsed_json.keys() <= {"name", "digest", "source", "source_type", "schema", "profile"}
    assert parsed_json["name"] == dataset.name
    assert parsed_json["digest"] == dataset.digest
    assert parsed_json["source"] == dataset.source.to_json()
    assert parsed_json["source_type"] == dataset.source._get_source_type()
    assert parsed_json["profile"] == json.dumps(dataset.profile)

    schema_json = json.dumps(json.loads(parsed_json["schema"])["mlflow_colspec"])
    assert Schema.from_json(schema_json) == dataset.schema


def test_digest_property_has_expected_value():
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)
    dataset = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")
    assert dataset.digest == dataset._compute_digest()


def test_expected_name_is_used():
    source_uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(source_uri)

    dataset_without_name = SampleDataset(data_list=[1, 2, 3], source=source)
    assert dataset_without_name.name == "dataset"

    dataset_with_name = SampleDataset(data_list=[1, 2, 3], source=source, name="testname")
    assert dataset_with_name.name == "testname"
import json

import pandas as pd
import pytest

import mlflow.data
from mlflow.exceptions import MlflowException

from tests.resources.data.dataset_source import SampleDatasetSource


def test_load(tmp_path):
    assert SampleDatasetSource("test:" + str(tmp_path)).load() == str(tmp_path)


def test_conversion_to_json_and_back():
    uri = "test:/my/test/uri"
    source = SampleDatasetSource._resolve(uri)
    source_json = source.to_json()
    assert json.loads(source_json)["uri"] == uri
    reloaded_source = SampleDatasetSource.from_json(source_json)
    assert reloaded_source.uri == source.uri


def test_get_source_obtains_expected_file_source(tmp_path):
    df = pd.DataFrame([[1, 2, 3], [1, 2, 3]], columns=["a", "b", "c"])
    path = tmp_path / "temp.csv"
    df.to_csv(path)
    pandas_ds = mlflow.data.from_pandas(df, source=path)

    source1 = mlflow.data.get_source(pandas_ds)
    assert json.loads(source1.to_json()) == json.loads(pandas_ds.source.to_json())

    with mlflow.start_run() as r:
        mlflow.log_input(pandas_ds)

    run = mlflow.get_run(r.info.run_id)

    ds_input = run.inputs.dataset_inputs[0]
    source2 = mlflow.data.get_source(ds_input)
    assert json.loads(source2.to_json()) == json.loads(pandas_ds.source.to_json())

    ds_entity = run.inputs.dataset_inputs[0].dataset
    source3 = mlflow.data.get_source(ds_entity)
    assert json.loads(source3.to_json()) == json.loads(pandas_ds.source.to_json())

    assert source1.load() == source2.load() == source3.load() == str(path)


def test_get_source_obtains_expected_code_source():
    df = pd.DataFrame([[1, 2, 3], [1, 2, 3]], columns=["a", "b", "c"])
    pandas_ds = mlflow.data.from_pandas(df)

    source1 = mlflow.data.get_source(pandas_ds)
    assert json.loads(source1.to_json()) == json.loads(pandas_ds.source.to_json())

    with mlflow.start_run() as r:
        mlflow.log_input(pandas_ds)

    run = mlflow.get_run(r.info.run_id)

    ds_input = run.inputs.dataset_inputs[0]
    source2 = mlflow.data.get_source(ds_input)
    assert json.loads(source2.to_json()) == json.loads(pandas_ds.source.to_json())

    ds_entity = run.inputs.dataset_inputs[0].dataset
    source3 = mlflow.data.get_source(ds_entity)
    assert json.loads(source3.to_json()) == json.loads(pandas_ds.source.to_json())


def test_get_source_throws_for_invalid_input(tmp_path):
    with pytest.raises(MlflowException, match="Unrecognized dataset type.*str"):
        mlflow.data.get_source(str(tmp_path))
import base64
import hashlib
import json
from typing import Any

import numpy as np
import pandas as pd

from mlflow.data.dataset import Dataset
from mlflow.types import Schema
from mlflow.types.utils import _infer_schema

from tests.resources.data.dataset_source import SampleDatasetSource


class SampleDataset(Dataset):
    def __init__(
        self,
        data_list: list[int],
        source: SampleDatasetSource,
        name: str | None = None,
        digest: str | None = None,
    ):
        self._data_list = data_list
        super().__init__(source=source, name=name, digest=digest)

    def _compute_digest(self) -> str:
        """
        Computes a digest for the dataset. Called if the user doesn't supply
        a digest when constructing the dataset.
        """
        hash_md5 = hashlib.md5(usedforsecurity=False)
        for hash_part in pd.util.hash_array(np.array(self._data_list)):
            hash_md5.update(hash_part)
        return base64.b64encode(hash_md5.digest()).decode("ascii")

    def to_dict(self) -> dict[str, str]:
        """
        Returns:
            A string dictionary containing the following fields: name,
            digest, source, source type, schema (optional), profile
            (optional).
        """
        config = super().to_dict()
        config.update(
            {
                "schema": json.dumps({"mlflow_colspec": self.schema.to_dict()}),
                "profile": json.dumps(self.profile),
            }
        )
        return config

    @property
    def data_list(self) -> list[int]:
        return self._data_list

    @property
    def source(self) -> SampleDatasetSource:
        return self._source

    @property
    def profile(self) -> Any | None:
        return {
            "length": len(self._data_list),
        }

    @property
    def schema(self) -> Schema:
        return _infer_schema(np.array(self._data_list))
from typing import Any
from urllib.parse import urlparse

from mlflow.artifacts import download_artifacts
from mlflow.data.dataset_source import DatasetSource
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE


class SampleDatasetSource(DatasetSource):
    def __init__(self, uri):
        self._uri = uri

    @property
    def uri(self):
        return self._uri

    @staticmethod
    def _get_source_type() -> str:
        return "test"

    def load(self) -> str:
        # Ignore the "test" URI scheme and download the local path
        parsed_uri = urlparse(self._uri)
        return download_artifacts(parsed_uri.path)

    @staticmethod
    def _can_resolve(raw_source: Any) -> bool:
        if not isinstance(raw_source, str):
            return False

        try:
            parsed_source = urlparse(raw_source)
            return parsed_source.scheme == "test"
        except Exception:
            return False

    @classmethod
    def _resolve(cls, raw_source: Any) -> DatasetSource:
        return cls(raw_source)

    def to_dict(self) -> dict[Any, Any]:
        return {"uri": self.uri}

    @classmethod
    def from_dict(cls, source_dict: dict[Any, Any]) -> DatasetSource:
        uri = source_dict.get("uri")
        if uri is None:
            raise MlflowException(
                'Failed to parse dummy dataset source. Missing expected key: "uri"',
                INVALID_PARAMETER_VALUE,
            )

        return cls(uri=uri)
mlflow/data/pandas_dataset.py:63:        super().__init__(source=source, name=name, digest=digest)
mlflow/data/numpy_dataset.py:45:        super().__init__(source=source, name=name, digest=digest)
mlflow/data/tensorflow_dataset.py:78:        super().__init__(source=source, name=name, digest=digest)
mlflow/data/polars_dataset.py:186:        super().__init__(source=source, name=name, digest=digest)
mlflow/data/spark_dataset.py:57:        super().__init__(source=source, name=name, digest=digest)
mlflow/data/huggingface_dataset.py:57:        super().__init__(source=source, name=name, digest=digest)
mlflow/data/meta_dataset.py:72:        super().__init__(source=source, name=name, digest=digest)
tests/resources/mlflow-test-plugin/mlflow_test_plugin/dummy_dataset.py:22:        super().__init__(source=source, name=name, digest=digest)
tests/resources/data/dataset.py:25:        super().__init__(source=source, name=name, digest=digest)
```

## 原始行 15 · agent_message

```
The visible tests confirm the base dictionary must store the source as its JSON string (not a nested dict), and subclasses already initialize digest-dependent state before calling `Dataset.__init__`. I’m adding exactly the constructor, base serializer, stored digest/name properties, and source JSON serializer.
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/data/dataset.py | sed -n '1,180p'; nl -ba mlflow/data/dataset_source.py | sed -n '1,180p'"
```

退出码：`0`

输出：
```
     1	import json
     2	from abc import abstractmethod
     3	from typing import Any
     4	
     5	from mlflow.data.dataset_source import DatasetSource
     6	from mlflow.entities import Dataset as DatasetEntity
     7	
     8	
     9	class Dataset:
    10	    """
    11	    Represents a dataset for use with MLflow Tracking, including the name, digest (hash),
    12	    schema, and profile of the dataset as well as source information (e.g. the S3 bucket or
    13	    managed Delta table from which the dataset was derived). Most datasets expose features
    14	    and targets for training and evaluation as well.
    15	    """
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	    @abstractmethod
    28	    def _compute_digest(self) -> str:
    29	        """Computes a digest for the dataset. Called if the user doesn't supply
    30	        a digest when constructing the dataset.
    31	
    32	        Returns:
    33	            A string digest for the dataset. We recommend a maximum digest length
    34	            of 10 characters with an ideal length of 8 characters.
    35	
    36	        """
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	    def to_json(self) -> str:
    55	        """
    56	        Obtains a JSON string representation of the :py:class:`Dataset
    57	        <mlflow.data.dataset.Dataset>`.
    58	
    59	        Returns:
    60	            A JSON string representation of the :py:class:`Dataset <mlflow.data.dataset.Dataset>`.
    61	        """
    62	
    63	        return json.dumps(self.to_dict())
    64	
    65	    def _get_source_type(self) -> str:
    66	        """Returns the type of the dataset's underlying source."""
    67	
    68	        return self.source._get_source_type()
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	    @property
    88	    def source(self) -> DatasetSource:
    89	        """
    90	        Information about the dataset's source, represented as an instance of
    91	        :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`. For example, this
    92	        may be the S3 location or the name of the managed Delta Table from which the dataset
    93	        was derived.
    94	        """
    95	        return self._source
    96	
    97	    @property
    98	    @abstractmethod
    99	    def profile(self) -> Any | None:
   100	        """
   101	        Optional summary statistics for the dataset, such as the number of rows in a table, the
   102	        mean / median / std of each table column, etc.
   103	        """
   104	
   105	    @property
   106	    @abstractmethod
   107	    def schema(self) -> Any | None:
   108	        """
   109	        Optional dataset schema, such as an instance of :py:class:`mlflow.types.Schema` representing
   110	        the features and targets of the dataset.
   111	        """
   112	
   113	    def _to_mlflow_entity(self) -> DatasetEntity:
   114	        """
   115	        Returns:
   116	            A `mlflow.entities.Dataset` instance representing the dataset.
   117	        """
   118	        dataset_dict = self.to_dict()
   119	        return DatasetEntity(
   120	            name=dataset_dict["name"],
   121	            digest=dataset_dict["digest"],
   122	            source_type=dataset_dict["source_type"],
   123	            source=dataset_dict["source"],
   124	            schema=dataset_dict.get("schema"),
   125	            profile=dataset_dict.get("profile"),
   126	        )
     1	import json
     2	from abc import abstractmethod
     3	from typing import Any
     4	
     5	
     6	class DatasetSource:
     7	    """
     8	    Represents the source of a dataset used in MLflow Tracking, providing information such as
     9	    cloud storage location, delta table name / version, etc.
    10	    """
    11	
    12	    @staticmethod
    13	    @abstractmethod
    14	    def _get_source_type() -> str:
    15	        """Obtains a string representing the source type of the dataset.
    16	
    17	        Returns:
    18	            A string representing the source type of the dataset, e.g. "s3", "delta_table", ...
    19	
    20	        """
    21	
    22	    @abstractmethod
    23	    def load(self) -> Any:
    24	        """
    25	        Loads files / objects referred to by the DatasetSource. For example, depending on the type
    26	        of :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`, this may download
    27	        source CSV files from S3 to the local filesystem, load a source Delta Table as a Spark
    28	        DataFrame, etc.
    29	
    30	        Returns:
    31	            The downloaded source, e.g. a local filesystem path, a Spark DataFrame, etc.
    32	
    33	        """
    34	
    35	    @staticmethod
    36	    @abstractmethod
    37	    def _can_resolve(raw_source: Any) -> bool:
    38	        """Determines whether this type of DatasetSource can be resolved from a specified raw source
    39	        object. For example, an S3DatasetSource can be resolved from an S3 URI like
    40	        "s3://mybucket/path/to/iris/data" but not from an Azure Blob Storage URI like
    41	        "wasbs:/account@host.blob.core.windows.net".
    42	
    43	        Args:
    44	            raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data".
    45	
    46	        Returns:
    47	            True if this DatasetSource can resolve the raw source, False otherwise.
    48	
    49	        """
    50	
    51	    @classmethod
    52	    @abstractmethod
    53	    def _resolve(cls, raw_source: Any) -> "DatasetSource":
    54	        """Constructs an instance of the DatasetSource from a raw source object, such as a
    55	        string URI like "s3://mybucket/path/to/iris/data" or a delta table identifier
    56	        like "my.delta.table@2".
    57	
    58	        Args:
    59	            raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data".
    60	
    61	        Returns:
    62	            A DatasetSource instance derived from the raw_source.
    63	
    64	        """
    65	
    66	    @abstractmethod
    67	    def to_dict(self) -> dict[str, Any]:
    68	        """Obtains a JSON-compatible dictionary representation of the DatasetSource.
    69	
    70	        Returns:
    71	            A JSON-compatible dictionary representation of the DatasetSource.
    72	
    73	        """
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	    @classmethod
    87	    @abstractmethod
    88	    def from_dict(cls, source_dict: dict[Any, Any]) -> "DatasetSource":
    89	        """Constructs an instance of the DatasetSource from a dictionary representation.
    90	
    91	        Args:
    92	            source_dict: A dictionary representation of the DatasetSource.
    93	
    94	        Returns:
    95	            A DatasetSource instance.
    96	
    97	        """
    98	
    99	    @classmethod
   100	    def from_json(cls, source_json: str) -> "DatasetSource":
   101	        """Constructs an instance of the DatasetSource from a JSON string representation.
   102	
   103	        Args:
   104	            source_json: A JSON string representation of the DatasetSource.
   105	
   106	        Returns:
   107	            A DatasetSource instance.
   108	
   109	        """
   110	        return cls.from_dict(json.loads(source_json))
```

## 原始行 21 · file_change

```
{
  "id": "item_13",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/data/dataset.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/data/dataset_source.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 24 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/data/test_dataset.py tests/data/test_dataset_source.py -q'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 8 items

tests/data/test_dataset.py [32m.[0m[32m.[0m[32m.[0m[32m                                           [ 37%][0m
tests/data/test_dataset_source.py [31mF[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[31m                                  [100%][0m

=================================== FAILURES ===================================
[31m[1m__________________________________ test_load ___________________________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-0/test_load0')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_load[39;49;00m(tmp_path):[90m[39;49;00m
>       [94massert[39;49;00m SampleDatasetSource([33m"[39;49;00m[33mtest:[39;49;00m[33m"[39;49;00m + [96mstr[39;49;00m(tmp_path)).load() == [96mstr[39;49;00m(tmp_path)[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-0/test_load0')

[1m[31mtests/data/test_dataset_source.py[0m:13: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mtests/resources/data/dataset_source.py[0m:25: in load
    [0m[94mreturn[39;49;00m download_artifacts(parsed_uri.path)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        parsed_uri = ParseResult(scheme='test', netloc='', path='/tmp/pytest-of-root/pytest-0/test_load0', params='', query='', fragment='')
        self       = <tests.resources.data.dataset_source.SampleDatasetSource object at 0x7da26ec05610>
[1m[31mmlflow/artifacts/__init__.py[0m:84: in download_artifacts
    [0m[94mreturn[39;49;00m _download_artifact_from_uri([90m[39;49;00m
        artifact_path = None
        artifact_uri = '/tmp/pytest-of-root/pytest-0/test_load0'
        dst_path   = None
        registry_uri = None
        run_id     = None
        tracking_uri = None
[1m[31mmlflow/tracking/artifact_utils.py[0m:116: in _download_artifact_from_uri
    [0mroot_uri, artifact_path = _get_root_uri_and_artifact_path(artifact_uri)[90m[39;49;00m
                              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        artifact_uri = '/tmp/pytest-of-root/pytest-0/test_load0'
        lineage_header_info = None
        output_path = None
        registry_uri = None
        tracking_uri = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

artifact_uri = '/tmp/pytest-of-root/pytest-0/test_load0'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_get_root_uri_and_artifact_path[39;49;00m(artifact_uri):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Parse the artifact_uri to get the root_uri and artifact_path.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        artifact_uri: The *absolute* URI of the artifact.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [94mif[39;49;00m os.path.exists(artifact_uri):[90m[39;49;00m
>           [94mif[39;49;00m [95mnot[39;49;00m is_windows():[90m[39;49;00m
                   ^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'is_windows' is not defined[0m

artifact_uri = '/tmp/pytest-of-root/pytest-0/test_load0'

[1m[31mmlflow/tracking/artifact_utils.py[0m:71: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:00:55 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________ test_get_source_obtains_expected_file_source _________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get_source_obtains_expected_file_source[39;49;00m(tmp_path):[90m[39;49;00m
        df = pd.DataFrame([[[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m], [[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m]], columns=[[33m"[39;49;00m[33ma[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mb[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mc[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
        path = tmp_path / [33m"[39;49;00m[33mtemp.csv[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        df.to_csv(path)[90m[39;49;00m
>       pandas_ds = mlflow.data.from_pandas(df, source=path)[90m[39;49;00m
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

df         =    a  b  c
0  1  2  3
1  1  2  3
path       = PosixPath('/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0/temp.csv')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0')

[1m[31mtests/data/test_dataset_source.py[0m:29: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/data/pandas_dataset.py[0m:218: in from_pandas
    [0mresolved_source = resolve_dataset_source([90m[39;49;00m
        CodeDatasetSource = <class 'mlflow.data.code_dataset_source.CodeDatasetSource'>
        df         =    a  b  c
0  1  2  3
1  1  2  3
        digest     = None
        name       = None
        predictions = None
        registry   = <module 'mlflow.tracking.context.registry' from '/testbed/mlflow/tracking/context/registry.py'>
        resolve_dataset_source = <function resolve_dataset_source at 0x7da2744e7880>
        source     = PosixPath('/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0/temp.csv')
        targets    = None
[1m[31mmlflow/data/dataset_source_registry.py[0m:148: in resolve_dataset_source
    [0m[94mreturn[39;49;00m _dataset_source_registry.resolve([90m[39;49;00m
        candidate_sources = None
        raw_source = PosixPath('/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0/temp.csv')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x7da27435b010>
raw_source = PosixPath('/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0/temp.csv')
candidate_sources = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m, raw_source: Any, candidate_sources: [96mlist[39;49;00m[DatasetSource] | [94mNone[39;49;00m = [94mNone[39;49;00m[90m[39;49;00m
    ) -> DatasetSource:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Resolves a raw source object, such as a string URI, to a DatasetSource for use with[39;49;00m
    [33m    MLflow Tracking.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data" or a[39;49;00m
    [33m            HuggingFace :py:class:`datasets.Dataset` object.[39;49;00m
    [33m        candidate_sources: A list of DatasetSource classes to consider as potential sources[39;49;00m
    [33m            when resolving the raw source. Subclasses of the specified candidate sources are[39;49;00m
    [33m            also considered. If unspecified, all registered sources are considered.[39;49;00m
    [33m[39;49;00m
    [33m    Raises:[39;49;00m
    [33m        MlflowException: If no DatasetSource class can resolve the raw source.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        The resolved DatasetSource.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        matching_sources = [][90m[39;49;00m
        [94mfor[39;49;00m source [95min[39;49;00m [96mself[39;49;00m.sources:[90m[39;49;00m
            [94mif[39;49;00m candidate_sources [95mand[39;49;00m [95mnot[39;49;00m [96many[39;49;00m([90m[39;49;00m
                [96missubclass[39;49;00m(source, candidate_src) [94mfor[39;49;00m candidate_src [95min[39;49;00m candidate_sources[90m[39;49;00m
            ):[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mif[39;49;00m source._can_resolve(raw_source):[90m[39;49;00m
                    matching_sources.append(source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mFailed to determine whether [39;49;00m[33m{[39;49;00msource.[91m__name__[39;49;00m[33m}[39;49;00m[33m can resolve source[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [96mlen[39;49;00m(matching_sources) > [94m1[39;49;00m:[90m[39;49;00m
            source_class_names_str = [33m"[39;49;00m[33m, [39;49;00m[33m"[39;49;00m.join([source.[91m__name__[39;49;00m [94mfor[39;49;00m source [95min[39;49;00m matching_sources])[90m[39;49;00m
            warnings.warn([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mThe specified dataset source can be interpreted in multiple ways:[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00msource_class_names_str[33m}[39;49;00m[33m. MLflow will assume that this is a[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00mmatching_sources[-[94m1[39;49;00m].[91m__name__[39;49;00m[33m}[39;49;00m[33m source.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                stacklevel=[94m2[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        [94mfor[39;49;00m matching_source [95min[39;49;00m [96mreversed[39;49;00m(matching_sources):[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mreturn[39;49;00m matching_source._resolve(raw_source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mEncountered an unexpected error while using [39;49;00m[33m{[39;49;00mmatching_source.[91m__name__[39;49;00m[33m}[39;49;00m[33m to[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m resolve source information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mraise[39;49;00m MlflowException([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33mCould not find a source information resolver for the specified[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m dataset source: [39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       mlflow.exceptions.MlflowException: Could not find a source information resolver for the specified dataset source: /tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0/temp.csv.[0m

candidate_sources = None
matching_sources = []
raw_source = PosixPath('/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0/temp.csv')
self       = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x7da27435b010>
source     = <class 'mlflow.data.uc_volume_dataset_source.UCVolumeDatasetSource'>

[1m[31mmlflow/data/dataset_source_registry.py[0m:94: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:00:55 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________ test_get_source_obtains_expected_code_source _________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get_source_obtains_expected_code_source[39;49;00m():[90m[39;49;00m
        df = pd.DataFrame([[[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m], [[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m]], columns=[[33m"[39;49;00m[33ma[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mb[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mc[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
        pandas_ds = mlflow.data.from_pandas(df)[90m[39;49;00m
    [90m[39;49;00m
        source1 = mlflow.data.get_source(pandas_ds)[90m[39;49;00m
        [94massert[39;49;00m json.loads(source1.to_json()) == json.loads(pandas_ds.source.to_json())[90m[39;49;00m
    [90m[39;49;00m
>       [94mwith[39;49;00m mlflow.start_run() [94mas[39;49;00m r:[90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^[90m[39;49;00m

df         =    a  b  c
0  1  2  3
1  1  2  3
pandas_ds  = <mlflow.data.pandas_dataset.PandasDataset object at 0x7da26ea51b10>
source1    = <mlflow.data.code_dataset_source.CodeDatasetSource object at 0x7da26eb36310>

[1m[31mtests/data/test_dataset_source.py[0m:57: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/tracking/fluent.py[0m:390: in start_run
    [0mclient = MlflowClient()[90m[39;49;00m
             ^^^^^^^^^^^^^^[90m[39;49;00m
        active_run_stack = []
        description = None
        experiment_id = None
        log_system_metrics = None
        nested     = False
        parent_run_id = None
        run_id     = None
        run_name   = None
        tags       = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.tracking.client.MlflowClient object at 0x7da26ebe11d0>
tracking_uri = None, registry_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__init__[39;49;00m([96mself[39;49;00m, tracking_uri: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m, registry_uri: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Args:[39;49;00m
    [33m        tracking_uri: Address of local or remote tracking server. If not provided, defaults[39;49;00m
    [33m            to the service set by ``mlflow.tracking.set_tracking_uri``. See[39;49;00m
    [33m            `Where Runs Get Recorded <../tracking.html#where-runs-get-recorded>`_[39;49;00m
    [33m            for more info.[39;49;00m
    [33m        registry_uri: Address of local or remote model registry server. If not provided,[39;49;00m
    [33m            defaults to the service set by ``mlflow.tracking.set_registry_uri``. If[39;49;00m
    [33m            no such service was set, defaults to the tracking uri of the client.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
>       final_tracking_uri = utils._resolve_tracking_uri(tracking_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       AttributeError: module 'mlflow.tracking._tracking_service.utils' has no attribute '_resolve_tracking_uri'[0m

registry_uri = None
self       = <mlflow.tracking.client.MlflowClient object at 0x7da26ebe11d0>
tracking_uri = None

[1m[31mmlflow/tracking/client.py[0m:216: AttributeError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:00:55 INFO mlflow.tracking.fluent: Active model is cleared
[33m=============================== warnings summary ===============================[0m
tests/data/test_dataset_source.py::test_get_source_obtains_expected_file_source
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: Failed to determine whether UCVolumeDatasetSource can resolve source information for '/tmp/pytest-of-root/pytest-0/test_get_source_obtains_expect0/temp.csv'. Exception: 
    return _dataset_source_registry.resolve(

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
0.04s call     tests/data/test_dataset_source.py::test_get_source_obtains_expected_code_source

(9 durations < 0.005s hidden.  Use -vv to show these durations.)
========================= command to run failed tests ==========================
pytest 'tests/data/test_dataset_source.py::test_load' 'tests/data/test_dataset_source.py::test_get_source_obtains_expected_file_source' 'tests/data/test_dataset_source.py::test_get_source_obtains_expected_code_source'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_dataset_source.py::[1mtest_load[0m - NameError: name 'is_windows' is not defined
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_dataset_source.py::[1mtest_get_source_obtains_expected_file_source[0m - mlflow.exceptions.MlflowException: Could not find a source information reso...
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_dataset_source.py::[1mtest_get_source_obtains_expected_code_source[0m - AttributeError: module 'mlflow.tracking._tracking_service.utils' has no att...
[31m==================== [31m[1m3 failed[0m, [32m5 passed[0m, [33m1 warning[0m[31m in 0.20s[0m[31m ====================[0m
```

## 原始行 26 · agent_message

```
The requested dataset tests pass. Three broader source-module failures come from separate masked omissions elsewhere (`is_windows`, tracking URI resolution, and a source resolver), not from these interfaces; the source JSON round-trip itself passes. I’m now checking formatting plus representative dataset subclasses and explicit edge cases (empty digest, empty name, and digest snapshot stability).
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc 'ruff check mlflow/data/dataset.py mlflow/data/dataset_source.py && ruff format --check mlflow/data/dataset.py mlflow/data/dataset_source.py && python -m pytest tests/data/test_numpy_dataset.py tests/data/test_pandas_dataset.py -q'
```

退出码：`2`

输出：
```
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 31 · command_execution

命令：
```
/bin/bash -lc 'python -m compileall -q mlflow/data/dataset.py mlflow/data/dataset_source.py && python -m pytest tests/data/test_numpy_dataset.py tests/data/test_pandas_dataset.py -q'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 30 items

tests/data/test_numpy_dataset.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[31m                         [ 50%][0m
tests/data/test_pandas_dataset.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[31mE[0m[31mE[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                        [100%][0m

==================================== ERRORS ====================================
[31m[1m_____________ ERROR at setup of test_from_pandas_spark_datasource ______________[0m

    [0m[37m@pytest[39;49;00m.fixture(scope=[33m"[39;49;00m[33mmodule[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mspark_session[39;49;00m():[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mpyspark[39;49;00m[04m[96m.[39;49;00m[04m[96msql[39;49;00m[90m [39;49;00m[94mimport[39;49;00m SparkSession[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'pyspark'[0m


[1m[31mtests/data/test_pandas_dataset.py[0m:23: ModuleNotFoundError
[31m[1m_____________ ERROR at setup of test_from_pandas_delta_datasource ______________[0m

    [0m[37m@pytest[39;49;00m.fixture(scope=[33m"[39;49;00m[33mmodule[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mspark_session[39;49;00m():[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mpyspark[39;49;00m[04m[96m.[39;49;00m[04m[96msql[39;49;00m[90m [39;49;00m[94mimport[39;49;00m SparkSession[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'pyspark'[0m


[1m[31mtests/data/test_pandas_dataset.py[0m:23: ModuleNotFoundError
=================================== FAILURES ===================================
[31m[1m________________________ test_from_numpy_features_only _________________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_from_numpy_features_only[39;49;00m(tmp_path):[90m[39;49;00m
        features = np.array([[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m])[90m[39;49;00m
        path = tmp_path / [33m"[39;49;00m[33mtemp.csv[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        pd.DataFrame(features).to_csv(path)[90m[39;49;00m
>       mlflow_features = mlflow.data.from_numpy(features, source=path)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

features   = array([1, 2, 3])
path       = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0/temp.csv')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0')

[1m[31mtests/data/test_numpy_dataset.py[0m:211: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/data/numpy_dataset.py[0m:215: in from_numpy
    [0mresolved_source = resolve_dataset_source([90m[39;49;00m
        CodeDatasetSource = <class 'mlflow.data.code_dataset_source.CodeDatasetSource'>
        digest     = None
        features   = array([1, 2, 3])
        name       = None
        registry   = <module 'mlflow.tracking.context.registry' from '/testbed/mlflow/tracking/context/registry.py'>
        resolve_dataset_source = <function resolve_dataset_source at 0x74cbc067d620>
        source     = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0/temp.csv')
        targets    = None
[1m[31mmlflow/data/dataset_source_registry.py[0m:148: in resolve_dataset_source
    [0m[94mreturn[39;49;00m _dataset_source_registry.resolve([90m[39;49;00m
        candidate_sources = None
        raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0/temp.csv')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0/temp.csv')
candidate_sources = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m, raw_source: Any, candidate_sources: [96mlist[39;49;00m[DatasetSource] | [94mNone[39;49;00m = [94mNone[39;49;00m[90m[39;49;00m
    ) -> DatasetSource:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Resolves a raw source object, such as a string URI, to a DatasetSource for use with[39;49;00m
    [33m    MLflow Tracking.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data" or a[39;49;00m
    [33m            HuggingFace :py:class:`datasets.Dataset` object.[39;49;00m
    [33m        candidate_sources: A list of DatasetSource classes to consider as potential sources[39;49;00m
    [33m            when resolving the raw source. Subclasses of the specified candidate sources are[39;49;00m
    [33m            also considered. If unspecified, all registered sources are considered.[39;49;00m
    [33m[39;49;00m
    [33m    Raises:[39;49;00m
    [33m        MlflowException: If no DatasetSource class can resolve the raw source.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        The resolved DatasetSource.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        matching_sources = [][90m[39;49;00m
        [94mfor[39;49;00m source [95min[39;49;00m [96mself[39;49;00m.sources:[90m[39;49;00m
            [94mif[39;49;00m candidate_sources [95mand[39;49;00m [95mnot[39;49;00m [96many[39;49;00m([90m[39;49;00m
                [96missubclass[39;49;00m(source, candidate_src) [94mfor[39;49;00m candidate_src [95min[39;49;00m candidate_sources[90m[39;49;00m
            ):[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mif[39;49;00m source._can_resolve(raw_source):[90m[39;49;00m
                    matching_sources.append(source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mFailed to determine whether [39;49;00m[33m{[39;49;00msource.[91m__name__[39;49;00m[33m}[39;49;00m[33m can resolve source[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [96mlen[39;49;00m(matching_sources) > [94m1[39;49;00m:[90m[39;49;00m
            source_class_names_str = [33m"[39;49;00m[33m, [39;49;00m[33m"[39;49;00m.join([source.[91m__name__[39;49;00m [94mfor[39;49;00m source [95min[39;49;00m matching_sources])[90m[39;49;00m
            warnings.warn([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mThe specified dataset source can be interpreted in multiple ways:[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00msource_class_names_str[33m}[39;49;00m[33m. MLflow will assume that this is a[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00mmatching_sources[-[94m1[39;49;00m].[91m__name__[39;49;00m[33m}[39;49;00m[33m source.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                stacklevel=[94m2[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        [94mfor[39;49;00m matching_source [95min[39;49;00m [96mreversed[39;49;00m(matching_sources):[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mreturn[39;49;00m matching_source._resolve(raw_source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mEncountered an unexpected error while using [39;49;00m[33m{[39;49;00mmatching_source.[91m__name__[39;49;00m[33m}[39;49;00m[33m to[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m resolve source information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mraise[39;49;00m MlflowException([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33mCould not find a source information resolver for the specified[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m dataset source: [39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       mlflow.exceptions.MlflowException: Could not find a source information resolver for the specified dataset source: /tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0/temp.csv.[0m

candidate_sources = None
matching_sources = []
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0/temp.csv')
self       = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
source     = <class 'mlflow.data.uc_volume_dataset_source.UCVolumeDatasetSource'>

[1m[31mmlflow/data/dataset_source_registry.py[0m:94: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:01:05 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________ test_from_numpy_features_and_targets _____________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_from_numpy_features_and_targets[39;49;00m(tmp_path):[90m[39;49;00m
        features = np.array([[[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m], [[94m3[39;49;00m, [94m2[39;49;00m, [94m1[39;49;00m], [[94m2[39;49;00m, [94m3[39;49;00m, [94m1[39;49;00m]])[90m[39;49;00m
        targets = np.array([[94m4[39;49;00m, [94m5[39;49;00m, [94m6[39;49;00m])[90m[39;49;00m
        path = tmp_path / [33m"[39;49;00m[33mtemp.csv[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        pd.DataFrame(features).to_csv(path)[90m[39;49;00m
>       mlflow_ds = mlflow.data.from_numpy(features, targets=targets, source=path)[90m[39;49;00m
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

features   = array([[1, 2, 3],
       [3, 2, 1],
       [2, 3, 1]])
path       = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0/temp.csv')
targets    = array([4, 5, 6])
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0')

[1m[31mtests/data/test_numpy_dataset.py[0m:230: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/data/numpy_dataset.py[0m:215: in from_numpy
    [0mresolved_source = resolve_dataset_source([90m[39;49;00m
        CodeDatasetSource = <class 'mlflow.data.code_dataset_source.CodeDatasetSource'>
        digest     = None
        features   = array([[1, 2, 3],
       [3, 2, 1],
       [2, 3, 1]])
        name       = None
        registry   = <module 'mlflow.tracking.context.registry' from '/testbed/mlflow/tracking/context/registry.py'>
        resolve_dataset_source = <function resolve_dataset_source at 0x74cbc067d620>
        source     = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0/temp.csv')
        targets    = array([4, 5, 6])
[1m[31mmlflow/data/dataset_source_registry.py[0m:148: in resolve_dataset_source
    [0m[94mreturn[39;49;00m _dataset_source_registry.resolve([90m[39;49;00m
        candidate_sources = None
        raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0/temp.csv')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0/temp.csv')
candidate_sources = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m, raw_source: Any, candidate_sources: [96mlist[39;49;00m[DatasetSource] | [94mNone[39;49;00m = [94mNone[39;49;00m[90m[39;49;00m
    ) -> DatasetSource:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Resolves a raw source object, such as a string URI, to a DatasetSource for use with[39;49;00m
    [33m    MLflow Tracking.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data" or a[39;49;00m
    [33m            HuggingFace :py:class:`datasets.Dataset` object.[39;49;00m
    [33m        candidate_sources: A list of DatasetSource classes to consider as potential sources[39;49;00m
    [33m            when resolving the raw source. Subclasses of the specified candidate sources are[39;49;00m
    [33m            also considered. If unspecified, all registered sources are considered.[39;49;00m
    [33m[39;49;00m
    [33m    Raises:[39;49;00m
    [33m        MlflowException: If no DatasetSource class can resolve the raw source.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        The resolved DatasetSource.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        matching_sources = [][90m[39;49;00m
        [94mfor[39;49;00m source [95min[39;49;00m [96mself[39;49;00m.sources:[90m[39;49;00m
            [94mif[39;49;00m candidate_sources [95mand[39;49;00m [95mnot[39;49;00m [96many[39;49;00m([90m[39;49;00m
                [96missubclass[39;49;00m(source, candidate_src) [94mfor[39;49;00m candidate_src [95min[39;49;00m candidate_sources[90m[39;49;00m
            ):[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mif[39;49;00m source._can_resolve(raw_source):[90m[39;49;00m
                    matching_sources.append(source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mFailed to determine whether [39;49;00m[33m{[39;49;00msource.[91m__name__[39;49;00m[33m}[39;49;00m[33m can resolve source[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [96mlen[39;49;00m(matching_sources) > [94m1[39;49;00m:[90m[39;49;00m
            source_class_names_str = [33m"[39;49;00m[33m, [39;49;00m[33m"[39;49;00m.join([source.[91m__name__[39;49;00m [94mfor[39;49;00m source [95min[39;49;00m matching_sources])[90m[39;49;00m
            warnings.warn([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mThe specified dataset source can be interpreted in multiple ways:[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00msource_class_names_str[33m}[39;49;00m[33m. MLflow will assume that this is a[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00mmatching_sources[-[94m1[39;49;00m].[91m__name__[39;49;00m[33m}[39;49;00m[33m source.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                stacklevel=[94m2[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        [94mfor[39;49;00m matching_source [95min[39;49;00m [96mreversed[39;49;00m(matching_sources):[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mreturn[39;49;00m matching_source._resolve(raw_source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mEncountered an unexpected error while using [39;49;00m[33m{[39;49;00mmatching_source.[91m__name__[39;49;00m[33m}[39;49;00m[33m to[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m resolve source information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mraise[39;49;00m MlflowException([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33mCould not find a source information resolver for the specified[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m dataset source: [39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       mlflow.exceptions.MlflowException: Could not find a source information resolver for the specified dataset source: /tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0/temp.csv.[0m

candidate_sources = None
matching_sources = []
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0/temp.csv')
self       = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
source     = <class 'mlflow.data.uc_volume_dataset_source.UCVolumeDatasetSource'>

[1m[31mmlflow/data/dataset_source_registry.py[0m:94: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:01:05 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m________________________ test_from_pandas_with_targets _________________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_from_pandas_with_targets[39;49;00m(tmp_path):[90m[39;49;00m
        df = pd.DataFrame([[[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m], [[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m]], columns=[[33m"[39;49;00m[33ma[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mb[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mc[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
        path = tmp_path / [33m"[39;49;00m[33mtemp.csv[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        df.to_csv(path)[90m[39;49;00m
>       dataset = mlflow.data.from_pandas(df, targets=[33m"[39;49;00m[33mc[39;49;00m[33m"[39;49;00m, source=path)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

df         =    a  b  c
0  1  2  3
1  1  2  3
path       = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0/temp.csv')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0')

[1m[31mtests/data/test_pandas_dataset.py[0m:152: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/data/pandas_dataset.py[0m:218: in from_pandas
    [0mresolved_source = resolve_dataset_source([90m[39;49;00m
        CodeDatasetSource = <class 'mlflow.data.code_dataset_source.CodeDatasetSource'>
        df         =    a  b  c
0  1  2  3
1  1  2  3
        digest     = None
        name       = None
        predictions = None
        registry   = <module 'mlflow.tracking.context.registry' from '/testbed/mlflow/tracking/context/registry.py'>
        resolve_dataset_source = <function resolve_dataset_source at 0x74cbc067d620>
        source     = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0/temp.csv')
        targets    = 'c'
[1m[31mmlflow/data/dataset_source_registry.py[0m:148: in resolve_dataset_source
    [0m[94mreturn[39;49;00m _dataset_source_registry.resolve([90m[39;49;00m
        candidate_sources = None
        raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0/temp.csv')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0/temp.csv')
candidate_sources = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m, raw_source: Any, candidate_sources: [96mlist[39;49;00m[DatasetSource] | [94mNone[39;49;00m = [94mNone[39;49;00m[90m[39;49;00m
    ) -> DatasetSource:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Resolves a raw source object, such as a string URI, to a DatasetSource for use with[39;49;00m
    [33m    MLflow Tracking.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data" or a[39;49;00m
    [33m            HuggingFace :py:class:`datasets.Dataset` object.[39;49;00m
    [33m        candidate_sources: A list of DatasetSource classes to consider as potential sources[39;49;00m
    [33m            when resolving the raw source. Subclasses of the specified candidate sources are[39;49;00m
    [33m            also considered. If unspecified, all registered sources are considered.[39;49;00m
    [33m[39;49;00m
    [33m    Raises:[39;49;00m
    [33m        MlflowException: If no DatasetSource class can resolve the raw source.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        The resolved DatasetSource.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        matching_sources = [][90m[39;49;00m
        [94mfor[39;49;00m source [95min[39;49;00m [96mself[39;49;00m.sources:[90m[39;49;00m
            [94mif[39;49;00m candidate_sources [95mand[39;49;00m [95mnot[39;49;00m [96many[39;49;00m([90m[39;49;00m
                [96missubclass[39;49;00m(source, candidate_src) [94mfor[39;49;00m candidate_src [95min[39;49;00m candidate_sources[90m[39;49;00m
            ):[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mif[39;49;00m source._can_resolve(raw_source):[90m[39;49;00m
                    matching_sources.append(source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mFailed to determine whether [39;49;00m[33m{[39;49;00msource.[91m__name__[39;49;00m[33m}[39;49;00m[33m can resolve source[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [96mlen[39;49;00m(matching_sources) > [94m1[39;49;00m:[90m[39;49;00m
            source_class_names_str = [33m"[39;49;00m[33m, [39;49;00m[33m"[39;49;00m.join([source.[91m__name__[39;49;00m [94mfor[39;49;00m source [95min[39;49;00m matching_sources])[90m[39;49;00m
            warnings.warn([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mThe specified dataset source can be interpreted in multiple ways:[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00msource_class_names_str[33m}[39;49;00m[33m. MLflow will assume that this is a[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00mmatching_sources[-[94m1[39;49;00m].[91m__name__[39;49;00m[33m}[39;49;00m[33m source.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                stacklevel=[94m2[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        [94mfor[39;49;00m matching_source [95min[39;49;00m [96mreversed[39;49;00m(matching_sources):[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mreturn[39;49;00m matching_source._resolve(raw_source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mEncountered an unexpected error while using [39;49;00m[33m{[39;49;00mmatching_source.[91m__name__[39;49;00m[33m}[39;49;00m[33m to[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m resolve source information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mraise[39;49;00m MlflowException([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33mCould not find a source information resolver for the specified[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m dataset source: [39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       mlflow.exceptions.MlflowException: Could not find a source information resolver for the specified dataset source: /tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0/temp.csv.[0m

candidate_sources = None
matching_sources = []
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0/temp.csv')
self       = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
source     = <class 'mlflow.data.uc_volume_dataset_source.UCVolumeDatasetSource'>

[1m[31mmlflow/data/dataset_source_registry.py[0m:94: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:01:05 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_from_pandas_file_system_datasource ____________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_from_pandas_file_system_datasource[39;49;00m(tmp_path):[90m[39;49;00m
        df = pd.DataFrame([[[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m], [[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m]], columns=[[33m"[39;49;00m[33ma[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mb[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mc[39;49;00m[33m"[39;49;00m])[90m[39;49;00m
        path = tmp_path / [33m"[39;49;00m[33mtemp.csv[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        df.to_csv(path)[90m[39;49;00m
>       mlflow_df = mlflow.data.from_pandas(df, source=path)[90m[39;49;00m
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

df         =    a  b  c
0  1  2  3
1  1  2  3
path       = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0/temp.csv')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0')

[1m[31mtests/data/test_pandas_dataset.py[0m:163: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/data/pandas_dataset.py[0m:218: in from_pandas
    [0mresolved_source = resolve_dataset_source([90m[39;49;00m
        CodeDatasetSource = <class 'mlflow.data.code_dataset_source.CodeDatasetSource'>
        df         =    a  b  c
0  1  2  3
1  1  2  3
        digest     = None
        name       = None
        predictions = None
        registry   = <module 'mlflow.tracking.context.registry' from '/testbed/mlflow/tracking/context/registry.py'>
        resolve_dataset_source = <function resolve_dataset_source at 0x74cbc067d620>
        source     = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0/temp.csv')
        targets    = None
[1m[31mmlflow/data/dataset_source_registry.py[0m:148: in resolve_dataset_source
    [0m[94mreturn[39;49;00m _dataset_source_registry.resolve([90m[39;49;00m
        candidate_sources = None
        raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0/temp.csv')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0/temp.csv')
candidate_sources = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m, raw_source: Any, candidate_sources: [96mlist[39;49;00m[DatasetSource] | [94mNone[39;49;00m = [94mNone[39;49;00m[90m[39;49;00m
    ) -> DatasetSource:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Resolves a raw source object, such as a string URI, to a DatasetSource for use with[39;49;00m
    [33m    MLflow Tracking.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data" or a[39;49;00m
    [33m            HuggingFace :py:class:`datasets.Dataset` object.[39;49;00m
    [33m        candidate_sources: A list of DatasetSource classes to consider as potential sources[39;49;00m
    [33m            when resolving the raw source. Subclasses of the specified candidate sources are[39;49;00m
    [33m            also considered. If unspecified, all registered sources are considered.[39;49;00m
    [33m[39;49;00m
    [33m    Raises:[39;49;00m
    [33m        MlflowException: If no DatasetSource class can resolve the raw source.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        The resolved DatasetSource.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        matching_sources = [][90m[39;49;00m
        [94mfor[39;49;00m source [95min[39;49;00m [96mself[39;49;00m.sources:[90m[39;49;00m
            [94mif[39;49;00m candidate_sources [95mand[39;49;00m [95mnot[39;49;00m [96many[39;49;00m([90m[39;49;00m
                [96missubclass[39;49;00m(source, candidate_src) [94mfor[39;49;00m candidate_src [95min[39;49;00m candidate_sources[90m[39;49;00m
            ):[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mif[39;49;00m source._can_resolve(raw_source):[90m[39;49;00m
                    matching_sources.append(source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mFailed to determine whether [39;49;00m[33m{[39;49;00msource.[91m__name__[39;49;00m[33m}[39;49;00m[33m can resolve source[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [96mlen[39;49;00m(matching_sources) > [94m1[39;49;00m:[90m[39;49;00m
            source_class_names_str = [33m"[39;49;00m[33m, [39;49;00m[33m"[39;49;00m.join([source.[91m__name__[39;49;00m [94mfor[39;49;00m source [95min[39;49;00m matching_sources])[90m[39;49;00m
            warnings.warn([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mThe specified dataset source can be interpreted in multiple ways:[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00msource_class_names_str[33m}[39;49;00m[33m. MLflow will assume that this is a[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00mmatching_sources[-[94m1[39;49;00m].[91m__name__[39;49;00m[33m}[39;49;00m[33m source.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                stacklevel=[94m2[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        [94mfor[39;49;00m matching_source [95min[39;49;00m [96mreversed[39;49;00m(matching_sources):[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mreturn[39;49;00m matching_source._resolve(raw_source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mEncountered an unexpected error while using [39;49;00m[33m{[39;49;00mmatching_source.[91m__name__[39;49;00m[33m}[39;49;00m[33m to[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m resolve source information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mraise[39;49;00m MlflowException([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33mCould not find a source information resolver for the specified[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m dataset source: [39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       mlflow.exceptions.MlflowException: Could not find a source information resolver for the specified dataset source: /tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0/temp.csv.[0m

candidate_sources = None
matching_sources = []
raw_source = PosixPath('/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0/temp.csv')
self       = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x74cbc06842d0>
source     = <class 'mlflow.data.uc_volume_dataset_source.UCVolumeDatasetSource'>

[1m[31mmlflow/data/dataset_source_registry.py[0m:94: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:01:05 INFO mlflow.tracking.fluent: Active model is cleared
[33m=============================== warnings summary ===============================[0m
tests/data/test_numpy_dataset.py::test_from_numpy_features_only
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: Failed to determine whether UCVolumeDatasetSource can resolve source information for '/tmp/pytest-of-root/pytest-1/test_from_numpy_features_only0/temp.csv'. Exception: 
    return _dataset_source_registry.resolve(

tests/data/test_numpy_dataset.py::test_from_numpy_features_and_targets
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: Failed to determine whether UCVolumeDatasetSource can resolve source information for '/tmp/pytest-of-root/pytest-1/test_from_numpy_features_and_t0/temp.csv'. Exception: 
    return _dataset_source_registry.resolve(

tests/data/test_pandas_dataset.py::test_conversion_to_json
  /testbed/mlflow/types/utils.py:452: UserWarning: Hint: Inferred schema contains integer column(s). Integer columns in Python cannot represent missing values. If your input data contains missing values at inference time, it will be encoded as floats and will cause a schema enforcement error. The best way to avoid this problem is to infer the model schema based on a realistic data sample (training dataset) that includes missing values. Alternatively, you can declare integer columns as doubles (float64) whenever these columns may have missing values. See `Handling Integers With Missing Values <https://www.mlflow.org/docs/latest/models.html#handling-integers-with-missing-values>`_ for more details.
    warnings.warn(

tests/data/test_pandas_dataset.py::test_from_pandas_with_targets
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: Failed to determine whether UCVolumeDatasetSource can resolve source information for '/tmp/pytest-of-root/pytest-1/test_from_pandas_with_targets0/temp.csv'. Exception: 
    return _dataset_source_registry.resolve(

tests/data/test_pandas_dataset.py::test_from_pandas_file_system_datasource
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: Failed to determine whether UCVolumeDatasetSource can resolve source information for '/tmp/pytest-of-root/pytest-1/test_from_pandas_file_system_d0/temp.csv'. Exception: 
    return _dataset_source_registry.resolve(

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
0.02s call     tests/data/test_numpy_dataset.py::test_from_numpy_no_source_specified

(9 durations < 0.005s hidden.  Use -vv to show these durations.)
========================= command to run failed tests ==========================
pytest 'tests/data/test_numpy_dataset.py::test_from_numpy_features_only' 'tests/data/test_numpy_dataset.py::test_from_numpy_features_and_targets' 'tests/data/test_pandas_dataset.py::test_from_pandas_with_targets' 'tests/data/test_pandas_dataset.py::test_from_pandas_file_system_datasource'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_numpy_dataset.py::[1mtest_from_numpy_features_only[0m - mlflow.exceptions.MlflowException: Could not find a source information reso...
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_numpy_dataset.py::[1mtest_from_numpy_features_and_targets[0m - mlflow.exceptions.MlflowException: Could not find a source information reso...
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_pandas_dataset.py::[1mtest_from_pandas_with_targets[0m - mlflow.exceptions.MlflowException: Could not find a source information reso...
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_pandas_dataset.py::[1mtest_from_pandas_file_system_datasource[0m - mlflow.exceptions.MlflowException: Could not find a source information reso...
[31mERROR[0m tests/data/test_pandas_dataset.py::[1mtest_from_pandas_spark_datasource[0m - ModuleNotFoundError: No module named 'pyspark'
[31mERROR[0m tests/data/test_pandas_dataset.py::[1mtest_from_pandas_delta_datasource[0m - ModuleNotFoundError: No module named 'pyspark'
[31m============== [31m[1m4 failed[0m, [32m24 passed[0m, [33m5 warnings[0m, [31m[1m2 errors[0m[31m in 0.30s[0m[31m ==============[0m
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' mlflow/data/dataset.py; sed -n '55,130p' mlflow/data/dataset_source.py; git diff --check; git diff -- mlflow/data/dataset.py mlflow/data/dataset_source.py"
```

退出码：`0`

输出：
```
import json
from abc import abstractmethod
from typing import Any

from mlflow.data.dataset_source import DatasetSource
from mlflow.entities import Dataset as DatasetEntity


class Dataset:
    """
    Represents a dataset for use with MLflow Tracking, including the name, digest (hash),
    schema, and profile of the dataset as well as source information (e.g. the S3 bucket or
    managed Delta table from which the dataset was derived). Most datasets expose features
    and targets for training and evaluation as well.
    """

    def __init__(
        self, source: DatasetSource, name: str | None = None, digest: str | None = None
    ):
        """Initialize a dataset with its source and optional identity metadata.

        If ``digest`` is falsy (including None or an empty string), compute it with the subclass's
        ``_compute_digest()``. Subclasses should call this constructor only after initializing the
        state needed for that computation. If ``name`` is None, ``name`` falls back to ``"dataset"``.
        """
        self._source = source
        self._name = name if name is not None else "dataset"
        self._digest = digest or self._compute_digest()











    @abstractmethod
    def _compute_digest(self) -> str:
        """Computes a digest for the dataset. Called if the user doesn't supply
        a digest when constructing the dataset.

        Returns:
            A string digest for the dataset. We recommend a maximum digest length
            of 10 characters with an ideal length of 8 characters.

        """

    def to_dict(self) -> dict[str, str]:
        """Return the base dataset configuration.

        The source is serialized as JSON so that the mapping can be passed directly to MLflow's
        tracking entities.
        """
        return {
            "name": self.name,
            "digest": self.digest,
            "source": self.source.to_json(),
            "source_type": self._get_source_type(),
        }

















    def to_json(self) -> str:
        """
        Obtains a JSON string representation of the :py:class:`Dataset
        <mlflow.data.dataset.Dataset>`.

        Returns:
            A JSON string representation of the :py:class:`Dataset <mlflow.data.dataset.Dataset>`.
        """

        return json.dumps(self.to_dict())

    def _get_source_type(self) -> str:
        """Returns the type of the dataset's underlying source."""

        return self.source._get_source_type()

    @property
    def digest(self) -> str:
        """The compact fingerprint stored when the dataset was initialized."""
        return self._digest

    @property
    def name(self) -> str:
        """The dataset name, or ``"dataset"`` when no name was provided."""
        return self._name


















    @property
    def source(self) -> DatasetSource:
        """
        Information about the dataset's source, represented as an instance of
        :py:class:`DatasetSource <mlflow.data.dataset_source.DatasetSource>`. For example, this
        may be the S3 location or the name of the managed Delta Table from which the dataset
        was derived.
        """
        return self._source

    @property
    @abstractmethod
    def profile(self) -> Any | None:
        """
        Optional summary statistics for the dataset, such as the number of rows in a table, the
        mean / median / std of each table column, etc.
        """

    @property
    @abstractmethod
    def schema(self) -> Any | None:
        """
        Optional dataset schema, such as an instance of :py:class:`mlflow.types.Schema` representing
        the features and targets of the dataset.
        """

    def _to_mlflow_entity(self) -> DatasetEntity:
        """
        Returns:
            A `mlflow.entities.Dataset` instance representing the dataset.
        """
        dataset_dict = self.to_dict()
        return DatasetEntity(
            name=dataset_dict["name"],
            digest=dataset_dict["digest"],
            source_type=dataset_dict["source_type"],
            source=dataset_dict["source"],
            schema=dataset_dict.get("schema"),
            profile=dataset_dict.get("profile"),
        )
        string URI like "s3://mybucket/path/to/iris/data" or a delta table identifier
        like "my.delta.table@2".

        Args:
            raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data".

        Returns:
            A DatasetSource instance derived from the raw_source.

        """

    @abstractmethod
    def to_dict(self) -> dict[str, Any]:
        """Obtains a JSON-compatible dictionary representation of the DatasetSource.

        Returns:
            A JSON-compatible dictionary representation of the DatasetSource.

        """

    def to_json(self) -> str:
        """Serialize this source's ``to_dict()`` representation as a JSON string."""
        return json.dumps(self.to_dict())












    @classmethod
    @abstractmethod
    def from_dict(cls, source_dict: dict[Any, Any]) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a dictionary representation.

        Args:
            source_dict: A dictionary representation of the DatasetSource.

        Returns:
            A DatasetSource instance.

        """

    @classmethod
    def from_json(cls, source_json: str) -> "DatasetSource":
        """Constructs an instance of the DatasetSource from a JSON string representation.

        Args:
            source_json: A JSON string representation of the DatasetSource.

        Returns:
            A DatasetSource instance.

        """
        return cls.from_dict(json.loads(source_json))
diff --git a/mlflow/data/dataset.py b/mlflow/data/dataset.py
index a69ce04..a53bb19 100644
--- a/mlflow/data/dataset.py
+++ b/mlflow/data/dataset.py
@@ -14,6 +14,19 @@ class Dataset:
     and targets for training and evaluation as well.
     """
 
+    def __init__(
+        self, source: DatasetSource, name: str | None = None, digest: str | None = None
+    ):
+        """Initialize a dataset with its source and optional identity metadata.
+
+        If ``digest`` is falsy (including None or an empty string), compute it with the subclass's
+        ``_compute_digest()``. Subclasses should call this constructor only after initializing the
+        state needed for that computation. If ``name`` is None, ``name`` falls back to ``"dataset"``.
+        """
+        self._source = source
+        self._name = name if name is not None else "dataset"
+        self._digest = digest or self._compute_digest()
+
 
 
 
@@ -35,6 +48,19 @@ class Dataset:
 
         """
 
+    def to_dict(self) -> dict[str, str]:
+        """Return the base dataset configuration.
+
+        The source is serialized as JSON so that the mapping can be passed directly to MLflow's
+        tracking entities.
+        """
+        return {
+            "name": self.name,
+            "digest": self.digest,
+            "source": self.source.to_json(),
+            "source_type": self._get_source_type(),
+        }
+
 
 
 
@@ -67,6 +93,16 @@ class Dataset:
 
         return self.source._get_source_type()
 
+    @property
+    def digest(self) -> str:
+        """The compact fingerprint stored when the dataset was initialized."""
+        return self._digest
+
+    @property
+    def name(self) -> str:
+        """The dataset name, or ``"dataset"`` when no name was provided."""
+        return self._name
+
 
 
 
@@ -123,4 +159,4 @@ class Dataset:
             source=dataset_dict["source"],
             schema=dataset_dict.get("schema"),
             profile=dataset_dict.get("profile"),
-        )
\ No newline at end of file
+        )
diff --git a/mlflow/data/dataset_source.py b/mlflow/data/dataset_source.py
index 04224ba..780f488 100644
--- a/mlflow/data/dataset_source.py
+++ b/mlflow/data/dataset_source.py
@@ -72,6 +72,10 @@ class DatasetSource:
 
         """
 
+    def to_json(self) -> str:
+        """Serialize this source's ``to_dict()`` representation as a JSON string."""
+        return json.dumps(self.to_dict())
+
 
 
 
@@ -107,4 +111,4 @@ class DatasetSource:
             A DatasetSource instance.
 
         """
-        return cls.from_dict(json.loads(source_json))
\ No newline at end of file
+        return cls.from_dict(json.loads(source_json))
```

## 原始行 37 · command_execution

命令：
```
/bin/bash -lc 'black --version'
```

退出码：`0`

输出：
```
black, 25.11.0 (compiled: yes)
Python (CPython) 3.11.14
```

## 原始行 40 · command_execution

命令：
```
/bin/bash -lc 'black mlflow/data/dataset.py mlflow/data/dataset_source.py && git diff --check'
```

退出码：`0`

输出：
```
reformatted mlflow/data/dataset_source.py
reformatted mlflow/data/dataset.py

All done! ✨ 🍰 ✨
2 files reformatted.
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from tests.resources.data.dataset import SampleDataset
from tests.resources.data.dataset_source import SampleDatasetSource

source = SampleDatasetSource('test:/snapshot')
dataset = SampleDataset([1, 2, 3], source, name='', digest='')
initial_digest = dataset.digest
assert initial_digest == dataset._compute_digest()
assert dataset.name == ''
dataset._data_list.append(4)
assert dataset.digest == initial_digest
provided = SampleDataset([1], source, digest='given')
assert provided.digest == 'given'
assert provided.to_dict() == {
    **provided.to_dict(),
    'name': 'dataset',
    'digest': 'given',
    'source': source.to_json(),
    'source_type': 'test',
}
print('edge cases passed')
PY
python -m pytest tests/data/test_dataset.py tests/data/test_dataset_source.py::test_conversion_to_json_and_back -q
git status --short
git diff --stat
git diff --check"
```

退出码：`0`

输出：
```
edge cases passed
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 4 items

tests/data/test_dataset.py [32m.[0m[32m.[0m[32m.[0m[32m                                           [ 75%][0m
tests/data/test_dataset_source.py [32m.[0m[32m                                      [100%][0m

============================= slowest 10 durations =============================

(10 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m============================== [32m[1m4 passed[0m[32m in 0.02s[0m[32m ===============================[0m
 M mlflow/data/dataset.py
 M mlflow/data/dataset_source.py
 mlflow/data/dataset.py        | 71 +++++++++++++++++++------------------------
 mlflow/data/dataset_source.py | 15 +++------
 2 files changed, 36 insertions(+), 50 deletions(-)
```

## 原始行 45 · agent_message

```
The implementation now passes the focused interface tests and explicit edge checks: a falsy digest is computed once, a supplied digest is retained, an empty name remains valid while `None` defaults, and later dataset mutation does not change the stored fingerprint. Representative NumPy/Pandas identity and serialization tests also passed; their unrelated filesystem-source cases remain blocked by masked resolver code and missing PySpark.
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "git diff -- mlflow/data/dataset.py mlflow/data/dataset_source.py && python -m pytest tests/data/test_numpy_dataset.py tests/data/test_pandas_dataset.py -q -k 'not file and not spark and not delta and not targets'"
```

退出码：`1`

输出：
```
diff --git a/mlflow/data/dataset.py b/mlflow/data/dataset.py
index a69ce04..f1f2f35 100644
--- a/mlflow/data/dataset.py
+++ b/mlflow/data/dataset.py
@@ -14,15 +14,18 @@ class Dataset:
     and targets for training and evaluation as well.
     """
 
-
-
-
-
-
-
-
-
-
+    def __init__(
+        self, source: DatasetSource, name: str | None = None, digest: str | None = None
+    ):
+        """Initialize a dataset with its source and optional identity metadata.
+
+        If ``digest`` is falsy (including None or an empty string), compute it with the subclass's
+        ``_compute_digest()``. Subclasses should call this constructor only after initializing the
+        state needed for that computation. If ``name`` is None, ``name`` falls back to ``"dataset"``.
+        """
+        self._source = source
+        self._name = name if name is not None else "dataset"
+        self._digest = digest or self._compute_digest()
 
     @abstractmethod
     def _compute_digest(self) -> str:
@@ -35,21 +38,18 @@ class Dataset:
 
         """
 
+    def to_dict(self) -> dict[str, str]:
+        """Return the base dataset configuration.
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+        The source is serialized as JSON so that the mapping can be passed directly to MLflow's
+        tracking entities.
+        """
+        return {
+            "name": self.name,
+            "digest": self.digest,
+            "source": self.source.to_json(),
+            "source_type": self._get_source_type(),
+        }
 
     def to_json(self) -> str:
         """
@@ -67,22 +67,15 @@ class Dataset:
 
         return self.source._get_source_type()
 
+    @property
+    def digest(self) -> str:
+        """The compact fingerprint stored when the dataset was initialized."""
+        return self._digest
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+    @property
+    def name(self) -> str:
+        """The dataset name, or ``"dataset"`` when no name was provided."""
+        return self._name
 
     @property
     def source(self) -> DatasetSource:
@@ -123,4 +116,4 @@ class Dataset:
             source=dataset_dict["source"],
             schema=dataset_dict.get("schema"),
             profile=dataset_dict.get("profile"),
-        )
\ No newline at end of file
+        )
diff --git a/mlflow/data/dataset_source.py b/mlflow/data/dataset_source.py
index 04224ba..9cd4f5a 100644
--- a/mlflow/data/dataset_source.py
+++ b/mlflow/data/dataset_source.py
@@ -72,16 +72,9 @@ class DatasetSource:
 
         """
 
-
-
-
-
-
-
-
-
-
-
+    def to_json(self) -> str:
+        """Serialize this source's ``to_dict()`` representation as a JSON string."""
+        return json.dumps(self.to_dict())
 
     @classmethod
     @abstractmethod
@@ -107,4 +100,4 @@ class DatasetSource:
             A DatasetSource instance.
 
         """
-        return cls.from_dict(json.loads(source_json))
\ No newline at end of file
+        return cls.from_dict(json.loads(source_json))
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 30 items / 14 deselected / 16 selected

tests/data/test_numpy_dataset.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[31m                                 [ 43%][0m
tests/data/test_pandas_dataset.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                              [100%][0m

=================================== FAILURES ===================================
[31m[1m________________________ test_from_numpy_features_only _________________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_from_numpy_features_only[39;49;00m(tmp_path):[90m[39;49;00m
        features = np.array([[94m1[39;49;00m, [94m2[39;49;00m, [94m3[39;49;00m])[90m[39;49;00m
        path = tmp_path / [33m"[39;49;00m[33mtemp.csv[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        pd.DataFrame(features).to_csv(path)[90m[39;49;00m
>       mlflow_features = mlflow.data.from_numpy(features, source=path)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

features   = array([1, 2, 3])
path       = PosixPath('/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0/temp.csv')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0')

[1m[31mtests/data/test_numpy_dataset.py[0m:211: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/data/numpy_dataset.py[0m:215: in from_numpy
    [0mresolved_source = resolve_dataset_source([90m[39;49;00m
        CodeDatasetSource = <class 'mlflow.data.code_dataset_source.CodeDatasetSource'>
        digest     = None
        features   = array([1, 2, 3])
        name       = None
        registry   = <module 'mlflow.tracking.context.registry' from '/testbed/mlflow/tracking/context/registry.py'>
        resolve_dataset_source = <function resolve_dataset_source at 0x7148f3859620>
        source     = PosixPath('/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0/temp.csv')
        targets    = None
[1m[31mmlflow/data/dataset_source_registry.py[0m:148: in resolve_dataset_source
    [0m[94mreturn[39;49;00m _dataset_source_registry.resolve([90m[39;49;00m
        candidate_sources = None
        raw_source = PosixPath('/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0/temp.csv')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x7148f3860090>
raw_source = PosixPath('/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0/temp.csv')
candidate_sources = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m, raw_source: Any, candidate_sources: [96mlist[39;49;00m[DatasetSource] | [94mNone[39;49;00m = [94mNone[39;49;00m[90m[39;49;00m
    ) -> DatasetSource:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Resolves a raw source object, such as a string URI, to a DatasetSource for use with[39;49;00m
    [33m    MLflow Tracking.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        raw_source: The raw source, e.g. a string like "s3://mybucket/path/to/iris/data" or a[39;49;00m
    [33m            HuggingFace :py:class:`datasets.Dataset` object.[39;49;00m
    [33m        candidate_sources: A list of DatasetSource classes to consider as potential sources[39;49;00m
    [33m            when resolving the raw source. Subclasses of the specified candidate sources are[39;49;00m
    [33m            also considered. If unspecified, all registered sources are considered.[39;49;00m
    [33m[39;49;00m
    [33m    Raises:[39;49;00m
    [33m        MlflowException: If no DatasetSource class can resolve the raw source.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        The resolved DatasetSource.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        matching_sources = [][90m[39;49;00m
        [94mfor[39;49;00m source [95min[39;49;00m [96mself[39;49;00m.sources:[90m[39;49;00m
            [94mif[39;49;00m candidate_sources [95mand[39;49;00m [95mnot[39;49;00m [96many[39;49;00m([90m[39;49;00m
                [96missubclass[39;49;00m(source, candidate_src) [94mfor[39;49;00m candidate_src [95min[39;49;00m candidate_sources[90m[39;49;00m
            ):[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mif[39;49;00m source._can_resolve(raw_source):[90m[39;49;00m
                    matching_sources.append(source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mFailed to determine whether [39;49;00m[33m{[39;49;00msource.[91m__name__[39;49;00m[33m}[39;49;00m[33m can resolve source[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [96mlen[39;49;00m(matching_sources) > [94m1[39;49;00m:[90m[39;49;00m
            source_class_names_str = [33m"[39;49;00m[33m, [39;49;00m[33m"[39;49;00m.join([source.[91m__name__[39;49;00m [94mfor[39;49;00m source [95min[39;49;00m matching_sources])[90m[39;49;00m
            warnings.warn([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mThe specified dataset source can be interpreted in multiple ways:[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00msource_class_names_str[33m}[39;49;00m[33m. MLflow will assume that this is a[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m [39;49;00m[33m{[39;49;00mmatching_sources[-[94m1[39;49;00m].[91m__name__[39;49;00m[33m}[39;49;00m[33m source.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                stacklevel=[94m2[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        [94mfor[39;49;00m matching_source [95min[39;49;00m [96mreversed[39;49;00m(matching_sources):[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mreturn[39;49;00m matching_source._resolve(raw_source)[90m[39;49;00m
            [94mexcept[39;49;00m [96mException[39;49;00m [94mas[39;49;00m e:[90m[39;49;00m
                warnings.warn([90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33mEncountered an unexpected error while using [39;49;00m[33m{[39;49;00mmatching_source.[91m__name__[39;49;00m[33m}[39;49;00m[33m to[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33mf[39;49;00m[33m"[39;49;00m[33m resolve source information for [39;49;00m[33m'[39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m'[39;49;00m[33m. Exception: [39;49;00m[33m{[39;49;00me[33m}[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    stacklevel=[94m2[39;49;00m,[90m[39;49;00m
                )[90m[39;49;00m
                [94mcontinue[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mraise[39;49;00m MlflowException([90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33mCould not find a source information resolver for the specified[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            [33mf[39;49;00m[33m"[39;49;00m[33m dataset source: [39;49;00m[33m{[39;49;00mraw_source[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       mlflow.exceptions.MlflowException: Could not find a source information resolver for the specified dataset source: /tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0/temp.csv.[0m

candidate_sources = None
matching_sources = []
raw_source = PosixPath('/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0/temp.csv')
self       = <mlflow.data.dataset_source_registry.DatasetSourceRegistry object at 0x7148f3860090>
source     = <class 'mlflow.data.uc_volume_dataset_source.UCVolumeDatasetSource'>

[1m[31mmlflow/data/dataset_source_registry.py[0m:94: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:01:33 INFO mlflow.tracking.fluent: Active model is cleared
[33m=============================== warnings summary ===============================[0m
tests/data/test_numpy_dataset.py::test_from_numpy_features_only
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: Failed to determine whether UCVolumeDatasetSource can resolve source information for '/tmp/pytest-of-root/pytest-3/test_from_numpy_features_only0/temp.csv'. Exception: 
    return _dataset_source_registry.resolve(

tests/data/test_pandas_dataset.py::test_conversion_to_json
  /testbed/mlflow/types/utils.py:452: UserWarning: Hint: Inferred schema contains integer column(s). Integer columns in Python cannot represent missing values. If your input data contains missing values at inference time, it will be encoded as floats and will cause a schema enforcement error. The best way to avoid this problem is to infer the model schema based on a realistic data sample (training dataset) that includes missing values. Alternatively, you can declare integer columns as doubles (float64) whenever these columns may have missing values. See `Handling Integers With Missing Values <https://www.mlflow.org/docs/latest/models.html#handling-integers-with-missing-values>`_ for more details.
    warnings.warn(

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
0.02s call     tests/data/test_numpy_dataset.py::test_from_numpy_no_source_specified

(9 durations < 0.005s hidden.  Use -vv to show these durations.)
========================= command to run failed tests ==========================
pytest 'tests/data/test_numpy_dataset.py::test_from_numpy_features_only'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 22.7/33.7 GB | DISK 797.6/915.7 GB[0m tests/data/test_numpy_dataset.py::[1mtest_from_numpy_features_only[0m - mlflow.exceptions.MlflowException: Could not find a source information reso...
[31m=========== [31m[1m1 failed[0m, [32m15 passed[0m, [33m14 deselected[0m, [33m2 warnings[0m[31m in 0.15s[0m[31m ============[0m
```

## 原始行 49 · agent_message

```
Implemented the dataset identity and serialization interfaces:

- [`dataset.py`](/testbed/mlflow/data/dataset.py): initialization, digest snapshotting, default naming, properties, and base serialization.
- [`dataset_source.py`](/testbed/mlflow/data/dataset_source.py): JSON serialization.

Validation:

- Focused interface tests: **4 passed**
- Edge cases for falsy/provided digests, empty/default names, and immutable digest snapshots passed.
- Compilation and diff checks passed.

Broader tests encounter unrelated masked repository omissions and unavailable PySpark.
```
