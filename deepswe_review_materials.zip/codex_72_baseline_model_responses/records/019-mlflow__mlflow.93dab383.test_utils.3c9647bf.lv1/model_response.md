# Codex baseline: mlflow__mlflow.93dab383.test_utils.3c9647bf.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the existing gateway utilities, their callers, and the visible tests, then implement the missing behavior and run the focused test suite.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' mlflow/gateway/utils.py && rg -n \"SearchRoutesToken|assemble_uri_path|check_configuration_route_name_collisions|get_gateway_uri|set_gateway_uri|resolve_route_url|is_valid_endpoint_name|_is_valid_uri\" mlflow tests -g '*.py'"
```

退出码：`127`

输出：
```
import base64
import functools
import inspect
import json
import logging
import posixpath
import re
import textwrap
import warnings
from typing import Any, AsyncGenerator
from urllib.parse import urlparse

from mlflow.environment_variables import MLFLOW_GATEWAY_URI
from mlflow.exceptions import MlflowException
from mlflow.gateway.constants import MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES
from mlflow.utils.uri import append_to_uri_path

_logger = logging.getLogger(__name__)
_gateway_uri: str | None = None
































































def check_configuration_deprecated_fields(config):
    endpoints = config.get("endpoints", [])
    for endpoint in endpoints:
        if "route_type" in endpoint:
            raise MlflowException.invalid_parameter_value(
                "The 'route_type' configuration key is not supported in the configuration file. "
                "Use 'endpoint_type' instead."
            )


def kill_child_processes(parent_pid):
    """
    Gracefully terminate or kill child processes from a main process
    """
    import psutil

    parent = psutil.Process(parent_pid)
    for child in parent.children(recursive=True):
        try:
            child.terminate()
        except psutil.NoSuchProcess:
            pass
    _, still_alive = psutil.wait_procs(parent.children(), timeout=3)
    for p in still_alive:
        p.kill()
















def _get_indent(s: str) -> str:
    for l in s.splitlines():
        if l.startswith(" "):
            return " " * (len(l) - len(l.lstrip()))
    return ""


def _prepend(docstring: str | None, text: str) -> str:
    if not docstring:
        return text

    indent = _get_indent(docstring)
    return f"""
{textwrap.indent(text, indent)}

{docstring}
"""


def gateway_deprecated(obj):
    msg = (
        "MLflow AI gateway is deprecated and has been replaced by the deployments API for "
        "generative AI. See https://mlflow.org/docs/latest/llms/gateway/migration.html for "
        "migration."
    )
    warning = f"""
.. warning::

    {msg}
""".strip()
    if inspect.isclass(obj):
        original = obj.__init__

        @functools.wraps(original)
        def wrapper(*args, **kwargs):
            warnings.warn(msg, FutureWarning, stacklevel=2)
            return original(*args, **kwargs)

        obj.__init__ = wrapper
        obj.__init__.__doc__ = _prepend(obj.__init__.__doc__, warning)
        return obj
    else:

        @functools.wraps(obj)
        def wrapper(*args, **kwargs):
            warnings.warn(msg, FutureWarning, stacklevel=2)
            return obj(*args, **kwargs)

        wrapper.__doc__ = _prepend(obj.__doc__, warning)

        return wrapper










































































class SearchRoutesToken:
    pass





























/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
The target file is intentionally masked and `rg` is unavailable here, so I’m switching to repository-local `grep`/`find`. I’ll use nearby gateway models and tests to preserve MLflow’s existing exception style and deprecated behavior.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "sed -n '280,700p' mlflow/gateway/utils.py; grep -RInE \"SearchRoutesToken|assemble_uri_path|check_configuration_route_name_collisions|get_gateway_uri|set_gateway_uri|resolve_route_url|is_valid_endpoint_name|_is_valid_uri\" mlflow tests --include='*.py' 2>/dev/null | head -400"
```

退出码：`0`

输出：
```







def is_valid_mosiacml_chat_model(model_name: str) -> bool:
    return any(
        model_name.lower().startswith(supported)
        for supported in MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES
    )


def is_valid_ai21labs_model(model_name: str) -> bool:
    return model_name in {"j2-ultra", "j2-mid", "j2-light"}


def strip_sse_prefix(s: str) -> str:
    # https://html.spec.whatwg.org/multipage/server-sent-events.html
    return re.sub(r"^data:\s+", "", s)


def to_sse_chunk(data: str) -> str:
    # https://html.spec.whatwg.org/multipage/server-sent-events.html
    return f"data: {data}\n\n"


def _find_boundary(buffer: bytes) -> int:
    try:
        return buffer.index(b"\n")
    except ValueError:
        return -1


async def handle_incomplete_chunks(
    stream: AsyncGenerator[bytes, Any],
) -> AsyncGenerator[bytes, Any]:
    """
    Wraps a streaming response and handles incomplete chunks from the server.
    See https://community.openai.com/t/incomplete-stream-chunks-for-completions-api/383520
    for more information.
    """
    buffer = b""
    async for chunk in stream:
        buffer += chunk
        while (boundary := _find_boundary(buffer)) != -1:
            yield buffer[:boundary]
            buffer = buffer[boundary + 1 :]


async def make_streaming_response(resp):
    from starlette.responses import StreamingResponse

    if isinstance(resp, AsyncGenerator):
        return StreamingResponse(
            (to_sse_chunk(d.json()) async for d in resp),
            media_type="text/event-stream",
        )
    else:
        return await respmlflow/gateway/utils.py:250:class SearchRoutesToken:
mlflow/gateway/__init__.py:4:    "get_gateway_uri",
mlflow/gateway/__init__.py:5:    "set_gateway_uri",
mlflow/gateway/config.py:23:    check_configuration_route_name_collisions,
mlflow/gateway/config.py:25:    is_valid_endpoint_name,
mlflow/gateway/config.py:341:        if not is_valid_endpoint_name(route_name):
mlflow/gateway/config.py:506:    check_configuration_route_name_collisions(configuration)
mlflow/gateway/app.py:51:from mlflow.gateway.utils import SearchRoutesToken, make_streaming_response
mlflow/gateway/app.py:379:        start_idx = SearchRoutesToken.decode(page_token).index if page_token is not None else 0
mlflow/gateway/app.py:387:            next_page_token = SearchRoutesToken(index=end_idx)
mlflow/gateway/app.py:395:        start_idx = SearchRoutesToken.decode(page_token).index if page_token is not None else 0
mlflow/gateway/app.py:401:            next_page_token = SearchRoutesToken(index=end_idx)
mlflow/deployments/utils.py:25:def _is_valid_uri(uri: str) -> bool:
mlflow/deployments/utils.py:52:    return endpoint if _is_valid_uri(endpoint) else append_to_uri_path(base_url, endpoint)
mlflow/deployments/utils.py:96:    return _is_valid_uri(target)
tests/gateway/test_gateway_config_parsing.py:15:from mlflow.gateway.utils import assemble_uri_path
tests/gateway/test_gateway_config_parsing.py:74:def test_assemble_uri_path(paths, expected):
tests/gateway/test_gateway_config_parsing.py:75:    assert assemble_uri_path(paths) == expected
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/gateway/utils.py | sed -n '1,430p'; sed -n '1,150p' mlflow/deployments/utils.py; sed -n '1,140p' tests/gateway/test_gateway_config_parsing.py; sed -n '300,540p' mlflow/gateway/config.py; sed -n '1,100p' mlflow/gateway/__init__.py"
```

退出码：`0`

输出：
```
     1	import base64
     2	import functools
     3	import inspect
     4	import json
     5	import logging
     6	import posixpath
     7	import re
     8	import textwrap
     9	import warnings
    10	from typing import Any, AsyncGenerator
    11	from urllib.parse import urlparse
    12	
    13	from mlflow.environment_variables import MLFLOW_GATEWAY_URI
    14	from mlflow.exceptions import MlflowException
    15	from mlflow.gateway.constants import MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES
    16	from mlflow.utils.uri import append_to_uri_path
    17	
    18	_logger = logging.getLogger(__name__)
    19	_gateway_uri: str | None = None
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	def check_configuration_deprecated_fields(config):
    85	    endpoints = config.get("endpoints", [])
    86	    for endpoint in endpoints:
    87	        if "route_type" in endpoint:
    88	            raise MlflowException.invalid_parameter_value(
    89	                "The 'route_type' configuration key is not supported in the configuration file. "
    90	                "Use 'endpoint_type' instead."
    91	            )
    92	
    93	
    94	def kill_child_processes(parent_pid):
    95	    """
    96	    Gracefully terminate or kill child processes from a main process
    97	    """
    98	    import psutil
    99	
   100	    parent = psutil.Process(parent_pid)
   101	    for child in parent.children(recursive=True):
   102	        try:
   103	            child.terminate()
   104	        except psutil.NoSuchProcess:
   105	            pass
   106	    _, still_alive = psutil.wait_procs(parent.children(), timeout=3)
   107	    for p in still_alive:
   108	        p.kill()
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	def _get_indent(s: str) -> str:
   126	    for l in s.splitlines():
   127	        if l.startswith(" "):
   128	            return " " * (len(l) - len(l.lstrip()))
   129	    return ""
   130	
   131	
   132	def _prepend(docstring: str | None, text: str) -> str:
   133	    if not docstring:
   134	        return text
   135	
   136	    indent = _get_indent(docstring)
   137	    return f"""
   138	{textwrap.indent(text, indent)}
   139	
   140	{docstring}
   141	"""
   142	
   143	
   144	def gateway_deprecated(obj):
   145	    msg = (
   146	        "MLflow AI gateway is deprecated and has been replaced by the deployments API for "
   147	        "generative AI. See https://mlflow.org/docs/latest/llms/gateway/migration.html for "
   148	        "migration."
   149	    )
   150	    warning = f"""
   151	.. warning::
   152	
   153	    {msg}
   154	""".strip()
   155	    if inspect.isclass(obj):
   156	        original = obj.__init__
   157	
   158	        @functools.wraps(original)
   159	        def wrapper(*args, **kwargs):
   160	            warnings.warn(msg, FutureWarning, stacklevel=2)
   161	            return original(*args, **kwargs)
   162	
   163	        obj.__init__ = wrapper
   164	        obj.__init__.__doc__ = _prepend(obj.__init__.__doc__, warning)
   165	        return obj
   166	    else:
   167	
   168	        @functools.wraps(obj)
   169	        def wrapper(*args, **kwargs):
   170	            warnings.warn(msg, FutureWarning, stacklevel=2)
   171	            return obj(*args, **kwargs)
   172	
   173	        wrapper.__doc__ = _prepend(obj.__doc__, warning)
   174	
   175	        return wrapper
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	
   210	
   211	
   212	
   213	
   214	
   215	
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	class SearchRoutesToken:
   251	    pass
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	def is_valid_mosiacml_chat_model(model_name: str) -> bool:
   288	    return any(
   289	        model_name.lower().startswith(supported)
   290	        for supported in MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES
   291	    )
   292	
   293	
   294	def is_valid_ai21labs_model(model_name: str) -> bool:
   295	    return model_name in {"j2-ultra", "j2-mid", "j2-light"}
   296	
   297	
   298	def strip_sse_prefix(s: str) -> str:
   299	    # https://html.spec.whatwg.org/multipage/server-sent-events.html
   300	    return re.sub(r"^data:\s+", "", s)
   301	
   302	
   303	def to_sse_chunk(data: str) -> str:
   304	    # https://html.spec.whatwg.org/multipage/server-sent-events.html
   305	    return f"data: {data}\n\n"
   306	
   307	
   308	def _find_boundary(buffer: bytes) -> int:
   309	    try:
   310	        return buffer.index(b"\n")
   311	    except ValueError:
   312	        return -1
   313	
   314	
   315	async def handle_incomplete_chunks(
   316	    stream: AsyncGenerator[bytes, Any],
   317	) -> AsyncGenerator[bytes, Any]:
   318	    """
   319	    Wraps a streaming response and handles incomplete chunks from the server.
   320	    See https://community.openai.com/t/incomplete-stream-chunks-for-completions-api/383520
   321	    for more information.
   322	    """
   323	    buffer = b""
   324	    async for chunk in stream:
   325	        buffer += chunk
   326	        while (boundary := _find_boundary(buffer)) != -1:
   327	            yield buffer[:boundary]
   328	            buffer = buffer[boundary + 1 :]
   329	
   330	
   331	async def make_streaming_response(resp):
   332	    from starlette.responses import StreamingResponse
   333	
   334	    if isinstance(resp, AsyncGenerator):
   335	        return StreamingResponse(
   336	            (to_sse_chunk(d.json()) async for d in resp),
   337	            media_type="text/event-stream",
   338	        )
   339	    else:
   340	        return await resp
import urllib
from urllib.parse import urlparse

from mlflow.environment_variables import MLFLOW_DEPLOYMENTS_TARGET
from mlflow.exceptions import MlflowException
from mlflow.utils.uri import append_to_uri_path

_deployments_target: str | None = None


def parse_target_uri(target_uri):
    """Parse out the deployment target from the provided target uri"""
    parsed = urllib.parse.urlparse(target_uri)
    if not parsed.scheme:
        if parsed.path:
            # uri = 'target_name' (without :/<path>)
            return parsed.path
        raise MlflowException(
            f"Not a proper deployment URI: {target_uri}. "
            + "Deployment URIs must be of the form 'target' or 'target:/suffix'"
        )
    return parsed.scheme


def _is_valid_uri(uri: str) -> bool:
    """
    Evaluates the basic structure of a provided uri to determine if the scheme and
    netloc are provided
    """
    try:
        parsed = urlparse(uri)
        return bool(parsed.scheme and parsed.netloc)
    except ValueError:
        return False


def resolve_endpoint_url(base_url: str, endpoint: str) -> str:
    """Performs a validation on whether the returned value is a fully qualified url
    or requires the assembly of a fully qualified url by appending `endpoint`.

    Args:
        base_url: The base URL. Should include the scheme and domain, e.g.,
            ``http://127.0.0.1:6000``.
        endpoint: The endpoint to be appended to the base URL, e.g., ``/api/2.0/endpoints/`` or,
            in the case of Databricks, the fully qualified url.

    Returns:
        The complete URL, either directly returned or formed and returned by joining the
        base URL and the endpoint path.

    """
    return endpoint if _is_valid_uri(endpoint) else append_to_uri_path(base_url, endpoint)


def set_deployments_target(target: str):
    """Sets the target deployment client for MLflow deployments

    Args:
        target: The full uri of a running MLflow AI Gateway or, if running on
            Databricks, "databricks".
    """
    if not _is_valid_target(target):
        raise MlflowException.invalid_parameter_value(
            "The target provided is not a valid uri or 'databricks'"
        )

    global _deployments_target
    _deployments_target = target


def get_deployments_target() -> str:
    """
    Returns the currently set MLflow deployments target iff set.
    If the deployments target has not been set by using ``set_deployments_target``, an
    ``MlflowException`` is raised.
    """
    if _deployments_target is not None:
        return _deployments_target
    elif uri := MLFLOW_DEPLOYMENTS_TARGET.get():
        return uri
    else:
        raise MlflowException(
            "No deployments target has been set. Please either set the MLflow deployments target"
            " via `mlflow.deployments.set_deployments_target()` or set the environment variable "
            f"{MLFLOW_DEPLOYMENTS_TARGET} to the running deployment server's uri"
        )


def _is_valid_target(target: str):
    """
    Evaluates the basic structure of a provided target to determine if the scheme and
    netloc are provided
    """
    if target == "databricks":
        return True
    return _is_valid_uri(target)
import re

import pytest
import yaml

from mlflow.exceptions import MlflowException
from mlflow.gateway.config import (
    AnthropicConfig,
    EndpointConfig,
    OpenAIConfig,
    _load_gateway_config,
    _resolve_api_key_from_input,
    _save_route_config,
)
from mlflow.gateway.utils import assemble_uri_path


@pytest.fixture
def basic_config_dict():
    return {
        "endpoints": [
            {
                "name": "completions-gpt4",
                "endpoint_type": "llm/v1/completions",
                "model": {
                    "name": "gpt-4",
                    "provider": "openai",
                    "config": {
                        "openai_api_key": "mykey",
                        "openai_api_base": "https://api.openai.com/v1",
                        "openai_api_version": "2023-05-10",
                        "openai_api_type": "openai",
                        "openai_organization": "my_company",
                    },
                },
            },
            {
                "name": "chat-gpt4",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "gpt-4",
                    "provider": "openai",
                    "config": {"openai_api_key": "sk-openai"},
                },
            },
            {
                "name": "claude-chat",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "claude-v1",
                    "provider": "anthropic",
                    "config": {
                        "anthropic_api_key": "api_key",
                    },
                },
            },
        ]
    }


@pytest.mark.parametrize(
    ("paths", "expected"),
    [
        (["gateway", "/routes/", "/chat"], "/gateway/routes/chat"),
        (["/gateway/", "/routes", "chat"], "/gateway/routes/chat"),
        (["gateway/routes/", "chat"], "/gateway/routes/chat"),
        (["gateway/", "routes/chat"], "/gateway/routes/chat"),
        (["/gateway/routes", "/chat/"], "/gateway/routes/chat"),
        (["/gateway", "/routes/", "chat/"], "/gateway/routes/chat"),
        (["/"], "/"),
        (["gateway", "", "/routes/", "", "/chat", ""], "/gateway/routes/chat"),
    ],
)
def test_assemble_uri_path(paths, expected):
    assert assemble_uri_path(paths) == expected


def test_api_key_parsing_env(tmp_path, monkeypatch):
    monkeypatch.setenv("KEY_AS_ENV", "my_key")

    assert _resolve_api_key_from_input("$KEY_AS_ENV") == "my_key"
    monkeypatch.delenv("KEY_AS_ENV", raising=False)
    with pytest.raises(MlflowException, match="Environment variable 'KEY_AS_ENV' is not set"):
        _resolve_api_key_from_input("$KEY_AS_ENV")

    string_key = "my_key_as_a_string"

    assert _resolve_api_key_from_input(string_key) == string_key

    conf_path = tmp_path.joinpath("mykey.conf")
    file_key = "Here is my key that sits safely in a file"

    conf_path.write_text(file_key)

    assert _resolve_api_key_from_input(str(conf_path)) == file_key


def test_api_key_input_exceeding_maximum_filename_length():
    assert _resolve_api_key_from_input("a" * 256) == "a" * 256


def test_api_key_parsing_file(tmp_path):
    key_path = tmp_path.joinpath("api.key")
    config = {
        "endpoints": [
            {
                "name": "claude-chat",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "claude-v1",
                    "provider": "anthropic",
                    "config": {
                        "anthropic_api_key": str(key_path),
                    },
                },
            },
        ]
    }

    key_path.write_text("abc")
    config_path = tmp_path.joinpath("config.yaml")
    config_path.write_text(yaml.safe_dump(config))
    loaded_config = _load_gateway_config(config_path)

    assert isinstance(loaded_config.endpoints[0].model.config, AnthropicConfig)
    assert loaded_config.endpoints[0].model.config.anthropic_api_key == "abc"


def test_route_configuration_parsing(basic_config_dict, tmp_path, monkeypatch):
    conf_path = tmp_path.joinpath("config.yaml")

    conf_path.write_text(yaml.safe_dump(basic_config_dict))

    loaded_config = _load_gateway_config(conf_path)

    save_path = tmp_path.joinpath("config2.yaml")
    _save_route_config(loaded_config, save_path)
    loaded_from_save = _load_gateway_config(save_path)

    completions_gpt4 = loaded_from_save.endpoints[0]
        # For Pydantic v2: 'context' is a ValidationInfo object with a 'data' attribute.
        # For Pydantic v1: 'context' is dict-like 'values'.
        provider = context.data.get("provider")
        if provider:
            config_type = provider_registry.get(provider).CONFIG_TYPE
            return config_type(**val) if isinstance(val, dict) else val
        raise MlflowException.invalid_parameter_value(
            "A provider must be provided for each gateway route."
        )

    @field_validator("config", mode="before")
    def validate_config(cls, info, values):
        return cls._validate_config(info, values)


class AliasedConfigModel(ConfigModel):
    """
    Enables use of field aliases in a configuration model for backwards compatibility
    """

    model_config = ConfigDict(populate_by_name=True)


class Limit(LimitModel):
    calls: int
    key: str | None = None
    renewal_period: str


class LimitsConfig(ConfigModel):
    limits: list[Limit] | None = []


class EndpointConfig(AliasedConfigModel):
    name: str
    endpoint_type: EndpointType
    model: Model
    limit: Limit | None = None

    @field_validator("name")
    def validate_endpoint_name(cls, route_name):
        if not is_valid_endpoint_name(route_name):
            raise MlflowException.invalid_parameter_value(
                "The route name provided contains disallowed characters for a url endpoint. "
                f"'{route_name}' is invalid. Names cannot contain spaces or any non "
                "alphanumeric characters other than hyphen and underscore."
            )
        return route_name

    @field_validator("model", mode="before")
    def validate_model(cls, model):
        if model:
            model_instance = Model(**model)
            if model_instance.provider in Provider.values() and model_instance.config is None:
                raise MlflowException.invalid_parameter_value(
                    "A config must be supplied when setting a provider. The provider entry for "
                    f"{model_instance.provider} is incorrect."
                )
        return model

    @model_validator(mode="after")
    def validate_route_type_and_model_name(self):
        if (
            self.model
            and self.model.provider == "mosaicml"
            and self.endpoint_type == EndpointType.LLM_V1_CHAT
            and not is_valid_mosiacml_chat_model(self.model.name)
        ):
            raise MlflowException.invalid_parameter_value(
                f"An invalid model has been specified for the chat route. '{self.model.name}'. "
                f"Ensure the model selected starts with one of: "
                f"{MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES}"
            )
        if (
            self.model
            and self.model.provider == "ai21labs"
            and not is_valid_ai21labs_model(self.model.name)
        ):
            raise MlflowException.invalid_parameter_value(
                f"An Unsupported AI21Labs model has been specified: '{self.model.name}'. "
                f"Please see documentation for supported models."
            )
        return self

    @field_validator("endpoint_type", mode="before")
    def validate_route_type(cls, value):
        if value in EndpointType._value2member_map_:
            return value
        raise MlflowException.invalid_parameter_value(f"The route_type '{value}' is not supported.")

    @field_validator("limit", mode="before")
    def validate_limit(cls, value):
        from limits import parse

        if value:
            limit = Limit(**value)
            try:
                parse(f"{limit.calls}/{limit.renewal_period}")
            except ValueError:
                raise MlflowException.invalid_parameter_value(
                    "Failed to parse the rate limit configuration."
                    "Please make sure limit.calls is a positive number and"
                    "limit.renewal_period is a right granularity"
                )

        return value

    def _to_legacy_route(self) -> "_LegacyRoute":
        return _LegacyRoute(
            name=self.name,
            route_type=self.endpoint_type,
            model=EndpointModelInfo(
                name=self.model.name,
                provider=self.model.provider,
            ),
            route_url=f"{MLFLOW_GATEWAY_ROUTE_BASE}{self.name}{MLFLOW_QUERY_SUFFIX}",
            limit=self.limit,
        )

    def to_endpoint(self) -> "Endpoint":
        from mlflow.deployments.server.config import Endpoint

        return Endpoint(
            name=self.name,
            endpoint_type=self.endpoint_type,
            model=EndpointModelInfo(
                name=self.model.name,
                provider=self.model.provider,
            ),
            endpoint_url=f"{MLFLOW_GATEWAY_ROUTE_BASE}{self.name}{MLFLOW_QUERY_SUFFIX}",
            limit=self.limit,
        )


class RouteDestinationConfig(ConfigModel):
    name: str
    traffic_percentage: int


class TrafficRouteConfig(ConfigModel):
    name: str
    task_type: EndpointType
    destinations: list[RouteDestinationConfig]
    routing_strategy: Literal["TRAFFIC_SPLIT"] = "TRAFFIC_SPLIT"


class EndpointModelInfo(ResponseModel):
    name: str | None = None
    # Use `str` instead of `Provider` enum to allow gateway backends such as Databricks to
    # support new providers without breaking the gateway client.
    provider: str


_ROUTE_EXTRA_SCHEMA = {
    "example": {
        "name": "openai-completions",
        "route_type": "llm/v1/completions",
        "model": {
            "name": "gpt-4o-mini",
            "provider": "openai",
        },
        "route_url": "/gateway/routes/completions/invocations",
    }
}


class _LegacyRoute(ConfigModel):
    name: str
    route_type: str
    model: EndpointModelInfo
    route_url: str
    limit: Limit | None = None

    model_config = ConfigDict(json_schema_extra=_ROUTE_EXTRA_SCHEMA)

    def to_endpoint(self):
        from mlflow.deployments.server.config import Endpoint

        return Endpoint(
            name=self.name,
            endpoint_type=self.route_type,
            model=self.model,
            endpoint_url=self.route_url,
            limit=self.limit,
        )


class GatewayConfig(AliasedConfigModel):
    endpoints: list[EndpointConfig]
    routes: list[TrafficRouteConfig] | None = None


def _load_gateway_config(path: str | Path) -> GatewayConfig:
    """
    Reads the gateway configuration yaml file from the storage location and returns an instance
    of the configuration RouteConfig class
    """
    if isinstance(path, str):
        path = Path(path)
    try:
        configuration = yaml.safe_load(path.read_text())
    except Exception as e:
        raise MlflowException.invalid_parameter_value(
            f"The file at {path} is not a valid yaml file"
        ) from e
    check_configuration_deprecated_fields(configuration)
    check_configuration_route_name_collisions(configuration)
    try:
        return GatewayConfig(**configuration)
    except ValidationError as e:
        raise MlflowException.invalid_parameter_value(
            f"The gateway configuration is invalid: {e}"
        ) from e


def _save_route_config(config: GatewayConfig, path: str | Path) -> None:
    if isinstance(path, str):
        path = Path(path)
    path.write_text(
        yaml.safe_dump(json.loads(json.dumps(config.model_dump(), default=pydantic_encoder)))
    )


def _validate_config(config_path: str) -> GatewayConfig:
    if not os.path.exists(config_path):
        raise MlflowException.invalid_parameter_value(f"{config_path} does not exist")

    try:
        return _load_gateway_config(config_path)
    except Exception as e:
        raise MlflowException.invalid_parameter_value(f"Invalid gateway configuration: {e}") from e


__all__ = [
    "get_gateway_uri",
    "set_gateway_uri",
]
```

## 原始行 16 · command_execution

命令：
```
/bin/bash -lc "find tests -type f -name '*.py' -print | sort | grep -E 'gateway|deploy' ; grep -RInE \"collision|traffic_percentage|destination|gateway URI|gateway_uri|page_token|SearchRoutes|route URL|resolve_route\" tests/gateway tests --include='*.py' 2>/dev/null | head -500; grep -RIn \"MLFLOW_GATEWAY_URI\" mlflow tests --include='*.py' 2>/dev/null | head -100; grep -RIn \"invalid.*token\\|Invalid.*token\\|page token\" mlflow tests --include='*.py' 2>/dev/null | head -200"
```

退出码：`0`

输出：
```
tests/deployments/__init__.py
tests/deployments/databricks/__init__.py
tests/deployments/databricks/test_databricks.py
tests/deployments/mlflow/__init__.py
tests/deployments/mlflow/test_mlflow.py
tests/deployments/openai/__init__.py
tests/deployments/openai/test_openai.py
tests/deployments/test_cli.py
tests/deployments/test_deployments.py
tests/deployments/test_interface.py
tests/deployments/test_utils.py
tests/gateway/__init__.py
tests/gateway/providers/__init__.py
tests/gateway/providers/test_ai21labs.py
tests/gateway/providers/test_anthropic.py
tests/gateway/providers/test_bedrock.py
tests/gateway/providers/test_cohere.py
tests/gateway/providers/test_gemini.py
tests/gateway/providers/test_huggingface.py
tests/gateway/providers/test_mistral.py
tests/gateway/providers/test_mlflow.py
tests/gateway/providers/test_mosaicml.py
tests/gateway/providers/test_openai.py
tests/gateway/providers/test_openai_uc_functions.py
tests/gateway/providers/test_palm.py
tests/gateway/providers/test_provider_utils.py
tests/gateway/providers/test_togetherai.py
tests/gateway/providers/test_traffic_route_provider.py
tests/gateway/schemas/__init__.py
tests/gateway/schemas/test_chat.py
tests/gateway/schemas/test_completions.py
tests/gateway/schemas/test_embeddings.py
tests/gateway/test_cli.py
tests/gateway/test_gateway_app.py
tests/gateway/test_gateway_config_parsing.py
tests/gateway/test_openai_compatibility.py
tests/gateway/test_runner.py
tests/gateway/tools.py
tests/resources/mlflow-test-plugin/mlflow_test_plugin/fake_deployment_plugin.py
tests/sagemaker/test_batch_deployment.py
tests/sagemaker/test_sagemaker_deployment_client.py
tests/gateway/test_gateway_config_parsing.py:192:        # Route definition that would be returned via the GetRoute or SearchRoutes APIs
tests/gateway/test_gateway_app.py:65:                    "destinations": [
tests/gateway/test_gateway_app.py:68:                            "traffic_percentage": 80,
tests/gateway/test_gateway_app.py:72:                            "traffic_percentage": 20,
tests/gateway/test_gateway_app.py:175:        "destinations": [
tests/gateway/test_gateway_app.py:176:            {"name": "chat-gpt4", "traffic_percentage": 80},
tests/gateway/test_gateway_app.py:177:            {"name": "chat-gpt5", "traffic_percentage": 20},
tests/gateway/test_gateway_app.py:205:                    "destinations": [
tests/gateway/test_gateway_app.py:208:                            "traffic_percentage": 100,
tests/autologging/test_autologging_behaviors_unit.py:18:    patch_destination,
tests/autologging/test_autologging_behaviors_unit.py:30:def autolog_function(patch_destination, logger):
tests/autologging/test_autologging_behaviors_unit.py:40:    patch_destination.fn = original_impl
tests/autologging/test_autologging_behaviors_unit.py:73:        safe_patch("test_integration", patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_behaviors_unit.py:79:    autolog_function, patch_destination, logger
tests/autologging/test_autologging_behaviors_unit.py:86:        patch_destination.fn()
tests/autologging/test_autologging_behaviors_unit.py:118:    autolog_function, patch_destination, logger
tests/autologging/test_autologging_behaviors_unit.py:126:        patch_destination.fn()
tests/autologging/test_autologging_behaviors_unit.py:142:        patch_destination.fn()
tests/autologging/test_autologging_behaviors_unit.py:163:    autolog_function, patch_destination, logger
tests/autologging/test_autologging_behaviors_unit.py:176:        patch_destination.fn()
tests/autologging/test_autologging_behaviors_unit.py:211:    patch_destination.fn = original_impl
tests/autologging/test_autologging_behaviors_unit.py:219:        safe_patch("test_integration", patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_behaviors_unit.py:227:        patch_destination.fn()
tests/autologging/test_autologging_behaviors_unit.py:243:def test_silent_mode_operates_independently_across_integrations(patch_destination, logger):
tests/autologging/test_autologging_behaviors_unit.py:247:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_behaviors_unit.py:255:        safe_patch("integration1", patch_destination, "fn", patch_impl1)
tests/autologging/test_autologging_behaviors_unit.py:257:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_behaviors_unit.py:268:        safe_patch("integration2", patch_destination, "fn2", patch_impl2)
tests/autologging/test_autologging_behaviors_unit.py:274:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_behaviors_unit.py:275:        run_sync_or_async(patch_destination.fn2)
tests/autologging/test_autologging_behaviors_unit.py:290:    patch_destination, silent, disable
tests/autologging/test_autologging_behaviors_unit.py:298:    patch_destination.fn = original_fn
tests/autologging/test_autologging_behaviors_unit.py:302:        safe_patch("test_integration", patch_destination, "fn", lambda original: original())
tests/autologging/test_autologging_behaviors_unit.py:307:        patch_destination.fn()
tests/autologging/test_autologging_behaviors_unit.py:319:def test_autolog_function_thread_safety(patch_destination):
tests/autologging/test_autologging_behaviors_unit.py:327:    patch_destination.fn = original_impl
tests/autologging/test_autologging_behaviors_unit.py:335:        safe_patch("test_integration", patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_behaviors_unit.py:347:    assert patch_destination.fn is original_impl
tests/autologging/test_autologging_safety_unit.py:34:    patch_destination,  # noqa: F401
tests/autologging/test_autologging_safety_unit.py:165:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:170:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:177:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:178:    run_sync_or_async(patch_destination.fn, 7, bar=11)
tests/autologging/test_autologging_safety_unit.py:184:    test_autologging_integration, patch_destination
tests/autologging/test_autologging_safety_unit.py:186:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:193:    patch_destination.fn = original_fn
tests/autologging/test_autologging_safety_unit.py:195:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:199:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:201:    assert run_sync_or_async(patch_destination.fn, 1, 2) == {"foo": 2, "bar": 4}
tests/autologging/test_autologging_safety_unit.py:205:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:209:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:213:    patch_destination.fn = original
tests/autologging/test_autologging_safety_unit.py:217:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:223:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:226:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:233:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:237:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:241:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:243:        assert run_sync_or_async(patch_destination.fn) == PATCH_DESTINATION_FN_DEFAULT_RESULT
tests/autologging/test_autologging_safety_unit.py:253:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:257:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:261:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:263:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:269:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:273:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:279:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:280:    assert run_sync_or_async(patch_destination.fn) == PATCH_DESTINATION_FN_DEFAULT_RESULT
tests/autologging/test_autologging_safety_unit.py:281:    assert patch_destination.fn_call_count == 1
tests/autologging/test_autologging_safety_unit.py:286:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:290:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:297:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:298:    assert run_sync_or_async(patch_destination.fn) == PATCH_DESTINATION_FN_DEFAULT_RESULT
tests/autologging/test_autologging_safety_unit.py:299:    assert patch_destination.fn_call_count == 1
tests/autologging/test_autologging_safety_unit.py:303:def test_safe_patch_respects_disable_flag(patch_destination):
tests/autologging/test_autologging_safety_unit.py:308:        @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:314:        safe_patch("test_respects_disable", patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:317:    run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:321:    run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:326:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:330:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:336:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:337:    assert run_sync_or_async(patch_destination.fn) == PATCH_DESTINATION_FN_DEFAULT_RESULT
tests/autologging/test_autologging_safety_unit.py:338:    assert patch_destination.fn_call_count == 1
tests/autologging/test_autologging_safety_unit.py:344:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:346:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:350:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:359:        run_sync_or_async(patch_destination.fn, "a", "b", "c")
tests/autologging/test_autologging_safety_unit.py:366:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:370:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:374:    safe_patch(test_autologging_integration, patch_destination, "fn", leak_run_patch_impl)
tests/autologging/test_autologging_safety_unit.py:376:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:384:        patch_destination.fn()
tests/autologging/test_autologging_safety_unit.py:392:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:396:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:400:    safe_patch(test_autologging_integration, patch_destination, "fn", leak_run_patch_impl)
tests/autologging/test_autologging_safety_unit.py:401:    run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:412:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:424:    if patch_destination.is_async:
tests/autologging/test_autologging_safety_unit.py:425:        safe_patch(test_autologging_integration, patch_destination, "fn", async_no_tag_run_patch)
tests/autologging/test_autologging_safety_unit.py:427:        safe_patch(test_autologging_integration, patch_destination, "fn", no_tag_run_patch)
tests/autologging/test_autologging_safety_unit.py:436:            run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:444:            run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:449:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:453:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:458:    safe_patch(test_autologging_integration, patch_destination, "fn", no_tag_run_patch_impl)
tests/autologging/test_autologging_safety_unit.py:464:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:469:            run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:475:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:480:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:486:    if patch_destination.is_async:
tests/autologging/test_autologging_safety_unit.py:489:                test_autologging_integration, patch_destination, "fn", patch_impl, manage_run=True
tests/autologging/test_autologging_safety_unit.py:497:            test_autologging_integration, patch_destination, "fn", patch_impl, manage_run=True
tests/autologging/test_autologging_safety_unit.py:500:    run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:510:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:514:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:524:            test_autologging_integration, patch_destination, "fn", patch_impl, manage_run=False
tests/autologging/test_autologging_safety_unit.py:526:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:532:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:534:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:538:    patch_destination.fn = original
tests/autologging/test_autologging_safety_unit.py:542:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:548:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:549:    run_sync_or_async(patch_destination.fn, 1, 2)
tests/autologging/test_autologging_safety_unit.py:551:    assert inspect.signature(patch_destination.fn) == inspect.signature(original)
tests/autologging/test_autologging_safety_unit.py:555:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:557:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:561:    patch_destination.fn = original
tests/autologging/test_autologging_safety_unit.py:565:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:571:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:572:    run_sync_or_async(patch_destination.fn, 1, 2)
tests/autologging/test_autologging_safety_unit.py:577:    patch_destination,
tests/autologging/test_autologging_safety_unit.py:584:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:595:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:597:    run_sync_or_async(patch_destination.fn, "a", 1, b=2)
tests/autologging/test_autologging_safety_unit.py:601:    assert all(call.patch_obj == patch_destination for call in mock_event_logger.calls)
tests/autologging/test_autologging_safety_unit.py:613:    patch_destination,
tests/autologging/test_autologging_safety_unit.py:621:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:633:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:644:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:654:    patch_destination,
tests/autologging/test_autologging_safety_unit.py:663:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:675:    safe_patch(test_autologging_integration, patch_destination, "throw_error_fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:682:            run_sync_or_async(patch_destination.throw_error_fn, original_err_to_raise)
tests/autologging/test_autologging_safety_unit.py:691:    patch_destination,
tests/autologging/test_autologging_safety_unit.py:697:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:701:    patch_destination.fn = original
tests/autologging/test_autologging_safety_unit.py:703:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:707:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:710:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:720:    patch_destination,
tests/autologging/test_autologging_safety_unit.py:726:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:734:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:787:    assert run_sync_or_async(patch_destination.fn) == PATCH_DESTINATION_FN_DEFAULT_RESULT
tests/autologging/test_autologging_safety_unit.py:1431:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:1435:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:1440:    safe_patch(test_autologging_integration, patch_destination, "fn", check_session_manager_status)
tests/autologging/test_autologging_safety_unit.py:1441:    run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:1446:    patch_destination, test_autologging_integration
tests/autologging/test_autologging_safety_unit.py:1448:    @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:1452:    safe_patch(test_autologging_integration, patch_destination, "fn", patch_fn)
tests/autologging/test_autologging_safety_unit.py:1453:    run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:1469:def test_original_fn_runs_if_patch_should_not_be_applied(patch_destination):
tests/autologging/test_autologging_safety_unit.py:1474:        @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:1480:        safe_patch("test_respects_exclusive", patch_destination, "fn", patch_impl)
tests/autologging/test_autologging_safety_unit.py:1484:        run_sync_or_async(patch_destination.fn)
tests/autologging/test_autologging_safety_unit.py:1486:    assert patch_destination.fn_call_count == 1
tests/autologging/test_autologging_safety_unit.py:1535:def test_nested_call_autologging_disabled_when_top_level_call_autologging_failed(patch_destination):
tests/autologging/test_autologging_safety_unit.py:1542:        @asyncify(patch_destination.is_async)
tests/autologging/test_autologging_safety_unit.py:1556:            patch_destination,
tests/autologging/test_autologging_safety_unit.py:1564:        patch_destination.recurse_fn_call_count = 0
tests/autologging/test_autologging_safety_unit.py:1566:            run_sync_or_async(patch_destination.recursive_fn, level=0, max_depth=max_depth)
tests/autologging/test_autologging_safety_unit.py:1568:        assert patch_destination.recurse_fn_call_count == max_depth + 1
tests/autologging/fixtures.py:15:def patch_destination(request):
tests/test_cli.py:80:            artifacts_destination=mock.ANY,
tests/test_cli.py:102:            artifacts_destination=mock.ANY,
tests/test_cli.py:128:            artifacts_destination=mock.ANY,
tests/test_cli.py:154:            artifacts_destination=mock.ANY,
tests/test_cli.py:581:                "--artifacts-destination",
tests/gateway/test_gateway_config_parsing.py:192:        # Route definition that would be returned via the GetRoute or SearchRoutes APIs
tests/gateway/test_gateway_app.py:65:                    "destinations": [
tests/gateway/test_gateway_app.py:68:                            "traffic_percentage": 80,
tests/gateway/test_gateway_app.py:72:                            "traffic_percentage": 20,
tests/gateway/test_gateway_app.py:175:        "destinations": [
tests/gateway/test_gateway_app.py:176:            {"name": "chat-gpt4", "traffic_percentage": 80},
tests/gateway/test_gateway_app.py:177:            {"name": "chat-gpt5", "traffic_percentage": 20},
tests/gateway/test_gateway_app.py:205:                    "destinations": [
tests/gateway/test_gateway_app.py:208:                            "traffic_percentage": 100,
tests/tracing/test_provider.py:16:from mlflow.tracing.destination import Databricks, MlflowExperiment
tests/tracing/test_provider.py:93:def test_set_destination_mlflow_experiment(monkeypatch):
tests/tracing/test_provider.py:94:    mlflow.tracing.set_destination(destination=MlflowExperimentLocation(experiment_id="123"))
tests/tracing/test_provider.py:102:def test_set_destination_databricks(monkeypatch):
tests/tracing/test_provider.py:104:    mlflow.tracing.set_destination(destination=Databricks(experiment_id="123"))
tests/tracing/test_provider.py:113:def test_set_destination_databricks_uc(monkeypatch):
tests/tracing/test_provider.py:114:    mlflow.tracing.set_destination(
tests/tracing/test_provider.py:115:        destination=UCSchemaLocation(
tests/tracing/test_provider.py:129:def test_set_destination_from_env_var_mlflow_experiment(monkeypatch):
tests/tracing/test_provider.py:139:def test_set_destination_from_env_var_databricks_uc(monkeypatch):
tests/tracing/test_provider.py:150:def test_set_destination_in_model_serving(mock_databricks_serving_with_tracing_env, monkeypatch):
tests/tracing/test_provider.py:162:def test_set_destination_deprecated_classes():
tests/tracing/test_provider.py:165:    with pytest.warns(FutureWarning, match="`mlflow.tracing.destination.MlflowExperiment``"):
tests/tracing/test_provider.py:166:        mlflow.tracing.set_destination(destination=MlflowExperiment(experiment_id="123"))
tests/tracing/test_provider.py:168:    destination = _MLFLOW_TRACE_USER_DESTINATION.get()
tests/tracing/test_provider.py:169:    assert isinstance(destination, MlflowExperimentLocation)
tests/tracing/test_provider.py:170:    assert destination.experiment_id == "123"
tests/tracing/test_provider.py:172:    with pytest.warns(FutureWarning, match="`mlflow.tracing.destination.Databricks`"):
tests/tracing/test_provider.py:173:        mlflow.tracing.set_destination(destination=Databricks(experiment_id="123"))
tests/tracing/test_provider.py:175:    destination = _MLFLOW_TRACE_USER_DESTINATION.get()
tests/tracing/test_provider.py:176:    assert isinstance(destination, MlflowExperimentLocation)
tests/tracing/test_provider.py:177:    assert destination.experiment_id == "123"
tests/tracing/utils/test_utils.py:409:def test_get_spans_table_name_for_trace_with_destination():
tests/tracing/utils/test_utils.py:410:    mock_destination = UCSchemaLocation(catalog_name="catalog", schema_name="schema")
tests/tracing/utils/test_utils.py:413:        mock_ctx.get.return_value = mock_destination
tests/tracing/utils/test_utils.py:419:def test_get_spans_table_name_for_trace_no_destination():
tests/tracing/test_tracing_client.py:168:        page_token=None,
tests/tracing/test_fluent.py:36:from mlflow.tracing.destination import MlflowExperiment
tests/tracing/test_fluent.py:39:from mlflow.tracing.provider import _get_tracer, set_destination
tests/tracing/test_fluent.py:625:    @mlflow.trace(trace_destination=MlflowExperiment(exp_1))
tests/tracing/test_fluent.py:652:    @mlflow.trace(trace_destination=MlflowExperiment(exp_1))
tests/tracing/test_fluent.py:656:    @mlflow.trace(trace_destination=MlflowExperiment(exp_1))
tests/tracing/test_fluent.py:936:        page_token=None,
tests/tracing/test_fluent.py:989:            mock.call(**common_args, page_token=None),
tests/tracing/test_fluent.py:990:            mock.call(**common_args, page_token="token-1"),
tests/tracing/test_fluent.py:991:            mock.call(**common_args, page_token="token-2"),
tests/tracing/test_fluent.py:1007:        page_token=None,
tests/tracing/test_fluent.py:2263:def test_set_destination_in_threads(async_logging_enabled):
tests/tracing/test_fluent.py:2264:    # This test makes sure `set_destination` obeys thread-local behavior.
tests/tracing/test_fluent.py:2287:            set_destination(MlflowExperiment(experiment_id), context_local=True)
tests/tracing/test_fluent.py:2294:    set_destination(MlflowExperiment(experiment_id1))
tests/tracing/test_fluent.py:2335:async def test_set_destination_in_async_contexts(async_logging_enabled):
tests/tracing/test_fluent.py:2355:        set_destination(MlflowExperiment(experiment_id), context_local=True)
tests/tracing/helper.py:171:    """Get current tracking URI configured as the trace export destination."""
tests/tracing/conftest.py:24:    # Some API like set_destination("databricks") updates the tracking URI,
tests/tracing/export/test_mlflow_v3_exporter.py:63:    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id=_EXPERIMENT_ID))
tests/tracing/export/test_mlflow_v3_exporter.py:167:    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id=_EXPERIMENT_ID))
tests/tracing/export/test_mlflow_v3_exporter.py:198:    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id=0))
tests/tracing/export/test_mlflow_v3_exporter.py:240:    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id=_EXPERIMENT_ID))
tests/tracing/export/test_mlflow_v3_exporter.py:346:    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id=_EXPERIMENT_ID))
tests/tracing/export/test_mlflow_v3_exporter.py:415:    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id=_EXPERIMENT_ID))
tests/tracing/opentelemetry/test_integration.py:18:    # Use set_destination to trigger tracer provider initialization
tests/tracing/opentelemetry/test_integration.py:20:    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id))
tests/genai/judges/test_judge_tool_get_root_span.py:199:    page_token = None
tests/genai/judges/test_judge_tool_get_root_span.py:204:        result = tool.invoke(trace, max_content_length=1000, page_token=page_token)
tests/genai/judges/test_judge_tool_get_root_span.py:213:        if result.page_token is None:
tests/genai/judges/test_judge_tool_get_root_span.py:216:        page_token = result.page_token
tests/genai/judges/test_judge_tool_get_root_span.py:224:def test_get_root_span_tool_invoke_invalid_page_token():
tests/genai/judges/test_judge_tool_get_root_span.py:251:        MlflowException, match="Invalid page_token 'invalid': must be a valid integer"
tests/genai/judges/test_judge_tool_get_root_span.py:253:        tool.invoke(trace, page_token="invalid")
tests/genai/judges/test_judge_tool_get_root_span.py:257:        MlflowException, match="Invalid page_token '\\[\\]': must be a valid integer"
tests/genai/judges/test_judge_tool_get_root_span.py:259:        tool.invoke(trace, page_token=[])
tests/genai/judges/test_judge_tool_get_span.py:174:    page_token = None
tests/genai/judges/test_judge_tool_get_span.py:179:        result = tool.invoke(trace, span.span_id, max_content_length=1000, page_token=page_token)
tests/genai/judges/test_judge_tool_get_span.py:188:        if result.page_token is None:
tests/genai/judges/test_judge_tool_get_span.py:191:        page_token = result.page_token
tests/genai/judges/test_judge_tool_get_span.py:199:def test_get_span_tool_invoke_invalid_page_token():
tests/genai/judges/test_judge_tool_get_span.py:226:        MlflowException, match="Invalid page_token 'invalid': must be a valid integer"
tests/genai/judges/test_judge_tool_get_span.py:228:        tool.invoke(trace, span.span_id, page_token="invalid")
tests/genai/judges/test_judge_tool_get_span.py:232:        MlflowException, match="Invalid page_token '\\[\\]': must be a valid integer"
tests/genai/judges/test_judge_tool_get_span.py:234:        tool.invoke(trace, span.span_id, page_token=[])
tests/genai/judges/test_judge_tool_list_spans.py:75:    assert result.next_page_token is None
tests/genai/judges/test_judge_tool_list_spans.py:105:    assert result.next_page_token is None
tests/genai/judges/test_judge_tool_list_spans.py:124:    assert result.next_page_token is None
tests/genai/judges/test_judge_tool_list_spans.py:134:    assert result.next_page_token == "1"
tests/genai/judges/test_judge_tool_list_spans.py:138:    result = tool.invoke(mock_trace_with_spans, max_results=1, page_token="1")
tests/genai/judges/test_judge_tool_list_spans.py:140:    assert result.next_page_token is None
tests/genai/judges/test_judge_tool_list_spans.py:144:def test_list_spans_tool_invoke_invalid_page_token(mock_trace_with_spans):
tests/genai/judges/test_judge_tool_list_spans.py:152:        MlflowException, match="Invalid page_token 'invalid': must be a valid integer"
tests/genai/judges/test_judge_tool_list_spans.py:154:        tool.invoke(mock_trace_with_spans, page_token="invalid")
tests/genai/judges/test_judge_tool_list_spans.py:158:        MlflowException, match="Invalid page_token '\\[\\]': must be a valid integer"
tests/genai/judges/test_judge_tool_list_spans.py:160:        tool.invoke(mock_trace_with_spans, page_token=[])
tests/genai/datasets/test_fluent.py:274:        page_token=None,
tests/genai/datasets/test_fluent.py:303:        page_token=None,
tests/genai/datasets/test_fluent.py:343:    assert first_call[1]["page_token"] is None
tests/genai/datasets/test_fluent.py:346:    assert second_call[1]["page_token"] == "token1"
tests/genai/datasets/test_fluent.py:1349:    assert not hasattr(dataset, "page_token")
tests/genai/datasets/test_fluent.py:1350:    assert not hasattr(dataset, "next_page_token")
tests/server/auth/test_auth.py:197:        page_token = ""
tests/server/auth/test_auth.py:204:                page_token=page_token,
tests/server/auth/test_auth.py:207:            page_token = res.token
tests/server/auth/test_auth.py:208:            if not page_token:
tests/server/auth/test_auth.py:215:        page_token = ""
tests/server/auth/test_auth.py:222:                page_token=page_token,
tests/server/auth/test_auth.py:225:            page_token = res.token
tests/server/auth/test_auth.py:226:            if not page_token:
tests/server/auth/test_auth.py:280:        page_token = ""
tests/server/auth/test_auth.py:287:                page_token=page_token,
tests/server/auth/test_auth.py:290:            page_token = res.token
tests/server/auth/test_auth.py:291:            if not page_token:
tests/server/auth/test_auth.py:298:        page_token = ""
tests/server/auth/test_auth.py:305:                page_token=page_token,
tests/server/auth/test_auth.py:308:            page_token = res.token
tests/server/auth/test_auth.py:309:            if not page_token:
tests/server/auth/test_auth.py:543:            experiment_ids=experiment_ids, max_results=2, page_token=models.token
tests/server/auth/test_auth.py:548:        models = client.search_logged_models(experiment_ids=experiment_ids, page_token=models.token)
tests/server/auth/test_auth.py:562:            experiment_ids=experiment_ids, max_results=2, page_token=models.token
tests/server/auth/test_auth.py:567:        models = client.search_logged_models(experiment_ids=experiment_ids, page_token=models.token)
tests/server/auth/test_auth.py:614:        page_token = None
tests/server/auth/test_auth.py:620:                page_token=page_token,
tests/server/auth/test_auth.py:623:            page_token = runs.token
tests/server/auth/test_auth.py:624:            if not page_token:
tests/server/test_init.py:138:            artifacts_destination="",
tests/server/test_init.py:155:            artifacts_destination="",
tests/server/test_init.py:171:            artifacts_destination="",
tests/server/test_init.py:217:            artifacts_destination="",
tests/server/test_handlers.py:350:def test_search_runs_empty_page_token(mock_get_request_message, mock_tracking_store):
tests/server/test_handlers.py:352:    Test that empty page_token from protobuf is converted to None before calling store
tests/server/test_handlers.py:354:    # Create proto without setting page_token
tests/server/test_handlers.py:359:    assert search_runs_proto.page_token == ""
tests/server/test_handlers.py:369:    assert call_kwargs["page_token"] is None  # page_token should be None, not ""
tests/server/test_handlers.py:511:        "page_token": None,
tests/server/test_handlers.py:523:        "page_token": None,
tests/server/test_handlers.py:527:        "next_page_token": "tok",
tests/server/test_handlers.py:534:    assert args == {"filter_string": "hi", "max_results": 5, "order_by": [], "page_token": None}
tests/server/test_handlers.py:537:        "next_page_token": "tik",
tests/server/test_handlers.py:541:        filter="hey", max_results=500, order_by=["a", "B desc"], page_token="prev"
tests/server/test_handlers.py:550:        "page_token": "prev",
tests/server/test_handlers.py:554:        "next_page_token": "DONE",
tests/server/test_handlers.py:801:        page_token=None,
tests/server/test_handlers.py:812:        page_token=None,
tests/server/test_handlers.py:816:        "next_page_token": "tok",
tests/server/test_handlers.py:825:        filter_string="version<=12", max_results=2, order_by=[], page_token=None
tests/server/test_handlers.py:829:        "next_page_token": "next",
tests/server/test_handlers.py:833:        filter="version<=12", max_results=2, order_by=["version DESC"], page_token="prev"
tests/server/test_handlers.py:838:        filter_string="version<=12", max_results=2, order_by=["version DESC"], page_token="prev"
tests/server/test_handlers.py:842:        "next_page_token": "next",
tests/server/test_handlers.py:1115:            "page_token": "token123",
tests/server/test_handlers.py:1125:        page_token="token123",
tests/server/test_handlers.py:1233:        dataset_id, max_results=1000, page_token=None
tests/server/test_handlers.py:1247:            "page_token": None,
tests/server/test_handlers.py:1253:        dataset_id, max_results=2, page_token=None
tests/server/test_handlers.py:1259:    assert response_data["next_page_token"] == "token_page2"
tests/server/test_handlers.py:1267:            "page_token": "token_page2",
tests/server/test_handlers.py:1273:        dataset_id, max_results=2, page_token="token_page2"
tests/server/test_handlers.py:1279:    assert "next_page_token" not in response_data or response_data["next_page_token"] == ""
tests/server/test_handlers.py:1292:    assert "next_page_token" not in response_data or response_data["next_page_token"] == ""
tests/server/test_handlers.py:1326:        dataset_id, max_results=20, page_token=None
tests/server/test_handlers.py:1332:    assert response_data["next_page_token"] == "token_20"
tests/server/test_handlers.py:1339:        json={"max_results": 20, "page_token": "token_20"},
tests/server/test_handlers.py:1344:        dataset_id, max_results=20, page_token="token_20"
tests/server/test_handlers.py:1350:    assert response_data["next_page_token"] == "token_40"
tests/server/test_handlers.py:1356:        json={"max_results": 20, "page_token": "token_40"},
tests/server/test_handlers.py:1363:    assert "next_page_token" not in response_data or response_data["next_page_token"] == ""
tests/server/test_handlers.py:1764:def test_search_experiments_empty_page_token(mock_get_request_message, mock_tracking_store):
tests/server/test_handlers.py:1765:    """Test that _search_experiments converts empty page_token to None."""
tests/server/test_handlers.py:1766:    # Create proto without setting page_token - it defaults to empty string
tests/server/test_handlers.py:1770:    # Verify that proto's default page_token is empty string
tests/server/test_handlers.py:1771:    assert search_experiments_proto.page_token == ""
tests/server/test_handlers.py:1778:    # Verify that search_experiments was called with page_token=None (not empty string)
tests/server/test_handlers.py:1781:    assert call_kwargs.get("page_token") is None
tests/server/test_handlers.py:1785:def test_search_registered_models_empty_page_token(
tests/server/test_handlers.py:1788:    """Test that _search_registered_models converts empty page_token to None."""
tests/server/test_handlers.py:1789:    # Create proto without setting page_token - it defaults to empty string
tests/server/test_handlers.py:1793:    # Verify that proto's default page_token is empty string
tests/server/test_handlers.py:1794:    assert search_registered_models_proto.page_token == ""
tests/server/test_handlers.py:1801:    # Verify that search_registered_models was called with page_token=None (not empty string)
tests/server/test_handlers.py:1804:    assert call_kwargs.get("page_token") is None
tests/server/test_handlers.py:1808:def test_search_model_versions_empty_page_token(
tests/server/test_handlers.py:1811:    """Test that _search_model_versions converts empty page_token to None."""
tests/server/test_handlers.py:1812:    # Create proto without setting page_token - it defaults to empty string
tests/server/test_handlers.py:1816:    # Verify that proto's default page_token is empty string
tests/server/test_handlers.py:1817:    assert search_model_versions_proto.page_token == ""
tests/server/test_handlers.py:1824:    # Verify that search_model_versions was called with page_token=None (not empty string)
tests/server/test_handlers.py:1827:    assert call_kwargs.get("page_token") is None
tests/server/test_handlers.py:1831:def test_search_traces_v3_empty_page_token(mock_get_request_message, mock_tracking_store):
tests/server/test_handlers.py:1832:    """Test that _search_traces_v3 converts empty page_token to None."""
tests/server/test_handlers.py:1833:    # Create proto without setting page_token - it defaults to empty string
tests/server/test_handlers.py:1841:    # Verify that proto's default page_token is empty string
tests/server/test_handlers.py:1842:    assert search_traces_proto.page_token == ""
tests/server/test_handlers.py:1849:    # Verify that search_traces was called with page_token=None (not empty string)
tests/server/test_handlers.py:1852:    assert call_kwargs.get("page_token") is None
tests/server/test_handlers.py:1856:def test_deprecated_search_traces_v2_empty_page_token(
tests/server/test_handlers.py:1859:    """Test that _deprecated_search_traces_v2 converts empty page_token to None."""
tests/server/test_handlers.py:1860:    # Create proto without setting page_token - it defaults to empty string
tests/server/test_handlers.py:1864:    # Verify that proto's default page_token is empty string
tests/server/test_handlers.py:1865:    assert search_traces_proto.page_token == ""
tests/server/test_handlers.py:1872:    # Verify that search_traces was called with page_token=None (not empty string)
tests/server/test_handlers.py:1875:    assert call_kwargs.get("page_token") is None
tests/server/test_handlers.py:1879:def test_search_logged_models_empty_page_token(mock_get_request_message, mock_tracking_store):
tests/server/test_handlers.py:1880:    """Test that _search_logged_models converts empty page_token to None."""
tests/server/test_handlers.py:1881:    # Create proto without setting page_token - it defaults to empty string
tests/server/test_handlers.py:1885:    # Verify that proto's default page_token is empty string
tests/server/test_handlers.py:1886:    assert search_logged_models_proto.page_token == ""
tests/server/test_handlers.py:1893:    # Verify that search_logged_models was called with page_token=None (not empty string)
tests/server/test_handlers.py:1896:    assert call_kwargs.get("page_token") is None
tests/server/test_handlers.py:1900:def test_list_webhooks_empty_page_token(mock_get_request_message, mock_model_registry_store):
tests/server/test_handlers.py:1901:    """Test that _list_webhooks converts empty page_token to None."""
tests/server/test_handlers.py:1902:    # Create proto without setting page_token - it defaults to empty string
tests/server/test_handlers.py:1906:    # Verify that proto's default page_token is empty string
tests/server/test_handlers.py:1907:    assert list_webhooks_proto.page_token == ""
tests/server/test_handlers.py:1914:    # Verify that list_webhooks was called with page_token=None (not empty string)
tests/server/test_handlers.py:1917:    assert call_kwargs.get("page_token") is None
tests/tracking/test_client.py:403:        page_token=None,
tests/tracking/test_client.py:450:        page_token=None,
tests/tracking/test_client.py:502:        page_token=None,
tests/tracking/test_client.py:545:        page_token=None,
tests/tracking/test_client.py:595:        page_token=None,
tests/tracking/test_client.py:1291:        page_token=None,
tests/tracking/test_client.py:1303:        page_token=None,
tests/tracking/test_client.py:1315:        page_token=None,
tests/tracking/test_client.py:1327:        page_token=None,
tests/tracking/test_client.py:1339:        page_token=None,
tests/tracking/test_client.py:1351:        page_token=None,
tests/tracking/test_client.py:1363:        page_token=None,
tests/tracking/test_client.py:1367:def test_client_search_runs_page_token(mock_store):
tests/tracking/test_client.py:1368:    MlflowClient().search_runs([5], page_token="blah")
tests/tracking/test_client.py:1375:        page_token="blah",
tests/tracking/test_client.py:3244:        page_token="page_token_123",
tests/tracking/test_client.py:3257:        page_token="page_token_123",
tests/tracking/test_client.py:3285:        page_token=None,
tests/tracking/fluent/test_fluent.py:1995:            page_token=None,
tests/tracking/fluent/test_fluent.py:2024:                page_token=None,
tests/tracking/fluent/test_fluent.py:2032:                page_token="token_1",
tests/tracking/fluent/test_fluent.py:2057:            page_token=None,
tests/tracking/test_mlflow_artifacts.py:21:def _launch_server(host, port, backend_store_uri, default_artifact_root, artifacts_destination):
tests/tracking/test_mlflow_artifacts.py:34:        "--artifacts-destination",
tests/tracking/test_mlflow_artifacts.py:35:        artifacts_destination,
tests/tracking/test_mlflow_artifacts.py:46:    artifacts_destination: str
tests/tracking/test_mlflow_artifacts.py:56:        artifacts_destination = os.path.join(tmpdir, "mlartifacts")
tests/tracking/test_mlflow_artifacts.py:64:            ("file:///" + artifacts_destination if is_windows() else artifacts_destination),
tests/tracking/test_mlflow_artifacts.py:67:            backend_store_uri, default_artifact_root, artifacts_destination, url, process
tests/tracking/test_mlflow_artifacts.py:96:    artifacts_destination = artifacts_server.artifacts_destination
tests/tracking/test_mlflow_artifacts.py:102:    assert os.path.exists(os.path.join(artifacts_destination, "a.txt"))
tests/tracking/test_mlflow_artifacts.py:103:    assert read_file(os.path.join(artifacts_destination, "a.txt")) == "0"
tests/tracking/test_mlflow_artifacts.py:108:    assert os.path.join(artifacts_destination, "dir", "b.txt")
tests/tracking/test_mlflow_artifacts.py:109:    assert read_file(os.path.join(artifacts_destination, "dir", "b.txt")) == "1"
tests/tracking/test_mlflow_artifacts.py:136:    artifacts_destination = artifacts_server.artifacts_destination
tests/tracking/test_mlflow_artifacts.py:147:        artifacts_destination, experiment_id, run.info.run_id, "artifacts"
tests/tracking/test_mlflow_artifacts.py:157:        artifacts_destination, experiment_id, run.info.run_id, "artifacts"
tests/tracking/test_mlflow_artifacts.py:318:    artifact_file = pathlib.Path(artifacts_server.artifacts_destination, "a.txt")
tests/tracking/test_rest_tracking.py:192:        max_results=1, view_type=ViewType.ALL, page_token=all_exps_paginated.token
tests/tracking/test_rest_tracking.py:884:    result = mlflow_client.search_runs([experiment_id], max_results=4, page_token=None)
tests/tracking/test_rest_tracking.py:887:    result = mlflow_client.search_runs([experiment_id], max_results=4, page_token=result.token)
tests/tracking/test_rest_tracking.py:890:    result = mlflow_client.search_runs([experiment_id], max_results=4, page_token=result.token)
tests/tracking/test_rest_tracking.py:961:    # page_token
tests/tracking/test_rest_tracking.py:962:    experiments = mlflow_client.search_experiments(page_token=experiments.token)
tests/tracking/test_rest_tracking.py:1208:def test_get_metric_history_with_page_token(mlflow_client):
tests/tracking/test_rest_tracking.py:1209:    experiment_id = mlflow_client.create_experiment("test page_token")
tests/tracking/test_rest_tracking.py:1233:    first_token = first_data.get("next_page_token")
tests/tracking/test_rest_tracking.py:1244:            "page_token": first_token,
tests/tracking/test_rest_tracking.py:1250:    second_token = second_data.get("next_page_token")
tests/tracking/test_rest_tracking.py:1261:            "page_token": second_token,
tests/tracking/test_rest_tracking.py:1267:    third_token = third_data.get("next_page_token")
tests/tracking/test_rest_tracking.py:1287:    # Test with invalid page_token
tests/tracking/test_rest_tracking.py:1293:            "page_token": "invalid_token",
tests/tracking/test_rest_tracking.py:2645:        page_token=traces.token,
tests/tracking/test_rest_tracking.py:2729:    time.sleep(0.1)  # Add some time gap to avoid timestamp collision
tests/tracking/test_rest_tracking.py:3214:        experiment_ids=[exp_id], max_results=1, page_token=page_1.token
tests/tracking/_model_registry/test_model_registry_client.py:139:        page_token="next one",
tests/tracking/_model_registry/test_model_registry_client.py:419:        "version <= 2", max_results=2, order_by="version DESC", page_token="next"
tests/tracking/_model_registry/test_model_registry_client.py:554:        page_token="prev_token",
tests/tracking/test_client_webhooks.py:122:    next_webhooks_page = client.list_webhooks(max_results=2, page_token=webhooks_page.token)
tests/tracking/test_model_registry.py:143:            filter_string=filter_string, max_results=max_results, page_token=tok
tests/tracking/test_model_registry.py:323:            page_token=tok,
tests/tracking/test_model_registry.py:357:            page_token=tok,
tests/tracking/test_model_registry.py:412:            page_token=tok,
tests/utils/test_name_utils.py:19:    # validate that in 1 million experiments written to a set, no collisions occur
tests/utils/test_search_utils.py:593:    ("page_token", "max_results", "matching_runs", "expected_next_page_token"),
tests/utils/test_search_utils.py:608:def test_pagination(page_token, max_results, matching_runs, expected_next_page_token):
tests/utils/test_search_utils.py:647:    encoded_page_token = None
tests/utils/test_search_utils.py:648:    if page_token:
tests/utils/test_search_utils.py:649:        encoded_page_token = base64.b64encode(json.dumps(page_token).encode("utf-8"))
tests/utils/test_search_utils.py:650:    paginated_runs, next_page_token = SearchUtils.paginate(runs, encoded_page_token, max_results)
tests/utils/test_search_utils.py:660:    decoded_next_page_token = None
tests/utils/test_search_utils.py:661:    if next_page_token:
tests/utils/test_search_utils.py:662:        decoded_next_page_token = json.loads(base64.b64decode(next_page_token))
tests/utils/test_search_utils.py:663:    assert decoded_next_page_token == expected_next_page_token
tests/utils/test_search_utils.py:667:    ("page_token", "error_message"),
tests/utils/test_search_utils.py:676:def test_invalid_page_tokens(page_token, error_message):
tests/utils/test_search_utils.py:678:        SearchUtils.paginate([], page_token, 1)
tests/helper_functions.py:51:        "UUID4 generated strings have a high potential for collision at small sizes. "
tests/crewai/test_crewai_autolog.py:123:_AGENT_1_BACKSTORY = "An expert in analyzing travel data to pick ideal destinations"
tests/uc_oss/test_uc_oss_integration.py:109:    #      destination path
tests/deployments/mlflow/test_mlflow.py:103:            "next_page_token": "token",
tests/cli/test_traces.py:61:    assert "page_token" in param_names
tests/store/artifact/test_presigned_url_artifact_repo.py:55:        {"page_token": "some_token"}
tests/store/artifact/test_presigned_url_artifact_repo.py:67:            next_page_token="some_token",
tests/store/artifact/test_models_artifact_repo.py:215:        # Use another temporary directory as the download destination
tests/store/artifact/test_databricks_artifact_repo.py:655:        root_uri="", files=list_artifacts_dir_proto_mock, next_page_token=None
tests/store/artifact/test_databricks_artifact_repo.py:702:            root_uri="", files=list_artifacts_dir_proto_mock, next_page_token=None
tests/store/artifact/test_databricks_artifact_repo.py:727:                root_uri="", files=list_artifact_file_proto_mock, next_page_token=None
tests/store/artifact/test_databricks_artifact_repo.py:749:        ListArtifacts.Response(root_uri="", files=list_artifacts_proto_mock_1, next_page_token="2"),
tests/store/artifact/test_databricks_artifact_repo.py:750:        ListArtifacts.Response(root_uri="", files=list_artifacts_proto_mock_2, next_page_token="4"),
tests/store/artifact/test_databricks_artifact_repo.py:751:        ListArtifacts.Response(root_uri="", files=list_artifacts_proto_mock_3, next_page_token="6"),
tests/store/artifact/test_databricks_artifact_repo.py:752:        ListArtifacts.Response(root_uri="", files=list_artifacts_proto_mock_4, next_page_token="8"),
tests/store/artifact/test_databricks_artifact_repo.py:767:            mock.call(ListArtifacts(run_id=MOCK_RUN_ID, path="", page_token="2")),
tests/store/artifact/test_databricks_artifact_repo.py:768:            mock.call(ListArtifacts(run_id=MOCK_RUN_ID, path="", page_token="4")),
tests/store/artifact/test_databricks_artifact_repo.py:769:            mock.call(ListArtifacts(run_id=MOCK_RUN_ID, path="", page_token="6")),
tests/store/artifact/test_databricks_artifact_repo.py:796:            credential_infos=credential_infos_mock_1, next_page_token="2"
tests/store/artifact/test_databricks_artifact_repo.py:799:            credential_infos=credential_infos_mock_2, next_page_token="3"
tests/store/artifact/test_databricks_artifact_repo.py:820:                    GetCredentialsForRead(run_id=MOCK_RUN_ID, path=["testpath"], page_token="2")
tests/store/artifact/test_databricks_artifact_repo.py:823:                    GetCredentialsForRead(run_id=MOCK_RUN_ID, path=["testpath"], page_token="3")
tests/store/artifact/test_databricks_artifact_repo.py:914:            credential_infos=credential_infos_mock_1, next_page_token="2"
tests/store/artifact/test_databricks_artifact_repo.py:917:            credential_infos=credential_infos_mock_2, next_page_token="3"
tests/store/artifact/test_databricks_artifact_repo.py:938:                    GetCredentialsForWrite(run_id=MOCK_RUN_ID, path=["testpath"], page_token="2")
tests/store/artifact/test_databricks_artifact_repo.py:941:                    GetCredentialsForWrite(run_id=MOCK_RUN_ID, path=["testpath"], page_token="3")
tests/store/artifact/test_artifact_repo.py:111:        MlflowException, match="The destination path for downloaded artifacts does not exist"
tests/store/artifact/test_artifact_repo.py:121:        MlflowException, match="The destination path for downloaded artifacts must be a directory"
tests/store/tracking/test_file_store_logged_model.py:1040:    models = store.search_logged_models(experiment_ids=[exp_id], page_token=models.token)
tests/store/tracking/test_file_store.py:420:    experiments = store.search_experiments(max_results=4, page_token=experiments.token)
tests/store/tracking/test_file_store.py:424:    experiments = store.search_experiments(max_results=4, page_token=experiments.token)
tests/store/tracking/test_file_store.py:1218:def test_get_metric_history_with_page_token(store):
mlflow/gateway/utils.py:13:from mlflow.environment_variables import MLFLOW_GATEWAY_URI
mlflow/environment_variables.py:451:MLFLOW_GATEWAY_URI = _EnvironmentVariable("MLFLOW_GATEWAY_URI", str, None)
mlflow/gateway/providers/anthropic.py:36:                detail="Invalid value for max_tokens: cannot exceed "
mlflow/gateway/providers/anthropic.py:276:                detail="Invalid value for max_tokens: cannot exceed "
mlflow/genai/judges/tools/utils.py:16:    Create a page token from an offset value.
mlflow/genai/judges/tools/utils.py:22:        String representation of the offset to use as a page token
mlflow/genai/judges/tools/utils.py:30:    Parse a page token to extract the offset value.
mlflow/genai/judges/tools/utils.py:33:        page_token: The page token string to parse, or None
mlflow/genai/judges/tools/utils.py:48:            f"Invalid page_token '{page_token}': must be a valid integer",
mlflow/genai/judges/tools/list_spans.py:109:            ListSpansResult containing spans list and optional next page token
mlflow/genai/judges/tools/list_spans.py:124:        # Determine next page token - only include if there are more pages
mlflow/server/auth/__init__.py:886:        # recalculate next page token
mlflow/server/auth/__init__.py:1014:        # recalculate next page token
mlflow/utils/search_logged_model_utils.py:102:                    f"Invalid comparison: {stmt}. Expected a comparison with 3 tokens."
mlflow/utils/search_utils.py:78:                        f"Invalid comparison clause with token `{first}, {second}, {third}`, "
mlflow/utils/search_utils.py:498:    def _invalid_statement_token_search_runs(cls, token):
mlflow/utils/search_utils.py:511:        invalids = list(filter(cls._invalid_statement_token_search_runs, tokens))
mlflow/utils/search_utils.py:513:            invalid_clauses = ", ".join(f"'{token}'" for token in invalids)
mlflow/utils/search_utils.py:789:                f"Invalid order by key '{token_value}' specified. Valid keys "
mlflow/utils/search_utils.py:893:                "Invalid page token, could not base64-decode", error_code=INVALID_PARAMETER_VALUE
mlflow/utils/search_utils.py:897:                "Invalid page token, could not base64-decode", error_code=INVALID_PARAMETER_VALUE
mlflow/utils/search_utils.py:904:                f"Invalid page token, decoded value={decoded_token}",
mlflow/utils/search_utils.py:911:                f"Invalid page token, parsed value={parsed_token}",
mlflow/utils/search_utils.py:919:                f"Invalid page token, not stringable {offset_str}",
mlflow/utils/search_utils.py:999:    def _invalid_statement_token_search_experiments(cls, token):
mlflow/utils/search_utils.py:1011:        invalids = list(filter(cls._invalid_statement_token_search_experiments, tokens))
mlflow/utils/search_utils.py:1265:        invalids = list(filter(cls._invalid_statement_token_search_model_registry, tokens))
mlflow/utils/search_utils.py:1346:    def _invalid_statement_token_search_model_registry(cls, token):
mlflow/utils/search_utils.py:1549:        invalids = list(filter(cls._invalid_statement_token_search_model_version, tokens))
mlflow/utils/search_utils.py:1558:    def _invalid_statement_token_search_model_version(cls, token):
mlflow/utils/search_utils.py:1979:        invalids = list(filter(cls._invalid_statement_token_search_traces, tokens))
mlflow/utils/search_utils.py:1981:            invalid_clauses = ", ".join(f"'{token}'" for token in invalids)
mlflow/utils/search_utils.py:1989:    def _invalid_statement_token_search_traces(cls, token):
mlflow/utils/search_utils.py:2028:    def _invalid_statement_token(cls, token):
mlflow/utils/search_utils.py:2040:        invalids = list(filter(cls._invalid_statement_token, tokens))
mlflow/utils/search_utils.py:2064:                    f"Invalid identifier token '{tokens[0]}' specified"
mlflow/utils/search_utils.py:2318:            raise MlflowException.invalid_parameter_value(f"Invalid page token: {token}. {e}")
mlflow/utils/search_utils.py:2335:                f"Experiment IDs in the page token do not match the requested experiment IDs. "
mlflow/utils/search_utils.py:2341:                f"Filter string in the page token does not match the requested filter string. "
mlflow/utils/search_utils.py:2347:                f"Order by in the page token does not match the requested order by. "
mlflow/cli/traces.py:370:            click.echo(f"\nNext page token: {traces.token}")
mlflow/store/tracking/sqlalchemy_store.py:4728:            raise MlflowException.invalid_parameter_value(f"Invalid token type: {type_}")
mlflow/store/tracking/sqlalchemy_store.py:4985:            raise MlflowException.invalid_parameter_value(f"Invalid token type: {type_}")
mlflow/store/model_registry/sqlalchemy_store.py:412:                    f"Invalid token type: {type_}", error_code=INVALID_PARAMETER_VALUE
mlflow/store/model_registry/sqlalchemy_store.py:504:                    f"Invalid token type: {type_}", error_code=INVALID_PARAMETER_VALUE
mlflow/store/model_registry/sqlalchemy_store.py:605:                        f"Invalid order by key '{attribute_token}' specified."
tests/gateway/providers/test_ai21labs.py:141:    assert "Invalid parameter maxTokens. Use max_tokens instead." in e.value.detail
tests/gateway/providers/test_mosaicml.py:522:async def test_completions_raises_with_invalid_max_tokens_too_large():
tests/gateway/providers/test_mosaicml.py:547:async def test_chat_raises_with_invalid_max_tokens_too_large():
tests/gateway/providers/test_gemini.py:259:        ({"maxOutputTokens": 50}, [], "Invalid parameter maxOutputTokens. Use max_tokens instead."),
tests/gateway/providers/test_gemini.py:369:            "Invalid parameter maxOutputTokens. Use max_tokens instead.",
tests/gateway/providers/test_anthropic.py:122:async def test_completions_throws_with_invalid_max_tokens_too_large():
tests/gateway/providers/test_anthropic.py:129:        "Invalid value for max_tokens: cannot exceed "
tests/genai/judges/test_judge_tool_get_root_span.py:224:def test_get_root_span_tool_invoke_invalid_page_token():
tests/genai/judges/test_judge_tool_get_root_span.py:225:    """Test that invalid page tokens raise MlflowException."""
tests/genai/judges/test_judge_tool_get_root_span.py:249:    # Test with invalid string token - should raise exception
tests/genai/judges/test_judge_tool_get_root_span.py:251:        MlflowException, match="Invalid page_token 'invalid': must be a valid integer"
tests/genai/judges/test_judge_tool_get_root_span.py:255:    # Test with non-string invalid token - should raise exception
tests/genai/judges/test_judge_tool_get_root_span.py:257:        MlflowException, match="Invalid page_token '\\[\\]': must be a valid integer"
tests/genai/judges/test_judge_tool_get_span.py:199:def test_get_span_tool_invoke_invalid_page_token():
tests/genai/judges/test_judge_tool_get_span.py:200:    """Test that invalid page tokens raise MlflowException."""
tests/genai/judges/test_judge_tool_get_span.py:224:    # Test with invalid string token - should raise exception
tests/genai/judges/test_judge_tool_get_span.py:226:        MlflowException, match="Invalid page_token 'invalid': must be a valid integer"
tests/genai/judges/test_judge_tool_get_span.py:230:    # Test with non-string invalid token - should raise exception
tests/genai/judges/test_judge_tool_get_span.py:232:        MlflowException, match="Invalid page_token '\\[\\]': must be a valid integer"
tests/genai/judges/test_judge_tool_list_spans.py:144:def test_list_spans_tool_invoke_invalid_page_token(mock_trace_with_spans):
tests/genai/judges/test_judge_tool_list_spans.py:145:    """Test that invalid page tokens raise MlflowException."""
tests/genai/judges/test_judge_tool_list_spans.py:150:    # Test with invalid string token - should raise exception
tests/genai/judges/test_judge_tool_list_spans.py:152:        MlflowException, match="Invalid page_token 'invalid': must be a valid integer"
tests/genai/judges/test_judge_tool_list_spans.py:156:    # Test with non-string invalid token - should raise exception
tests/genai/judges/test_judge_tool_list_spans.py:158:        MlflowException, match="Invalid page_token '\\[\\]': must be a valid integer"
tests/server/auth/test_auth.py:142:    # invalid token
tests/tracking/test_rest_tracking.py:1287:    # Test with invalid page_token
tests/tracking/test_rest_tracking.py:1293:            "page_token": "invalid_token",
tests/utils/test_search_utils.py:669:        (base64.b64encode(json.dumps({}).encode("utf-8")), "Invalid page token"),
tests/utils/test_search_utils.py:670:        (base64.b64encode(json.dumps({"offset": "a"}).encode("utf-8")), "Invalid page token"),
tests/utils/test_search_utils.py:671:        (base64.b64encode(json.dumps({"offsoot": 7}).encode("utf-8")), "Invalid page token"),
tests/utils/test_search_utils.py:672:        (base64.b64encode(b"not json"), "Invalid page token"),
tests/utils/test_search_utils.py:673:        ("not base64", "Invalid page token"),
tests/utils/test_search_utils.py:676:def test_invalid_page_tokens(page_token, error_message):
tests/store/tracking/test_file_store.py:1259:    # Test with invalid page_token
tests/store/tracking/test_file_store.py:1260:    with pytest.raises(MlflowException, match="Invalid page token"):
tests/store/tracking/test_file_store.py:1261:        store.get_metric_history(run_id, metric_key, page_token="invalid_token")
tests/store/tracking/test_sqlalchemy_store.py:1679:    # Test with invalid page_token
tests/store/tracking/test_sqlalchemy_store.py:1680:    with pytest.raises(MlflowException, match="Invalid page token"):
tests/store/tracking/test_sqlalchemy_store.py:1681:        store.get_metric_history(run_id, metric_key, page_token="invalid_token")
tests/store/tracking/test_sqlalchemy_store.py:8274:    # Search params must match the page token
tests/store/tracking/test_sqlalchemy_store.py:8276:    with pytest.raises(MlflowException, match="Experiment IDs in the page token do not match"):
tests/store/tracking/test_sqlalchemy_store.py:8279:    with pytest.raises(MlflowException, match="Order by in the page token does not match"):
tests/store/tracking/test_sqlalchemy_store.py:8286:    with pytest.raises(MlflowException, match="Filter string in the page token does not match"):
tests/store/model_registry/test_file_store.py:213:    # test that providing a completely invalid page token throws
tests/store/model_registry/test_file_store.py:215:        MlflowException, match=r"Invalid page token, could not base64-decode"
tests/store/model_registry/test_file_store.py:932:    # assert that page token is None
tests/store/model_registry/test_file_store.py:936:    # test that providing a completely invalid page token throws
tests/store/model_registry/test_file_store.py:938:        MlflowException, match=r"Invalid page token, could not base64-decode"
tests/store/model_registry/test_file_store.py:1230:    # assert that page token is None
tests/store/model_registry/test_file_store.py:1234:    # test that providing a completely invalid page token throws
tests/store/model_registry/test_file_store.py:1236:        MlflowException, match=r"Invalid page token, could not base64-decode"
tests/store/model_registry/test_sqlalchemy_store.py:1051:    # assert that page token is None
tests/store/model_registry/test_sqlalchemy_store.py:1055:    # test that providing a completely invalid page token throws
tests/store/model_registry/test_sqlalchemy_store.py:1057:        MlflowException, match=r"Invalid page token, could not base64-decode"
tests/store/model_registry/test_sqlalchemy_store.py:1354:    # assert that page token is None
tests/store/model_registry/test_sqlalchemy_store.py:1358:    # test that providing a completely invalid page token throws
tests/store/model_registry/test_sqlalchemy_store.py:1360:        MlflowException, match=r"Invalid page token, could not base64-decode"
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "grep -nE \"duplicate|collision|traffic|destination|route.*name|endpoint.*name\" tests/gateway/test_gateway_config_parsing.py; sed -n '140,520p' tests/gateway/test_gateway_config_parsing.py; sed -n '1,460p' tests/gateway/test_gateway_app.py; grep -RIn \"set_gateway_uri\\|get_gateway_uri\\|resolve_route_url\\|SearchRoutesToken\" tests/gateway --include='*.py'"
```

退出码：`1`

输出：
```
186:        route = [x for x in routes if x.name == config.name][0]
188:        assert route.model.name == config.model.name
341:    "route_name", ["Space Name", "bang!name", "query?name", "redirect#name", "bracket[]name"]
343:def test_invalid_route_name(tmp_path, route_name):
347:                "name": route_name,
364:        MlflowException, match="The route name provided contains disallowed characters"
390:def test_duplicate_routes_in_config(tmp_path):
    completions_gpt4 = loaded_from_save.endpoints[0]
    assert completions_gpt4.name == "completions-gpt4"
    assert completions_gpt4.endpoint_type == "llm/v1/completions"
    assert completions_gpt4.model.name == "gpt-4"
    assert completions_gpt4.model.provider == "openai"
    completions_conf = completions_gpt4.model.config
    assert isinstance(completions_conf, OpenAIConfig)
    assert completions_conf.openai_api_key == "mykey"
    assert completions_conf.openai_api_base == "https://api.openai.com/v1"
    assert completions_conf.openai_api_version == "2023-05-10"
    assert completions_conf.openai_api_type == "openai"
    assert completions_conf.openai_organization == "my_company"

    chat_gpt4 = loaded_from_save.endpoints[1]
    assert chat_gpt4.name == "chat-gpt4"
    assert chat_gpt4.endpoint_type == "llm/v1/chat"
    assert chat_gpt4.model.name == "gpt-4"
    assert chat_gpt4.model.provider == "openai"
    chat_conf = chat_gpt4.model.config
    assert isinstance(chat_conf, OpenAIConfig)
    assert chat_conf.openai_api_key == "sk-openai"
    assert chat_conf.openai_api_base == "https://api.openai.com/v1"
    assert chat_conf.openai_api_type == "openai"
    assert chat_conf.openai_api_version is None
    assert chat_conf.openai_organization is None

    claude = loaded_from_save.endpoints[2]
    assert isinstance(claude.model.config, AnthropicConfig)
    assert claude.name == "claude-chat"
    assert claude.endpoint_type == "llm/v1/chat"
    assert claude.model.name == "claude-v1"
    assert claude.model.provider == "anthropic"
    claude_conf = claude.model.config
    assert claude_conf.anthropic_api_key == "api_key"


def test_convert_route_config_to_routes_payload(basic_config_dict, tmp_path):
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(basic_config_dict))
    loaded = _load_gateway_config(conf_path)

    assert all(isinstance(route, EndpointConfig) for route in loaded.endpoints)

    routes = [r.to_endpoint() for r in loaded.endpoints]

    for config in loaded.endpoints:
        route = [x for x in routes if x.name == config.name][0]
        assert route.endpoint_type == config.endpoint_type
        assert route.model.name == config.model.name
        assert route.model.provider == config.model.provider
        # Pydantic doesn't allow undefined elements to be a part of its serialized object.
        # This test is a guard for devs only in case we inadvertently add sensitive keys to the
        # Route definition that would be returned via the GetRoute or SearchRoutes APIs
        assert not hasattr(route.model, "config")


def test_invalid_route_definition(tmp_path):
    invalid_conf = {
        "endpoints": [
            {
                "name": "invalid_route",
                "endpoint_type": "invalid/route",
                "model": {
                    "name": "gpt-4",
                    "provider": "openai",
                    "config": {
                        "openai_api_key": "mykey",
                        "openai_api_base": "https://api.openai.com/v1",
                        "openai_api_version": "2023-05-10",
                        "openai_api_type": "openai/v1/chat/completions",
                        "openai_organization": "my_company",
                    },
                },
            }
        ]
    }
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_conf))

    with pytest.raises(MlflowException, match=r"The route_type 'invalid/route' is not supported."):
        _load_gateway_config(conf_path)


def test_invalid_provider(tmp_path):
    invalid_conf = {
        "endpoints": [
            {
                "name": "invalid_route",
                "endpoint_type": "llm/v1/completions",
                "model": {
                    "name": "gpt-4",
                    "provider": "my_provider",
                    "config": {
                        "openai_api_key": "mykey",
                        "openai_api_base": "https://api.openai.com/v1",
                        "openai_api_version": "2023-05-10",
                        "openai_api_type": "openai/v1/chat/completions",
                        "openai_organization": "my_company",
                    },
                },
            }
        ]
    }
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_conf))

    with pytest.raises(MlflowException, match=r"The provider 'my_provider' is not supported."):
        _load_gateway_config(conf_path)


def test_invalid_model_definition(tmp_path):
    invalid_partial_config = {
        "endpoints": [
            {
                "name": "some_name",
                "endpoint_type": "llm/v1/completions",
                "model": {
                    "name": "invalid",
                    "provider": "openai",
                    "config": {"openai_api_type": "openai"},
                },
            }
        ]
    }

    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_partial_config))

    with pytest.raises(
        MlflowException, match=re.compile(r"validation error.+openai_api_key", re.DOTALL)
    ):
        _load_gateway_config(conf_path)

    invalid_format_config_key_is_not_string = {
        "endpoints": [
            {
                "name": "some_name",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "invalid",
                    "provider": "openai",
                    "config": {"openai_api_type": "openai", "openai_api_key": [42]},
                },
            }
        ]
    }

    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_format_config_key_is_not_string))

    with pytest.raises(
        MlflowException,
        match="The api key provided is not a string",
    ):
        _load_gateway_config(conf_path)

    invalid_format_config_key_invalid_path = {
        "endpoints": [
            {
                "name": "some_name",
                "endpoint_type": "llm/v1/embeddings",
                "model": {
                    "name": "invalid",
                    "provider": "openai",
                    "config": {"openai_api_type": "openai", "openai_api_key": "/not/a/real/path"},
                },
            }
        ]
    }

    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_format_config_key_invalid_path))

    assert (
        _load_gateway_config(conf_path).endpoints[0].model.config.openai_api_key
        == "/not/a/real/path"  # pylint: disable=line-too-long
    )

    invalid_no_config = {
        "endpoints": [
            {
                "name": "some_name",
                "endpoint_type": "llm/v1/embeddings",
                "model": {
                    "name": "invalid",
                    "provider": "anthropic",
                },
            }
        ]
    }
    conf_path = tmp_path.joinpath("config2.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_no_config))

    with pytest.raises(
        MlflowException,
        match="A config must be supplied when setting a provider. The provider entry",
    ):
        _load_gateway_config(conf_path)


@pytest.mark.parametrize(
    "route_name", ["Space Name", "bang!name", "query?name", "redirect#name", "bracket[]name"]
)
def test_invalid_route_name(tmp_path, route_name):
    bad_name = {
        "endpoints": [
            {
                "name": route_name,
                "endpoint_type": "bad/naming",
                "model": {
                    "name": "claude-v1",
                    "provider": "anthropic",
                    "config": {
                        "anthropic_api_key": "claudekey",
                    },
                },
            }
        ]
    }

    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(bad_name))

    with pytest.raises(
        MlflowException, match="The route name provided contains disallowed characters"
    ):
        _load_gateway_config(conf_path)


def test_default_base_api(tmp_path):
    route_no_base = {
        "endpoints": [
            {
                "name": "chat-gpt4",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "gpt-4",
                    "provider": "openai",
                    "config": {"openai_api_key": "sk-openai"},
                },
            },
        ]
    }
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(route_no_base))
    loaded_conf = _load_gateway_config(conf_path)

    assert loaded_conf.endpoints[0].model.config.openai_api_base == "https://api.openai.com/v1"


def test_duplicate_routes_in_config(tmp_path):
    route = {
        "endpoints": [
            {
                "name": "classifier",
                "endpoint_type": "llm/v1/classifier",
                "model": {
                    "name": "serving-endpoints/document-classifier/Production/invocations",
                    "provider": "databricks-model-serving",
                    "config": {
                        "databricks_api_token": "MY_TOKEN",
                        "databricks_api_base": "https://my-shard-001/",
                    },
                },
            },
            {
                "name": "classifier",
                "endpoint_type": "llm/v1/classifier",
                "model": {
                    "name": "serving-endpoints/document-classifier/Production/invocations",
                    "provider": "databricks_serving_endpoint",
                    "config": {
                        "databricks_api_token": "MY_TOKEN",
                        "databricks_api_base": "https://my-shard-001/",
                    },
                },
            },
        ]
    }
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(route))
    with pytest.raises(
        MlflowException, match="Duplicate names found in endpoint / route configurations"
    ):
        _load_gateway_config(conf_path)
from unittest import mock

import pytest
from fastapi.testclient import TestClient

from mlflow.exceptions import MlflowException
from mlflow.gateway.app import create_app_from_config, create_app_from_env
from mlflow.gateway.config import GatewayConfig
from mlflow.gateway.constants import (
    MLFLOW_GATEWAY_CRUD_ENDPOINT_V3_BASE,
    MLFLOW_GATEWAY_CRUD_ROUTE_BASE,
    MLFLOW_GATEWAY_CRUD_ROUTE_V3_BASE,
    MLFLOW_GATEWAY_ROUTE_BASE,
)

from tests.gateway.tools import MockAsyncResponse


@pytest.fixture
def client() -> TestClient:
    config = GatewayConfig(
        **{
            "endpoints": [
                {
                    "name": "completions-gpt4",
                    "endpoint_type": "llm/v1/completions",
                    "model": {
                        "name": "gpt-4",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "mykey",
                            "openai_api_base": "https://api.openai.com/v1",
                            "openai_api_version": "2023-05-10",
                            "openai_api_type": "openai",
                        },
                    },
                },
                {
                    "name": "chat-gpt4",
                    "endpoint_type": "llm/v1/chat",
                    "model": {
                        "name": "gpt-4",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "MY_API_KEY",
                        },
                    },
                },
                {
                    "name": "chat-gpt5",
                    "endpoint_type": "llm/v1/chat",
                    "model": {
                        "name": "gpt-5",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "MY_API_KEY",
                        },
                    },
                },
            ],
            "routes": [
                {
                    "name": "traffic_route1",
                    "task_type": "llm/v1/chat",
                    "destinations": [
                        {
                            "name": "chat-gpt4",
                            "traffic_percentage": 80,
                        },
                        {
                            "name": "chat-gpt5",
                            "traffic_percentage": 20,
                        },
                    ],
                },
            ],
        }
    )
    app = create_app_from_config(config)
    return TestClient(app)


def test_index(client: TestClient):
    response = client.get("/", follow_redirects=False)
    assert response.status_code == 307
    assert response.headers["Location"] == "/docs"


def test_health(client: TestClient):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "OK"}


def test_favicon(client: TestClient):
    response = client.get("/favicon.ico")
    assert response.status_code == 200


def test_docs(client: TestClient):
    response = client.get("/docs")
    assert response.status_code == 200


def test_search_routes(client: TestClient):
    response = client.get(MLFLOW_GATEWAY_CRUD_ROUTE_BASE)
    assert response.status_code == 200
    assert response.json()["routes"] == [
        {
            "name": "completions-gpt4",
            "route_type": "llm/v1/completions",
            "route_url": "/gateway/completions-gpt4/invocations",
            "model": {
                "name": "gpt-4",
                "provider": "openai",
            },
            "limit": None,
        },
        {
            "name": "chat-gpt4",
            "route_type": "llm/v1/chat",
            "route_url": "/gateway/chat-gpt4/invocations",
            "model": {
                "name": "gpt-4",
                "provider": "openai",
            },
            "limit": None,
        },
        {
            "name": "chat-gpt5",
            "route_type": "llm/v1/chat",
            "route_url": "/gateway/chat-gpt5/invocations",
            "model": {
                "name": "gpt-5",
                "provider": "openai",
            },
            "limit": None,
        },
    ]


def test_get_route(client: TestClient):
    response = client.get(f"{MLFLOW_GATEWAY_CRUD_ROUTE_BASE}chat-gpt4")
    assert response.status_code == 200
    assert response.json() == {
        "name": "chat-gpt4",
        "route_type": "llm/v1/chat",
        "route_url": "/gateway/chat-gpt4/invocations",
        "model": {
            "name": "gpt-4",
            "provider": "openai",
        },
        "limit": None,
    }


def test_get_endpoint_v3(client: TestClient):
    response = client.get(f"{MLFLOW_GATEWAY_CRUD_ENDPOINT_V3_BASE}chat-gpt4")
    assert response.status_code == 200
    assert response.json() == {
        "name": "chat-gpt4",
        "endpoint_type": "llm/v1/chat",
        "model": {"name": "gpt-4", "provider": "openai"},
        "endpoint_url": "/gateway/chat-gpt4/invocations",
        "limit": None,
    }


def test_get_route_v3(client: TestClient):
    response = client.get(f"{MLFLOW_GATEWAY_CRUD_ROUTE_V3_BASE}traffic_route1")
    assert response.status_code == 200
    assert response.json() == {
        "name": "traffic_route1",
        "task_type": "llm/v1/chat",
        "destinations": [
            {"name": "chat-gpt4", "traffic_percentage": 80},
            {"name": "chat-gpt5", "traffic_percentage": 20},
        ],
        "routing_strategy": "TRAFFIC_SPLIT",
    }


def test_dynamic_route():
    config = GatewayConfig(
        **{
            "endpoints": [
                {
                    "name": "chat",
                    "endpoint_type": "llm/v1/chat",
                    "model": {
                        "name": "gpt-4",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "mykey",
                            "openai_api_base": "https://api.openai.com/v1",
                        },
                    },
                    "limit": None,
                }
            ],
            "routes": [
                {
                    "name": "traffic_route",
                    "task_type": "llm/v1/chat",
                    "destinations": [
                        {
                            "name": "chat",
                            "traffic_percentage": 100,
                        }
                    ],
                }
            ],
        }
    )
    app = create_app_from_config(config)
    client = TestClient(app)

    resp = {
        "id": "chatcmpl-abc123",
        "object": "chat.completion",
        "created": 1677858242,
        "model": "gpt-4o-mini",
        "usage": {
            "prompt_tokens": 13,
            "completion_tokens": 7,
            "total_tokens": 20,
        },
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "\n\nThis is a test!",
                    "refusal": None,
                },
                "finish_reason": "stop",
                "index": 0,
            }
        ],
        "headers": {"Content-Type": "application/json"},
    }
    with mock.patch(
        "aiohttp.ClientSession.post", return_value=MockAsyncResponse(resp)
    ) as mock_post:
        for name in ["chat", "traffic_route"]:
            resp = client.post(
                f"{MLFLOW_GATEWAY_ROUTE_BASE}{name}/invocations",
                json={"messages": [{"role": "user", "content": "Tell me a joke"}]},
            )
            mock_post.assert_called_once()
            assert resp.status_code == 200
            assert resp.json() == {
                "id": "chatcmpl-abc123",
                "object": "chat.completion",
                "created": 1677858242,
                "model": "gpt-4o-mini",
                "usage": {
                    "prompt_tokens": 13,
                    "completion_tokens": 7,
                    "total_tokens": 20,
                },
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "\n\nThis is a test!",
                            "tool_calls": None,
                            "refusal": None,
                        },
                        "finish_reason": "stop",
                        "index": 0,
                    }
                ],
            }

            mock_post.reset_mock()


def test_create_app_from_env_fails_if_MLFLOW_GATEWAY_CONFIG_is_not_set(monkeypatch):
    monkeypatch.delenv("MLFLOW_GATEWAY_CONFIG", raising=False)
    with pytest.raises(MlflowException, match="'MLFLOW_GATEWAY_CONFIG' is not set"):
        create_app_from_env()
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc "git status --short; git diff -- mlflow/gateway/utils.py; grep -RIn \"Duplicate names found in endpoint / route configurations\\|traffic percentage\\|traffic_percentage\\|does not exist in endpoint\\|task type\" mlflow tests --include='*.py' 2>/dev/null | head -200; grep -RIn \"resolve_route_url\" mlflow --include='*.py'; grep -RIn \"assemble_uri_path\" mlflow --include='*.py'; grep -RIn \"gateway.utils import\" mlflow/gateway --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/dspy/save.py:98:        task: defaults to None. The task type of the model. Can only be `llm/v1/chat` or None for
mlflow/dspy/save.py:297:        task: defaults to None. The task type of the model. Can only be `llm/v1/chat` or None for
mlflow/gateway/config.py:436:    traffic_percentage: int
mlflow/gateway/app.py:99:                destination.traffic_percentage for destination in route_config.destinations
mlflow/utils/mlflow_tags.py:56:# Here MLFLOW_DATABRICKS_JOB_TYPE means the job task type and MLFLOW_DATABRICKS_JOB_TYPE_INFO
mlflow/transformers/signature.py:25:# Order is important here, the first matching task type will be used
mlflow/transformers/signature.py:128:        "An unsupported task type was supplied for signature inference. Either provide an "
mlflow/transformers/__init__.py:139:# Transformers pipeline complains that PeftModel is not supported for any task type, even
mlflow/transformers/__init__.py:371:        task: The transformers-specific task type of the model, or MLflow inference task type.
mlflow/transformers/__init__.py:372:            If provided a transformers-specific task type, these strings are utilized so
mlflow/transformers/__init__.py:375:            If this argument is provided as a inference task type or not specified, the
mlflow/transformers/__init__.py:377:            correct task type. If the value specified is not a supported type,
mlflow/transformers/__init__.py:516:                "checkpoint. Please provide the task type of the pipeline.",
mlflow/transformers/__init__.py:565:        # corresponding Transformers task type.
mlflow/transformers/__init__.py:598:            f"LLM v1 task type '{metadata_task}' is specified in "
mlflow/transformers/__init__.py:599:            "metadata, but it doesn't match the task type provided in the `task` argument: "
mlflow/transformers/__init__.py:600:            f"'{task}'. The mismatched task type may cause incorrect model inference behavior. "
mlflow/transformers/__init__.py:601:            "Please provide the correct LLM v1 task type in the `task` argument. E.g. "
mlflow/transformers/__init__.py:610:                f"Prompt templating is not supported for the `{built_pipeline.task}` task type. "
mlflow/transformers/__init__.py:611:                f"Supported task types are: {_SUPPORTED_PROMPT_TEMPLATING_TASK_TYPES}."
mlflow/transformers/__init__.py:688:    # Only allow a subset of task types to have a pyfunc definition.
mlflow/transformers/__init__.py:883:        task: The transformers-specific task type of the model. These strings are utilized so
mlflow/transformers/__init__.py:887:            correct task type. If the value specified is not a supported type within the
mlflow/transformers/__init__.py:1512:    Get the Transformers pipeline task type fro the model instance.
mlflow/transformers/__init__.py:1591:    Discriminator for determining whether a particular task type and model instance from within
mlflow/sentence_transformers/__init__.py:142:        task: MLflow inference task type for ``sentence-transformers`` model. Candidate task type
mlflow/sentence_transformers/__init__.py:353:        task: MLflow inference task type for ``sentence-transformers`` model. Candidate task type
tests/gateway/test_gateway_config_parsing.py:422:        MlflowException, match="Duplicate names found in endpoint / route configurations"
tests/gateway/test_gateway_app.py:68:                            "traffic_percentage": 80,
tests/gateway/test_gateway_app.py:72:                            "traffic_percentage": 20,
tests/gateway/test_gateway_app.py:176:            {"name": "chat-gpt4", "traffic_percentage": 80},
tests/gateway/test_gateway_app.py:177:            {"name": "chat-gpt5", "traffic_percentage": 20},
tests/gateway/test_gateway_app.py:208:                            "traffic_percentage": 100,
tests/transformers/test_transformers_prompt_templating.py:133:            match=f"Prompt templating is not supported for the `{pipeline_type}` task type.",
tests/transformers/test_transformers_model_export.py:3094:        MlflowException, match=r"LLM v1 task type 'llm/v1/chat' is specified in metadata, but"
tests/sentence_transformers/test_sentence_transformers_model_export.py:566:    # Invalid task type
mlflow/gateway/runner.py:12:from mlflow.gateway.utils import kill_child_processes
mlflow/gateway/providers/openai.py:22:from mlflow.gateway.utils import handle_incomplete_chunks, strip_sse_prefix
mlflow/gateway/providers/togetherai.py:12:from mlflow.gateway.utils import strip_sse_prefix
mlflow/gateway/providers/gemini.py:19:from mlflow.gateway.utils import handle_incomplete_chunks, strip_sse_prefix
mlflow/gateway/config.py:21:from mlflow.gateway.utils import (
mlflow/gateway/app.py:51:from mlflow.gateway.utils import SearchRoutesToken, make_streaming_response
```

## 原始行 26 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"TRAFFIC_SPLIT|traffic_percentage|destinations:\" docs examples mlflow --include='*.md' --include='*.rst' --include='*.yaml' --include='*.yml' --include='*.py' 2>/dev/null | head -300; grep -RIn \"No gateway server URI\\|No Gateway server URI\\|Gateway server URI\\|MLflow Gateway server\" mlflow tests docs --include='*.py' --include='*.md' --include='*.rst' 2>/dev/null | head -200; sed -n '1,130p' tests/deployments/test_utils.py; grep -n \"def append_to_uri_path\" -A35 mlflow/utils/uri.py; sed -n '350,420p' mlflow/gateway/app.py; sed -n '70,125p' mlflow/gateway/app.py"
```

退出码：`0`

输出：
```
mlflow/gateway/providers/base.py:103:        if routing_strategy != "TRAFFIC_SPLIT":
mlflow/gateway/providers/base.py:105:                "'routing_strategy' must be 'TRAFFIC_SPLIT'."
mlflow/gateway/config.py:436:    traffic_percentage: int
mlflow/gateway/config.py:442:    destinations: list[RouteDestinationConfig]
mlflow/gateway/config.py:443:    routing_strategy: Literal["TRAFFIC_SPLIT"] = "TRAFFIC_SPLIT"
mlflow/gateway/app.py:99:                destination.traffic_percentage for destination in route_config.destinations
import pytest

from mlflow.deployments.utils import (
    get_deployments_target,
    set_deployments_target,
)
from mlflow.exceptions import MlflowException


def test_set_deployments_target(monkeypatch):
    monkeypatch.setattr("mlflow.deployments.utils._deployments_target", None)

    valid_target = "databricks"
    set_deployments_target(valid_target)
    assert get_deployments_target() == valid_target

    valid_uri = "http://localhost"
    set_deployments_target(valid_uri)
    assert get_deployments_target() == valid_uri

    invalid_uri = "localhost"
    with pytest.raises(
        MlflowException, match="The target provided is not a valid uri or 'databricks'"
    ):
        set_deployments_target(invalid_uri)


def test_get_deployments_target(monkeypatch):
    monkeypatch.setattr("mlflow.deployments.utils._deployments_target", None)
    monkeypatch.delenv("MLFLOW_DEPLOYMENTS_TARGET", raising=False)

    with pytest.raises(MlflowException, match="No deployments target has been set"):
        get_deployments_target()

    valid_uri = "http://localhost"
    monkeypatch.setattr("mlflow.deployments.utils._deployments_target", valid_uri)
    assert get_deployments_target() == valid_uri

    monkeypatch.delenv("MLFLOW_DEPLOYMENTS_TARGET", raising=False)
    set_deployments_target(valid_uri)
    assert get_deployments_target() == valid_uri
292:def append_to_uri_path(uri, *paths):
293-    """Appends the specified POSIX `paths` to the path component of the specified `uri`.
294-
295-    Args:
296-        uri: The input URI, represented as a string.
297-        paths: The POSIX paths to append to the specified `uri`'s path component.
298-
299-    Returns:
300-        A new URI with a path component consisting of the specified `paths` appended to
301-        the path component of the specified `uri`.
302-
303-        .. code-block:: python
304-          uri1 = "s3://root/base/path?param=value"
305-          uri1 = append_to_uri_path(uri1, "some/subpath", "/anotherpath")
306-          assert uri1 == "s3://root/base/path/some/subpath/anotherpath?param=value"
307-          uri2 = "a/posix/path"
308-          uri2 = append_to_uri_path(uri2, "/some", "subpath")
309-          assert uri2 == "a/posixpath/some/subpath"
310-    """
311-    path = ""
312-    for subpath in paths:
313-        path = _join_posixpaths_and_append_absolute_suffixes(path, subpath)
314-
315-    parsed_uri = urllib.parse.urlparse(uri)
316-
317-    # Validate query string not to contain any traversal path (../) before appending
318-    # to the end of the path, otherwise they will be resolved as part of the path.
319-    validate_query_string(parsed_uri.query)
320-
321-    if len(parsed_uri.scheme) == 0:
322-        # If the input URI does not define a scheme, we assume that it is a POSIX path
323-        # and join it with the specified input paths
324-        return _join_posixpaths_and_append_absolute_suffixes(uri, path)
325-
326-    prefix = ""
327-    if not parsed_uri.path.startswith("/"):
            detail=f"The route '{route_name}' is not present or active on the server. Please "
            "verify the route name.",
        )

    @app.get(MLFLOW_GATEWAY_CRUD_ENDPOINT_V3_BASE + "{endpoint_name}", include_in_schema=False)
    async def get_endpoint_v3(endpoint_name: str) -> Endpoint:
        if matched := app.dynamic_endpoints.get(endpoint_name):
            return matched.to_endpoint()

        raise HTTPException(
            status_code=404,
            detail=f"The endpoint '{endpoint_name}' is not present or active on the server. "
            f"Please verify the endpoint name.",
        )

    @app.get(MLFLOW_GATEWAY_CRUD_ROUTE_V3_BASE + "{route_name}", include_in_schema=False)
    async def get_route_v3(route_name: str) -> TrafficRouteConfig:
        if matched := app.traffic_routes.get(route_name):
            return matched

        raise HTTPException(
            status_code=404,
            detail=f"The route '{route_name}' is not present or active on the server. "
            f"Please verify the route name.",
        )

    # TODO: Remove deployments server URLs after deprecation window elapses
    @app.get(MLFLOW_DEPLOYMENTS_CRUD_ENDPOINT_BASE)
    async def list_endpoints(page_token: str | None = None) -> ListEndpointsResponse:
        start_idx = SearchRoutesToken.decode(page_token).index if page_token is not None else 0

        end_idx = start_idx + MLFLOW_DEPLOYMENTS_LIST_ENDPOINTS_PAGE_SIZE
        endpoints = list(app.dynamic_endpoints.values())
        result = {
            "endpoints": [endpoint.to_endpoint() for endpoint in endpoints[start_idx:end_idx]]
        }
        if len(endpoints[end_idx:]) > 0:
            next_page_token = SearchRoutesToken(index=end_idx)
            result["next_page_token"] = next_page_token.encode()

        return result

    # TODO: Remove the deprecated endpoint
    @app.get(MLFLOW_GATEWAY_CRUD_ROUTE_BASE, include_in_schema=False, deprecated=True)
    async def _legacy_search_routes(page_token: str | None = None) -> _LegacySearchRoutesResponse:
        start_idx = SearchRoutesToken.decode(page_token).index if page_token is not None else 0

        end_idx = start_idx + MLFLOW_GATEWAY_SEARCH_ROUTES_PAGE_SIZE
        routes = list(app.dynamic_endpoints.values())
        result = {"routes": [r._to_legacy_route() for r in routes[start_idx:end_idx]]}
        if len(routes[end_idx:]) > 0:
            next_page_token = SearchRoutesToken(index=end_idx)
            result["next_page_token"] = next_page_token.encode()

        return result

    # TODO: Remove deployments server URLs after deprecation window elapses
    @app.get(MLFLOW_DEPLOYMENTS_LIMITS_BASE + "{endpoint}")
    @app.get(MLFLOW_GATEWAY_LIMITS_BASE + "{endpoint}", include_in_schema=False)
    async def get_limits(endpoint: str) -> LimitsConfig:
        raise HTTPException(status_code=501, detail="The get_limits API is not available yet.")

    # TODO: Remove deployments server URLs after deprecation window elapses
    @app.post(MLFLOW_DEPLOYMENTS_LIMITS_BASE)
    @app.post(MLFLOW_GATEWAY_LIMITS_BASE, include_in_schema=False)
    async def set_limits(payload: SetLimitsModel) -> LimitsConfig:
        raise HTTPException(status_code=501, detail="The set_limits API is not available yet.")

    @app.post("/v1/chat/completions")
    async def openai_chat_handler(
        request: Request, payload: chat.RequestPayload
            self.add_api_route(
                path=(MLFLOW_DEPLOYMENTS_ENDPOINTS_BASE + name + MLFLOW_DEPLOYMENTS_QUERY_SUFFIX),
                endpoint=_get_endpoint_handler(self, name, limiter, "deployments"),
                methods=["POST"],
            )
            self.add_api_route(
                path=f"{MLFLOW_GATEWAY_ROUTE_BASE}{name}{MLFLOW_QUERY_SUFFIX}",
                endpoint=_get_endpoint_handler(self, name, limiter, "gateway"),
                methods=["POST"],
                include_in_schema=False,
            )

    def _get_provider_by_name(self, name: str) -> tuple[Provider, EndpointType]:
        """
        If the name is an endpoint name, return the endpoint's provider
        If the name is a traffic route name, return a `TrafficRouteProvider`
        """
        from mlflow.gateway.providers.base import TrafficRouteProvider

        if name in self.dynamic_endpoints:
            config = self.dynamic_endpoints[name]
            return get_provider(config.model.provider)(config), config.endpoint_type
        if name in self.traffic_routes:
            route_config = self.traffic_routes[name]
            endpoint_configs = [
                self.dynamic_endpoints[destination.name]
                for destination in route_config.destinations
            ]
            traffic_splits = [
                destination.traffic_percentage for destination in route_config.destinations
            ]
            return TrafficRouteProvider(
                endpoint_configs,
                traffic_splits,
                route_config.routing_strategy,
            ), route_config.task_type
        raise MlflowException.invalid_parameter_value(f"Invalid endpoint / route name: '{name}'")

    def get_dynamic_endpoint(self, endpoint_name: str) -> Endpoint | None:
        return r.to_endpoint() if (r := self.dynamic_endpoints.get(endpoint_name)) else None

    def _get_legacy_dynamic_route(self, route_name: str) -> _LegacyRoute | None:
        return r._to_legacy_route() if (r := self.dynamic_endpoints.get(route_name)) else None


def _translate_http_exception(func):
    """
    Decorator for translating MLflow exceptions to HTTP exceptions
    """

    @functools.wraps(func)
    async def wrapper(*args, **kwargs):
        try:
            return await func(*args, **kwargs)
        except AIGatewayException as e:
            raise HTTPException(status_code=e.status_code, detail=e.detail)
```

## 原始行 29 · command_execution

命令：
```
/bin/bash -lc "sed -n '430,465p' mlflow/environment_variables.py; grep -n \"class _EnvironmentVariable\" -A85 mlflow/environment_variables.py; grep -n \"class MlflowException\" -A100 mlflow/exceptions.py; sed -n '286,365p' mlflow/utils/uri.py; grep -RIn \"urlparse(.*databricks\\|scheme == \\\"databricks\\\"\" mlflow --include='*.py' | head -100"
```

退出码：`0`

输出：
```
)

#: Specifies whether or not to use DBFS FUSE mount to store artifacts on Databricks
#: (default: ``False``)
MLFLOW_ENABLE_DBFS_FUSE_ARTIFACT_REPO = _BooleanEnvironmentVariable(
    "MLFLOW_ENABLE_DBFS_FUSE_ARTIFACT_REPO", True
)

#: Specifies whether or not to use UC Volume FUSE mount to store artifacts on Databricks
#: (default: ``True``)
MLFLOW_ENABLE_UC_VOLUME_FUSE_ARTIFACT_REPO = _BooleanEnvironmentVariable(
    "MLFLOW_ENABLE_UC_VOLUME_FUSE_ARTIFACT_REPO", True
)

#: Private environment variable that should be set to ``True`` when running autologging tests.
#: (default: ``False``)
_MLFLOW_AUTOLOGGING_TESTING = _BooleanEnvironmentVariable("MLFLOW_AUTOLOGGING_TESTING", False)

#: (Experimental, may be changed or removed)
#: Specifies the uri of a MLflow Gateway Server instance to be used with the Gateway Client APIs
#: (default: ``None``)
MLFLOW_GATEWAY_URI = _EnvironmentVariable("MLFLOW_GATEWAY_URI", str, None)

#: (Experimental, may be changed or removed)
#: Specifies the uri of an MLflow AI Gateway instance to be used with the Deployments
#: Client APIs
#: (default: ``None``)
MLFLOW_DEPLOYMENTS_TARGET = _EnvironmentVariable("MLFLOW_DEPLOYMENTS_TARGET", str, None)

#: Specifies the path of the config file for MLflow AI Gateway.
#: (default: ``None``)
MLFLOW_GATEWAY_CONFIG = _EnvironmentVariable("MLFLOW_GATEWAY_CONFIG", str, None)

#: Specifies the path of the config file for MLflow AI Gateway.
#: (default: ``None``)
MLFLOW_DEPLOYMENTS_CONFIG = _EnvironmentVariable("MLFLOW_DEPLOYMENTS_CONFIG", str, None)
13:class _EnvironmentVariable:
14-    """
15-    Represents an environment variable.
16-    """
17-
18-    def __init__(self, name, type_, default):
19-        if type_ == bool and not isinstance(self, _BooleanEnvironmentVariable):
20-            raise ValueError("Use _BooleanEnvironmentVariable instead for boolean variables")
21-        self.name = name
22-        self.type = type_
23-        self.default = default
24-
25-    @property
26-    def defined(self):
27-        return self.name in os.environ
28-
29-    def get_raw(self):
30-        return os.getenv(self.name)
31-
32-    def set(self, value):
33-        os.environ[self.name] = str(value)
34-
35-    def unset(self):
36-        os.environ.pop(self.name, None)
37-
38-    def is_set(self):
39-        return self.name in os.environ
40-
41-    def get(self):
42-        """
43-        Reads the value of the environment variable if it exists and converts it to the desired
44-        type. Otherwise, returns the default value.
45-        """
46-        if (val := self.get_raw()) is not None:
47-            try:
48-                return self.type(val)
49-            except Exception as e:
50-                raise ValueError(f"Failed to convert {val!r} for {self.name}: {e}")
51-        return self.default
52-
53-    def __str__(self):
54-        return f"{self.name} (default: {self.default})"
55-
56-    def __repr__(self):
57-        return repr(self.name)
58-
59-
60-
61-
62-
63-class _BooleanEnvironmentVariable(_EnvironmentVariable):
64-    """
65-    Represents a boolean environment variable.
66-    """
67-
68-    def __init__(self, name, default):
69-        # `default not in [True, False, None]` doesn't work because `1 in [True]`
70-        # (or `0 in [False]`) returns True.
71-        if not (default is True or default is False or default is None):
72-            raise ValueError(f"{name} default value must be one of [True, False, None]")
73-        super().__init__(name, bool, default)
74-
75-    def get(self):
76-        # TODO: Remove this block in MLflow 3.2.0
77-        if self.name == MLFLOW_CONFIGURE_LOGGING.name and (
78-            val := os.getenv("MLFLOW_LOGGING_CONFIGURE_LOGGING")
79-        ):
80-            warnings.warn(
81-                "Environment variable MLFLOW_LOGGING_CONFIGURE_LOGGING is deprecated and will be "
82-                f"removed in a future release. Please use {MLFLOW_CONFIGURE_LOGGING.name} instead.",
83-                FutureWarning,
84-                stacklevel=2,
85-            )
86-            return val.lower() in ["true", "1"]
87-
88-        if not self.defined:
89-            return self.default
90-
91-        val = os.getenv(self.name)
92-        lowercased = val.lower()
93-        if lowercased not in ["true", "false", "1", "0"]:
94-            raise ValueError(
95-                f"{self.name} value must be one of ['true', 'false', '1', '0'] (case-insensitive), "
96-                f"but got {val}"
97-            )
98-        return lowercased in ["true", "1"]
67:class MlflowException(Exception):
68-    """
69-    Generic exception thrown to surface failure information about external-facing operations.
70-    The error message associated with this exception may be exposed to clients in HTTP responses
71-    for debugging purposes. If the error text is sensitive, raise a generic `Exception` object
72-    instead.
73-    """
74-
75-    def __init__(self, message, error_code=INTERNAL_ERROR, **kwargs):
76-        """
77-        Args:
78-            message: The message or exception describing the error that occurred. This will be
79-                included in the exception's serialized JSON representation.
80-            error_code: An appropriate error code for the error that occurred; it will be
81-                included in the exception's serialized JSON representation. This should
82-                be one of the codes listed in the `mlflow.protos.databricks_pb2` proto.
83-            kwargs: Additional key-value pairs to include in the serialized JSON representation
84-                of the MlflowException.
85-        """
86-        try:
87-            self.error_code = ErrorCode.Name(error_code)
88-        except (ValueError, TypeError):
89-            self.error_code = ErrorCode.Name(INTERNAL_ERROR)
90-        message = str(message)
91-        self.message = message
92-        self.json_kwargs = kwargs
93-        super().__init__(message)
94-
95-    def serialize_as_json(self):
96-        exception_dict = {"error_code": self.error_code, "message": self.message}
97-        exception_dict.update(self.json_kwargs)
98-        return json.dumps(exception_dict)
99-
100-    def get_http_status_code(self):
101-        return ERROR_CODE_TO_HTTP_STATUS.get(self.error_code, 500)
102-
103-    @classmethod
104-    def invalid_parameter_value(cls, message, **kwargs):
105-        """Constructs an `MlflowException` object with the `INVALID_PARAMETER_VALUE` error code.
106-
107-        Args:
108-            message: The message describing the error that occurred. This will be included in the
109-                exception's serialized JSON representation.
110-            kwargs: Additional key-value pairs to include in the serialized JSON representation
111-                of the MlflowException.
112-        """
113-        return cls(message, error_code=INVALID_PARAMETER_VALUE, **kwargs)
114-
115-
116-class RestException(MlflowException):
117-    """Exception thrown on non 200-level responses from the REST API"""
118-
119-    def __init__(self, json):
120-        self.json = json
121-
122-        error_code = json.get("error_code", ErrorCode.Name(INTERNAL_ERROR))
123-        message = "{}: {}".format(
124-            error_code,
125-            json["message"] if "message" in json else "Response: " + str(json),
126-        )
127-
128-        try:
129-            super().__init__(message, error_code=ErrorCode.Value(error_code))
130-        except ValueError:
131-            try:
132-                # The `error_code` can be an http error code, in which case we convert it to the
133-                # corresponding `ErrorCode`.
134-                error_code = HTTP_STATUS_TO_ERROR_CODE[int(error_code)]
135-                super().__init__(message, error_code=ErrorCode.Value(error_code))
136-            except ValueError or KeyError:
137-                _logger.warning(
138-                    f"Received error code not recognized by MLflow: {error_code}, this may "
139-                    "indicate your request encountered an error before reaching MLflow server, "
140-                    "e.g., within a proxy server or authentication / authorization service."
141-                )
142-                super().__init__(message)
143-
144-    def __reduce__(self):
145-        """
146-        Overriding `__reduce__` to make `RestException` instance pickle-able.
147-        """
148-        return RestException, (self.json,)
149-
150-
151-class ExecutionException(MlflowException):
152-    """Exception thrown when executing a project fails"""
153-
154-
155-class MissingConfigException(MlflowException):
156-    """Exception thrown when expected configuration file/directory not found"""
157-
158-
159-class InvalidUrlException(MlflowException):
160-    """Exception thrown when a http request fails to send due to an invalid URL"""
161-
162-
163-class _UnsupportedMultipartUploadException(MlflowException):
164-    """Exception thrown when multipart upload is unsupported by an artifact repository"""
165-
166-    MESSAGE = "Multipart upload is not supported for the current artifact repository"
167-
def extract_and_normalize_path(uri):
    parsed_uri_path = urllib.parse.urlparse(uri).path
    normalized_path = posixpath.normpath(parsed_uri_path)
    return normalized_path.lstrip("/")


def append_to_uri_path(uri, *paths):
    """Appends the specified POSIX `paths` to the path component of the specified `uri`.

    Args:
        uri: The input URI, represented as a string.
        paths: The POSIX paths to append to the specified `uri`'s path component.

    Returns:
        A new URI with a path component consisting of the specified `paths` appended to
        the path component of the specified `uri`.

        .. code-block:: python
          uri1 = "s3://root/base/path?param=value"
          uri1 = append_to_uri_path(uri1, "some/subpath", "/anotherpath")
          assert uri1 == "s3://root/base/path/some/subpath/anotherpath?param=value"
          uri2 = "a/posix/path"
          uri2 = append_to_uri_path(uri2, "/some", "subpath")
          assert uri2 == "a/posixpath/some/subpath"
    """
    path = ""
    for subpath in paths:
        path = _join_posixpaths_and_append_absolute_suffixes(path, subpath)

    parsed_uri = urllib.parse.urlparse(uri)

    # Validate query string not to contain any traversal path (../) before appending
    # to the end of the path, otherwise they will be resolved as part of the path.
    validate_query_string(parsed_uri.query)

    if len(parsed_uri.scheme) == 0:
        # If the input URI does not define a scheme, we assume that it is a POSIX path
        # and join it with the specified input paths
        return _join_posixpaths_and_append_absolute_suffixes(uri, path)

    prefix = ""
    if not parsed_uri.path.startswith("/"):
        # For certain URI schemes (e.g., "file:"), urllib's unparse routine does
        # not preserve the relative URI path component properly. In certain cases,
        # urlunparse converts relative paths to absolute paths. We introduce this logic
        # to circumvent urlunparse's erroneous conversion
        prefix = parsed_uri.scheme + ":"
        parsed_uri = parsed_uri._replace(scheme="")

    new_uri_path = _join_posixpaths_and_append_absolute_suffixes(parsed_uri.path, path)
    new_parsed_uri = parsed_uri._replace(path=new_uri_path)
    return prefix + urllib.parse.urlunparse(new_parsed_uri)


def append_to_uri_query_params(uri, *query_params: tuple[str, Any]) -> str:
    """Appends the specified query parameters to an existing URI.

    Args:
        uri: The URI to which to append query parameters.
        query_params: Query parameters to append. Each parameter should
            be a 2-element tuple. For example, ``("key", "value")``.
    """
    parsed_uri = urllib.parse.urlparse(uri)
    parsed_query = urllib.parse.parse_qsl(parsed_uri.query)
    new_parsed_query = parsed_query + list(query_params)
    new_query = urllib.parse.urlencode(new_parsed_query)
    new_parsed_uri = parsed_uri._replace(query=new_query)
    return urllib.parse.urlunparse(new_parsed_uri)


def _join_posixpaths_and_append_absolute_suffixes(prefix_path, suffix_path):
    """
    Joins the POSIX path `prefix_path` with the POSIX path `suffix_path`. Unlike posixpath.join(),
    if `suffix_path` is an absolute path, it is appended to prefix_path.

    >>> result1 = _join_posixpaths_and_append_absolute_suffixes("relpath1", "relpath2")
    >>> assert result1 == "relpath1/relpath2"
    >>> result2 = _join_posixpaths_and_append_absolute_suffixes("relpath", "/absolutepath")
    >>> assert result2 == "relpath/absolutepath"
    >>> result3 = _join_posixpaths_and_append_absolute_suffixes("/absolutepath", "relpath")
mlflow/utils/uri.py:88:    return scheme == "databricks" or uri == "databricks"
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "sed -n '60,100p' mlflow/utils/uri.py; grep -RInE \"Duplicate names found|traffic percentages|traffic percentage|destinations.*endpoint|endpoint.*destination\" . --exclude-dir=.git --include='*.py' --include='*.md' --include='*.yaml' --include='*.yml' 2>/dev/null | head -200"
```

退出码：`0`

输出：
```
            )
        return True

    if is_remote_hostname:
        return False

    if is_windows() and len(scheme) == 1 and scheme.lower() == pathlib.Path(uri).drive.lower()[0]:
        return True

    return False


def is_file_uri(uri):
    scheme = urllib.parse.urlparse(uri).scheme
    return scheme == "file"


def is_http_uri(uri):
    scheme = urllib.parse.urlparse(uri).scheme
    return scheme in {"http", "https"}


def is_databricks_uri(uri):
    """
    Databricks URIs look like 'databricks' (default profile) or 'databricks://profile'
    or 'databricks://secret_scope:secret_key_prefix'.
    """
    scheme = urllib.parse.urlparse(uri).scheme
    return scheme == "databricks" or uri == "databricks"


def is_fuse_or_uc_volumes_uri(uri):
    """
    Validates whether a provided URI is directed to a FUSE mount point or a UC volumes mount point.
    Multiple directory paths are collapsed into a single designator for root path validation.
    For example, "////Volumes/" will resolve to "/Volumes/" for validation purposes.
    """
    resolved_uri = re.sub("/+", "/", uri).lower()
    return any(
        resolved_uri.startswith(x.lower())
        for x in [
./mlflow/gateway/app.py:95:                self.dynamic_endpoints[destination.name]
./tests/gateway/test_gateway_config_parsing.py:422:        MlflowException, match="Duplicate names found in endpoint / route configurations"
```

## 原始行 36 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"traffic routing|traffic route|traffic split|TrafficRoute\" CHANGELOG.md docs mlflow --include='*.md' --include='*.rst' --include='*.py' 2>/dev/null | head -300; grep -RInE \"Duplicate names found\" . --exclude-dir=.git 2>/dev/null"
```

退出码：`0`

输出：
```
CHANGELOG.md:50:- [Gateway] Add traffic route to multiple endpoints (#18064, @WeichenXu123)
mlflow/gateway/providers/base.py:83:class TrafficRouteProvider(BaseProvider):
mlflow/gateway/providers/base.py:88:    NAME: str = "TrafficRoute"
mlflow/gateway/config.py:439:class TrafficRouteConfig(ConfigModel):
mlflow/gateway/config.py:489:    routes: list[TrafficRouteConfig] | None = None
mlflow/gateway/app.py:34:    TrafficRouteConfig,
mlflow/gateway/app.py:63:        self.traffic_routes: dict[str, TrafficRouteConfig] = {
mlflow/gateway/app.py:85:        If the name is a traffic route name, return a `TrafficRouteProvider`
mlflow/gateway/app.py:87:        from mlflow.gateway.providers.base import TrafficRouteProvider
mlflow/gateway/app.py:101:            return TrafficRouteProvider(
mlflow/gateway/app.py:366:    async def get_route_v3(route_name: str) -> TrafficRouteConfig:
./tests/gateway/test_gateway_config_parsing.py:422:        MlflowException, match="Duplicate names found in endpoint / route configurations"
```

## 原始行 40 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"add_exception_handler\\|MlflowException\" mlflow/gateway/app.py | head -50; sed -n '30,75p' mlflow/gateway/app.py; sed -n '460,520p' mlflow/gateway/app.py"
```

退出码：`0`

输出：
```
26:from mlflow.exceptions import MlflowException
59:        self.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
106:        raise MlflowException.invalid_parameter_value(f"Invalid endpoint / route name: '{name}'")
490:    raise MlflowException(
    EndpointType,
    GatewayConfig,
    LimitsConfig,
    Provider,
    TrafficRouteConfig,
    _LegacyRoute,
    _load_gateway_config,
)
from mlflow.gateway.constants import (
    MLFLOW_GATEWAY_CRUD_ENDPOINT_V3_BASE,
    MLFLOW_GATEWAY_CRUD_ROUTE_BASE,
    MLFLOW_GATEWAY_CRUD_ROUTE_V3_BASE,
    MLFLOW_GATEWAY_HEALTH_ENDPOINT,
    MLFLOW_GATEWAY_LIMITS_BASE,
    MLFLOW_GATEWAY_ROUTE_BASE,
    MLFLOW_GATEWAY_SEARCH_ROUTES_PAGE_SIZE,
    MLFLOW_QUERY_SUFFIX,
)
from mlflow.gateway.exceptions import AIGatewayException
from mlflow.gateway.providers import get_provider
from mlflow.gateway.schemas import chat, completions, embeddings
from mlflow.gateway.utils import SearchRoutesToken, make_streaming_response
from mlflow.version import VERSION


class GatewayAPI(FastAPI):
    def __init__(self, config: GatewayConfig, limiter: Limiter, *args: Any, **kwargs: Any):
        super().__init__(*args, **kwargs)
        self.state.limiter = limiter
        self.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
        self.dynamic_endpoints: dict[str, EndpointConfig] = {
            endpoint.name: endpoint for endpoint in config.endpoints
        }
        self.traffic_routes: dict[str, TrafficRouteConfig] = {
            route.name: route for route in (config.routes or [])
        }

        # config API routes
        for name in self.dynamic_endpoints.keys() | self.traffic_routes.keys():
            # TODO: Remove deployments server URLs after deprecation window elapses
            self.add_api_route(
                path=(MLFLOW_DEPLOYMENTS_ENDPOINTS_BASE + name + MLFLOW_DEPLOYMENTS_QUERY_SUFFIX),
                endpoint=_get_endpoint_handler(self, name, limiter, "deployments"),
                methods=["POST"],
            )
            self.add_api_route(
        name = payload.model
        prov, endpoint_type = app._get_provider_by_name(name)

        if endpoint_type != EndpointType.LLM_V1_EMBEDDINGS:
            raise HTTPException(
                status_code=400,
                detail=f"Endpoint {name!r} is not an embeddings endpoint.",
            )

        payload.model = None  # provider rejects a request with model field, must be set to None
        return await prov.embeddings(payload)

    return app


def create_app_from_path(config_path: str | Path) -> GatewayAPI:
    """
    Load the path and generate the GatewayAPI app instance.
    """
    config = _load_gateway_config(config_path)
    return create_app_from_config(config)


def create_app_from_env() -> GatewayAPI:
    """
    Load the path from the environment variable and generate the GatewayAPI app instance.
    """
    if config_path := MLFLOW_GATEWAY_CONFIG.get():
        return create_app_from_path(config_path)

    raise MlflowException(
        f"Environment variable {MLFLOW_GATEWAY_CONFIG!r} is not set. "
        "Please set it to the path of the gateway configuration file."
    )
```

## 原始行 42 · agent_message

```
The surrounding imports and the deployments utility confirm the intended patterns: strict structural URI checks, `append_to_uri_path` for URL joining, MLflow invalid-parameter exceptions, and standard JSON/base64 pagination. I’m implementing those contracts now, including validation of the newer traffic-route configuration.
```

## 原始行 44 · file_change

```
{
  "id": "item_29",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/gateway/utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,330p' mlflow/gateway/utils.py; python -m pytest tests/gateway/test_gateway_config_parsing.py tests/gateway/test_gateway_app.py -q"
```

退出码：`2`

输出：
```
import base64
import functools
import inspect
import json
import logging
import posixpath
import re
import textwrap
import warnings
from typing import Any, AsyncGenerator
from urllib.parse import urlparse

from mlflow.environment_variables import MLFLOW_GATEWAY_URI
from mlflow.exceptions import MlflowException
from mlflow.gateway.constants import MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES
from mlflow.utils.uri import append_to_uri_path

_logger = logging.getLogger(__name__)
_gateway_uri: str | None = None


def _is_valid_uri(uri: str):
    """Return whether *uri* has the structure required for a gateway URI."""
    if uri == "databricks":
        return True

    try:
        parsed = urlparse(uri)
        return bool(parsed.scheme and (parsed.scheme == "databricks" or parsed.netloc))
    except ValueError:
        return False


def assemble_uri_path(paths: list[str]) -> str:
    """Join URI path components into a normalized absolute path."""
    return posixpath.join("/", *(path.strip("/") for path in paths if path))


def check_configuration_route_name_collisions(config):
    """Validate endpoint and traffic-route names and destination configuration."""
    endpoints = config.get("endpoints", []) or []
    routes = config.get("routes", []) or []

    endpoint_names = [endpoint["name"] for endpoint in endpoints]
    route_names = [route["name"] for route in routes]
    all_names = endpoint_names + route_names
    if len(all_names) != len(set(all_names)):
        raise MlflowException.invalid_parameter_value(
            "Duplicate names found in endpoint / route configurations"
        )

    endpoint_types = {
        endpoint["name"]: endpoint["endpoint_type"] for endpoint in endpoints
    }
    for route in routes:
        route_name = route["name"]
        task_type = route["task_type"]
        total_traffic = 0
        for destination in route["destinations"]:
            destination_name = destination["name"]
            if destination_name not in endpoint_types:
                raise MlflowException.invalid_parameter_value(
                    f"Route '{route_name}' references undefined endpoint "
                    f"'{destination_name}'"
                )
            if endpoint_types[destination_name] != task_type:
                raise MlflowException.invalid_parameter_value(
                    f"Route '{route_name}' has task type '{task_type}', which does not match "
                    f"endpoint '{destination_name}' type '{endpoint_types[destination_name]}'"
                )

            traffic_percentage = destination["traffic_percentage"]
            try:
                is_valid_percentage = 0 <= traffic_percentage <= 100
            except TypeError:
                is_valid_percentage = False
            if not is_valid_percentage:
                raise MlflowException.invalid_parameter_value(
                    f"Traffic percentage for endpoint '{destination_name}' in route "
                    f"'{route_name}' must be between 0 and 100"
                )
            total_traffic += traffic_percentage

        if total_traffic != 100:
            raise MlflowException.invalid_parameter_value(
                f"Traffic percentages for route '{route_name}' must sum to 100; "
                f"got {total_traffic}"
            )
































































def check_configuration_deprecated_fields(config):
    endpoints = config.get("endpoints", [])
    for endpoint in endpoints:
        if "route_type" in endpoint:
            raise MlflowException.invalid_parameter_value(
                "The 'route_type' configuration key is not supported in the configuration file. "
                "Use 'endpoint_type' instead."
            )


def kill_child_processes(parent_pid):
    """
    Gracefully terminate or kill child processes from a main process
    """
    import psutil

    parent = psutil.Process(parent_pid)
    for child in parent.children(recursive=True):
        try:
            child.terminate()
        except psutil.NoSuchProcess:
            pass
    _, still_alive = psutil.wait_procs(parent.children(), timeout=3)
    for p in still_alive:
        p.kill()


def is_valid_endpoint_name(name: str) -> bool:
    """Return whether *name* is safe to use as a URL path component."""
    return bool(re.fullmatch(r"[\w.-]+", name))


def resolve_route_url(base_url: str, route: str) -> str:
    """Resolve a route path against a gateway URL, preserving absolute URLs."""
    return route if _is_valid_uri(route) else append_to_uri_path(base_url, route)
















def _get_indent(s: str) -> str:
    for l in s.splitlines():
        if l.startswith(" "):
            return " " * (len(l) - len(l.lstrip()))
    return ""


def _prepend(docstring: str | None, text: str) -> str:
    if not docstring:
        return text

    indent = _get_indent(docstring)
    return f"""
{textwrap.indent(text, indent)}

{docstring}
"""


def gateway_deprecated(obj):
    msg = (
        "MLflow AI gateway is deprecated and has been replaced by the deployments API for "
        "generative AI. See https://mlflow.org/docs/latest/llms/gateway/migration.html for "
        "migration."
    )
    warning = f"""
.. warning::

    {msg}
""".strip()
    if inspect.isclass(obj):
        original = obj.__init__

        @functools.wraps(original)
        def wrapper(*args, **kwargs):
            warnings.warn(msg, FutureWarning, stacklevel=2)
            return original(*args, **kwargs)

        obj.__init__ = wrapper
        obj.__init__.__doc__ = _prepend(obj.__init__.__doc__, warning)
        return obj
    else:

        @functools.wraps(obj)
        def wrapper(*args, **kwargs):
            warnings.warn(msg, FutureWarning, stacklevel=2)
            return obj(*args, **kwargs)

        wrapper.__doc__ = _prepend(obj.__doc__, warning)

        return wrapper


@gateway_deprecated
def get_gateway_uri() -> str:
    """Return the configured MLflow AI Gateway server URI."""
    if _gateway_uri is not None:
        return _gateway_uri
    if uri := MLFLOW_GATEWAY_URI.get():
        return uri
    raise MlflowException(
        "No Gateway server URI has been set. Please either set the Gateway server URI via "
        "`mlflow.gateway.set_gateway_uri()` or set the environment variable "
        f"{MLFLOW_GATEWAY_URI} to the running Gateway server's URI"
    )


@gateway_deprecated
def set_gateway_uri(gateway_uri: str):
    """Set the MLflow AI Gateway server URI used by the fluent APIs."""
    if not _is_valid_uri(gateway_uri):
        raise MlflowException.invalid_parameter_value(
            "The gateway URI provided is not a valid URI or 'databricks'"
        )

    global _gateway_uri
    _gateway_uri = gateway_uri


















































[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 23 items / 1 error

==================================== ERRORS ====================================
[31m[1m______________ ERROR collecting tests/gateway/test_gateway_app.py ______________[0m
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py[0m:44: in <module>
    [0m[94mimport[39;49;00m[90m [39;49;00m[04m[96mhttpx[39;49;00m[90m[39;49;00m
[1m[31mE   ModuleNotFoundError: No module named 'httpx'[0m
        ASGIApp    = typing.Callable[[collections.abc.MutableMapping[str, typing.Any], typing.Callable[[], collections.abc.Awaitable[collec...[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]], collections.abc.Awaitable[None]]
        AbstractContextManager = <class 'contextlib.AbstractContextManager'>
        Any        = typing.Any
        Awaitable  = <class 'collections.abc.Awaitable'>
        Callable   = typing.Callable
        Future     = <class 'concurrent.futures._base.Future'>
        Generator  = <class 'collections.abc.Generator'>
        GeneratorType = <class 'generator'>
        Iterable   = <class 'collections.abc.Iterable'>
        Literal    = typing.Literal
        Mapping    = <class 'collections.abc.Mapping'>
        Message    = collections.abc.MutableMapping[str, typing.Any]
        MutableMapping = <class 'collections.abc.MutableMapping'>
        Receive    = typing.Callable[[], collections.abc.Awaitable[collections.abc.MutableMapping[str, typing.Any]]]
        Scope      = collections.abc.MutableMapping[str, typing.Any]
        Self       = typing.Self
        Send       = typing.Callable[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]
        Sequence   = <class 'collections.abc.Sequence'>
        StapledObjectStream = <class 'anyio.streams.stapled.StapledObjectStream'>
        TypeGuard  = typing.TypeGuard
        TypedDict  = <function TypedDict at 0x703ad7a72b60>
        Union      = typing.Union
        WebSocketDisconnect = <class 'starlette.websockets.WebSocketDisconnect'>
        __builtins__ = <builtins>
        __cached__ = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/__pycache__/testclient.cpython-311.pyc'
        __doc__    = None
        __file__   = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py'
        __loader__ = <_frozen_importlib_external.SourceFileLoader object at 0x703a9b81d2d0>
        __name__   = 'starlette.testclient'
        __package__ = 'starlette'
        __spec__   = ModuleSpec(name='starlette.testclient', loader=<_frozen_importlib_external.SourceFileLoader object at 0x703a9b81d2d0>, origin='/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py')
        annotations = _Feature((3, 7, 0, 'beta', 1), None, 16777216)
        anyio      = <module 'anyio' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/anyio/__init__.py'>
        cast       = <function cast at 0x703ad76ed4e0>
        contextlib = <module 'contextlib' from '/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py'>
        inspect    = <module 'inspect' from '/opt/miniconda3/envs/testbed/lib/python3.11/inspect.py'>
        io         = <module 'io' (frozen)>
        is_async_callable = <function is_async_callable at 0x703a9b9718a0>
        json       = <module 'json' from '/opt/miniconda3/envs/testbed/lib/python3.11/json/__init__.py'>
        math       = <module 'math' from '/opt/miniconda3/envs/testbed/lib/python3.11/lib-dynload/math.cpython-311-x86_64-linux-gnu.so'>
        sys        = <module 'sys' (built-in)>
        unquote    = <function unquote at 0x703ad77aa200>
        urljoin    = <function urljoin at 0x703ad77a9f80>
        warnings   = <module 'warnings' from '/opt/miniconda3/envs/testbed/lib/python3.11/warnings.py'>

[33mDuring handling of the above exception, another exception occurred:[0m
[1m[31mtests/gateway/test_gateway_app.py[0m:4: in <module>
    [0m[94mfrom[39;49;00m[90m [39;49;00m[04m[96mfastapi[39;49;00m[04m[96m.[39;49;00m[04m[96mtestclient[39;49;00m[90m [39;49;00m[94mimport[39;49;00m TestClient[90m[39;49;00m
        __builtins__ = <builtins>
        __cached__ = '/testbed/tests/gateway/__pycache__/test_gateway_app.cpython-311.pyc'
        __doc__    = None
        __file__   = '/testbed/tests/gateway/test_gateway_app.py'
        __loader__ = <_pytest.assertion.rewrite.AssertionRewritingHook object at 0x703ad6bc0bd0>
        __name__   = 'tests.gateway.test_gateway_app'
        __package__ = 'tests.gateway'
        __spec__   = ModuleSpec(name='tests.gateway.test_gateway_app', loader=<_pytest.assertion.rewrite.AssertionRewritingHook object at 0x703ad6bc0bd0>, origin='/testbed/tests/gateway/test_gateway_app.py')
        mock       = <module 'unittest.mock' from '/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py'>
        pytest     = <module 'pytest' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pytest/__init__.py'>
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/testclient.py[0m:1: in <module>
    [0m[94mfrom[39;49;00m[90m [39;49;00m[04m[96mstarlette[39;49;00m[04m[96m.[39;49;00m[04m[96mtestclient[39;49;00m[90m [39;49;00m[94mimport[39;49;00m TestClient [94mas[39;49;00m TestClient  [90m# noqa[39;49;00m[90m[39;49;00m
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        __builtins__ = <builtins>
        __cached__ = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/__pycache__/testclient.cpython-311.pyc'
        __doc__    = None
        __file__   = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/testclient.py'
        __loader__ = <_frozen_importlib_external.SourceFileLoader object at 0x703a9bb9fc10>
        __name__   = 'fastapi.testclient'
        __package__ = 'fastapi'
        __spec__   = ModuleSpec(name='fastapi.testclient', loader=<_frozen_importlib_external.SourceFileLoader object at 0x703a9bb9fc10>, origin='/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/testclient.py')
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py[0m:46: in <module>
    [0m[94mraise[39;49;00m [96mRuntimeError[39;49;00m([90m[39;49;00m
[1m[31mE   RuntimeError: The starlette.testclient module requires the httpx package to be installed.[0m
[1m[31mE   You can install this with:[0m
[1m[31mE       $ pip install httpx[0m
        ASGIApp    = typing.Callable[[collections.abc.MutableMapping[str, typing.Any], typing.Callable[[], collections.abc.Awaitable[collec...[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]], collections.abc.Awaitable[None]]
        AbstractContextManager = <class 'contextlib.AbstractContextManager'>
        Any        = typing.Any
        Awaitable  = <class 'collections.abc.Awaitable'>
        Callable   = typing.Callable
        Future     = <class 'concurrent.futures._base.Future'>
        Generator  = <class 'collections.abc.Generator'>
        GeneratorType = <class 'generator'>
        Iterable   = <class 'collections.abc.Iterable'>
        Literal    = typing.Literal
        Mapping    = <class 'collections.abc.Mapping'>
        Message    = collections.abc.MutableMapping[str, typing.Any]
        MutableMapping = <class 'collections.abc.MutableMapping'>
        Receive    = typing.Callable[[], collections.abc.Awaitable[collections.abc.MutableMapping[str, typing.Any]]]
        Scope      = collections.abc.MutableMapping[str, typing.Any]
        Self       = typing.Self
        Send       = typing.Callable[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]
        Sequence   = <class 'collections.abc.Sequence'>
        StapledObjectStream = <class 'anyio.streams.stapled.StapledObjectStream'>
        TypeGuard  = typing.TypeGuard
        TypedDict  = <function TypedDict at 0x703ad7a72b60>
        Union      = typing.Union
        WebSocketDisconnect = <class 'starlette.websockets.WebSocketDisconnect'>
        __builtins__ = <builtins>
        __cached__ = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/__pycache__/testclient.cpython-311.pyc'
        __doc__    = None
        __file__   = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py'
        __loader__ = <_frozen_importlib_external.SourceFileLoader object at 0x703a9b81d2d0>
        __name__   = 'starlette.testclient'
        __package__ = 'starlette'
        __spec__   = ModuleSpec(name='starlette.testclient', loader=<_frozen_importlib_external.SourceFileLoader object at 0x703a9b81d2d0>, origin='/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py')
        annotations = _Feature((3, 7, 0, 'beta', 1), None, 16777216)
        anyio      = <module 'anyio' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/anyio/__init__.py'>
        cast       = <function cast at 0x703ad76ed4e0>
        contextlib = <module 'contextlib' from '/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py'>
        inspect    = <module 'inspect' from '/opt/miniconda3/envs/testbed/lib/python3.11/inspect.py'>
        io         = <module 'io' (frozen)>
        is_async_callable = <function is_async_callable at 0x703a9b9718a0>
        json       = <module 'json' from '/opt/miniconda3/envs/testbed/lib/python3.11/json/__init__.py'>
        math       = <module 'math' from '/opt/miniconda3/envs/testbed/lib/python3.11/lib-dynload/math.cpython-311-x86_64-linux-gnu.so'>
        sys        = <module 'sys' (built-in)>
        unquote    = <function unquote at 0x703ad77aa200>
        urljoin    = <function urljoin at 0x703ad77a9f80>
        warnings   = <module 'warnings' from '/opt/miniconda3/envs/testbed/lib/python3.11/warnings.py'>
[36m[1m=========================== short test summary info ============================[0m
[31mERROR[0m tests/gateway/test_gateway_app.py - RuntimeError: The starlette.testclient module requires the httpx package to...
!!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
[31m=============================== [31m[1m1 error[0m[31m in 0.40s[0m[31m ===============================[0m
```

## 原始行 49 · agent_message

```
The implementation is in place and the focused gateway tests are running. One compatibility detail I’m checking closely is how malformed pagination tokens surface through the API, since those need to remain `MlflowException` failures rather than leaking decoder or JSON exceptions.
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc "python -m pytest tests/gateway/test_gateway_config_parsing.py -q; python - <<'PY'
import base64
import json
import os
import warnings

from mlflow.exceptions import MlflowException
import mlflow.gateway.utils as u

assert u.assemble_uri_path([]) == '/'
assert u.assemble_uri_path([None, '', '/', '/api/', 'v1/']) == '/api/v1'
assert u._is_valid_uri('databricks')
assert u._is_valid_uri('databricks:profile')
assert u._is_valid_uri('databricks://workspace')
assert u._is_valid_uri('https://example.com')
assert not u._is_valid_uri('https://')
assert not u._is_valid_uri('localhost:5000')
assert u.resolve_route_url('http://localhost:5000/', '/api/x') == 'http://localhost:5000/api/x'
assert u.resolve_route_url('http://localhost:5000', 'https://example.com/a') == 'https://example.com/a'
assert u.is_valid_endpoint_name('endpoint_1.x-λ')
assert not u.is_valid_endpoint_name('')
assert not u.is_valid_endpoint_name('endpoint/x')
for index in (0, 1, 100):
    encoded = u.SearchRoutesToken(index).encode()
    assert json.loads(base64.b64decode(encoded)) == {'index': index}
    assert u.SearchRoutesToken.decode(encoded).index == index
for bad in ('not base64', base64.b64encode(b'{}').decode(), base64.b64encode(b'{').decode(), base64.b64encode(b'{\"index\": -1}').decode()):
    try:
        u.SearchRoutesToken.decode(bad)
    except MlflowException as e:
        assert e.error_code == 'INVALID_PARAMETER_VALUE'
    else:
        raise AssertionError(bad)
with warnings.catch_warnings():
    warnings.simplefilter('ignore')
    u._gateway_uri = None
    os.environ.pop('MLFLOW_GATEWAY_URI', None)
    try:
        u.get_gateway_uri()
    except MlflowException:
        pass
    else:
        raise AssertionError
    os.environ['MLFLOW_GATEWAY_URI'] = 'anything-from-env'
    assert u.get_gateway_uri() == 'anything-from-env'
    u.set_gateway_uri('http://localhost:5000')
    assert u.get_gateway_uri() == 'http://localhost:5000'
print('direct utility checks passed')
PY"
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 23 items

tests/gateway/test_gateway_config_parsing.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m     [100%][0m

=================================== FAILURES ===================================
[31m[1m_______________________ test_route_configuration_parsing _______________________[0m

basic_config_dict = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'model': {'config': {'openai_api_base': 'https://api.openai.com...': {'config': {'anthropic_api_key': 'api_key'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}]}
tmp_path = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f3ff929450>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_route_configuration_parsing[39;49;00m(basic_config_dict, tmp_path, monkeypatch):[90m[39;49;00m
        conf_path = tmp_path.joinpath([33m"[39;49;00m[33mconfig.yaml[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        conf_path.write_text(yaml.safe_dump(basic_config_dict))[90m[39;49;00m
    [90m[39;49;00m
        loaded_config = _load_gateway_config(conf_path)[90m[39;49;00m
    [90m[39;49;00m
        save_path = tmp_path.joinpath([33m"[39;49;00m[33mconfig2.yaml[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        _save_route_config(loaded_config, save_path)[90m[39;49;00m
>       loaded_from_save = _load_gateway_config(save_path)[90m[39;49;00m
                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

basic_config_dict = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'model': {'config': {'openai_api_base': 'https://api.openai.com...': {'config': {'anthropic_api_key': 'api_key'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}]}
conf_path  = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0/config.yaml')
loaded_config = GatewayConfig(endpoints=[EndpointConfig(name='completions-gpt4', endpoint_type=<EndpointType.LLM_V1_COMPLETIONS: 'llm/...pic'>, config=AnthropicConfig(anthropic_api_key='api_key', anthropic_version='2023-06-01')), limit=None)], routes=None)
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f3ff929450>
save_path  = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0/config2.yaml')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0')

[1m[31mtests/gateway/test_gateway_config_parsing.py[0m:138: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/gateway/config.py[0m:508: in _load_gateway_config
    [0m[94mreturn[39;49;00m GatewayConfig(**configuration)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        configuration = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'limit': None, 'model': {'config': {'openai_api_base': 'https:/...hropic_version': '2023-06-01'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}], 'routes': None}
        path       = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0/config2.yaml')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'mlflow.gateway.config.EndpointConfig'>, value = None

    [0m[37m@field_validator[39;49;00m([33m"[39;49;00m[33mlimit[39;49;00m[33m"[39;49;00m, mode=[33m"[39;49;00m[33mbefore[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mvalidate_limit[39;49;00m([96mcls[39;49;00m, value):[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mlimits[39;49;00m[90m [39;49;00m[94mimport[39;49;00m parse[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'limits'[0m

cls        = <class 'mlflow.gateway.config.EndpointConfig'>
value      = None

[1m[31mmlflow/gateway/config.py[0m:392: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:09:06 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
0.05s call     tests/gateway/test_gateway_config_parsing.py::test_api_key_parsing_file
0.01s call     tests/gateway/test_gateway_config_parsing.py::test_convert_route_config_to_routes_payload
0.01s call     tests/gateway/test_gateway_config_parsing.py::test_invalid_model_definition

(7 durations < 0.005s hidden.  Use -vv to show these durations.)
========================= command to run failed tests ==========================
pytest 'tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 23.8/33.7 GB | DISK 793.0/915.7 GB[0m tests/gateway/test_gateway_config_parsing.py::[1mtest_route_configuration_parsing[0m - ModuleNotFoundError: No module named 'limits'
[31m========================= [31m[1m1 failed[0m, [32m22 passed[0m[31m in 0.22s[0m[31m =========================[0m
direct utility checks passed
```

## 原始行 54 · agent_message

```
The utility checks pass, and 22/23 visible configuration tests pass. The remaining visible failure is environmental (`limits` is not installed), occurring in an unrelated pre-existing validator; the app suite likewise cannot collect because `httpx` is absent. I’m now tightening edge cases and running static checks plus targeted validation cases.
```

## 原始行 56 · command_execution

命令：
```
/bin/bash -lc 'ruff check mlflow/gateway/utils.py 2>&1 || true; ruff format --check mlflow/gateway/utils.py 2>&1 || true; git diff --check; git diff --stat; git diff -- mlflow/gateway/utils.py'
```

退出码：`0`

输出：
```
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
 mlflow/gateway/utils.py | 132 +++++++++++++++++++++++++++++++++++++++++++++++-
 1 file changed, 130 insertions(+), 2 deletions(-)
diff --git a/mlflow/gateway/utils.py b/mlflow/gateway/utils.py
index a9487c4..f2ea274 100644
--- a/mlflow/gateway/utils.py
+++ b/mlflow/gateway/utils.py
@@ -19,6 +19,75 @@ _logger = logging.getLogger(__name__)
 _gateway_uri: str | None = None
 
 
+def _is_valid_uri(uri: str):
+    """Return whether *uri* has the structure required for a gateway URI."""
+    if uri == "databricks":
+        return True
+
+    try:
+        parsed = urlparse(uri)
+        return bool(parsed.scheme and (parsed.scheme == "databricks" or parsed.netloc))
+    except ValueError:
+        return False
+
+
+def assemble_uri_path(paths: list[str]) -> str:
+    """Join URI path components into a normalized absolute path."""
+    return posixpath.join("/", *(path.strip("/") for path in paths if path))
+
+
+def check_configuration_route_name_collisions(config):
+    """Validate endpoint and traffic-route names and destination configuration."""
+    endpoints = config.get("endpoints", []) or []
+    routes = config.get("routes", []) or []
+
+    endpoint_names = [endpoint["name"] for endpoint in endpoints]
+    route_names = [route["name"] for route in routes]
+    all_names = endpoint_names + route_names
+    if len(all_names) != len(set(all_names)):
+        raise MlflowException.invalid_parameter_value(
+            "Duplicate names found in endpoint / route configurations"
+        )
+
+    endpoint_types = {
+        endpoint["name"]: endpoint["endpoint_type"] for endpoint in endpoints
+    }
+    for route in routes:
+        route_name = route["name"]
+        task_type = route["task_type"]
+        total_traffic = 0
+        for destination in route["destinations"]:
+            destination_name = destination["name"]
+            if destination_name not in endpoint_types:
+                raise MlflowException.invalid_parameter_value(
+                    f"Route '{route_name}' references undefined endpoint "
+                    f"'{destination_name}'"
+                )
+            if endpoint_types[destination_name] != task_type:
+                raise MlflowException.invalid_parameter_value(
+                    f"Route '{route_name}' has task type '{task_type}', which does not match "
+                    f"endpoint '{destination_name}' type '{endpoint_types[destination_name]}'"
+                )
+
+            traffic_percentage = destination["traffic_percentage"]
+            try:
+                is_valid_percentage = 0 <= traffic_percentage <= 100
+            except TypeError:
+                is_valid_percentage = False
+            if not is_valid_percentage:
+                raise MlflowException.invalid_parameter_value(
+                    f"Traffic percentage for endpoint '{destination_name}' in route "
+                    f"'{route_name}' must be between 0 and 100"
+                )
+            total_traffic += traffic_percentage
+
+        if total_traffic != 100:
+            raise MlflowException.invalid_parameter_value(
+                f"Traffic percentages for route '{route_name}' must sum to 100; "
+                f"got {total_traffic}"
+            )
+
+
 
 
 
@@ -108,6 +177,16 @@ def kill_child_processes(parent_pid):
         p.kill()
 
 
+def is_valid_endpoint_name(name: str) -> bool:
+    """Return whether *name* is safe to use as a URL path component."""
+    return bool(re.fullmatch(r"[\w.-]+", name))
+
+
+def resolve_route_url(base_url: str, route: str) -> str:
+    """Resolve a route path against a gateway URL, preserving absolute URLs."""
+    return route if _is_valid_uri(route) else append_to_uri_path(base_url, route)
+
+
 
 
 
@@ -175,6 +254,32 @@ def gateway_deprecated(obj):
         return wrapper
 
 
+@gateway_deprecated
+def get_gateway_uri() -> str:
+    """Return the configured MLflow AI Gateway server URI."""
+    if _gateway_uri is not None:
+        return _gateway_uri
+    if uri := MLFLOW_GATEWAY_URI.get():
+        return uri
+    raise MlflowException(
+        "No Gateway server URI has been set. Please either set the Gateway server URI via "
+        "`mlflow.gateway.set_gateway_uri()` or set the environment variable "
+        f"{MLFLOW_GATEWAY_URI} to the running Gateway server's URI"
+    )
+
+
+@gateway_deprecated
+def set_gateway_uri(gateway_uri: str):
+    """Set the MLflow AI Gateway server URI used by the fluent APIs."""
+    if not _is_valid_uri(gateway_uri):
+        raise MlflowException.invalid_parameter_value(
+            "The gateway URI provided is not a valid URI or 'databricks'"
+        )
+
+    global _gateway_uri
+    _gateway_uri = gateway_uri
+
+
 
 
 
@@ -248,7 +353,30 @@ def gateway_deprecated(obj):
 
 
 class SearchRoutesToken:
-    pass
+    def __init__(self, index: int):
+        self._index = index
+
+    @classmethod
+    def decode(cls, encoded_token: str):
+        try:
+            decoded_token = base64.b64decode(encoded_token, validate=True)
+            parsed_token = json.loads(decoded_token)
+            index = int(parsed_token["index"])
+            if index < 0:
+                raise ValueError("Token index must be non-negative")
+            return cls(index)
+        except Exception as e:
+            raise MlflowException.invalid_parameter_value(
+                f"Invalid page token: {encoded_token}"
+            ) from e
+
+    def encode(self) -> str:
+        token = json.dumps({"index": self._index}).encode("utf-8")
+        return base64.b64encode(token).decode("utf-8")
+
+    @property
+    def index(self):
+        return self._index
 
 
 
@@ -337,4 +465,4 @@ async def make_streaming_response(resp):
             media_type="text/event-stream",
         )
     else:
-        return await resp
\ No newline at end of file
+        return await resp
```

## 原始行 60 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,220p' mlflow/gateway/__init__.py; grep -RIn \"mlflow.gateway\" mlflow/__init__.py | head -30; python - <<'PY'
from mlflow.gateway.utils import check_configuration_route_name_collisions
from mlflow.exceptions import MlflowException

base_endpoint = {'name': 'chat', 'endpoint_type': 'llm/v1/chat'}
cases = [
    ({'endpoints': [base_endpoint, dict(base_endpoint)]}, 'duplicate endpoints'),
    ({'endpoints': [base_endpoint], 'routes': [{'name': 'chat', 'task_type': 'llm/v1/chat', 'destinations': []}]}, 'cross collision'),
    ({'endpoints': [base_endpoint], 'routes': [{'name': 'route', 'task_type': 'llm/v1/chat', 'destinations': [{'name': 'missing', 'traffic_percentage': 100}]}]}, 'missing endpoint'),
    ({'endpoints': [base_endpoint], 'routes': [{'name': 'route', 'task_type': 'llm/v1/completions', 'destinations': [{'name': 'chat', 'traffic_percentage': 100}]}]}, 'type mismatch'),
    ({'endpoints': [base_endpoint], 'routes': [{'name': 'route', 'task_type': 'llm/v1/chat', 'destinations': [{'name': 'chat', 'traffic_percentage': 101}]}]}, 'out of range'),
    ({'endpoints': [base_endpoint], 'routes': [{'name': 'route', 'task_type': 'llm/v1/chat', 'destinations': [{'name': 'chat', 'traffic_percentage': 99}]}]}, 'bad sum'),
]
for config, label in cases:
    try:
        check_configuration_route_name_collisions(config)
    except MlflowException as e:
        assert e.error_code == 'INVALID_PARAMETER_VALUE'
        print(label, '->', e)
    else:
        raise AssertionError(label)
check_configuration_route_name_collisions({'endpoints': [base_endpoint], 'routes': [{'name': 'route', 'task_type': 'llm/v1/chat', 'destinations': [{'name': 'chat', 'traffic_percentage': 100}]}]})
print('configuration validation checks passed')
PY
python -m compileall -q mlflow/gateway/utils.py
git diff --check"
```

退出码：`0`

输出：
```


__all__ = [
    "get_gateway_uri",
    "set_gateway_uri",
]
410:# `mlflow.gateway` depends on optional dependencies such as pydantic, psutil, and has version
duplicate endpoints -> Duplicate names found in endpoint / route configurations
cross collision -> Duplicate names found in endpoint / route configurations
missing endpoint -> Route 'route' references undefined endpoint 'missing'
type mismatch -> Route 'route' has task type 'llm/v1/completions', which does not match endpoint 'chat' type 'llm/v1/chat'
out of range -> Traffic percentage for endpoint 'chat' in route 'route' must be between 0 and 100
bad sum -> Traffic percentages for route 'route' must sum to 100; got 99
configuration validation checks passed
```

## 原始行 63 · command_execution

命令：
```
/bin/bash -lc "sed -n '380,435p' mlflow/__init__.py; grep -RIn \"gateway.set_gateway_uri\\|gateway.get_gateway_uri\" mlflow --include='*.py' | head -100; python - <<'PY'
import mlflow.gateway
print(hasattr(mlflow.gateway, 'set_gateway_uri'))
try:
    from mlflow.gateway import set_gateway_uri
    print(set_gateway_uri)
except Exception as e:
    print(type(e).__name__, e)
PY"
```

退出码：`0`

输出：
```
        "search_registered_models",
        "search_runs",
        "search_prompts",
        "set_active_model",
        "set_experiment_tag",
        "set_experiment_tags",
        "delete_experiment_tag",
        "set_model_version_tag",
        "set_registry_uri",
        "set_system_metrics_node_id",
        "set_system_metrics_samples_before_logging",
        "set_system_metrics_sampling_interval",
        "set_tag",
        "set_tags",
        "start_run",
        "validate_evaluation_results",
        "Image",
        # Prompt Registry APIs
        # TODO: Prompt Registry APIs are moved to the `mlflow.genai` namespace and direct
        # imports from mlflow will be deprecated in the future.
        "load_prompt",
        "register_prompt",
        "search_prompts",
        "set_prompt_alias",
        "delete_prompt_alias",
        "set_logged_model_tags",
        "delete_logged_model_tag",
    ]


# `mlflow.gateway` depends on optional dependencies such as pydantic, psutil, and has version
# restrictions for dependencies. Importing this module fails if they are not installed or
# if invalid versions of these required packages are installed.
with contextlib.suppress(Exception):
    from mlflow import gateway  # noqa: F401

    __all__.append("gateway")

from mlflow.telemetry import set_telemetry_client

set_telemetry_client()
mlflow/gateway/utils.py:266:        "`mlflow.gateway.set_gateway_uri()` or set the environment variable "
False
ImportError cannot import name 'set_gateway_uri' from 'mlflow.gateway' (/testbed/mlflow/gateway/__init__.py)
```

## 原始行 66 · command_execution

命令：
```
/bin/bash -lc "find mlflow/gateway -maxdepth 2 -type f -name '*.py' -print | sort; grep -RInE \"def (query|get_route|search_routes|set_gateway_uri|get_gateway_uri)|class MlflowGatewayClient\" mlflow/gateway --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/gateway/__init__.py
mlflow/gateway/app.py
mlflow/gateway/base_models.py
mlflow/gateway/cli.py
mlflow/gateway/config.py
mlflow/gateway/constants.py
mlflow/gateway/exceptions.py
mlflow/gateway/provider_registry.py
mlflow/gateway/providers/__init__.py
mlflow/gateway/providers/ai21labs.py
mlflow/gateway/providers/anthropic.py
mlflow/gateway/providers/base.py
mlflow/gateway/providers/bedrock.py
mlflow/gateway/providers/cohere.py
mlflow/gateway/providers/gemini.py
mlflow/gateway/providers/huggingface.py
mlflow/gateway/providers/mistral.py
mlflow/gateway/providers/mlflow.py
mlflow/gateway/providers/mosaicml.py
mlflow/gateway/providers/openai.py
mlflow/gateway/providers/palm.py
mlflow/gateway/providers/togetherai.py
mlflow/gateway/providers/utils.py
mlflow/gateway/runner.py
mlflow/gateway/schemas/__init__.py
mlflow/gateway/schemas/chat.py
mlflow/gateway/schemas/completions.py
mlflow/gateway/schemas/embeddings.py
mlflow/gateway/uc_function_utils.py
mlflow/gateway/utils.py
mlflow/gateway/utils.py:258:def get_gateway_uri() -> str:
mlflow/gateway/utils.py:272:def set_gateway_uri(gateway_uri: str):
mlflow/gateway/app.py:366:    async def get_route_v3(route_name: str) -> TrafficRouteConfig:
```

## 原始行 69 · agent_message

```
I found one repository-level compatibility gap tied directly to these utilities: `mlflow.gateway.__all__` advertises `get_gateway_uri` and `set_gateway_uri`, but the package no longer imports them, so the documented public calls fail. I’m restoring those package exports as part of the gateway behavior contract.
```

## 原始行 71 · file_change

```
{
  "id": "item_49",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/gateway/__init__.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 74 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import warnings
from mlflow.gateway import get_gateway_uri, set_gateway_uri
import mlflow.gateway.utils as utils

with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always')
    set_gateway_uri('databricks')
    assert get_gateway_uri() == 'databricks'
    assert len(caught) == 2
    assert all(w.category is FutureWarning for w in caught)
assert utils._gateway_uri == 'databricks'
print('public gateway exports and deprecation warnings passed')
PY
python -m pytest tests/gateway/test_gateway_config_parsing.py -q --ignore=tests/gateway/test_gateway_app.py 2>&1 | tail -30
git diff --check
git status --short"
```

退出码：`0`

输出：
```
public gateway exports and deprecation warnings passed
    [0m[94mreturn[39;49;00m GatewayConfig(**configuration)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        configuration = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'limit': None, 'model': {'config': {'openai_api_base': 'https:/...hropic_version': '2023-06-01'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}], 'routes': None}
        path       = PosixPath('/tmp/pytest-of-root/pytest-1/test_route_configuration_parsi0/config2.yaml')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'mlflow.gateway.config.EndpointConfig'>, value = None

    [0m[37m@field_validator[39;49;00m([33m"[39;49;00m[33mlimit[39;49;00m[33m"[39;49;00m, mode=[33m"[39;49;00m[33mbefore[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mvalidate_limit[39;49;00m([96mcls[39;49;00m, value):[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mlimits[39;49;00m[90m [39;49;00m[94mimport[39;49;00m parse[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'limits'[0m

cls        = <class 'mlflow.gateway.config.EndpointConfig'>
value      = None

[1m[31mmlflow/gateway/config.py[0m:392: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:10:02 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
0.03s call     tests/gateway/test_gateway_config_parsing.py::test_api_key_parsing_file
0.01s call     tests/gateway/test_gateway_config_parsing.py::test_convert_route_config_to_routes_payload

(8 durations < 0.005s hidden.  Use -vv to show these durations.)
========================= command to run failed tests ==========================
pytest 'tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 23.9/33.7 GB | DISK 793.0/915.7 GB[0m tests/gateway/test_gateway_config_parsing.py::[1mtest_route_configuration_parsing[0m - ModuleNotFoundError: No module named 'limits'
[31m========================= [31m[1m1 failed[0m, [32m22 passed[0m[31m in 0.19s[0m[31m =========================[0m
 M mlflow/gateway/__init__.py
 M mlflow/gateway/utils.py
```

## 原始行 79 · command_execution

命令：
```
/bin/bash -lc "ruff check --isolated mlflow/gateway/utils.py mlflow/gateway/__init__.py; ruff format --isolated --check mlflow/gateway/utils.py mlflow/gateway/__init__.py; python - <<'PY'
from mlflow.gateway.utils import check_configuration_route_name_collisions

config = {
    'endpoints': [
        {'name': 'chat-a', 'endpoint_type': 'llm/v1/chat'},
        {'name': 'chat-b', 'endpoint_type': 'llm/v1/chat'},
    ],
    'routes': [{
        'name': 'split',
        'task_type': 'llm/v1/chat',
        'destinations': [
            {'name': 'chat-a', 'traffic_percentage': 0},
            {'name': 'chat-b', 'traffic_percentage': 100},
        ],
    }],
}
check_configuration_route_name_collisions(config)
print('boundary traffic validation passed')
PY"
```

退出码：`0`

输出：
```
E741 Ambiguous variable name: `l`
   --> mlflow/gateway/utils.py:205:9
    |
204 | def _get_indent(s: str) -> str:
205 |     for l in s.splitlines():
    |         ^
206 |         if l.startswith(" "):
207 |             return " " * (len(l) - len(l.lstrip()))
    |

Found 1 error.
Would reformat: mlflow/gateway/__init__.py
Would reformat: mlflow/gateway/utils.py
2 files would be reformatted
boundary traffic validation passed
```

## 原始行 82 · command_execution

命令：
```
/bin/bash -lc 'nl -ba mlflow/gateway/__init__.py; ruff format --isolated --diff mlflow/gateway/__init__.py mlflow/gateway/utils.py 2>/dev/null | head -200'
```

退出码：`0`

输出：
```
     1	
     2	from mlflow.gateway.utils import get_gateway_uri, set_gateway_uri
     3	
     4	
     5	__all__ = [
     6	    "get_gateway_uri",
     7	    "set_gateway_uri",
     8	]
--- mlflow/gateway/__init__.py
+++ mlflow/gateway/__init__.py
@@ -1,4 +1,3 @@
-
 from mlflow.gateway.utils import get_gateway_uri, set_gateway_uri
 
 

--- mlflow/gateway/utils.py
+++ mlflow/gateway/utils.py
@@ -12,7 +12,9 @@
 
 from mlflow.environment_variables import MLFLOW_GATEWAY_URI
 from mlflow.exceptions import MlflowException
-from mlflow.gateway.constants import MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES
+from mlflow.gateway.constants import (
+    MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES,
+)
 from mlflow.utils.uri import append_to_uri_path
 
 _logger = logging.getLogger(__name__)
@@ -86,70 +88,8 @@
                 f"Traffic percentages for route '{route_name}' must sum to 100; "
                 f"got {total_traffic}"
             )
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
 
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
 def check_configuration_deprecated_fields(config):
     endpoints = config.get("endpoints", [])
     for endpoint in endpoints:
@@ -185,22 +125,8 @@
 def resolve_route_url(base_url: str, route: str) -> str:
     """Resolve a route path against a gateway URL, preserving absolute URLs."""
     return route if _is_valid_uri(route) else append_to_uri_path(base_url, route)
-
-
-
-
 
 
-
-
-
-
-
-
-
-
-
-
 def _get_indent(s: str) -> str:
     for l in s.splitlines():
         if l.startswith(" "):
@@ -278,80 +204,8 @@
 
     global _gateway_uri
     _gateway_uri = gateway_uri
-
-
-
-
-
-
-
-
-
-
-
-
-
 
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
 class SearchRoutesToken:
     def __init__(self, index: int):
         self._index = index
@@ -377,39 +231,6 @@
     @property
     def index(self):
         return self._index
```

## 原始行 85 · file_change

```
{
  "id": "item_59",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/gateway/__init__.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 87 · agent_message

```
The public exports, deprecation warnings, URI selection precedence, base64 round trips, malformed-token handling, Unicode endpoint names, and traffic split boundary cases all pass direct checks. I’m doing one final focused run that excludes only the single test blocked by the missing optional `limits` package.
```

## 原始行 89 · command_execution

命令：
```
/bin/bash -lc "python -m pytest tests/gateway/test_gateway_config_parsing.py -q -k 'not route_configuration_parsing'; python -m pytest tests/deployments/test_utils.py -q; python -m compileall -q mlflow/gateway; git diff --check; git status --short; git diff --stat"
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 23 items / 1 deselected / 22 selected

tests/gateway/test_gateway_config_parsing.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m      [100%][0m

============================= slowest 10 durations =============================
0.03s call     tests/gateway/test_gateway_config_parsing.py::test_api_key_parsing_file
0.01s call     tests/gateway/test_gateway_config_parsing.py::test_convert_route_config_to_routes_payload

(8 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m======================= [32m[1m22 passed[0m, [33m1 deselected[0m[32m in 0.11s[0m[32m =======================[0m
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 2 items

tests/deployments/test_utils.py [32m.[0m[32m.[0m[32m                                       [100%][0m

============================= slowest 10 durations =============================

(6 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m============================== [32m[1m2 passed[0m[32m in 0.03s[0m[32m ===============================[0m
 M mlflow/gateway/__init__.py
 M mlflow/gateway/utils.py
 mlflow/gateway/__init__.py |   1 +
 mlflow/gateway/utils.py    | 132 ++++++++++++++++++++++++++++++++++++++++++++-
 2 files changed, 131 insertions(+), 2 deletions(-)
```

## 原始行 91 · agent_message

```
Implemented gateway utility restoration in:

- [mlflow/gateway/utils.py](/testbed/mlflow/gateway/utils.py)
- [mlflow/gateway/__init__.py](/testbed/mlflow/gateway/__init__.py)

Restored URI validation/selection, route path and URL assembly, endpoint-name validation, configuration collision and traffic validation, pagination token encoding/decoding, deprecated warnings, and public gateway exports.

Validation:

- 22 focused gateway configuration tests passed.
- 2 deployments utility tests passed.
- Direct edge-case checks passed.
- Full gateway tests were limited by missing optional `limits` and `httpx` dependencies.
```
