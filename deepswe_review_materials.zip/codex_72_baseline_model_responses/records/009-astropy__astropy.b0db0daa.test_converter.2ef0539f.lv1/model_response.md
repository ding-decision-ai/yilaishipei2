# Codex baseline: astropy__astropy.b0db0daa.test_converter.2ef0539f.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll trace the existing VOTable validation and converter patterns in the current tree, implement the requested interfaces in place, then run the focused tests and expand only where failures reveal a genuine integration issue.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' astropy/utils/xml/check.py && sed -n '1,280p' astropy/io/votable/ucd.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
A collection of functions for checking various XML-related strings for
standards compliance.
"""

import re
import urllib.parse




























_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"














def check_mime_content_type(content_type):
    """
    Returns `True` if *content_type* is a valid MIME content type
    (syntactically at least), as defined by RFC 2045.
    """
    ctrls = "".join(chr(x) for x in range(0x20))
    token_regex = f'[^()<>@,;:\\"/[\\]?= {ctrls}\x7f]+'
    return (
        re.match(rf"(?P<type>{token_regex})/(?P<subtype>{token_regex})$", content_type)
        is not None
    )


def check_anyuri(uri):
    """
    Returns `True` if *uri* is a valid URI as defined in RFC 2396.
    """
    if (
        re.match(
            (
                r"(([a-zA-Z][0-9a-zA-Z+\-\.]*:)?/{0,2}[0-9a-zA-Z;"
                r"/?:@&=+$\.\-_!~*'()%]+)?(#[0-9a-zA-Z;/?:@&=+$\.\-_!~*'()%]+)?"
            ),
            uri,
        )
        is None
    ):
        return False
    try:
        urllib.parse.urlparse(uri)
    except Exception:
        return False
    return True# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This file contains routines to verify the correctness of UCD strings.
"""

# STDLIB
import re

# LOCAL
from astropy.utils import data

__all__ = ["check_ucd", "parse_ucd"]


class UCDWords:
    """
    Manages a list of acceptable UCD words.

    Works by reading in a data file exactly as provided by IVOA.  This
    file resides in data/ucd1p-words.txt.
    """

































    def get_description(self, name):
        """
        Returns the official English description of the given UCD
        *name*.
        """
        return self._descriptions[name.lower()]








_ucd_singleton = None


def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
    """
    Parse the UCD into its component parts.

    Parameters
    ----------
    ucd : str
        The UCD string

    check_controlled_vocabulary : bool, optional
        If `True`, then each word in the UCD will be verified against
        the UCD1+ controlled vocabulary, (as required by the VOTable
        specification version 1.2), otherwise not.

    has_colon : bool, optional
        If `True`, the UCD may contain a colon (as defined in earlier
        versions of the standard).

    Returns
    -------
    parts : list
        The result is a list of tuples of the form:

            (*namespace*, *word*)

        If no namespace was explicitly specified, *namespace* will be
        returned as ``'ivoa'`` (i.e., the default namespace).

    Raises
    ------
    ValueError
        if *ucd* is invalid
    """
    global _ucd_singleton
    if _ucd_singleton is None:
        _ucd_singleton = UCDWords()

    if has_colon:
        m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
    else:
        m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
    if m is not None:
        raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")

    word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
    word_re = rf"{word_component_re}(\.{word_component_re})*"

    parts = ucd.split(";")
    words = []
    for i, word in enumerate(parts):
        colon_count = word.count(":")
        if colon_count == 1:
            ns, word = word.split(":", 1)
            if not re.match(word_component_re, ns):
                raise ValueError(f"Invalid namespace '{ns}'")
            ns = ns.lower()
        elif colon_count > 1:
            raise ValueError(f"Too many colons in '{word}'")
        else:
            ns = "ivoa"

        if not re.match(word_re, word):
            raise ValueError(f"Invalid word '{word}'")

        if ns == "ivoa" and check_controlled_vocabulary:
            if i == 0:
                if not _ucd_singleton.is_primary(word):
                    if _ucd_singleton.is_secondary(word):
                        raise ValueError(
                            f"Secondary word '{word}' is not valid as a primary word"
                        )
                    else:
                        raise ValueError(f"Unknown word '{word}'")
            else:
                if not _ucd_singleton.is_secondary(word):
                    if _ucd_singleton.is_primary(word):
                        raise ValueError(
                            f"Primary word '{word}' is not valid as a secondary word"
                        )
                    else:
                        raise ValueError(f"Unknown word '{word}'")

        try:
            normalized_word = _ucd_singleton.normalize_capitalization(word)
        except KeyError:
            normalized_word = word
        words.append((ns, normalized_word))

    return words


def check_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
    """
    Returns False if *ucd* is not a valid `unified content descriptor`_.

    Parameters
    ----------
    ucd : str
        The UCD string

    check_controlled_vocabulary : bool, optional
        If `True`, then each word in the UCD will be verified against
        the UCD1+ controlled vocabulary, (as required by the VOTable
        specification version 1.2), otherwise not.

    has_colon : bool, optional
        If `True`, the UCD may contain a colon (as defined in earlier
        versions of the standard).

    Returns
    -------
    valid : bool
    """
    if ucd is None:
        return True

    try:
        parse_ucd(
            ucd,
            check_controlled_vocabulary=check_controlled_vocabulary,
            has_colon=has_colon,
        )
    except ValueError:
        return False
    return True
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc "git status --short && rg -n \"def check_id|def fix_id|class Resource|def links|class TableElement|def get_field_by_id|def to_table|class Values|def _parse_minmax|def is_defaults|def check_string|class FloatingPoint|supports_empty_values|class UnicodeChar|_binoutput_fixed|_binoutput_var\" astropy/io/votable astropy/utils/xml -g '*.py'"
```

退出码：`127`

输出：
```
/bin/bash: line 1: rg: command not found
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"def check_id|def fix_id|class Resource|def links|class TableElement|def get_field_by_id|def to_table|class Values|def _parse_minmax|def is_defaults|def check_string|class FloatingPoint|supports_empty_values|class UnicodeChar|_binoutput_fixed|_binoutput_var\" astropy/io/votable astropy/utils/xml --include='*.py'"
```

退出码：`0`

输出：
```
astropy/io/votable/converters.py:187:    def supports_empty_values(self, config):
astropy/io/votable/converters.py:323:            self.binoutput = self._binoutput_var
astropy/io/votable/converters.py:339:                self.binoutput = self._binoutput_var
astropy/io/votable/converters.py:342:                self.binoutput = self._binoutput_fixed
astropy/io/votable/converters.py:346:    def supports_empty_values(self, config):
astropy/io/votable/converters.py:398:    def _binoutput_var(self, value, mask):
astropy/io/votable/converters.py:412:    def _binoutput_fixed(self, value, mask):
astropy/io/votable/converters.py:423:class UnicodeChar(Converter):
astropy/io/votable/converters.py:442:            self.binoutput = self._binoutput_var
astropy/io/votable/converters.py:457:                self.binoutput = self._binoutput_var
astropy/io/votable/converters.py:460:                self.binoutput = self._binoutput_fixed
astropy/io/votable/converters.py:726:class FloatingPoint(Numeric):
astropy/io/votable/tests/test_table.py:709:    if hasattr(converter, "_binoutput_var"):
astropy/io/votable/tests/test_table.py:711:            result = converter._binoutput_var(long_string, False)
astropy/io/votable/tests/test_table.py:835:    if hasattr(converter, "_binoutput_var"):
astropy/io/votable/tests/test_table.py:837:            result = converter._binoutput_var(long_string, False)
astropy/io/votable/tree.py:757:    def to_table_column(self, column):
astropy/io/votable/tree.py:948:class Values(Element, _IDProperty):
astropy/io/votable/tree.py:1264:    def to_table_column(self, column):
astropy/io/votable/tree.py:1658:    def links(self):
astropy/io/votable/tree.py:2478:class TableElement(
astropy/io/votable/tree.py:2691:    def links(self):
astropy/io/votable/tree.py:3398:                supports_empty_values = [
astropy/io/votable/tree.py:3399:                    field.converter.supports_empty_values(kwargs) for field in fields
astropy/io/votable/tree.py:3408:                    supports_empty_values,
astropy/io/votable/tree.py:3423:                        field.converter.supports_empty_values(kwargs),
astropy/io/votable/tree.py:3431:                    for i, output, supports_empty_values in fields:
astropy/io/votable/tree.py:3434:                        if supports_empty_values and np.all(masked):
astropy/io/votable/tree.py:3812:class Resource(
astropy/io/votable/xmlutil.py:25:def check_id(ID, name="ID", config=None, pos=None):
astropy/io/votable/xmlutil.py:39:def fix_id(ID, config=None, pos=None):
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,130p' astropy/io/votable/xmlutil.py && sed -n '130,230p' astropy/io/votable/converters.py && sed -n '280,490p' astropy/io/votable/converters.py && sed -n '680,770p' astropy/io/votable/converters.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Various XML-related utilities.
"""

# ASTROPY
from astropy.logger import log
from astropy.utils import data
from astropy.utils.xml import check as xml_check
from astropy.utils.xml import validate

# LOCAL
from .exceptions import W02, W03, W04, W05, vo_warn, warn_or_raise

__all__ = [
    "check_anyuri",
    "check_id",
    "check_mime_content_type",
    "check_token",
    "fix_id",
    "validate_schema",
]


def check_id(ID, name="ID", config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if *ID*
    is not a valid XML ID_.

    *name* is the name of the attribute being checked (used only for
    error messages).
    """
    if ID is not None and not xml_check.check_id(ID):
        warn_or_raise(W02, W02, (name, ID), config, pos)
        return False
    return True


def fix_id(ID, config=None, pos=None):
    """
    Given an arbitrary string, create one that can be used as an xml id.

    This is rather simplistic at the moment, since it just replaces
    non-valid characters with underscores.
    """
    if ID is None:
        return None
    corrected = xml_check.fix_id(ID)
    if corrected != ID:
        vo_warn(W03, (ID, corrected), config, pos)
    return corrected


_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"


def check_token(token, attr_name, config=None, pos=None):
    """
    Raises a `ValueError` if *token* is not a valid XML token.

    As defined by XML Schema Part 2.
    """
    return token is None or xml_check.check_token(token)


def check_mime_content_type(content_type, config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
    *content_type* is not a valid MIME content type.

    As defined by RFC 2045 (syntactically, at least).
    """
    if content_type is not None and not xml_check.check_mime_content_type(content_type):
        warn_or_raise(W04, W04, content_type, config, pos)
        return False
    return True


def check_anyuri(uri, config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
    *uri* is not a valid URI.

    As defined in RFC 2396.
    """
    if uri is not None and not xml_check.check_anyuri(uri):
        warn_or_raise(W05, W05, uri, config, pos)
        return False
    return True


def validate_schema(filename, version="1.1"):
    """
    Validates the given file against the appropriate VOTable schema.

    Parameters
    ----------
    filename : str
        The path to the XML file to validate

    version : str, optional
        The VOTABLE version to check, which must be a string \"1.0\",
        \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
        version \"1.1\" is assumed.

        For version \"1.0\", it is checked against a DTD, since that
        version did not have an XML Schema.

    Returns
    -------
    returncode, stdout, stderr : int, str, str
        Returns the returncode from xmllint and the stdout and stderr
        as strings
    """
    supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]

    if version == "1.0":
        schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
    else:
        if version not in supported_schemas:
            log.info(f"{filename} has version {version}, using schema 1.1")
            version = "1.1"
        schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")

    return validate.validate_schema(filename, schema_path)
    Returns
    -------
    bit_array : bytes
        The first value in the input array will be the most
        significant bit in the result.  The length will be `floor((N +
        7) / 8)` where `N` is the length of `value`.
    """
    value = value.flat
    bit_no = 7
    byte = 0
    bytes = []
    for v in value:
        if v:
            byte |= 1 << bit_no
        if bit_no == 0:
            bytes.append(byte)
            bit_no = 7
            byte = 0
        else:
            bit_no -= 1
    if bit_no != 7:
        bytes.append(byte)

    return struct.pack(f"{len(bytes)}B", *bytes)


class Converter:
    """
    The base class for all converters.  Each subclass handles
    converting a specific VOTABLE data type to/from the TABLEDATA_ and
    BINARY_ on-disk representations.

    Parameters
    ----------
    field : `~astropy.io.votable.tree.Field`
        object describing the datatype

    config : dict
        The parser configuration dictionary

    pos : tuple
        The position in the XML file where the FIELD object was
        found.  Used for error messages.

    """

    def __init__(self, field, config=None, pos=None):
        pass

    @staticmethod
    def _parse_length(read):
        return struct.unpack(">I", read(4))[0]





    def supports_empty_values(self, config):
        """
        Returns True when the field can be completely empty.
        """
        return config.get("version_1_3_or_later")

    def parse(self, value, config=None, pos=None):
        """
        Convert the string *value* from the TABLEDATA_ format into an
        object with the correct native in-memory datatype and mask flag.

        Parameters
        ----------
        value : str
            value in TABLEDATA format

        Returns
        -------
        native : tuple
            A two-element tuple of: value, mask.
            The value as a Numpy array or scalar, and *mask* is True
            if the value is missing.
        """
        raise NotImplementedError("This datatype must implement a 'parse' method.")

    def parse_scalar(self, value, config=None, pos=None):
        """
        Parse a single scalar of the underlying type of the converter.
        For non-array converters, this is equivalent to parse.  For
        array converters, this is used to parse a single
        element of the array.

        Parameters
        ----------
        value : str
            value in TABLEDATA format

        Returns
        -------
        native : (2,) tuple
            (value, mask)
            The value as a Numpy array or scalar, and *mask* is True
            if the value is missing.
        """

        Parameters
        ----------
        value
            The value, the native type corresponding to this converter

        mask : bool
            If `True`, will return the string representation of a
            masked value.

        Returns
        -------
        bytes : bytes
            The binary representation of the value, suitable for
            serialization in the BINARY_ format.
        """
        raise NotImplementedError("This datatype must implement a 'binoutput' method.")


class Char(Converter):
    """
    Handles the char datatype. (7-bit unsigned characters).

    Missing values are not handled for string or unicode types.
    """

    default = _empty_bytes

    def __init__(self, field, config=None, pos=None):
        if config is None:
            config = {}

        Converter.__init__(self, field, config, pos)

        self.field_name = field.name

        if field.arraysize is None:
            vo_warn(W47, (), config, pos)
            field.arraysize = "1"

        if field.arraysize == "*":
            self.format = "O"
            self.binparse = self._binparse_var
            self.binoutput = self._binoutput_var
            self.arraysize = "*"
        else:
            # Check if this is a bounded variable-length field
            is_variable = field.arraysize.endswith("*")
            numeric_part = field.arraysize.removesuffix("*")
            try:
                self.arraysize = int(numeric_part)
            except ValueError:
                vo_raise(E01, (numeric_part, "char", field.ID), config)

            self.format = f"U{self.arraysize:d}"

            # For bounded variable-length fields use the variable methods
            if is_variable:
                self.binparse = self._binparse_var
                self.binoutput = self._binoutput_var
            else:
                self.binparse = self._binparse_fixed
                self.binoutput = self._binoutput_fixed

            self._struct_format = f">{self.arraysize:d}s"

    def supports_empty_values(self, config):
        return True

    def parse(self, value, config=None, pos=None):
        if self.arraysize != "*" and len(value) > self.arraysize:
            vo_warn(W46, ("char", self.arraysize), config, pos)

        # Warn about non-ascii characters if warnings are enabled.
        try:
            value.encode("ascii")
        except UnicodeEncodeError:
            vo_warn(W55, (self.field_name, value), config, pos)
        return value, False

    def output(self, value, mask):
        if mask:
            return ""

        # The output methods for Char assume that value is either str or bytes.
        # This method needs to return a str, but needs to warn if the str contains
        # non-ASCII characters.
        try:
            if isinstance(value, str):
                value.encode("ascii")
            else:
                # Check for non-ASCII chars in the bytes object.
                value = value.decode("ascii")
        except (ValueError, UnicodeEncodeError):
            warn_or_raise(E24, UnicodeEncodeError, (value, self.field_name))
        finally:
            if isinstance(value, bytes):
                # Convert the bytes to str regardless of non-ASCII chars.
                value = value.decode("utf-8")

        return xml_escape_cdata(value)

    def _binparse_var(self, read):
        length = self._parse_length(read)

        if self.arraysize != "*" and length > self.arraysize:
            vo_warn(W46, ("char", self.arraysize), None, None)

        return read(length).decode("ascii"), False

    def _binparse_fixed(self, read):
        s = struct.unpack(self._struct_format, read(self.arraysize))[0]
        end = s.find(_zero_byte)
        s = s.decode("ascii")
        if end != -1:
            return s[:end], False
        return s, False

    def _binoutput_var(self, value, mask):
        if mask or value is None or value == "":
            return _zero_int
        if isinstance(value, str):
            try:
                value = value.encode("ascii")
            except ValueError:
                vo_raise(E24, (value, self.field_name))

        if self.arraysize != "*" and len(value) > self.arraysize:
            vo_warn(W46, ("char", self.arraysize), None, None)

        return self._write_length(len(value)) + value

    def _binoutput_fixed(self, value, mask):
        if mask:
            value = _empty_bytes
        elif isinstance(value, str):
            try:
                value = value.encode("ascii")
            except ValueError:
                vo_raise(E24, (value, self.field_name))
        return struct.pack(self._struct_format, value)


class UnicodeChar(Converter):
    """
    Handles the unicodeChar data type. UTF-16-BE.

    Missing values are not handled for string or unicode types.
    """

    default = ""

    def __init__(self, field, config=None, pos=None):
        Converter.__init__(self, field, config, pos)

        if field.arraysize is None:
            vo_warn(W47, (), config, pos)
            field.arraysize = "1"

        if field.arraysize == "*":
            self.format = "O"
            self.binparse = self._binparse_var
            self.binoutput = self._binoutput_var
            self.arraysize = "*"
        else:
            # Check if this is a bounded variable-length field
            is_variable = field.arraysize.endswith("*")
            numeric_part = field.arraysize.removesuffix("*")
            try:
                self.arraysize = int(numeric_part)
            except ValueError:
                vo_raise(E01, (numeric_part, "unicode", field.ID), config)

            self.format = f"U{self.arraysize:d}"

            if is_variable:
                self.binparse = self._binparse_var
                self.binoutput = self._binoutput_var
            else:
                self.binparse = self._binparse_fixed
                self.binoutput = self._binoutput_fixed

            self._struct_format = f">{self.arraysize * 2:d}s"

    def parse(self, value, config=None, pos=None):
        if self.arraysize != "*" and len(value) > self.arraysize:
            vo_warn(W46, ("unicodeChar", self.arraysize), config, pos)
        return value, False

    def output(self, value, mask):
        if mask:
            return ""
        return xml_escape_cdata(str(value))

    def _binparse_var(self, read):
        length = self._parse_length(read)

        if self.arraysize != "*" and length > self.arraysize:
            vo_warn(W46, ("unicodeChar", self.arraysize), None, None)

        return read(length * 2).decode("utf_16_be"), False

    def _binparse_fixed(self, read):
        s = struct.unpack(self._struct_format, read(self.arraysize * 2))[0]
        s = s.decode("utf_16_be")
        end = s.find("\0")
        if end != -1:
            return s[:end], False
        return s, False


        if mask.size <= 1:
            func = np.broadcast
        else:  # When mask is already array but value is scalar, this prevents broadcast
            func = zip
        return " ".join(base_output(x, m) for x, m in func(value.flat, mask.flat))

    def binparse(self, read):
        result = np.frombuffer(read(self._memsize), dtype=self._bigendian_format)[0]
        result_mask = self._base.is_null(result)
        return result, result_mask

    def binoutput(self, value, mask):
        filtered = self._base.filter_array(value, mask)
        filtered = _ensure_bigendian(filtered)
        return filtered.tobytes()


class Numeric(Converter):
    """
    The base class for all numeric data types.
    """

    array_type = NumericArray
    vararray_type = ScalarVarArray
    null = None

    def __init__(self, field, config=None, pos=None):
        Converter.__init__(self, field, config, pos)

        self._memsize = np.dtype(self.format).itemsize
        self._bigendian_format = ">" + self.format
        if field.values.null is not None:
            self.null = np.asarray(field.values.null, dtype=self.format)
            self.default = self.null
            self.is_null = self._is_null
        else:
            self.is_null = np.isnan

    def binparse(self, read):
        result = np.frombuffer(read(self._memsize), dtype=self._bigendian_format)
        return result[0], self.is_null(result[0])

    def _is_null(self, value):
        return value == self.null


class FloatingPoint(Numeric):
    """
    The base class for floating-point datatypes.
    """

    default = np.nan

    def __init__(self, field, config=None, pos=None):
        if config is None:
            config = {}

        Numeric.__init__(self, field, config, pos)

        precision = field.precision
        width = field.width

        if precision is None:
            format_parts = ["{!s:>"]
        else:
            format_parts = ["{:"]

        if width is not None:
            format_parts.append(str(width))

        if precision is not None:
            if precision.startswith("E"):
                format_parts.append(f".{int(precision[1:]):d}g")
            elif precision.startswith("F"):
                format_parts.append(f".{int(precision[1:]):d}f")
            else:
                format_parts.append(f".{int(precision):d}f")

        format_parts.append("}")

        self._output_format = "".join(format_parts)

        self.nan = np.array(np.nan, self.format)

        if self.null is None:
            self._null_output = "NaN"
            self._null_binoutput = self.binoutput(self.nan, False)
            self.filter_array = self._filter_nan
        else:
            self._null_output = self.output(np.asarray(self.null), False)
            self._null_binoutput = self.binoutput(np.asarray(self.null), False)
```

## 原始行 17 · command_execution

命令：
```
/bin/bash -lc "sed -n '770,860p' astropy/io/votable/converters.py && sed -n '1,180p' astropy/io/votable/tree.py && sed -n '900,1100p' astropy/io/votable/tree.py && sed -n '1580,1710p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
            self._null_binoutput = self.binoutput(np.asarray(self.null), False)
            self.filter_array = self._filter_null

        if config.get("verify", "ignore") == "exception":
            self.parse = self._parse_pedantic
        else:
            self.parse = self._parse_permissive




    def _parse_pedantic(self, value, config=None, pos=None):
        if value.strip() == "":
            return self.null, True
        f = float(value)
        return f, self.is_null(f)

    def _parse_permissive(self, value, config=None, pos=None):
        try:
            f = float(value)
            return f, self.is_null(f)
        except ValueError:
            # IRSA VOTables use the word 'null' to specify empty values,
            # but this is not defined in the VOTable spec.
            if value.strip() != "":
                vo_warn(W30, value, config, pos)
            return self.null, True

    @property
    def output_format(self):
        return self._output_format

    def output(self, value, mask):
        if mask:
            return self._null_output
        if np.isfinite(value):
            if not np.isscalar(value):
                value = value.dtype.type(value)
            result = self._output_format.format(value)
            if result.startswith("array"):
                raise RuntimeError()
            if self._output_format[2] == "s" and result.endswith(".0"):
                result = result[:-2]
            return result
        elif np.isnan(value):
            return "NaN"
        elif np.isposinf(value):
            return "+InF"
        elif np.isneginf(value):
            return "-InF"
        # Should never raise
        vo_raise(f"Invalid floating point value '{value}'")

    def binoutput(self, value, mask):
        if mask:
            return self._null_binoutput

        value = _ensure_bigendian(value)
        return value.tobytes()

    def _filter_nan(self, value, mask):
        return np.where(mask, np.nan, value)

    def _filter_null(self, value, mask):
        return np.where(mask, self.null, value)


class Double(FloatingPoint):
    """
    Handles the double datatype.  Double-precision IEEE
    floating-point.
    """

    format = "f8"


class Float(FloatingPoint):
    """
    Handles the float datatype.  Single-precision IEEE floating-point.
    """

    format = "f4"


class Integer(Numeric):
    """
    The base class for all the integral datatypes.
    """

    default = 0

# Licensed under a 3-clause BSD style license - see LICENSE.rst
# TODO: Test FITS parsing

# STDLIB
import base64
import codecs
import gzip
import io
import json
import os
import re
import urllib.request

# THIRD-PARTY
import numpy as np
from numpy import ma

# LOCAL
from astropy import __version__ as astropy_version
from astropy.io import fits
from astropy.utils import deprecated
from astropy.utils.collections import HomogeneousList
from astropy.utils.data import get_pkg_data_filename
from astropy.utils.xml import iterparser
from astropy.utils.xml.writer import XMLWriter

from . import converters, util, xmlutil
from . import ucd as ucd_mod
from .exceptions import (
    E06,
    E08,
    E09,
    E10,
    E11,
    E12,
    E13,
    E15,
    E16,
    E17,
    E18,
    E19,
    E20,
    E21,
    E22,
    E23,
    E25,
    E26,
    W06,
    W07,
    W08,
    W09,
    W10,
    W11,
    W12,
    W13,
    W15,
    W17,
    W18,
    W19,
    W20,
    W21,
    W22,
    W26,
    W27,
    W28,
    W29,
    W32,
    W33,
    W35,
    W36,
    W37,
    W38,
    W40,
    W41,
    W42,
    W43,
    W44,
    W45,
    W50,
    W52,
    W53,
    W54,
    W56,
    W57,
    vo_raise,
    vo_reraise,
    vo_warn,
    warn_or_raise,
    warn_unknown_attrs,
)

try:
    from . import tablewriter

    _has_c_tabledata_writer = True
except ImportError:
    _has_c_tabledata_writer = False


__all__ = [
    "CooSys",
    "Element",
    "Field",
    "FieldRef",
    "Group",
    "Info",
    "Link",
    "MivotBlock",
    "Param",
    "ParamRef",
    "Resource",
    "TableElement",
    "TimeSys",
    "VOTableFile",
    "Values",
]


# The default number of rows to read in each chunk before converting
# to an array.
DEFAULT_CHUNK_SIZE = 256
RESIZE_AMOUNT = 1.5

######################################################################
# FACTORY FUNCTIONS


def _resize(masked, new_size):
    """
    Masked arrays can not be resized inplace, and `np.resize` and
    `ma.resize` are both incompatible with structured arrays.
    Therefore, we do all this.
    """
    new_array = ma.zeros((new_size,), dtype=masked.dtype)
    length = min(len(masked), new_size)
    new_array[:length] = masked[:length]

    return new_array


def _lookup_by_attr_factory(attr, unique, iterator, element_name, doc):
    """
    Creates a function useful for looking up an element by a given
    attribute.

    Parameters
    ----------
    attr : str
        The attribute name

    unique : bool
        Should be `True` if the attribute is unique and therefore this
        should return only one value.  Otherwise, returns a list of
        values.

    iterator : generator
        A generator that iterates over some arbitrary set of elements

    element_name : str
        The XML element name of the elements being iterated over (used
        for error messages only).

    doc : str
        A docstring to apply to the generated function.

    Returns
    -------
    factory : function
        A function that looks up an element by the given attribute.
    """

    def lookup_by_attr(self, ref, before=None):
        """
        Given a string *ref*, finds the first element in the iterator
        where the given attribute == *ref*.  If *before* is provided,
        will stop searching at the object *before*.  This is
        important, since "forward references" are not allowed in the
        VOTABLE format.
        """
        for element in getattr(self, iterator)():
        #     self.max_inclusive = other.max_inclusive
        #     self._options[:] = other.options
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def unit(self):
        """A string specifying the units_ for the INFO_."""
        return self._unit

    @unit.setter
    def unit(self, unit):
        if unit is None:
            self._unit = None
            return

        from astropy import units as u

        if not self._config.get("version_1_2_or_later"):
            warn_or_raise(W28, W28, ("unit", "INFO", "1.2"), self._config, self._pos)

        # First, parse the unit in the default way, so that we can
        # still emit a warning if the unit is not to spec.
        default_format = _get_default_unit_format(self._config)
        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
        if isinstance(unit_obj, u.UnrecognizedUnit):
            warn_or_raise(W50, W50, (unit,), self._config, self._pos)

        format = _get_unit_format(self._config)
        if format != default_format:
            unit_obj = u.Unit(unit, format=format, parse_strict="silent")

        self._unit = unit_obj

    @unit.deleter
    def unit(self):
        self._unit = None

    def to_xml(self, w, **kwargs):
        attrib = w.object_attrs(self, self._attr_list)
        if "unit" in attrib:
            attrib["unit"] = self.unit.to_string("cds")
        w.element(self._element_name, self._content, attrib=attrib)


class Values(Element, _IDProperty):
    """
    VALUES_ element: used within FIELD_ and PARAM_ elements to define the domain of values.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    def __init__(
        self,
        votable,
        field,
        ID=None,
        null=None,
        ref=None,
        type="legal",
        id=None,
        config=None,
        pos=None,
        **extras,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        Element.__init__(self)

        self._votable = votable
        self._field = field
        self.ID = resolve_id(ID, id, config, pos)
        self.null = null
        self._ref = ref
        self.type = type

        self.min = None
        self.max = None
        self.min_inclusive = True
        self.max_inclusive = True
        self._options = []

        warn_unknown_attrs("VALUES", extras.keys(), config, pos)

    def __repr__(self):
        buff = io.StringIO()
        self.to_xml(XMLWriter(buff))
        return buff.getvalue().strip()

    @property
    def null(self):
        """
        For integral datatypes, *null* is used to define the value
        used for missing values.
        """
        return self._null

    @null.setter
    def null(self, null):
        if null is not None and isinstance(null, str):
            try:
                null_val = self._field.converter.parse_scalar(
                    null, self._config, self._pos
                )[0]
            except Exception:
                warn_or_raise(W36, W36, null, self._config, self._pos)
                null_val = self._field.converter.parse_scalar(
                    "0", self._config, self._pos
                )[0]
        else:
            null_val = null
        self._null = null_val

    @null.deleter
    def null(self):
        self._null = None

    @property
    def type(self):
        """Defines the applicability of the domain defined by this VALUES_ element [*required*].

        Must be one of the following strings:

          - 'legal': The domain of this column applies in general to
            this datatype. (default)

          - 'actual': The domain of this column applies only to the
            data enclosed in the parent table.
        """
        return self._type

    @type.setter
    def type(self, type):
        if type not in ("legal", "actual"):
            vo_raise(E08, type, self._config, self._pos)
        self._type = type

    @property
    def ref(self):
        """
        Refer to another VALUES_ element by ID_, defined previously in
        the document, for MIN/MAX/OPTION information.
        """
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        if ref is not None:
            try:
                other = self._votable.get_values_by_id(ref, before=self)
            except KeyError:
                warn_or_raise(W43, W43, ("VALUES", self.ref), self._config, self._pos)
                ref = None
            else:
                self.null = other.null
                self.type = other.type
                self.min = other.min
                self.min_inclusive = other.min_inclusive
                self.max = other.max
                self.max_inclusive = other.max_inclusive
                self._options[:] = other.options
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def min(self):
        """
        The minimum value of the domain.  See :attr:`min_inclusive`.
        """
        return self._min

    @min.setter
    def min(self, min):
        self._min = self._parse_minmax(min)

    @min.deleter
    def min(self):
        self._min = None

    @property
    def min_inclusive(self):
        """When `True`, the domain includes the minimum value."""
        return self._min_inclusive

    @min_inclusive.setter
    def min_inclusive(self, inclusive):
        if inclusive == "yes":
            self._min_inclusive = True
        elif inclusive == "no":
            self._min_inclusive = False
            self._unit = None
            return

        from astropy import units as u

        # First, parse the unit in the default way, so that we can
        # still emit a warning if the unit is not to spec.
        default_format = _get_default_unit_format(self._config)
        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
        if isinstance(unit_obj, u.UnrecognizedUnit):
            warn_or_raise(W50, W50, (unit,), self._config, self._pos)

        format = _get_unit_format(self._config)
        if format != default_format:
            unit_obj = u.Unit(unit, format=format, parse_strict="silent")

        self._unit = unit_obj

    @unit.deleter
    def unit(self):
        self._unit = None

    @property
    def arraysize(self):
        """
        Specifies the size of the multidimensional array if this
        FIELD_ contains more than a single value.

        See `multidimensional arrays`_.
        """
        return self._arraysize

    @arraysize.setter
    def arraysize(self, arraysize):
        if arraysize is not None and not re.match(
            r"^([0-9]+x)*[0-9]*[*]?(s\W)?$", arraysize
        ):
            vo_raise(E13, arraysize, self._config, self._pos)
        self._arraysize = arraysize

    @arraysize.deleter
    def arraysize(self):
        self._arraysize = None

    @property
    def type(self):
        """
        The type attribute on FIELD_ elements is reserved for future
        extensions.
        """
        return self._type

    @type.setter
    def type(self, type):
        self._type = type

    @type.deleter
    def type(self):
        self._type = None

    @property
    def values(self):
        """
        A :class:`Values` instance (or `None`) defining the domain
        of the column.
        """
        return self._values

    @values.setter
    def values(self, values):
        assert values is None or isinstance(values, Values)
        self._values = values

    @values.deleter
    def values(self):
        self._values = None

    @property
    def links(self):
        """
        A list of :class:`Link` instances used to reference more
        details about the meaning of the FIELD_.  This is purely
        informational and is not used by the `astropy.io.votable`
        package.
        """
        return self._links

    def parse(self, iterator, config):
        for start, tag, data, pos in iterator:
            if start:
                if tag == "VALUES":
                    self.values.__init__(
                        self._votable, self, config=config, pos=pos, **data
                    )
                    self.values.parse(iterator, config)
                elif tag == "LINK":
                    link = Link(config=config, pos=pos, **data)
                    self.links.append(link)
                    link.parse(iterator, config)
                elif tag == "DESCRIPTION":
                    warn_unknown_attrs("DESCRIPTION", data.keys(), config, pos)
                elif tag != self._element_name:
                    self._add_unknown_tag(iterator, tag, data, config, pos)
            else:
                if tag == "DESCRIPTION":
                    if self.description is not None:
                        warn_or_raise(W17, W17, self._element_name, config, pos)
                    self.description = data or None
                elif tag == self._element_name:
                    break

        if self.description is not None:
            self.title = " ".join(x.strip() for x in self.description.splitlines())
        else:
            self.title = self.name

        self._setup(config, pos)

        return self

    def to_xml(self, w, **kwargs):
        attrib = w.object_attrs(self, self._attr_list)
        if "unit" in attrib:
            format = _get_unit_format(self._config)
            try:
                attrib["unit"] = self.unit.to_string(format)
            except ValueError as e:
                # Allow non-standard units with a warning, see
                # https://github.com/astropy/astropy/issues/17497#issuecomment-2520472495
                attrib["unit"] = self.unit.to_string()
                warn_or_raise(W50, W50, (attrib["unit"],), self._config, self._pos)
```

## 原始行 20 · command_execution

命令：
```
/bin/bash -lc "sed -n '80,170p' astropy/io/votable/tree.py && sed -n '948,1220p' astropy/io/votable/tree.py && sed -n '2420,2840p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
    W52,
    W53,
    W54,
    W56,
    W57,
    vo_raise,
    vo_reraise,
    vo_warn,
    warn_or_raise,
    warn_unknown_attrs,
)

try:
    from . import tablewriter

    _has_c_tabledata_writer = True
except ImportError:
    _has_c_tabledata_writer = False


__all__ = [
    "CooSys",
    "Element",
    "Field",
    "FieldRef",
    "Group",
    "Info",
    "Link",
    "MivotBlock",
    "Param",
    "ParamRef",
    "Resource",
    "TableElement",
    "TimeSys",
    "VOTableFile",
    "Values",
]


# The default number of rows to read in each chunk before converting
# to an array.
DEFAULT_CHUNK_SIZE = 256
RESIZE_AMOUNT = 1.5

######################################################################
# FACTORY FUNCTIONS


def _resize(masked, new_size):
    """
    Masked arrays can not be resized inplace, and `np.resize` and
    `ma.resize` are both incompatible with structured arrays.
    Therefore, we do all this.
    """
    new_array = ma.zeros((new_size,), dtype=masked.dtype)
    length = min(len(masked), new_size)
    new_array[:length] = masked[:length]

    return new_array


def _lookup_by_attr_factory(attr, unique, iterator, element_name, doc):
    """
    Creates a function useful for looking up an element by a given
    attribute.

    Parameters
    ----------
    attr : str
        The attribute name

    unique : bool
        Should be `True` if the attribute is unique and therefore this
        should return only one value.  Otherwise, returns a list of
        values.

    iterator : generator
        A generator that iterates over some arbitrary set of elements

    element_name : str
        The XML element name of the elements being iterated over (used
        for error messages only).

    doc : str
        A docstring to apply to the generated function.

    Returns
    -------
    factory : function
        A function that looks up an element by the given attribute.
    """
class Values(Element, _IDProperty):
    """
    VALUES_ element: used within FIELD_ and PARAM_ elements to define the domain of values.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    def __init__(
        self,
        votable,
        field,
        ID=None,
        null=None,
        ref=None,
        type="legal",
        id=None,
        config=None,
        pos=None,
        **extras,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        Element.__init__(self)

        self._votable = votable
        self._field = field
        self.ID = resolve_id(ID, id, config, pos)
        self.null = null
        self._ref = ref
        self.type = type

        self.min = None
        self.max = None
        self.min_inclusive = True
        self.max_inclusive = True
        self._options = []

        warn_unknown_attrs("VALUES", extras.keys(), config, pos)

    def __repr__(self):
        buff = io.StringIO()
        self.to_xml(XMLWriter(buff))
        return buff.getvalue().strip()

    @property
    def null(self):
        """
        For integral datatypes, *null* is used to define the value
        used for missing values.
        """
        return self._null

    @null.setter
    def null(self, null):
        if null is not None and isinstance(null, str):
            try:
                null_val = self._field.converter.parse_scalar(
                    null, self._config, self._pos
                )[0]
            except Exception:
                warn_or_raise(W36, W36, null, self._config, self._pos)
                null_val = self._field.converter.parse_scalar(
                    "0", self._config, self._pos
                )[0]
        else:
            null_val = null
        self._null = null_val

    @null.deleter
    def null(self):
        self._null = None

    @property
    def type(self):
        """Defines the applicability of the domain defined by this VALUES_ element [*required*].

        Must be one of the following strings:

          - 'legal': The domain of this column applies in general to
            this datatype. (default)

          - 'actual': The domain of this column applies only to the
            data enclosed in the parent table.
        """
        return self._type

    @type.setter
    def type(self, type):
        if type not in ("legal", "actual"):
            vo_raise(E08, type, self._config, self._pos)
        self._type = type

    @property
    def ref(self):
        """
        Refer to another VALUES_ element by ID_, defined previously in
        the document, for MIN/MAX/OPTION information.
        """
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        if ref is not None:
            try:
                other = self._votable.get_values_by_id(ref, before=self)
            except KeyError:
                warn_or_raise(W43, W43, ("VALUES", self.ref), self._config, self._pos)
                ref = None
            else:
                self.null = other.null
                self.type = other.type
                self.min = other.min
                self.min_inclusive = other.min_inclusive
                self.max = other.max
                self.max_inclusive = other.max_inclusive
                self._options[:] = other.options
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def min(self):
        """
        The minimum value of the domain.  See :attr:`min_inclusive`.
        """
        return self._min

    @min.setter
    def min(self, min):
        self._min = self._parse_minmax(min)

    @min.deleter
    def min(self):
        self._min = None

    @property
    def min_inclusive(self):
        """When `True`, the domain includes the minimum value."""
        return self._min_inclusive

    @min_inclusive.setter
    def min_inclusive(self, inclusive):
        if inclusive == "yes":
            self._min_inclusive = True
        elif inclusive == "no":
            self._min_inclusive = False
        else:
            self._min_inclusive = bool(inclusive)

    @min_inclusive.deleter
    def min_inclusive(self):
        self._min_inclusive = True

    @property
    def max(self):
        """
        The maximum value of the domain.  See :attr:`max_inclusive`.
        """
        return self._max

    @max.setter
    def max(self, max):
        self._max = self._parse_minmax(max)

    @max.deleter
    def max(self):
        self._max = None

    @property
    def max_inclusive(self):
        """When `True`, the domain includes the maximum value."""
        return self._max_inclusive

    @max_inclusive.setter
    def max_inclusive(self, inclusive):
        if inclusive == "yes":
            self._max_inclusive = True
        elif inclusive == "no":
            self._max_inclusive = False
        else:
            self._max_inclusive = bool(inclusive)

    @max_inclusive.deleter
    def max_inclusive(self):
        self._max_inclusive = True

    @property
    def options(self):
        """
        A list of string key-value tuples defining other OPTION
        elements for the domain.  All options are ignored -- they are
        stored for round-tripping purposes only.
        """
        return self._options

    def parse(self, iterator, config):
        if self.ref is not None:
            for start, tag, data, pos in iterator:
                if start:
                    warn_or_raise(W44, W44, tag, config, pos)
                else:
                    if tag != "VALUES":
                        warn_or_raise(W44, W44, tag, config, pos)
                    break
        else:
            for start, tag, data, pos in iterator:
                if start:
                    if tag == "MIN":
                        if "value" not in data:
                            vo_raise(E09, "MIN", config, pos)
                        self.min = data["value"]
                        self.min_inclusive = data.get("inclusive", "yes")
                        warn_unknown_attrs(
                            "MIN", data.keys(), config, pos, ["value", "inclusive"]
                        )
                    elif tag == "MAX":
                        if "value" not in data:
                            vo_raise(E09, "MAX", config, pos)
                        self.max = data["value"]
                        self.max_inclusive = data.get("inclusive", "yes")
                        warn_unknown_attrs(
                            "MAX", data.keys(), config, pos, ["value", "inclusive"]
                        )
                    elif tag == "OPTION":
                        if "value" not in data:
                            vo_raise(E09, "OPTION", config, pos)
                        xmlutil.check_token(data.get("name"), "name", config, pos)
                        self.options.append((data.get("name"), data.get("value")))
                        warn_unknown_attrs(
                            "OPTION", data.keys(), config, pos, ["value", "name"]
                        )
                elif tag == "VALUES":
                    break

        return self































        group = Group(self._table, config=config, pos=pos, **data)
        self.entries.append(group)
        group.parse(iterator, config)

    def parse(self, iterator, config):
        tag_mapping = {
            "FIELDref": self._add_fieldref,
            "PARAMref": self._add_paramref,
            "PARAM": self._add_param,
            "GROUP": self._add_group,
            "DESCRIPTION": self._ignore_add,
        }

        for start, tag, data, pos in iterator:
            if start:
                tag_mapping.get(tag, self._add_unknown_tag)(
                    iterator, tag, data, config, pos
                )
            else:
                if tag == "DESCRIPTION":
                    if self.description is not None:
                        warn_or_raise(W17, W17, "GROUP", config, pos)
                    self.description = data or None
                elif tag == "GROUP":
                    break
        return self

    def to_xml(self, w, **kwargs):
        with w.tag(
            "GROUP", attrib=w.object_attrs(self, ["ID", "name", "ref", "ucd", "utype"])
        ):
            if self.description is not None:
                w.element("DESCRIPTION", self.description, wrap=True)
            for entry in self.entries:
                entry.to_xml(w, **kwargs)

    def iter_fields_and_params(self):
        """
        Recursively iterate over all :class:`Param` elements in this
        :class:`Group`.
        """
        for entry in self.entries:
            if isinstance(entry, Param):
                yield entry
            elif isinstance(entry, Group):
                yield from entry.iter_fields_and_params()

    def iter_groups(self):
        """
        Recursively iterate over all sub-:class:`Group` instances in
        this :class:`Group`.
        """
        for entry in self.entries:
            if isinstance(entry, Group):
                yield entry
                yield from entry.iter_groups()


class TableElement(
    Element, _IDProperty, _NameProperty, _UcdProperty, _DescriptionProperty
):
    """
    TABLE_ element: optionally contains data.

    It contains the following publicly-accessible and mutable
    attribute:

        *array*: A Numpy masked array of the data itself, where each
        row is a row of votable data, and columns are named and typed
        based on the <FIELD> elements of the table.  The mask is
        parallel to the data array, except for variable-length fields.
        For those fields, the numpy array's column type is "object"
        (``"O"``), and another masked array is stored there.

    If the TableElement contains no data, (for example, its enclosing
    :class:`Resource` has :attr:`~Resource.type` == 'meta') *array*
    will have zero-length.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    def __init__(
        self,
        votable,
        ID=None,
        name=None,
        ref=None,
        ucd=None,
        utype=None,
        nrows=None,
        id=None,
        config=None,
        pos=None,
        **extra,
    ):
        self._config = _attach_default_config(votable, config)
        self._pos = pos
        self._empty = False

        Element.__init__(self)
        self._votable = votable

        self.ID = resolve_id(ID, id, self._config, pos) or xmlutil.fix_id(
            name, self._config, pos
        )
        self.name = name
        xmlutil.check_id(ref, "ref", self._config, pos)
        self._ref = ref
        self.ucd = ucd
        self.utype = utype
        if nrows is not None:
            nrows = int(nrows)
            if nrows < 0:
                raise ValueError("'nrows' cannot be negative.")
        self._nrows = nrows
        self.description = None
        self.format = "tabledata"

        self._fields = HomogeneousList(Field)
        self._all_fields = HomogeneousList(Field)
        self._params = HomogeneousList(Param)
        self._groups = HomogeneousList(Group)
        self._links = HomogeneousList(Link)
        self._infos = HomogeneousList(Info)

        self.array = ma.array([])

        warn_unknown_attrs("TABLE", extra.keys(), self._config, pos)

    def __repr__(self):
        s = repr(self.to_table())
        if s.startswith("<Table"):
            s = "<VO" + s[1:]
        return s

    def __bytes__(self):
        return bytes(self.to_table())

    def __str__(self):
        return str(self.to_table())

    @property
    def ref(self):
        return self._ref

    @ref.setter
    def ref(self, ref):
        """
        Refer to another TABLE, previously defined, by the *ref* ID_
        for all metadata (FIELD_, PARAM_ etc.) information.
        """
        # When the ref changes, we want to verify that it will work
        # by actually going and looking for the referenced table.
        # If found, set a bunch of properties in this table based
        # on the other one.
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        if ref is not None:
            try:
                table = self._votable.get_table_by_id(ref, before=self)
            except KeyError:
                warn_or_raise(W43, W43, ("TABLE", self.ref), self._config, self._pos)
                ref = None
            else:
                self._fields = table.fields
                self._all_fields = table.all_fields
                self._params = table.params
                self._groups = table.groups
                self._links = table.links
        else:
            del self._fields[:]
            del self._all_fields[:]
            del self._params[:]
            del self._groups[:]
            del self._links[:]
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def format(self):
        """The serialization format of the table [*required*].

        Must be one of:

          'tabledata' (TABLEDATA_), 'binary' (BINARY_), 'binary2' (BINARY2_)
          'fits' (FITS_).

        Note that the 'fits' format, since it requires an external
        file, can not be written out.  Any file read in with 'fits'
        format will be read out, by default, in 'tabledata' format.

        See :ref:`astropy:votable-serialization`.
        """
        return self._format

    @format.setter
    def format(self, format):
        format = format.lower()
        if format == "fits":
            vo_raise(
                NotImplementedError,
                "fits format can not be written out, only read.",
                self._config,
                self._pos,
            )
        if format == "binary2":
            if not self._config.get("version_1_3_or_later"):
                vo_raise(
                    W37,
                    "binary2 only supported in votable 1.3 or later",
                    self._config,
                    self._pos,
                )
        elif format not in ("tabledata", "binary"):
            vo_raise(W37, f"Invalid format '{format}'", self._config, self._pos)
        self._format = format

    @property
    def nrows(self):
        """
        [*immutable*] The number of rows in the table, as specified in
        the XML file.
        """
        return self._nrows

    @property
    def fields(self):
        """
        A list of :class:`Field` objects describing the types of each
        of the data columns.
        """
        return self._fields

    @property
    def all_fields(self):
        """
        A list of :class:`Field` objects describing the types of each
        of the data columns. Contrary to ``fields``, this property should
        list every field that's available on disk, including deselected columns.
        """
        # since we support extending self.fields directly via list.extend
        # and list.append, self._all_fields may go out of sync.
        # To remedy this issue, we sync back the public property upon access.
        for field in self._fields:
            if field not in self._all_fields:
                self._all_fields.append(field)

        return self._all_fields

    @property
    def params(self):
        """
        A list of parameters (constant-valued columns) for the
        table.  Must contain only :class:`Param` objects.
        """
        return self._params

    @property
    def groups(self):
        """
        A list of :class:`Group` objects describing how the columns
        and parameters are grouped.  Currently this information is
        only kept around for round-tripping and informational
        purposes.
        """
        return self._groups

    @property
    def links(self):
        """
        A list of :class:`Link` objects (pointers to other documents
        or servers through a URI) for the table.
        """
        return self._links

    @property
    def infos(self):
        """
        A list of :class:`Info` objects for the table.  Allows for
        post-operational diagnostics.
        """
        return self._infos









    def create_arrays(
        self,
        nrows=0,
        config=None,
        *,
        colnumbers=None,
    ):
        """
        Create a new array to hold the data based on the current set
        of fields, and store them in the *array* and member variable.
        Any data in the existing array will be lost.

        *nrows*, if provided, is the number of rows to allocate.
        *colnumbers*, if provided, is the list of column indices to select.
        By default, all columns are selected.
        """
        if nrows is None:
            nrows = 0
        if colnumbers is None:
            colnumbers = list(range(len(self.all_fields)))

        new_fields = HomogeneousList(
            Field,
            values=[f for i, f in enumerate(self.all_fields) if i in colnumbers],
        )
        if new_fields != self._fields:
            self._fields = new_fields

        fields = self.all_fields

        if len(fields) == 0:
            array = np.recarray((nrows,), dtype="O")
            mask = np.zeros((nrows,), dtype="b")
        else:
            # for field in fields: field._setup(config)
            Field.uniqify_names(fields)

            dtype = []
            for i, x in enumerate(fields):
                if i not in colnumbers:
                    continue
                if x._unique_name == x.ID:
                    id = x.ID
                else:
                    id = (x._unique_name, x.ID)
                dtype.append((id, x.converter.format))

            array = np.recarray((nrows,), dtype=np.dtype(dtype))
            descr_mask = []
            for d in array.dtype.descr:
                new_type = (d[1][1] == "O" and "O") or "bool"
                if len(d) == 2:
                    descr_mask.append((d[0], new_type))
                elif len(d) == 3:
                    descr_mask.append((d[0], new_type, d[2]))
            mask = np.zeros((nrows,), dtype=descr_mask)

        self.array = ma.array(array, mask=mask)

    def _resize_strategy(self, size):
        """
        Return a new (larger) size based on size, used for
        reallocating an array when it fills up.  This is in its own
        function so the resizing strategy can be easily replaced.
        """
        # Once we go beyond 0, make a big step -- after that use a
        # factor of 1.5 to help keep memory usage compact
        if size == 0:
            return 512
        return int(np.ceil(size * RESIZE_AMOUNT))

    def add_field(self, field: Field) -> None:
        self.fields.append(field)
        self.all_fields.append(field)

    def _register_field(self, iterator, tag, data, config, pos) -> None:
        field = Field(self._votable, config=config, pos=pos, **data)
        field.parse(iterator, config)
        self._all_fields.append(field)

    def _add_param(self, iterator, tag, data, config, pos):
        param = Param(self._votable, config=config, pos=pos, **data)
        self.params.append(param)
        param.parse(iterator, config)

    def _add_group(self, iterator, tag, data, config, pos):
        group = Group(self, config=config, pos=pos, **data)
        self.groups.append(group)
        group.parse(iterator, config)

    def _add_link(self, iterator, tag, data, config, pos):
        link = Link(config=config, pos=pos, **data)
        self.links.append(link)
        link.parse(iterator, config)

    def _add_info(self, iterator, tag, data, config, pos):
        if not config.get("version_1_2_or_later"):
            warn_or_raise(W26, W26, ("INFO", "TABLE", "1.2"), config, pos)
        info = Info(config=config, pos=pos, **data)
        self.infos.append(info)
        info.parse(iterator, config)

    def parse(self, iterator, config):
        columns = config.get("columns")

        # If we've requested to read in only a specific table, skip
        # all others
        table_number = config.get("table_number")
        current_table_number = config.get("_current_table_number")
        skip_table = False
        if current_table_number is not None:
            config["_current_table_number"] += 1
            if table_number is not None and table_number != current_table_number:
                skip_table = True
                self._empty = True

        table_id = config.get("table_id")
        if table_id is not None:
            if table_id != self.ID:
                skip_table = True
                self._empty = True

        if self.ref is not None:
            # This table doesn't have its own datatype descriptors, it
            # just references those from another table.

            # This is to call the property setter to go and get the
```

## 原始行 23 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '110,260p'; nl -ba astropy/io/votable/tree.py | sed -n '1120,1260p'; nl -ba astropy/io/votable/tree.py | sed -n '2680,2790p'; nl -ba astropy/io/votable/tree.py | sed -n '3650,3970p'"
```

退出码：`0`

输出：
```
   110	    "ParamRef",
   111	    "Resource",
   112	    "TableElement",
   113	    "TimeSys",
   114	    "VOTableFile",
   115	    "Values",
   116	]
   117	
   118	
   119	# The default number of rows to read in each chunk before converting
   120	# to an array.
   121	DEFAULT_CHUNK_SIZE = 256
   122	RESIZE_AMOUNT = 1.5
   123	
   124	######################################################################
   125	# FACTORY FUNCTIONS
   126	
   127	
   128	def _resize(masked, new_size):
   129	    """
   130	    Masked arrays can not be resized inplace, and `np.resize` and
   131	    `ma.resize` are both incompatible with structured arrays.
   132	    Therefore, we do all this.
   133	    """
   134	    new_array = ma.zeros((new_size,), dtype=masked.dtype)
   135	    length = min(len(masked), new_size)
   136	    new_array[:length] = masked[:length]
   137	
   138	    return new_array
   139	
   140	
   141	def _lookup_by_attr_factory(attr, unique, iterator, element_name, doc):
   142	    """
   143	    Creates a function useful for looking up an element by a given
   144	    attribute.
   145	
   146	    Parameters
   147	    ----------
   148	    attr : str
   149	        The attribute name
   150	
   151	    unique : bool
   152	        Should be `True` if the attribute is unique and therefore this
   153	        should return only one value.  Otherwise, returns a list of
   154	        values.
   155	
   156	    iterator : generator
   157	        A generator that iterates over some arbitrary set of elements
   158	
   159	    element_name : str
   160	        The XML element name of the elements being iterated over (used
   161	        for error messages only).
   162	
   163	    doc : str
   164	        A docstring to apply to the generated function.
   165	
   166	    Returns
   167	    -------
   168	    factory : function
   169	        A function that looks up an element by the given attribute.
   170	    """
   171	
   172	    def lookup_by_attr(self, ref, before=None):
   173	        """
   174	        Given a string *ref*, finds the first element in the iterator
   175	        where the given attribute == *ref*.  If *before* is provided,
   176	        will stop searching at the object *before*.  This is
   177	        important, since "forward references" are not allowed in the
   178	        VOTABLE format.
   179	        """
   180	        for element in getattr(self, iterator)():
   181	            if element is before:
   182	                if getattr(element, attr, None) == ref:
   183	                    vo_raise(
   184	                        KeyError,
   185	                        f"{element_name} references itself",
   186	                        element._config,
   187	                        element._pos,
   188	                    )
   189	                break
   190	            if getattr(element, attr, None) == ref:
   191	                yield element
   192	
   193	    def lookup_by_attr_unique(self, ref, before=None):
   194	        for element in lookup_by_attr(self, ref, before=before):
   195	            return element
   196	        raise KeyError(
   197	            f"No {element_name} with {attr} '{ref}' found before the referencing "
   198	            f"{element_name}"
   199	        )
   200	
   201	    if unique:
   202	        lookup_by_attr_unique.__doc__ = doc
   203	        return lookup_by_attr_unique
   204	    else:
   205	        lookup_by_attr.__doc__ = doc
   206	        return lookup_by_attr
   207	
   208	
   209	def _lookup_by_id_or_name_factory(iterator, element_name, doc):
   210	    """
   211	    Like `_lookup_by_attr_factory`, but looks in both the "ID" and
   212	    "name" attributes.
   213	    """
   214	
   215	    def lookup_by_id_or_name(self, ref, before=None):
   216	        """
   217	        Given an key *ref*, finds the first element in the iterator
   218	        with the attribute ID == *ref* or name == *ref*.  If *before*
   219	        is provided, will stop searching at the object *before*.  This
   220	        is important, since "forward references" are not allowed in
   221	        the VOTABLE format.
   222	        """
   223	        for element in getattr(self, iterator)():
   224	            if element is before:
   225	                if ref in (element.ID, element.name):
   226	                    vo_raise(
   227	                        KeyError,
   228	                        f"{element_name} references itself",
   229	                        element._config,
   230	                        element._pos,
   231	                    )
   232	                break
   233	            if ref in (element.ID, element.name):
   234	                return element
   235	        raise KeyError(
   236	            f"No {element_name} with ID or name '{ref}' found before the referencing "
   237	            f"{element_name}"
   238	        )
   239	
   240	    lookup_by_id_or_name.__doc__ = doc
   241	    return lookup_by_id_or_name
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
  1120	    def max(self):
  1121	        self._max = None
  1122	
  1123	    @property
  1124	    def max_inclusive(self):
  1125	        """When `True`, the domain includes the maximum value."""
  1126	        return self._max_inclusive
  1127	
  1128	    @max_inclusive.setter
  1129	    def max_inclusive(self, inclusive):
  1130	        if inclusive == "yes":
  1131	            self._max_inclusive = True
  1132	        elif inclusive == "no":
  1133	            self._max_inclusive = False
  1134	        else:
  1135	            self._max_inclusive = bool(inclusive)
  1136	
  1137	    @max_inclusive.deleter
  1138	    def max_inclusive(self):
  1139	        self._max_inclusive = True
  1140	
  1141	    @property
  1142	    def options(self):
  1143	        """
  1144	        A list of string key-value tuples defining other OPTION
  1145	        elements for the domain.  All options are ignored -- they are
  1146	        stored for round-tripping purposes only.
  1147	        """
  1148	        return self._options
  1149	
  1150	    def parse(self, iterator, config):
  1151	        if self.ref is not None:
  1152	            for start, tag, data, pos in iterator:
  1153	                if start:
  1154	                    warn_or_raise(W44, W44, tag, config, pos)
  1155	                else:
  1156	                    if tag != "VALUES":
  1157	                        warn_or_raise(W44, W44, tag, config, pos)
  1158	                    break
  1159	        else:
  1160	            for start, tag, data, pos in iterator:
  1161	                if start:
  1162	                    if tag == "MIN":
  1163	                        if "value" not in data:
  1164	                            vo_raise(E09, "MIN", config, pos)
  1165	                        self.min = data["value"]
  1166	                        self.min_inclusive = data.get("inclusive", "yes")
  1167	                        warn_unknown_attrs(
  1168	                            "MIN", data.keys(), config, pos, ["value", "inclusive"]
  1169	                        )
  1170	                    elif tag == "MAX":
  1171	                        if "value" not in data:
  1172	                            vo_raise(E09, "MAX", config, pos)
  1173	                        self.max = data["value"]
  1174	                        self.max_inclusive = data.get("inclusive", "yes")
  1175	                        warn_unknown_attrs(
  1176	                            "MAX", data.keys(), config, pos, ["value", "inclusive"]
  1177	                        )
  1178	                    elif tag == "OPTION":
  1179	                        if "value" not in data:
  1180	                            vo_raise(E09, "OPTION", config, pos)
  1181	                        xmlutil.check_token(data.get("name"), "name", config, pos)
  1182	                        self.options.append((data.get("name"), data.get("value")))
  1183	                        warn_unknown_attrs(
  1184	                            "OPTION", data.keys(), config, pos, ["value", "name"]
  1185	                        )
  1186	                elif tag == "VALUES":
  1187	                    break
  1188	
  1189	        return self
  1190	
  1191	
  1192	
  1193	
  1194	
  1195	
  1196	
  1197	
  1198	
  1199	
  1200	
  1201	
  1202	
  1203	
  1204	
  1205	
  1206	
  1207	
  1208	
  1209	
  1210	
  1211	
  1212	
  1213	
  1214	
  1215	
  1216	
  1217	
  1218	
  1219	
  1220	
  1221	
  1222	
  1223	
  1224	
  1225	
  1226	
  1227	
  1228	
  1229	
  1230	
  1231	
  1232	
  1233	
  1234	
  1235	
  1236	    def to_xml(self, w, **kwargs):
  1237	        def yes_no(value):
  1238	            if value:
  1239	                return "yes"
  1240	            return "no"
  1241	
  1242	        if self.is_defaults():
  1243	            return
  1244	
  1245	        if self.ref is not None:
  1246	            w.element("VALUES", attrib=w.object_attrs(self, ["ref"]))
  1247	        else:
  1248	            with w.tag("VALUES", attrib=w.object_attrs(self, ["ID", "null", "ref"])):
  1249	                if self.min is not None:
  1250	                    w.element(
  1251	                        "MIN",
  1252	                        value=self._field.converter.output(self.min, False),
  1253	                        inclusive=yes_no(self.min_inclusive),
  1254	                    )
  1255	                if self.max is not None:
  1256	                    w.element(
  1257	                        "MAX",
  1258	                        value=self._field.converter.output(self.max, False),
  1259	                        inclusive=yes_no(self.max_inclusive),
  1260	                    )
  2680	    @property
  2681	    def groups(self):
  2682	        """
  2683	        A list of :class:`Group` objects describing how the columns
  2684	        and parameters are grouped.  Currently this information is
  2685	        only kept around for round-tripping and informational
  2686	        purposes.
  2687	        """
  2688	        return self._groups
  2689	
  2690	    @property
  2691	    def links(self):
  2692	        """
  2693	        A list of :class:`Link` objects (pointers to other documents
  2694	        or servers through a URI) for the table.
  2695	        """
  2696	        return self._links
  2697	
  2698	    @property
  2699	    def infos(self):
  2700	        """
  2701	        A list of :class:`Info` objects for the table.  Allows for
  2702	        post-operational diagnostics.
  2703	        """
  2704	        return self._infos
  2705	
  2706	
  2707	
  2708	
  2709	
  2710	
  2711	
  2712	
  2713	
  2714	    def create_arrays(
  2715	        self,
  2716	        nrows=0,
  2717	        config=None,
  2718	        *,
  2719	        colnumbers=None,
  2720	    ):
  2721	        """
  2722	        Create a new array to hold the data based on the current set
  2723	        of fields, and store them in the *array* and member variable.
  2724	        Any data in the existing array will be lost.
  2725	
  2726	        *nrows*, if provided, is the number of rows to allocate.
  2727	        *colnumbers*, if provided, is the list of column indices to select.
  2728	        By default, all columns are selected.
  2729	        """
  2730	        if nrows is None:
  2731	            nrows = 0
  2732	        if colnumbers is None:
  2733	            colnumbers = list(range(len(self.all_fields)))
  2734	
  2735	        new_fields = HomogeneousList(
  2736	            Field,
  2737	            values=[f for i, f in enumerate(self.all_fields) if i in colnumbers],
  2738	        )
  2739	        if new_fields != self._fields:
  2740	            self._fields = new_fields
  2741	
  2742	        fields = self.all_fields
  2743	
  2744	        if len(fields) == 0:
  2745	            array = np.recarray((nrows,), dtype="O")
  2746	            mask = np.zeros((nrows,), dtype="b")
  2747	        else:
  2748	            # for field in fields: field._setup(config)
  2749	            Field.uniqify_names(fields)
  2750	
  2751	            dtype = []
  2752	            for i, x in enumerate(fields):
  2753	                if i not in colnumbers:
  2754	                    continue
  2755	                if x._unique_name == x.ID:
  2756	                    id = x.ID
  2757	                else:
  2758	                    id = (x._unique_name, x.ID)
  2759	                dtype.append((id, x.converter.format))
  2760	
  2761	            array = np.recarray((nrows,), dtype=np.dtype(dtype))
  2762	            descr_mask = []
  2763	            for d in array.dtype.descr:
  2764	                new_type = (d[1][1] == "O" and "O") or "bool"
  2765	                if len(d) == 2:
  2766	                    descr_mask.append((d[0], new_type))
  2767	                elif len(d) == 3:
  2768	                    descr_mask.append((d[0], new_type, d[2]))
  2769	            mask = np.zeros((nrows,), dtype=descr_mask)
  2770	
  2771	        self.array = ma.array(array, mask=mask)
  2772	
  2773	    def _resize_strategy(self, size):
  2774	        """
  2775	        Return a new (larger) size based on size, used for
  2776	        reallocating an array when it fills up.  This is in its own
  2777	        function so the resizing strategy can be easily replaced.
  2778	        """
  2779	        # Once we go beyond 0, make a big step -- after that use a
  2780	        # factor of 1.5 to help keep memory usage compact
  2781	        if size == 0:
  2782	            return 512
  2783	        return int(np.ceil(size * RESIZE_AMOUNT))
  2784	
  2785	    def add_field(self, field: Field) -> None:
  2786	        self.fields.append(field)
  2787	        self.all_fields.append(field)
  2788	
  2789	    def _register_field(self, iterator, tag, data, config, pos) -> None:
  2790	        field = Field(self._votable, config=config, pos=pos, **data)
  3650	    extraction or the writing of a mapping block from/to a VOTable
  3651	    There is no syntax validation other than the allowed tag names.
  3652	    The mapping block is handled as a correctly indented XML string
  3653	    which is meant to be parsed by the calling API (e.g., PyVO).
  3654	
  3655	    The constructor takes "content" as a parameter, it is the string
  3656	    serialization of the MIVOT block.
  3657	    If it is None, the instance is meant to be set by the Resource parser.
  3658	    Orherwise, the parameter value is parsed to make sure it matches
  3659	    the MIVOT XML structure.
  3660	
  3661	    """
  3662	
  3663	    def __init__(self, content=None):
  3664	        if content is not None:
  3665	            self._content = content.strip()
  3666	            self.check_content_format()
  3667	        else:
  3668	            self._content = ""
  3669	        self._indent_level = 0
  3670	        self._on_error = False
  3671	
  3672	    def __str__(self):
  3673	        return self._content
  3674	
  3675	    def _add_statement(self, start, tag, data, config, pos):
  3676	        """
  3677	        Convert the tag as a string and append it to the mapping
  3678	        block string with the correct indentation level.
  3679	        The signature is the same as for all _add_* methods of the parser.
  3680	        """
  3681	        if self._on_error is True:
  3682	            return
  3683	        # The first mapping tag (<VODML>) is consumed by the host RESOURCE
  3684	        # To check that the content is a mapping block. This cannot be done here
  3685	        # because that RESOURCE might have another content
  3686	        if self._content == "":
  3687	            self._content = '<VODML xmlns="http://www.ivoa.net/xml/mivot">\n'
  3688	            self._indent_level += 1
  3689	
  3690	        ele_content = ""
  3691	        if start:
  3692	            element = "<" + tag
  3693	            for k, v in data.items():
  3694	                element += f" {k}='{v}'"
  3695	            element += ">\n"
  3696	        else:
  3697	            if data:
  3698	                ele_content = f"{data}\n"
  3699	            element = f"</{tag}>\n"
  3700	
  3701	        if start is False:
  3702	            self._indent_level -= 1
  3703	        # The content is formatted on the fly: not mandatory but cool for debugging
  3704	        indent = "".join(" " for _ in range(2 * self._indent_level))
  3705	        if ele_content:
  3706	            self._content += indent + "  " + ele_content
  3707	        self._content += indent + element
  3708	        if start is True:
  3709	            self._indent_level += 1
  3710	
  3711	    def _unknown_mapping_tag(self, start, tag, data, config, pos):
  3712	        """
  3713	        In case of unexpected tag, the parsing stops and the mapping block
  3714	        is set with a REPORT tag telling what went wrong.
  3715	        The signature si that same as for all _add_* methods of the parser.
  3716	        """
  3717	        self._content = (
  3718	            f'<VODML xmlns="http://www.ivoa.net/xml/mivot">\n '
  3719	            f'<REPORT status="KO">Unknown mivot block statement: {tag}</REPORT>\n</VODML>'
  3720	        )
  3721	        self._on_error = True
  3722	        warn_or_raise(W10, W10, tag, config, pos=pos)
  3723	
  3724	    @property
  3725	    def content(self):
  3726	        """
  3727	        The XML mapping block serialized as string.
  3728	        If there is not mapping block, an empty block is returned in order to
  3729	        prevent client code to deal with None blocks.
  3730	        """
  3731	        if self._content == "":
  3732	            self._content = (
  3733	                '<VODML xmlns="http://www.ivoa.net/xml/mivot">\n '
  3734	                '<REPORT status="KO">No Mivot block</REPORT>\n</VODML>\n'
  3735	            )
  3736	        return self._content
  3737	
  3738	    def parse(self, votable, iterator, config):
  3739	        """
  3740	        Regular parser similar to others VOTable components.
  3741	        """
  3742	        model_mapping_mapping = {
  3743	            "VODML": self._add_statement,
  3744	            "GLOBALS": self._add_statement,
  3745	            "REPORT": self._add_statement,
  3746	            "MODEL": self._add_statement,
  3747	            "TEMPLATES": self._add_statement,
  3748	            "COLLECTION": self._add_statement,
  3749	            "INSTANCE": self._add_statement,
  3750	            "ATTRIBUTE": self._add_statement,
  3751	            "REFERENCE": self._add_statement,
  3752	            "JOIN": self._add_statement,
  3753	            "WHERE": self._add_statement,
  3754	            "PRIMARY_KEY": self._add_statement,
  3755	            "FOREIGN_KEY": self._add_statement,
  3756	        }
  3757	        for start, tag, data, pos in iterator:
  3758	            model_mapping_mapping.get(tag, self._unknown_mapping_tag)(
  3759	                start, tag, data, config, pos
  3760	            )
  3761	            if start is False and tag == "VODML":
  3762	                break
  3763	
  3764	        return self
  3765	
  3766	    def to_xml(self, w):
  3767	        """
  3768	        Tells the writer to insert the MIVOT block in its output stream.
  3769	        """
  3770	        w.string_element(self._content)
  3771	
  3772	    def check_content_format(self):
  3773	        """
  3774	        Check if the content is on xml format by building a VOTable,
  3775	        putting a MIVOT block in the first resource and trying to parse the VOTable.
  3776	        """
  3777	        if not self._content.startswith("<"):
  3778	            vo_raise(E26)
  3779	
  3780	        in_memory_votable = VOTableFile()
  3781	        mivot_resource = Resource()
  3782	        mivot_resource.type = "meta"
  3783	        mivot_resource.mivot_block = self
  3784	        # pack the meta resource in a top level resource
  3785	        result_resource = Resource()
  3786	        result_resource.type = "results"
  3787	        result_resource.resources.append(mivot_resource)
  3788	        data_table = TableElement(in_memory_votable)
  3789	        data_table.name = "t1"
  3790	        result_resource.tables.append(data_table)
  3791	        in_memory_votable.resources.append(result_resource)
  3792	
  3793	        # Push the VOTable in an IOSTream (emulates a disk saving)
  3794	        buff = io.BytesIO()
  3795	        in_memory_votable.to_xml(buff)
  3796	
  3797	        # Read the IOStream (emulates a disk readout)
  3798	        buff.seek(0)
  3799	        config = {}
  3800	
  3801	        with iterparser.get_xml_iterator(
  3802	            buff, _debug_python_based_parser=None
  3803	        ) as iterator:
  3804	            return VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
  3805	
  3806	
  3807	@deprecated("6.0", alternative="TableElement")
  3808	class Table(TableElement):
  3809	    pass
  3810	
  3811	
  3812	class Resource(
  3813	    Element, _IDProperty, _NameProperty, _UtypeProperty, _DescriptionProperty
  3814	):
  3815	    """
  3816	    RESOURCE_ element: Groups TABLE_ and RESOURCE_ elements.
  3817	
  3818	    The keyword arguments correspond to setting members of the same
  3819	    name, documented below.
  3820	    """
  3821	
  3822	    def __init__(
  3823	        self,
  3824	        name=None,
  3825	        ID=None,
  3826	        utype=None,
  3827	        type="results",
  3828	        id=None,
  3829	        config=None,
  3830	        pos=None,
  3831	        **kwargs,
  3832	    ):
  3833	        if config is None:
  3834	            config = {}
  3835	        self._config = config
  3836	        self._pos = pos
  3837	
  3838	        Element.__init__(self)
  3839	        self.name = name
  3840	        self.ID = resolve_id(ID, id, config, pos)
  3841	        self.utype = utype
  3842	        self.type = type
  3843	        self._extra_attributes = kwargs
  3844	        self.description = None
  3845	
  3846	        self._coordinate_systems = HomogeneousList(CooSys)
  3847	        self._time_systems = HomogeneousList(TimeSys)
  3848	        self._groups = HomogeneousList(Group)
  3849	        self._params = HomogeneousList(Param)
  3850	        self._infos = HomogeneousList(Info)
  3851	        self._links = HomogeneousList(Link)
  3852	        self._tables = HomogeneousList(TableElement)
  3853	        self._resources = HomogeneousList(Resource)
  3854	
  3855	        self._mivot_block = MivotBlock()
  3856	        warn_unknown_attrs("RESOURCE", kwargs.keys(), config, pos)
  3857	
  3858	    def __repr__(self):
  3859	        buff = io.StringIO()
  3860	        w = XMLWriter(buff)
  3861	        w.element(self._element_name, attrib=w.object_attrs(self, self._attr_list))
  3862	        return buff.getvalue().strip()
  3863	
  3864	    @property
  3865	    def type(self):
  3866	        """The type of the resource [*required*].
  3867	
  3868	        Must be either:
  3869	
  3870	          - 'results': This resource contains actual result values
  3871	            (default)
  3872	
  3873	          - 'meta': This resource contains only datatype descriptions
  3874	            (FIELD_ elements), but no actual data.
  3875	        """
  3876	        return self._type
  3877	
  3878	    @type.setter
  3879	    def type(self, type):
  3880	        if type not in ("results", "meta"):
  3881	            vo_raise(E18, type, self._config, self._pos)
  3882	        self._type = type
  3883	
  3884	    @property
  3885	    def mivot_block(self):
  3886	        """
  3887	        Returns the MIVOT block instance.
  3888	        If the host resource is of type results, it is taken from the first
  3889	        child resource with a MIVOT block, if any.
  3890	        Otherwise, it is taken from the host resource.
  3891	        """
  3892	        if self.type == "results":
  3893	            for resource in self.resources:
  3894	                if str(resource._mivot_block).strip() != "":
  3895	                    return resource._mivot_block
  3896	        return self._mivot_block
  3897	
  3898	    @mivot_block.setter
  3899	    def mivot_block(self, mivot_block):
  3900	        if self.type == "results":
  3901	            vo_raise(E26)
  3902	        self._mivot_block = mivot_block
  3903	
  3904	    @property
  3905	    def extra_attributes(self):
  3906	        """Dictionary of extra attributes of the RESOURCE_ element.
  3907	
  3908	        This is dictionary of string keys to string values containing any
  3909	        extra attributes of the RESOURCE_ element that are not defined
  3910	        in the specification. The specification explicitly allows
  3911	        for extra attributes here, but nowhere else.
  3912	        """
  3913	        return self._extra_attributes
  3914	
  3915	    @property
  3916	    def coordinate_systems(self):
  3917	        """
  3918	        A list of coordinate system definitions (COOSYS_ elements) for
  3919	        the RESOURCE_.  Must contain only `CooSys` objects.
  3920	        """
  3921	        return self._coordinate_systems
  3922	
  3923	    @property
  3924	    def time_systems(self):
  3925	        """
  3926	        A list of time system definitions (TIMESYS_ elements) for
  3927	        the RESOURCE_.  Must contain only `TimeSys` objects.
  3928	        """
  3929	        return self._time_systems
  3930	
  3931	    @property
  3932	    def infos(self):
  3933	        """
  3934	        A list of informational parameters (key-value pairs) for the
  3935	        resource.  Must only contain `Info` objects.
  3936	        """
  3937	        return self._infos
  3938	
  3939	    @property
  3940	    def groups(self):
  3941	        """
  3942	        A list of groups.
  3943	        """
  3944	        return self._groups
  3945	
  3946	    @property
  3947	    def params(self):
  3948	        """
  3949	        A list of parameters (constant-valued columns) for the
  3950	        resource.  Must contain only `Param` objects.
  3951	        """
  3952	        return self._params
  3953	
  3954	
  3955	
  3956	
  3957	
  3958	
  3959	
  3960	
  3961	
  3962	
  3963	    @property
  3964	    def tables(self):
  3965	        """
  3966	        A list of tables in the resource.  Must contain only
  3967	        `TableElement` objects.
  3968	        """
  3969	        return self._tables
  3970
```

## 原始行 26 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '200,400p'; nl -ba astropy/io/votable/tree.py | sed -n '3960,4300p'; find astropy/io/votable/tests astropy/utils/xml/tests -type f -name '*.py' -maxdepth 3 | sort"
```

退出码：`0`

输出：
```
   200	
   201	    if unique:
   202	        lookup_by_attr_unique.__doc__ = doc
   203	        return lookup_by_attr_unique
   204	    else:
   205	        lookup_by_attr.__doc__ = doc
   206	        return lookup_by_attr
   207	
   208	
   209	def _lookup_by_id_or_name_factory(iterator, element_name, doc):
   210	    """
   211	    Like `_lookup_by_attr_factory`, but looks in both the "ID" and
   212	    "name" attributes.
   213	    """
   214	
   215	    def lookup_by_id_or_name(self, ref, before=None):
   216	        """
   217	        Given an key *ref*, finds the first element in the iterator
   218	        with the attribute ID == *ref* or name == *ref*.  If *before*
   219	        is provided, will stop searching at the object *before*.  This
   220	        is important, since "forward references" are not allowed in
   221	        the VOTABLE format.
   222	        """
   223	        for element in getattr(self, iterator)():
   224	            if element is before:
   225	                if ref in (element.ID, element.name):
   226	                    vo_raise(
   227	                        KeyError,
   228	                        f"{element_name} references itself",
   229	                        element._config,
   230	                        element._pos,
   231	                    )
   232	                break
   233	            if ref in (element.ID, element.name):
   234	                return element
   235	        raise KeyError(
   236	            f"No {element_name} with ID or name '{ref}' found before the referencing "
   237	            f"{element_name}"
   238	        )
   239	
   240	    lookup_by_id_or_name.__doc__ = doc
   241	    return lookup_by_id_or_name
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	def _attach_default_config(votable, config) -> dict:
   268	    """Create default config if none given.
   269	
   270	    Parameters
   271	    ----------
   272	    votable
   273	        Object that might potentially have a config attached to it.
   274	    config : `dict` or `None`
   275	        Config to be used or defined.
   276	
   277	    Returns
   278	    -------
   279	    config : `dict`
   280	        If config was `None` this will be a new `dict`. If the ``votable``
   281	        supported version checks then version information will be stored in
   282	        the returned `dict`. If it was defined this will be the given
   283	        parameter unchanged.
   284	    """
   285	    if config is None:
   286	        if hasattr(votable, "_get_version_checks"):
   287	            config = votable._get_version_checks()
   288	        else:
   289	            config = {}
   290	    return config
   291	
   292	
   293	######################################################################
   294	# ATTRIBUTE CHECKERS
   295	def check_astroyear(year, field, config=None, pos=None):
   296	    """
   297	    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
   298	    *year* is not a valid astronomical year as defined by the VOTABLE
   299	    standard.
   300	
   301	    Parameters
   302	    ----------
   303	    year : str
   304	        An astronomical year string
   305	
   306	    field : str
   307	        The name of the field this year was found in (used for error
   308	        message)
   309	
   310	    config, pos : optional
   311	        Information about the source of the value
   312	    """
   313	    if year is not None and re.match(r"^[JB]?[0-9]+([.][0-9]*)?$", year) is None:
   314	        warn_or_raise(W07, W07, (field, year), config, pos)
   315	        return False
   316	    return True
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	def resolve_id(ID, id, config=None, pos=None):
   343	    if ID is None and id is not None:
   344	        warn_or_raise(W09, W09, (), config, pos)
   345	        return id
   346	    return ID
   347	
   348	
   349	def check_ucd(ucd, config=None, pos=None):
   350	    """
   351	    Warns or raises a
   352	    `~astropy.io.votable.exceptions.VOTableSpecError` if *ucd* is not
   353	    a valid `unified content descriptor`_ string as defined by the
   354	    VOTABLE standard.
   355	
   356	    Parameters
   357	    ----------
   358	    ucd : str
   359	        A UCD string.
   360	
   361	    config, pos : optional
   362	        Information about the source of the value
   363	    """
   364	    if config is None:
   365	        config = {}
   366	    if config.get("version_1_1_or_later"):
   367	        try:
   368	            ucd_mod.parse_ucd(
   369	                ucd,
   370	                check_controlled_vocabulary=config.get("version_1_2_or_later", False),
   371	                has_colon=config.get("version_1_2_or_later", False),
   372	            )
   373	        except ValueError as e:
   374	            # This weird construction is for Python 3 compatibility
   375	            if config.get("verify", "ignore") == "exception":
   376	                vo_raise(W06, (ucd, str(e)), config, pos)
   377	            elif config.get("verify", "ignore") == "warn":
   378	                vo_warn(W06, (ucd, str(e)), config, pos)
   379	                return False
   380	            else:
   381	                return False
   382	    return True
   383	
   384	
   385	######################################################################
   386	# PROPERTY MIXINS
   387	class _IDProperty:
   388	    @property
   389	    def ID(self):
   390	        """
   391	        The XML ID_ of the element.  May be `None` or a string
   392	        conforming to XML ID_ syntax.
   393	        """
   394	        return self._ID
   395	
   396	    @ID.setter
   397	    def ID(self, ID):
   398	        xmlutil.check_id(ID, "ID", self._config, self._pos)
   399	        self._ID = ID
   400	
  3960	
  3961	
  3962	
  3963	    @property
  3964	    def tables(self):
  3965	        """
  3966	        A list of tables in the resource.  Must contain only
  3967	        `TableElement` objects.
  3968	        """
  3969	        return self._tables
  3970	
  3971	    @property
  3972	    def resources(self):
  3973	        """
  3974	        A list of nested resources inside this resource.  Must contain
  3975	        only `Resource` objects.
  3976	        """
  3977	        return self._resources
  3978	
  3979	    def _add_table(self, iterator, tag, data, config, pos):
  3980	        table = TableElement(self._votable, config=config, pos=pos, **data)
  3981	        self.tables.append(table)
  3982	        table.parse(iterator, config)
  3983	
  3984	    def _add_info(self, iterator, tag, data, config, pos):
  3985	        info = Info(config=config, pos=pos, **data)
  3986	        self.infos.append(info)
  3987	        info.parse(iterator, config)
  3988	
  3989	    def _add_group(self, iterator, tag, data, config, pos):
  3990	        group = Group(self, config=config, pos=pos, **data)
  3991	        self.groups.append(group)
  3992	        group.parse(iterator, config)
  3993	
  3994	    def _add_param(self, iterator, tag, data, config, pos):
  3995	        param = Param(self._votable, config=config, pos=pos, **data)
  3996	        self.params.append(param)
  3997	        param.parse(iterator, config)
  3998	
  3999	    def _add_coosys(self, iterator, tag, data, config, pos):
  4000	        coosys = CooSys(config=config, pos=pos, **data)
  4001	        self.coordinate_systems.append(coosys)
  4002	        coosys.parse(iterator, config)
  4003	
  4004	    def _add_timesys(self, iterator, tag, data, config, pos):
  4005	        timesys = TimeSys(config=config, pos=pos, **data)
  4006	        self.time_systems.append(timesys)
  4007	        timesys.parse(iterator, config)
  4008	
  4009	    def _add_resource(self, iterator, tag, data, config, pos):
  4010	        resource = Resource(config=config, pos=pos, **data)
  4011	        self.resources.append(resource)
  4012	        resource.parse(self._votable, iterator, config)
  4013	
  4014	    def _add_link(self, iterator, tag, data, config, pos):
  4015	        link = Link(config=config, pos=pos, **data)
  4016	        self.links.append(link)
  4017	        link.parse(iterator, config)
  4018	
  4019	    def parse(self, votable, iterator, config):
  4020	        self._votable = votable
  4021	
  4022	        tag_mapping = {
  4023	            "TABLE": self._add_table,
  4024	            "INFO": self._add_info,
  4025	            "PARAM": self._add_param,
  4026	            "GROUP": self._add_group,
  4027	            "COOSYS": self._add_coosys,
  4028	            "TIMESYS": self._add_timesys,
  4029	            "RESOURCE": self._add_resource,
  4030	            "LINK": self._add_link,
  4031	            "DESCRIPTION": self._ignore_add,
  4032	        }
  4033	
  4034	        for start, tag, data, pos in iterator:
  4035	            # If the resource content starts with VODML,
  4036	            # the parsing is delegated to the MIVOT parser
  4037	            if tag == "VODML":
  4038	                self._mivot_block.parse(votable, iterator, config)
  4039	            elif start:
  4040	                tag_mapping.get(tag, self._add_unknown_tag)(
  4041	                    iterator, tag, data, config, pos
  4042	                )
  4043	            elif tag == "DESCRIPTION":
  4044	                if self.description is not None:
  4045	                    warn_or_raise(W17, W17, "RESOURCE", config, pos)
  4046	                self.description = data or None
  4047	            elif tag == "RESOURCE":
  4048	                break
  4049	
  4050	        del self._votable
  4051	
  4052	        return self
  4053	
  4054	    def to_xml(self, w, **kwargs):
  4055	        attrs = w.object_attrs(self, ("ID", "type", "utype"))
  4056	        attrs.update(self.extra_attributes)
  4057	        with w.tag("RESOURCE", attrib=attrs):
  4058	            if self.description is not None:
  4059	                w.element("DESCRIPTION", self.description, wrap=True)
  4060	            if self.mivot_block is not None and self.type == "meta":
  4061	                self.mivot_block.to_xml(w)
  4062	            element_sets = [
  4063	                self.infos,
  4064	                self.coordinate_systems,
  4065	                self.time_systems,
  4066	                self.params,
  4067	                self.links,
  4068	            ]
  4069	            if kwargs["version_1_2_or_later"]:
  4070	                element_sets.append(self.groups)
  4071	
  4072	            for element_set in element_sets:
  4073	                for element in element_set:
  4074	                    element.to_xml(w, **kwargs)
  4075	
  4076	            # The mivot_block should be before the table
  4077	            for elm in self.resources:
  4078	                if elm.type == "meta" and elm.mivot_block is not None:
  4079	                    elm.to_xml(w, **kwargs)
  4080	
  4081	            for elm in self.tables:
  4082	                elm.to_xml(w, **kwargs)
  4083	
  4084	            for elm in self.resources:
  4085	                if elm.type != "meta":
  4086	                    elm.to_xml(w, **kwargs)
  4087	
  4088	    def iter_tables(self):
  4089	        """
  4090	        Recursively iterates over all tables in the resource and
  4091	        nested resources.
  4092	        """
  4093	        yield from self.tables
  4094	        for resource in self.resources:
  4095	            yield from resource.iter_tables()
  4096	
  4097	    def iter_fields_and_params(self):
  4098	        """
  4099	        Recursively iterates over all FIELD_ and PARAM_ elements in
  4100	        the resource, its tables and nested resources.
  4101	        """
  4102	        yield from self.params
  4103	        for table in self.tables:
  4104	            yield from table.iter_fields_and_params()
  4105	        for resource in self.resources:
  4106	            yield from resource.iter_fields_and_params()
  4107	
  4108	    def iter_coosys(self):
  4109	        """
  4110	        Recursively iterates over all the COOSYS_ elements in the
  4111	        resource and nested resources.
  4112	        """
  4113	        yield from self.coordinate_systems
  4114	        for resource in self.resources:
  4115	            yield from resource.iter_coosys()
  4116	
  4117	    def iter_timesys(self):
  4118	        """
  4119	        Recursively iterates over all the TIMESYS_ elements in the
  4120	        resource and nested resources.
  4121	        """
  4122	        yield from self.time_systems
  4123	        for resource in self.resources:
  4124	            yield from resource.iter_timesys()
  4125	
  4126	    def iter_info(self):
  4127	        """
  4128	        Recursively iterates over all the INFO_ elements in the
  4129	        resource and nested resources.
  4130	        """
  4131	        yield from self.infos
  4132	        for table in self.tables:
  4133	            yield from table.iter_info()
  4134	        for resource in self.resources:
  4135	            yield from resource.iter_info()
  4136	
  4137	
  4138	class VOTableFile(Element, _IDProperty, _DescriptionProperty):
  4139	    """
  4140	    VOTABLE_ element: represents an entire file.
  4141	
  4142	    The keyword arguments correspond to setting members of the same
  4143	    name, documented below.
  4144	
  4145	    *version* is settable at construction time only, since conformance
  4146	    tests for building the rest of the structure depend on it.
  4147	    """
  4148	
  4149	    def __init__(self, ID=None, id=None, config=None, pos=None, version="1.4"):
  4150	        self._config = config.copy() if config is not None else {}
  4151	
  4152	        # Version setter forces the associated version config settings to
  4153	        # be calculated.
  4154	        self.version = version
  4155	        self._pos = pos
  4156	
  4157	        Element.__init__(self)
  4158	        self.ID = resolve_id(ID, id, config, pos)
  4159	        self.description = None
  4160	
  4161	        self._coordinate_systems = HomogeneousList(CooSys)
  4162	        self._time_systems = HomogeneousList(TimeSys)
  4163	        self._params = HomogeneousList(Param)
  4164	        self._infos = HomogeneousList(Info)
  4165	        self._resources = HomogeneousList(Resource)
  4166	        self._groups = HomogeneousList(Group)
  4167	
  4168	    def __repr__(self):
  4169	        n_tables = len(list(self.iter_tables()))
  4170	        return f"<VOTABLE>... {n_tables} tables ...</VOTABLE>"
  4171	
  4172	    @property
  4173	    def config(self):
  4174	        """
  4175	        Configuration used to construct this object. Will always include the
  4176	        version check values.
  4177	        """
  4178	        return self._config
  4179	
  4180	    @property
  4181	    def version(self):
  4182	        """
  4183	        The version of the VOTable specification that the file uses.
  4184	        """
  4185	        return self._version
  4186	
  4187	    @version.setter
  4188	    def version(self, version):
  4189	        version = str(version)
  4190	        if version not in self._version_namespace_map:
  4191	            allowed_from_map = "', '".join(self._version_namespace_map)
  4192	            raise ValueError(
  4193	                f"astropy.io.votable version should be in ('{allowed_from_map}')."
  4194	            )
  4195	        self._version = version
  4196	        # Force config update.
  4197	        self._config.update(self._get_version_checks())
  4198	        self._config["version"] = version
  4199	
  4200	    @property
  4201	    def coordinate_systems(self):
  4202	        """
  4203	        A list of coordinate system descriptions for the file.  Must
  4204	        contain only `CooSys` objects.
  4205	        """
  4206	        return self._coordinate_systems
  4207	
  4208	    @property
  4209	    def time_systems(self):
  4210	        """
  4211	        A list of time system descriptions for the file.  Must
  4212	        contain only `TimeSys` objects.
  4213	        """
  4214	        return self._time_systems
  4215	
  4216	    @property
  4217	    def params(self):
  4218	        """
  4219	        A list of parameters (constant-valued columns) that apply to
  4220	        the entire file.  Must contain only `Param` objects.
  4221	        """
  4222	        return self._params
  4223	
  4224	    @property
  4225	    def infos(self):
  4226	        """
  4227	        A list of informational parameters (key-value pairs) for the
  4228	        entire file.  Must only contain `Info` objects.
  4229	        """
  4230	        return self._infos
  4231	
  4232	    @property
  4233	    def resources(self):
  4234	        """
  4235	        A list of resources, in the order they appear in the file.
  4236	        Must only contain `Resource` objects.
  4237	        """
  4238	        return self._resources
  4239	
  4240	    @property
  4241	    def groups(self):
  4242	        """
  4243	        A list of groups, in the order they appear in the file.  Only
  4244	        supported as a child of the VOTABLE element in VOTable 1.2 or
  4245	        later.
  4246	        """
  4247	        return self._groups
  4248	
  4249	    def _add_param(self, iterator, tag, data, config, pos):
  4250	        param = Param(self, config=config, pos=pos, **data)
  4251	        self.params.append(param)
  4252	        param.parse(iterator, config)
  4253	
  4254	    def _add_resource(self, iterator, tag, data, config, pos):
  4255	        resource = Resource(config=config, pos=pos, **data)
  4256	        self.resources.append(resource)
  4257	        resource.parse(self, iterator, config)
  4258	
  4259	    def _add_coosys(self, iterator, tag, data, config, pos):
  4260	        coosys = CooSys(config=config, pos=pos, **data)
  4261	        self.coordinate_systems.append(coosys)
  4262	        coosys.parse(iterator, config)
  4263	
  4264	    def _add_timesys(self, iterator, tag, data, config, pos):
  4265	        timesys = TimeSys(config=config, pos=pos, **data)
  4266	        self.time_systems.append(timesys)
  4267	        timesys.parse(iterator, config)
  4268	
  4269	    def _add_info(self, iterator, tag, data, config, pos):
  4270	        info = Info(config=config, pos=pos, **data)
  4271	        self.infos.append(info)
  4272	        info.parse(iterator, config)
  4273	
  4274	    def _add_group(self, iterator, tag, data, config, pos):
  4275	        if not config.get("version_1_2_or_later"):
  4276	            warn_or_raise(W26, W26, ("GROUP", "VOTABLE", "1.2"), config, pos)
  4277	        group = Group(self, config=config, pos=pos, **data)
  4278	        self.groups.append(group)
  4279	        group.parse(iterator, config)
  4280	
  4281	    def _get_version_checks(self):
  4282	        config = {}
  4283	        config["version"] = self.version
  4284	        config["version_1_1_or_later"] = util.version_compare(self.version, "1.1") >= 0
  4285	        config["version_1_2_or_later"] = util.version_compare(self.version, "1.2") >= 0
  4286	        config["version_1_3_or_later"] = util.version_compare(self.version, "1.3") >= 0
  4287	        config["version_1_4_or_later"] = util.version_compare(self.version, "1.4") >= 0
  4288	        config["version_1_5_or_later"] = util.version_compare(self.version, "1.5") >= 0
  4289	        return config
  4290	
  4291	    # Map VOTable version numbers to namespace URIs and schema information.
  4292	    _version_namespace_map = {
  4293	        # Version 1.0 isn't well-supported, but is allowed on parse (with a warning).
  4294	        # It used DTD rather than schema, so this information would not be useful.
  4295	        # By omitting 1.0 from this dict we can use the keys as the list of versions
  4296	        # that are allowed in various other checks.
  4297	        "1.1": {
  4298	            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.1",
  4299	            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
  4300	            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.1",
astropy/io/votable/tests/__init__.py
astropy/io/votable/tests/test_coosys.py
astropy/io/votable/tests/test_dataorigin.py
astropy/io/votable/tests/test_exception.py
astropy/io/votable/tests/test_resource.py
astropy/io/votable/tests/test_schema_versions.py
astropy/io/votable/tests/test_table.py
astropy/io/votable/tests/test_tree.py
astropy/io/votable/tests/test_ucd.py
astropy/io/votable/tests/test_util.py
astropy/io/votable/tests/test_vo.py
astropy/utils/xml/tests/__init__.py
astropy/utils/xml/tests/test_iterparse.py
```

## 原始行 28 · agent_message

```
The requested functions sit in clearly excised blocks, while their surrounding factories and serializers are intact. I’m using those neighboring implementations and the repository’s tests as the behavioral contract—especially for warning classes, forward-reference boundaries, masking, and metadata round-trips.
```

## 原始行 30 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"check_id|fix_id|UCDWords|parse_ucd|get_field_by_id|get_field_by_id_or_name|get_fields_by_utype|get_group_by_id|get_groups_by_utype|to_table\\(|is_defaults|_parse_minmax|check_string|unicodeChar|supports_empty_values\" astropy/io/votable/tests astropy/utils --include='*.py' | head -n 500"
```

退出码：`0`

输出：
```
astropy/io/votable/tests/test_table.py:67:    astropy_table = table.to_table()
astropy/io/votable/tests/test_table.py:78:        ("unicode_test", {"datatype": "unicodeChar", "arraysize": "*"}),
astropy/io/votable/tests/test_table.py:79:        ("fixed_unicode_test", {"datatype": "unicodeChar", "arraysize": "10"}),
astropy/io/votable/tests/test_table.py:172:    table = votable.get_first_table().to_table(use_names_over_ids=True)
astropy/io/votable/tests/test_table.py:199:    table = votable.get_first_table().to_table(use_names_over_ids=False)
astropy/io/votable/tests/test_table.py:237:    table = parse(fpath).get_first_table().to_table()
astropy/io/votable/tests/test_table.py:448:    table.to_table()
astropy/io/votable/tests/test_table.py:473:    astropy_table = table.to_table()
astropy/io/votable/tests/test_table.py:531:    astropy_table = table.to_table()
astropy/io/votable/tests/test_table.py:545:    astropy_table2 = table2.to_table()
astropy/io/votable/tests/test_table.py:758:    Test that variable length unicodeChars with a maximum length are correctly
astropy/io/votable/tests/test_table.py:771:            datatype="unicodeChar",
astropy/io/votable/tests/test_table.py:814:    Test that unicodeChar converter correctly validates bounds and issues warnings.
astropy/io/votable/tests/test_table.py:820:        datatype="unicodeChar",
astropy/io/votable/tests/test_table.py:832:        "unicodeChar" in str(w.message) and "5" in str(w.message) for w in record
astropy/io/votable/tests/test_table.py:840:            "unicodeChar" in str(w.message) and "5" in str(w.message) for w in record
astropy/io/votable/tests/test_table.py:922:    Test that a warning is issued when reading a unicodeChar array in
astropy/io/votable/tests/test_table.py:929:        datatype="unicodeChar",
astropy/io/votable/tests/test_table.py:946:        "unicodeChar" in str(w.message) and "5" in str(w.message) for w in record
astropy/io/votable/tests/test_tree.py:37:        tree.check_string(42, "foo", config)
astropy/io/votable/tests/test_tree.py:231:        param_or_field = vot.get_field_by_id_or_name("param_or_field")
astropy/io/votable/tests/test_ucd.py:55:        assert ucd.parse_ucd(s, True, True) == p
astropy/io/votable/tests/test_ucd.py:61:        ucd.parse_ucd("ivoa:stsci:phot", True, True)
astropy/io/votable/tests/test_ucd.py:66:        ucd.parse_ucd("_ivoa:phot.mag", True, True)
astropy/io/votable/tests/test_ucd.py:71:        ucd.parse_ucd("-pho")
astropy/io/votable/tests/test_ucd.py:82:    result = ucd.parse_ucd(ucd_string, check_controlled_vocabulary=True)
astropy/io/votable/tests/test_ucd.py:100:        result = ucd.parse_ucd(term, check_controlled_vocabulary=True)
astropy/io/votable/tests/test_ucd.py:113:        result = ucd.parse_ucd(combined_ucd, check_controlled_vocabulary=True)
astropy/io/votable/tests/test_vo.py:391:    t1 = vot1.to_table(use_names_over_ids=use_names_over_ids)
astropy/io/votable/tests/test_vo.py:685:        fields = list(self.votable.get_fields_by_utype("myint"))
astropy/io/votable/tests/test_vo.py:844:    table = votable.get_first_table().to_table()
astropy/utils/tests/test_xml.py:23:def test_check_id():
astropy/utils/tests/test_xml.py:24:    assert check.check_id("Fof32")
astropy/utils/tests/test_xml.py:25:    assert check.check_id("_Fof32")
astropy/utils/tests/test_xml.py:26:    assert not check.check_id("32Fof")
astropy/utils/tests/test_xml.py:29:def test_fix_id():
astropy/utils/tests/test_xml.py:30:    assert check.fix_id("Fof32") == "Fof32"
astropy/utils/tests/test_xml.py:31:    assert check.fix_id("@#f") == "___f"
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,270p' astropy/io/votable/tests/test_tree.py; sed -n '1,250p' astropy/io/votable/tests/test_table.py; sed -n '430,570p' astropy/io/votable/tests/test_table.py; sed -n '680,860p' astropy/io/votable/tests/test_table.py; sed -n '1,160p' astropy/io/votable/tests/test_ucd.py; sed -n '650,720p' astropy/io/votable/tests/test_vo.py; sed -n '1,80p' astropy/utils/tests/test_xml.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
import filecmp
import io

import numpy as np
import pytest

from astropy.io.votable import tree
from astropy.io.votable.exceptions import (
    E26,
    W07,
    W08,
    W15,
    W21,
    W27,
    W37,
    W41,
    W47,
    W54,
    W57,
)
from astropy.io.votable.table import parse
from astropy.io.votable.tree import MivotBlock, Resource, VOTableFile
from astropy.utils.data import get_pkg_data_filename


def test_check_astroyear_fail():
    config = {"verify": "exception"}
    field = tree.Field(None, name="astroyear", arraysize="1")
    with pytest.raises(W07):
        tree.check_astroyear("X2100", field, config)


def test_string_fail():
    config = {"verify": "exception"}
    with pytest.raises(W08):
        tree.check_string(42, "foo", config)


def test_make_Fields():
    votable = VOTableFile()
    # ...with one resource...
    resource = Resource()
    votable.resources.append(resource)

    # ... with one table
    table = tree.TableElement(votable)
    resource.tables.append(table)

    table.fields.extend(
        [tree.Field(votable, name="Test", datatype="float", unit="mag")]
    )


def test_unit_format():
    data = parse(get_pkg_data_filename("data/irsa-nph-error.xml"))
    assert data._config["version"] == "1.0"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/names.xml"))
    assert data._config["version"] == "1.1"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/gemini.xml"))
    assert data._config["version"] == "1.2"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/binary2_masked_strings.xml"))
    assert data._config["version"] == "1.3"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/timesys.xml"))
    assert data._config["version"] == "1.4"
    assert tree._get_default_unit_format(data._config) == "vounit"


def test_namespace_warning():
    """
    A version 1.4 VOTable must use the same namespace as 1.3.
    (see https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html#ToC16).
    """
    bad_namespace = b"""<?xml version="1.0" encoding="utf-8"?>
        <VOTABLE version="1.4" xmlns="http://www.ivoa.net/xml/VOTable/v1.4"
                               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <RESOURCE/>
        </VOTABLE>
    """
    with pytest.warns(W41):
        parse(io.BytesIO(bad_namespace), verify="exception")

    good_namespace_14 = b"""<?xml version="1.0" encoding="utf-8"?>
        <VOTABLE version="1.4" xmlns="http://www.ivoa.net/xml/VOTable/v1.3"
                               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <RESOURCE/>
        </VOTABLE>
    """
    parse(io.BytesIO(good_namespace_14), verify="exception")

    good_namespace_13 = b"""<?xml version="1.0" encoding="utf-8"?>
        <VOTABLE version="1.3" xmlns="http://www.ivoa.net/xml/VOTable/v1.3"
                               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <RESOURCE/>
        </VOTABLE>
    """
    parse(io.BytesIO(good_namespace_13), verify="exception")


def test_votable_values_empty_min_max():
    """Regression test for https://github.com/astropy/astropy/issues/16825"""
    with_empty_minmax = b"""<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.4">
        <RESOURCE type="results">
          <TABLE name="main">
            <PARAM name="break" datatype="int" value=""/>
          <FIELD ID="hd" datatype="int" name="hd" ucd="meta.id;meta.main">
            <DESCRIPTION>HD number for this object</DESCRIPTION>
            <VALUES null="-2147483648">
              <MIN value=""/>
              <MAX value=""/>
            </VALUES>
          </FIELD>
          <DATA>
            <BINARY>
              <STREAM encoding="base64">AAMNIg==</STREAM>
            </BINARY>
          </DATA>
        </TABLE>
      </RESOURCE>
    </VOTABLE>
    """
    parse(io.BytesIO(with_empty_minmax), verify="exception")


def _assert_minmax_match(val, expected_val):
    """val can be number or numpy array; expected_val can be number or list"""
    if isinstance(val, np.ndarray):
        assert np.allclose(val, np.array(expected_val))
    else:
        assert val == expected_val


@pytest.mark.parametrize(
    ("testvals"),
    [
        {
            "dt": "float",
            "min": "1.2",
            "max": "3.4",
            "expected_min": 1.2,
            "expected_max": 3.4,
        },
        {
            "dt": "float",
            "min": "1.2 3.4",
            "max": "3.4 5.6",
            "expected_min": [1.2, 3.4],
            "expected_max": [3.4, 5.6],
        },
        {
            "dt": "double",
            "min": "1.2",
            "max": "3.4",
            "expected_min": 1.2,
            "expected_max": 3.4,
        },
        {
            "dt": "double",
            "min": "1.2 3.4",
            "max": "3.4 5.6",
            "expected_min": [1.2, 3.4],
            "expected_max": [3.4, 5.6],
        },
        {
            "dt": "unsignedByte",
            "min": "1",
            "max": "3",
            "expected_min": 1,
            "expected_max": 3,
        },
        {
            "dt": "unsignedByte",
            "min": "1 3",
            "max": "3 5",
            "expected_min": [1, 3],
            "expected_max": [3, 5],
        },
        {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
        {
            "dt": "short",
            "min": "1 3",
            "max": "3 5",
            "expected_min": [1, 3],
            "expected_max": [3, 5],
        },
        {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
        {
            "dt": "int",
            "min": "1 3",
            "max": "3 5",
            "expected_min": [1, 3],
            "expected_max": [3, 5],
        },
        {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
        {
            "dt": "long",
            "min": "1 3",
            "max": "3 5",
            "expected_min": [1, 3],
            "expected_max": [3, 5],
        },
    ],
)
def test_min_max_with_arrays(testvals):
    """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
    MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
    minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
        <RESOURCE type="results">
            <TABLE ID="result" name="result">
                <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                    <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                </{param_or_field}>
            </TABLE>
        </RESOURCE>
    </VOTABLE>
    """

    for param_or_field in ["PARAM", "FIELD"]:
        testvals["param_or_field"] = param_or_field
        xml_string = minmax_template.format(**testvals)
        xml_bytes = xml_string.encode("utf-8")

        # Parse without exceptions.
        vot = parse(io.BytesIO(xml_bytes), verify="exception")

        # Assert that the scalar or array values were parsed and stored as expected.
        param_or_field = vot.get_field_by_id_or_name("param_or_field")
        _assert_minmax_match(param_or_field.values.min, testvals["expected_min"])
        _assert_minmax_match(param_or_field.values.max, testvals["expected_max"])


def test_version():
    """
    VOTableFile.__init__ allows versions of '1.1' through '1.5'.
    VOTableFile.__init__ does not allow version of '1.0' anymore and now raises a ValueError as it does to other versions not supported.
    """
    # Exercise the checks in __init__
    for version in ("1.1", "1.2", "1.3", "1.4", "1.5"):
        VOTableFile(version=version)
    for version in ("0.9", "1.0", "1.6", "2.0"):
        with pytest.raises(
            ValueError, match=r"should be in \('1.1', '1.2', '1.3', '1.4', '1.5'\)."
        ):
            VOTableFile(version=version)

    # Exercise the checks in the setter
    vot = VOTableFile()
    for version in ("1.1", "1.2", "1.3", "1.4", "1.5"):
        vot.version = version
    for version in ("1.0", "1.6", "2.0"):
        with pytest.raises(
            ValueError,
            match=r"version should be in \('1.1', '1.2', '1.3', '1.4', '1.5'\).",
        ):
            vot.version = version

    # Exercise the checks in the parser.
    begin = b'<?xml version="1.0" encoding="utf-8"?><VOTABLE version="'
    middle = b'" xmlns="http://www.ivoa.net/xml/VOTable/v'
    end = (
        b'" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><RESOURCE/></VOTABLE>'
    )

    # Valid versions
    for bversion in (b"1.1", b"1.2", b"1.3"):
        parse(
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Test the conversion to/from astropy.table.
"""

import io
import os
import pathlib
import struct
import warnings

import numpy as np
import pytest

from astropy import units as u
from astropy.io.votable import conf, from_table, is_votable, tree, validate
from astropy.io.votable.converters import Char, UnicodeChar, get_converter
from astropy.io.votable.exceptions import E01, E25, W39, W46, W50, VOWarning
from astropy.io.votable.table import parse, writeto
from astropy.io.votable.tree import Field, VOTableFile
from astropy.table import Column, Table
from astropy.table.table_helpers import simple_table
from astropy.utils.compat.optional_deps import HAS_PYARROW
from astropy.utils.data import (
    get_pkg_data_filename,
    get_pkg_data_fileobj,
    get_pkg_data_path,
)
from astropy.utils.misc import _NOT_OVERWRITING_MSG_MATCH


@pytest.fixture
def home_is_data(monkeypatch):
    """
    Pytest fixture to run a test case with tilde-prefixed paths.

    In the tilde-path case, environment variables are temporarily
    modified so that '~' resolves to the data directory.
    """
    path = get_pkg_data_path("data")
    # For Unix
    monkeypatch.setenv("HOME", path)
    # For Windows
    monkeypatch.setenv("USERPROFILE", path)


@pytest.fixture
def home_is_tmpdir(monkeypatch, tmp_path):
    """
    Pytest fixture to run a test case with tilde-prefixed paths.

    In the tilde-path case, environment variables are temporarily
    modified so that '~' resolves to the temp directory.
    """
    # For Unix
    monkeypatch.setenv("HOME", str(tmp_path))
    # For Windows
    monkeypatch.setenv("USERPROFILE", str(tmp_path))


def test_table(tmp_path):
    # Read the VOTABLE
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        votable = parse(get_pkg_data_filename("data/regression.xml"))
    table = votable.get_first_table()
    astropy_table = table.to_table()

    for name in table.array.dtype.names:
        assert np.all(astropy_table.mask[name] == table.array.mask[name])

    votable2 = tree.VOTableFile.from_table(astropy_table)
    t = votable2.get_first_table()

    field_types = [
        ("string_test", {"datatype": "char", "arraysize": "*"}),
        ("string_test_2", {"datatype": "char", "arraysize": "10"}),
        ("unicode_test", {"datatype": "unicodeChar", "arraysize": "*"}),
        ("fixed_unicode_test", {"datatype": "unicodeChar", "arraysize": "10"}),
        ("string_array_test", {"datatype": "char", "arraysize": "4*"}),
        ("unsignedByte", {"datatype": "unsignedByte"}),
        ("short", {"datatype": "short"}),
        ("int", {"datatype": "int"}),
        ("intNoNull", {"datatype": "int"}),
        ("long", {"datatype": "long"}),
        ("double", {"datatype": "double"}),
        ("float", {"datatype": "float"}),
        ("array", {"datatype": "long", "arraysize": "2*"}),
        ("bit", {"datatype": "bit"}),
        ("bitarray", {"datatype": "bit", "arraysize": "3x2"}),
        ("bitvararray", {"datatype": "bit", "arraysize": "*"}),
        ("bitvararray2", {"datatype": "bit", "arraysize": "3x2*"}),
        ("floatComplex", {"datatype": "floatComplex"}),
        ("doubleComplex", {"datatype": "doubleComplex"}),
        ("doubleComplexArray", {"datatype": "doubleComplex", "arraysize": "*"}),
        ("doubleComplexArrayFixed", {"datatype": "doubleComplex", "arraysize": "2"}),
        ("boolean", {"datatype": "bit"}),
        ("booleanArray", {"datatype": "bit", "arraysize": "4"}),
        ("nulls", {"datatype": "int"}),
        ("nulls_array", {"datatype": "int", "arraysize": "2x2"}),
        ("precision1", {"datatype": "double"}),
        ("precision2", {"datatype": "double"}),
        ("doublearray", {"datatype": "double", "arraysize": "*"}),
        ("bitarray2", {"datatype": "bit", "arraysize": "16"}),
    ]

    for field, (name, d) in zip(t.fields, field_types):
        assert field.ID == name
        assert field.datatype == d["datatype"], (
            f"{name} expected {d['datatype']} but get {field.datatype}"
        )
        if "arraysize" in d:
            assert field.arraysize == d["arraysize"]

    # W39: Bit values can not be masked
    with pytest.warns(W39):
        writeto(votable2, str(tmp_path / "through_table.xml"))


def test_read_from_tilde_path(home_is_data):
    # Just test that these run without error for tilde-paths
    path = os.path.join("~", "regression.xml")
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        votable = parse(path)
        Table.read(path, format="votable", table_id="main_table")


def test_read_through_table_interface(tmp_path):
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
            t = Table.read(fd, format="votable", table_id="main_table")

    assert len(t) == 5

    # Issue 8354
    assert t["float"].format is None

    fn = tmp_path / "table_interface.xml"

    # W39: Bit values can not be masked
    with pytest.warns(W39):
        t.write(fn, table_id="FOO", format="votable")

    with open(fn, "rb") as fd:
        t2 = Table.read(fd, format="votable", table_id="FOO")

    assert len(t2) == 5


def test_read_through_table_interface2():
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
            t = Table.read(fd, format="votable", table_id="last_table")

    assert len(t) == 0


def test_pass_kwargs_through_table_interface():
    # Table.read() should pass on keyword arguments meant for parse()
    filename = get_pkg_data_filename("data/nonstandard_units.xml")
    t = Table.read(filename, format="votable", unit_format="generic")
    assert t["Flux1"].unit == u.Unit("erg / (Angstrom cm2 s)")


def test_names_over_ids():
    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
        votable = parse(fd)

    table = votable.get_first_table().to_table(use_names_over_ids=True)

    assert table.colnames == [
        "Name",
        "GLON",
        "GLAT",
        "RAdeg",
        "DEdeg",
        "Jmag",
        "Hmag",
        "Kmag",
        "G3.6mag",
        "G4.5mag",
        "G5.8mag",
        "G8.0mag",
        "4.5mag",
        "8.0mag",
        "Emag",
        "24mag",
        "f_Name",
    ]


def test_explicit_ids():
    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
        votable = parse(fd)

    table = votable.get_first_table().to_table(use_names_over_ids=False)

    assert table.colnames == [
        "col1",
        "col2",
        "col3",
        "col4",
        "col5",
        "col6",
        "col7",
        "col8",
        "col9",
        "col10",
        "col11",
        "col12",
        "col13",
        "col14",
        "col15",
        "col16",
        "col17",
    ]


def test_table_read_with_unnamed_tables():
    """
    Issue #927.
    """
    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
        t = Table.read(fd, format="votable")

    assert len(t) == 1


def test_votable_path_object():
    """
    Testing when votable is passed as pathlib.Path object #4412.
    """
    fpath = pathlib.Path(get_pkg_data_filename("data/names.xml"))
    table = parse(fpath).get_first_table().to_table()

    assert len(table) == 1
    assert int(table[0][3]) == 266


def test_from_table_without_mask():
    t = Table()
    c = Column(data=[1, 2, 3], name="a")
    t.add_column(c)
    output = io.BytesIO()
    t.write(output, format="votable")


    t["a"] = [1, 2, 3]
    vt = from_table(t)
    writeto(vt, fname)

    if path_format == "tilde":
        # Ensure the tilde-prefixed path wasn't treated literally
        assert not os.path.exists(fname)

    with open(os.path.expanduser(fname)) as f:
        obuff = f.read()
    assert 'VOTABLE version="1.4"' in obuff
    assert "BINARY" not in obuff
    assert "TABLEDATA" in obuff


def test_empty_table():
    votable = parse(get_pkg_data_filename("data/empty_table.xml"))
    table = votable.get_first_table()
    table.to_table()


def test_no_field_not_empty_table():
    votable = parse(get_pkg_data_filename("data/no_field_not_empty_table.xml"))
    table = votable.get_first_table()
    assert len(table.fields) == 0
    assert len(table.infos) == 1


def test_no_field_not_empty_table_exception():
    with pytest.raises(E25):
        parse(
            get_pkg_data_filename("data/no_field_not_empty_table.xml"),
            verify="exception",
        )


def test_binary2_masked_strings():
    """
    Issue #8995.
    """
    # Read a VOTable which sets the null mask bit for each empty string value.
    votable = parse(get_pkg_data_filename("data/binary2_masked_strings.xml"))
    table = votable.get_first_table()
    astropy_table = table.to_table()

    # Ensure string columns have no masked values and can be written out
    assert not np.any(table.array.mask["epoch_photometry_url"])
    output = io.BytesIO()
    astropy_table.write(output, format="votable")


def test_validate_output_invalid():
    """
    Issue #12603. Test that we get the correct output from votable.validate with an invalid
    votable.
    """
    # A votable with errors
    invalid_votable_filepath = get_pkg_data_filename("data/regression.xml")

    # When output is None, check that validate returns validation output as a string
    validate_out = validate(invalid_votable_filepath, output=None)
    assert isinstance(validate_out, str)
    # Check for known error string
    assert "E02: Incorrect number of elements in array." in validate_out

    # When output is not set, check that validate returns a bool
    validate_out = validate(invalid_votable_filepath)
    assert isinstance(validate_out, bool)
    # Check that validation output is correct (votable is not valid)
    assert validate_out is False


def test_validate_output_valid():
    """
    Issue #12603. Test that we get the correct output from votable.validate with a valid
    votable.
    """
    # A valid votable. (Example from the votable standard:
    # https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html )
    valid_votable_filepath = get_pkg_data_filename("data/valid_votable.xml")

    # When output is None, check that validate returns validation output as a string
    validate_out = validate(valid_votable_filepath, output=None)
    assert isinstance(validate_out, str)
    # Check for known good output string
    assert "astropy.io.votable found no violations" in validate_out

    # When output is not set, check that validate returns a bool
    validate_out = validate(valid_votable_filepath)
    assert isinstance(validate_out, bool)
    # Check that validation output is correct (votable is valid)
    assert validate_out is True


def test_binary2_single_bounded_char_array():
    """
    Test that variable length char arrays with a max length
    (arraysize="128*") are read correctly in BINARY2 format.
    """
    votable = parse(get_pkg_data_filename("data/binary2_variable_length_char.xml"))
    table = votable.get_first_table()
    astropy_table = table.to_table()

    assert len(astropy_table) == 1
    assert (
        astropy_table[0]["access_format"]
        == "application/x-votable+xml;content=datalink"
    )

    output = io.BytesIO()
    astropy_table.write(output, format="votable", tabledata_format="binary2")
    output.seek(0)

    votable2 = parse(output)
    table2 = votable2.get_first_table()
    astropy_table2 = table2.to_table()

    assert len(astropy_table2) == 1
    assert (
        astropy_table2[0]["access_format"]
        == "application/x-votable+xml;content=datalink"
    )


def test_binary2_bounded_variable_length_char():
    """
    Test that max length variable length char arrays (arraysize="128*")
    are correctly serialized and deserialized correctly
    """
    votable = tree.VOTableFile()
    resource = tree.Resource()
    votable.resources.append(resource)
    table = tree.TableElement(votable)
    resource.tables.append(table)

    table.fields.append(
        tree.Field(
            votable,
            name="bounded_char",
            datatype="char",
            arraysize="128*",
    bio.seek(0)

    votable2 = parse(bio)
    table2 = votable2.get_first_table()

    assert table2.fields[7].arraysize == "7*"
    assert table2.fields[8].arraysize == "7*"

    assert table2.array[0]["CS"] == ""
    assert table2.array[4]["CS"] == ""


def test_char_bounds_validation():
    """
    Test that char converter correctly validates the bounds.
    """
    votable = tree.VOTableFile()
    field = tree.Field(
        votable, name="bounded_char", datatype="char", arraysize="2*", ID="bounded_char"
    )

    converter = get_converter(field)

    long_string = "abcdefgh"
    with pytest.warns(W46) as record:
        value, mask = converter.parse(long_string, {}, None)

    assert any("char" in str(w.message) and "2" in str(w.message) for w in record)

    if hasattr(converter, "_binoutput_var"):
        with pytest.warns(W46) as record:
            result = converter._binoutput_var(long_string, False)

        assert any("char" in str(w.message) and "2" in str(w.message) for w in record)


def test_binary2_bounded_char_warnings():
    """
    Test that appropriate warnings are issued when strings exceed
    the maximum length in bounded variable-length char arrays.
    """
    votable = tree.VOTableFile()
    resource = tree.Resource()
    votable.resources.append(resource)
    table = tree.TableElement(votable)
    resource.tables.append(table)

    table.fields.append(
        tree.Field(
            votable,
            name="bounded_char",
            datatype="char",
            arraysize="5*",
            ID="bounded_char",
        )
    )

    table.create_arrays(1)
    table.array[0]["bounded_char"] = "abcdefghijklmnopqrstu"

    bio = io.BytesIO()
    votable.version = "1.3"
    table._config = table._config or {}
    table._config["version_1_3_or_later"] = True
    table.format = "binary2"
    votable.to_xml(bio)
    bio.seek(0)

    votable2 = parse(bio)
    with pytest.warns(W46) as record:
        field = votable2.get_first_table().fields[0]
        value, mask = field.converter.parse("Too long value", {}, None)

    assert any("arraysize" in str(w.message) or "5" in str(w.message) for w in record)


def test_binary2_bounded_unichar_valid():
    """
    Test that variable length unicodeChars with a maximum length are correctly
    serialized and deserialized in BINARY2 format.
    """
    votable = tree.VOTableFile()
    resource = tree.Resource()
    votable.resources.append(resource)
    table = tree.TableElement(votable)
    resource.tables.append(table)

    table.fields.append(
        tree.Field(
            votable,
            name="bounded_unichar",
            datatype="unicodeChar",
            arraysize="10*",
            ID="bounded_unichar",
        )
    )

    table.create_arrays(3)
    table.array[0]["bounded_unichar"] = ""
    table.array[1]["bounded_unichar"] = "áéíóú"
    table.array[2]["bounded_unichar"] = "áéíóúÁÉÍÓ"

    for format_name in ["tabledata", "binary", "binary2"]:
        bio = io.BytesIO()

        if format_name == "binary2":
            votable.version = "1.3"
            table._config = table._config or {}
            table._config["version_1_3_or_later"] = True

        table.format = format_name
        votable.to_xml(bio)
        bio.seek(0)

        votable2 = parse(bio)
        table2 = votable2.get_first_table()

        assert table2.fields[0].arraysize == "10*", (
            f"Arraysize not preserved in {format_name} format"
        )

        assert table2.array[0]["bounded_unichar"] == "", (
            f"Empty string not preserved in {format_name} format"
        )
        assert table2.array[1]["bounded_unichar"] == "áéíóú", (
            f"Unicode string not preserved in {format_name} format"
        )
        assert table2.array[2]["bounded_unichar"] == "áéíóúÁÉÍÓ", (
            f"Full-length string not preserved in {format_name} format"
        )


def test_unichar_bounds_validation():
    """
    Test that unicodeChar converter correctly validates bounds and issues warnings.
    """
    votable = tree.VOTableFile()
    field = tree.Field(
        votable,
        name="bounded_unichar",
        datatype="unicodeChar",
        arraysize="5*",
        ID="bounded_unichar",
    )

    converter = get_converter(field)

    long_string = "áéíóúÁÉÍÓÚabcdefgh"
    with pytest.warns(W46) as record:
        value, mask = converter.parse(long_string, {}, None)

    assert any(
        "unicodeChar" in str(w.message) and "5" in str(w.message) for w in record
    )

    if hasattr(converter, "_binoutput_var"):
        with pytest.warns(W46) as record:
            result = converter._binoutput_var(long_string, False)

        assert any(
            "unicodeChar" in str(w.message) and "5" in str(w.message) for w in record
        )


def test_char_invalid_arraysize_raises_e01():
    """
    Test that an invalid arraysize for a char field raises E01.
    """

    class DummyField:
        name = "dummy"
        ID = "dummy_id"
        arraysize = "invalid*"

    field = DummyField()
    config = {}

    with pytest.raises(E01) as excinfo:
        Char(field, config)

    err_msg = str(excinfo.value)
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import pytest

from astropy.io.votable import ucd


def test_none():
    assert ucd.check_ucd(None)


examples = {
    "phys.temperature": [("ivoa", "phys.temperature")],
    "pos.eq.ra;meta.main": [("ivoa", "pos.eq.ra"), ("ivoa", "meta.main")],
    "meta.id;src": [("ivoa", "meta.id"), ("ivoa", "src")],
    "phot.flux;em.radio;arith.ratio": [
        ("ivoa", "phot.flux"),
        ("ivoa", "em.radio"),
        ("ivoa", "arith.ratio"),
    ],
    "PHot.Flux;EM.Radio;ivoa:arith.Ratio": [
        ("ivoa", "phot.flux"),
        ("ivoa", "em.radio"),
        ("ivoa", "arith.ratio"),
    ],
    "pos.galactic.lat": [("ivoa", "pos.galactic.lat")],
    "meta.code;phot.mag": [("ivoa", "meta.code"), ("ivoa", "phot.mag")],
    "stat.error;phot.mag": [("ivoa", "stat.error"), ("ivoa", "phot.mag")],
    "phys.temperature;instr;stat.max": [
        ("ivoa", "phys.temperature"),
        ("ivoa", "instr"),
        ("ivoa", "stat.max"),
    ],
    "stat.error;phot.mag;em.opt.V": [
        ("ivoa", "stat.error"),
        ("ivoa", "phot.mag"),
        ("ivoa", "em.opt.V"),
    ],
    "phot.color;em.opt.B;em.opt.V": [
        ("ivoa", "phot.color"),
        ("ivoa", "em.opt.B"),
        ("ivoa", "em.opt.V"),
    ],
    "stat.error;phot.color;em.opt.B;em.opt.V": [
        ("ivoa", "stat.error"),
        ("ivoa", "phot.color"),
        ("ivoa", "em.opt.B"),
        ("ivoa", "em.opt.V"),
    ],
}


def test_check():
    for s, p in examples.items():
        assert ucd.parse_ucd(s, True, True) == p
        assert ucd.check_ucd(s, True, True)


def test_too_many_colons():
    with pytest.raises(ValueError):
        ucd.parse_ucd("ivoa:stsci:phot", True, True)


def test_invalid_namespace():
    with pytest.raises(ValueError):
        ucd.parse_ucd("_ivoa:phot.mag", True, True)


def test_invalid_word():
    with pytest.raises(ValueError):
        ucd.parse_ucd("-pho")


def test_atmospheric_wind_ucd():
    """Test parsing of atmospheric observation UCDs, specifically obs.atmos.wind.

    This test addresses issue #18452 where obs.atmos.wind and other new
    atmospheric terms from UCD1+ version 1.6 should be recognized.
    """
    # Test the specific case from the issue report
    ucd_string = "phys.veloc;obs.atmos.wind;stat.mean"
    result = ucd.parse_ucd(ucd_string, check_controlled_vocabulary=True)
    expected = [
        ("ivoa", "phys.veloc"),
        ("ivoa", "obs.atmos.wind"),
        ("ivoa", "stat.mean"),
    ]
    assert result == expected

    # Test primary/quantified atmospheric terms (can be used standalone)
    primary_atmos_terms = [
        "obs.atmos.humidity",
        "obs.atmos.rain",
        "obs.atmos.turbulence.isoplanatic",
        "obs.atmos.water",
        "phys.temperature.dew",
    ]

    for term in primary_atmos_terms:
        result = ucd.parse_ucd(term, check_controlled_vocabulary=True)
        assert result == [("ivoa", term)]
        assert ucd.check_ucd(term, check_controlled_vocabulary=True)

    # Test secondary atmospheric terms (must be used with primary terms)
    secondary_atmos_terms = [
        "obs.atmos.wind",
        "obs.atmos.turbulence",
    ]

    for term in secondary_atmos_terms:
        # Test as secondary word (valid)
        combined_ucd = f"phys.temperature;{term}"
        result = ucd.parse_ucd(combined_ucd, check_controlled_vocabulary=True)
        expected = [("ivoa", "phys.temperature"), ("ivoa", term)]
        assert result == expected
        assert ucd.check_ucd(combined_ucd, check_controlled_vocabulary=True)
            [False, False, False, False, False, False, True],
        )

    def test_bit_array2(self):
        assert_array_equal(
            self.array["bitarray2"][0],
            [
                True,
                True,
                True,
                True,
                False,
                False,
                False,
                False,
                True,
                True,
                True,
                True,
                False,
                False,
                False,
                False,
            ],
        )

    def test_bit_array2_mask(self):
        assert not np.any(self.mask["bitarray2"][0])
        assert np.all(self.mask["bitarray2"][1:])

    def test_get_coosys_by_id(self):
        coosys = self.votable.get_coosys_by_id("J2000")
        assert coosys.system == "eq_FK5"

    def test_get_field_by_utype(self):
        fields = list(self.votable.get_fields_by_utype("myint"))
        assert fields[0].name == "int"
        assert fields[0].values.min == -1000

    def test_get_info_by_id(self):
        info = self.votable.get_info_by_id("QUERY_STATUS")
        assert info.value == "OK"

        if self.votable.version != "1.1":
            info = self.votable.get_info_by_id("ErrorInfo")
            assert info.value == "One might expect to find some INFO here, too..."

    def test_repr(self):
        assert "3 tables" in repr(self.votable)
        assert (
            repr(list(self.votable.iter_fields_and_params())[0])
            == '<PARAM ID="awesome" arraysize="*" datatype="float" '
            'name="INPUT" unit="deg" value="[0.0 0.0]"/>'
        )
        # Smoke test
        repr(list(self.votable.iter_groups()))

        # Resource
        assert repr(self.votable.resources) == "[</>]"

        # Table
        assert repr(self.table).startswith("<VOTable")


class TestThroughTableData(TestParse):
    def setup_class(self):
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            votable = parse(get_pkg_data_filename("data/regression.xml"))

        self.xmlout = bio = io.BytesIO()
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import io

import pytest

from astropy.utils.compat.optional_deps import HAS_BLEACH
from astropy.utils.xml import check, unescaper, writer


def test_writer():
    fh = io.StringIO()
    w = writer.XMLWriter(fh)
    with w.tag("html"):
        with w.tag("body"):
            w.data("This is the content")
            w.comment("comment")

    value = "".join(fh.getvalue().split())
    assert value == "<html><body>Thisisthecontent<!--comment--></body></html>"


def test_check_id():
    assert check.check_id("Fof32")
    assert check.check_id("_Fof32")
    assert not check.check_id("32Fof")


def test_fix_id():
    assert check.fix_id("Fof32") == "Fof32"
    assert check.fix_id("@#f") == "___f"


def test_check_token():
    assert check.check_token("token")
    assert not check.check_token("token\rtoken")


def test_check_mime_content_type():
    assert check.check_mime_content_type("image/jpeg")
    assert not check.check_mime_content_type("image")


def test_check_anyuri():
    assert check.check_anyuri("https://github.com/astropy/astropy")


def test_unescape_all():
    # str
    url_in = (
        "http://casu.ast.cam.ac.uk/ag/iphas-dsa%2FSubmitCone?"
        "DSACAT=IDR&amp;amp;DSATAB=Emitters&amp;amp;"
    )
    url_out = (
        "http://casu.ast.cam.ac.uk/ag/iphas-dsa/SubmitCone?DSACAT=IDR&DSATAB=Emitters&"
    )
    assert unescaper.unescape_all(url_in) == url_out

    # bytes
    url_in = (
        b"http://casu.ast.cam.ac.uk/ag/iphas-dsa%2FSubmitCone?"
        b"DSACAT=IDR&amp;amp;DSATAB=Emitters&amp;amp;"
    )
    url_out = (
        b"http://casu.ast.cam.ac.uk/ag/iphas-dsa/SubmitCone?DSACAT=IDR&DSATAB=Emitters&"
    )
    assert unescaper.unescape_all(url_in) == url_out


def test_escape_xml():
    s = writer.xml_escape("This & That")
    assert type(s) == str
    assert s == "This &amp; That"

    s = writer.xml_escape(1)
    assert type(s) == str
    assert s == "1"

    s = writer.xml_escape(b"This & That")
    assert type(s) == bytes
```

## 原始行 35 · command_execution

命令：
```
/bin/bash -lc "grep -n -B 8 -A 35 -E \"to_table\\(|meta\\[|\\.meta|description|use_names_over_ids\" astropy/io/votable/tests/test_table.py | head -n 500; grep -R -n \"is_defaults\" astropy --include='*.py'; grep -R -n \"_parse_minmax\" astropy --include='*.py'; grep -R -n \"check_string(\" astropy/io/votable --include='*.py'"
```

退出码：`0`

输出：
```
59-
60-
61-def test_table(tmp_path):
62-    # Read the VOTABLE
63-    with np.errstate(over="ignore"):
64-        # https://github.com/astropy/astropy/issues/13341
65-        votable = parse(get_pkg_data_filename("data/regression.xml"))
66-    table = votable.get_first_table()
67:    astropy_table = table.to_table()
68-
69-    for name in table.array.dtype.names:
70-        assert np.all(astropy_table.mask[name] == table.array.mask[name])
71-
72-    votable2 = tree.VOTableFile.from_table(astropy_table)
73-    t = votable2.get_first_table()
74-
75-    field_types = [
76-        ("string_test", {"datatype": "char", "arraysize": "*"}),
77-        ("string_test_2", {"datatype": "char", "arraysize": "10"}),
78-        ("unicode_test", {"datatype": "unicodeChar", "arraysize": "*"}),
79-        ("fixed_unicode_test", {"datatype": "unicodeChar", "arraysize": "10"}),
80-        ("string_array_test", {"datatype": "char", "arraysize": "4*"}),
81-        ("unsignedByte", {"datatype": "unsignedByte"}),
82-        ("short", {"datatype": "short"}),
83-        ("int", {"datatype": "int"}),
84-        ("intNoNull", {"datatype": "int"}),
85-        ("long", {"datatype": "long"}),
86-        ("double", {"datatype": "double"}),
87-        ("float", {"datatype": "float"}),
88-        ("array", {"datatype": "long", "arraysize": "2*"}),
89-        ("bit", {"datatype": "bit"}),
90-        ("bitarray", {"datatype": "bit", "arraysize": "3x2"}),
91-        ("bitvararray", {"datatype": "bit", "arraysize": "*"}),
92-        ("bitvararray2", {"datatype": "bit", "arraysize": "3x2*"}),
93-        ("floatComplex", {"datatype": "floatComplex"}),
94-        ("doubleComplex", {"datatype": "doubleComplex"}),
95-        ("doubleComplexArray", {"datatype": "doubleComplex", "arraysize": "*"}),
96-        ("doubleComplexArrayFixed", {"datatype": "doubleComplex", "arraysize": "2"}),
97-        ("boolean", {"datatype": "bit"}),
98-        ("booleanArray", {"datatype": "bit", "arraysize": "4"}),
99-        ("nulls", {"datatype": "int"}),
100-        ("nulls_array", {"datatype": "int", "arraysize": "2x2"}),
101-        ("precision1", {"datatype": "double"}),
102-        ("precision2", {"datatype": "double"}),
--
164-    t = Table.read(filename, format="votable", unit_format="generic")
165-    assert t["Flux1"].unit == u.Unit("erg / (Angstrom cm2 s)")
166-
167-
168-def test_names_over_ids():
169-    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
170-        votable = parse(fd)
171-
172:    table = votable.get_first_table().to_table(use_names_over_ids=True)
173-
174-    assert table.colnames == [
175-        "Name",
176-        "GLON",
177-        "GLAT",
178-        "RAdeg",
179-        "DEdeg",
180-        "Jmag",
181-        "Hmag",
182-        "Kmag",
183-        "G3.6mag",
184-        "G4.5mag",
185-        "G5.8mag",
186-        "G8.0mag",
187-        "4.5mag",
188-        "8.0mag",
189-        "Emag",
190-        "24mag",
191-        "f_Name",
192-    ]
193-
194-
195-def test_explicit_ids():
196-    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
197-        votable = parse(fd)
198-
199:    table = votable.get_first_table().to_table(use_names_over_ids=False)
200-
201-    assert table.colnames == [
202-        "col1",
203-        "col2",
204-        "col3",
205-        "col4",
206-        "col5",
207-        "col6",
208-        "col7",
209-        "col8",
210-        "col9",
211-        "col10",
212-        "col11",
213-        "col12",
214-        "col13",
215-        "col14",
216-        "col15",
217-        "col16",
218-        "col17",
219-    ]
220-
221-
222-def test_table_read_with_unnamed_tables():
223-    """
224-    Issue #927.
225-    """
226-    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
227-        t = Table.read(fd, format="votable")
228-
229-    assert len(t) == 1
230-
231-
232-def test_votable_path_object():
233-    """
234-    Testing when votable is passed as pathlib.Path object #4412.
235-    """
236-    fpath = pathlib.Path(get_pkg_data_filename("data/names.xml"))
237:    table = parse(fpath).get_first_table().to_table()
238-
239-    assert len(table) == 1
240-    assert int(table[0][3]) == 266
241-
242-
243-def test_from_table_without_mask():
244-    t = Table()
245-    c = Column(data=[1, 2, 3], name="a")
246-    t.add_column(c)
247-    output = io.BytesIO()
248-    t.write(output, format="votable")
249-
250-
251-def test_write_with_format():
252-    t = Table()
253-    c = Column(data=[1, 2, 3], name="a")
254-    t.add_column(c)
255-
256-    output = io.BytesIO()
257-    t.write(output, format="votable", tabledata_format="binary")
258-    obuff = output.getvalue()
259-    assert b'VOTABLE version="1.4"' in obuff
260-    assert b"BINARY" in obuff
261-    assert b"TABLEDATA" not in obuff
262-
263-    output = io.BytesIO()
264-    t.write(output, format="votable", tabledata_format="binary2")
265-    obuff = output.getvalue()
266-    assert b'VOTABLE version="1.4"' in obuff
267-    assert b"BINARY2" in obuff
268-    assert b"TABLEDATA" not in obuff
269-
270-
271-@pytest.mark.skipif(not HAS_PYARROW, reason="requires pyarrow")
272-@pytest.mark.parametrize("overwrite", [True, False])
--
440-    assert 'VOTABLE version="1.4"' in obuff
441-    assert "BINARY" not in obuff
442-    assert "TABLEDATA" in obuff
443-
444-
445-def test_empty_table():
446-    votable = parse(get_pkg_data_filename("data/empty_table.xml"))
447-    table = votable.get_first_table()
448:    table.to_table()
449-
450-
451-def test_no_field_not_empty_table():
452-    votable = parse(get_pkg_data_filename("data/no_field_not_empty_table.xml"))
453-    table = votable.get_first_table()
454-    assert len(table.fields) == 0
455-    assert len(table.infos) == 1
456-
457-
458-def test_no_field_not_empty_table_exception():
459-    with pytest.raises(E25):
460-        parse(
461-            get_pkg_data_filename("data/no_field_not_empty_table.xml"),
462-            verify="exception",
463-        )
464-
465-
466-def test_binary2_masked_strings():
467-    """
468-    Issue #8995.
469-    """
470-    # Read a VOTable which sets the null mask bit for each empty string value.
471-    votable = parse(get_pkg_data_filename("data/binary2_masked_strings.xml"))
472-    table = votable.get_first_table()
473:    astropy_table = table.to_table()
474-
475-    # Ensure string columns have no masked values and can be written out
476-    assert not np.any(table.array.mask["epoch_photometry_url"])
477-    output = io.BytesIO()
478-    astropy_table.write(output, format="votable")
479-
480-
481-def test_validate_output_invalid():
482-    """
483-    Issue #12603. Test that we get the correct output from votable.validate with an invalid
484-    votable.
485-    """
486-    # A votable with errors
487-    invalid_votable_filepath = get_pkg_data_filename("data/regression.xml")
488-
489-    # When output is None, check that validate returns validation output as a string
490-    validate_out = validate(invalid_votable_filepath, output=None)
491-    assert isinstance(validate_out, str)
492-    # Check for known error string
493-    assert "E02: Incorrect number of elements in array." in validate_out
494-
495-    # When output is not set, check that validate returns a bool
496-    validate_out = validate(invalid_votable_filepath)
497-    assert isinstance(validate_out, bool)
498-    # Check that validation output is correct (votable is not valid)
499-    assert validate_out is False
500-
501-
502-def test_validate_output_valid():
503-    """
504-    Issue #12603. Test that we get the correct output from votable.validate with a valid
505-    votable.
506-    """
507-    # A valid votable. (Example from the votable standard:
508-    # https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html )
--
523-
524-def test_binary2_single_bounded_char_array():
525-    """
526-    Test that variable length char arrays with a max length
527-    (arraysize="128*") are read correctly in BINARY2 format.
528-    """
529-    votable = parse(get_pkg_data_filename("data/binary2_variable_length_char.xml"))
530-    table = votable.get_first_table()
531:    astropy_table = table.to_table()
532-
533-    assert len(astropy_table) == 1
534-    assert (
535-        astropy_table[0]["access_format"]
536-        == "application/x-votable+xml;content=datalink"
537-    )
538-
539-    output = io.BytesIO()
540-    astropy_table.write(output, format="votable", tabledata_format="binary2")
541-    output.seek(0)
542-
543-    votable2 = parse(output)
544-    table2 = votable2.get_first_table()
545:    astropy_table2 = table2.to_table()
546-
547-    assert len(astropy_table2) == 1
548-    assert (
549-        astropy_table2[0]["access_format"]
550-        == "application/x-votable+xml;content=datalink"
551-    )
552-
553-
554-def test_binary2_bounded_variable_length_char():
555-    """
556-    Test that max length variable length char arrays (arraysize="128*")
557-    are correctly serialized and deserialized correctly
558-    """
559-    votable = tree.VOTableFile()
560-    resource = tree.Resource()
561-    votable.resources.append(resource)
562-    table = tree.TableElement(votable)
563-    resource.tables.append(table)
564-
565-    table.fields.append(
566-        tree.Field(
567-            votable,
568-            name="bounded_char",
569-            datatype="char",
570-            arraysize="128*",
571-            ID="bounded_char",
572-        )
573-    )
574-
575-    table.create_arrays(2)
576-    table.array[0]["bounded_char"] = "Short string"
577-    table.array[1]["bounded_char"] = "Longer string that still fits the 128 characters"
578-
579-    for format_name in ["tabledata", "binary", "binary2"]:
580-        bio = io.BytesIO()
astropy/io/votable/tree.py:1242:        if self.is_defaults():
astropy/io/votable/tree.py:1714:            if not self.values.is_defaults():
astropy/io/votable/tree.py:1084:        self._min = self._parse_minmax(min)
astropy/io/votable/tree.py:1117:        self._max = self._parse_minmax(max)
astropy/io/votable/tests/test_tree.py:37:        tree.check_string(42, "foo", config)
astropy/io/votable/tree.py:434:        check_string(xtype, "xtype", self._config, self._pos)
astropy/io/votable/tree.py:460:        check_string(utype, "utype", self._config, self._pos)
astropy/io/votable/tree.py:636:        check_string(content, "content", self._config, self._pos)
astropy/io/votable/tree.py:857:        check_string(value, "value", self._config, self._pos)
astropy/io/votable/tree.py:867:        check_string(content, "content", self._config, self._pos)
```

## 原始行 38 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '700,820p'; nl -ba astropy/io/votable/tree.py | sed -n '1220,1330p'; nl -ba astropy/io/votable/tree.py | sed -n '3200,3650p'; grep -n -E \"def iter_fields_and_params|def iter_groups|to_table =|get_field_by_id|get_group_by_id\" astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
   700	            pos,
   701	            ["content-role", "content_role", "content-type", "content_type", "gref"],
   702	        )
   703	
   704	    @property
   705	    def content_role(self):
   706	        """Defines the MIME role of the referenced object.
   707	
   708	        Must be one of:
   709	
   710	          None, 'query', 'hints', 'doc', 'location' or 'type'
   711	        """
   712	        return self._content_role
   713	
   714	    @content_role.setter
   715	    def content_role(self, content_role):
   716	        if (
   717	            content_role == "type" and not self._config.get("version_1_3_or_later")
   718	        ) or content_role not in (None, "query", "hints", "doc", "location"):
   719	            vo_warn(W45, (content_role,), self._config, self._pos)
   720	        self._content_role = content_role
   721	
   722	    @content_role.deleter
   723	    def content_role(self):
   724	        self._content_role = None
   725	
   726	    @property
   727	    def content_type(self):
   728	        """Defines the MIME content type of the referenced object."""
   729	        return self._content_type
   730	
   731	    @content_type.setter
   732	    def content_type(self, content_type):
   733	        xmlutil.check_mime_content_type(content_type, self._config, self._pos)
   734	        self._content_type = content_type
   735	
   736	    @content_type.deleter
   737	    def content_type(self):
   738	        self._content_type = None
   739	
   740	    @property
   741	    def href(self):
   742	        """
   743	        A URI to an arbitrary protocol.  The vo package only supports
   744	        http and anonymous ftp.
   745	        """
   746	        return self._href
   747	
   748	    @href.setter
   749	    def href(self, href):
   750	        xmlutil.check_anyuri(href, self._config, self._pos)
   751	        self._href = href
   752	
   753	    @href.deleter
   754	    def href(self):
   755	        self._href = None
   756	
   757	    def to_table_column(self, column):
   758	        meta = {}
   759	        for key in self._attr_list:
   760	            val = getattr(self, key, None)
   761	            if val is not None:
   762	                meta[key] = val
   763	
   764	        column.meta.setdefault("links", [])
   765	        column.meta["links"].append(meta)
   766	
   767	    @classmethod
   768	    def from_table_column(cls, d):
   769	        return cls(**d)
   770	
   771	
   772	class Info(SimpleElementWithContent, _IDProperty, _XtypeProperty, _UtypeProperty):
   773	    """
   774	    INFO_ elements: arbitrary key-value pairs for extensions to the standard.
   775	
   776	    The keyword arguments correspond to setting members of the same
   777	    name, documented below.
   778	    """
   779	
   780	    _element_name = "INFO"
   781	    _attr_list_11 = ["ID", "name", "value"]
   782	    _attr_list_12 = _attr_list_11 + ["xtype", "ref", "unit", "ucd", "utype"]
   783	    _utype_in_v1_2 = True
   784	
   785	    def __init__(
   786	        self,
   787	        ID=None,
   788	        name=None,
   789	        value=None,
   790	        id=None,
   791	        xtype=None,
   792	        ref=None,
   793	        unit=None,
   794	        ucd=None,
   795	        utype=None,
   796	        config=None,
   797	        pos=None,
   798	        **extra,
   799	    ):
   800	        if config is None:
   801	            config = {}
   802	        self._config = config
   803	        self._pos = pos
   804	
   805	        SimpleElementWithContent.__init__(self)
   806	
   807	        self.ID = resolve_id(ID, id, config, pos) or xmlutil.fix_id(name, config, pos)
   808	        self.name = name
   809	        self.value = value
   810	        self.xtype = xtype
   811	        self.ref = ref
   812	        self.unit = unit
   813	        self.ucd = ucd
   814	        self.utype = utype
   815	
   816	        if config.get("version_1_2_or_later"):
   817	            self._attr_list = self._attr_list_12
   818	        else:
   819	            self._attr_list = self._attr_list_11
   820	            if xtype is not None:
  1220	
  1221	
  1222	
  1223	
  1224	
  1225	
  1226	
  1227	
  1228	
  1229	
  1230	
  1231	
  1232	
  1233	
  1234	
  1235	
  1236	    def to_xml(self, w, **kwargs):
  1237	        def yes_no(value):
  1238	            if value:
  1239	                return "yes"
  1240	            return "no"
  1241	
  1242	        if self.is_defaults():
  1243	            return
  1244	
  1245	        if self.ref is not None:
  1246	            w.element("VALUES", attrib=w.object_attrs(self, ["ref"]))
  1247	        else:
  1248	            with w.tag("VALUES", attrib=w.object_attrs(self, ["ID", "null", "ref"])):
  1249	                if self.min is not None:
  1250	                    w.element(
  1251	                        "MIN",
  1252	                        value=self._field.converter.output(self.min, False),
  1253	                        inclusive=yes_no(self.min_inclusive),
  1254	                    )
  1255	                if self.max is not None:
  1256	                    w.element(
  1257	                        "MAX",
  1258	                        value=self._field.converter.output(self.max, False),
  1259	                        inclusive=yes_no(self.max_inclusive),
  1260	                    )
  1261	                for name, value in self.options:
  1262	                    w.element("OPTION", name=name, value=value)
  1263	
  1264	    def to_table_column(self, column):
  1265	        # Have the ref filled in here
  1266	        meta = {}
  1267	        for key in ["ID", "null"]:
  1268	            val = getattr(self, key, None)
  1269	            if val is not None:
  1270	                meta[key] = val
  1271	        if self.min is not None:
  1272	            meta["min"] = {"value": self.min, "inclusive": self.min_inclusive}
  1273	        if self.max is not None:
  1274	            meta["max"] = {"value": self.max, "inclusive": self.max_inclusive}
  1275	        if len(self.options):
  1276	            meta["options"] = dict(self.options)
  1277	
  1278	        column.meta["values"] = meta
  1279	
  1280	    def from_table_column(self, column):
  1281	        if column.info.meta is None or "values" not in column.info.meta:
  1282	            return
  1283	
  1284	        meta = column.info.meta["values"]
  1285	        for key in ["ID", "null"]:
  1286	            val = meta.get(key, None)
  1287	            if val is not None:
  1288	                setattr(self, key, val)
  1289	        if "min" in meta:
  1290	            self.min = meta["min"]["value"]
  1291	            self.min_inclusive = meta["min"]["inclusive"]
  1292	        if "max" in meta:
  1293	            self.max = meta["max"]["value"]
  1294	            self.max_inclusive = meta["max"]["inclusive"]
  1295	        if "options" in meta:
  1296	            self._options = list(meta["options"].items())
  1297	
  1298	
  1299	class Field(
  1300	    SimpleElement,
  1301	    _IDProperty,
  1302	    _NameProperty,
  1303	    _XtypeProperty,
  1304	    _UtypeProperty,
  1305	    _UcdProperty,
  1306	):
  1307	    """
  1308	    FIELD_ element: describes the datatype of a particular column of data.
  1309	
  1310	    The keyword arguments correspond to setting members of the same
  1311	    name, documented below.
  1312	
  1313	    If *ID* is provided, it is used for the column name in the
  1314	    resulting recarray of the table.  If no *ID* is provided, *name*
  1315	    is used instead.  If neither is provided, an exception will be
  1316	    raised.
  1317	    """
  1318	
  1319	    _attr_list_11 = [
  1320	        "ID",
  1321	        "name",
  1322	        "datatype",
  1323	        "arraysize",
  1324	        "ucd",
  1325	        "unit",
  1326	        "width",
  1327	        "precision",
  1328	        "utype",
  1329	        "ref",
  1330	    ]
  3200	
  3201	                for i, binparse in enumerate(binparsers):
  3202	                    try:
  3203	                        value, value_mask = binparse(careful_read)
  3204	                    except EOFError:
  3205	                        raise
  3206	                    except Exception as e:
  3207	                        vo_reraise(
  3208	                            e,
  3209	                            config,
  3210	                            pos,
  3211	                            f"(in row {numrows:d}, col '{fields[i].ID}')",
  3212	                        )
  3213	                    row_data.append(value)
  3214	                    if mode == 1:
  3215	                        row_mask_data.append(value_mask)
  3216	                    else:
  3217	                        row_mask_data[i] = row_mask_data[i] or value_mask
  3218	            except EOFError:
  3219	                break
  3220	
  3221	            row = [x.converter.default for x in self.fields]
  3222	            row_mask = [False] * len(self.fields)
  3223	            for j, i in enumerate(colnumbers):
  3224	                row[j] = row_data[i]
  3225	                row_mask[j] = row_mask_data[i]
  3226	
  3227	            array[numrows] = tuple(row)
  3228	            array.mask[numrows] = tuple(row_mask)
  3229	            numrows += 1
  3230	
  3231	        return _resize(array, numrows)
  3232	
  3233	    def _parse_fits(self, iterator, extnum, config):
  3234	        for start, tag, data, pos in iterator:
  3235	            if tag == "STREAM":
  3236	                if start:
  3237	                    warn_unknown_attrs(
  3238	                        "STREAM",
  3239	                        data.keys(),
  3240	                        config,
  3241	                        pos,
  3242	                        ["type", "href", "actuate", "encoding", "expires", "rights"],
  3243	                    )
  3244	                    href = data["href"]
  3245	                    encoding = data.get("encoding", None)
  3246	                else:
  3247	                    break
  3248	
  3249	        if not href.startswith(("http", "ftp", "file")):
  3250	            vo_raise(
  3251	                NotImplementedError,
  3252	                "The vo package only supports remote data through http, ftp or file",
  3253	                self._config,
  3254	                self._pos,
  3255	            )
  3256	
  3257	        fd = urllib.request.urlopen(href)
  3258	        if encoding is not None:
  3259	            if encoding == "gzip":
  3260	                fd = gzip.GzipFile(href, "r", fileobj=fd)
  3261	            elif encoding == "base64":
  3262	                fd = codecs.EncodedFile(fd, "base64")
  3263	            else:
  3264	                vo_raise(
  3265	                    NotImplementedError,
  3266	                    f"Unknown encoding type '{encoding}'",
  3267	                    self._config,
  3268	                    self._pos,
  3269	                )
  3270	        hdulist = fits.open(fd)
  3271	
  3272	        array = hdulist[int(extnum)].data
  3273	        if array.dtype != self.array.dtype:
  3274	            warn_or_raise(W19, W19, (), self._config, self._pos)
  3275	
  3276	        return array
  3277	
  3278	    def _parse_parquet(self, iterator, config):
  3279	        """
  3280	        Functionality to parse parquet files that are embedded
  3281	        in VOTables.
  3282	        """
  3283	        from astropy.table import Table
  3284	
  3285	        for start, tag, data, pos in iterator:
  3286	            if tag == "STREAM":
  3287	                if start:
  3288	                    warn_unknown_attrs(
  3289	                        "STREAM",
  3290	                        data.keys(),
  3291	                        config,
  3292	                        pos,
  3293	                        ["type", "href", "actuate", "encoding", "expires", "rights"],
  3294	                    )
  3295	                    href = data["href"]
  3296	                    encoding = data.get("encoding", None)
  3297	                else:
  3298	                    break
  3299	
  3300	            else:  # in this case, there is no STREAM, hence no file linked.
  3301	                href = ""
  3302	
  3303	        if not href.startswith(("http", "ftp", "file")):
  3304	            vo_raise(
  3305	                NotImplementedError,
  3306	                "The vo package only supports remote data through http, ftp or file",
  3307	                self._config,
  3308	                self._pos,
  3309	            )
  3310	
  3311	        try:
  3312	            # Hack to keep windows working
  3313	            try:
  3314	                fd = urllib.request.urlopen(href)
  3315	            except urllib.error.URLError:
  3316	                # Hack to keep windows working
  3317	                if href.startswith("file://"):
  3318	                    fd = urllib.request.urlopen(f"file:{href[7:]}")
  3319	                # Relative path to parquet part should be relative from the votable
  3320	                elif href.startswith("file:"):
  3321	                    parquet = os.path.join(
  3322	                        os.path.dirname(config["filename"]), href[5:]
  3323	                    )
  3324	                    fd = urllib.request.urlopen(f"file:{parquet}")
  3325	
  3326	            if encoding is not None:
  3327	                if encoding == "gzip":
  3328	                    fd = gzip.GzipFile(href, "r", fileobj=fd)
  3329	                elif encoding == "base64":
  3330	                    fd = codecs.EncodedFile(fd, "base64")
  3331	                else:
  3332	                    vo_raise(
  3333	                        NotImplementedError,
  3334	                        f"Unknown encoding type '{encoding}'",
  3335	                        self._config,
  3336	                        self._pos,
  3337	                    )
  3338	
  3339	            array = Table.read(fd, format="parquet")
  3340	        finally:
  3341	            if hasattr(fd, "close"):
  3342	                fd.close()
  3343	
  3344	        if array.dtype != self.array.dtype:
  3345	            warn_or_raise(W56, W56, (), self._config, self._pos)
  3346	
  3347	        return array
  3348	
  3349	    def to_xml(self, w, **kwargs):
  3350	        specified_format = kwargs.get("tabledata_format")
  3351	        if specified_format is not None:
  3352	            format = specified_format
  3353	        else:
  3354	            format = self.format
  3355	        if format == "fits":
  3356	            format = "tabledata"
  3357	
  3358	        with w.tag(
  3359	            "TABLE",
  3360	            attrib=w.object_attrs(self, ("ID", "name", "ref", "ucd", "utype", "nrows")),
  3361	        ):
  3362	            if self.description is not None:
  3363	                w.element("DESCRIPTION", self.description, wrap=True)
  3364	
  3365	            for element_set in (self.fields, self.params):
  3366	                for element in element_set:
  3367	                    element._setup({}, None)
  3368	
  3369	            if self.ref is None:
  3370	                for element_set in (self.fields, self.params, self.groups, self.links):
  3371	                    for element in element_set:
  3372	                        element.to_xml(w, **kwargs)
  3373	            elif kwargs["version_1_2_or_later"]:
  3374	                index = list(self._votable.iter_tables()).index(self)
  3375	                group = Group(self, ID=f"_g{index}")
  3376	                group.to_xml(w, **kwargs)
  3377	
  3378	            if len(self.array):
  3379	                with w.tag("DATA"):
  3380	                    if format == "tabledata":
  3381	                        self._write_tabledata(w, **kwargs)
  3382	                    elif format == "binary":
  3383	                        self._write_binary(1, w, **kwargs)
  3384	                    elif format == "binary2":
  3385	                        self._write_binary(2, w, **kwargs)
  3386	
  3387	            if kwargs["version_1_2_or_later"]:
  3388	                for element in self._infos:
  3389	                    element.to_xml(w, **kwargs)
  3390	
  3391	    def _write_tabledata(self, w, **kwargs):
  3392	        fields = self.fields
  3393	        array = self.array
  3394	
  3395	        with w.tag("TABLEDATA"):
  3396	            w._flush()
  3397	            if _has_c_tabledata_writer and not kwargs.get("_debug_python_based_parser"):
  3398	                supports_empty_values = [
  3399	                    field.converter.supports_empty_values(kwargs) for field in fields
  3400	                ]
  3401	                fields = [field.converter.output for field in fields]
  3402	                indent = len(w._tags) - 1
  3403	                tablewriter.write_tabledata(
  3404	                    w.write,
  3405	                    array.data,
  3406	                    array.mask,
  3407	                    fields,
  3408	                    supports_empty_values,
  3409	                    indent,
  3410	                    1 << 8,
  3411	                )
  3412	            else:
  3413	                write = w.write
  3414	                indent_spaces = w.get_indentation_spaces()
  3415	                tr_start = indent_spaces + "<TR>\n"
  3416	                tr_end = indent_spaces + "</TR>\n"
  3417	                td = indent_spaces + " <TD>{}</TD>\n"
  3418	                td_empty = indent_spaces + " <TD/>\n"
  3419	                fields = [
  3420	                    (
  3421	                        i,
  3422	                        field.converter.output,
  3423	                        field.converter.supports_empty_values(kwargs),
  3424	                    )
  3425	                    for i, field in enumerate(fields)
  3426	                ]
  3427	                for row in range(len(array)):
  3428	                    write(tr_start)
  3429	                    array_row = array.data[row]
  3430	                    mask_row = array.mask[row]
  3431	                    for i, output, supports_empty_values in fields:
  3432	                        data = array_row[i]
  3433	                        masked = mask_row[i]
  3434	                        if supports_empty_values and np.all(masked):
  3435	                            write(td_empty)
  3436	                        else:
  3437	                            try:
  3438	                                val = output(data, masked)
  3439	                            except Exception as e:
  3440	                                vo_reraise(
  3441	                                    e,
  3442	                                    additional=(
  3443	                                        f"(in row {row:d}, col '{self.fields[i].ID}')"
  3444	                                    ),
  3445	                                )
  3446	                            if len(val):
  3447	                                write(td.format(val))
  3448	                            else:
  3449	                                write(td_empty)
  3450	                    write(tr_end)
  3451	
  3452	    def _write_binary(self, mode, w, **kwargs):
  3453	        fields = self.fields
  3454	        array = self.array
  3455	        if mode == 1:
  3456	            tag_name = "BINARY"
  3457	        else:
  3458	            tag_name = "BINARY2"
  3459	
  3460	        with w.tag(tag_name):
  3461	            with w.tag("STREAM", encoding="base64"):
  3462	                fields_basic = [
  3463	                    (i, field.converter.binoutput) for (i, field) in enumerate(fields)
  3464	                ]
  3465	
  3466	                data = io.BytesIO()
  3467	                for row in range(len(array)):
  3468	                    array_row = array.data[row]
  3469	                    array_mask = array.mask[row]
  3470	                    if mode == 2:
  3471	                        flattened = np.array([np.all(x) for x in array_mask])
  3472	                        data.write(converters.bool_to_bitarray(flattened))
  3473	
  3474	                    for i, converter in fields_basic:
  3475	                        try:
  3476	                            # BINARY2 cannot handle individual array element masks
  3477	                            converter_type = converter.__self__.__class__
  3478	                            # Delegate converter to handle the mask
  3479	                            delegate_condition = issubclass(
  3480	                                converter_type, converters.Array
  3481	                            )
  3482	                            if mode == 1 or delegate_condition:
  3483	                                chunk = converter(array_row[i], array_mask[i])
  3484	                            else:
  3485	                                # Mask is already handled by BINARY2 behaviour
  3486	                                chunk = converter(array_row[i], None)
  3487	                            assert type(chunk) == bytes
  3488	                        except Exception as e:
  3489	                            vo_reraise(
  3490	                                e, additional=f"(in row {row:d}, col '{fields[i].ID}')"
  3491	                            )
  3492	                        data.write(chunk)
  3493	
  3494	                w._flush()
  3495	                w.write(base64.b64encode(data.getvalue()).decode("ascii"))
  3496	
  3497	
  3498	
  3499	
  3500	
  3501	
  3502	
  3503	
  3504	
  3505	
  3506	
  3507	
  3508	
  3509	
  3510	
  3511	
  3512	
  3513	
  3514	
  3515	
  3516	
  3517	
  3518	
  3519	
  3520	
  3521	
  3522	
  3523	
  3524	
  3525	
  3526	
  3527	
  3528	
  3529	
  3530	
  3531	
  3532	
  3533	
  3534	
  3535	
  3536	
  3537	
  3538	
  3539	
  3540	
  3541	
  3542	
  3543	
  3544	
  3545	
  3546	    @classmethod
  3547	    def from_table(cls, votable, table):
  3548	        """
  3549	        Create a `TableElement` instance from a given `astropy.table.Table`
  3550	        instance.
  3551	        """
  3552	        kwargs = {}
  3553	        for key in ["ID", "name", "ref", "ucd", "utype"]:
  3554	            val = table.meta.get(key)
  3555	            if val is not None:
  3556	                kwargs[key] = val
  3557	        new_table = cls(votable, **kwargs)
  3558	        if "description" in table.meta:
  3559	            new_table.description = table.meta["description"]
  3560	
  3561	        for colname in table.colnames:
  3562	            column = table[colname]
  3563	            new_table.add_field(Field.from_table_column(votable, column))
  3564	
  3565	        if table.mask is None:
  3566	            new_table.array = ma.array(np.asarray(table))
  3567	        else:
  3568	            new_table.array = ma.array(np.asarray(table), mask=np.asarray(table.mask))
  3569	
  3570	        return new_table
  3571	
  3572	    def iter_fields_and_params(self):
  3573	        """
  3574	        Recursively iterate over all FIELD and PARAM elements in the
  3575	        TABLE.
  3576	        """
  3577	        yield from self.params
  3578	        yield from self.all_fields
  3579	        for group in self.groups:
  3580	            yield from group.iter_fields_and_params()
  3581	
  3582	    get_field_by_id = _lookup_by_attr_factory(
  3583	        "ID",
  3584	        True,
  3585	        "iter_fields_and_params",
  3586	        "FIELD or PARAM",
  3587	        """
  3588	        Looks up a FIELD or PARAM element by the given ID.
  3589	        """,
  3590	    )
  3591	
  3592	    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
  3593	        "iter_fields_and_params",
  3594	        "FIELD or PARAM",
  3595	        """
  3596	        Looks up a FIELD or PARAM element by the given ID or name.
  3597	        """,
  3598	    )
  3599	
  3600	    get_fields_by_utype = _lookup_by_attr_factory(
  3601	        "utype",
  3602	        False,
  3603	        "iter_fields_and_params",
  3604	        "FIELD or PARAM",
  3605	        """
  3606	        Looks up a FIELD or PARAM element by the given utype and
  3607	        returns an iterator emitting all matches.
  3608	        """,
  3609	    )
  3610	
  3611	    def iter_groups(self):
  3612	        """
  3613	        Recursively iterate over all GROUP elements in the TABLE.
  3614	        """
  3615	        for group in self.groups:
  3616	            yield group
  3617	            yield from group.iter_groups()
  3618	
  3619	    get_group_by_id = _lookup_by_attr_factory(
  3620	        "ID",
  3621	        True,
  3622	        "iter_groups",
  3623	        "GROUP",
  3624	        """
  3625	        Looks up a GROUP element by the given ID.  Used by the group's
  3626	        "ref" attribute
  3627	        """,
  3628	    )
  3629	
  3630	    get_groups_by_utype = _lookup_by_attr_factory(
  3631	        "utype",
  3632	        False,
  3633	        "iter_groups",
  3634	        "GROUP",
  3635	        """
  3636	        Looks up a GROUP element by the given utype and returns an
  3637	        iterator emitting all matches.
  3638	        """,
  3639	    )
  3640	
  3641	    def iter_info(self):
  3642	        yield from self.infos
  3643	
  3644	
  3645	class MivotBlock(Element):
  3646	    """
  3647	    MIVOT Block holder:
  3648	    Processing VO model views on data is out of the scope of Astropy.
  3649	    This is why the only VOmodel-related feature implemented here the
  3650	    extraction or the writing of a mapping block from/to a VOTable
2456:    def iter_fields_and_params(self):
2467:    def iter_groups(self):
3572:    def iter_fields_and_params(self):
3582:    get_field_by_id = _lookup_by_attr_factory(
3592:    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
3611:    def iter_groups(self):
3619:    get_group_by_id = _lookup_by_attr_factory(
4097:    def iter_fields_and_params(self):
4539:    def iter_fields_and_params(self):
4547:    get_field_by_id = _lookup_by_attr_factory(
4569:    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
4596:    def iter_groups(self):
4604:    get_group_by_id = _lookup_by_attr_factory(
```

## 原始行 41 · command_execution

命令：
```
/bin/bash -lc "find astropy/io/votable -path '*data*' -type f | sort | grep -E 'ucd|words'; sed -n '1,35p' astropy/io/votable/data/ucd1p-words.txt; tail -n 20 astropy/io/votable/data/ucd1p-words.txt; grep -n -E '"'^#|''^[A-Z] *'"\\|' astropy/io/votable/data/ucd1p-words.txt | head -n 30; sed -n '4300,4650p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
astropy/io/votable/data/ucd1p-words.txt
#EN-UCDlist-v1.6-2024-12-18
Q | arith                             |  Arithmetic quantities
S | arith.diff                        |  Difference between two quantities described by the same UCD
P | arith.factor                      |  Numerical factor
P | arith.grad                        |  Gradient
P | arith.rate                        |  Rate (per time unit)
S | arith.ratio                       |  Ratio between two quantities described by the same UCD
S | arith.squared                     |  Squared quantity
S | arith.sum                         |  Summed or integrated quantity
S | arith.variation                   |  Generic variation of a quantity
Q | arith.zp                          |  Zero point
S | em                                |  Electromagnetic spectrum
S | em.IR                             |  Infrared part of the spectrum
S | em.IR.J                           |  Infrared between 1.0 and 1.5 micron
S | em.IR.H                           |  Infrared between 1.5 and 2 micron
S | em.IR.K                           |  Infrared between 2 and 3 micron
S | em.IR.3-4um                       |  Infrared between 3 and 4 micron
S | em.IR.4-8um                       |  Infrared between 4 and 8 micron
S | em.IR.8-15um                      |  Infrared between 8 and 15 micron
S | em.IR.15-30um                     |  Infrared between 15 and 30 micron
S | em.IR.30-60um                     |  Infrared between 30 and 60 micron
S | em.IR.60-100um                    |  Infrared between 60 and 100 micron
S | em.IR.NIR                         |  Near-Infrared, 1-5 microns
S | em.IR.MIR                         |  Medium-Infrared, 5-30 microns
S | em.IR.FIR                         |  Far-Infrared, 30-100 microns
S | em.UV                             |  Ultraviolet part of the spectrum
S | em.UV.10-50nm                     |  Ultraviolet between 10 and 50 nm EUV extreme UV
S | em.UV.50-100nm                    |  Ultraviolet between 50 and 100 nm
S | em.UV.100-200nm                   |  Ultraviolet between 100 and 200 nm FUV Far UV
S | em.UV.200-300nm                   |  Ultraviolet between 200 and 300 nm NUV near UV
S | em.X-ray                          |  X-ray part of the spectrum
S | em.X-ray.soft                     |  Soft X-ray (0.12 - 2 keV)
S | em.X-ray.medium                   |  Medium X-ray (2 - 12 keV)
S | em.X-ray.hard                     |  Hard X-ray (12 - 120 keV)
Q | em.bin                            |  Channel / instrumental spectral bin coordinate (bin number)
Q | time.crossing                     |  Crossing time
Q | time.duration                     |  Interval of time describing the duration of a generic event or phenomenon
Q | time.end                          |  End time/date of a generic event
Q | time.epoch                        |  Instant of time related to a generic event (epoch, date, Julian date, time stamp/tag,...)
Q | time.equinox                      |  Equinox
Q | time.interval                     |  Time interval, time-bin, time elapsed between two events, not the duration of an event
Q | time.lifetime                     |  Lifetime
Q | time.period                       |  Period, interval of time between the recurrence of phases in a periodic phenomenon
Q | time.period.pulsation             |  Period of pulsation or oscillation of a body or a phenomenon
Q | time.period.revolution            |  Period of revolution of a body around a primary one (similar to year)
Q | time.period.rotation              |  Period of rotation of a body around its axis (similar to day)
Q | time.phase                        |  Phase, position within a period
Q | time.processing                   |  A time/date associated with the processing of data
Q | time.publiYear                    |  Publication year
Q | time.relax                        |  Relaxation time
Q | time.release                      |  The time/date data is available to the public
Q | time.resolution                   |  Time resolution
Q | time.scale                        |  Timescale
Q | time.start                        |  Start time/date of generic event
# This file distributed under CC-0 by the IVOA
1:#EN-UCDlist-v1.6-2024-12-18
2:Q | arith                             |  Arithmetic quantities
3:S | arith.diff                        |  Difference between two quantities described by the same UCD
4:P | arith.factor                      |  Numerical factor
5:P | arith.grad                        |  Gradient
6:P | arith.rate                        |  Rate (per time unit)
7:S | arith.ratio                       |  Ratio between two quantities described by the same UCD
8:S | arith.squared                     |  Squared quantity
9:S | arith.sum                         |  Summed or integrated quantity
10:S | arith.variation                   |  Generic variation of a quantity
11:Q | arith.zp                          |  Zero point
12:S | em                                |  Electromagnetic spectrum
13:S | em.IR                             |  Infrared part of the spectrum
14:S | em.IR.J                           |  Infrared between 1.0 and 1.5 micron
15:S | em.IR.H                           |  Infrared between 1.5 and 2 micron
16:S | em.IR.K                           |  Infrared between 2 and 3 micron
17:S | em.IR.3-4um                       |  Infrared between 3 and 4 micron
18:S | em.IR.4-8um                       |  Infrared between 4 and 8 micron
19:S | em.IR.8-15um                      |  Infrared between 8 and 15 micron
20:S | em.IR.15-30um                     |  Infrared between 15 and 30 micron
21:S | em.IR.30-60um                     |  Infrared between 30 and 60 micron
22:S | em.IR.60-100um                    |  Infrared between 60 and 100 micron
23:S | em.IR.NIR                         |  Near-Infrared, 1-5 microns
24:S | em.IR.MIR                         |  Medium-Infrared, 5-30 microns
25:S | em.IR.FIR                         |  Far-Infrared, 30-100 microns
26:S | em.UV                             |  Ultraviolet part of the spectrum
27:S | em.UV.10-50nm                     |  Ultraviolet between 10 and 50 nm EUV extreme UV
28:S | em.UV.50-100nm                    |  Ultraviolet between 50 and 100 nm
29:S | em.UV.100-200nm                   |  Ultraviolet between 100 and 200 nm FUV Far UV
30:S | em.UV.200-300nm                   |  Ultraviolet between 200 and 300 nm NUV near UV
            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.1",
        },
        "1.2": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.2",
            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.2",
        },
        # With 1.3 we'll be more explicit with the schema location.
        # - xsi:schemaLocation uses the namespace name along with the URL
        #   to reference it.
        # - For convenience, but somewhat confusingly, the namespace URIs
        #   are also usable URLs for accessing an applicable schema.
        #   However to avoid confusion, we'll use the explicit schema URL.
        "1.3": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.3.xsd"
            ),
        },
        # With 1.4 namespace URIs stopped incrementing with minor version changes
        # so we use the same URI as with 1.3.  See this IVOA note for more info:
        # http://www.ivoa.net/documents/Notes/XMLVers/20180529/
        "1.4": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.4.xsd"
            ),
        },
        "1.5": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.5.xsd"
            ),
        },
    }

    def parse(self, iterator, config):
        config["_current_table_number"] = 0

        for start, tag, data, pos in iterator:
            if start:
                if tag == "xml":
                    pass
                elif tag == "VOTABLE":
                    if "version" not in data:
                        warn_or_raise(W20, W20, self.version, config, pos)
                        config["version"] = self.version
                    else:
                        config["version"] = self._version = data["version"]
                        if config["version"].lower().startswith("v"):
                            warn_or_raise(W29, W29, config["version"], config, pos)
                            self._version = config["version"] = config["version"][1:]
                        if config["version"] not in self._version_namespace_map:
                            vo_warn(W21, config["version"], config, pos)

                        # Update the configuration of the VOTableFile itself.
                        # This can not be done via the .version property setter
                        # because that refuses to allow votable 1.0.
                        self._config["version"] = config["version"]
                        self._config.update(self._get_version_checks())

                    if "xmlns" in data:
                        ns_info = self._version_namespace_map.get(config["version"], {})
                        correct_ns = ns_info.get("namespace_uri")
                        if data["xmlns"] != correct_ns:
                            vo_warn(W41, (correct_ns, data["xmlns"]), config, pos)
                    else:
                        vo_warn(W42, (), config, pos)

                    break
                else:
                    vo_raise(E19, (), config, pos)
        config.update(self._get_version_checks())

        tag_mapping = {
            "PARAM": self._add_param,
            "RESOURCE": self._add_resource,
            "COOSYS": self._add_coosys,
            "TIMESYS": self._add_timesys,
            "INFO": self._add_info,
            "DEFINITIONS": self._add_definitions,
            "DESCRIPTION": self._ignore_add,
            "GROUP": self._add_group,
        }

        for start, tag, data, pos in iterator:
            if start:
                tag_mapping.get(tag, self._add_unknown_tag)(
                    iterator, tag, data, config, pos
                )
            elif tag == "DESCRIPTION":
                if self.description is not None:
                    warn_or_raise(W17, W17, "VOTABLE", config, pos)
                self.description = data or None

        if not len(self.resources) and config["version_1_2_or_later"]:
            warn_or_raise(W53, W53, (), config, pos)

        return self

    def to_xml(
        self,
        fd,
        compressed=False,
        tabledata_format=None,
        _debug_python_based_parser=False,
        _astropy_version=None,
    ):
        """
        Write to an XML file.

        Parameters
        ----------
        fd : str or file-like
            Where to write the file. If a file-like object, must be writable.

        compressed : bool, optional
            When `True`, write to a gzip-compressed file.  (Default:
            `False`)

        tabledata_format : str, optional
            Override the format of the table(s) data to write.  Must
            be one of ``tabledata`` (text representation), ``binary`` or
            ``binary2``.  By default, use the format that was specified
            in each `TableElement` object as it was created or read in.  See
            :ref:`astropy:votable-serialization`.
        """
        if tabledata_format is not None:
            if tabledata_format.lower() not in ("tabledata", "binary", "binary2"):
                raise ValueError(f"Unknown format type '{format}'")

        kwargs = {
            "version": self.version,
            "tabledata_format": tabledata_format,
            "_debug_python_based_parser": _debug_python_based_parser,
            "_group_number": 1,
        }
        kwargs.update(self._get_version_checks())

        with util.convert_to_writable_filelike(fd, compressed=compressed) as fh:
            w = XMLWriter(fh)
            version = self.version
            if _astropy_version is None:
                lib_version = astropy_version
            else:
                lib_version = _astropy_version

            xml_header = """
<?xml version="1.0" encoding="utf-8"?>
<!-- Produced with astropy.io.votable version {lib_version}
     http://www.astropy.org/ -->\n"""
            w.write(xml_header.lstrip().format(**locals()))

            # Build the VOTABLE tag attributes.
            votable_attr = {
                "version": version,
                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            }
            ns_info = self._version_namespace_map.get(version, {})
            namespace_uri = ns_info.get("namespace_uri")
            if namespace_uri:
                votable_attr["xmlns"] = namespace_uri
            schema_location_attr = ns_info.get("schema_location_attr")
            schema_location_value = ns_info.get("schema_location_value")
            if schema_location_attr and schema_location_value:
                votable_attr[schema_location_attr] = schema_location_value

            with w.tag("VOTABLE", votable_attr):
                if self.description is not None:
                    w.element("DESCRIPTION", self.description, wrap=True)
                element_sets = [
                    self.coordinate_systems,
                    self.time_systems,
                    self.params,
                    self.infos,
                    self.resources,
                ]
                if kwargs["version_1_2_or_later"]:
                    element_sets.append(self.groups)

                for element_set in element_sets:
                    for element in element_set:
                        element.to_xml(w, **kwargs)

    def iter_tables(self):
        """
        Iterates over all tables in the VOTable file in a "flat" way,
        ignoring the nesting of resources etc.
        """
        for resource in self.resources:
            yield from resource.iter_tables()











    get_table_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_tables",
        "TABLE",
        """
        Looks up a TABLE_ element by the given ID.  Used by the table
        "ref" attribute.
        """,
    )

    get_tables_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_tables",
        "TABLE",
        """
        Looks up a TABLE_ element by the given utype, and returns an
        iterator emitting all matches.
        """,
    )

    def get_table_by_index(self, idx):
        """
        Get a table by its ordinal position in the file.
        """
        for i, table in enumerate(self.iter_tables()):
            if i == idx:
                return table
        raise IndexError(f"No table at index {idx:d} found in VOTABLE file.")

    def iter_fields_and_params(self):
        """
        Recursively iterate over all FIELD_ and PARAM_ elements in the
        VOTABLE_ file.
        """
        for resource in self.resources:
            yield from resource.iter_fields_and_params()

    get_field_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_fields_and_params",
        "FIELD",
        """
        Looks up a FIELD_ element by the given ID_.  Used by the field's
        "ref" attribute.
        """,
    )

    get_fields_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_fields_and_params",
        "FIELD",
        """
        Looks up a FIELD_ element by the given utype and returns an
        iterator emitting all matches.
        """,
    )

    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
        "iter_fields_and_params",
        "FIELD",
        """
        Looks up a FIELD_ element by the given ID_ or name.
        """,
    )

    def iter_values(self):
        """
        Recursively iterate over all VALUES_ elements in the VOTABLE_
        file.
        """
        for field in self.iter_fields_and_params():
            yield field.values

    get_values_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_values",
        "VALUES",
        """
        Looks up a VALUES_ element by the given ID.  Used by the values
        "ref" attribute.
        """,
    )

    def iter_groups(self):
        """
        Recursively iterate over all GROUP_ elements in the VOTABLE_
        file.
        """
        for table in self.iter_tables():
            yield from table.iter_groups()

    get_group_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_groups",
        "GROUP",
        """
        Looks up a GROUP_ element by the given ID.  Used by the group's
        "ref" attribute
        """,
    )

    get_groups_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_groups",
        "GROUP",
        """
        Looks up a GROUP_ element by the given utype and returns an
        iterator emitting all matches.
        """,
    )

    def iter_coosys(self):
        """
        Recursively iterate over all COOSYS_ elements in the VOTABLE_
        file.
        """
        yield from self.coordinate_systems
        for resource in self.resources:
            yield from resource.iter_coosys()

    get_coosys_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_coosys",
        "COOSYS",
        """Looks up a COOSYS_ element by the given ID.""",
    )

    def iter_timesys(self):
        """
        Recursively iterate over all TIMESYS_ elements in the VOTABLE_
        file.
        """
        yield from self.time_systems
        for resource in self.resources:
            yield from resource.iter_timesys()
```

## 原始行 44 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '1290,1770p'; grep -R -n -E \"meta\\[['\\\"](ID|name|ref|ucd|utype|description)['\\\"]\\]|column.meta|values.*meta|links.*meta\" astropy/io/votable/tests astropy/table/tests --include='*.py' | head -n 300"
```

退出码：`0`

输出：
```
  1290	            self.min = meta["min"]["value"]
  1291	            self.min_inclusive = meta["min"]["inclusive"]
  1292	        if "max" in meta:
  1293	            self.max = meta["max"]["value"]
  1294	            self.max_inclusive = meta["max"]["inclusive"]
  1295	        if "options" in meta:
  1296	            self._options = list(meta["options"].items())
  1297	
  1298	
  1299	class Field(
  1300	    SimpleElement,
  1301	    _IDProperty,
  1302	    _NameProperty,
  1303	    _XtypeProperty,
  1304	    _UtypeProperty,
  1305	    _UcdProperty,
  1306	):
  1307	    """
  1308	    FIELD_ element: describes the datatype of a particular column of data.
  1309	
  1310	    The keyword arguments correspond to setting members of the same
  1311	    name, documented below.
  1312	
  1313	    If *ID* is provided, it is used for the column name in the
  1314	    resulting recarray of the table.  If no *ID* is provided, *name*
  1315	    is used instead.  If neither is provided, an exception will be
  1316	    raised.
  1317	    """
  1318	
  1319	    _attr_list_11 = [
  1320	        "ID",
  1321	        "name",
  1322	        "datatype",
  1323	        "arraysize",
  1324	        "ucd",
  1325	        "unit",
  1326	        "width",
  1327	        "precision",
  1328	        "utype",
  1329	        "ref",
  1330	    ]
  1331	    _attr_list_12 = _attr_list_11 + ["xtype"]
  1332	    _element_name = "FIELD"
  1333	
  1334	    def __init__(
  1335	        self,
  1336	        votable,
  1337	        ID=None,
  1338	        name=None,
  1339	        datatype=None,
  1340	        arraysize=None,
  1341	        ucd=None,
  1342	        unit=None,
  1343	        width=None,
  1344	        precision=None,
  1345	        utype=None,
  1346	        ref=None,
  1347	        type=None,
  1348	        id=None,
  1349	        xtype=None,
  1350	        config=None,
  1351	        pos=None,
  1352	        **extra,
  1353	    ):
  1354	        self._config = _attach_default_config(votable, config)
  1355	        self._pos = pos
  1356	
  1357	        SimpleElement.__init__(self)
  1358	
  1359	        if self._config.get("version_1_2_or_later"):
  1360	            self._attr_list = self._attr_list_12
  1361	        else:
  1362	            self._attr_list = self._attr_list_11
  1363	            if xtype is not None:
  1364	                warn_unknown_attrs(self._element_name, ["xtype"], config, pos)
  1365	
  1366	        # TODO: REMOVE ME ----------------------------------------
  1367	        # This is a terrible hack to support Simple Image Access
  1368	        # Protocol results from https://astroarchive.noirlab.edu/ .  It creates a field
  1369	        # for the coordinate projection type of type "double", which
  1370	        # actually contains character data.  We have to hack the field
  1371	        # to store character data, or we can't read it in.  A warning
  1372	        # will be raised when this happens.
  1373	        if (
  1374	            self._config.get("verify", "ignore") != "exception"
  1375	            and name == "cprojection"
  1376	            and ID == "cprojection"
  1377	            and ucd == "VOX:WCS_CoordProjection"
  1378	            and datatype == "double"
  1379	        ):
  1380	            datatype = "char"
  1381	            arraysize = "3"
  1382	            vo_warn(W40, (), config, pos)
  1383	        # ----------------------------------------
  1384	
  1385	        self.description = None
  1386	        self._votable = votable
  1387	
  1388	        self.ID = resolve_id(ID, id, config, pos) or xmlutil.fix_id(name, config, pos)
  1389	        self.name = name
  1390	        if name is None:
  1391	            if self._element_name == "PARAM" and not self._config.get(
  1392	                "version_1_1_or_later"
  1393	            ):
  1394	                pass
  1395	            else:
  1396	                warn_or_raise(W15, W15, self._element_name, config, pos)
  1397	            self.name = self.ID
  1398	
  1399	        if self._ID is None and name is None:
  1400	            vo_raise(W12, self._element_name, config, pos)
  1401	
  1402	        datatype_mapping = {
  1403	            "string": "char",
  1404	            "unicodeString": "unicodeChar",
  1405	            "int16": "short",
  1406	            "int32": "int",
  1407	            "int64": "long",
  1408	            "float32": "float",
  1409	            "float64": "double",
  1410	            # The following appear in some Vizier tables
  1411	            "unsignedInt": "long",
  1412	            "unsignedShort": "int",
  1413	        }
  1414	
  1415	        datatype_mapping.update(self._config.get("datatype_mapping", {}))
  1416	
  1417	        if datatype in datatype_mapping:
  1418	            warn_or_raise(W13, W13, (datatype, datatype_mapping[datatype]), config, pos)
  1419	            datatype = datatype_mapping[datatype]
  1420	
  1421	        self.ref = ref
  1422	        self.datatype = datatype
  1423	        self.arraysize = arraysize
  1424	        self.ucd = ucd
  1425	        self.unit = unit
  1426	        self.width = width
  1427	        self.precision = precision
  1428	        self.utype = utype
  1429	        self.type = type
  1430	        self._links = HomogeneousList(Link)
  1431	        self.title = self.name
  1432	        self.values = Values(self._votable, self)
  1433	        self.xtype = xtype
  1434	
  1435	        self._setup(config, pos)
  1436	
  1437	        warn_unknown_attrs(self._element_name, extra.keys(), config, pos)
  1438	
  1439	    @classmethod
  1440	    def uniqify_names(cls, fields):
  1441	        """
  1442	        Make sure that all names and titles in a list of fields are
  1443	        unique, by appending numbers if necessary.
  1444	        """
  1445	        unique = {}
  1446	        for field in fields:
  1447	            i = 2
  1448	            new_id = field.ID
  1449	            while new_id in unique:
  1450	                new_id = field.ID + f"_{i:d}"
  1451	                i += 1
  1452	            if new_id != field.ID:
  1453	                vo_warn(W32, (field.ID, new_id), field._config, field._pos)
  1454	            field.ID = new_id
  1455	            unique[new_id] = field.ID
  1456	
  1457	        for field in fields:
  1458	            i = 2
  1459	            if field.name is None:
  1460	                new_name = field.ID
  1461	                implicit = True
  1462	            else:
  1463	                new_name = field.name
  1464	                implicit = False
  1465	            if new_name != field.ID:
  1466	                while new_name in unique:
  1467	                    new_name = field.name + f" {i:d}"
  1468	                    i += 1
  1469	
  1470	            if not implicit and new_name != field.name:
  1471	                vo_warn(W33, (field.name, new_name), field._config, field._pos)
  1472	            field._unique_name = new_name
  1473	            unique[new_name] = field.name
  1474	
  1475	    def _setup(self, config, pos):
  1476	        if self.values._ref is not None:
  1477	            self.values.ref = self.values._ref
  1478	        self.converter = converters.get_converter(self, config, pos)
  1479	
  1480	    @property
  1481	    def datatype(self):
  1482	        """The datatype of the column [*required*].
  1483	
  1484	        Valid values (as defined by the spec) are:
  1485	
  1486	          'boolean', 'bit', 'unsignedByte', 'short', 'int', 'long',
  1487	          'char', 'unicodeChar', 'float', 'double', 'floatComplex', or
  1488	          'doubleComplex'
  1489	
  1490	        Many VOTABLE files in the wild use 'string' instead of 'char',
  1491	        so that is also a valid option, though 'string' will always be
  1492	        converted to 'char' when writing the file back out.
  1493	        """
  1494	        return self._datatype
  1495	
  1496	    @datatype.setter
  1497	    def datatype(self, datatype):
  1498	        if datatype is None:
  1499	            if self._config.get("version_1_1_or_later"):
  1500	                warn_or_raise(E10, E10, self._element_name, self._config, self._pos)
  1501	            datatype = "char"
  1502	        if datatype not in converters.converter_mapping:
  1503	            vo_raise(E06, (datatype, self.ID), self._config, self._pos)
  1504	        self._datatype = datatype
  1505	
  1506	    @property
  1507	    def precision(self):
  1508	        """
  1509	        Along with :attr:`width`, defines the `numerical accuracy`_
  1510	        associated with the data.  These values are used to limit the
  1511	        precision when writing floating point values back to the XML
  1512	        file.  Otherwise, it is purely informational -- the Numpy
  1513	        recarray containing the data itself does not use this
  1514	        information.
  1515	        """
  1516	        return self._precision
  1517	
  1518	    @precision.setter
  1519	    def precision(self, precision):
  1520	        if precision is not None and not re.match(r"^[FE]?[0-9]+$", precision):
  1521	            vo_raise(E11, precision, self._config, self._pos)
  1522	        self._precision = precision
  1523	
  1524	    @precision.deleter
  1525	    def precision(self):
  1526	        self._precision = None
  1527	
  1528	    @property
  1529	    def width(self):
  1530	        """
  1531	        Along with :attr:`precision`, defines the `numerical
  1532	        accuracy`_ associated with the data.  These values are used to
  1533	        limit the precision when writing floating point values back to
  1534	        the XML file.  Otherwise, it is purely informational -- the
  1535	        Numpy recarray containing the data itself does not use this
  1536	        information.
  1537	        """
  1538	        return self._width
  1539	
  1540	    @width.setter
  1541	    def width(self, width):
  1542	        if width is not None:
  1543	            width = int(width)
  1544	            if width <= 0:
  1545	                vo_raise(E12, width, self._config, self._pos)
  1546	        self._width = width
  1547	
  1548	    @width.deleter
  1549	    def width(self):
  1550	        self._width = None
  1551	
  1552	    # ref on FIELD and PARAM behave differently than elsewhere -- here
  1553	    # they're just informational, such as to refer to a coordinate
  1554	    # system.
  1555	    @property
  1556	    def ref(self):
  1557	        """
  1558	        On FIELD_ elements, ref is used only for informational
  1559	        purposes, for example to refer to a COOSYS_ or TIMESYS_ element.
  1560	        """
  1561	        return self._ref
  1562	
  1563	    @ref.setter
  1564	    def ref(self, ref):
  1565	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  1566	        self._ref = ref
  1567	
  1568	    @ref.deleter
  1569	    def ref(self):
  1570	        self._ref = None
  1571	
  1572	    @property
  1573	    def unit(self):
  1574	        """A string specifying the units_ for the FIELD_."""
  1575	        return self._unit
  1576	
  1577	    @unit.setter
  1578	    def unit(self, unit):
  1579	        if unit is None:
  1580	            self._unit = None
  1581	            return
  1582	
  1583	        from astropy import units as u
  1584	
  1585	        # First, parse the unit in the default way, so that we can
  1586	        # still emit a warning if the unit is not to spec.
  1587	        default_format = _get_default_unit_format(self._config)
  1588	        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
  1589	        if isinstance(unit_obj, u.UnrecognizedUnit):
  1590	            warn_or_raise(W50, W50, (unit,), self._config, self._pos)
  1591	
  1592	        format = _get_unit_format(self._config)
  1593	        if format != default_format:
  1594	            unit_obj = u.Unit(unit, format=format, parse_strict="silent")
  1595	
  1596	        self._unit = unit_obj
  1597	
  1598	    @unit.deleter
  1599	    def unit(self):
  1600	        self._unit = None
  1601	
  1602	    @property
  1603	    def arraysize(self):
  1604	        """
  1605	        Specifies the size of the multidimensional array if this
  1606	        FIELD_ contains more than a single value.
  1607	
  1608	        See `multidimensional arrays`_.
  1609	        """
  1610	        return self._arraysize
  1611	
  1612	    @arraysize.setter
  1613	    def arraysize(self, arraysize):
  1614	        if arraysize is not None and not re.match(
  1615	            r"^([0-9]+x)*[0-9]*[*]?(s\W)?$", arraysize
  1616	        ):
  1617	            vo_raise(E13, arraysize, self._config, self._pos)
  1618	        self._arraysize = arraysize
  1619	
  1620	    @arraysize.deleter
  1621	    def arraysize(self):
  1622	        self._arraysize = None
  1623	
  1624	    @property
  1625	    def type(self):
  1626	        """
  1627	        The type attribute on FIELD_ elements is reserved for future
  1628	        extensions.
  1629	        """
  1630	        return self._type
  1631	
  1632	    @type.setter
  1633	    def type(self, type):
  1634	        self._type = type
  1635	
  1636	    @type.deleter
  1637	    def type(self):
  1638	        self._type = None
  1639	
  1640	    @property
  1641	    def values(self):
  1642	        """
  1643	        A :class:`Values` instance (or `None`) defining the domain
  1644	        of the column.
  1645	        """
  1646	        return self._values
  1647	
  1648	    @values.setter
  1649	    def values(self, values):
  1650	        assert values is None or isinstance(values, Values)
  1651	        self._values = values
  1652	
  1653	    @values.deleter
  1654	    def values(self):
  1655	        self._values = None
  1656	
  1657	    @property
  1658	    def links(self):
  1659	        """
  1660	        A list of :class:`Link` instances used to reference more
  1661	        details about the meaning of the FIELD_.  This is purely
  1662	        informational and is not used by the `astropy.io.votable`
  1663	        package.
  1664	        """
  1665	        return self._links
  1666	
  1667	    def parse(self, iterator, config):
  1668	        for start, tag, data, pos in iterator:
  1669	            if start:
  1670	                if tag == "VALUES":
  1671	                    self.values.__init__(
  1672	                        self._votable, self, config=config, pos=pos, **data
  1673	                    )
  1674	                    self.values.parse(iterator, config)
  1675	                elif tag == "LINK":
  1676	                    link = Link(config=config, pos=pos, **data)
  1677	                    self.links.append(link)
  1678	                    link.parse(iterator, config)
  1679	                elif tag == "DESCRIPTION":
  1680	                    warn_unknown_attrs("DESCRIPTION", data.keys(), config, pos)
  1681	                elif tag != self._element_name:
  1682	                    self._add_unknown_tag(iterator, tag, data, config, pos)
  1683	            else:
  1684	                if tag == "DESCRIPTION":
  1685	                    if self.description is not None:
  1686	                        warn_or_raise(W17, W17, self._element_name, config, pos)
  1687	                    self.description = data or None
  1688	                elif tag == self._element_name:
  1689	                    break
  1690	
  1691	        if self.description is not None:
  1692	            self.title = " ".join(x.strip() for x in self.description.splitlines())
  1693	        else:
  1694	            self.title = self.name
  1695	
  1696	        self._setup(config, pos)
  1697	
  1698	        return self
  1699	
  1700	    def to_xml(self, w, **kwargs):
  1701	        attrib = w.object_attrs(self, self._attr_list)
  1702	        if "unit" in attrib:
  1703	            format = _get_unit_format(self._config)
  1704	            try:
  1705	                attrib["unit"] = self.unit.to_string(format)
  1706	            except ValueError as e:
  1707	                # Allow non-standard units with a warning, see
  1708	                # https://github.com/astropy/astropy/issues/17497#issuecomment-2520472495
  1709	                attrib["unit"] = self.unit.to_string()
  1710	                warn_or_raise(W50, W50, (attrib["unit"],), self._config, self._pos)
  1711	        with w.tag(self._element_name, attrib=attrib):
  1712	            if self.description is not None:
  1713	                w.element("DESCRIPTION", self.description, wrap=True)
  1714	            if not self.values.is_defaults():
  1715	                self.values.to_xml(w, **kwargs)
  1716	            for link in self.links:
  1717	                link.to_xml(w, **kwargs)
  1718	
  1719	
  1720	
  1721	
  1722	
  1723	
  1724	
  1725	
  1726	
  1727	
  1728	
  1729	
  1730	
  1731	
  1732	
  1733	
  1734	
  1735	
  1736	
  1737	
  1738	
  1739	
  1740	
  1741	
  1742	
  1743	
  1744	
  1745	
  1746	
  1747	
  1748	
  1749	
  1750	
  1751	    @classmethod
  1752	    def from_table_column(cls, votable, column):
  1753	        """
  1754	        Restores a `Field` instance from a given
  1755	        `astropy.table.Column` instance.
  1756	        """
  1757	        kwargs = {}
  1758	        meta = column.info.meta
  1759	        if meta:
  1760	            for key in ["ucd", "width", "precision", "utype", "xtype"]:
  1761	                val = meta.get(key, None)
  1762	                if val is not None:
  1763	                    kwargs[key] = val
  1764	        # TODO: Use the unit framework when available
  1765	        if column.info.unit is not None:
  1766	            kwargs["unit"] = column.info.unit
  1767	        kwargs["name"] = column.info.name
  1768	        result = converters.table_column_to_votable_datatype(column)
  1769	        kwargs.update(result)
  1770	
astropy/io/votable/tests/test_table.py:287:    column_metadata = {
astropy/io/votable/tests/test_table.py:298:        column_metadata=column_metadata,
astropy/io/votable/tests/test_table.py:324:    for kk, key in enumerate(column_metadata.keys()):
astropy/io/votable/tests/test_table.py:325:        for tag in column_metadata[key].keys():
astropy/io/votable/tests/test_table.py:327:                column_metadata[key][tag]
```

## 原始行 46 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '1710,1805p'; sed -n '270,350p' astropy/io/votable/tests/test_table.py; grep -R -n -E \"VALUES|MIN|MAX|OPTION|links\" astropy/io/votable/tests --include='*.py' | head -n 200"
```

退出码：`0`

输出：
```
  1710	                warn_or_raise(W50, W50, (attrib["unit"],), self._config, self._pos)
  1711	        with w.tag(self._element_name, attrib=attrib):
  1712	            if self.description is not None:
  1713	                w.element("DESCRIPTION", self.description, wrap=True)
  1714	            if not self.values.is_defaults():
  1715	                self.values.to_xml(w, **kwargs)
  1716	            for link in self.links:
  1717	                link.to_xml(w, **kwargs)
  1718	
  1719	
  1720	
  1721	
  1722	
  1723	
  1724	
  1725	
  1726	
  1727	
  1728	
  1729	
  1730	
  1731	
  1732	
  1733	
  1734	
  1735	
  1736	
  1737	
  1738	
  1739	
  1740	
  1741	
  1742	
  1743	
  1744	
  1745	
  1746	
  1747	
  1748	
  1749	
  1750	
  1751	    @classmethod
  1752	    def from_table_column(cls, votable, column):
  1753	        """
  1754	        Restores a `Field` instance from a given
  1755	        `astropy.table.Column` instance.
  1756	        """
  1757	        kwargs = {}
  1758	        meta = column.info.meta
  1759	        if meta:
  1760	            for key in ["ucd", "width", "precision", "utype", "xtype"]:
  1761	                val = meta.get(key, None)
  1762	                if val is not None:
  1763	                    kwargs[key] = val
  1764	        # TODO: Use the unit framework when available
  1765	        if column.info.unit is not None:
  1766	            kwargs["unit"] = column.info.unit
  1767	        kwargs["name"] = column.info.name
  1768	        result = converters.table_column_to_votable_datatype(column)
  1769	        kwargs.update(result)
  1770	
  1771	        field = cls(votable, **kwargs)
  1772	
  1773	        if column.info.description is not None:
  1774	            field.description = column.info.description
  1775	        field.values.from_table_column(column)
  1776	        if meta and "links" in meta:
  1777	            for link in meta["links"]:
  1778	                field.links.append(Link.from_table_column(link))
  1779	
  1780	        # TODO: Parse format into precision and width
  1781	        return field
  1782	
  1783	
  1784	class Param(Field):
  1785	    """
  1786	    PARAM_ element: constant-valued columns in the data.
  1787	
  1788	    :class:`Param` objects are a subclass of :class:`Field`, and have
  1789	    all of its methods and members.  Additionally, it defines :attr:`value`.
  1790	    """
  1791	
  1792	    _attr_list_11 = Field._attr_list_11 + ["value"]
  1793	    _attr_list_12 = Field._attr_list_12 + ["value"]
  1794	    _element_name = "PARAM"
  1795	
  1796	    def __init__(
  1797	        self,
  1798	        votable,
  1799	        ID=None,
  1800	        name=None,
  1801	        value=None,
  1802	        datatype=None,
  1803	        arraysize=None,
  1804	        ucd=None,
  1805	        unit=None,

@pytest.mark.skipif(not HAS_PYARROW, reason="requires pyarrow")
@pytest.mark.parametrize("overwrite", [True, False])
def test_read_write_votable_parquet(tmp_path, overwrite):
    """
    Test to write and read VOTable with Parquet serialization
    """

    # Create some fake data
    number_of_objects = 10
    ids = [f"COSMOS_{ii:03g}" for ii in range(number_of_objects)]
    redshift = np.random.uniform(low=0, high=3, size=number_of_objects)
    mass = np.random.uniform(low=1e8, high=1e10, size=number_of_objects)
    sfr = np.random.uniform(low=1, high=100, size=number_of_objects)
    astropytab = Table([ids, redshift, mass, sfr], names=["id", "z", "mass", "sfr"])

    # Create Column metadata
    column_metadata = {
        "id": {"unit": "", "ucd": "meta.id", "utype": "none"},
        "z": {"unit": "", "ucd": "src.redshift", "utype": "none"},
        "mass": {"unit": "solMass", "ucd": "phys.mass", "utype": "none"},
        "sfr": {"unit": "solMass / yr", "ucd": "phys.SFR", "utype": "none"},
    }

    # Write VOTable with Parquet serialization
    filename = tmp_path / "test_votable_parquet.vot"
    astropytab.write(
        filename,
        column_metadata=column_metadata,
        overwrite=overwrite,
        format="votable.parquet",
    )

    # Check both files are written out
    assert set(os.listdir(tmp_path)) == {
        "test_votable_parquet.vot",
        "test_votable_parquet.vot.parquet",
    }

    # Open created VOTable with Parquet serialization
    with warnings.catch_warnings():
        warnings.simplefilter("always", ResourceWarning)
        votable = parse(filename)

    # Get table out
    votable_table = votable.resources[0].tables[0].array

    # compare tables
    assert (astropytab == votable_table).all()

    # Compare metadata
    # Note: VOTable parses empty units ("") as "---". This is
    # taken into account below by .replace("---","").
    saved_bool = []
    for kk, key in enumerate(column_metadata.keys()):
        for tag in column_metadata[key].keys():
            saved_bool.append(
                column_metadata[key][tag]
                == str(
                    eval(f"votable.resources[0].tables[0].fields[{kk}].{tag}")
                ).replace("---", "")
            )
    assert np.asarray(saved_bool).all()


@pytest.mark.skipif(not HAS_PYARROW, reason="requires pyarrow")
@pytest.mark.parametrize("format", [None, "votable.parquet"])
def test_stored_parquet_votable(format):
    # Ensures that parquet is found as relative to the votable and not the test file
    with warnings.catch_warnings():
        warnings.simplefilter("always", ResourceWarning)
        if format is None:
            stored_votable = Table.read(
                get_pkg_data_filename("data/parquet_binary.xml")
            )
        else:
            stored_votable = Table.read(
                get_pkg_data_filename("data/parquet_binary.xml"), format=format
            )

    assert len(stored_votable) == 10
astropy/io/votable/tests/test_tree.py:112:            <VALUES null="-2147483648">
astropy/io/votable/tests/test_tree.py:113:              <MIN value=""/>
astropy/io/votable/tests/test_tree.py:114:              <MAX value=""/>
astropy/io/votable/tests/test_tree.py:115:            </VALUES>
astropy/io/votable/tests/test_tree.py:210:    MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
astropy/io/votable/tests/test_tree.py:215:                    <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
```

## 原始行 49 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '4480,4640p'; grep -R -n \"to_table_column\" astropy --include='*.py'; grep -R -n \"get_first_table\" astropy/io/votable/tests --include='*.py' | head"
```

退出码：`0`

输出：
```
  4480	                    self.infos,
  4481	                    self.resources,
  4482	                ]
  4483	                if kwargs["version_1_2_or_later"]:
  4484	                    element_sets.append(self.groups)
  4485	
  4486	                for element_set in element_sets:
  4487	                    for element in element_set:
  4488	                        element.to_xml(w, **kwargs)
  4489	
  4490	    def iter_tables(self):
  4491	        """
  4492	        Iterates over all tables in the VOTable file in a "flat" way,
  4493	        ignoring the nesting of resources etc.
  4494	        """
  4495	        for resource in self.resources:
  4496	            yield from resource.iter_tables()
  4497	
  4498	
  4499	
  4500	
  4501	
  4502	
  4503	
  4504	
  4505	
  4506	
  4507	
  4508	    get_table_by_id = _lookup_by_attr_factory(
  4509	        "ID",
  4510	        True,
  4511	        "iter_tables",
  4512	        "TABLE",
  4513	        """
  4514	        Looks up a TABLE_ element by the given ID.  Used by the table
  4515	        "ref" attribute.
  4516	        """,
  4517	    )
  4518	
  4519	    get_tables_by_utype = _lookup_by_attr_factory(
  4520	        "utype",
  4521	        False,
  4522	        "iter_tables",
  4523	        "TABLE",
  4524	        """
  4525	        Looks up a TABLE_ element by the given utype, and returns an
  4526	        iterator emitting all matches.
  4527	        """,
  4528	    )
  4529	
  4530	    def get_table_by_index(self, idx):
  4531	        """
  4532	        Get a table by its ordinal position in the file.
  4533	        """
  4534	        for i, table in enumerate(self.iter_tables()):
  4535	            if i == idx:
  4536	                return table
  4537	        raise IndexError(f"No table at index {idx:d} found in VOTABLE file.")
  4538	
  4539	    def iter_fields_and_params(self):
  4540	        """
  4541	        Recursively iterate over all FIELD_ and PARAM_ elements in the
  4542	        VOTABLE_ file.
  4543	        """
  4544	        for resource in self.resources:
  4545	            yield from resource.iter_fields_and_params()
  4546	
  4547	    get_field_by_id = _lookup_by_attr_factory(
  4548	        "ID",
  4549	        True,
  4550	        "iter_fields_and_params",
  4551	        "FIELD",
  4552	        """
  4553	        Looks up a FIELD_ element by the given ID_.  Used by the field's
  4554	        "ref" attribute.
  4555	        """,
  4556	    )
  4557	
  4558	    get_fields_by_utype = _lookup_by_attr_factory(
  4559	        "utype",
  4560	        False,
  4561	        "iter_fields_and_params",
  4562	        "FIELD",
  4563	        """
  4564	        Looks up a FIELD_ element by the given utype and returns an
  4565	        iterator emitting all matches.
  4566	        """,
  4567	    )
  4568	
  4569	    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
  4570	        "iter_fields_and_params",
  4571	        "FIELD",
  4572	        """
  4573	        Looks up a FIELD_ element by the given ID_ or name.
  4574	        """,
  4575	    )
  4576	
  4577	    def iter_values(self):
  4578	        """
  4579	        Recursively iterate over all VALUES_ elements in the VOTABLE_
  4580	        file.
  4581	        """
  4582	        for field in self.iter_fields_and_params():
  4583	            yield field.values
  4584	
  4585	    get_values_by_id = _lookup_by_attr_factory(
  4586	        "ID",
  4587	        True,
  4588	        "iter_values",
  4589	        "VALUES",
  4590	        """
  4591	        Looks up a VALUES_ element by the given ID.  Used by the values
  4592	        "ref" attribute.
  4593	        """,
  4594	    )
  4595	
  4596	    def iter_groups(self):
  4597	        """
  4598	        Recursively iterate over all GROUP_ elements in the VOTABLE_
  4599	        file.
  4600	        """
  4601	        for table in self.iter_tables():
  4602	            yield from table.iter_groups()
  4603	
  4604	    get_group_by_id = _lookup_by_attr_factory(
  4605	        "ID",
  4606	        True,
  4607	        "iter_groups",
  4608	        "GROUP",
  4609	        """
  4610	        Looks up a GROUP_ element by the given ID.  Used by the group's
  4611	        "ref" attribute
  4612	        """,
  4613	    )
  4614	
  4615	    get_groups_by_utype = _lookup_by_attr_factory(
  4616	        "utype",
  4617	        False,
  4618	        "iter_groups",
  4619	        "GROUP",
  4620	        """
  4621	        Looks up a GROUP_ element by the given utype and returns an
  4622	        iterator emitting all matches.
  4623	        """,
  4624	    )
  4625	
  4626	    def iter_coosys(self):
  4627	        """
  4628	        Recursively iterate over all COOSYS_ elements in the VOTABLE_
  4629	        file.
  4630	        """
  4631	        yield from self.coordinate_systems
  4632	        for resource in self.resources:
  4633	            yield from resource.iter_coosys()
  4634	
  4635	    get_coosys_by_id = _lookup_by_attr_factory(
  4636	        "ID",
  4637	        True,
  4638	        "iter_coosys",
  4639	        "COOSYS",
  4640	        """Looks up a COOSYS_ element by the given ID.""",
astropy/io/votable/tree.py:757:    def to_table_column(self, column):
astropy/io/votable/tree.py:1264:    def to_table_column(self, column):
astropy/io/votable/tests/test_table.py:66:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:73:    t = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:172:    table = votable.get_first_table().to_table(use_names_over_ids=True)
astropy/io/votable/tests/test_table.py:199:    table = votable.get_first_table().to_table(use_names_over_ids=False)
astropy/io/votable/tests/test_table.py:237:    table = parse(fpath).get_first_table().to_table()
astropy/io/votable/tests/test_table.py:447:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:453:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:472:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:530:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:544:    table2 = votable2.get_first_table()
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^def '"' astropy/io/votable/tree.py; grep -n '"'^    def '"' astropy/io/votable/tree.py | tail -n 120; grep -n '"'^    def '"' astropy/io/votable/converters.py | head -n 200; grep -n '"'^def '"' astropy/utils/xml/check.py astropy/io/votable/ucd.py"
```

退出码：`0`

输出：
```
128:def _resize(masked, new_size):
141:def _lookup_by_attr_factory(attr, unique, iterator, element_name, doc):
209:def _lookup_by_id_or_name_factory(iterator, element_name, doc):
267:def _attach_default_config(votable, config) -> dict:
295:def check_astroyear(year, field, config=None, pos=None):
342:def resolve_id(ID, id, config=None, pos=None):
349:def check_ucd(ucd, config=None, pos=None):
2307:    def ref(self):
2310:    def get_ref(self):
2341:    def __init__(
2373:    def __repr__(self):
2377:    def ref(self):
2385:    def ref(self, ref):
2390:    def ref(self):
2394:    def entries(self):
2402:    def _add_fieldref(self, iterator, tag, data, config, pos):
2406:    def _add_paramref(self, iterator, tag, data, config, pos):
2410:    def _add_param(self, iterator, tag, data, config, pos):
2419:    def _add_group(self, iterator, tag, data, config, pos):
2424:    def parse(self, iterator, config):
2447:    def to_xml(self, w, **kwargs):
2456:    def iter_fields_and_params(self):
2467:    def iter_groups(self):
2502:    def __init__(
2550:    def __repr__(self):
2556:    def __bytes__(self):
2559:    def __str__(self):
2563:    def ref(self):
2567:    def ref(self, ref):
2598:    def ref(self):
2602:    def format(self):
2619:    def format(self, format):
2641:    def nrows(self):
2649:    def fields(self):
2657:    def all_fields(self):
2673:    def params(self):
2681:    def groups(self):
2691:    def links(self):
2699:    def infos(self):
2714:    def create_arrays(
2773:    def _resize_strategy(self, size):
2785:    def add_field(self, field: Field) -> None:
2789:    def _register_field(self, iterator, tag, data, config, pos) -> None:
2794:    def _add_param(self, iterator, tag, data, config, pos):
2799:    def _add_group(self, iterator, tag, data, config, pos):
2804:    def _add_link(self, iterator, tag, data, config, pos):
2809:    def _add_info(self, iterator, tag, data, config, pos):
2816:    def parse(self, iterator, config):
2980:    def _parse_tabledata(self, iterator, colnumbers, config):
3102:    def _get_binary_data_stream(self, iterator, config):
3165:    def _parse_binary(self, mode, iterator, colnumbers, config, pos):
3233:    def _parse_fits(self, iterator, extnum, config):
3278:    def _parse_parquet(self, iterator, config):
3349:    def to_xml(self, w, **kwargs):
3391:    def _write_tabledata(self, w, **kwargs):
3452:    def _write_binary(self, mode, w, **kwargs):
3547:    def from_table(cls, votable, table):
3572:    def iter_fields_and_params(self):
3611:    def iter_groups(self):
3641:    def iter_info(self):
3663:    def __init__(self, content=None):
3672:    def __str__(self):
3675:    def _add_statement(self, start, tag, data, config, pos):
3711:    def _unknown_mapping_tag(self, start, tag, data, config, pos):
3725:    def content(self):
3738:    def parse(self, votable, iterator, config):
3766:    def to_xml(self, w):
3772:    def check_content_format(self):
3822:    def __init__(
3858:    def __repr__(self):
3865:    def type(self):
3879:    def type(self, type):
3885:    def mivot_block(self):
3899:    def mivot_block(self, mivot_block):
3905:    def extra_attributes(self):
3916:    def coordinate_systems(self):
3924:    def time_systems(self):
3932:    def infos(self):
3940:    def groups(self):
3947:    def params(self):
3964:    def tables(self):
3972:    def resources(self):
3979:    def _add_table(self, iterator, tag, data, config, pos):
3984:    def _add_info(self, iterator, tag, data, config, pos):
3989:    def _add_group(self, iterator, tag, data, config, pos):
3994:    def _add_param(self, iterator, tag, data, config, pos):
3999:    def _add_coosys(self, iterator, tag, data, config, pos):
4004:    def _add_timesys(self, iterator, tag, data, config, pos):
4009:    def _add_resource(self, iterator, tag, data, config, pos):
4014:    def _add_link(self, iterator, tag, data, config, pos):
4019:    def parse(self, votable, iterator, config):
4054:    def to_xml(self, w, **kwargs):
4088:    def iter_tables(self):
4097:    def iter_fields_and_params(self):
4108:    def iter_coosys(self):
4117:    def iter_timesys(self):
4126:    def iter_info(self):
4149:    def __init__(self, ID=None, id=None, config=None, pos=None, version="1.4"):
4168:    def __repr__(self):
4173:    def config(self):
4181:    def version(self):
4188:    def version(self, version):
4201:    def coordinate_systems(self):
4209:    def time_systems(self):
4217:    def params(self):
4225:    def infos(self):
4233:    def resources(self):
4241:    def groups(self):
4249:    def _add_param(self, iterator, tag, data, config, pos):
4254:    def _add_resource(self, iterator, tag, data, config, pos):
4259:    def _add_coosys(self, iterator, tag, data, config, pos):
4264:    def _add_timesys(self, iterator, tag, data, config, pos):
4269:    def _add_info(self, iterator, tag, data, config, pos):
4274:    def _add_group(self, iterator, tag, data, config, pos):
4281:    def _get_version_checks(self):
4342:    def parse(self, iterator, config):
4406:    def to_xml(
4490:    def iter_tables(self):
4530:    def get_table_by_index(self, idx):
4539:    def iter_fields_and_params(self):
4577:    def iter_values(self):
4596:    def iter_groups(self):
4626:    def iter_coosys(self):
4643:    def iter_timesys(self):
4660:    def iter_info(self):
4681:    def set_all_tables_format(self, format):
4689:    def from_table(cls, table, table_id=None):
62:    def _ensure_bigendian(x):
69:    def _ensure_bigendian(x):
176:    def __init__(self, field, config=None, pos=None):
180:    def _parse_length(read):
187:    def supports_empty_values(self, config):
193:    def parse(self, value, config=None, pos=None):
212:    def parse_scalar(self, value, config=None, pos=None):
233:    def output(self, value, mask):
254:    def binparse(self, read):
275:    def binoutput(self, value, mask):
308:    def __init__(self, field, config=None, pos=None):
346:    def supports_empty_values(self, config):
349:    def parse(self, value, config=None, pos=None):
360:    def output(self, value, mask):
382:    def _binparse_var(self, read):
390:    def _binparse_fixed(self, read):
398:    def _binoutput_var(self, value, mask):
412:    def _binoutput_fixed(self, value, mask):
432:    def __init__(self, field, config=None, pos=None):
464:    def parse(self, value, config=None, pos=None):
469:    def output(self, value, mask):
474:    def _binparse_var(self, read):
482:    def _binparse_fixed(self, read):
512:    def __init__(self, field, config=None, pos=None):
521:    def parse_scalar(self, value, config=None, pos=0):
525:    def _splitter_pedantic(value, config=None, pos=None):
529:    def _splitter_lax(value, config=None, pos=None):
542:    def __init__(self, field, base, arraysize, config=None, pos=None):
548:    def output(self, value, mask):
553:    def binparse(self, read):
566:    def binoutput(self, value, mask):
584:    def parse(self, value, config=None, pos=None):
608:    def parse(self, value, config=None, pos=None):
632:    def __init__(self, field, base, arraysize, config=None, pos=None):
645:    def parse(self, value, config=None, pos=None):
664:    def parse_parts(self, parts, config=None, pos=None):
676:    def output(self, value, mask):
686:    def binparse(self, read):
691:    def binoutput(self, value, mask):
706:    def __init__(self, field, config=None, pos=None):
718:    def binparse(self, read):
722:    def _is_null(self, value):
733:    def __init__(self, field, config=None, pos=None):
781:    def _parse_pedantic(self, value, config=None, pos=None):
787:    def _parse_permissive(self, value, config=None, pos=None):
799:    def output_format(self):
802:    def output(self, value, mask):
823:    def binoutput(self, value, mask):
830:    def _filter_nan(self, value, mask):
833:    def _filter_null(self, value, mask):
861:    def __init__(self, field, config=None, pos=None):
864:    def parse(self, value, config=None, pos=None):
904:    def output(self, value, mask):
912:    def binoutput(self, value, mask):
922:    def filter_array(self, value, mask):
976:    def parse(self, value, config=None, pos=None):
1000:    def parse(self, value, config=None, pos=None):
1027:    def __init__(self, field, base, arraysize, config=None, pos=None):
1031:    def parse(self, value, config=None, pos=None):
1037:    def parse_parts(self, parts, config=None, pos=None):
1062:    def __init__(self, field, config=None, pos=None):
1066:    def parse(self, value, config=None, pos=None):
1079:    def parse_parts(self, parts, config=None, pos=None):
1083:    def output(self, value, mask):
1122:    def __init__(self, field, base, arraysize, config=None, pos=None):
1137:    def output(self, value, mask):
1144:    def binparse(self, read):
1151:    def binoutput(self, value, mask):
1170:    def parse(self, value, config=None, pos=None):
1184:    def output(self, value, mask):
1193:    def binparse(self, read):
1197:    def binoutput(self, value, mask):
1213:    def binparse(self, read):
1226:    def binoutput(self, value, mask):
1247:    def parse(self, value, config=None, pos=None):
1269:    def output(self, value, mask):
1276:    def binparse(self, read):
1292:    def binparse_value(self, value):
1298:    def binoutput(self, value, mask):
astropy/utils/xml/check.py:52:def check_mime_content_type(content_type):
astropy/utils/xml/check.py:65:def check_anyuri(uri):
astropy/io/votable/ucd.py:72:def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
astropy/io/votable/ucd.py:163:def check_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
```

## 原始行 55 · command_execution

命令：
```
/bin/bash -lc "grep -n -A 8 -B 3 'class W08\\|class W46' astropy/io/votable/exceptions.py; sed -n '1,130p' astropy/io/votable/converters.py; sed -n '230,290p' astropy/io/votable/converters.py; sed -n '460,530p' astropy/io/votable/converters.py; grep -R -n \"_get_unit_format\\|_get_default_unit_format\" astropy/io/votable --include='*.py'"
```

退出码：`0`

输出：
```
455-    default_args = ("x", "y")
456-
457-
458:class W08(VOTableSpecWarning):
459-    """
460-    To avoid local-dependent number parsing differences, ``astropy.io.votable``
461-    may require a string or unicode string where a numeric type may
462-    make more sense.
463-    """
464-
465-    message_template = "'{}' must be a str or bytes object"
466-
--
1030-    default_args = ("x",)
1031-
1032-
1033:class W46(VOTableSpecWarning):
1034-    """
1035-    The given char or unicode string is too long for the specified
1036-    field length.
1037-    """
1038-
1039-    message_template = "{} value is too long for specified length of {}"
1040-    default_args = ("char or unicode", "x")
1041-
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This module handles the conversion of various VOTABLE datatypes
to/from TABLEDATA_ and BINARY_ formats.
"""

# STDLIB
import re
import struct
import sys
from math import prod

# THIRD-PARTY
import numpy as np
from numpy import ma

# ASTROPY
from astropy.utils.xml.writer import xml_escape_cdata

# LOCAL
from .exceptions import (
    E01,
    E02,
    E03,
    E04,
    E05,
    E06,
    E24,
    W01,
    W30,
    W31,
    W39,
    W46,
    W47,
    W49,
    W51,
    W55,
    vo_raise,
    vo_warn,
    warn_or_raise,
)

__all__ = ["Converter", "get_converter", "table_column_to_votable_datatype"]


pedantic_array_splitter = re.compile(r" +")
array_splitter = re.compile(r"\s+|(?:\s*,\s*)")
"""
A regex to handle splitting values on either whitespace or commas.

SPEC: Usage of commas is not actually allowed by the spec, but many
files in the wild use them.
"""

_zero_int = b"\0\0\0\0"
_empty_bytes = b""
_zero_byte = b"\0"


if sys.byteorder == "little":

    def _ensure_bigendian(x):
        if x.dtype.byteorder != ">":
            return x.byteswap()
        return x

else:

    def _ensure_bigendian(x):
        if x.dtype.byteorder == "<":
            return x.byteswap()
        return x
















def bitarray_to_bool(data, length):
    """
    Converts a bit array (a string of bits in a bytes object) to a
    boolean Numpy array.

    Parameters
    ----------
    data : bytes
        The bit array.  The most significant byte is read first.

    length : int
        The number of bits to read.  The least significant bits in the
        data bytes beyond length will be ignored.

    Returns
    -------
    array : numpy bool array
    """
    results = []
    for byte in data:
        for bit_no in range(7, -1, -1):
            bit = byte & (1 << bit_no)
            bit = bit != 0
            results.append(bit)
            if len(results) == length:
                break
        if len(results) == length:
            break

    return np.array(results, dtype="b1")


def bool_to_bitarray(value):
    """
    Converts a numpy boolean array to a bit array (a string of bits in
    a bytes object).

    Parameters
    ----------
    value : numpy bool array

    Returns
        """
        return self.parse(value, config, pos)

    def output(self, value, mask):
        """
        Convert the object *value* (in the native in-memory datatype)
        to a unicode string suitable for serializing in the TABLEDATA_
        format.

        Parameters
        ----------
        value
            The value, the native type corresponding to this converter

        mask : bool
            If `True`, will return the string representation of a
            masked value.

        Returns
        -------
        tabledata_repr : unicode
        """
        raise NotImplementedError("This datatype must implement a 'output' method.")

    def binparse(self, read):
        """
        Reads some number of bytes from the BINARY_ format
        representation by calling the function *read*, and returns the
        native in-memory object representation for the datatype
        handled by *self*.

        Parameters
        ----------
        read : function
            A function that given a number of bytes, returns a byte
            string.

        Returns
        -------
        native : (2,) tuple
            (value, mask). The value as a Numpy array or scalar, and *mask* is
            True if the value is missing.
        """
        raise NotImplementedError("This datatype must implement a 'binparse' method.")

    def binoutput(self, value, mask):
        """
        Convert the object *value* in the native in-memory datatype to
        a string of bytes suitable for serialization in the BINARY_
        format.

        Parameters
        ----------
        value
            The value, the native type corresponding to this converter

        mask : bool
            If `True`, will return the string representation of a
            masked value.

        Returns
                self.binoutput = self._binoutput_fixed

            self._struct_format = f">{self.arraysize * 2:d}s"

    def parse(self, value, config=None, pos=None):
        if self.arraysize != "*" and len(value) > self.arraysize:
            vo_warn(W46, ("unicodeChar", self.arraysize), config, pos)
        return value, False

    def output(self, value, mask):
        if mask:
            return ""
        return xml_escape_cdata(str(value))

    def _binparse_var(self, read):
        length = self._parse_length(read)

        if self.arraysize != "*" and length > self.arraysize:
            vo_warn(W46, ("unicodeChar", self.arraysize), None, None)

        return read(length * 2).decode("utf_16_be"), False

    def _binparse_fixed(self, read):
        s = struct.unpack(self._struct_format, read(self.arraysize * 2))[0]
        s = s.decode("utf_16_be")
        end = s.find("\0")
        if end != -1:
            return s[:end], False
        return s, False


















class Array(Converter):
    """
    Handles both fixed and variable-lengths arrays.
    """

    def __init__(self, field, config=None, pos=None):
        if config is None:
            config = {}
        Converter.__init__(self, field, config, pos)
        if config.get("verify", "ignore") == "exception":
            self._splitter = self._splitter_pedantic
        else:
            self._splitter = self._splitter_lax

    def parse_scalar(self, value, config=None, pos=0):
        return self._base.parse_scalar(value, config, pos)

    @staticmethod
    def _splitter_pedantic(value, config=None, pos=None):
        return pedantic_array_splitter.split(value)

    @staticmethod
    def _splitter_lax(value, config=None, pos=None):
        if "," in value:
astropy/io/votable/tests/test_tree.py:58:    assert tree._get_default_unit_format(data._config) == "cds"
astropy/io/votable/tests/test_tree.py:61:    assert tree._get_default_unit_format(data._config) == "cds"
astropy/io/votable/tests/test_tree.py:64:    assert tree._get_default_unit_format(data._config) == "cds"
astropy/io/votable/tests/test_tree.py:67:    assert tree._get_default_unit_format(data._config) == "cds"
astropy/io/votable/tests/test_tree.py:70:    assert tree._get_default_unit_format(data._config) == "vounit"
astropy/io/votable/tree.py:926:        default_format = _get_default_unit_format(self._config)
astropy/io/votable/tree.py:931:        format = _get_unit_format(self._config)
astropy/io/votable/tree.py:1587:        default_format = _get_default_unit_format(self._config)
astropy/io/votable/tree.py:1592:        format = _get_unit_format(self._config)
astropy/io/votable/tree.py:1703:            format = _get_unit_format(self._config)
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/converters.py | sed -n '45,110p'; nl -ba astropy/io/votable/converters.py | sed -n '165,295p'; grep -R -n \"_write_length\" astropy/io/votable --include='*.py'; grep -R -n \"get_first_table\" astropy --include='*.py' | head -n 50"
```

退出码：`0`

输出：
```
    45	
    46	pedantic_array_splitter = re.compile(r" +")
    47	array_splitter = re.compile(r"\s+|(?:\s*,\s*)")
    48	"""
    49	A regex to handle splitting values on either whitespace or commas.
    50	
    51	SPEC: Usage of commas is not actually allowed by the spec, but many
    52	files in the wild use them.
    53	"""
    54	
    55	_zero_int = b"\0\0\0\0"
    56	_empty_bytes = b""
    57	_zero_byte = b"\0"
    58	
    59	
    60	if sys.byteorder == "little":
    61	
    62	    def _ensure_bigendian(x):
    63	        if x.dtype.byteorder != ">":
    64	            return x.byteswap()
    65	        return x
    66	
    67	else:
    68	
    69	    def _ensure_bigendian(x):
    70	        if x.dtype.byteorder == "<":
    71	            return x.byteswap()
    72	        return x
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	def bitarray_to_bool(data, length):
    90	    """
    91	    Converts a bit array (a string of bits in a bytes object) to a
    92	    boolean Numpy array.
    93	
    94	    Parameters
    95	    ----------
    96	    data : bytes
    97	        The bit array.  The most significant byte is read first.
    98	
    99	    length : int
   100	        The number of bits to read.  The least significant bits in the
   101	        data bytes beyond length will be ignored.
   102	
   103	    Returns
   104	    -------
   105	    array : numpy bool array
   106	    """
   107	    results = []
   108	    for byte in data:
   109	        for bit_no in range(7, -1, -1):
   110	            bit = byte & (1 << bit_no)
   165	        object describing the datatype
   166	
   167	    config : dict
   168	        The parser configuration dictionary
   169	
   170	    pos : tuple
   171	        The position in the XML file where the FIELD object was
   172	        found.  Used for error messages.
   173	
   174	    """
   175	
   176	    def __init__(self, field, config=None, pos=None):
   177	        pass
   178	
   179	    @staticmethod
   180	    def _parse_length(read):
   181	        return struct.unpack(">I", read(4))[0]
   182	
   183	
   184	
   185	
   186	
   187	    def supports_empty_values(self, config):
   188	        """
   189	        Returns True when the field can be completely empty.
   190	        """
   191	        return config.get("version_1_3_or_later")
   192	
   193	    def parse(self, value, config=None, pos=None):
   194	        """
   195	        Convert the string *value* from the TABLEDATA_ format into an
   196	        object with the correct native in-memory datatype and mask flag.
   197	
   198	        Parameters
   199	        ----------
   200	        value : str
   201	            value in TABLEDATA format
   202	
   203	        Returns
   204	        -------
   205	        native : tuple
   206	            A two-element tuple of: value, mask.
   207	            The value as a Numpy array or scalar, and *mask* is True
   208	            if the value is missing.
   209	        """
   210	        raise NotImplementedError("This datatype must implement a 'parse' method.")
   211	
   212	    def parse_scalar(self, value, config=None, pos=None):
   213	        """
   214	        Parse a single scalar of the underlying type of the converter.
   215	        For non-array converters, this is equivalent to parse.  For
   216	        array converters, this is used to parse a single
   217	        element of the array.
   218	
   219	        Parameters
   220	        ----------
   221	        value : str
   222	            value in TABLEDATA format
   223	
   224	        Returns
   225	        -------
   226	        native : (2,) tuple
   227	            (value, mask)
   228	            The value as a Numpy array or scalar, and *mask* is True
   229	            if the value is missing.
   230	        """
   231	        return self.parse(value, config, pos)
   232	
   233	    def output(self, value, mask):
   234	        """
   235	        Convert the object *value* (in the native in-memory datatype)
   236	        to a unicode string suitable for serializing in the TABLEDATA_
   237	        format.
   238	
   239	        Parameters
   240	        ----------
   241	        value
   242	            The value, the native type corresponding to this converter
   243	
   244	        mask : bool
   245	            If `True`, will return the string representation of a
   246	            masked value.
   247	
   248	        Returns
   249	        -------
   250	        tabledata_repr : unicode
   251	        """
   252	        raise NotImplementedError("This datatype must implement a 'output' method.")
   253	
   254	    def binparse(self, read):
   255	        """
   256	        Reads some number of bytes from the BINARY_ format
   257	        representation by calling the function *read*, and returns the
   258	        native in-memory object representation for the datatype
   259	        handled by *self*.
   260	
   261	        Parameters
   262	        ----------
   263	        read : function
   264	            A function that given a number of bytes, returns a byte
   265	            string.
   266	
   267	        Returns
   268	        -------
   269	        native : (2,) tuple
   270	            (value, mask). The value as a Numpy array or scalar, and *mask* is
   271	            True if the value is missing.
   272	        """
   273	        raise NotImplementedError("This datatype must implement a 'binparse' method.")
   274	
   275	    def binoutput(self, value, mask):
   276	        """
   277	        Convert the object *value* in the native in-memory datatype to
   278	        a string of bytes suitable for serialization in the BINARY_
   279	        format.
   280	
   281	        Parameters
   282	        ----------
   283	        value
   284	            The value, the native type corresponding to this converter
   285	
   286	        mask : bool
   287	            If `True`, will return the string representation of a
   288	            masked value.
   289	
   290	        Returns
   291	        -------
   292	        bytes : bytes
   293	            The binary representation of the value, suitable for
   294	            serialization in the BINARY_ format.
   295	        """
astropy/io/votable/converters.py:410:        return self._write_length(len(value)) + value
astropy/io/votable/converters.py:571:        result = [self._write_length(length)]
astropy/table/table_helpers.py:97:    first_table = votable.get_first_table()
astropy/io/votable/table.py:184:    return votable.get_first_table()
astropy/io/votable/tests/test_table.py:66:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:73:    t = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:172:    table = votable.get_first_table().to_table(use_names_over_ids=True)
astropy/io/votable/tests/test_table.py:199:    table = votable.get_first_table().to_table(use_names_over_ids=False)
astropy/io/votable/tests/test_table.py:237:    table = parse(fpath).get_first_table().to_table()
astropy/io/votable/tests/test_table.py:447:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:453:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:472:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:530:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:544:    table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:592:        table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:643:    table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:666:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:683:    table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:750:        field = votable2.get_first_table().fields[0]
astropy/io/votable/tests/test_table.py:795:        table2 = votable2.get_first_table()
astropy/io/votable/tests/test_vo.py:77:    table = votable.get_first_table()
astropy/io/votable/tests/test_vo.py:126:        votable.get_first_table().format = "binary"
astropy/io/votable/tests/test_vo.py:129:        votable.get_first_table()._config["version_1_3_or_later"] = True
astropy/io/votable/tests/test_vo.py:130:        votable.get_first_table().format = "binary2"
astropy/io/votable/tests/test_vo.py:140:    votable2.get_first_table().format = "tabledata"
astropy/io/votable/tests/test_vo.py:209:            ).get_first_table()
astropy/io/votable/tests/test_vo.py:222:        self.table = self.votable.get_first_table()
astropy/io/votable/tests/test_vo.py:283:    ).get_first_table()
astropy/io/votable/tests/test_vo.py:300:    ).get_first_table()
astropy/io/votable/tests/test_vo.py:400:        self.table = self.votable.get_first_table()
astropy/io/votable/tests/test_vo.py:726:        self.table = self.votable.get_first_table()
astropy/io/votable/tests/test_vo.py:753:        votable.get_first_table().format = "binary"
astropy/io/votable/tests/test_vo.py:762:        self.table = self.votable.get_first_table()
astropy/io/votable/tests/test_vo.py:797:        votable.get_first_table()._config["version_1_3_or_later"] = True
astropy/io/votable/tests/test_vo.py:798:        votable.get_first_table().format = "binary2"
astropy/io/votable/tests/test_vo.py:807:        self.table = self.votable.get_first_table()
astropy/io/votable/tests/test_vo.py:821:        table = self.votable.get_first_table()
astropy/io/votable/tests/test_vo.py:835:        votable.get_first_table()._config["version_1_3_or_later"] = True
astropy/io/votable/tests/test_vo.py:836:    votable.get_first_table().format = format_
astropy/io/votable/tests/test_vo.py:844:    table = votable.get_first_table().to_table()
astropy/io/votable/tests/test_vo.py:937:    table = votable.get_first_table()
astropy/io/votable/tests/test_vo.py:1070:    assert isinstance(votable.get_first_table().fields[0].unit, u.UnrecognizedUnit)
astropy/io/votable/tests/test_vo.py:1076:    assert not isinstance(votable.get_first_table().fields[0].unit, u.UnrecognizedUnit)
astropy/io/votable/tests/test_vo.py:1169:    table = votable.get_first_table()
```

## 原始行 61 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from pathlib import Path
for f in ['astropy/utils/xml/check.py','astropy/io/votable/ucd.py','astropy/io/votable/converters.py','astropy/io/votable/tree.py']:
    lines=Path(f).read_text().splitlines()
    print(f)
    start=None
    for i,l in enumerate(lines,1):
        if not l.strip():
            if start is None:start=i
        elif start is not None:
            if i-start>=4: print(start,i-1,i-start)
            start=None
PY
pytest -q astropy/utils/tests/test_xml.py astropy/io/votable/tests/test_ucd.py astropy/io/votable/tests/test_tree.py astropy/io/votable/tests/test_table.py --disable-warnings --maxfail=5"
```

退出码：`1`

输出：
```
astropy/utils/xml/check.py
9 36 28
38 51 14
astropy/io/votable/ucd.py
22 54 33
61 68 8
astropy/io/votable/converters.py
73 88 16
182 186 5
489 506 18
777 780 4
1126 1136 11
astropy/io/votable/tree.py
242 266 25
317 341 25
1190 1235 46
1718 1750 33
2705 2713 9
3496 3545 50
3953 3962 10
4497 4507 11
Internet access disabled
.FFF.....s.F...F
=================================== FAILURES ===================================
________________________________ test_check_id _________________________________

    def test_check_id():
>       assert check.check_id("Fof32")
               ^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'check_id'

astropy/utils/tests/test_xml.py:24: AttributeError
_________________________________ test_fix_id __________________________________

    def test_fix_id():
>       assert check.fix_id("Fof32") == "Fof32"
               ^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'fix_id'

astropy/utils/tests/test_xml.py:30: AttributeError
_______________________________ test_check_token _______________________________

    def test_check_token():
>       assert check.check_token("token")
               ^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'check_token'

astropy/utils/tests/test_xml.py:35: AttributeError
__________________________________ test_check __________________________________

    def test_check():
        for s, p in examples.items():
>           assert ucd.parse_ucd(s, True, True) == p
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_ucd.py:55: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ucd = 'phys.temperature', check_controlled_vocabulary = True, has_colon = True

    def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
        """
        Parse the UCD into its component parts.
    
        Parameters
        ----------
        ucd : str
            The UCD string
    
        check_controlled_vocabulary : bool, optional
            If `True`, then each word in the UCD will be verified against
            the UCD1+ controlled vocabulary, (as required by the VOTable
            specification version 1.2), otherwise not.
    
        has_colon : bool, optional
            If `True`, the UCD may contain a colon (as defined in earlier
            versions of the standard).
    
        Returns
        -------
        parts : list
            The result is a list of tuples of the form:
    
                (*namespace*, *word*)
    
            If no namespace was explicitly specified, *namespace* will be
            returned as ``'ivoa'`` (i.e., the default namespace).
    
        Raises
        ------
        ValueError
            if *ucd* is invalid
        """
        global _ucd_singleton
        if _ucd_singleton is None:
            _ucd_singleton = UCDWords()
    
        if has_colon:
            m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
        else:
            m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
        if m is not None:
            raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")
    
        word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
        word_re = rf"{word_component_re}(\.{word_component_re})*"
    
        parts = ucd.split(";")
        words = []
        for i, word in enumerate(parts):
            colon_count = word.count(":")
            if colon_count == 1:
                ns, word = word.split(":", 1)
                if not re.match(word_component_re, ns):
                    raise ValueError(f"Invalid namespace '{ns}'")
                ns = ns.lower()
            elif colon_count > 1:
                raise ValueError(f"Too many colons in '{word}'")
            else:
                ns = "ivoa"
    
            if not re.match(word_re, word):
                raise ValueError(f"Invalid word '{word}'")
    
            if ns == "ivoa" and check_controlled_vocabulary:
                if i == 0:
>                   if not _ucd_singleton.is_primary(word):
                           ^^^^^^^^^^^^^^^^^^^^^^^^^
E                   AttributeError: 'UCDWords' object has no attribute 'is_primary'

astropy/io/votable/ucd.py:138: AttributeError
__________________________ test_atmospheric_wind_ucd ___________________________

    def test_atmospheric_wind_ucd():
        """Test parsing of atmospheric observation UCDs, specifically obs.atmos.wind.
    
        This test addresses issue #18452 where obs.atmos.wind and other new
        atmospheric terms from UCD1+ version 1.6 should be recognized.
        """
        # Test the specific case from the issue report
        ucd_string = "phys.veloc;obs.atmos.wind;stat.mean"
>       result = ucd.parse_ucd(ucd_string, check_controlled_vocabulary=True)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_ucd.py:82: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ucd = 'phys.veloc;obs.atmos.wind;stat.mean', check_controlled_vocabulary = True
has_colon = False

    def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
        """
        Parse the UCD into its component parts.
    
        Parameters
        ----------
        ucd : str
            The UCD string
    
        check_controlled_vocabulary : bool, optional
            If `True`, then each word in the UCD will be verified against
            the UCD1+ controlled vocabulary, (as required by the VOTable
            specification version 1.2), otherwise not.
    
        has_colon : bool, optional
            If `True`, the UCD may contain a colon (as defined in earlier
            versions of the standard).
    
        Returns
        -------
        parts : list
            The result is a list of tuples of the form:
    
                (*namespace*, *word*)
    
            If no namespace was explicitly specified, *namespace* will be
            returned as ``'ivoa'`` (i.e., the default namespace).
    
        Raises
        ------
        ValueError
            if *ucd* is invalid
        """
        global _ucd_singleton
        if _ucd_singleton is None:
            _ucd_singleton = UCDWords()
    
        if has_colon:
            m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
        else:
            m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
        if m is not None:
            raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")
    
        word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
        word_re = rf"{word_component_re}(\.{word_component_re})*"
    
        parts = ucd.split(";")
        words = []
        for i, word in enumerate(parts):
            colon_count = word.count(":")
            if colon_count == 1:
                ns, word = word.split(":", 1)
                if not re.match(word_component_re, ns):
                    raise ValueError(f"Invalid namespace '{ns}'")
                ns = ns.lower()
            elif colon_count > 1:
                raise ValueError(f"Too many colons in '{word}'")
            else:
                ns = "ivoa"
    
            if not re.match(word_re, word):
                raise ValueError(f"Invalid word '{word}'")
    
            if ns == "ivoa" and check_controlled_vocabulary:
                if i == 0:
>                   if not _ucd_singleton.is_primary(word):
                           ^^^^^^^^^^^^^^^^^^^^^^^^^
E                   AttributeError: 'UCDWords' object has no attribute 'is_primary'

astropy/io/votable/ucd.py:138: AttributeError
=========================== short test summary info ============================
FAILED astropy/utils/tests/test_xml.py::test_check_id - AttributeError: modul...
FAILED astropy/utils/tests/test_xml.py::test_fix_id - AttributeError: module ...
FAILED astropy/utils/tests/test_xml.py::test_check_token - AttributeError: mo...
FAILED astropy/io/votable/tests/test_ucd.py::test_check - AttributeError: 'UC...
FAILED astropy/io/votable/tests/test_ucd.py::test_atmospheric_wind_ucd - Attr...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 5 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
5 failed, 10 passed, 1 skipped in 0.11s
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/converters.py | sed -n '1090,1160p'; nl -ba astropy/io/votable/tree.py | sed -n '2200,2490p'; nl -ba astropy/io/votable/tree.py | sed -n '4660,4745p'; sed -n '1,160p' astropy/io/votable/tests/test_resource.py"
```

退出码：`0`

输出：
```
  1090	        imag = self._output_format.format(float(value.imag))
  1091	        if self._output_format[2] == "s":
  1092	            real = real.removesuffix(".0")
  1093	            imag = imag.removesuffix(".0")
  1094	        return real + " " + imag
  1095	
  1096	
  1097	class FloatComplex(Complex):
  1098	    """
  1099	    Handle floatComplex datatype.  Pair of single-precision IEEE
  1100	    floating-point numbers.
  1101	    """
  1102	
  1103	    format = "c8"
  1104	
  1105	
  1106	class DoubleComplex(Complex):
  1107	    """
  1108	    Handle doubleComplex datatype.  Pair of double-precision IEEE
  1109	    floating-point numbers.
  1110	    """
  1111	
  1112	    format = "c16"
  1113	
  1114	
  1115	class BitArray(NumericArray):
  1116	    """
  1117	    Handles an array of bits.
  1118	    """
  1119	
  1120	    vararray_type = ArrayVarArray
  1121	
  1122	    def __init__(self, field, base, arraysize, config=None, pos=None):
  1123	        NumericArray.__init__(self, field, base, arraysize, config, pos)
  1124	
  1125	        self._bytes = ((self._items - 1) // 8) + 1
  1126	
  1127	
  1128	
  1129	
  1130	
  1131	
  1132	
  1133	
  1134	
  1135	
  1136	
  1137	    def output(self, value, mask):
  1138	        if np.any(mask):
  1139	            vo_warn(W39)
  1140	        value = np.asarray(value)
  1141	        mapping = {False: "0", True: "1"}
  1142	        return "".join(mapping[x] for x in value.flat)
  1143	
  1144	    def binparse(self, read):
  1145	        data = read(self._bytes)
  1146	        result = bitarray_to_bool(data, self._items)
  1147	        result = result.reshape(self._arraysize)
  1148	        result_mask = np.zeros(self._arraysize, dtype="b1")
  1149	        return result, result_mask
  1150	
  1151	    def binoutput(self, value, mask):
  1152	        if np.any(mask):
  1153	            vo_warn(W39)
  1154	
  1155	        return bool_to_bitarray(value)
  1156	
  1157	
  1158	class Bit(Converter):
  1159	    """
  1160	    Handles the bit datatype.
  2200	
  2201	    def __init__(
  2202	        self, table, ref, ucd=None, utype=None, config=None, pos=None, **extra
  2203	    ):
  2204	        """
  2205	        *table* is the :class:`TableElement` object that this :class:`FieldRef`
  2206	        is a member of.
  2207	
  2208	        *ref* is the ID to reference a :class:`Field` object defined
  2209	        elsewhere.
  2210	        """
  2211	        if config is None:
  2212	            config = {}
  2213	        self._config = config
  2214	        self._pos = pos
  2215	
  2216	        SimpleElement.__init__(self)
  2217	        self._table = table
  2218	        self.ref = ref
  2219	        self.ucd = ucd
  2220	        self.utype = utype
  2221	
  2222	        if config.get("version_1_2_or_later"):
  2223	            self._attr_list = self._attr_list_12
  2224	        else:
  2225	            self._attr_list = self._attr_list_11
  2226	            if ucd is not None:
  2227	                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
  2228	            if utype is not None:
  2229	                warn_unknown_attrs(self._element_name, ["utype"], config, pos)
  2230	
  2231	    @property
  2232	    def ref(self):
  2233	        """The ID_ of the FIELD_ that this FIELDref_ references."""
  2234	        return self._ref
  2235	
  2236	    @ref.setter
  2237	    def ref(self, ref):
  2238	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  2239	        self._ref = ref
  2240	
  2241	    @ref.deleter
  2242	    def ref(self):
  2243	        self._ref = None
  2244	
  2245	    def get_ref(self):
  2246	        """
  2247	        Lookup the :class:`Field` instance that this :class:`FieldRef`
  2248	        references.
  2249	        """
  2250	        for field in self._table._votable.iter_fields_and_params():
  2251	            if isinstance(field, Field) and field.ID == self.ref:
  2252	                return field
  2253	        vo_raise(KeyError, f"No field named '{self.ref}'", self._config, self._pos)
  2254	
  2255	
  2256	class ParamRef(SimpleElement, _UtypeProperty, _UcdProperty):
  2257	    """
  2258	    PARAMref_ element: used inside of GROUP_ elements to refer to remote PARAM_ elements.
  2259	
  2260	    The keyword arguments correspond to setting members of the same
  2261	    name, documented below.
  2262	
  2263	    It contains the following publicly-accessible members:
  2264	
  2265	      *ref*: An XML ID referring to a <PARAM> element.
  2266	    """
  2267	
  2268	    _attr_list_11 = ["ref"]
  2269	    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
  2270	    _element_name = "PARAMref"
  2271	    _utype_in_v1_2 = True
  2272	    _ucd_in_v1_2 = True
  2273	
  2274	    def __init__(self, table, ref, ucd=None, utype=None, config=None, pos=None):
  2275	        if config is None:
  2276	            config = {}
  2277	
  2278	        self._config = config
  2279	        self._pos = pos
  2280	
  2281	        Element.__init__(self)
  2282	        self._table = table
  2283	        self.ref = ref
  2284	        self.ucd = ucd
  2285	        self.utype = utype
  2286	
  2287	        if config.get("version_1_2_or_later"):
  2288	            self._attr_list = self._attr_list_12
  2289	        else:
  2290	            self._attr_list = self._attr_list_11
  2291	            if ucd is not None:
  2292	                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
  2293	            if utype is not None:
  2294	                warn_unknown_attrs(self._element_name, ["utype"], config, pos)
  2295	
  2296	    @property
  2297	    def ref(self):
  2298	        """The ID_ of the PARAM_ that this PARAMref_ references."""
  2299	        return self._ref
  2300	
  2301	    @ref.setter
  2302	    def ref(self, ref):
  2303	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  2304	        self._ref = ref
  2305	
  2306	    @ref.deleter
  2307	    def ref(self):
  2308	        self._ref = None
  2309	
  2310	    def get_ref(self):
  2311	        """
  2312	        Lookup the :class:`Param` instance that this :class:``PARAMref``
  2313	        references.
  2314	        """
  2315	        for param in self._table._votable.iter_fields_and_params():
  2316	            if isinstance(param, Param) and param.ID == self.ref:
  2317	                return param
  2318	        vo_raise(KeyError, f"No params named '{self.ref}'", self._config, self._pos)
  2319	
  2320	
  2321	class Group(
  2322	    Element,
  2323	    _IDProperty,
  2324	    _NameProperty,
  2325	    _UtypeProperty,
  2326	    _UcdProperty,
  2327	    _DescriptionProperty,
  2328	):
  2329	    """
  2330	    GROUP_ element: groups FIELD_ and PARAM_ elements.
  2331	
  2332	    This information is currently ignored by the vo package---that is
  2333	    the columns in the recarray are always flat---but the grouping
  2334	    information is stored so that it can be written out again to the
  2335	    XML file.
  2336	
  2337	    The keyword arguments correspond to setting members of the same
  2338	    name, documented below.
  2339	    """
  2340	
  2341	    def __init__(
  2342	        self,
  2343	        table,
  2344	        ID=None,
  2345	        name=None,
  2346	        ref=None,
  2347	        ucd=None,
  2348	        utype=None,
  2349	        id=None,
  2350	        config=None,
  2351	        pos=None,
  2352	        **extra,
  2353	    ):
  2354	        if config is None:
  2355	            config = {}
  2356	        self._config = config
  2357	        self._pos = pos
  2358	
  2359	        Element.__init__(self)
  2360	        self._table = table
  2361	
  2362	        self.ID = resolve_id(ID, id, config, pos) or xmlutil.fix_id(name, config, pos)
  2363	        self.name = name
  2364	        self.ref = ref
  2365	        self.ucd = ucd
  2366	        self.utype = utype
  2367	        self.description = None
  2368	
  2369	        self._entries = HomogeneousList((FieldRef, ParamRef, Group, Param))
  2370	
  2371	        warn_unknown_attrs("GROUP", extra.keys(), config, pos)
  2372	
  2373	    def __repr__(self):
  2374	        return f"<GROUP>... {len(self._entries)} entries ...</GROUP>"
  2375	
  2376	    @property
  2377	    def ref(self):
  2378	        """
  2379	        Currently ignored, as it's not clear from the spec how this is
  2380	        meant to work.
  2381	        """
  2382	        return self._ref
  2383	
  2384	    @ref.setter
  2385	    def ref(self, ref):
  2386	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  2387	        self._ref = ref
  2388	
  2389	    @ref.deleter
  2390	    def ref(self):
  2391	        self._ref = None
  2392	
  2393	    @property
  2394	    def entries(self):
  2395	        """
  2396	        [read-only] A list of members of the GROUP_.  This list may
  2397	        only contain objects of type :class:`Param`, :class:`Group`,
  2398	        :class:`ParamRef` and :class:`FieldRef`.
  2399	        """
  2400	        return self._entries
  2401	
  2402	    def _add_fieldref(self, iterator, tag, data, config, pos):
  2403	        fieldref = FieldRef(self._table, config=config, pos=pos, **data)
  2404	        self.entries.append(fieldref)
  2405	
  2406	    def _add_paramref(self, iterator, tag, data, config, pos):
  2407	        paramref = ParamRef(self._table, config=config, pos=pos, **data)
  2408	        self.entries.append(paramref)
  2409	
  2410	    def _add_param(self, iterator, tag, data, config, pos):
  2411	        if isinstance(self._table, VOTableFile):
  2412	            votable = self._table
  2413	        else:
  2414	            votable = self._table._votable
  2415	        param = Param(votable, config=config, pos=pos, **data)
  2416	        self.entries.append(param)
  2417	        param.parse(iterator, config)
  2418	
  2419	    def _add_group(self, iterator, tag, data, config, pos):
  2420	        group = Group(self._table, config=config, pos=pos, **data)
  2421	        self.entries.append(group)
  2422	        group.parse(iterator, config)
  2423	
  2424	    def parse(self, iterator, config):
  2425	        tag_mapping = {
  2426	            "FIELDref": self._add_fieldref,
  2427	            "PARAMref": self._add_paramref,
  2428	            "PARAM": self._add_param,
  2429	            "GROUP": self._add_group,
  2430	            "DESCRIPTION": self._ignore_add,
  2431	        }
  2432	
  2433	        for start, tag, data, pos in iterator:
  2434	            if start:
  2435	                tag_mapping.get(tag, self._add_unknown_tag)(
  2436	                    iterator, tag, data, config, pos
  2437	                )
  2438	            else:
  2439	                if tag == "DESCRIPTION":
  2440	                    if self.description is not None:
  2441	                        warn_or_raise(W17, W17, "GROUP", config, pos)
  2442	                    self.description = data or None
  2443	                elif tag == "GROUP":
  2444	                    break
  2445	        return self
  2446	
  2447	    def to_xml(self, w, **kwargs):
  2448	        with w.tag(
  2449	            "GROUP", attrib=w.object_attrs(self, ["ID", "name", "ref", "ucd", "utype"])
  2450	        ):
  2451	            if self.description is not None:
  2452	                w.element("DESCRIPTION", self.description, wrap=True)
  2453	            for entry in self.entries:
  2454	                entry.to_xml(w, **kwargs)
  2455	
  2456	    def iter_fields_and_params(self):
  2457	        """
  2458	        Recursively iterate over all :class:`Param` elements in this
  2459	        :class:`Group`.
  2460	        """
  2461	        for entry in self.entries:
  2462	            if isinstance(entry, Param):
  2463	                yield entry
  2464	            elif isinstance(entry, Group):
  2465	                yield from entry.iter_fields_and_params()
  2466	
  2467	    def iter_groups(self):
  2468	        """
  2469	        Recursively iterate over all sub-:class:`Group` instances in
  2470	        this :class:`Group`.
  2471	        """
  2472	        for entry in self.entries:
  2473	            if isinstance(entry, Group):
  2474	                yield entry
  2475	                yield from entry.iter_groups()
  2476	
  2477	
  2478	class TableElement(
  2479	    Element, _IDProperty, _NameProperty, _UcdProperty, _DescriptionProperty
  2480	):
  2481	    """
  2482	    TABLE_ element: optionally contains data.
  2483	
  2484	    It contains the following publicly-accessible and mutable
  2485	    attribute:
  2486	
  2487	        *array*: A Numpy masked array of the data itself, where each
  2488	        row is a row of votable data, and columns are named and typed
  2489	        based on the <FIELD> elements of the table.  The mask is
  2490	        parallel to the data array, except for variable-length fields.
  4660	    def iter_info(self):
  4661	        """
  4662	        Recursively iterate over all INFO_ elements in the VOTABLE_
  4663	        file.
  4664	        """
  4665	        yield from self.infos
  4666	        for resource in self.resources:
  4667	            yield from resource.iter_info()
  4668	
  4669	    get_info_by_id = _lookup_by_attr_factory(
  4670	        "ID", True, "iter_info", "INFO", """Looks up a INFO element by the given ID."""
  4671	    )
  4672	
  4673	    get_infos_by_name = _lookup_by_attr_factory(
  4674	        "name",
  4675	        False,
  4676	        "iter_info",
  4677	        "INFO",
  4678	        """Returns all INFO children with the given name.""",
  4679	    )
  4680	
  4681	    def set_all_tables_format(self, format):
  4682	        """
  4683	        Set the output storage format of all tables in the file.
  4684	        """
  4685	        for table in self.iter_tables():
  4686	            table.format = format
  4687	
  4688	    @classmethod
  4689	    def from_table(cls, table, table_id=None):
  4690	        """
  4691	        Create a `VOTableFile` instance from a given
  4692	        `astropy.table.Table` instance.
  4693	
  4694	        Parameters
  4695	        ----------
  4696	        table_id : str, optional
  4697	            Set the given ID attribute on the returned TableElement instance.
  4698	        """
  4699	        votable_file = cls()
  4700	        resource = Resource()
  4701	        votable = TableElement.from_table(votable_file, table)
  4702	        if table_id is not None:
  4703	            votable.ID = table_id
  4704	        resource.tables.append(votable)
  4705	        votable_file.resources.append(resource)
  4706	        return votable_file
# Licensed under a 3-clause BSD style license - see LICENSE.rst
# LOCAL
import io

from astropy.io.votable import parse
from astropy.utils.data import get_pkg_data_filename


def test_resource_groups():
    # Read the VOTABLE
    votable = parse(get_pkg_data_filename("data/resource_groups.xml"))

    resource = votable.resources[0]
    groups = resource.groups
    params = resource.params

    # Test that params inside groups are not outside

    assert len(groups[0].entries) == 1
    assert groups[0].entries[0].name == "ID"

    assert len(params) == 2
    assert params[0].name == "standardID"
    assert params[1].name == "accessURL"


def test_roundtrip():
    # Issue #16511 VOTable writer does not write out GROUPs within RESOURCEs

    # Read the VOTABLE
    votable = parse(get_pkg_data_filename("data/resource_groups.xml"))

    bio = io.BytesIO()
    votable.to_xml(bio)
    bio.seek(0)
    votable = parse(bio)

    resource = votable.resources[0]
    groups = resource.groups
    params = resource.params

    # Test that params inside groups are not outside

    assert len(groups[0].entries) == 1
    assert groups[0].entries[0].name == "ID"

    assert len(params) == 2
    assert params[0].name == "standardID"
    assert params[1].name == "accessURL"
```

## 原始行 69 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"get_pkg_data_contents(.*encoding\\|get_pkg_data_contents\" astropy | head -n 30; grep -n -E '"'^[A-Z]'"' astropy/io/votable/data/ucd1p-words.txt | cut -d'|' -f1 | sort | uniq -c; grep -n '"'^E'"\\|"'^V'"\\|"'^C'"' astropy/io/votable/data/ucd1p-words.txt | head -n 20"
```

退出码：`0`

输出：
```
astropy/coordinates/funcs.py:219:        cdata = data.get_pkg_data_contents("data/constellation_data_roman87.dat")
astropy/coordinates/funcs.py:221:        cnames = data.get_pkg_data_contents(
astropy/coordinates/sites.py:19:from astropy.utils.data import get_file_contents, get_pkg_data_contents
astropy/coordinates/sites.py:137:        content = get_pkg_data_contents("coordinates/sites.json", encoding="UTF-8")
astropy/coordinates/tests/accuracy/test_fk4_no_e_fk4.py:11:from astropy.utils.data import get_pkg_data_contents
astropy/coordinates/tests/accuracy/test_fk4_no_e_fk4.py:23:    lines = get_pkg_data_contents("data/fk4_no_e_fk4.csv").split("\n")
astropy/coordinates/tests/accuracy/test_icrs_fk5.py:11:from astropy.utils.data import get_pkg_data_contents
astropy/coordinates/tests/accuracy/test_icrs_fk5.py:20:    lines = get_pkg_data_contents("data/icrs_fk5.csv").split("\n")
astropy/coordinates/tests/accuracy/test_fk4_no_e_fk5.py:11:from astropy.utils.data import get_pkg_data_contents
astropy/coordinates/tests/accuracy/test_fk4_no_e_fk5.py:20:    lines = get_pkg_data_contents("data/fk4_no_e_fk5.csv").split("\n")
astropy/coordinates/tests/accuracy/test_galactic_fk4.py:11:from astropy.utils.data import get_pkg_data_contents
astropy/coordinates/tests/accuracy/test_galactic_fk4.py:20:    lines = get_pkg_data_contents("data/galactic_fk4.csv").split("\n")
astropy/coordinates/tests/test_sky_coord.py:1291:    from astropy.utils.data import get_pkg_data_contents
astropy/coordinates/tests/test_sky_coord.py:1295:    header = get_pkg_data_contents(
astropy/wcs/tests/test_pickle.py:13:    get_pkg_data_contents,
astropy/wcs/tests/test_pickle.py:96:    header = get_pkg_data_contents(
astropy/wcs/tests/test_utils.py:28:from astropy.utils.data import get_pkg_data_contents, get_pkg_data_filename
astropy/wcs/tests/test_utils.py:840:    header = get_pkg_data_contents("data/maps/1904-66_TAN.hdr", encoding="binary")
astropy/wcs/tests/test_utils.py:872:    header = get_pkg_data_contents("data/maps/1904-66_TAN.hdr", encoding="binary")
astropy/wcs/tests/test_wcs.py:29:    get_pkg_data_contents,
astropy/wcs/tests/test_wcs.py:88:            header = get_pkg_data_contents(
astropy/wcs/tests/test_wcs.py:122:            header = get_pkg_data_contents(
astropy/wcs/tests/test_wcs.py:146:    header = get_pkg_data_contents("data/nonstandard_units.hdr", encoding="binary")
astropy/wcs/tests/test_wcs.py:171:    header = get_pkg_data_contents("data/outside_sky.hdr", encoding="binary")
astropy/wcs/tests/test_wcs.py:370:    header = get_pkg_data_contents("data/defunct_keywords.hdr", encoding="binary")
astropy/wcs/tests/test_wcs.py:388:    header = get_pkg_data_contents("data/defunct_keywords.hdr", encoding="binary")
astropy/wcs/tests/test_wcs.py:695:    header = get_pkg_data_contents("data/validate.fits", encoding="binary")
astropy/wcs/tests/test_wcs.py:706:    header = get_pkg_data_contents("data/nonstandard_units.hdr", encoding="binary")
astropy/wcs/tests/test_wcs.py:715:    header = get_pkg_data_contents("data/unit.hdr", encoding="binary")
astropy/wcs/tests/test_wcs.py:789:    header = get_pkg_data_contents("data/invalid_header.hdr", encoding="binary")
      1 100:Q 
      1 101:Q 
      1 102:Q 
      1 103:S 
      1 104:S 
      1 105:Q 
      1 106:Q 
      1 107:Q 
      1 108:Q 
      1 109:Q 
      1 10:S 
      1 110:Q 
      1 111:Q 
      1 112:Q 
      1 113:Q 
      1 114:Q 
      1 115:Q 
      1 116:S 
      1 117:P 
      1 118:P 
      1 119:P 
      1 11:Q 
      1 120:P 
      1 121:P 
      1 122:P 
      1 123:P 
      1 124:P 
      1 125:P 
      1 126:Q 
      1 127:Q 
      1 128:P 
      1 129:P 
      1 12:S 
      1 130:P 
      1 131:P 
      1 132:P 
      1 133:P 
      1 134:P 
      1 135:P 
      1 136:Q 
      1 137:P 
      1 138:Q 
      1 139:Q 
      1 13:S 
      1 140:Q 
      1 141:S 
      1 142:S 
      1 143:P 
      1 144:P 
      1 145:P 
      1 146:P 
      1 147:P 
      1 148:P 
      1 149:P 
      1 14:S 
      1 150:S 
      1 151:S 
      1 152:P 
      1 153:P 
      1 154:S 
      1 155:Q 
      1 156:P 
      1 157:P 
      1 158:P 
      1 159:P 
      1 15:S 
      1 160:Q 
      1 161:P 
      1 162:P 
      1 163:P 
      1 164:P 
      1 165:P 
      1 166:S 
      1 167:S 
      1 168:P 
      1 169:Q 
      1 16:S 
      1 170:P 
      1 171:P 
      1 172:S 
      1 173:Q 
      1 174:S 
      1 175:Q 
      1 176:Q 
      1 177:Q 
      1 178:Q 
      1 179:S 
      1 17:S 
      1 180:P 
      1 181:Q 
      1 182:S 
      1 183:S 
      1 184:S 
      1 185:S 
      1 186:S 
      1 187:S 
      1 188:S 
      1 189:Q 
      1 18:S 
      1 190:S 
      1 191:S 
      1 192:Q 
      1 193:S 
      1 194:Q 
      1 195:S 
      1 196:E 
      1 197:E 
      1 198:Q 
      1 199:C 
      1 19:S 
      1 200:Q 
      1 201:Q 
      1 202:E 
      1 203:E 
      1 204:E 
      1 205:Q 
      1 206:E 
      1 207:E 
      1 208:E 
      1 209:E 
      1 20:S 
      1 210:E 
      1 211:E 
      1 212:Q 
      1 213:Q 
      1 214:E 
      1 215:E 
      1 216:E 
      1 217:Q 
      1 218:Q 
      1 219:E 
      1 21:S 
      1 220:Q 
      1 221:Q 
      1 222:Q 
      1 223:Q 
      1 224:Q 
      1 225:Q 
      1 226:Q 
      1 227:Q 
      1 228:Q 
      1 229:S 
      1 22:S 
      1 230:Q 
      1 231:Q 
      1 232:Q 
      1 233:E 
      1 234:E 
      1 235:E 
      1 236:Q 
      1 237:S 
      1 238:Q 
      1 239:S 
      1 23:S 
      1 240:Q 
      1 241:Q 
      1 242:Q 
      1 243:Q 
      1 244:Q 
      1 245:Q 
      1 246:Q 
      1 247:Q 
      1 248:S 
      1 249:Q 
      1 24:S 
      1 250:S 
      1 251:Q 
      1 252:Q 
      1 253:Q 
      1 254:Q 
      1 255:Q 
      1 256:Q 
      1 257:Q 
      1 258:Q 
      1 259:Q 
      1 25:S 
      1 260:Q 
      1 261:Q 
      1 262:S 
      1 263:Q 
      1 264:Q 
      1 265:Q 
      1 266:Q 
      1 267:S 
      1 268:Q 
      1 269:Q 
      1 26:S 
      1 270:S 
      1 271:Q 
      1 272:Q 
      1 273:Q 
      1 274:Q 
      1 275:Q 
      1 276:Q 
      1 277:Q 
      1 278:S 
      1 279:Q 
      1 27:S 
      1 280:V 
      1 281:S 
      1 282:Q 
      1 283:Q 
      1 284:Q 
      1 285:Q 
      1 286:Q 
      1 287:Q 
      1 288:Q 
      1 289:Q 
      1 28:S 
      1 290:Q 
      1 291:Q 
      1 292:Q 
      1 293:E 
      1 294:Q 
      1 295:Q 
      1 296:Q 
      1 297:Q 
      1 298:Q 
      1 299:Q 
      1 29:S 
      1 2:Q 
      1 300:Q 
      1 301:Q 
      1 302:E 
      1 303:Q 
      1 304:E 
      1 305:Q 
      1 306:V 
      1 307:Q 
      1 308:Q 
      1 309:Q 
      1 30:S 
      1 310:Q 
      1 311:Q 
      1 312:Q 
      1 313:Q 
      1 314:Q 
      1 315:Q 
      1 316:Q 
      1 317:Q 
      1 318:S 
      1 319:S 
      1 31:S 
      1 320:S 
      1 321:S 
      1 322:S 
      1 323:S 
      1 324:S 
      1 325:S 
      1 326:E 
      1 327:Q 
      1 328:Q 
      1 329:Q 
      1 32:S 
      1 330:Q 
      1 331:Q 
      1 332:Q 
      1 333:Q 
      1 334:Q 
      1 335:Q 
      1 336:Q 
      1 337:Q 
      1 338:Q 
      1 339:Q 
      1 33:S 
      1 340:Q 
      1 341:Q 
      1 342:Q 
      1 343:Q 
      1 344:Q 
      1 345:Q 
      1 346:Q 
      1 347:Q 
      1 348:Q 
      1 349:Q 
      1 34:S 
      1 350:Q 
      1 351:Q 
      1 352:Q 
      1 353:Q 
      1 354:Q 
      1 355:Q 
      1 356:V 
      1 357:Q 
      1 358:Q 
      1 359:Q 
      1 35:Q 
      1 360:Q 
      1 361:Q 
      1 362:Q 
      1 363:Q 
      1 364:Q 
      1 365:Q 
      1 366:S 
      1 367:Q 
      1 368:Q 
      1 369:Q 
      1 36:Q 
      1 370:Q 
      1 371:Q 
      1 372:Q 
      1 373:Q 
      1 374:Q 
      1 375:Q 
      1 376:Q 
      1 377:S 
      1 378:S 
      1 379:S 
      1 37:Q 
      1 380:S 
      1 381:Q 
      1 382:Q 
      1 383:Q 
      1 384:S 
      1 385:Q 
      1 386:Q 
      1 387:Q 
      1 388:S 
      1 389:S 
      1 38:Q 
      1 390:S 
      1 391:Q 
      1 392:Q 
      1 393:Q 
      1 394:Q 
      1 395:V 
      1 396:S 
      1 397:Q 
      1 398:Q 
      1 399:Q 
      1 39:Q 
      1 3:S 
      1 400:S 
      1 401:Q 
      1 402:Q 
      1 403:Q 
      1 404:S 
      1 405:Q 
      1 406:Q 
      1 407:Q 
      1 408:Q 
      1 409:Q 
      1 40:S 
      1 410:Q 
      1 411:S 
      1 412:Q 
      1 413:S 
      1 414:Q 
      1 415:Q 
      1 416:S 
      1 417:S 
      1 418:Q 
      1 419:S 
      1 41:S 
      1 420:Q 
      1 421:Q 
      1 422:S 
      1 423:S 
      1 424:Q 
      1 425:Q 
      1 426:Q 
      1 427:Q 
      1 428:Q 
      1 429:Q 
      1 42:S 
      1 430:Q 
      1 431:Q 
      1 432:Q 
      1 433:Q 
      1 434:V 
      1 435:Q 
      1 436:V 
      1 437:Q 
      1 438:Q 
      1 439:S 
      1 43:S 
      1 440:Q 
      1 441:Q 
      1 442:Q 
      1 443:S 
      1 444:Q 
      1 445:Q 
      1 446:P 
      1 447:P 
      1 448:P 
      1 449:P 
      1 44:S 
      1 450:P 
      1 451:P 
      1 452:P 
      1 453:P 
      1 454:Q 
      1 455:Q 
      1 456:S 
      1 457:Q 
      1 458:E 
      1 459:E 
      1 45:S 
      1 460:E 
      1 461:E 
      1 462:S 
      1 463:E 
      1 464:E 
      1 465:Q 
      1 466:E 
      1 467:E 
      1 468:E 
      1 469:E 
      1 46:S 
      1 470:Q 
      1 471:E 
      1 472:Q 
      1 473:S 
      1 474:S 
      1 475:S 
      1 476:Q 
      1 477:Q 
      1 478:Q 
      1 479:Q 
      1 47:S 
      1 480:Q 
      1 481:Q 
      1 482:Q 
      1 483:Q 
      1 484:Q 
      1 485:Q 
      1 486:Q 
      1 487:Q 
      1 488:Q 
      1 489:Q 
      1 48:S 
      1 490:S 
      1 491:Q 
      1 492:Q 
      1 493:Q 
      1 494:Q 
      1 495:Q 
      1 496:Q 
      1 497:Q 
      1 498:Q 
      1 499:Q 
      1 49:S 
      1 4:P 
      1 500:Q 
      1 501:Q 
      1 502:Q 
      1 503:Q 
      1 504:Q 
      1 505:Q 
      1 506:Q 
      1 507:Q 
      1 508:Q 
      1 509:Q 
      1 50:S 
      1 510:P 
      1 511:P 
      1 512:P 
      1 513:P 
      1 514:P 
      1 515:Q 
      1 516:Q 
      1 517:Q 
      1 518:Q 
      1 519:P 
      1 51:S 
      1 520:P 
      1 521:P 
      1 522:S 
      1 523:Q 
      1 524:P 
      1 525:Q 
      1 526:Q 
      1 527:S 
      1 528:S 
      1 529:P 
      1 52:S 
      1 530:P 
      1 531:P 
      1 532:S 
      1 533:S 
      1 534:S 
      1 535:S 
      1 536:Q 
      1 537:Q 
      1 538:Q 
      1 539:P 
      1 53:S 
      1 540:P 
      1 541:P 
      1 542:P 
      1 543:Q 
      1 544:S 
      1 545:Q 
      1 546:P 
      1 547:P 
      1 548:Q 
      1 549:Q 
      1 54:S 
      1 550:Q 
      1 551:Q 
      1 552:Q 
      1 553:Q 
      1 554:Q 
      1 555:Q 
      1 556:Q 
      1 557:Q 
      1 558:Q 
      1 559:Q 
      1 55:S 
      1 560:Q 
      1 561:Q 
      1 562:Q 
      1 563:Q 
      1 564:Q 
      1 565:Q 
      1 566:Q 
      1 567:Q 
      1 568:Q 
      1 569:Q 
      1 56:S 
      1 57:S 
      1 58:S 
      1 59:S 
      1 5:P 
      1 60:S 
      1 61:S 
      1 62:S 
      1 63:S 
      1 64:S 
      1 65:S 
      1 66:S 
      1 67:S 
      1 68:S 
      1 69:S 
      1 6:P 
      1 70:S 
      1 71:S 
      1 72:S 
      1 73:S 
      1 74:S 
      1 75:S 
      1 76:S 
      1 77:S 
      1 78:S 
      1 79:Q 
      1 7:S 
      1 80:Q 
      1 81:Q 
      1 82:Q 
      1 83:Q 
      1 84:E 
      1 85:Q 
      1 86:Q 
      1 87:Q 
      1 88:S 
      1 89:Q 
      1 8:S 
      1 90:S 
      1 91:Q 
      1 92:Q 
      1 93:Q 
      1 94:Q 
      1 95:Q 
      1 96:S 
      1 97:S 
      1 98:S 
      1 99:Q 
      1 9:S 
84:E | instr.background                  |  Instrumental background
196:E | phot                              |  Photometry
197:E | phot.antennaTemp                  |  Antenna temperature
199:C | phot.color                        |  Color index or magnitude difference
202:E | phot.count                        |  Flux expressed in counts
203:E | phot.fluence                      |  Radiant photon energy received by a surface per unit area or irradiance of a surface integrated over time of irradiation
204:E | phot.flux                         |  Photon flux or irradiance
206:E | phot.flux.density                 |  Flux density (per wl/freq/energy interval)
207:E | phot.flux.density.sb              |  Flux density surface brightness
208:E | phot.flux.sb                      |  Flux surface brightness
209:E | phot.limbDark                     |  Limb-darkening coefficients
210:E | phot.mag                          |  Photometric magnitude
211:E | phot.mag.bc                       |  Bolometric correction
214:E | phot.mag.reddFree                 |  Dereddened magnitude
215:E | phot.mag.sb                       |  Surface brightness in magnitude units
216:E | phot.radiance                     |  Radiance as energy flux per solid angle
219:E | phys.absorption                   |  Extinction or absorption along the line of sight
233:E | phys.angSize                      |  Angular size width diameter dimension extension major minor axis extraction radius
234:E | phys.angSize.smajAxis             |  Angular size extent or extension of semi-major axis
235:E | phys.angSize.sminAxis             |  Angular size extent or extension of semi-minor axis
```

## 原始行 72 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.utils import data
try:
 print(data.get_pkg_data_contents('data/ucd1p-words.txt')[:30])
except Exception as e: print(type(e),e)
PY"
```

退出码：`0`

输出：
```
<class 'urllib.error.URLError'> <urlopen error Unable to open any source! Exceptions were {'http://data.astropy.org/data/ucd1p-words.txt': <HTTPError 403: 'Forbidden'>, 'http://www.astropy.org/astropy-data/data/ucd1p-words.txt': <HTTPError 403: 'Forbidden'>}>
```

## 原始行 75 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def get_pkg_data_filename\\|def get_pkg_data_contents\" astropy/utils/data.py | head; sed -n '1140,1215p' astropy/utils/data.py"
```

退出码：`0`

输出：
```
659:def get_pkg_data_filename(
779:def get_pkg_data_contents(data_name, package=None, encoding=None, cache=True):
855:def get_pkg_data_filenames(datadir, package=None, pattern="*"):

    size : int or `~astropy.units.Quantity`
        A proposed filesize. If not a Quantity, assume it is in bytes.

    Raises
    ------
    OSError
        There is not enough room on the filesystem.
    """
    space = get_free_space_in_dir(path, unit=getattr(size, "unit", False))
    if space < size:
        from astropy.utils.console import human_file_size

        raise OSError(
            f"Not enough free space in {path} "
            f"to download a {human_file_size(size)} file, "
            f"only {human_file_size(space)} left"
        )


class _ftptlswrapper(urllib.request.ftpwrapper):
    def init(self):
        self.busy = 0
        self.ftp = ftplib.FTP_TLS()
        self.ftp.connect(self.host, self.port, self.timeout)
        self.ftp.login(self.user, self.passwd)
        self.ftp.prot_p()
        _target = "/".join(self.dirs)
        self.ftp.cwd(_target)


class _FTPTLSHandler(urllib.request.FTPHandler):
    def connect_ftp(self, user, passwd, host, port, dirs, timeout):
        return _ftptlswrapper(user, passwd, host, port, dirs, timeout, persistent=False)


@functools.lru_cache
def _build_urlopener(ftp_tls=False, ssl_context=None, allow_insecure=False):
    """
    Helper for building a `urllib.request.build_opener` which handles TLS/SSL.
    """
    # Import ssl here to avoid import failure when running in pyodide/Emscripten
    import ssl

    ssl_context = dict(it for it in ssl_context) if ssl_context else {}
    cert_chain = {}
    if "certfile" in ssl_context:
        cert_chain.update(
            {
                "certfile": ssl_context.pop("certfile"),
                "keyfile": ssl_context.pop("keyfile", None),
                "password": ssl_context.pop("password", None),
            }
        )
    elif "password" in ssl_context or "keyfile" in ssl_context:
        raise ValueError(
            "passing 'keyfile' or 'password' in the ssl_context argument "
            "requires passing 'certfile' as well"
        )

    if "cafile" not in ssl_context and HAS_CERTIFI:
        import certifi

        ssl_context["cafile"] = certifi.where()

    ssl_context = ssl.create_default_context(**ssl_context)

    if allow_insecure:
        ssl_context.check_hostname = False
        ssl_context.verify_mode = ssl.CERT_NONE

    if cert_chain:
        ssl_context.load_cert_chain(**cert_chain)

    https_handler = urllib.request.HTTPSHandler(context=ssl_context)
```

## 原始行 78 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^def warn_or_raise'"\\|"'^def vo_raise'"\\|"'^def vo_warn'"' astropy/io/votable/exceptions.py; sed -n '110,190p' astropy/io/votable/exceptions.py; grep -R -n \"warn_or_raise(W08\" astropy"
```

退出码：`1`

输出：
```
98:def warn_or_raise(
118:def vo_raise(exception_class, args=(), config=None, pos=None):
145:def vo_warn(warning_class, args=(), config=None, pos=None, stacklevel=1):
    if config_value == "exception":
        if exception_class is None:
            exception_class = warning_class
        vo_raise(exception_class, args, config, pos)
    elif config_value == "warn":
        vo_warn(warning_class, args, config, pos, stacklevel=stacklevel + 1)


def vo_raise(exception_class, args=(), config=None, pos=None):
    """
    Raise an exception, with proper position information if available.
    """
    if config is None:
        config = {}
    raise exception_class(args, config, pos)


def vo_reraise(exc, config=None, pos=None, additional=""):
    """
    Raise an exception, with proper position information if available.

    Restores the original traceback of the exception, and should only
    be called within an "except:" block of code.
    """
    if config is None:
        config = {}
    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
    if message.split()[0] == str(exc).split()[0]:
        message = str(exc)
    if len(additional):
        message += " " + additional
    exc.args = (message,)
    raise exc


def vo_warn(warning_class, args=(), config=None, pos=None, stacklevel=1):
    """
    Warn, with proper position information if available.
    """
    if config is None:
        config = {}
    # NOTE: the default here is deliberately warn rather than ignore, since
    # one would expect that calling warn_or_raise without config should not
    # silence the warnings.
    if config.get("verify", "warn") != "ignore":
        warning = warning_class(args, config, pos)
        _suppressed_warning(warning, config, stacklevel=stacklevel + 1)


def warn_unknown_attrs(element, attrs, config, pos, good_attr=[], stacklevel=1):
    for attr in attrs:
        if attr not in good_attr:
            vo_warn(W48, (attr, element), config, pos, stacklevel=stacklevel + 1)


_warning_pat = re.compile(
    r":?(?P<nline>[0-9?]+):(?P<nchar>[0-9?]+): "
    r"((?P<warning>[WE]\d+): )?(?P<rest>.*)$"
)


def parse_vowarning(line):
    """
    Parses the vo warning string back into its parts.
    """
    result = {}
    match = _warning_pat.search(line)
    if match:
        result["warning"] = warning = match.group("warning")
        if warning is not None:
            result["is_warning"] = warning[0].upper() == "W"
            result["is_exception"] = not result["is_warning"]
            result["number"] = int(match.group("warning")[1:])
            result["doc_url"] = f"io/votable/api_exceptions.html#{warning.lower()}"
        else:
            result["is_warning"] = False
            result["is_exception"] = False
            result["is_other"] = True
            result["number"] = None
            result["doc_url"] = None
        try:
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc "sed -n '80,125p' astropy/io/votable/exceptions.py"
```

退出码：`0`

输出：
```


















def warn_or_raise(
    warning_class, exception_class=None, args=(), config=None, pos=None, stacklevel=1
):
    """
    Warn or raise an exception, depending on the verify setting.
    """
    if config is None:
        config = {}
    # NOTE: the default here is deliberately warn rather than ignore, since
    # one would expect that calling warn_or_raise without config should not
    # silence the warnings.
    config_value = config.get("verify", "warn")
    if config_value == "exception":
        if exception_class is None:
            exception_class = warning_class
        vo_raise(exception_class, args, config, pos)
    elif config_value == "warn":
        vo_warn(warning_class, args, config, pos, stacklevel=stacklevel + 1)


def vo_raise(exception_class, args=(), config=None, pos=None):
    """
    Raise an exception, with proper position information if available.
    """
    if config is None:
        config = {}
    raise exception_class(args, config, pos)
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/converters.py | sed -n '500,710p'; nl -ba astropy/io/votable/converters.py | sed -n '840,1035p'"
```

退出码：`0`

输出：
```
   500	
   501	
   502	
   503	
   504	
   505	
   506	
   507	class Array(Converter):
   508	    """
   509	    Handles both fixed and variable-lengths arrays.
   510	    """
   511	
   512	    def __init__(self, field, config=None, pos=None):
   513	        if config is None:
   514	            config = {}
   515	        Converter.__init__(self, field, config, pos)
   516	        if config.get("verify", "ignore") == "exception":
   517	            self._splitter = self._splitter_pedantic
   518	        else:
   519	            self._splitter = self._splitter_lax
   520	
   521	    def parse_scalar(self, value, config=None, pos=0):
   522	        return self._base.parse_scalar(value, config, pos)
   523	
   524	    @staticmethod
   525	    def _splitter_pedantic(value, config=None, pos=None):
   526	        return pedantic_array_splitter.split(value)
   527	
   528	    @staticmethod
   529	    def _splitter_lax(value, config=None, pos=None):
   530	        if "," in value:
   531	            vo_warn(W01, (), config, pos)
   532	        return array_splitter.split(value)
   533	
   534	
   535	class VarArray(Array):
   536	    """
   537	    Handles variable lengths arrays (i.e. where *arraysize* is '*').
   538	    """
   539	
   540	    format = "O"
   541	
   542	    def __init__(self, field, base, arraysize, config=None, pos=None):
   543	        Array.__init__(self, field, config)
   544	
   545	        self._base = base
   546	        self.default = np.array([], dtype=self._base.format)
   547	
   548	    def output(self, value, mask):
   549	        output = self._base.output
   550	        result = [output(x, m) for x, m in np.broadcast(value, mask)]
   551	        return " ".join(result)
   552	
   553	    def binparse(self, read):
   554	        length = self._parse_length(read)
   555	
   556	        result = []
   557	        result_mask = []
   558	        binparse = self._base.binparse
   559	        for i in range(length):
   560	            val, mask = binparse(read)
   561	            result.append(val)
   562	            result_mask.append(mask)
   563	
   564	        return _make_masked_array(result, result_mask), False
   565	
   566	    def binoutput(self, value, mask):
   567	        if value is None or len(value) == 0:
   568	            return _zero_int
   569	
   570	        length = len(value)
   571	        result = [self._write_length(length)]
   572	        binoutput = self._base.binoutput
   573	        for x, m in zip(value, value.mask):
   574	            result.append(binoutput(x, m))
   575	        return _empty_bytes.join(result)
   576	
   577	
   578	class ArrayVarArray(VarArray):
   579	    """
   580	    Handles an array of variable-length arrays, i.e. where *arraysize*
   581	    ends in '*'.
   582	    """
   583	
   584	    def parse(self, value, config=None, pos=None):
   585	        if value.strip() == "":
   586	            return ma.array([]), False
   587	
   588	        parts = self._splitter(value, config, pos)
   589	        items = self._base._items
   590	        parse_parts = self._base.parse_parts
   591	        if len(parts) % items != 0:
   592	            vo_raise(E02, (items, len(parts)), config, pos)
   593	        result = []
   594	        result_mask = []
   595	        for i in range(0, len(parts), items):
   596	            value, mask = parse_parts(parts[i : i + items], config, pos)
   597	            result.append(value)
   598	            result_mask.append(mask)
   599	
   600	        return _make_masked_array(result, result_mask), False
   601	
   602	
   603	class ScalarVarArray(VarArray):
   604	    """
   605	    Handles a variable-length array of numeric scalars.
   606	    """
   607	
   608	    def parse(self, value, config=None, pos=None):
   609	        if value.strip() == "":
   610	            return ma.array([]), False
   611	
   612	        parts = self._splitter(value, config, pos)
   613	
   614	        parse = self._base.parse
   615	        result = []
   616	        result_mask = []
   617	        for x in parts:
   618	            value, mask = parse(x, config, pos)
   619	            result.append(value)
   620	            result_mask.append(mask)
   621	
   622	        return _make_masked_array(result, result_mask), False
   623	
   624	
   625	class NumericArray(Array):
   626	    """
   627	    Handles a fixed-length array of numeric scalars.
   628	    """
   629	
   630	    vararray_type = ArrayVarArray
   631	
   632	    def __init__(self, field, base, arraysize, config=None, pos=None):
   633	        Array.__init__(self, field, config, pos)
   634	
   635	        self._base = base
   636	        self._arraysize = arraysize
   637	        self.format = f"{tuple(arraysize)}{base.format}"
   638	        self._items = prod(arraysize)
   639	        self._memsize = np.dtype(self.format).itemsize
   640	        self._bigendian_format = ">" + self.format
   641	
   642	        self.default = np.empty(arraysize, dtype=self._base.format)
   643	        self.default[...] = self._base.default
   644	
   645	    def parse(self, value, config=None, pos=None):
   646	        if config is None:
   647	            config = {}
   648	        elif config["version_1_3_or_later"] and value == "":
   649	            return np.zeros(self._arraysize, dtype=self._base.format), True
   650	        parts = self._splitter(value, config, pos)
   651	        if len(parts) != self._items:
   652	            warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
   653	        if config.get("verify", "ignore") == "exception":
   654	            return self.parse_parts(parts, config, pos)
   655	        else:
   656	            if len(parts) == self._items:
   657	                pass
   658	            elif len(parts) > self._items:
   659	                parts = parts[: self._items]
   660	            else:
   661	                parts = parts + ([self._base.default] * (self._items - len(parts)))
   662	            return self.parse_parts(parts, config, pos)
   663	
   664	    def parse_parts(self, parts, config=None, pos=None):
   665	        base_parse = self._base.parse
   666	        result = []
   667	        result_mask = []
   668	        for x in parts:
   669	            value, mask = base_parse(x, config, pos)
   670	            result.append(value)
   671	            result_mask.append(mask)
   672	        result = np.array(result, dtype=self._base.format).reshape(self._arraysize)
   673	        result_mask = np.array(result_mask, dtype="bool").reshape(self._arraysize)
   674	        return result, result_mask
   675	
   676	    def output(self, value, mask):
   677	        base_output = self._base.output
   678	        value = np.asarray(value)
   679	        mask = np.asarray(mask)
   680	        if mask.size <= 1:
   681	            func = np.broadcast
   682	        else:  # When mask is already array but value is scalar, this prevents broadcast
   683	            func = zip
   684	        return " ".join(base_output(x, m) for x, m in func(value.flat, mask.flat))
   685	
   686	    def binparse(self, read):
   687	        result = np.frombuffer(read(self._memsize), dtype=self._bigendian_format)[0]
   688	        result_mask = self._base.is_null(result)
   689	        return result, result_mask
   690	
   691	    def binoutput(self, value, mask):
   692	        filtered = self._base.filter_array(value, mask)
   693	        filtered = _ensure_bigendian(filtered)
   694	        return filtered.tobytes()
   695	
   696	
   697	class Numeric(Converter):
   698	    """
   699	    The base class for all numeric data types.
   700	    """
   701	
   702	    array_type = NumericArray
   703	    vararray_type = ScalarVarArray
   704	    null = None
   705	
   706	    def __init__(self, field, config=None, pos=None):
   707	        Converter.__init__(self, field, config, pos)
   708	
   709	        self._memsize = np.dtype(self.format).itemsize
   710	        self._bigendian_format = ">" + self.format
   840	    floating-point.
   841	    """
   842	
   843	    format = "f8"
   844	
   845	
   846	class Float(FloatingPoint):
   847	    """
   848	    Handles the float datatype.  Single-precision IEEE floating-point.
   849	    """
   850	
   851	    format = "f4"
   852	
   853	
   854	class Integer(Numeric):
   855	    """
   856	    The base class for all the integral datatypes.
   857	    """
   858	
   859	    default = 0
   860	
   861	    def __init__(self, field, config=None, pos=None):
   862	        Numeric.__init__(self, field, config, pos)
   863	
   864	    def parse(self, value, config=None, pos=None):
   865	        if config is None:
   866	            config = {}
   867	        mask = False
   868	        if isinstance(value, str):
   869	            value = value.lower()
   870	            if value == "":
   871	                if config["version_1_3_or_later"]:
   872	                    mask = True
   873	                else:
   874	                    warn_or_raise(W49, W49, (), config, pos)
   875	                if self.null is not None:
   876	                    value = self.null
   877	                else:
   878	                    value = self.default
   879	            elif value == "nan":
   880	                mask = True
   881	                if self.null is None:
   882	                    warn_or_raise(W31, W31, (), config, pos)
   883	                    value = self.default
   884	                else:
   885	                    value = self.null
   886	            elif value.startswith("0x"):
   887	                value = int(value[2:], 16)
   888	            else:
   889	                value = int(value, 10)
   890	        else:
   891	            value = int(value)
   892	        if self.null is not None and value == self.null:
   893	            mask = True
   894	
   895	        if value < self.val_range[0]:
   896	            warn_or_raise(W51, W51, (value, self.bit_size), config, pos)
   897	            value = self.val_range[0]
   898	        elif value > self.val_range[1]:
   899	            warn_or_raise(W51, W51, (value, self.bit_size), config, pos)
   900	            value = self.val_range[1]
   901	
   902	        return value, mask
   903	
   904	    def output(self, value, mask):
   905	        if mask:
   906	            if self.null is None:
   907	                warn_or_raise(W31, W31)
   908	                return "NaN"
   909	            return str(self.null)
   910	        return str(value)
   911	
   912	    def binoutput(self, value, mask):
   913	        if mask:
   914	            if self.null is None:
   915	                vo_raise(W31)
   916	            else:
   917	                value = self.null
   918	
   919	        value = _ensure_bigendian(value)
   920	        return value.tobytes()
   921	
   922	    def filter_array(self, value, mask):
   923	        if np.any(mask):
   924	            if self.null is not None:
   925	                return np.where(mask, self.null, value)
   926	            else:
   927	                vo_raise(W31)
   928	        return value
   929	
   930	
   931	class UnsignedByte(Integer):
   932	    """
   933	    Handles the unsignedByte datatype.  Unsigned 8-bit integer.
   934	    """
   935	
   936	    format = "u1"
   937	    val_range = (0, 255)
   938	    bit_size = "8-bit unsigned"
   939	
   940	
   941	class Short(Integer):
   942	    """
   943	    Handles the short datatype.  Signed 16-bit integer.
   944	    """
   945	
   946	    format = "i2"
   947	    val_range = (-32768, 32767)
   948	    bit_size = "16-bit"
   949	
   950	
   951	class Int(Integer):
   952	    """
   953	    Handles the int datatype.  Signed 32-bit integer.
   954	    """
   955	
   956	    format = "i4"
   957	    val_range = (-2147483648, 2147483647)
   958	    bit_size = "32-bit"
   959	
   960	
   961	class Long(Integer):
   962	    """
   963	    Handles the long datatype.  Signed 64-bit integer.
   964	    """
   965	
   966	    format = "i8"
   967	    val_range = (-9223372036854775808, 9223372036854775807)
   968	    bit_size = "64-bit"
   969	
   970	
   971	class ComplexArrayVarArray(VarArray):
   972	    """
   973	    Handles an array of variable-length arrays of complex numbers.
   974	    """
   975	
   976	    def parse(self, value, config=None, pos=None):
   977	        if value.strip() == "":
   978	            return ma.array([]), True
   979	
   980	        parts = self._splitter(value, config, pos)
   981	        items = self._base._items
   982	        parse_parts = self._base.parse_parts
   983	        if len(parts) % items != 0:
   984	            vo_raise(E02, (items, len(parts)), config, pos)
   985	        result = []
   986	        result_mask = []
   987	        for i in range(0, len(parts), items):
   988	            value, mask = parse_parts(parts[i : i + items], config, pos)
   989	            result.append(value)
   990	            result_mask.append(mask)
   991	
   992	        return _make_masked_array(result, result_mask), False
   993	
   994	
   995	class ComplexVarArray(VarArray):
   996	    """
   997	    Handles a variable-length array of complex numbers.
   998	    """
   999	
  1000	    def parse(self, value, config=None, pos=None):
  1001	        if value.strip() == "":
  1002	            return ma.array([]), True
  1003	
  1004	        parts = self._splitter(value, config, pos)
  1005	        parse_parts = self._base.parse_parts
  1006	        result = []
  1007	        result_mask = []
  1008	        for i in range(0, len(parts), 2):
  1009	            value = [float(x) for x in parts[i : i + 2]]
  1010	            value, mask = parse_parts(value, config, pos)
  1011	            result.append(value)
  1012	            result_mask.append(mask)
  1013	
  1014	        return (
  1015	            _make_masked_array(np.array(result, dtype=self._base.format), result_mask),
  1016	            False,
  1017	        )
  1018	
  1019	
  1020	class ComplexArray(NumericArray):
  1021	    """
  1022	    Handles a fixed-size array of complex numbers.
  1023	    """
  1024	
  1025	    vararray_type = ComplexArrayVarArray
  1026	
  1027	    def __init__(self, field, base, arraysize, config=None, pos=None):
  1028	        NumericArray.__init__(self, field, base, arraysize, config, pos)
  1029	        self._items *= 2
  1030	
  1031	    def parse(self, value, config=None, pos=None):
  1032	        parts = self._splitter(value, config, pos)
  1033	        if parts == [""]:
  1034	            parts = []
  1035	        return self.parse_parts(parts, config, pos)
```

## 原始行 87 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
from numpy import ma
from astropy.table import Table
x=ma.array(np.zeros(2,dtype=[('a','i4'),('b','i4')]))
for names in [None,['x','y'],['x','x']]:
 try:
  t=Table(x,names=names); print(names,t.colnames)
 except Exception as e: print(names,type(e).__name__,e)
PY"
```

退出码：`0`

输出：
```
None ['a', 'b']
['x', 'y'] ['x', 'y']
['x', 'x'] ValueError Duplicate column names
```

## 原始行 91 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _make_masked_array\\|_make_masked_array\" astropy/io/votable/converters.py; grep -R -n \"BitArray.*supports_empty\\|supports_empty_values\" astropy/io/votable/tests astropy/io/votable --include='*.py'"
```

退出码：`0`

输出：
```
564:        return _make_masked_array(result, result_mask), False
600:        return _make_masked_array(result, result_mask), False
622:        return _make_masked_array(result, result_mask), False
992:        return _make_masked_array(result, result_mask), False
1015:            _make_masked_array(np.array(result, dtype=self._base.format), result_mask),
astropy/io/votable/converters.py:187:    def supports_empty_values(self, config):
astropy/io/votable/converters.py:346:    def supports_empty_values(self, config):
astropy/io/votable/tree.py:3398:                supports_empty_values = [
astropy/io/votable/tree.py:3399:                    field.converter.supports_empty_values(kwargs) for field in fields
astropy/io/votable/tree.py:3408:                    supports_empty_values,
astropy/io/votable/tree.py:3423:                        field.converter.supports_empty_values(kwargs),
astropy/io/votable/tree.py:3431:                    for i, output, supports_empty_values in fields:
astropy/io/votable/tree.py:3434:                        if supports_empty_values and np.all(masked):
```

## 原始行 94 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/converters.py | sed -n '1150,1245p'; grep -R -n \"bitarray\" astropy/io/votable/tests/test_*py | head -n 80; grep -R -n \"W39\\|E03\\|E04\" astropy/io/votable/converters.py astropy/io/votable/tests --include='*.py'"
```

退出码：`0`

输出：
```
  1150	
  1151	    def binoutput(self, value, mask):
  1152	        if np.any(mask):
  1153	            vo_warn(W39)
  1154	
  1155	        return bool_to_bitarray(value)
  1156	
  1157	
  1158	class Bit(Converter):
  1159	    """
  1160	    Handles the bit datatype.
  1161	    """
  1162	
  1163	    format = "b1"
  1164	    array_type = BitArray
  1165	    vararray_type = ScalarVarArray
  1166	    default = False
  1167	    binary_one = b"\x08"
  1168	    binary_zero = b"\0"
  1169	
  1170	    def parse(self, value, config=None, pos=None):
  1171	        if config is None:
  1172	            config = {}
  1173	        mapping = {"1": True, "0": False}
  1174	        if value is False or value.strip() == "":
  1175	            if not config["version_1_3_or_later"]:
  1176	                warn_or_raise(W49, W49, (), config, pos)
  1177	            return False, True
  1178	        else:
  1179	            try:
  1180	                return mapping[value], False
  1181	            except KeyError:
  1182	                vo_raise(E04, (value,), config, pos)
  1183	
  1184	    def output(self, value, mask):
  1185	        if mask:
  1186	            vo_warn(W39)
  1187	
  1188	        if value:
  1189	            return "1"
  1190	        else:
  1191	            return "0"
  1192	
  1193	    def binparse(self, read):
  1194	        data = read(1)
  1195	        return (ord(data) & 0x8) != 0, False
  1196	
  1197	    def binoutput(self, value, mask):
  1198	        if mask:
  1199	            vo_warn(W39)
  1200	
  1201	        if value:
  1202	            return self.binary_one
  1203	        return self.binary_zero
  1204	
  1205	
  1206	class BooleanArray(NumericArray):
  1207	    """
  1208	    Handles an array of boolean values.
  1209	    """
  1210	
  1211	    vararray_type = ArrayVarArray
  1212	
  1213	    def binparse(self, read):
  1214	        data = read(self._items)
  1215	        binparse = self._base.binparse_value
  1216	        result = []
  1217	        result_mask = []
  1218	        for char in data:
  1219	            value, mask = binparse(char)
  1220	            result.append(value)
  1221	            result_mask.append(mask)
  1222	        result = np.array(result, dtype="b1").reshape(self._arraysize)
  1223	        result_mask = np.array(result_mask, dtype="b1").reshape(self._arraysize)
  1224	        return result, result_mask
  1225	
  1226	    def binoutput(self, value, mask):
  1227	        binoutput = self._base.binoutput
  1228	        value = np.asarray(value)
  1229	        mask = np.asarray(mask)
  1230	        result = [binoutput(x, m) for x, m in np.broadcast(value.flat, mask.flat)]
  1231	        return _empty_bytes.join(result)
  1232	
  1233	
  1234	class Boolean(Converter):
  1235	    """
  1236	    Handles the boolean datatype.
  1237	    """
  1238	
  1239	    format = "b1"
  1240	    array_type = BooleanArray
  1241	    vararray_type = ScalarVarArray
  1242	    default = False
  1243	    binary_question_mark = b"?"
  1244	    binary_true = b"T"
  1245	    binary_false = b"F"
astropy/io/votable/tests/test_table.py:90:        ("bitarray", {"datatype": "bit", "arraysize": "3x2"}),
astropy/io/votable/tests/test_table.py:104:        ("bitarray2", {"datatype": "bit", "arraysize": "16"}),
astropy/io/votable/tests/test_vo.py:94:        ("bitarray", "|b1", (3, 2)),
astropy/io/votable/tests/test_vo.py:108:        ("bitarray2", "|b1", (16,)),
astropy/io/votable/tests/test_vo.py:287:    columns = ["string_test", "unsignedByte", "bitarray"]
astropy/io/votable/tests/test_vo.py:297:    columns = ["string_test", "unsignedByte", "bitarray"]
astropy/io/votable/tests/test_vo.py:499:    def test_bitarray(self):
astropy/io/votable/tests/test_vo.py:500:        assert issubclass(self.array["bitarray"].dtype.type, np.bool_)
astropy/io/votable/tests/test_vo.py:501:        assert self.array["bitarray"].shape == (5, 3, 2)
astropy/io/votable/tests/test_vo.py:503:            self.array["bitarray"],
astropy/io/votable/tests/test_vo.py:513:    def test_bitarray_mask(self):
astropy/io/votable/tests/test_vo.py:515:            self.mask["bitarray"],
astropy/io/votable/tests/test_vo.py:655:            self.array["bitarray2"][0],
astropy/io/votable/tests/test_vo.py:677:        assert not np.any(self.mask["bitarray2"][0])
astropy/io/votable/tests/test_vo.py:678:        assert np.all(self.mask["bitarray2"][1:])
astropy/io/votable/tests/test_vo.py:733:    def test_bitarray_mask(self):
astropy/io/votable/tests/test_vo.py:734:        assert not np.any(self.mask["bitarray"])
astropy/io/votable/tests/test_vo.py:737:        assert not np.any(self.mask["bitarray2"])
astropy/io/votable/tests/test_vo.py:772:    def test_bitarray_mask(self):
astropy/io/votable/tests/test_vo.py:773:        assert not np.any(self.mask["bitarray"])
astropy/io/votable/tests/test_vo.py:776:        assert not np.any(self.mask["bitarray2"])
astropy/io/votable/converters.py:24:    E03,
astropy/io/votable/converters.py:25:    E04,
astropy/io/votable/converters.py:32:    W39,
astropy/io/votable/converters.py:1073:            vo_raise(E03, (value,), config, pos)
astropy/io/votable/converters.py:1139:            vo_warn(W39)
astropy/io/votable/converters.py:1153:            vo_warn(W39)
astropy/io/votable/converters.py:1182:                vo_raise(E04, (value,), config, pos)
astropy/io/votable/converters.py:1186:            vo_warn(W39)
astropy/io/votable/converters.py:1199:            vo_warn(W39)
astropy/io/votable/tests/test_table.py:18:from astropy.io.votable.exceptions import E01, E25, W39, W46, W50, VOWarning
astropy/io/votable/tests/test_table.py:115:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_table.py:116:    with pytest.warns(W39):
astropy/io/votable/tests/test_table.py:142:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_table.py:143:    with pytest.warns(W39):
astropy/io/votable/tests/test_vo.py:22:from astropy.io.votable.exceptions import W31, W39, VOTableSpecError, VOWarning
astropy/io/votable/tests/test_vo.py:184:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:185:    with pytest.warns(W39), np.errstate(over="ignore"):
astropy/io/votable/tests/test_vo.py:191:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:192:    with pytest.warns(W39), np.errstate(over="ignore"):
astropy/io/votable/tests/test_vo.py:198:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:199:    with pytest.warns(W39), np.errstate(over="ignore"):
astropy/io/votable/tests/test_vo.py:721:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:722:        with pytest.warns(W39):
astropy/io/votable/tests/test_vo.py:756:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:757:        with pytest.warns(W39):
astropy/io/votable/tests/test_vo.py:801:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:802:        with pytest.warns(W39):
astropy/io/votable/tests/test_vo.py:839:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:840:    with pytest.warns(W39):
astropy/io/votable/tests/test_vo.py:1006:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:1007:    with pytest.warns(W39):
```

## 原始行 97 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"use_names_over_ids|column.*metadata|TableElement.to_table|values.*options\" docs astropy/io/votable -g '*' 2>/dev/null | head -n 200 || true; grep -R -n \"get_first_table\" docs astropy/io/votable --exclude='*.py' 2>/dev/null | head -n 50"
```

退出码：`0`

输出：
```
docs/io/votable/table_element.rst:27:to use `~astropy.io.votable.tree.VOTableFile.get_first_table`::
docs/io/votable/table_element.rst:29:  table = votable.get_first_table()
docs/io/votable/table_element.rst:90:      >>> votable.get_first_table().to_table(use_names_over_ids=True)
docs/io/votable/index.rst:64:  votable.get_first_table().format = 'binary'
docs/io/votable/index.rst:210:        votable.get_first_table().format = "binary"
docs/io/votable/coosys_element.rst:52:    >>> table = votable.get_first_table()
```

## 原始行 99 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,125p' docs/io/votable/table_element.rst; grep -R -n \"values.*meta\\|meta.*ucd\\|metadata\" docs/io/votable | head -n 100"
```

退出码：`0`

输出：
```
.. doctest-skip-all

Table element
-------------

VOTable files can contain ``RESOURCE`` elements, each of
which may contain one or more ``TABLE`` elements. The ``TABLE``
elements contain the arrays of data.

To get at the ``TABLE`` elements, you can write a loop over the
resources in the ``VOTABLE`` file::

    for resource in votable.resources:
        for table in resource.tables:
            # ... do something with the table ...
            pass

However, if the nested structure of the resources is not important,
you can use `~astropy.io.votable.tree.VOTableFile.iter_tables` to
return a flat list of all tables::

    for table in votable.iter_tables():
        # ... do something with the table ...
        pass

Finally, if you expect only one table in the file, it might be most convenient
to use `~astropy.io.votable.tree.VOTableFile.get_first_table`::

  table = votable.get_first_table()

Alternatively, there is a convenience method to parse a VOTable file and
return the first table all in one step::

  from astropy.io.votable import parse_single_table
  table = parse_single_table("votable.xml")

From a `~astropy.io.votable.tree.TableElement` object, you can get the data itself
in the ``array`` member variable::

  data = table.array

This data is a ``numpy`` record array.

The columns get their names from both the ``ID`` and ``name``
attributes of the ``FIELD`` elements in the ``VOTABLE`` file.

..
  EXAMPLE START
  Reading a VOTable File with astropy.io.votable

Suppose we had a ``FIELD`` specified as follows:

.. code-block:: xml

   <FIELD ID="Dec" name="dec_targ" datatype="char" ucd="POS_EQ_DEC_MAIN"
          unit="deg">
    <DESCRIPTION>
     representing the ICRS declination of the center of the image.
    </DESCRIPTION>
   </FIELD>

.. note::

    The mapping from VOTable ``name`` and ``ID`` attributes to ``numpy``
    dtype ``names`` and ``titles`` is highly confusing.

    In VOTable, ``ID`` is guaranteed to be unique, but is not
    required. ``name`` is not guaranteed to be unique, but is
    required.

    In ``numpy`` record dtypes, ``names`` are required to be unique and
    are required. ``titles`` are not required, and are not required
    to be unique.

    Therefore, VOTable's ``ID`` most closely maps to ``numpy``'s
    ``names``, and VOTable's ``name`` most closely maps to ``numpy``'s
    ``titles``. However, in some cases where a VOTable ``ID`` is not
    provided, a ``numpy`` ``name`` will be generated based on the VOTable
    ``name``. Unfortunately, VOTable fields do not have an attribute
    that is both unique and required, which would be the most
    convenient mechanism to uniquely identify a column.

    When converting from an `astropy.io.votable.tree.TableElement` object to
    an `astropy.table.Table` object, you can specify whether to give
    preference to ``name`` or ``ID`` attributes when naming the
    columns. By default, ``ID`` is given preference. To give
    ``name`` preference, pass the keyword argument
    ``use_names_over_ids=True``::

      >>> votable.get_first_table().to_table(use_names_over_ids=True)

This column of data can be extracted from the record array using::

  >>> table.array['dec_targ']
  array([17.15153360566, 17.15153360566, 17.15153360566, 17.1516686826,
         17.1516686826, 17.1516686826, 17.1536197136, 17.1536197136,
         17.1536197136, 17.15375479055, 17.15375479055, 17.15375479055,
         17.1553884541, 17.15539736932, 17.15539752176,
         17.25736014763,
         # ...
         17.2765703], dtype=object)

or equivalently::

  >>> table.array['Dec']
  array([17.15153360566, 17.15153360566, 17.15153360566, 17.1516686826,
         17.1516686826, 17.1516686826, 17.1536197136, 17.1536197136,
         17.1536197136, 17.15375479055, 17.15375479055, 17.15375479055,
         17.1553884541, 17.15539736932, 17.15539752176,
         17.25736014763,
         # ...
         17.2765703], dtype=object)

..
  EXAMPLE END

Datatype Mappings
^^^^^^^^^^^^^^^^^

The datatype specified by a ``FIELD`` element is mapped to a ``numpy``
type according to the following table:

  ================================ =========================
  VOTABLE type                     NumPy type
  ================================ =========================
docs/io/votable/mivot_blocks.rst:12:This annotation schema operates as a bridge between data and the models. It associates both column/param metadata and data
docs/io/votable/mivot_blocks.rst:14:metadata that were possibly missing in the table, e.g., coordinate system description, or curation tracing.
docs/io/votable/dataorigin.rst:74:Contents and metadata
docs/io/votable/dataorigin.rst:81:  It includes metadata like  the publisher, the contact, date of execution, query, etc.
docs/io/votable/dataorigin.rst:85:  It includes metadata like authors, ivoid, landing pages, ....
```

## 原始行 101 · agent_message

```
I also found a few excised helpers that the requested interfaces directly call (token checking, unit-format selection, masked-array construction, field-to-column metadata, binary length packing, and first-table lookup). I’m restoring those narrowly as part of the same implementation so the public methods can actually execute end to end.
```

## 原始行 104 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/utils/xml/check.py | sed -n '1,65p'; sed -n '30,45l' astropy/utils/xml/check.py"
```

退出码：`0`

输出：
```
     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	"""
     3	A collection of functions for checking various XML-related strings for
     4	standards compliance.
     5	"""
     6	
     7	import re
     8	import urllib.parse
     9	
    10	
    11	
    12	
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	def check_mime_content_type(content_type):
    53	    """
    54	    Returns `True` if *content_type* is a valid MIME content type
    55	    (syntactically at least), as defined by RFC 2045.
    56	    """
    57	    ctrls = "".join(chr(x) for x in range(0x20))
    58	    token_regex = f'[^()<>@,;:\\"/[\\]?= {ctrls}\x7f]+'
    59	    return (
    60	        re.match(rf"(?P<type>{token_regex})/(?P<subtype>{token_regex})$", content_type)
    61	        is not None
    62	    )
    63	
    64	
    65	def check_anyuri(uri):
$
$
$
$
$
$
$
_token_regex = r"(?![\\r\\l\\t ])[^\\r\\l\\t]*(?![\\r\\l\\t ])"$
$
$
$
$
$
$
$
$
```

## 原始行 108 · file_change

```
{
  "id": "item_71",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/check.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 114 · file_change

```
{
  "id": "item_76",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/check.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 117 · file_change

```
{
  "id": "item_78",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/ucd.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 120 · file_change

```
{
  "id": "item_80",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/converters.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 123 · file_change

```
{
  "id": "item_82",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 126 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/utils/tests/test_xml.py astropy/io/votable/tests/test_ucd.py astropy/io/votable/tests/test_tree.py astropy/io/votable/tests/test_table.py --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
.........s......FFFFFFFFFF
=================================== FAILURES ===================================
__________________________ test_check_astroyear_fail ___________________________

    def test_check_astroyear_fail():
        config = {"verify": "exception"}
>       field = tree.Field(None, name="astroyear", arraysize="1")
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:29: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1482: in __init__
    self.values = Values(self._votable, self)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1033: in __init__
    self.min = None
    ^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'Values' object has no attribute 'is_defaults'") raised in repr()] Values object at 0x7c1d4c5bde50>
min = None

    @min.setter
    def min(self, min):
>       self._min = self._parse_minmax(min)
                    ^^^^^^^^^^^^^^^^^^
E       AttributeError: 'Values' object has no attribute '_parse_minmax'

astropy/io/votable/tree.py:1134: AttributeError
_______________________________ test_string_fail _______________________________

    def test_string_fail():
        config = {"verify": "exception"}
        with pytest.raises(W08):
>           tree.check_string(42, "foo", config)

astropy/io/votable/tests/test_tree.py:37: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:332: in check_string
    warn_or_raise(W08, W08, attr_name, config, pos)
astropy/io/votable/exceptions.py:113: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
astropy/io/votable/exceptions.py:124: in vo_raise
    raise exception_class(args, config, pos)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = W08('foo', {'verify': 'exception'}, None), args = ('foo',)
config = {'verify': 'exception'}, pos = None

    def __init__(self, args, config=None, pos=None):
        if config is None:
            config = {}
        if not isinstance(args, tuple):
            args = (args,)
        msg = self.message_template.format(*args)
    
>       self.formatted_message = _format_message(
                                 ^^^^^^^^^^^^^^^
            msg, self.__class__.__name__, config, pos
        )
E       NameError: name '_format_message' is not defined

astropy/io/votable/exceptions.py:231: NameError
_______________________________ test_make_Fields _______________________________

    def test_make_Fields():
        votable = VOTableFile()
        # ...with one resource...
        resource = Resource()
        votable.resources.append(resource)
    
        # ... with one table
        table = tree.TableElement(votable)
        resource.tables.append(table)
    
        table.fields.extend(
>           [tree.Field(votable, name="Test", datatype="float", unit="mag")]
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
        )

astropy/io/votable/tests/test_tree.py:51: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1482: in __init__
    self.values = Values(self._votable, self)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1033: in __init__
    self.min = None
    ^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'Values' object has no attribute 'is_defaults'") raised in repr()] Values object at 0x7c1d4bff8f50>
min = None

    @min.setter
    def min(self, min):
>       self._min = self._parse_minmax(min)
                    ^^^^^^^^^^^^^^^^^^
E       AttributeError: 'Values' object has no attribute '_parse_minmax'

astropy/io/votable/tree.py:1134: AttributeError
_______________________________ test_unit_format _______________________________

    def test_unit_format():
>       data = parse(get_pkg_data_filename("data/irsa-nph-error.xml"))
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:56: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = '/testbed/astropy/io/votable/tests/data/irsa-nph-error.xml'
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
____________________________ test_namespace_warning ____________________________

    def test_namespace_warning():
        """
        A version 1.4 VOTable must use the same namespace as 1.3.
        (see https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html#ToC16).
        """
        bad_namespace = b"""<?xml version="1.0" encoding="utf-8"?>
            <VOTABLE version="1.4" xmlns="http://www.ivoa.net/xml/VOTable/v1.4"
                                   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
              <RESOURCE/>
            </VOTABLE>
        """
        with pytest.warns(W41):
>           parse(io.BytesIO(bad_namespace), verify="exception")

astropy/io/votable/tests/test_tree.py:85: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7c1d4c656b60>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError

During handling of the above exception, another exception occurred:

    def test_namespace_warning():
        """
        A version 1.4 VOTable must use the same namespace as 1.3.
        (see https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html#ToC16).
        """
        bad_namespace = b"""<?xml version="1.0" encoding="utf-8"?>
            <VOTABLE version="1.4" xmlns="http://www.ivoa.net/xml/VOTable/v1.4"
                                   xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
              <RESOURCE/>
            </VOTABLE>
        """
>       with pytest.warns(W41):
E       Failed: DID NOT WARN. No warnings of type (<class 'astropy.io.votable.exceptions.W41'>,) were emitted.
E        Emitted warnings: [].

astropy/io/votable/tests/test_tree.py:84: Failed
______________________ test_votable_values_empty_min_max _______________________

    def test_votable_values_empty_min_max():
        """Regression test for https://github.com/astropy/astropy/issues/16825"""
        with_empty_minmax = b"""<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.4">
            <RESOURCE type="results">
              <TABLE name="main">
                <PARAM name="break" datatype="int" value=""/>
              <FIELD ID="hd" datatype="int" name="hd" ucd="meta.id;meta.main">
                <DESCRIPTION>HD number for this object</DESCRIPTION>
                <VALUES null="-2147483648">
                  <MIN value=""/>
                  <MAX value=""/>
                </VALUES>
              </FIELD>
              <DATA>
                <BINARY>
                  <STREAM encoding="base64">AAMNIg==</STREAM>
                </BINARY>
              </DATA>
            </TABLE>
          </RESOURCE>
        </VOTABLE>
        """
>       parse(io.BytesIO(with_empty_minmax), verify="exception")

astropy/io/votable/tests/test_tree.py:126: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7c1d4c4c8a40>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
_____________________ test_min_max_with_arrays[testvals0] ______________________

testvals = {'dt': 'float', 'expected_max': 3.4, 'expected_min': 1.2, 'max': '3.4', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7c1d4c4c9f80>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
_____________________ test_min_max_with_arrays[testvals1] ______________________

testvals = {'dt': 'float', 'expected_max': [3.4, 5.6], 'expected_min': [1.2, 3.4], 'max': '3.4 5.6', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7c1d4c4c84a0>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
_____________________ test_min_max_with_arrays[testvals2] ______________________

testvals = {'dt': 'double', 'expected_max': 3.4, 'expected_min': 1.2, 'max': '3.4', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7c1d4c4c9760>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
_____________________ test_min_max_with_arrays[testvals3] ______________________

testvals = {'dt': 'double', 'expected_max': [3.4, 5.6], 'expected_min': [1.2, 3.4], 'max': '3.4 5.6', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x7c1d4c4ca8e0>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_tree.py::test_check_astroyear_fail - Att...
FAILED astropy/io/votable/tests/test_tree.py::test_string_fail - NameError: n...
FAILED astropy/io/votable/tests/test_tree.py::test_make_Fields - AttributeErr...
FAILED astropy/io/votable/tests/test_tree.py::test_unit_format - NameError: n...
FAILED astropy/io/votable/tests/test_tree.py::test_namespace_warning - Failed...
FAILED astropy/io/votable/tests/test_tree.py::test_votable_values_empty_min_max
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals0]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals1]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals2]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals3]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 10 failures !!!!!!!!!!!!!!!!!!!!!!!!!!
10 failed, 15 passed, 1 skipped in 0.33s
```

## 原始行 129 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _parse_minmax\\|def is_defaults\\|def to_table_column\\|def to_table(self\\|def links\\|def get_first_table\" astropy/io/votable/tree.py; nl -ba astropy/io/votable/tree.py | sed -n '580,700p'; nl -ba astropy/io/votable/tree.py | sed -n '1170,1250p'; sed -n '1,180p' astropy/io/votable/exceptions.py; sed -n '1,180p' astropy/utils/xml/iterparser.py"
```

退出码：`0`

输出：
```
614:    def _parse_minmax(self, val):
636:    def is_defaults(self):
807:    def to_table_column(self, column):
1314:    def to_table_column(self, column):
1708:    def links(self):
1769:    def to_table_column(self, column):
2757:    def links(self):
3563:    def to_table(self, use_names_over_ids=False):
4044:    def links(self):
4191:    def get_first_table(self):
   580	
   581	        Parameters
   582	        ----------
   583	        w : astropy.utils.xml.writer.XMLWriter object
   584	            An XML writer to write to.
   585	        **kwargs : dict
   586	            Any configuration parameters to control the output.
   587	        """
   588	        raise NotImplementedError()
   589	
   590	
   591	class SimpleElement(Element):
   592	    """
   593	    A base class for simple elements, such as FIELD, PARAM and INFO
   594	    that don't require any special parsing or outputting machinery.
   595	    """
   596	
   597	    def __init__(self):
   598	        Element.__init__(self)
   599	
   600	    def __repr__(self):
   601	        buff = io.StringIO()
   602	        SimpleElement.to_xml(self, XMLWriter(buff))
   603	        return buff.getvalue().strip()
   604	
   605	    def parse(self, iterator, config):
   606	        for start, tag, data, pos in iterator:
   607	            if start and tag != self._element_name:
   608	                self._add_unknown_tag(iterator, tag, data, config, pos)
   609	            elif tag == self._element_name:
   610	                break
   611	
   612	        return self
   613	
   614	    def _parse_minmax(self, val):
   615	        if val is None:
   616	            return None
   617	
   618	        converter = getattr(self._field, "converter", None)
   619	        if converter is None:
   620	            return val
   621	
   622	        arraysize = getattr(self._field, "arraysize", None)
   623	        if arraysize is None:
   624	            return converter.parse(val, self._config, self._pos)[0]
   625	
   626	        # Array-valued fields in real-world files use both scalar constraints
   627	        # and full arrays (notably for interval xtypes).  Try the scalar form
   628	        # first, then parse an array without array-size verification noise.
   629	        try:
   630	            return converter.parse_scalar(val, self._config, self._pos)[0]
   631	        except (TypeError, ValueError):
   632	            config = self._config.copy()
   633	            config["verify"] = "ignore"
   634	            return converter.parse(val, config, self._pos)[0]
   635	
   636	    def is_defaults(self):
   637	        return (
   638	            self.ref is None
   639	            and self.null is None
   640	            and self.ID is None
   641	            and self.max is None
   642	            and self.min is None
   643	            and len(self.options) == 0
   644	        )
   645	
   646	    def to_xml(self, w, **kwargs):
   647	        w.element(self._element_name, attrib=w.object_attrs(self, self._attr_list))
   648	
   649	
   650	class SimpleElementWithContent(SimpleElement):
   651	    """
   652	    A base class for simple elements, such as FIELD, PARAM and INFO
   653	    that don't require any special parsing or outputting machinery.
   654	    """
   655	
   656	    def __init__(self):
   657	        SimpleElement.__init__(self)
   658	
   659	        self._content = None
   660	
   661	    def parse(self, iterator, config):
   662	        for start, tag, data, pos in iterator:
   663	            if start and tag != self._element_name:
   664	                self._add_unknown_tag(iterator, tag, data, config, pos)
   665	            elif tag == self._element_name:
   666	                if data:
   667	                    self.content = data
   668	                break
   669	
   670	        return self
   671	
   672	    def to_xml(self, w, **kwargs):
   673	        w.element(
   674	            self._element_name,
   675	            self._content,
   676	            attrib=w.object_attrs(self, self._attr_list),
   677	        )
   678	
   679	    @property
   680	    def content(self):
   681	        """The content of the element."""
   682	        return self._content
   683	
   684	    @content.setter
   685	    def content(self, content):
   686	        check_string(content, "content", self._config, self._pos)
   687	        self._content = content
   688	
   689	    @content.deleter
   690	    def content(self):
   691	        self._content = None
   692	
   693	
   694	class Link(SimpleElement, _IDProperty):
   695	    """
   696	    LINK_ elements: used to reference external documents and servers through a URI.
   697	
   698	    The keyword arguments correspond to setting members of the same
   699	    name, documented below.
   700	    """
  1170	    def max(self):
  1171	        self._max = None
  1172	
  1173	    @property
  1174	    def max_inclusive(self):
  1175	        """When `True`, the domain includes the maximum value."""
  1176	        return self._max_inclusive
  1177	
  1178	    @max_inclusive.setter
  1179	    def max_inclusive(self, inclusive):
  1180	        if inclusive == "yes":
  1181	            self._max_inclusive = True
  1182	        elif inclusive == "no":
  1183	            self._max_inclusive = False
  1184	        else:
  1185	            self._max_inclusive = bool(inclusive)
  1186	
  1187	    @max_inclusive.deleter
  1188	    def max_inclusive(self):
  1189	        self._max_inclusive = True
  1190	
  1191	    @property
  1192	    def options(self):
  1193	        """
  1194	        A list of string key-value tuples defining other OPTION
  1195	        elements for the domain.  All options are ignored -- they are
  1196	        stored for round-tripping purposes only.
  1197	        """
  1198	        return self._options
  1199	
  1200	    def parse(self, iterator, config):
  1201	        if self.ref is not None:
  1202	            for start, tag, data, pos in iterator:
  1203	                if start:
  1204	                    warn_or_raise(W44, W44, tag, config, pos)
  1205	                else:
  1206	                    if tag != "VALUES":
  1207	                        warn_or_raise(W44, W44, tag, config, pos)
  1208	                    break
  1209	        else:
  1210	            for start, tag, data, pos in iterator:
  1211	                if start:
  1212	                    if tag == "MIN":
  1213	                        if "value" not in data:
  1214	                            vo_raise(E09, "MIN", config, pos)
  1215	                        self.min = data["value"]
  1216	                        self.min_inclusive = data.get("inclusive", "yes")
  1217	                        warn_unknown_attrs(
  1218	                            "MIN", data.keys(), config, pos, ["value", "inclusive"]
  1219	                        )
  1220	                    elif tag == "MAX":
  1221	                        if "value" not in data:
  1222	                            vo_raise(E09, "MAX", config, pos)
  1223	                        self.max = data["value"]
  1224	                        self.max_inclusive = data.get("inclusive", "yes")
  1225	                        warn_unknown_attrs(
  1226	                            "MAX", data.keys(), config, pos, ["value", "inclusive"]
  1227	                        )
  1228	                    elif tag == "OPTION":
  1229	                        if "value" not in data:
  1230	                            vo_raise(E09, "OPTION", config, pos)
  1231	                        xmlutil.check_token(data.get("name"), "name", config, pos)
  1232	                        self.options.append((data.get("name"), data.get("value")))
  1233	                        warn_unknown_attrs(
  1234	                            "OPTION", data.keys(), config, pos, ["value", "name"]
  1235	                        )
  1236	                elif tag == "VALUES":
  1237	                    break
  1238	
  1239	        return self
  1240	
  1241	
  1242	
  1243	
  1244	
  1245	
  1246	
  1247	
  1248	
  1249	
  1250	
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""VOTable exceptions and warnings.

.. _warnings:

Warnings
--------
.. note::
    Most of the following warnings indicate violations of the VOTable
    specification.  They should be reported to the authors of the
    tools that produced the VOTable file.

    To control the warnings emitted, use the standard Python
    :mod:`warnings` module and the ``astropy.io.votable.exceptions.conf.max_warnings``
    configuration item.  Most of these are of the type `VOTableSpecWarning`.

{warnings}

.. _exceptions:

Exceptions
----------

.. note::

    This is a list of many of the fatal exceptions emitted by ``astropy.io.votable``
    when the file does not conform to spec.  Other exceptions may be
    raised due to unforeseen cases or bugs in ``astropy.io.votable`` itself.

{exceptions}
"""

# STDLIB
import io
import re
from textwrap import dedent
from warnings import warn

from astropy import config as _config
from astropy.utils.exceptions import AstropyWarning

__all__ = [
    "Conf",
    "IOWarning",
    "UnimplementedWarning",
    "VOTableChangeWarning",
    "VOTableSpecError",
    "VOTableSpecWarning",
    "VOWarning",
    "conf",
    "parse_vowarning",
    "vo_raise",
    "vo_reraise",
    "vo_warn",
    "warn_or_raise",
    "warn_unknown_attrs",
]


# NOTE: Cannot put this in __init__.py due to circular import.
class Conf(_config.ConfigNamespace):
    """
    Configuration parameters for `astropy.io.votable.exceptions`.
    """

    max_warnings = _config.ConfigItem(
        10,
        "Number of times the same type of warning is displayed before being suppressed",
        cfgtype="integer",
    )


conf = Conf()
























def warn_or_raise(
    warning_class, exception_class=None, args=(), config=None, pos=None, stacklevel=1
):
    """
    Warn or raise an exception, depending on the verify setting.
    """
    if config is None:
        config = {}
    # NOTE: the default here is deliberately warn rather than ignore, since
    # one would expect that calling warn_or_raise without config should not
    # silence the warnings.
    config_value = config.get("verify", "warn")
    if config_value == "exception":
        if exception_class is None:
            exception_class = warning_class
        vo_raise(exception_class, args, config, pos)
    elif config_value == "warn":
        vo_warn(warning_class, args, config, pos, stacklevel=stacklevel + 1)


def vo_raise(exception_class, args=(), config=None, pos=None):
    """
    Raise an exception, with proper position information if available.
    """
    if config is None:
        config = {}
    raise exception_class(args, config, pos)


def vo_reraise(exc, config=None, pos=None, additional=""):
    """
    Raise an exception, with proper position information if available.

    Restores the original traceback of the exception, and should only
    be called within an "except:" block of code.
    """
    if config is None:
        config = {}
    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
    if message.split()[0] == str(exc).split()[0]:
        message = str(exc)
    if len(additional):
        message += " " + additional
    exc.args = (message,)
    raise exc


def vo_warn(warning_class, args=(), config=None, pos=None, stacklevel=1):
    """
    Warn, with proper position information if available.
    """
    if config is None:
        config = {}
    # NOTE: the default here is deliberately warn rather than ignore, since
    # one would expect that calling warn_or_raise without config should not
    # silence the warnings.
    if config.get("verify", "warn") != "ignore":
        warning = warning_class(args, config, pos)
        _suppressed_warning(warning, config, stacklevel=stacklevel + 1)


def warn_unknown_attrs(element, attrs, config, pos, good_attr=[], stacklevel=1):
    for attr in attrs:
        if attr not in good_attr:
            vo_warn(W48, (attr, element), config, pos, stacklevel=stacklevel + 1)


_warning_pat = re.compile(
    r":?(?P<nline>[0-9?]+):(?P<nchar>[0-9?]+): "
    r"((?P<warning>[WE]\d+): )?(?P<rest>.*)$"
)


def parse_vowarning(line):
    """
    Parses the vo warning string back into its parts.
    """
    result = {}
    match = _warning_pat.search(line)
    if match:
        result["warning"] = warning = match.group("warning")
        if warning is not None:
            result["is_warning"] = warning[0].upper() == "W"
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This module includes a fast iterator-based XML parser.
"""

# STDLIB
import contextlib
import io
import sys

# ASTROPY
from astropy.utils import data

from ._iterparser import IterParser as _fast_iterparse

__all__ = ["get_xml_encoding", "get_xml_iterator", "xml_readlines"]

























































def _slow_iterparse(fd, buffersize=2**10):
    from xml.parsers import expat

    if not callable(fd):
        read = fd.read
    else:
        read = fd

    queue = []
    text = []

    def start(name, attr):
        queue.append(
            (True, name, attr, (parser.CurrentLineNumber, parser.CurrentColumnNumber))
        )
        del text[:]

    def end(name):
        queue.append(
            (
                False,
                name,
                "".join(text).strip(),
                (parser.CurrentLineNumber, parser.CurrentColumnNumber),
            )
        )

    parser = expat.ParserCreate()
    parser.specified_attributes = True
    parser.StartElementHandler = start
    parser.EndElementHandler = end
    parser.CharacterDataHandler = text.append
    Parse = parser.Parse

    data = read(buffersize)
    while data:
        Parse(data, False)
        yield from queue
        del queue[:]
        data = read(buffersize)

    Parse("", True)
    yield from queue


@contextlib.contextmanager
def get_xml_iterator(source, _debug_python_based_parser=False):
    """
    Returns an iterator over the elements of an XML file.

    The iterator doesn't ever build a tree, so it is much more memory
    and time efficient than the alternative in ``cElementTree``.

    Parameters
    ----------
    source : path-like, :term:`file-like (readable)`, or callable
        Handle that contains the data or function that reads it.
        If a function or callable object, it must directly read from a stream.
        Non-callable objects must define a ``read`` method.

    Returns
    -------
    parts : iterator

        The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):

            - *start*: when `True` is a start element event, otherwise
              an end element event.

            - *tag*: The name of the element

            - *data*: Depends on the value of *event*:

                - if *start* == `True`, data is a dictionary of
                  attributes

                - if *start* == `False`, data is a string containing
                  the text content of the element

            - *pos*: Tuple (*line*, *col*) indicating the source of the
              event.
    """
    with _convert_to_fd_or_read_function(source) as fd:
        if _debug_python_based_parser:
            context = _slow_iterparse(fd)
        else:
            context = _fast_iterparse(fd)
        yield iter(context)


def get_xml_encoding(source):
    """
    Determine the encoding of an XML file by reading its header.

    Parameters
    ----------
    source : path-like, :term:`file-like (readable)`, or callable
        Handle that contains the data or function that reads it.
        If a function or callable object, it must directly read from a stream.
        Non-callable objects must define a ``read`` method.

    Returns
    -------
    encoding : str
    """
    with get_xml_iterator(source) as iterator:
        start, tag, data, pos = next(iterator)
```

## 原始行 132 · file_change

```
{
  "id": "item_88",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 135 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '4160,4230p'; nl -ba astropy/io/votable/tree.py | sed -n '4560,4625p'"
```

退出码：`0`

输出：
```
  4160	                self.params,
  4161	                self.links,
  4162	            ]
  4163	            if kwargs["version_1_2_or_later"]:
  4164	                element_sets.append(self.groups)
  4165	
  4166	            for element_set in element_sets:
  4167	                for element in element_set:
  4168	                    element.to_xml(w, **kwargs)
  4169	
  4170	            # The mivot_block should be before the table
  4171	            for elm in self.resources:
  4172	                if elm.type == "meta" and elm.mivot_block is not None:
  4173	                    elm.to_xml(w, **kwargs)
  4174	
  4175	            for elm in self.tables:
  4176	                elm.to_xml(w, **kwargs)
  4177	
  4178	            for elm in self.resources:
  4179	                if elm.type != "meta":
  4180	                    elm.to_xml(w, **kwargs)
  4181	
  4182	    def iter_tables(self):
  4183	        """
  4184	        Recursively iterates over all tables in the resource and
  4185	        nested resources.
  4186	        """
  4187	        yield from self.tables
  4188	        for resource in self.resources:
  4189	            yield from resource.iter_tables()
  4190	
  4191	    def get_first_table(self):
  4192	        """Return the first table in the flattened resource tree."""
  4193	        for table in self.iter_tables():
  4194	            return table
  4195	        raise IndexError("No table found in VOTABLE file.")
  4196	
  4197	    def iter_fields_and_params(self):
  4198	        """
  4199	        Recursively iterates over all FIELD_ and PARAM_ elements in
  4200	        the resource, its tables and nested resources.
  4201	        """
  4202	        yield from self.params
  4203	        for table in self.tables:
  4204	            yield from table.iter_fields_and_params()
  4205	        for resource in self.resources:
  4206	            yield from resource.iter_fields_and_params()
  4207	
  4208	    def iter_coosys(self):
  4209	        """
  4210	        Recursively iterates over all the COOSYS_ elements in the
  4211	        resource and nested resources.
  4212	        """
  4213	        yield from self.coordinate_systems
  4214	        for resource in self.resources:
  4215	            yield from resource.iter_coosys()
  4216	
  4217	    def iter_timesys(self):
  4218	        """
  4219	        Recursively iterates over all the TIMESYS_ elements in the
  4220	        resource and nested resources.
  4221	        """
  4222	        yield from self.time_systems
  4223	        for resource in self.resources:
  4224	            yield from resource.iter_timesys()
  4225	
  4226	    def iter_info(self):
  4227	        """
  4228	        Recursively iterates over all the INFO_ elements in the
  4229	        resource and nested resources.
  4230	        """
  4560	            votable_attr = {
  4561	                "version": version,
  4562	                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
  4563	            }
  4564	            ns_info = self._version_namespace_map.get(version, {})
  4565	            namespace_uri = ns_info.get("namespace_uri")
  4566	            if namespace_uri:
  4567	                votable_attr["xmlns"] = namespace_uri
  4568	            schema_location_attr = ns_info.get("schema_location_attr")
  4569	            schema_location_value = ns_info.get("schema_location_value")
  4570	            if schema_location_attr and schema_location_value:
  4571	                votable_attr[schema_location_attr] = schema_location_value
  4572	
  4573	            with w.tag("VOTABLE", votable_attr):
  4574	                if self.description is not None:
  4575	                    w.element("DESCRIPTION", self.description, wrap=True)
  4576	                element_sets = [
  4577	                    self.coordinate_systems,
  4578	                    self.time_systems,
  4579	                    self.params,
  4580	                    self.infos,
  4581	                    self.resources,
  4582	                ]
  4583	                if kwargs["version_1_2_or_later"]:
  4584	                    element_sets.append(self.groups)
  4585	
  4586	                for element_set in element_sets:
  4587	                    for element in element_set:
  4588	                        element.to_xml(w, **kwargs)
  4589	
  4590	    def iter_tables(self):
  4591	        """
  4592	        Iterates over all tables in the VOTable file in a "flat" way,
  4593	        ignoring the nesting of resources etc.
  4594	        """
  4595	        for resource in self.resources:
  4596	            yield from resource.iter_tables()
  4597	
  4598	
  4599	
  4600	
  4601	
  4602	
  4603	
  4604	
  4605	
  4606	
  4607	
  4608	    get_table_by_id = _lookup_by_attr_factory(
  4609	        "ID",
  4610	        True,
  4611	        "iter_tables",
  4612	        "TABLE",
  4613	        """
  4614	        Looks up a TABLE_ element by the given ID.  Used by the table
  4615	        "ref" attribute.
  4616	        """,
  4617	    )
  4618	
  4619	    get_tables_by_utype = _lookup_by_attr_factory(
  4620	        "utype",
  4621	        False,
  4622	        "iter_tables",
  4623	        "TABLE",
  4624	        """
  4625	        Looks up a TABLE_ element by the given utype, and returns an
```

## 原始行 137 · file_change

```
{
  "id": "item_91",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 140 · command_execution

命令：
```
/bin/bash -lc 'grep -n "def get_first_table" astropy/io/votable/tree.py'
```

退出码：`0`

输出：
```
4592:    def get_first_table(self):
```

## 原始行 143 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"formatted_message|parse_vowarning|max_warnings|suppressed|W08\" astropy/io/votable/tests astropy/utils/xml/tests --include='*.py' | head -n 250; grep -n \"_format_message\\|_suppressed_warning\" astropy/io/votable/exceptions.py; sed -n '180,270p' astropy/io/votable/exceptions.py; sed -n '1,160p' astropy/io/votable/tests/test_exception.py; sed -n '1,110p' astropy/utils/xml/iterparser.py; sed -n '180,300p' astropy/utils/xml/iterparser.py"
```

退出码：`0`

输出：
```
astropy/io/votable/tests/test_tree.py:12:    W08,
astropy/io/votable/tests/test_tree.py:36:    with pytest.raises(W08):
astropy/io/votable/tests/test_exception.py:19:def test_parse_vowarning():
astropy/io/votable/tests/test_exception.py:26:    parts = exceptions.parse_vowarning(str(w[0].message))
astropy/io/votable/tests/test_exception.py:46:    with exceptions.conf.set_temp("max_warnings", 2):
astropy/io/votable/tests/test_exception.py:48:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:53:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:55:        exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:58:    assert exceptions.conf.max_warnings == 10
136:    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
156:        _suppressed_warning(warning, config, stacklevel=stacklevel + 1)
231:        self.formatted_message = _format_message(
            result["is_warning"] = warning[0].upper() == "W"
            result["is_exception"] = not result["is_warning"]
            result["number"] = int(match.group("warning")[1:])
            result["doc_url"] = f"io/votable/api_exceptions.html#{warning.lower()}"
        else:
            result["is_warning"] = False
            result["is_exception"] = False
            result["is_other"] = True
            result["number"] = None
            result["doc_url"] = None
        try:
            result["nline"] = int(match.group("nline"))
        except ValueError:
            result["nline"] = 0
        try:
            result["nchar"] = int(match.group("nchar"))
        except ValueError:
            result["nchar"] = 0
        result["message"] = match.group("rest")
        result["is_something"] = True
    else:
        result["warning"] = None
        result["is_warning"] = False
        result["is_exception"] = False
        result["is_other"] = False
        result["is_something"] = False
        if not isinstance(line, str):
            line = line.decode("utf-8")
        result["message"] = line

    return result


class VOWarning(AstropyWarning):
    """
    The base class of all VO warnings and exceptions.

    Handles the formatting of the message with a warning or exception
    code, filename, line and column number.
    """

    default_args = ()
    message_template = ""

    def __init__(self, args, config=None, pos=None):
        if config is None:
            config = {}
        if not isinstance(args, tuple):
            args = (args,)
        msg = self.message_template.format(*args)

        self.formatted_message = _format_message(
            msg, self.__class__.__name__, config, pos
        )
        Warning.__init__(self, self.formatted_message)

    def __str__(self):
        return self.formatted_message

    @classmethod
    def get_short_name(cls):
        if len(cls.default_args):
            return cls.message_template.format(*cls.default_args)
        return cls.message_template


class VOTableChangeWarning(VOWarning, SyntaxWarning):
    """
    A change has been made to the input XML file.
    """


class VOTableSpecWarning(VOWarning, SyntaxWarning):
    """
    The input XML file violates the spec, but there is an obvious workaround.
    """


class ModelMappingSpecWarning(VOWarning, SyntaxWarning):
    """
    The input model mapping XML mapping block violates the spec.
    """


class UnimplementedWarning(VOWarning, SyntaxWarning):
    """
    A feature of the VOTABLE_ spec is not implemented.
    """


class IOWarning(VOWarning, RuntimeWarning):
# Licensed under a 3-clause BSD style license - see LICENSE.rst
import pytest

# LOCAL
from astropy.io.votable import converters, exceptions, tree


def test_reraise():
    def fail():
        raise RuntimeError("This failed")

    with pytest.raises(RuntimeError, match="From here"):
        try:
            fail()
        except RuntimeError as e:
            exceptions.vo_reraise(e, additional="From here")


def test_parse_vowarning():
    config = {"verify": "exception", "filename": "foo.xml"}
    pos = (42, 64)
    with pytest.warns(exceptions.W47) as w:
        field = tree.Field(None, name="c", datatype="char", config=config, pos=pos)
        converters.get_converter(field, config=config, pos=pos)

    parts = exceptions.parse_vowarning(str(w[0].message))

    match = {
        "number": 47,
        "is_exception": False,
        "nchar": 64,
        "warning": "W47",
        "is_something": True,
        "message": "Missing arraysize indicates length 1",
        "doc_url": "io/votable/api_exceptions.html#w47",
        "nline": 42,
        "is_warning": True,
    }
    assert parts == match


def test_suppress_warnings():
    cfg = {}
    warn = exceptions.W01("foo")

    with exceptions.conf.set_temp("max_warnings", 2):
        with pytest.warns(exceptions.W01) as record:
            exceptions._suppressed_warning(warn, cfg)
            assert len(record) == 1
            assert "suppressing" not in str(record[0].message)

        with pytest.warns(exceptions.W01, match="suppressing"):
            exceptions._suppressed_warning(warn, cfg)

        exceptions._suppressed_warning(warn, cfg)

    assert cfg["_warning_counts"][exceptions.W01] == 3
    assert exceptions.conf.max_warnings == 10
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This module includes a fast iterator-based XML parser.
"""

# STDLIB
import contextlib
import io
import sys

# ASTROPY
from astropy.utils import data

from ._iterparser import IterParser as _fast_iterparse

__all__ = ["get_xml_encoding", "get_xml_iterator", "xml_readlines"]

























































def _slow_iterparse(fd, buffersize=2**10):
    from xml.parsers import expat

    if not callable(fd):
        read = fd.read
    else:
        read = fd

    queue = []
    text = []

    def start(name, attr):
        queue.append(
            (True, name, attr, (parser.CurrentLineNumber, parser.CurrentColumnNumber))
        )
        del text[:]

    def end(name):
        queue.append(
            (
                False,
                name,
                "".join(text).strip(),
                (parser.CurrentLineNumber, parser.CurrentColumnNumber),
            )
        )

    parser = expat.ParserCreate()
    parser.specified_attributes = True
    parser.StartElementHandler = start
    parser.EndElementHandler = end
    parser.CharacterDataHandler = text.append
    Parse = parser.Parse

    data = read(buffersize)
    while data:
        Parse(data, False)
        start, tag, data, pos = next(iterator)
        if not start or tag != "xml":
            raise OSError("Invalid XML file")

    # The XML spec says that no encoding === utf-8
    return data.get("encoding") or "utf-8"


def xml_readlines(source):
    """
    Get the lines from a given XML file.  Correctly determines the
    encoding and always returns unicode.

    Parameters
    ----------
    source : path-like, :term:`file-like (readable)`, or callable
        Handle that contains the data or function that reads it.
        If a function or callable object, it must directly read from a stream.
        Non-callable objects must define a ``read`` method.

    Returns
    -------
    lines : list of unicode
    """
    encoding = get_xml_encoding(source)

    with data.get_readable_fileobj(source, encoding=encoding) as input:
        input.seek(0)
        xml_lines = input.readlines()

    return xml_lines
```

## 原始行 146 · command_execution

命令：
```
/bin/bash -lc "sed -n '35,75p' astropy/io/votable/tests/test_exception.py; grep -R -n \"get_xml_iterator(.*lambda\\|xml_readlines\\|get_xml_encoding\" astropy/utils/xml/tests astropy/io/votable/tests --include='*.py'; sed -n '1,260p' astropy/utils/xml/tests/test_iterparse.py; grep -R -n \"_warning_counts\" astropy/io/votable --include='*.py'"
```

退出码：`0`

输出：
```
        "doc_url": "io/votable/api_exceptions.html#w47",
        "nline": 42,
        "is_warning": True,
    }
    assert parts == match


def test_suppress_warnings():
    cfg = {}
    warn = exceptions.W01("foo")

    with exceptions.conf.set_temp("max_warnings", 2):
        with pytest.warns(exceptions.W01) as record:
            exceptions._suppressed_warning(warn, cfg)
            assert len(record) == 1
            assert "suppressing" not in str(record[0].message)

        with pytest.warns(exceptions.W01, match="suppressing"):
            exceptions._suppressed_warning(warn, cfg)

        exceptions._suppressed_warning(warn, cfg)

    assert cfg["_warning_counts"][exceptions.W01] == 3
    assert exceptions.conf.max_warnings == 10
# Licensed under a 3-clause BSD style license - see LICENSE.rst

# LOCAL
# SYSTEM
import io
import zlib

from astropy.utils.xml.iterparser import _fast_iterparse

# The C-based XML parser for VOTables previously used fixed-sized
# buffers (allocated at __init__() time).  This test will
# only pass with the patch that allows a dynamic realloc() of
# the queue.  This addresses the bugs:
#
# - "RuntimeError: XML queue overflow"
#   https://github.com/astropy/astropy/issues/5824
#   (Kudos to Stefan Becker---ARI/ZAH Heidelberg)
#
# - "iterparse.c: add queue_realloc() + move 'buffersize / 2' logic there"
#   https://github.com/astropy/astropy/issues/5869
#
# This test code can emulate a combination of network buffering and
# gzip decompression---with different request sizes, it can be used to
# demonstrate both under-reading and over-reading.
#
# Using the 512-tag VOTABLE XML sample input, and various combinations
# of minimum/maximum fetch sizes, the following situations can be
# generated:
#
# maximum_fetch =  1 (ValueError, no element found) still within gzip headers
# maximum_fetch = 80 (ValueError, unclosed token) short read
# maximum_fetch =217 passes, because decompressed_length > requested
#                            && <512 tags in a single parse
# maximum_fetch =218 (RuntimeError, XML queue overflow)
#
# The test provided here covers the over-reading identified in #5824
# (equivalent to the 217).

# Firstly, assemble a minimal VOTABLE header, table contents and footer.
# This is done in textual form, as the aim is to only test the parser, not
# the outputter!
HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<VOTABLE>
 <RESOURCE type="results">
  <TABLE>
   <FIELD ID="foo" name="foo" datatype="int" arraysize="1"/>
    <DATA>
     <TABLEDATA>
"""

ROW = """<TR><TD>0</TD></TR>
"""

FOOTER = """
    </TABLEDATA>
   </DATA>
  </TABLE>
 </RESOURCE>
</VOTABLE>
"""

# minimum passable buffer size => 1024
# 1024 / 2 => 512 tags for overflow
# 512 - 7 tags in header, - 5 tags in footer = 500 tags required for overflow
# 500 / 4 tags (<tr><td></td></tr>) per row == 125 rows required for overflow
VOTABLE_XML = HEADER + 125 * ROW + FOOTER

# UngzipFileWrapper() wraps an existing file-like Object,
# decompressing the content and returning the plaintext.
# This therefore emulates the behavior of the Python 'requests'
# library when transparently decompressing Gzip HTTP responses.
#
# The critical behavior is that---because of the
# decompression---read() can return considerably more
# bytes than were requested!  (But, read() can also return less).
#
# inspiration:
# http://stackoverflow.com/questions/4013843/how-to-wrap-file-object-read-and-write-operation-which-are-readonly


class UngzipFileWrapper:
    def __init__(self, fd, **kwargs):
        self._file = fd
        self._z = zlib.decompressobj(16 + zlib.MAX_WBITS)

    def read(self, requested_length):
        # emulate network buffering dynamics by clamping the read size
        clamped_length = max(1, min(1 << 24, requested_length))
        compressed = self._file.read(clamped_length)
        plaintext = self._z.decompress(compressed)
        # Only for real local files---just for the testcase
        if len(compressed) == 0:
            self.close()
        return plaintext

    def __getattr__(self, attr):
        return getattr(self._file, attr)


# test_iterparser_over_read_simple() is a very cut down test,
# of the original more flexible test-case, but without external
# dependencies.  The plaintext is compressed and then decompressed
# to provide a better emulation of the original situation where
# the bug was observed.
#
# If a dependency upon 'zlib' is not desired, it would be possible to
# simplify this testcase by replacing the compress/decompress with a
# read() method emulation that always returned more from a buffer
# that was requested.


def test_iterparser_over_read_simple():
    # Take the plaintext of 512 tags, and compression it with a
    # Gzip-style header (+16), to most closely emulate the behavior
    # of most HTTP servers.
    zlib_GZIP_STYLE_HEADER = 16
    compo = zlib.compressobj(
        zlib.Z_BEST_COMPRESSION, zlib.DEFLATED, zlib.MAX_WBITS + zlib_GZIP_STYLE_HEADER
    )

    # Bytes vs. String  .encode()/.decode() for compatibility with Python 3.5.
    s = compo.compress(VOTABLE_XML.encode())
    s = s + compo.flush()
    fd = io.BytesIO(s)
    fd.seek(0)

    # Finally setup the test of the C-based '_fast_iterparse()' iterator
    # and a situation in which it can be called a-la the VOTable Parser.
    MINIMUM_REQUESTABLE_BUFFER_SIZE = 1024
    uncompressed_fd = UngzipFileWrapper(fd)
    iterable = _fast_iterparse(uncompressed_fd.read, MINIMUM_REQUESTABLE_BUFFER_SIZE)
    list(iterable)
astropy/io/votable/tests/test_exception.py:57:    assert cfg["_warning_counts"][exceptions.W01] == 3
```

## 原始行 149 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.utils.xml._iterparser import IterParser
import inspect
print(IterParser.__doc__)
try: print(inspect.signature(IterParser))
except Exception as e: print(e)
PY"
```

退出码：`0`

输出：
```
IterParser objects
no signature found for builtin type <class 'astropy.utils.xml._iterparser.IterParser'>
```

## 原始行 152 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"W[0-9][0-9]:|\\?:\\?:\" astropy/io/votable/tests docs/io/votable | head -n 80; grep -R -n \"suppressing warnings\" astropy docs | head -n 30"
```

退出码：`0`

输出：
```
astropy/io/votable/tests/test_table.py:115:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_table.py:142:    # W39: Bit values can not be masked
astropy/io/votable/tests/data/validation.txt:3:11: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:12:12: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:16:20: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:20:21: W50: Invalid unit string 'foo'
astropy/io/votable/tests/data/validation.txt:24:27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
astropy/io/votable/tests/data/validation.txt:28:28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
astropy/io/votable/tests/data/validation.txt:32:34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
astropy/io/votable/tests/data/validation.txt:36:38: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:40:41: W09: ID attribute not capitalized
astropy/io/votable/tests/data/validation.txt:44:44: W13: 'unicodeString' is not a valid VOTable datatype, should be
astropy/io/votable/tests/data/validation.txt:49:46: W13: 'string' is not a valid VOTable datatype, should be 'char'
astropy/io/votable/tests/data/validation.txt:53:49: W51: Value '-32769' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:57:57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
astropy/io/votable/tests/data/validation.txt:61:98: W17: GROUP element contains more than one DESCRIPTION element
astropy/io/votable/tests/data/validation.txt:65:105: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:69:42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
astropy/io/votable/tests/data/validation.txt:74:113: W46: char value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:78:115: W46: unicodeChar value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:82:116: W46: char value is too long for specified length of 4
astropy/io/votable/tests/data/validation.txt:91:136: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:95:144: W46: char value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:99:147: W46: char value is too long for specified length of 4
astropy/io/votable/tests/data/validation.txt:103:148: W51: Value '256' is out of range for a 8-bit unsigned integer
astropy/io/votable/tests/data/validation.txt:108:149: W51: Value '65536' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:112:152: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:116:155: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:125:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:129:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:133:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:137:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:141:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:145:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:149:171: W49: Empty cell illegal for integer fields.
astropy/io/votable/tests/data/validation.txt:153:171: W49: Empty cell illegal for integer fields. (suppressing further
astropy/io/votable/tests/data/validation.txt:158:177: W46: unicodeChar value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:162:179: W51: Value '-23' is out of range for a 8-bit unsigned integer
astropy/io/votable/tests/data/validation.txt:172:211: W51: Value '65535' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:176:217: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:195:241: W51: Value '256' is out of range for a 8-bit unsigned integer
astropy/io/votable/tests/data/validation.txt:200:242: W51: Value '65536' is out of range for a 16-bit integer field
astropy/io/votable/tests/data/validation.txt:204:248: W01: Array uses commas rather than whitespace
astropy/io/votable/tests/data/validation.txt:223:278: W46: char value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:227:280: W46: unicodeChar value is too long for specified length of 10
astropy/io/votable/tests/data/validation.txt:231:281: W46: char value is too long for specified length of 4
astropy/io/votable/tests/data/no_resource.txt:3:5: W53: VOTABLE element must contain at least one RESOURCE element.
astropy/io/votable/tests/test_vo.py:184:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:191:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:198:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:721:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:756:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:785:        # W31: NaN's can not be represented in integer field
astropy/io/votable/tests/test_vo.py:801:        # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:839:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:1006:    # W39: Bit values can not be masked
astropy/io/votable/tests/test_vo.py:1217:    assert "W48: Unknown attribute 'refposition_mispelled' on TIMESYS" in outstr
```

## 原始行 154 · agent_message

```
The first test run exposed two additional masked infrastructure functions outside the listed files: warning formatting/suppression and XML source adaptation. They are required before any VOTable parse or configured validation can run, so I’m restoring their minimal repository-consistent behavior, then I’ll return to the interface-specific failures.
```

## 原始行 156 · file_change

```
{
  "id": "item_104",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/exceptions.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/utils/xml/iterparser.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 159 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests/test_exception.py astropy/io/votable/tests/test_tree.py --disable-warnings --maxfail=10'
```

退出码：`0`

输出：
```
Internet access disabled
................................                                         [100%]
32 passed in 0.12s
```

## 原始行 161 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests/test_table.py --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
F.F........ssss.........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.............Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

....F..F.                          [100%]
=================================== FAILURES ===================================
__________________________________ test_table __________________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_table0')

    def test_table(tmp_path):
        # Read the VOTABLE
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            votable = parse(get_pkg_data_filename("data/regression.xml"))
        table = votable.get_first_table()
        astropy_table = table.to_table()
    
        for name in table.array.dtype.names:
            assert np.all(astropy_table.mask[name] == table.array.mask[name])
    
        votable2 = tree.VOTableFile.from_table(astropy_table)
        t = votable2.get_first_table()
    
        field_types = [
            ("string_test", {"datatype": "char", "arraysize": "*"}),
            ("string_test_2", {"datatype": "char", "arraysize": "10"}),
            ("unicode_test", {"datatype": "unicodeChar", "arraysize": "*"}),
            ("fixed_unicode_test", {"datatype": "unicodeChar", "arraysize": "10"}),
            ("string_array_test", {"datatype": "char", "arraysize": "4*"}),
            ("unsignedByte", {"datatype": "unsignedByte"}),
            ("short", {"datatype": "short"}),
            ("int", {"datatype": "int"}),
            ("intNoNull", {"datatype": "int"}),
            ("long", {"datatype": "long"}),
            ("double", {"datatype": "double"}),
            ("float", {"datatype": "float"}),
            ("array", {"datatype": "long", "arraysize": "2*"}),
            ("bit", {"datatype": "bit"}),
            ("bitarray", {"datatype": "bit", "arraysize": "3x2"}),
            ("bitvararray", {"datatype": "bit", "arraysize": "*"}),
            ("bitvararray2", {"datatype": "bit", "arraysize": "3x2*"}),
            ("floatComplex", {"datatype": "floatComplex"}),
            ("doubleComplex", {"datatype": "doubleComplex"}),
            ("doubleComplexArray", {"datatype": "doubleComplex", "arraysize": "*"}),
            ("doubleComplexArrayFixed", {"datatype": "doubleComplex", "arraysize": "2"}),
            ("boolean", {"datatype": "bit"}),
            ("booleanArray", {"datatype": "bit", "arraysize": "4"}),
            ("nulls", {"datatype": "int"}),
            ("nulls_array", {"datatype": "int", "arraysize": "2x2"}),
            ("precision1", {"datatype": "double"}),
            ("precision2", {"datatype": "double"}),
            ("doublearray", {"datatype": "double", "arraysize": "*"}),
            ("bitarray2", {"datatype": "bit", "arraysize": "16"}),
        ]
    
        for field, (name, d) in zip(t.fields, field_types):
            assert field.ID == name
>           assert field.datatype == d["datatype"], (
                f"{name} expected {d['datatype']} but get {field.datatype}"
            )
E           AssertionError: string_test expected char but get unicodeChar
E           assert 'unicodeChar' == 'char'
E             
E             - char
E             + unicodeChar

astropy/io/votable/tests/test_table.py:109: AssertionError
______________________ test_read_through_table_interface _______________________

self = <astropy.io.votable.converters.Bit object at 0x7aed0a643fd0>
value = '101101'
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (79, 10)

    def parse(self, value, config=None, pos=None):
        if config is None:
            config = {}
        mapping = {"1": True, "0": False}
        if value is False or value.strip() == "":
            if not config["version_1_3_or_later"]:
                warn_or_raise(W49, W49, (), config, pos)
            return False, True
        else:
            try:
>               return mapping[value], False
                       ^^^^^^^^^^^^^^
E               KeyError: '101101'

astropy/io/votable/converters.py:1215: KeyError

During handling of the above exception, another exception occurred:

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_read_through_table_interf0')

    def test_read_through_table_interface(tmp_path):
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
                t = Table.read(fd, format="votable", table_id="main_table")
    
        assert len(t) == 5
    
        # Issue 8354
        assert t["float"].format is None
    
        fn = tmp_path / "table_interface.xml"
    
        # W39: Bit values can not be masked
        with pytest.warns(W39):
            t.write(fn, table_id="FOO", format="votable")
    
        with open(fn, "rb") as fd:
>           t2 = Table.read(fd, format="votable", table_id="FOO")
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:147: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:62: in __call__
    out = self.registry.read(cls, *args, **kwargs)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/registry/core.py:221: in read
    data = reader(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:88: in read_table_votable
    input = parse(input, table_id=table_id, verify=verify, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4487: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4351: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4134: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4076: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2994: in parse
    self.array = self._parse_tabledata(iterator, colnumbers, config)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:3121: in _parse_tabledata
    vo_reraise(e, config, pos)
astropy/io/votable/exceptions.py:177: in vo_reraise
    raise exc
astropy/io/votable/tree.py:3110: in _parse_tabledata
    vo_reraise(
astropy/io/votable/exceptions.py:177: in vo_reraise
    raise exc
astropy/io/votable/tree.py:3106: in _parse_tabledata
    value, mask_value = parsers[i](
astropy/io/votable/converters.py:694: in parse
    return self.parse_parts(parts, config, pos)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:701: in parse_parts
    value, mask = base_parse(x, config, pos)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:1217: in parse
    vo_raise(E04, (value,), config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E04'>
args = ('101101',)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (79, 10)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E04: 79:10: E04: Invalid bit value '101101'

astropy/io/votable/exceptions.py:159: E04
______________________ TestVerifyOptions.test_verify_warn ______________________

self = <astropy.io.votable.tests.test_table.TestVerifyOptions object at 0x7aed0ab36ad0>

    def test_verify_warn(self):
        with pytest.warns(VOWarning) as w:
            parse(get_pkg_data_filename("data/gemini.xml"), verify="warn")
>       assert len(w) == 24
E       assert 30 == 24
E        +  where 30 = len(WarningsChecker(record=True))

astropy/io/votable/tests/test_table.py:975: AssertionError
___________________ TestVerifyOptions.test_conf_verify_warn ____________________

self = <astropy.io.votable.tests.test_table.TestVerifyOptions object at 0x7aed0ab37dd0>

    def test_conf_verify_warn(self):
        with conf.set_temp("verify", "warn"):
            with pytest.warns(VOWarning) as w:
                parse(get_pkg_data_filename("data/gemini.xml"))
>           assert len(w) == 24
E           assert 30 == 24
E            +  where 30 = len(WarningsChecker(record=True))

astropy/io/votable/tests/test_table.py:991: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_table - AssertionError: s...
FAILED astropy/io/votable/tests/test_table.py::test_read_through_table_interface
FAILED astropy/io/votable/tests/test_table.py::TestVerifyOptions::test_verify_warn
FAILED astropy/io/votable/tests/test_table.py::TestVerifyOptions::test_conf_verify_warn
4 failed, 39 passed, 4 skipped in 0.59s
```

## 原始行 164 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def table_column_to_votable_datatype\" -A 120 astropy/io/votable/converters.py; nl -ba astropy/io/votable/tree.py | sed -n '1740,1835p'; python - <<'PY'
from astropy.io.votable import tree
from astropy.io.votable.table import parse
from astropy.utils.data import get_pkg_data_filename
import numpy as np
with np.errstate(over='ignore'):
 v=parse(get_pkg_data_filename('data/regression.xml'))
t=v.get_first_table(); a=t.to_table()
for i in range(5):
 f=t.fields[i]; c=a.columns[i]
 print(i,f.datatype,f.arraysize,c.dtype,c.meta)
PY"
```

退出码：`1`

输出：
```
1479:def table_column_to_votable_datatype(column):
1480-    """
1481-    Given a `astropy.table.Column` instance, returns the attributes
1482-    necessary to create a VOTable FIELD element that corresponds to
1483-    the type of the column.
1484-
1485-    This necessarily must perform some heuristics to determine the
1486-    type of variable length arrays fields, since they are not directly
1487-    supported by Numpy.
1488-
1489-    If the column has dtype of "object", it performs the following
1490-    tests:
1491-
1492-       - If all elements are byte or unicode strings, it creates a
1493-         variable-length byte or unicode field, respectively.
1494-
1495-       - If all elements are numpy arrays of the same dtype and with a
1496-         consistent shape in all but the first dimension, it creates a
1497-         variable length array of fixed sized arrays.  If the dtypes
1498-         match, but the shapes do not, a variable length array is
1499-         created.
1500-
1501-    If the dtype of the input is not understood, it sets the data type
1502-    to the most inclusive: a variable length unicodeChar array.
1503-
1504-    Parameters
1505-    ----------
1506-    column : `astropy.table.Column` instance
1507-
1508-    Returns
1509-    -------
1510-    attributes : dict
1511-        A dict containing 'datatype' and 'arraysize' keys that can be
1512-        set on a VOTable FIELD element.
1513-    """
1514-    votable_string_dtype = None
1515-    max_length = None
1516-    original_arraysize = None
1517-
1518-    if column.info.meta is not None:
1519-        votable_string_dtype = column.info.meta.get("_votable_string_dtype")
1520-        # Check if we have stored the original arraysize with bounds
1521-        # If so, extract the max length
1522-        original_arraysize = column.info.meta.get("_votable_arraysize")
1523-        if (
1524-            original_arraysize is not None
1525-            and original_arraysize.endswith("*")
1526-            and not original_arraysize == "*"
1527-        ):
1528-            max_length = original_arraysize[:-1]
1529-
1530-    if column.dtype.char == "O":
1531-        arraysize = "*"
1532-
1533-        # If max length is stored use it to create a bounded var-length array
1534-        if max_length is not None:
1535-            arraysize = f"{max_length}*"
1536-
1537-        if votable_string_dtype is not None:
1538-            return {"datatype": votable_string_dtype, "arraysize": arraysize}
1539-        elif isinstance(column[0], np.ndarray):
1540-            dtype, shape = _all_matching_dtype(column)
1541-            if dtype is not False:
1542-                result = numpy_to_votable_dtype(dtype, shape)
1543-                if "arraysize" not in result:
1544-                    result["arraysize"] = arraysize
1545-                else:
1546-                    result["arraysize"] += "*"
1547-                return result
1548-
1549-        # All bets are off, do the most generic thing
1550-        return {"datatype": "unicodeChar", "arraysize": arraysize}
1551-
1552-    # For fixed size string columns, datatype here will be unicodeChar,
1553-    # but honor the original FIELD datatype if present.
1554-    result = numpy_to_votable_dtype(column.dtype, column.shape[1:])
1555-    if result["datatype"] == "unicodeChar" and votable_string_dtype == "char":
1556-        result["datatype"] = "char"
1557-
1558-    # If we stored the original arraysize, use it instead of what
1559-    # numpy_to_votable_dtype derives
1560-    if original_arraysize is not None:
1561-        result["arraysize"] = original_arraysize
1562-
1563-    return result
  1740	
  1741	        if self.description is not None:
  1742	            self.title = " ".join(x.strip() for x in self.description.splitlines())
  1743	        else:
  1744	            self.title = self.name
  1745	
  1746	        self._setup(config, pos)
  1747	
  1748	        return self
  1749	
  1750	    def to_xml(self, w, **kwargs):
  1751	        attrib = w.object_attrs(self, self._attr_list)
  1752	        if "unit" in attrib:
  1753	            format = _get_unit_format(self._config)
  1754	            try:
  1755	                attrib["unit"] = self.unit.to_string(format)
  1756	            except ValueError as e:
  1757	                # Allow non-standard units with a warning, see
  1758	                # https://github.com/astropy/astropy/issues/17497#issuecomment-2520472495
  1759	                attrib["unit"] = self.unit.to_string()
  1760	                warn_or_raise(W50, W50, (attrib["unit"],), self._config, self._pos)
  1761	        with w.tag(self._element_name, attrib=attrib):
  1762	            if self.description is not None:
  1763	                w.element("DESCRIPTION", self.description, wrap=True)
  1764	            if not self.values.is_defaults():
  1765	                self.values.to_xml(w, **kwargs)
  1766	            for link in self.links:
  1767	                link.to_xml(w, **kwargs)
  1768	
  1769	    def to_table_column(self, column):
  1770	        """Copy this FIELD's metadata to an Astropy table column."""
  1771	        for key in ("ucd", "width", "precision", "utype", "xtype"):
  1772	            val = getattr(self, key, None)
  1773	            if val is not None:
  1774	                column.meta[key] = val
  1775	
  1776	        if self.unit is not None:
  1777	            column.unit = self.unit
  1778	        if self.description is not None:
  1779	            column.description = self.description
  1780	
  1781	        self.values.to_table_column(column)
  1782	        for link in self.links:
  1783	            link.to_table_column(column)
  1784	
  1785	
  1786	
  1787	
  1788	
  1789	
  1790	
  1791	
  1792	
  1793	
  1794	
  1795	
  1796	
  1797	
  1798	
  1799	
  1800	
  1801	
  1802	
  1803	
  1804	
  1805	
  1806	
  1807	
  1808	
  1809	
  1810	
  1811	
  1812	
  1813	
  1814	
  1815	
  1816	
  1817	    @classmethod
  1818	    def from_table_column(cls, votable, column):
  1819	        """
  1820	        Restores a `Field` instance from a given
  1821	        `astropy.table.Column` instance.
  1822	        """
  1823	        kwargs = {}
  1824	        meta = column.info.meta
  1825	        if meta:
  1826	            for key in ["ucd", "width", "precision", "utype", "xtype"]:
  1827	                val = meta.get(key, None)
  1828	                if val is not None:
  1829	                    kwargs[key] = val
  1830	        # TODO: Use the unit framework when available
  1831	        if column.info.unit is not None:
  1832	            kwargs["unit"] = column.info.unit
  1833	        kwargs["name"] = column.info.name
  1834	        result = converters.table_column_to_votable_datatype(column)
  1835	        kwargs.update(result)
Traceback (most recent call last):
  File "/testbed/astropy/utils/data.py", line 1548, in download_file
    f_name = _download_file_from_source(
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/utils/data.py", line 1332, in _download_file_from_source
    with _try_url_open(
         ^^^^^^^^^^^^^^
  File "/testbed/astropy/utils/data.py", line 1246, in _try_url_open
    return urlopener.open(req, timeout=timeout)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/urllib/request.py", line 525, in open
    response = meth(req, response)
               ^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/urllib/request.py", line 634, in http_response
    response = self.parent.error(
               ^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/urllib/request.py", line 563, in error
    return self._call_chain(*args)
           ^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/urllib/request.py", line 496, in _call_chain
    result = func(*args)
             ^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/urllib/request.py", line 643, in http_error_default
    raise HTTPError(req.full_url, code, msg, hdrs, fp)
urllib.error.HTTPError: HTTP Error 403: Forbidden

The above exception was the direct cause of the following exception:

Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
  File "/testbed/astropy/utils/data.py", line 770, in get_pkg_data_filename
    return download_file(
           ^^^^^^^^^^^^^^
  File "/testbed/astropy/utils/data.py", line 1586, in download_file
    raise urllib.error.URLError(
urllib.error.URLError: <urlopen error Unable to open any source! Exceptions were {'http://data.astropy.org/data/regression.xml': <HTTPError 403: 'Forbidden'>, 'http://www.astropy.org/astropy-data/data/regression.xml': <HTTPError 403: 'Forbidden'>}>
```

## 原始行 167 · command_execution

命令：
```
/bin/bash -lc "sed -n '65,90p' astropy/io/votable/tests/data/regression.xml; sed -n '160,180p' astropy/io/votable/tests/data/regression.xml; grep -n -A 10 -B 5 \"bitarray\" astropy/io/votable/tests/data/regression.xml; grep -n -A 20 -B 5 \"class E02\\|class E04\" astropy/io/votable/exceptions.py"
```

退出码：`0`

输出：
```
<FIELD ID="float" name="float" datatype="float">
  <VALUES null=""/>
</FIELD>
<FIELD ID="array" name="array" datatype="long" arraysize="2x2*">
  <VALUES null="-1"/>
</FIELD>
<FIELD ID="bit" name="bit" datatype="bit"/>
<FIELD ID="bitarray" name="bitarray" datatype="bit" arraysize="2x3"/>
<FIELD ID="bitvararray" name="bitvararray" datatype="bit" arraysize="*"/>
<FIELD ID="bitvararray2" name="bitvararray2" datatype="bit" arraysize="2x3x*"/>
<FIELD ID="floatComplex" name="floatComplex" datatype="floatComplex"/>
<FIELD ID="doubleComplex" name="doubleComplex" datatype="doubleComplex"/>
<FIELD ID="doubleComplexArray" name="doubleComplexArray" datatype="doubleComplex" arraysize="*"/>
<FIELD ID="doubleComplexArrayFixed" name="doubleComplexArrayFixed" datatype="doubleComplex" arraysize="2"/>
<FIELD ID="boolean" name="boolean" datatype="boolean"/>
<FIELD ID="booleanArray" name="booleanArray" datatype="boolean" arraysize="4"/>
<FIELD ID="nulls" name="nulls" datatype="int">
  <VALUES null="-9"/>
</FIELD>
<FIELD ID="nulls_array" name="nulls_array" datatype="int" arraysize="2x2">
  <VALUES null="-9"/>
</FIELD>
<FIELD ID="precision1" name="precision1" datatype="double" precision="E3" width="10"/>
<FIELD ID="precision2" name="precision2" datatype="double" precision="F3"/>
<FIELD ID="doublearray" name="doublearray" datatype="double" arraysize="*">
  <VALUES null="-1"/>
  <TD>0 0</TD>
  <TD>0 0</TD>
  <TD>0 0 0 0</TD>
  <TD>0 -1 -1 -1</TD>
  <TD>FaLsE</TD>
  <TD>true true falSE TRUE</TD>
  <TD>-9</TD>
  <TD>0 1 2 3</TD>
  <TD>1.0</TD>
  <TD>1.0</TD>
  <TD>0 1 Inf -Inf NaN 0 -1</TD>
  <TD/>
</TR>
<TR>
  <TD>XXXX </TD>
  <TD> XXXX </TD> <!-- Shouldn't output extra 0 bytes even though field is wider than string -->
  <TD> XXXX </TD>
  <TD>0123456789A</TD>
  <TD/>
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
  <TD>-4096</TD> <!-- negative, perfectly valid -->
67-</FIELD>
68-<FIELD ID="array" name="array" datatype="long" arraysize="2x2*">
69-  <VALUES null="-1"/>
70-</FIELD>
71-<FIELD ID="bit" name="bit" datatype="bit"/>
72:<FIELD ID="bitarray" name="bitarray" datatype="bit" arraysize="2x3"/>
73-<FIELD ID="bitvararray" name="bitvararray" datatype="bit" arraysize="*"/>
74-<FIELD ID="bitvararray2" name="bitvararray2" datatype="bit" arraysize="2x3x*"/>
75-<FIELD ID="floatComplex" name="floatComplex" datatype="floatComplex"/>
76-<FIELD ID="doubleComplex" name="doubleComplex" datatype="doubleComplex"/>
77-<FIELD ID="doubleComplexArray" name="doubleComplexArray" datatype="doubleComplex" arraysize="*"/>
78-<FIELD ID="doubleComplexArrayFixed" name="doubleComplexArrayFixed" datatype="doubleComplex" arraysize="2"/>
79-<FIELD ID="boolean" name="boolean" datatype="boolean"/>
80-<FIELD ID="booleanArray" name="booleanArray" datatype="boolean" arraysize="4"/>
81-<FIELD ID="nulls" name="nulls" datatype="int">
82-  <VALUES null="-9"/>
--
87-<FIELD ID="precision1" name="precision1" datatype="double" precision="E3" width="10"/>
88-<FIELD ID="precision2" name="precision2" datatype="double" precision="F3"/>
89-<FIELD ID="doublearray" name="doublearray" datatype="double" arraysize="*">
90-  <VALUES null="-1"/>
91-</FIELD>
92:<FIELD ID="bitarray2" name="bitarray2" datatype="bit" arraysize="16"/>
93-<GROUP>
94-  <DESCRIPTION>
95-    This is just a group to make sure we can round-trip them.
96-  </DESCRIPTION>
97-  <DESCRIPTION>
98-    This should warn of a second description.
99-  </DESCRIPTION>
100-  <FIELDref ref="boolean"/>
101-  <GROUP>
102-    <PARAMref ref="awesome"/>
1227-
1228-    message_template = "Invalid size specifier '{}' for a {} field (in field '{}')"
1229-    default_args = ("x", "char/unicode", "y")
1230-
1231-
1232:class E02(VOWarning, ValueError):
1233-    """Incorrect number of elements in array.
1234-
1235-    The number of array elements in the data does not match that specified
1236-    in the FIELD specifier.
1237-    """
1238-
1239-    message_template = (
1240-        "Incorrect number of elements in array. Expected multiple of {}, got {}"
1241-    )
1242-    default_args = ("x", "y")
1243-
1244-
1245-class E03(VOWarning, ValueError):
1246-    """Complex numbers should be two values separated by whitespace.
1247-
1248-    **References**: `1.1
1249-    <http://www.ivoa.net/documents/VOTable/20040811/REC-VOTable-1.1-20040811.html#sec:datatypes>`__,
1250-    `1.2
1251-    <http://www.ivoa.net/documents/VOTable/20091130/REC-VOTable-1.2.html#sec:datatypes>`__
1252-    """
1253-
1254-    message_template = "'{}' does not parse as a complex number"
1255-    default_args = ("x",)
1256-
1257-
1258:class E04(VOWarning, ValueError):
1259-    """A ``bit`` array should be a string of '0's and '1's.
1260-
1261-    **References**: `1.1
1262-    <http://www.ivoa.net/documents/VOTable/20040811/REC-VOTable-1.1-20040811.html#sec:datatypes>`__,
1263-    `1.2
1264-    <http://www.ivoa.net/documents/VOTable/20091130/REC-VOTable-1.2.html#sec:datatypes>`__
1265-    """
1266-
1267-    message_template = "Invalid bit value '{}'"
1268-    default_args = ("x",)
1269-
1270-
1271-class E05(VOWarning, ValueError):
1272-    r"""Invalid boolean value.
1273-
1274-    A ``boolean`` value should be one of the following strings (case
1275-    insensitive) in the ``TABLEDATA`` format::
1276-
1277-        'TRUE', 'FALSE', '1', '0', 'T', 'F', '\0', ' ', '?'
1278-
```

## 原始行 170 · command_execution

命令：
```
/bin/bash -lc "sed -n '490,530p' astropy/io/votable/tests/test_vo.py; sed -n '645,685p' astropy/io/votable/tests/test_vo.py; sed -n '720,745p' astropy/io/votable/tests/test_vo.py"
```

退出码：`0`

输出：
```
        assert self.array.data["array"][4].mask[0][1]

    def test_bit(self):
        assert issubclass(self.array["bit"].dtype.type, np.bool_)
        assert_array_equal(self.array["bit"], [True, False, True, False, False])

    def test_bit_mask(self):
        assert_array_equal(self.mask["bit"], [False, False, False, False, True])

    def test_bitarray(self):
        assert issubclass(self.array["bitarray"].dtype.type, np.bool_)
        assert self.array["bitarray"].shape == (5, 3, 2)
        assert_array_equal(
            self.array["bitarray"],
            [
                [[True, False], [True, True], [False, True]],
                [[False, True], [False, False], [True, True]],
                [[True, True], [True, False], [False, False]],
                [[False, False], [False, False], [False, False]],
                [[False, False], [False, False], [False, False]],
            ],
        )

    def test_bitarray_mask(self):
        assert_array_equal(
            self.mask["bitarray"],
            [
                [[False, False], [False, False], [False, False]],
                [[False, False], [False, False], [False, False]],
                [[False, False], [False, False], [False, False]],
                [[True, True], [True, True], [True, True]],
                [[True, True], [True, True], [True, True]],
            ],
        )

    def test_bitvararray(self):
        assert issubclass(self.array["bitvararray"].dtype.type, np.object_)
        match = [
            [True, True, True],
            [False, False, False, False, False],
            [True, False, True, False, True],
        assert_array_equal(
            self.array["doublearray"][1], [0, 1, np.inf, -np.inf, np.nan, 0, -1]
        )
        assert_array_equal(
            self.array.data["doublearray"][1].mask,
            [False, False, False, False, False, False, True],
        )

    def test_bit_array2(self):
        assert_array_equal(
            self.array["bitarray2"][0],
            [
                True,
                True,
                True,
                True,
                False,
                False,
                False,
                False,
                True,
                True,
                True,
                True,
                False,
                False,
                False,
                False,
            ],
        )

    def test_bit_array2_mask(self):
        assert not np.any(self.mask["bitarray2"][0])
        assert np.all(self.mask["bitarray2"][1:])

    def test_get_coosys_by_id(self):
        coosys = self.votable.get_coosys_by_id("J2000")
        assert coosys.system == "eq_FK5"

    def test_get_field_by_utype(self):
        fields = list(self.votable.get_fields_by_utype("myint"))
        self.xmlout = bio = io.BytesIO()
        # W39: Bit values can not be masked
        with pytest.warns(W39):
            votable.to_xml(bio)
        bio.seek(0)
        self.votable = parse(bio)
        self.table = self.votable.get_first_table()
        self.array = self.table.array
        self.mask = self.table.array.mask

    def test_bit_mask(self):
        assert_array_equal(self.mask["bit"], [False, False, False, False, False])

    def test_bitarray_mask(self):
        assert not np.any(self.mask["bitarray"])

    def test_bit_array2_mask(self):
        assert not np.any(self.mask["bitarray2"])

    def test_schema(self, tmp_path):
        # have to use an actual file because assert_validate_schema only works
        # on filenames, not file-like objects
        fn = tmp_path / "test_through_tabledata.xml"
        with open(fn, "wb") as f:
            f.write(self.xmlout.getvalue())
        assert_validate_schema(fn, "1.1")
```

## 原始行 173 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def get_converter\" -A 150 astropy/io/votable/converters.py; sed -n '105,140p' astropy/io/votable/tests/data/regression.xml"
```

退出码：`0`

输出：
```
1357:def get_converter(field, config=None, pos=None):
1358-    """
1359-    Get an appropriate converter instance for a given field.
1360-
1361-    Parameters
1362-    ----------
1363-    field : astropy.io.votable.tree.Field
1364-
1365-    config : dict, optional
1366-        Parser configuration dictionary
1367-
1368-    pos : tuple
1369-        Position in the input XML file.  Used for error messages.
1370-
1371-    Returns
1372-    -------
1373-    converter : astropy.io.votable.converters.Converter
1374-    """
1375-    if config is None:
1376-        config = {}
1377-
1378-    if field.datatype not in converter_mapping:
1379-        vo_raise(E06, (field.datatype, field.ID), config)
1380-
1381-    cls = converter_mapping[field.datatype]
1382-    converter = cls(field, config, pos)
1383-
1384-    arraysize = field.arraysize
1385-
1386-    # With numeric datatypes, special things need to happen for
1387-    # arrays.
1388-    if field.datatype not in ("char", "unicodeChar") and arraysize is not None:
1389-        if arraysize[-1] == "*":
1390-            arraysize = arraysize[:-1]
1391-            last_x = arraysize.rfind("x")
1392-            if last_x == -1:
1393-                arraysize = ""
1394-            else:
1395-                arraysize = arraysize[:last_x]
1396-            fixed = False
1397-        else:
1398-            fixed = True
1399-
1400-        if arraysize != "":
1401-            arraysize = [int(x) for x in arraysize.split("x")]
1402-            arraysize.reverse()
1403-        else:
1404-            arraysize = []
1405-
1406-        if arraysize != []:
1407-            converter = converter.array_type(field, converter, arraysize, config)
1408-
1409-        if not fixed:
1410-            converter = converter.vararray_type(field, converter, arraysize, config)
1411-
1412-    return converter
1413-
1414-
1415-numpy_dtype_to_field_mapping = {
1416-    np.float64().dtype.num: "double",
1417-    np.float32().dtype.num: "float",
1418-    np.bool_().dtype.num: "bit",
1419-    np.uint8().dtype.num: "unsignedByte",
1420-    np.int16().dtype.num: "short",
1421-    np.int32().dtype.num: "int",
1422-    np.int64().dtype.num: "long",
1423-    np.complex64().dtype.num: "floatComplex",
1424-    np.complex128().dtype.num: "doubleComplex",
1425-    np.str_().dtype.num: "unicodeChar",
1426-    np.bytes_().dtype.num: "char",
1427-}
1428-
1429-
1430-def _all_matching_dtype(column):
1431-    first_dtype = False
1432-    first_shape = ()
1433-    for x in column:
1434-        if not isinstance(x, np.ndarray) or len(x) == 0:
1435-            continue
1436-
1437-        if first_dtype is False:
1438-            first_dtype = x.dtype
1439-            first_shape = x.shape[1:]
1440-        elif first_dtype != x.dtype:
1441-            return False, ()
1442-        elif first_shape != x.shape[1:]:
1443-            first_shape = ()
1444-    return first_dtype, first_shape
1445-
1446-
1447-def numpy_to_votable_dtype(dtype, shape):
1448-    """
1449-    Converts a numpy dtype and shape to a dictionary of attributes for
1450-    a VOTable FIELD element and correspond to that type.
1451-
1452-    Parameters
1453-    ----------
1454-    dtype : Numpy dtype instance
1455-
1456-    shape : tuple
1457-
1458-    Returns
1459-    -------
1460-    attributes : dict
1461-        A dict containing 'datatype' and 'arraysize' keys that can be
1462-        set on a VOTable FIELD element.
1463-    """
1464-    if dtype.num not in numpy_dtype_to_field_mapping:
1465-        raise TypeError(f"{dtype!r} can not be represented in VOTable")
1466-
1467-    if dtype.char == "S":
1468-        return {"datatype": "char", "arraysize": str(dtype.itemsize)}
1469-    elif dtype.char == "U":
1470-        return {"datatype": "unicodeChar", "arraysize": str(dtype.itemsize // 4)}
1471-    else:
1472-        result = {"datatype": numpy_dtype_to_field_mapping[dtype.num]}
1473-        if len(shape):
1474-            result["arraysize"] = "x".join(str(x) for x in shape)
1475-
1476-        return result
1477-
1478-
1479-def table_column_to_votable_datatype(column):
1480-    """
1481-    Given a `astropy.table.Column` instance, returns the attributes
1482-    necessary to create a VOTable FIELD element that corresponds to
1483-    the type of the column.
1484-
1485-    This necessarily must perform some heuristics to determine the
1486-    type of variable length arrays fields, since they are not directly
1487-    supported by Numpy.
1488-
1489-    If the column has dtype of "object", it performs the following
1490-    tests:
1491-
1492-       - If all elements are byte or unicode strings, it creates a
1493-         variable-length byte or unicode field, respectively.
1494-
1495-       - If all elements are numpy arrays of the same dtype and with a
1496-         consistent shape in all but the first dimension, it creates a
1497-         variable length array of fixed sized arrays.  If the dtypes
1498-         match, but the shapes do not, a variable length array is
1499-         created.
1500-
1501-    If the dtype of the input is not understood, it sets the data type
1502-    to the most inclusive: a variable length unicodeChar array.
1503-
1504-    Parameters
1505-    ----------
1506-    column : `astropy.table.Column` instance
1507-
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" arraysize="*" unit="deg">
    <DESCRIPTION>This is the most interesting parameter in the world, and it drinks Dos Equis</DESCRIPTION>
  </PARAM>
</GROUP>
<DATA>
<TABLEDATA>
<TR>
  <TD>String &amp; test</TD>
  <TD>Fixed string long test</TD> <!-- Should truncate -->
  <TD>Ceçi n'est pas un pipe</TD> <!-- French, n'est-ce pas? -->
  <TD>Ceçi n'est pas un pipe</TD>
  <TD>ab cd</TD>
  <TD>128</TD>
  <TD>4096</TD>
  <TD>268435456</TD>
  <TD>3</TD>
  <TD>922337203685477</TD>
  <TD>8.9990234375</TD>
  <TD encoding="base64">P4AAAA==</TD>
  <TD>   </TD>
  <TD>1</TD>
  <TD>1 0 1 1 0 1</TD>
  <TD>1 1 1</TD>
  <TD/>
  <TD/>
  <TD/>
  <TD/>
  <TD>0 0 0 0</TD>
  <TD>True</TD>
  <TD>True True True True</TD>
  <TD>0</TD>
  <TD/>
  <TD>1.333333333333333333333333333333333</TD>
  <TD>1.333333333333333333333333333333333</TD>
  <TD/>
  <TD>1 1 1 1 0 0 0 0 1 1 1 1 0 0 0 0</TD>
```

## 原始行 176 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import warnings
from astropy.io.votable.table import parse
from astropy.io.votable import exceptions
p='astropy/io/votable/tests/data/gemini.xml'
with warnings.catch_warnings(record=True) as w:
 warnings.simplefilter('always')
 parse(p, verify='warn')
for i,x in enumerate(w,1): print(i,type(x.message).__name__,str(x.message))
PY"
```

退出码：`0`

输出：
```
1 W49 astropy/io/votable/tests/data/gemini.xml:37:12: W49: Empty cell illegal for integer fields.
2 W49 astropy/io/votable/tests/data/gemini.xml:49:12: W49: Empty cell illegal for integer fields.
3 W49 astropy/io/votable/tests/data/gemini.xml:61:12: W49: Empty cell illegal for integer fields.
4 W48 astropy/io/votable/tests/data/gemini.xml:79:10: W48: Unknown attribute 'spurious' on OPTION
5 W06 astropy/io/votable/tests/data/gemini.xml:98:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
6 W06 astropy/io/votable/tests/data/gemini.xml:99:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
7 E02 astropy/io/votable/tests/data/gemini.xml:99:6: E02: Incorrect number of elements in array. Expected multiple of 3, got 1
8 W06 astropy/io/votable/tests/data/gemini.xml:100:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
9 E02 astropy/io/votable/tests/data/gemini.xml:101:6: E02: Incorrect number of elements in array. Expected multiple of 2, got 1
10 E02 astropy/io/votable/tests/data/gemini.xml:102:6: E02: Incorrect number of elements in array. Expected multiple of 2, got 1
11 W06 astropy/io/votable/tests/data/gemini.xml:112:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
12 W06 astropy/io/votable/tests/data/gemini.xml:113:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
13 E02 astropy/io/votable/tests/data/gemini.xml:113:6: E02: Incorrect number of elements in array. Expected multiple of 3, got 1
14 W06 astropy/io/votable/tests/data/gemini.xml:114:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
15 E02 astropy/io/votable/tests/data/gemini.xml:115:6: E02: Incorrect number of elements in array. Expected multiple of 2, got 1
16 E02 astropy/io/votable/tests/data/gemini.xml:116:6: E02: Incorrect number of elements in array. Expected multiple of 2, got 1
17 W06 astropy/io/votable/tests/data/gemini.xml:126:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
18 W06 astropy/io/votable/tests/data/gemini.xml:127:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
19 E02 astropy/io/votable/tests/data/gemini.xml:127:6: E02: Incorrect number of elements in array. Expected multiple of 3, got 1
20 W30 astropy/io/votable/tests/data/gemini.xml:128:8: W30: Invalid literal for float '249.4461412814794 6.208882135413049 0.04682149110213382'.  Treating as empty.
21 W06 astropy/io/votable/tests/data/gemini.xml:132:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word
22 W30 astropy/io/votable/tests/data/gemini.xml:133:8: W30: Invalid literal for float '249.39904413680034 6.208645591686135 249.39911774129286 6.209064581212914 249.49323846809307 6.209114516657962 249.49307002200794 6.208699271984017'.  Treating as empty.
23 E02 astropy/io/votable/tests/data/gemini.xml:137:6: E02: Incorrect number of elements in array. Expected multiple of 2, got 1
24 W30 astropy/io/votable/tests/data/gemini.xml:138:8: W30: Invalid literal for float '4.1449399999999995E-7 7.416079999999999E-7'.  Treating as empty.
25 W06 astropy/io/votable/tests/data/gemini.xml:150:6: W06: Invalid UCD 'obs.field': Secondary word 'obs.field' is not valid as a primary word (suppressing further warnings of this type...)
26 E02 astropy/io/votable/tests/data/gemini.xml:151:6: E02: Incorrect number of elements in array. Expected multiple of 3, got 1
27 W30 astropy/io/votable/tests/data/gemini.xml:152:8: W30: Invalid literal for float '249.4461412814794 6.208882135413049 0.04682149110213382'.  Treating as empty.
28 W30 astropy/io/votable/tests/data/gemini.xml:157:8: W30: Invalid literal for float '249.39904413680034 6.208645591686135 249.39911774129286 6.209064581212914 249.49323846809307 6.209114516657962 249.49307002200794 6.208699271984017'.  Treating as empty.
29 E02 astropy/io/votable/tests/data/gemini.xml:161:6: E02: Incorrect number of elements in array. Expected multiple of 2, got 1 (suppressing further warnings of this type...)
30 W30 astropy/io/votable/tests/data/gemini.xml:162:8: W30: Invalid literal for float '4.1449399999999995E-7 7.416079999999999E-7'.  Treating as empty.
```

## 原始行 179 · file_change

```
{
  "id": "item_119",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/converters.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 182 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests/test_table.py --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
F..........ssss.........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.............Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.........                          [100%]
=================================== FAILURES ===================================
__________________________________ test_table __________________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-2/test_table0')

    def test_table(tmp_path):
        # Read the VOTABLE
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            votable = parse(get_pkg_data_filename("data/regression.xml"))
        table = votable.get_first_table()
        astropy_table = table.to_table()
    
        for name in table.array.dtype.names:
            assert np.all(astropy_table.mask[name] == table.array.mask[name])
    
        votable2 = tree.VOTableFile.from_table(astropy_table)
        t = votable2.get_first_table()
    
        field_types = [
            ("string_test", {"datatype": "char", "arraysize": "*"}),
            ("string_test_2", {"datatype": "char", "arraysize": "10"}),
            ("unicode_test", {"datatype": "unicodeChar", "arraysize": "*"}),
            ("fixed_unicode_test", {"datatype": "unicodeChar", "arraysize": "10"}),
            ("string_array_test", {"datatype": "char", "arraysize": "4*"}),
            ("unsignedByte", {"datatype": "unsignedByte"}),
            ("short", {"datatype": "short"}),
            ("int", {"datatype": "int"}),
            ("intNoNull", {"datatype": "int"}),
            ("long", {"datatype": "long"}),
            ("double", {"datatype": "double"}),
            ("float", {"datatype": "float"}),
            ("array", {"datatype": "long", "arraysize": "2*"}),
            ("bit", {"datatype": "bit"}),
            ("bitarray", {"datatype": "bit", "arraysize": "3x2"}),
            ("bitvararray", {"datatype": "bit", "arraysize": "*"}),
            ("bitvararray2", {"datatype": "bit", "arraysize": "3x2*"}),
            ("floatComplex", {"datatype": "floatComplex"}),
            ("doubleComplex", {"datatype": "doubleComplex"}),
            ("doubleComplexArray", {"datatype": "doubleComplex", "arraysize": "*"}),
            ("doubleComplexArrayFixed", {"datatype": "doubleComplex", "arraysize": "2"}),
            ("boolean", {"datatype": "bit"}),
            ("booleanArray", {"datatype": "bit", "arraysize": "4"}),
            ("nulls", {"datatype": "int"}),
            ("nulls_array", {"datatype": "int", "arraysize": "2x2"}),
            ("precision1", {"datatype": "double"}),
            ("precision2", {"datatype": "double"}),
            ("doublearray", {"datatype": "double", "arraysize": "*"}),
            ("bitarray2", {"datatype": "bit", "arraysize": "16"}),
        ]
    
        for field, (name, d) in zip(t.fields, field_types):
            assert field.ID == name
            assert field.datatype == d["datatype"], (
                f"{name} expected {d['datatype']} but get {field.datatype}"
            )
            if "arraysize" in d:
>               assert field.arraysize == d["arraysize"]
E               AssertionError: assert '2x3' == '3x2'
E                 
E                 - 3x2
E                 + 2x3

astropy/io/votable/tests/test_table.py:113: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_table - AssertionError: a...
1 failed, 42 passed, 4 skipped in 0.34s
```

## 原始行 185 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
from astropy.io.votable.table import parse
p='astropy/io/votable/tests/data/regression.xml'
with np.errstate(over='ignore'): v=parse(p)
t=v.get_first_table(); a=t.to_table()
for i in [0,1,4,14,16,24]:
 f=t.fields[i]; c=a.columns[i]
 print(i,f.ID,f.arraysize,c.meta)
PY"
```

退出码：`0`

输出：
```
0 string_test * {'_votable_string_dtype': 'char', '_votable_arraysize': '*', 'values': {}}
1 string_test_2 10 {'_votable_string_dtype': 'char', '_votable_arraysize': '10', 'values': {}}
4 string_array_test 4* {'_votable_string_dtype': 'char', '_votable_arraysize': '4*', 'values': {}}
14 bitarray 2x3 {'_votable_arraysize': '2x3', 'values': {}}
16 bitvararray2 2x3x* {'_votable_arraysize': '2x3x*', 'values': {}}
24 nulls_array 2x2 {'_votable_arraysize': '2x2', 'values': {'null': -9}}
```

## 原始行 188 · file_change

```
{
  "id": "item_125",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 191 · command_execution

命令：
```
/bin/bash -lc "awk -F'|' 'NF "'!= 3 && $0 !~ /''^#/ {print NR ":" NF ":" $0}'"' astropy/io/votable/data/ucd1p-words.txt | head; python - <<'PY'
from astropy.utils.xml.check import check_id
for x in ['abc\\n','abc','']:
 print(repr(x),check_id(x))
PY"
```

退出码：`0`

输出：
```
'abc\n' True
'abc' True
'' False
```

## 原始行 195 · agent_message

```
The core VOTable table tests now pass except for one legacy round-trip detail: multidimensional numeric array sizes are intentionally re-derived in NumPy order, while only string array bounds are preserved verbatim. I’ve aligned that behavior and am now running the broader VOTable suite plus direct edge checks for UTF-16 code-unit lengths and self-reference lookups.
```

## 原始行 197 · file_change

```
{
  "id": "item_132",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/check.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 199 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests astropy/utils/tests/test_xml.py astropy/utils/xml/tests --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
...............................................ssss.........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

........... [ 22%]
..Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

........................................................FFFFF......... [ 44%]
........................................................................ [ 66%]
........................................................................ [ 88%]
..........FValidation report for /testbed/astropy/io/votable/tests/data/empty_table.xml

astropy.io.votable found no violations.

xmllint passed
.FF.FF
=================================== FAILURES ===================================
___________________________ test_parse_single_table2 ___________________________

    def test_parse_single_table2():
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            table2 = parse_single_table(
                get_pkg_data_filename("data/regression.xml"), table_number=1
            )
        assert isinstance(table2, tree.TableElement)
>       assert len(table2.array) == 1
E       AssertionError: assert 0 == 1
E        +  where 0 = len(masked_recarray(data=[],\n                mask=[],\n          fill_value=(array('?', dtype='<U1'), 'N/A', array('?', dty...rray', '<i4', (2, 2)), ('precision1', '<f8'), ('precision2', '<f8'), ('doublearray', 'O'), ('bitarray2', '?', (16,))])))
E        +    where masked_recarray(data=[],\n                mask=[],\n          fill_value=(array('?', dtype='<U1'), 'N/A', array('?', dty...rray', '<i4', (2, 2)), ('precision1', '<f8'), ('precision2', '<f8'), ('doublearray', 'O'), ('bitarray2', '?', (16,))])) = <VOTable length=0>\nstring_test string_test_2 unicode_test ... precision2 doublearray bitarray2\n   object       str10  ...ect    ...  float64      object    bool[16]\n----------- ------------- ------------ ... ---------- ----------- ---------.array

astropy/io/votable/tests/test_vo.py:62: AssertionError
___________________________ test_parse_single_table3 ___________________________

    def test_parse_single_table3():
>       with pytest.raises(IndexError):
E       Failed: DID NOT RAISE <class 'IndexError'>

astropy/io/votable/tests/test_vo.py:67: Failed
_______________________________ test_regression ________________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_regression0')

    @pytest.mark.xfail("legacy_float_repr")
    def test_regression(tmp_path):
        # W39: Bit values can not be masked
        with pytest.warns(W39), np.errstate(over="ignore"):
>           _test_regression(tmp_path, False)

astropy/io/votable/tests/test_vo.py:186: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_regression0')
_python_based = False, binary_mode = 1

    def _test_regression(tmp_path, _python_based=False, binary_mode=1):
        # Read the VOTABLE
        votable = parse(
            get_pkg_data_filename("data/regression.xml"),
            _debug_python_based_parser=_python_based,
        )
        table = votable.get_first_table()
    
        dtypes = [
            (("string test", "string_test"), "|O8"),
            (("fixed string test", "string_test_2"), "<U10"),
            ("unicode_test", "|O8"),
            (("unicode test", "fixed_unicode_test"), "<U10"),
            (("string array test", "string_array_test"), "<U4"),
            ("unsignedByte", "|u1"),
            ("short", "<i2"),
            ("int", "<i4"),
            ("intNoNull", "<i4"),
            ("long", "<i8"),
            ("double", "<f8"),
            ("float", "<f4"),
            ("array", "|O8"),
            ("bit", "|b1"),
            ("bitarray", "|b1", (3, 2)),
            ("bitvararray", "|O8"),
            ("bitvararray2", "|O8"),
            ("floatComplex", "<c8"),
            ("doubleComplex", "<c16"),
            ("doubleComplexArray", "|O8"),
            ("doubleComplexArrayFixed", "<c16", (2,)),
            ("boolean", "|b1"),
            ("booleanArray", "|b1", (4,)),
            ("nulls", "<i4"),
            ("nulls_array", "<i4", (2, 2)),
            ("precision1", "<f8"),
            ("precision2", "<f8"),
            ("doublearray", "|O8"),
            ("bitarray2", "|b1", (16,)),
        ]
        if sys.byteorder == "big":
            new_dtypes = []
            for dtype in dtypes:
                dtype = list(dtype)
                dtype[1] = dtype[1].replace("<", ">")
                new_dtypes.append(tuple(dtype))
            dtypes = new_dtypes
        assert table.array.dtype == dtypes
    
        votable.to_xml(
            str(tmp_path / "regression.tabledata.xml"),
            _debug_python_based_parser=_python_based,
        )
        assert_validate_schema(str(tmp_path / "regression.tabledata.xml"), votable.version)
    
        if binary_mode == 1:
            votable.get_first_table().format = "binary"
            votable.version = "1.1"
        elif binary_mode == 2:
            votable.get_first_table()._config["version_1_3_or_later"] = True
            votable.get_first_table().format = "binary2"
            votable.version = "1.3"
    
        # Also try passing a file handle
        with open(str(tmp_path / "regression.binary.xml"), "wb") as fd:
            votable.to_xml(fd, _debug_python_based_parser=_python_based)
        assert_validate_schema(str(tmp_path / "regression.binary.xml"), votable.version)
        # Also try passing a file handle
        with open(str(tmp_path / "regression.binary.xml"), "rb") as fd:
            votable2 = parse(fd, _debug_python_based_parser=_python_based)
        votable2.get_first_table().format = "tabledata"
        votable2.to_xml(
            str(tmp_path / "regression.bin.tabledata.xml"),
            _astropy_version="testing",
            _debug_python_based_parser=_python_based,
        )
        assert_validate_schema(
            str(tmp_path / "regression.bin.tabledata.xml"), votable.version
        )
    
        with open(
            get_pkg_data_filename(
                f"data/regression.bin.tabledata.truth.{votable.version}.xml"
            ),
            encoding="utf-8",
        ) as fd:
            truth = fd.readlines()
        with open(str(tmp_path / "regression.bin.tabledata.xml"), encoding="utf-8") as fd:
            output = fd.readlines()
    
        # If the lines happen to be different, print a diff
        # This is convenient for debugging
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       assert ['<?xml versi... data\n', ...] == ['<?xml versi... data\n', ...]
E         
E         At index 16 diff: ' <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">\n' != ' <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km / h" value="0 0">\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:166: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -14,7 +14,7 @@
  </DESCRIPTION>
  <COOSYS ID="J2000" equinox="J2000" system="eq_FK5"/>
  <PARAM ID="wrong_arraysize" arraysize="0" datatype="float" name="wrong_arraysize" value=""/>
- <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">
+ <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km / h" value="0 0">
   <DESCRIPTION>
    This is the most interesting parameter in the world, and it drinks
    Dos Equis
_____________________ test_regression_python_based_parser ______________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_regression_python_based_p0')

    @pytest.mark.xfail("legacy_float_repr")
    def test_regression_python_based_parser(tmp_path):
        # W39: Bit values can not be masked
        with pytest.warns(W39), np.errstate(over="ignore"):
>           _test_regression(tmp_path, True)

astropy/io/votable/tests/test_vo.py:193: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_regression_python_based_p0')
_python_based = True, binary_mode = 1

    def _test_regression(tmp_path, _python_based=False, binary_mode=1):
        # Read the VOTABLE
        votable = parse(
            get_pkg_data_filename("data/regression.xml"),
            _debug_python_based_parser=_python_based,
        )
        table = votable.get_first_table()
    
        dtypes = [
            (("string test", "string_test"), "|O8"),
            (("fixed string test", "string_test_2"), "<U10"),
            ("unicode_test", "|O8"),
            (("unicode test", "fixed_unicode_test"), "<U10"),
            (("string array test", "string_array_test"), "<U4"),
            ("unsignedByte", "|u1"),
            ("short", "<i2"),
            ("int", "<i4"),
            ("intNoNull", "<i4"),
            ("long", "<i8"),
            ("double", "<f8"),
            ("float", "<f4"),
            ("array", "|O8"),
            ("bit", "|b1"),
            ("bitarray", "|b1", (3, 2)),
            ("bitvararray", "|O8"),
            ("bitvararray2", "|O8"),
            ("floatComplex", "<c8"),
            ("doubleComplex", "<c16"),
            ("doubleComplexArray", "|O8"),
            ("doubleComplexArrayFixed", "<c16", (2,)),
            ("boolean", "|b1"),
            ("booleanArray", "|b1", (4,)),
            ("nulls", "<i4"),
            ("nulls_array", "<i4", (2, 2)),
            ("precision1", "<f8"),
            ("precision2", "<f8"),
            ("doublearray", "|O8"),
            ("bitarray2", "|b1", (16,)),
        ]
        if sys.byteorder == "big":
            new_dtypes = []
            for dtype in dtypes:
                dtype = list(dtype)
                dtype[1] = dtype[1].replace("<", ">")
                new_dtypes.append(tuple(dtype))
            dtypes = new_dtypes
        assert table.array.dtype == dtypes
    
        votable.to_xml(
            str(tmp_path / "regression.tabledata.xml"),
            _debug_python_based_parser=_python_based,
        )
        assert_validate_schema(str(tmp_path / "regression.tabledata.xml"), votable.version)
    
        if binary_mode == 1:
            votable.get_first_table().format = "binary"
            votable.version = "1.1"
        elif binary_mode == 2:
            votable.get_first_table()._config["version_1_3_or_later"] = True
            votable.get_first_table().format = "binary2"
            votable.version = "1.3"
    
        # Also try passing a file handle
        with open(str(tmp_path / "regression.binary.xml"), "wb") as fd:
            votable.to_xml(fd, _debug_python_based_parser=_python_based)
        assert_validate_schema(str(tmp_path / "regression.binary.xml"), votable.version)
        # Also try passing a file handle
        with open(str(tmp_path / "regression.binary.xml"), "rb") as fd:
            votable2 = parse(fd, _debug_python_based_parser=_python_based)
        votable2.get_first_table().format = "tabledata"
        votable2.to_xml(
            str(tmp_path / "regression.bin.tabledata.xml"),
            _astropy_version="testing",
            _debug_python_based_parser=_python_based,
        )
        assert_validate_schema(
            str(tmp_path / "regression.bin.tabledata.xml"), votable.version
        )
    
        with open(
            get_pkg_data_filename(
                f"data/regression.bin.tabledata.truth.{votable.version}.xml"
            ),
            encoding="utf-8",
        ) as fd:
            truth = fd.readlines()
        with open(str(tmp_path / "regression.bin.tabledata.xml"), encoding="utf-8") as fd:
            output = fd.readlines()
    
        # If the lines happen to be different, print a diff
        # This is convenient for debugging
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       assert ['<?xml versi... data\n', ...] == ['<?xml versi... data\n', ...]
E         
E         At index 16 diff: ' <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">\n' != ' <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km / h" value="0 0">\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:166: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -14,7 +14,7 @@
  </DESCRIPTION>
  <COOSYS ID="J2000" equinox="J2000" system="eq_FK5"/>
  <PARAM ID="wrong_arraysize" arraysize="0" datatype="float" name="wrong_arraysize" value=""/>
- <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">
+ <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km / h" value="0 0">
   <DESCRIPTION>
    This is the most interesting parameter in the world, and it drinks
    Dos Equis
___________________________ test_regression_binary2 ____________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_regression_binary20')

    @pytest.mark.xfail("legacy_float_repr")
    def test_regression_binary2(tmp_path):
        # W39: Bit values can not be masked
        with pytest.warns(W39), np.errstate(over="ignore"):
>           _test_regression(tmp_path, False, 2)

astropy/io/votable/tests/test_vo.py:200: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_regression_binary20')
_python_based = False, binary_mode = 2

    def _test_regression(tmp_path, _python_based=False, binary_mode=1):
        # Read the VOTABLE
        votable = parse(
            get_pkg_data_filename("data/regression.xml"),
            _debug_python_based_parser=_python_based,
        )
        table = votable.get_first_table()
    
        dtypes = [
            (("string test", "string_test"), "|O8"),
            (("fixed string test", "string_test_2"), "<U10"),
            ("unicode_test", "|O8"),
            (("unicode test", "fixed_unicode_test"), "<U10"),
            (("string array test", "string_array_test"), "<U4"),
            ("unsignedByte", "|u1"),
            ("short", "<i2"),
            ("int", "<i4"),
            ("intNoNull", "<i4"),
            ("long", "<i8"),
            ("double", "<f8"),
            ("float", "<f4"),
            ("array", "|O8"),
            ("bit", "|b1"),
            ("bitarray", "|b1", (3, 2)),
            ("bitvararray", "|O8"),
            ("bitvararray2", "|O8"),
            ("floatComplex", "<c8"),
            ("doubleComplex", "<c16"),
            ("doubleComplexArray", "|O8"),
            ("doubleComplexArrayFixed", "<c16", (2,)),
            ("boolean", "|b1"),
            ("booleanArray", "|b1", (4,)),
            ("nulls", "<i4"),
            ("nulls_array", "<i4", (2, 2)),
            ("precision1", "<f8"),
            ("precision2", "<f8"),
            ("doublearray", "|O8"),
            ("bitarray2", "|b1", (16,)),
        ]
        if sys.byteorder == "big":
            new_dtypes = []
            for dtype in dtypes:
                dtype = list(dtype)
                dtype[1] = dtype[1].replace("<", ">")
                new_dtypes.append(tuple(dtype))
            dtypes = new_dtypes
        assert table.array.dtype == dtypes
    
        votable.to_xml(
            str(tmp_path / "regression.tabledata.xml"),
            _debug_python_based_parser=_python_based,
        )
        assert_validate_schema(str(tmp_path / "regression.tabledata.xml"), votable.version)
    
        if binary_mode == 1:
            votable.get_first_table().format = "binary"
            votable.version = "1.1"
        elif binary_mode == 2:
            votable.get_first_table()._config["version_1_3_or_later"] = True
            votable.get_first_table().format = "binary2"
            votable.version = "1.3"
    
        # Also try passing a file handle
        with open(str(tmp_path / "regression.binary.xml"), "wb") as fd:
            votable.to_xml(fd, _debug_python_based_parser=_python_based)
        assert_validate_schema(str(tmp_path / "regression.binary.xml"), votable.version)
        # Also try passing a file handle
        with open(str(tmp_path / "regression.binary.xml"), "rb") as fd:
            votable2 = parse(fd, _debug_python_based_parser=_python_based)
        votable2.get_first_table().format = "tabledata"
        votable2.to_xml(
            str(tmp_path / "regression.bin.tabledata.xml"),
            _astropy_version="testing",
            _debug_python_based_parser=_python_based,
        )
        assert_validate_schema(
            str(tmp_path / "regression.bin.tabledata.xml"), votable.version
        )
    
        with open(
            get_pkg_data_filename(
                f"data/regression.bin.tabledata.truth.{votable.version}.xml"
            ),
            encoding="utf-8",
        ) as fd:
            truth = fd.readlines()
        with open(str(tmp_path / "regression.bin.tabledata.xml"), encoding="utf-8") as fd:
            output = fd.readlines()
    
        # If the lines happen to be different, print a diff
        # This is convenient for debugging
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       assert ['<?xml versi... data\n', ...] == ['<?xml versi... data\n', ...]
E         
E         At index 16 diff: ' <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">\n' != ' <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km / h" value="0 0">\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:166: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -14,7 +14,7 @@
  </DESCRIPTION>
  <COOSYS ID="J2000" equinox="J2000" system="eq_FK5"/>
  <PARAM ID="wrong_arraysize" arraysize="0" datatype="float" name="wrong_arraysize" value=""/>
- <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">
+ <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km / h" value="0 0">
   <DESCRIPTION>
    This is the most interesting parameter in the world, and it drinks
    Dos Equis
________________________________ test_validate _________________________________

test_path_object = False

    def test_validate(test_path_object=False):
        """
        test_path_object is needed for test below ``test_validate_path_object``
        so that file could be passed as pathlib.Path object.
        """
        output = io.StringIO()
        fpath = get_pkg_data_filename("data/regression.xml")
        if test_path_object:
            fpath = pathlib.Path(fpath)
    
        # We can't test xmllint, because we can't rely on it being on the
        # user's machine.
        result = validate(fpath, output, xmllint=False)
    
        assert result is False
    
        output.seek(0)
        output = output.readlines()
    
        # Uncomment to generate new groundtruth
        # with open('validation.txt', 'wt', encoding='utf-8') as fd:
        #    fd.write(u''.join(output))
    
        with open(get_pkg_data_filename("data/validation.txt"), encoding="utf-8") as fd:
            truth = fd.readlines()
    
        truth = truth[1:]
        output = output[1:-1]
    
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       AssertionError: assert ['\n', '11: W...le of\n', ...] == ['\n', '11: W...le of\n', ...]
E         
E         At index 119 diff: '  16, got 0\n' != '  16, got 1\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:983: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -117,7 +117,7 @@
       ^
 
 171: E02: Incorrect number of elements in array. Expected multiple of
-  16, got 0
+  16, got 1
   <TD/>
   ^
 
@@ -164,7 +164,7 @@
       ^
 
 202: E02: Incorrect number of elements in array. Expected multiple of
-  16, got 0
+  16, got 1
   <TD/>
   ^
 
@@ -177,7 +177,7 @@
       ^
 
 219: E02: Incorrect number of elements in array. Expected multiple of
-  6, got 0
+  6, got 1
   <TD/>
   ^
 
@@ -187,7 +187,7 @@
   ^
 
 233: E02: Incorrect number of elements in array. Expected multiple of
-  16, got 0
+  16, got 1
   <TD/>
   ^
 
@@ -205,7 +205,7 @@
       ^
 
 250: E02: Incorrect number of elements in array. Expected multiple of
-  6, got 0
+  6, got 1
   <TD/>
   ^
 
__________________________ test_validate_path_object ___________________________

    def test_validate_path_object():
        """Validating when source is passed as path object (#4412)."""
>       test_validate(test_path_object=True)

astropy/io/votable/tests/test_vo.py:998: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

test_path_object = True

    def test_validate(test_path_object=False):
        """
        test_path_object is needed for test below ``test_validate_path_object``
        so that file could be passed as pathlib.Path object.
        """
        output = io.StringIO()
        fpath = get_pkg_data_filename("data/regression.xml")
        if test_path_object:
            fpath = pathlib.Path(fpath)
    
        # We can't test xmllint, because we can't rely on it being on the
        # user's machine.
        result = validate(fpath, output, xmllint=False)
    
        assert result is False
    
        output.seek(0)
        output = output.readlines()
    
        # Uncomment to generate new groundtruth
        # with open('validation.txt', 'wt', encoding='utf-8') as fd:
        #    fd.write(u''.join(output))
    
        with open(get_pkg_data_filename("data/validation.txt"), encoding="utf-8") as fd:
            truth = fd.readlines()
    
        truth = truth[1:]
        output = output[1:-1]
    
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       AssertionError: assert ['\n', '11: W...le of\n', ...] == ['\n', '11: W...le of\n', ...]
E         
E         At index 119 diff: '  16, got 0\n' != '  16, got 1\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:983: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -117,7 +117,7 @@
       ^
 
 171: E02: Incorrect number of elements in array. Expected multiple of
-  16, got 0
+  16, got 1
   <TD/>
   ^
 
@@ -164,7 +164,7 @@
       ^
 
 202: E02: Incorrect number of elements in array. Expected multiple of
-  16, got 0
+  16, got 1
   <TD/>
   ^
 
@@ -177,7 +177,7 @@
       ^
 
 219: E02: Incorrect number of elements in array. Expected multiple of
-  6, got 0
+  6, got 1
   <TD/>
   ^
 
@@ -187,7 +187,7 @@
   ^
 
 233: E02: Incorrect number of elements in array. Expected multiple of
-  16, got 0
+  16, got 1
   <TD/>
   ^
 
@@ -205,7 +205,7 @@
       ^
 
 250: E02: Incorrect number of elements in array. Expected multiple of
-  6, got 0
+  6, got 1
   <TD/>
   ^
 
____________________________ test_gzip_filehandles _____________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-3/test_gzip_filehandles0')

    def test_gzip_filehandles(tmp_path):
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            votable = parse(get_pkg_data_filename("data/regression.xml"))
    
        # W39: Bit values can not be masked
        with pytest.warns(W39):
            with open(tmp_path / "regression.compressed.xml", "wb") as fd:
                votable.to_xml(fd, compressed=True, _astropy_version="testing")
    
        with open(tmp_path / "regression.compressed.xml", "rb") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_vo.py:1012: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <VOTABLE>... 0 tables ...</VOTABLE>
iterator = <astropy.utils.xml._iterparser.IterParser object at 0x717c77cad0e0>
config = {'_current_table_number': 0, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}

    def parse(self, iterator, config):
        config["_current_table_number"] = 0
    
>       for start, tag, data, pos in iterator:
E       ValueError: 1:0: not well-formed (invalid token)

astropy/io/votable/tree.py:4446: ValueError
_________________________________ test_fileobj _________________________________

    def test_fileobj():
        # Assert that what we get back is a raw C file pointer
        # so it will be super fast in the C extension.
        from astropy.utils.xml import iterparser
    
        filename = get_pkg_data_filename("data/regression.xml")
        with iterparser._convert_to_fd_or_read_function(filename) as fd:
            if sys.platform == "win32":
                fd()
            else:
>               assert isinstance(fd, io.FileIO)
E               AssertionError: assert False
E                +  where False = isinstance(<built-in method read of _io.FileIO object at 0x717c78413680>, <class '_io.FileIO'>)
E                +    where <class '_io.FileIO'> = io.FileIO

astropy/io/votable/tests/test_vo.py:1062: AssertionError
____________________________ test_nonstandard_units ____________________________

    def test_nonstandard_units():
        from astropy import units as u
    
        votable = parse(get_pkg_data_filename("data/nonstandard_units.xml"))
    
>       assert isinstance(votable.get_first_table().fields[0].unit, u.UnrecognizedUnit)
E       assert False
E        +  where False = isinstance(Unit("erg / (Angstrom s cm2)"), <class 'astropy.units.core.UnrecognizedUnit'>)
E        +    where Unit("erg / (Angstrom s cm2)") = <FIELD ID="Flux1" datatype="double" name="Flux" ucd="phot.flux.density;em.wl" unit="erg / (Angstrom s cm2)" utype="spec:Data.FluxAxis.value"/>.unit
E        +    and   <class 'astropy.units.core.UnrecognizedUnit'> = <module 'astropy.units' from '/testbed/astropy/units/__init__.py'>.UnrecognizedUnit

astropy/io/votable/tests/test_vo.py:1070: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_vo.py::test_parse_single_table2 - Assert...
FAILED astropy/io/votable/tests/test_vo.py::test_parse_single_table3 - Failed...
FAILED astropy/io/votable/tests/test_vo.py::test_regression - assert ['<?xml ...
FAILED astropy/io/votable/tests/test_vo.py::test_regression_python_based_parser
FAILED astropy/io/votable/tests/test_vo.py::test_regression_binary2 - assert ...
FAILED astropy/io/votable/tests/test_vo.py::test_validate - AssertionError: a...
FAILED astropy/io/votable/tests/test_vo.py::test_validate_path_object - Asser...
FAILED astropy/io/votable/tests/test_vo.py::test_gzip_filehandles - ValueErro...
FAILED astropy/io/votable/tests/test_vo.py::test_fileobj - AssertionError: as...
FAILED astropy/io/votable/tests/test_vo.py::test_nonstandard_units - assert F...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 10 failures !!!!!!!!!!!!!!!!!!!!!!!!!!
10 failed, 291 passed, 4 skipped in 1.72s
```

## 原始行 202 · command_execution

命令：
```
/bin/bash -lc "sed -n '110,205p' astropy/io/votable/table.py; sed -n '45,75p' astropy/io/votable/tests/test_vo.py; grep -R -n \"get_first_table\" docs astropy/io/votable/tests | grep -E \"raises|empty|table_number|No table\" | head -n 50; nl -ba astropy/io/votable/tree.py | sed -n '270,320p'"
```

退出码：`0`

输出：
```
        the unit format to use will be the one specified by the
        VOTable specification (which is ``cds`` up to version 1.3 of
        VOTable, and ``vounit`` in more recent versions of the spec).

    datatype_mapping : dict, optional
        A mapping of datatype names (`str`) to valid VOTable datatype names
        (str). For example, if the file being read contains the datatype
        "unsignedInt" (an invalid datatype in VOTable), include the mapping
        ``{"unsignedInt": "long"}``.

    Returns
    -------
    votable : `~astropy.io.votable.tree.VOTableFile` object

    See Also
    --------
    astropy.io.votable.exceptions : The exceptions this function may raise.
    """
    from . import VERIFY_OPTIONS, conf

    invalid = invalid.lower()
    if invalid not in ("exception", "mask"):
        raise ValueError(
            "accepted values of ``invalid`` are: ``'exception'`` or ``'mask'``."
        )

    if verify is None:
        verify = conf.verify
    elif verify not in VERIFY_OPTIONS:
        raise ValueError(f"verify should be one of {'/'.join(VERIFY_OPTIONS)}")

    if datatype_mapping is None:
        datatype_mapping = {}

    config = {
        "columns": columns,
        "invalid": invalid,
        "verify": verify,
        "chunk_size": chunk_size,
        "table_number": table_number,
        "filename": filename,
        "unit_format": unit_format,
        "datatype_mapping": datatype_mapping,
    }

    if isinstance(source, str):
        source = os.path.expanduser(source)

    if filename is None and isinstance(source, str):
        config["filename"] = source

    with iterparser.get_xml_iterator(
        source, _debug_python_based_parser=_debug_python_based_parser
    ) as iterator:
        return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)


def parse_single_table(source, **kwargs):
    """
    Parses a VOTABLE_ xml file (or file-like object), reading and
    returning only the first `~astropy.io.votable.tree.TableElement`
    instance.

    See `parse` for a description of the keyword arguments.

    Returns
    -------
    votable : `~astropy.io.votable.tree.TableElement` object
    """
    if kwargs.get("table_number") is None:
        kwargs["table_number"] = 0

    votable = parse(source, **kwargs)

    return votable.get_first_table()


def writeto(table, file, tabledata_format=None):
    """
    Writes a `~astropy.io.votable.tree.VOTableFile` to a VOTABLE_ xml file.

    Parameters
    ----------
    table : `~astropy.io.votable.tree.VOTableFile` or `~astropy.table.Table` instance.

    file : str or :term:`file-like (writeable)`
        Path or file object to write to

    tabledata_format : str, optional
        Override the format of the table(s) data to write.  Must be
        one of ``tabledata`` (text representation), ``binary`` or
        ``binary2``.  By default, use the format that was specified in
        each ``table`` object as it was created or read in.  See
        :ref:`astropy:votable-serialization`.
    """
    from astropy.table import Table


def test_parse_single_table():
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        table = parse_single_table(get_pkg_data_filename("data/regression.xml"))
    assert isinstance(table, tree.TableElement)
    assert len(table.array) == 5


def test_parse_single_table2():
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        table2 = parse_single_table(
            get_pkg_data_filename("data/regression.xml"), table_number=1
        )
    assert isinstance(table2, tree.TableElement)
    assert len(table2.array) == 1
    assert len(table2.array.dtype.names) == 29


def test_parse_single_table3():
    with pytest.raises(IndexError):
        parse_single_table(get_pkg_data_filename("data/regression.xml"), table_number=3)


def _test_regression(tmp_path, _python_based=False, binary_mode=1):
    # Read the VOTABLE
    votable = parse(
        get_pkg_data_filename("data/regression.xml"),
        _debug_python_based_parser=_python_based,
grep: astropy/io/votable/tests/__pycache__/test_vo.cpython-311-pytest-9.0.1.pyc: binary file matches
grep: astropy/io/votable/tests/__pycache__/test_table.cpython-311-pytest-9.0.1.pyc: binary file matches
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	def _attach_default_config(votable, config) -> dict:
   278	    """Create default config if none given.
   279	
   280	    Parameters
   281	    ----------
   282	    votable
   283	        Object that might potentially have a config attached to it.
   284	    config : `dict` or `None`
   285	        Config to be used or defined.
   286	
   287	    Returns
   288	    -------
   289	    config : `dict`
   290	        If config was `None` this will be a new `dict`. If the ``votable``
   291	        supported version checks then version information will be stored in
   292	        the returned `dict`. If it was defined this will be the given
   293	        parameter unchanged.
   294	    """
   295	    if config is None:
   296	        if hasattr(votable, "_get_version_checks"):
   297	            config = votable._get_version_checks()
   298	        else:
   299	            config = {}
   300	    return config
   301	
   302	
   303	######################################################################
   304	# ATTRIBUTE CHECKERS
   305	def check_astroyear(year, field, config=None, pos=None):
   306	    """
   307	    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
   308	    *year* is not a valid astronomical year as defined by the VOTABLE
   309	    standard.
   310	
   311	    Parameters
   312	    ----------
   313	    year : str
   314	        An astronomical year string
   315	
   316	    field : str
   317	        The name of the field this year was found in (used for error
   318	        message)
   319	
   320	    config, pos : optional
```

## 原始行 206 · file_change

```
{
  "id": "item_138",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/converters.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/utils/xml/iterparser.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 209 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests/test_vo.py::test_parse_single_table2 astropy/io/votable/tests/test_vo.py::test_parse_single_table3 astropy/io/votable/tests/test_vo.py::test_fileobj astropy/io/votable/tests/test_vo.py::test_nonstandard_units astropy/io/votable/tests/test_vo.py::test_gzip_filehandles astropy/io/votable/tests/test_vo.py::test_validate --disable-warnings --maxfail=5'
```

退出码：`1`

输出：
```
Internet access disabled
....FF                                                                   [100%]
=================================== FAILURES ===================================
____________________________ test_gzip_filehandles _____________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-4/test_gzip_filehandles0')

    def test_gzip_filehandles(tmp_path):
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            votable = parse(get_pkg_data_filename("data/regression.xml"))
    
        # W39: Bit values can not be masked
        with pytest.warns(W39):
            with open(tmp_path / "regression.compressed.xml", "wb") as fd:
                votable.to_xml(fd, compressed=True, _astropy_version="testing")
    
        with open(tmp_path / "regression.compressed.xml", "rb") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_vo.py:1012: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <VOTABLE>... 0 tables ...</VOTABLE>
iterator = <astropy.utils.xml._iterparser.IterParser object at 0x726db35d8200>
config = {'_current_table_number': 0, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}

    def parse(self, iterator, config):
        config["_current_table_number"] = 0
    
>       for start, tag, data, pos in iterator:
E       ValueError: 1:0: not well-formed (invalid token)

astropy/io/votable/tree.py:4446: ValueError
________________________________ test_validate _________________________________

test_path_object = False

    def test_validate(test_path_object=False):
        """
        test_path_object is needed for test below ``test_validate_path_object``
        so that file could be passed as pathlib.Path object.
        """
        output = io.StringIO()
        fpath = get_pkg_data_filename("data/regression.xml")
        if test_path_object:
            fpath = pathlib.Path(fpath)
    
        # We can't test xmllint, because we can't rely on it being on the
        # user's machine.
>       result = validate(fpath, output, xmllint=False)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_vo.py:962: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:285: in validate
    votable = parse(content_buffer, verify="warn", filename=filename)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x726db31a7830>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
        with _convert_to_fd_or_read_function(source) as fd:
            if _debug_python_based_parser:
                context = _slow_iterparse(fd)
            else:
>               context = _fast_iterparse(fd)
                          ^^^^^^^^^^^^^^^^^^^
E               TypeError: Arg 1 to iterparser must be a file object or callable object

astropy/utils/xml/iterparser.py:175: TypeError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_vo.py::test_gzip_filehandles - ValueErro...
FAILED astropy/io/votable/tests/test_vo.py::test_validate - TypeError: Arg 1 ...
2 failed, 4 passed in 0.20s
```

## 原始行 212 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def get_readable_fileobj\" -A 240 astropy/utils/data.py | sed -n '1,240p'"
```

退出码：`0`

输出：
```
200:def get_readable_fileobj(
201-    name_or_obj,
202-    encoding=None,
203-    cache=False,
204-    show_progress=True,
205-    remote_timeout=None,
206-    sources=None,
207-    http_headers=None,
208-    *,
209-    use_fsspec=None,
210-    fsspec_kwargs=None,
211-    close_files=True,
212-):
213-    """Yield a readable, seekable file-like object from a file or URL.
214-
215-    This supports passing filenames, URLs, and readable file-like objects,
216-    any of which can be compressed in gzip, bzip2, lzma (xz) or lzw (Z) if the
217-    appropriate compression libraries are provided by the Python installation.
218-
219-    Notes
220-    -----
221-    This function is a context manager, and should be used for example
222-    as::
223-
224-        with get_readable_fileobj('file.dat') as f:
225-            contents = f.read()
226-
227-    If a URL is provided and the cache is in use, the provided URL will be the
228-    name used in the cache. The contents may already be stored in the cache
229-    under this URL provided, they may be downloaded from this URL, or they may
230-    be downloaded from one of the locations listed in ``sources``. See
231-    `~download_file` for details.
232-
233-    Parameters
234-    ----------
235-    name_or_obj : str or file-like
236-        The filename of the file to access (if given as a string), or
237-        the file-like object to access.
238-
239-        If a file-like object, it must be opened in binary mode.
240-
241-    encoding : str, optional
242-        When `None` (default), returns a file-like object with a
243-        ``read`` method that returns `str` (``unicode``) objects, using
244-        `locale.getpreferredencoding` as an encoding.  This matches
245-        the default behavior of the built-in `open` when no ``mode``
246-        argument is provided.
247-
248-        When ``'binary'``, returns a file-like object where its ``read``
249-        method returns `bytes` objects.
250-
251-        When another string, it is the name of an encoding, and the
252-        file-like object's ``read`` method will return `str` (``unicode``)
253-        objects, decoded from binary using the given encoding.
254-
255-    cache : bool or "update", optional
256-        Whether to cache the contents of remote URLs. If "update",
257-        check the remote URL for a new version but store the result
258-        in the cache.
259-
260-    show_progress : bool, optional
261-        Whether to display a progress bar if the file is downloaded
262-        from a remote server.  Default is `True`.
263-
264-    remote_timeout : float
265-        Timeout for remote requests in seconds (default is the configurable
266-        `astropy.utils.data.Conf.remote_timeout`).
267-
268-    sources : list of str, optional
269-        If provided, a list of URLs to try to obtain the file from. The
270-        result will be stored under the original URL. The original URL
271-        will *not* be tried unless it is in this list; this is to prevent
272-        long waits for a primary server that is known to be inaccessible
273-        at the moment.
274-
275-    http_headers : dict or None
276-        HTTP request headers to pass into ``urlopen`` if needed. (These headers
277-        are ignored if the protocol for the ``name_or_obj``/``sources`` entry
278-        is not a remote HTTP URL.) In the default case (None), the headers are
279-        ``User-Agent: some_value`` and ``Accept: */*``, where ``some_value``
280-        is set by ``astropy.utils.data.conf.default_http_user_agent``.
281-
282-    use_fsspec : bool, optional
283-        Use `fsspec.open` to open the file? Defaults to `False` unless
284-        ``name_or_obj`` starts with the Amazon S3 storage prefix ``s3://``
285-        or the Google Cloud Storage prefix ``gs://``.  Can also be used for paths
286-        with other prefixes (e.g. ``http://``) but in this case you must
287-        explicitly pass ``use_fsspec=True``.
288-        Use of this feature requires the optional ``fsspec`` package.
289-        A ``ModuleNotFoundError`` will be raised if the dependency is missing.
290-
291-        .. versionadded:: 5.2
292-
293-    fsspec_kwargs : dict, optional
294-        Keyword arguments passed on to `fsspec.open`. This can be used to
295-        configure cloud storage credentials and caching behavior.
296-        For example, pass ``fsspec_kwargs={"anon": True}`` to enable
297-        anonymous access to Amazon S3 open data buckets.
298-        See ``fsspec``'s documentation for available parameters.
299-
300-        .. versionadded:: 5.2
301-
302-    close_files : bool, optional
303-        Close the file object when exiting the context manager.
304-        Default is `True`.
305-
306-        .. versionadded:: 5.2
307-
308-    Returns
309-    -------
310-    file : :term:`file-like (readable)`
311-    """
312-    # close_fds is a list of file handles created by this function
313-    # that need to be closed.  We don't want to always just close the
314-    # returned file handle, because it may simply be the file handle
315-    # passed in.  In that case it is not the responsibility of this
316-    # function to close it: doing so could result in a "double close"
317-    # and an "invalid file descriptor" exception.
318-
319-    close_fds = []
320-    delete_fds = []
321-
322-    if remote_timeout is None:
323-        # use configfile default
324-        remote_timeout = conf.remote_timeout
325-
326-    # Have `use_fsspec` default to ``True`` if the user passed an Amazon S3
327-    # or Google Cloud Storage URI.
328-    if use_fsspec is None and _requires_fsspec(name_or_obj):
329-        use_fsspec = True
330-
331-    if use_fsspec:
332-        if not isinstance(name_or_obj, str):
333-            raise TypeError("`name_or_obj` must be a string when `use_fsspec=True`")
334-        if fsspec_kwargs is None:
335-            fsspec_kwargs = {}
336-
337-    # name_or_obj could be an os.PathLike object
338-    if isinstance(name_or_obj, os.PathLike):
339-        name_or_obj = os.fspath(name_or_obj)
340-
341-    # Get a file object to the content
342-    if isinstance(name_or_obj, str):
343-        # Use fsspec to open certain cloud-hosted files (e.g., AWS S3, Google Cloud Storage)
344-        if use_fsspec:
345-            if not HAS_FSSPEC:
346-                raise ModuleNotFoundError("please install `fsspec` to open this file")
347-            import fsspec  # local import because it is a niche dependency
348-
349-            openfileobj = fsspec.open(name_or_obj, **fsspec_kwargs)
350-            close_fds.append(openfileobj)
351-            fileobj = openfileobj.open()
352-            close_fds.append(fileobj)
353-        else:
354-            is_url = _is_url(name_or_obj)
355-            if is_url:
356-                name_or_obj = download_file(
357-                    name_or_obj,
358-                    cache=cache,
359-                    show_progress=show_progress,
360-                    timeout=remote_timeout,
361-                    sources=sources,
362-                    http_headers=http_headers,
363-                )
364-            fileobj = io.FileIO(name_or_obj, "r")
365-            if is_url and not cache:
366-                delete_fds.append(fileobj)
367-            close_fds.append(fileobj)
368-    else:
369-        fileobj = name_or_obj
370-
371-    # Check if the file object supports random access, and if not,
372-    # then wrap it in a BytesIO buffer.  It would be nicer to use a
373-    # BufferedReader to avoid reading loading the whole file first,
374-    # but that might not be compatible with all possible I/O classes.
375-    if not hasattr(fileobj, "seek"):
376-        try:
377-            # py.path.LocalPath objects have .read() method but it uses
378-            # text mode, which won't work. .read_binary() does, and
379-            # surely other ducks would return binary contents when
380-            # called like this.
381-            # py.path.LocalPath is what comes from the legacy tmpdir fixture
382-            # in pytest.
383-            fileobj = io.BytesIO(fileobj.read_binary())
384-        except AttributeError:
385-            fileobj = io.BytesIO(fileobj.read())
386-
387-    # Now read enough bytes to look at signature
388-    signature = fileobj.read(6)
389-    fileobj.seek(0)
390-
391-    if signature[:3] == b"\x1f\x8b\x08":  # gzip
392-        import struct
393-
394-        try:
395-            import gzip
396-
397-            fileobj_new = gzip.GzipFile(fileobj=fileobj, mode="rb")
398-            fileobj_new.read(1)  # need to check that the file is really gzip
399-        except (OSError, EOFError, struct.error):  # invalid gzip file
400-            fileobj.seek(0)
401-            fileobj_new.close()
402-        else:
403-            fileobj_new.seek(0)
404-            fileobj = fileobj_new
405-    elif signature[:3] == b"BZh":  # bzip2
406-        if not HAS_BZ2:
407-            for fd in close_fds:
408-                fd.close()
409-            raise ModuleNotFoundError(
410-                "This Python installation does not provide the bz2 module."
411-            )
412-        import bz2
413-
414-        try:
415-            # bz2.BZ2File does not support file objects, only filenames, so we
416-            # need to write the data to a temporary file
417-            with NamedTemporaryFile("wb", delete=False) as tmp:
418-                tmp.write(fileobj.read())
419-                tmp.close()
420-                fileobj_new = bz2.BZ2File(tmp.name, mode="rb")
421-            fileobj_new.read(1)  # need to check that the file is really bzip2
422-        except OSError:  # invalid bzip2 file
423-            fileobj.seek(0)
424-            fileobj_new.close()
425-            # raise
426-        else:
427-            fileobj_new.seek(0)
428-            close_fds.append(fileobj_new)
429-            fileobj = fileobj_new
430-    elif signature[:6] == b"\xfd7zXZ\x00":  # xz
431-        if not HAS_LZMA:
432-            for fd in close_fds:
433-                fd.close()
434-            raise ModuleNotFoundError(
435-                "This Python installation does not provide the lzma module."
436-            )
437-        import lzma
438-
439-        try:
```

## 原始行 215 · file_change

```
{
  "id": "item_144",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/iterparser.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 217 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests/test_vo.py::test_gzip_filehandles astropy/io/votable/tests/test_vo.py::test_validate astropy/io/votable/tests/test_vo.py::test_regression astropy/io/votable/tests/test_vo.py::test_regression_python_based_parser astropy/io/votable/tests/test_vo.py::test_regression_binary2 --disable-warnings --maxfail=5'
```

退出码：`1`

输出：
```
Internet access disabled
.F...                                                                    [100%]
=================================== FAILURES ===================================
________________________________ test_validate _________________________________

test_path_object = False

    def test_validate(test_path_object=False):
        """
        test_path_object is needed for test below ``test_validate_path_object``
        so that file could be passed as pathlib.Path object.
        """
        output = io.StringIO()
        fpath = get_pkg_data_filename("data/regression.xml")
        if test_path_object:
            fpath = pathlib.Path(fpath)
    
        # We can't test xmllint, because we can't rely on it being on the
        # user's machine.
        result = validate(fpath, output, xmllint=False)
    
        assert result is False
    
        output.seek(0)
        output = output.readlines()
    
        # Uncomment to generate new groundtruth
        # with open('validation.txt', 'wt', encoding='utf-8') as fd:
        #    fd.write(u''.join(output))
    
        with open(get_pkg_data_filename("data/validation.txt"), encoding="utf-8") as fd:
            truth = fd.readlines()
    
        truth = truth[1:]
        output = output[1:-1]
    
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       AssertionError: assert ['\n', '11: W...le of\n', ...] == ['\n', '11: W...le of\n', ...]
E         
E         At index 85 diff: '  4, got 1\n' != '  4, got 0\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:983: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -83,11 +83,7 @@
       ^
 
 136: E02: Incorrect number of elements in array. Expected multiple of
-  4, got 1
-  <TD/>
-  ^
-
-136: W49: Empty cell illegal for integer fields.
+  4, got 0
   <TD/>
   ^
 
@@ -149,6 +145,10 @@
   <TD/>
   ^
 
+171: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 171: W49: Empty cell illegal for integer fields. (suppressing further
   warnings of this type...)
   <TD/>
@@ -182,7 +182,7 @@
   ^
 
 227: E02: Incorrect number of elements in array. Expected multiple of
-  4, got 1
+  4, got 0
   <TD/>
   ^
 
@@ -210,12 +210,12 @@
   ^
 
 258: E02: Incorrect number of elements in array. Expected multiple of
-  4, got 1
+  4, got 0
   <TD/>
   ^
 
 260: E02: Incorrect number of elements in array. Expected multiple of
-  4, got 1 (suppressing further warnings of this type...)
+  4, got 0 (suppressing further warnings of this type...)
   <TD/>
   ^
 
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_vo.py::test_validate - AssertionError: a...
1 failed, 4 passed in 0.21s
```

## 原始行 220 · file_change

```
{
  "id": "item_147",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/converters.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 223 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests astropy/utils/tests/test_xml.py astropy/utils/xml/tests --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
...............................................ssss.........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

228: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

243: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

245: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

249: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

260: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

301: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

........... [ 22%]
..Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

...................................................................... [ 44%]
........................................................................ [ 66%]
........................................................................ [ 88%]
..........FValidation report for /testbed/astropy/io/votable/tests/data/empty_table.xml

astropy.io.votable found no violations.

xmllint passed
.F.....................s.                                     [100%]
=================================== FAILURES ===================================
________________________________ test_validate _________________________________

test_path_object = False

    def test_validate(test_path_object=False):
        """
        test_path_object is needed for test below ``test_validate_path_object``
        so that file could be passed as pathlib.Path object.
        """
        output = io.StringIO()
        fpath = get_pkg_data_filename("data/regression.xml")
        if test_path_object:
            fpath = pathlib.Path(fpath)
    
        # We can't test xmllint, because we can't rely on it being on the
        # user's machine.
        result = validate(fpath, output, xmllint=False)
    
        assert result is False
    
        output.seek(0)
        output = output.readlines()
    
        # Uncomment to generate new groundtruth
        # with open('validation.txt', 'wt', encoding='utf-8') as fd:
        #    fd.write(u''.join(output))
    
        with open(get_pkg_data_filename("data/validation.txt"), encoding="utf-8") as fd:
            truth = fd.readlines()
    
        truth = truth[1:]
        output = output[1:-1]
    
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       AssertionError: assert ['\n', '11: W...le of\n', ...] == ['\n', '11: W...le of\n', ...]
E         
E         At index 123 diff: '171: W49: Empty cell illegal for integer fields.\n' != '177: W46: unicodeChar value is too long for specified length of 10\n'
E         Left contains 9 more items, first extra item: '      ^\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:983: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -121,39 +121,6 @@
   <TD/>
   ^
 
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields. (suppressing further
-  warnings of this type...)
-  <TD/>
-  ^
-
 177: W46: unicodeChar value is too long for specified length of 10
   <TD>0123456789A</TD>
       ^
@@ -186,6 +153,10 @@
   <TD/>
   ^
 
+228: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 233: E02: Incorrect number of elements in array. Expected multiple of
   16, got 0
   <TD/>
@@ -200,10 +171,22 @@
   <TD>0x10000</TD> <!-- hex, overflow -->
       ^
 
+243: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
+245: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 248: W01: Array uses commas rather than whitespace
   <TD>31, -1</TD>
       ^
 
+249: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 250: E02: Incorrect number of elements in array. Expected multiple of
   6, got 0
   <TD/>
@@ -219,6 +202,10 @@
   <TD/>
   ^
 
+260: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 278: W46: char value is too long for specified length of 10
   <TD>Fixed string long test</TD> <!-- Should truncate -->
       ^
@@ -230,3 +217,7 @@
 281: W46: char value is too long for specified length of 4
   <TD>ab cd</TD>
       ^
+
+301: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
__________________________ test_validate_path_object ___________________________

    def test_validate_path_object():
        """Validating when source is passed as path object (#4412)."""
>       test_validate(test_path_object=True)

astropy/io/votable/tests/test_vo.py:998: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

test_path_object = True

    def test_validate(test_path_object=False):
        """
        test_path_object is needed for test below ``test_validate_path_object``
        so that file could be passed as pathlib.Path object.
        """
        output = io.StringIO()
        fpath = get_pkg_data_filename("data/regression.xml")
        if test_path_object:
            fpath = pathlib.Path(fpath)
    
        # We can't test xmllint, because we can't rely on it being on the
        # user's machine.
        result = validate(fpath, output, xmllint=False)
    
        assert result is False
    
        output.seek(0)
        output = output.readlines()
    
        # Uncomment to generate new groundtruth
        # with open('validation.txt', 'wt', encoding='utf-8') as fd:
        #    fd.write(u''.join(output))
    
        with open(get_pkg_data_filename("data/validation.txt"), encoding="utf-8") as fd:
            truth = fd.readlines()
    
        truth = truth[1:]
        output = output[1:-1]
    
        sys.stdout.writelines(
            difflib.unified_diff(truth, output, fromfile="truth", tofile="output")
        )
    
>       assert truth == output
E       AssertionError: assert ['\n', '11: W...le of\n', ...] == ['\n', '11: W...le of\n', ...]
E         
E         At index 123 diff: '171: W49: Empty cell illegal for integer fields.\n' != '177: W46: unicodeChar value is too long for specified length of 10\n'
E         Left contains 9 more items, first extra item: '      ^\n'
E         Use -v to get more diff

astropy/io/votable/tests/test_vo.py:983: AssertionError
----------------------------- Captured stdout call -----------------------------
--- truth
+++ output
@@ -121,39 +121,6 @@
   <TD/>
   ^
 
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields.
-  <TD/>
-  ^
-
-171: W49: Empty cell illegal for integer fields. (suppressing further
-  warnings of this type...)
-  <TD/>
-  ^
-
 177: W46: unicodeChar value is too long for specified length of 10
   <TD>0123456789A</TD>
       ^
@@ -186,6 +153,10 @@
   <TD/>
   ^
 
+228: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 233: E02: Incorrect number of elements in array. Expected multiple of
   16, got 0
   <TD/>
@@ -200,10 +171,22 @@
   <TD>0x10000</TD> <!-- hex, overflow -->
       ^
 
+243: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
+245: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 248: W01: Array uses commas rather than whitespace
   <TD>31, -1</TD>
       ^
 
+249: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 250: E02: Incorrect number of elements in array. Expected multiple of
   6, got 0
   <TD/>
@@ -219,6 +202,10 @@
   <TD/>
   ^
 
+260: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
+
 278: W46: char value is too long for specified length of 10
   <TD>Fixed string long test</TD> <!-- Should truncate -->
       ^
@@ -230,3 +217,7 @@
 281: W46: char value is too long for specified length of 4
   <TD>ab cd</TD>
       ^
+
+301: W49: Empty cell illegal for integer fields.
+  <TD/>
+  ^
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_vo.py::test_validate - AssertionError: a...
FAILED astropy/io/votable/tests/test_vo.py::test_validate_path_object - Asser...
2 failed, 317 passed, 5 skipped in 0.98s
```

## 原始行 226 · file_change

```
{
  "id": "item_151",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/converters.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 229 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import io, struct, warnings
import numpy as np
from astropy.io.votable import tree
from astropy.io.votable.converters import UnicodeChar, Float
from astropy.io.votable.exceptions import W46
from astropy.utils.xml.check import check_id, fix_id

assert check_id('_a-1.2') and not check_id('1a') and not check_id('a\\n')
assert fix_id('@#f') == '___f' and fix_id('123abc') == '_123abc'
v = tree.VOTableFile()
for arraysize, value, units in [('2', '😀', 2), ('*', 'A😀', 3), ('2*', 'A😀', 3)]:
    f = tree.Field(v, ID='u', name='u', datatype='unicodeChar', arraysize=arraysize)
    c = UnicodeChar(f)
    if arraysize == '2':
        assert c._binoutput_fixed(value, False) == value.encode('utf-16-be')
    else:
        out = c._binoutput_var(value, False)
        assert struct.unpack('>I', out[:4])[0] == units
        assert out[4:] == value.encode('utf-16-be')
f = tree.Field(v, ID='u2', name='u2', datatype='unicodeChar', arraysize='3')
c = UnicodeChar(f)
assert c._binoutput_fixed('A', False) == b'\\x00A\\x00\\x00\\x00\\x00'
assert c._binoutput_fixed('ignored', True) == b'\\x00' * 6
try:
    c._binoutput_fixed('four', False)
except struct.error:
    pass
else:
    raise AssertionError('fixed overflow did not raise struct.error')
f_float = tree.Field(v, ID='f', name='f', datatype='float')
assert Float(f_float).supports_empty_values({}) is True
r = tree.Resource()
assert r.links is r._links
print('direct edge checks passed')
PY
pytest -q astropy/io/votable/tests/test_vo.py::test_validate astropy/io/votable/tests/test_vo.py::test_validate_path_object astropy/io/votable/tests/test_table.py::test_table --disable-warnings"
```

退出码：`0`

输出：
```
direct edge checks passed
Internet access disabled
...                                                                      [100%]
3 passed in 0.12s
```

## 原始行 232 · command_execution

命令：
```
/bin/bash -lc "git diff --check && python -m compileall -q astropy/utils/xml/check.py astropy/utils/xml/iterparser.py astropy/io/votable/ucd.py astropy/io/votable/converters.py astropy/io/votable/tree.py astropy/io/votable/exceptions.py && git diff --stat && git status --short && git diff -- astropy/utils/xml/check.py astropy/io/votable/ucd.py astropy/io/votable/converters.py astropy/io/votable/tree.py | sed -n '1,1000p'"
```

退出码：`0`

输出：
```
 astropy/io/votable/converters.py |  52 +++++++++++++++++-
 astropy/io/votable/exceptions.py |  37 ++++++++++++-
 astropy/io/votable/tree.py       | 110 ++++++++++++++++++++++++++++++++++++++-
 astropy/io/votable/ucd.py        |  43 ++++++++++++++-
 astropy/utils/xml/check.py       |  25 ++++++++-
 astropy/utils/xml/iterparser.py  |  17 +++++-
 6 files changed, 278 insertions(+), 6 deletions(-)
 M astropy/io/votable/converters.py
 M astropy/io/votable/exceptions.py
 M astropy/io/votable/tree.py
 M astropy/io/votable/ucd.py
 M astropy/utils/xml/check.py
 M astropy/utils/xml/iterparser.py
diff --git a/astropy/io/votable/converters.py b/astropy/io/votable/converters.py
index c0bf064..c720636 100644
--- a/astropy/io/votable/converters.py
+++ b/astropy/io/votable/converters.py
@@ -72,6 +72,11 @@ else:
         return x
 
 
+def _make_masked_array(data, mask):
+    """Construct a masked array while retaining element masks."""
+    return ma.array(data, mask=mask)
+
+
 
 
 
@@ -180,6 +185,10 @@ class Converter:
     def _parse_length(read):
         return struct.unpack(">I", read(4))[0]
 
+    @staticmethod
+    def _write_length(length):
+        return struct.pack(">I", length)
+
 
 
 
@@ -487,6 +496,29 @@ class UnicodeChar(Converter):
             return s[:end], False
         return s, False
 
+    def _binoutput_var(self, value, mask):
+        if mask or value is None or value == "":
+            return _zero_int
+
+        if self.arraysize != "*" and len(value) > self.arraysize:
+            vo_warn(W46, ("unicodeChar", self.arraysize), None, None)
+
+        encoded = str(value).encode("utf_16_be")
+        return self._write_length(len(encoded) // 2) + encoded
+
+    def _binoutput_fixed(self, value, mask):
+        if mask:
+            encoded = _empty_bytes
+        else:
+            encoded = str(value).encode("utf_16_be")
+
+        size = self.arraysize * 2
+        if len(encoded) > size:
+            raise struct.error(
+                f"argument for '{size}s' must be a bytes object of length at most {size}"
+            )
+        return struct.pack(self._struct_format, encoded)
+
 
 
 
@@ -775,6 +807,9 @@ class FloatingPoint(Numeric):
         else:
             self.parse = self._parse_permissive
 
+    def supports_empty_values(self, config):
+        return True
+
 
 
 
@@ -1124,6 +1159,21 @@ class BitArray(NumericArray):
 
         self._bytes = ((self._items - 1) // 8) + 1
 
+    def parse(self, value, config=None, pos=None):
+        # Both the whitespace-separated representation commonly found in
+        # input files and the compact representation emitted by ``output``
+        # are legal for bit arrays.
+        if not value.strip():
+            if config is None:
+                config = {}
+            if config.get("version_1_3_or_later"):
+                return np.zeros(self._arraysize, dtype=self._base.format), True
+            warn_or_raise(E02, E02, (self._items, 0), config, pos)
+            return self.parse_parts([False] * self._items, config, pos)
+        if not any(char.isspace() for char in value):
+            value = " ".join(value)
+        return NumericArray.parse(self, value, config, pos)
+
 
 
 
@@ -1525,4 +1575,4 @@ def table_column_to_votable_datatype(column):
     if original_arraysize is not None:
         result["arraysize"] = original_arraysize
 
-    return result
\ No newline at end of file
+    return result
diff --git a/astropy/io/votable/tree.py b/astropy/io/votable/tree.py
index ca1d43f..2c98b3b 100644
--- a/astropy/io/votable/tree.py
+++ b/astropy/io/votable/tree.py
@@ -241,6 +241,16 @@ def _lookup_by_id_or_name_factory(iterator, element_name, doc):
     return lookup_by_id_or_name
 
 
+def _get_default_unit_format(config):
+    if config.get("version_1_4_or_later"):
+        return "vounit"
+    return "cds"
+
+
+def _get_unit_format(config):
+    return config.get("unit_format") or _get_default_unit_format(config)
+
+
 
 
 
@@ -316,6 +326,14 @@ def check_astroyear(year, field, config=None, pos=None):
     return True
 
 
+def check_string(string, attr_name, config=None, pos=None):
+    """Validate attributes whose VOTable representation must be a string."""
+    if string is not None and not isinstance(string, (str, bytes)):
+        warn_or_raise(W08, W08, attr_name, config, pos)
+        return False
+    return True
+
+
 
 
 
@@ -993,6 +1011,40 @@ class Values(Element, _IDProperty):
         self.to_xml(XMLWriter(buff))
         return buff.getvalue().strip()
 
+    def _parse_minmax(self, val):
+        if val is None:
+            return None
+
+        converter = getattr(self._field, "converter", None)
+        if converter is None:
+            return val
+
+        arraysize = getattr(self._field, "arraysize", None)
+        if arraysize is None:
+            return converter.parse(val, self._config, self._pos)[0]
+
+        # Array-valued fields in real-world files use both scalar constraints
+        # and full arrays (notably for interval xtypes).  A permissive scalar
+        # floating-point converter consumes an array as a bad scalar instead
+        # of raising, so select the array parser from the lexical form first.
+        if isinstance(converter, converters.Array) and len(
+            converters.array_splitter.split(val.strip())
+        ) > 1:
+            config = self._config.copy()
+            config["verify"] = "ignore"
+            return converter.parse(val, config, self._pos)[0]
+        return converter.parse_scalar(val, self._config, self._pos)[0]
+
+    def is_defaults(self):
+        return (
+            self.ref is None
+            and self.null is None
+            and self.ID is None
+            and self.max is None
+            and self.min is None
+            and len(self.options) == 0
+        )
+
     @property
     def null(self):
         """
@@ -1716,6 +1768,27 @@ class Field(
             for link in self.links:
                 link.to_xml(w, **kwargs)
 
+    def to_table_column(self, column):
+        """Copy this FIELD's metadata to an Astropy table column."""
+        for key in ("ucd", "width", "precision", "utype", "xtype"):
+            val = getattr(self, key, None)
+            if val is not None:
+                column.meta[key] = val
+
+        if self.datatype in ("char", "unicodeChar"):
+            column.meta["_votable_string_dtype"] = self.datatype
+            if self.arraysize is not None:
+                column.meta["_votable_arraysize"] = self.arraysize
+
+        if self.unit is not None:
+            column.unit = self.unit
+        if self.description is not None:
+            column.description = self.description
+
+        self.values.to_table_column(column)
+        for link in self.links:
+            link.to_table_column(column)
+
 
 
 
@@ -3494,6 +3567,29 @@ class TableElement(
                 w._flush()
                 w.write(base64.b64encode(data.getvalue()).decode("ascii"))
 
+    def to_table(self, use_names_over_ids=False):
+        """Convert this VOTable table element to an `astropy.table.Table`."""
+        from astropy.table import Table
+
+        fields = self.fields
+        if use_names_over_ids:
+            names = [field._unique_name for field in fields]
+        else:
+            names = [field.ID for field in fields]
+
+        meta = {}
+        for key in ("ID", "name", "ref", "ucd", "utype"):
+            val = getattr(self, key, None)
+            if val is not None:
+                meta[key] = val
+        if self.description is not None:
+            meta["description"] = self.description
+
+        table = Table(self.array, names=names, meta=meta)
+        for field, column in zip(fields, table.columns.values()):
+            field.to_table_column(column)
+        return table
+
 
 
 
@@ -3951,6 +4047,11 @@ class Resource(
         """
         return self._params
 
+    @property
+    def links(self):
+        """A homogeneous list of links belonging to this resource."""
+        return self._links
+
 
 
 
@@ -4495,6 +4596,13 @@ class VOTableFile(Element, _IDProperty, _DescriptionProperty):
         for resource in self.resources:
             yield from resource.iter_tables()
 
+    def get_first_table(self):
+        """Return the first table in the flattened resource tree."""
+        for table in self.iter_tables():
+            if not table._empty:
+                return table
+        raise IndexError("No table found in VOTABLE file.")
+
 
 
 
@@ -4703,4 +4811,4 @@ class VOTableFile(Element, _IDProperty, _DescriptionProperty):
             votable.ID = table_id
         resource.tables.append(votable)
         votable_file.resources.append(resource)
-        return votable_file
\ No newline at end of file
+        return votable_file
diff --git a/astropy/io/votable/ucd.py b/astropy/io/votable/ucd.py
index a5e55bf..8113f87 100644
--- a/astropy/io/votable/ucd.py
+++ b/astropy/io/votable/ucd.py
@@ -20,6 +20,47 @@ class UCDWords:
     file resides in data/ucd1p-words.txt.
     """
 
+    def __init__(self):
+        self._primary = set()
+        self._secondary = set()
+        self._descriptions = {}
+        self._capitalization = {}
+
+        contents = data.get_pkg_data_contents(
+            "data/ucd1p-words.txt", package="astropy.io.votable", encoding="utf-8"
+        )
+        for line in contents.splitlines():
+            line = line.strip()
+            if not line or line.startswith("#"):
+                continue
+
+            parts = line.split("|")
+            if len(parts) != 3:
+                raise ValueError(f"Invalid UCD vocabulary line: {line!r}")
+            word_type, name, description = (part.strip() for part in parts)
+            if len(word_type) != 1 or word_type not in "QPESVC":
+                raise ValueError(f"Invalid UCD word type {word_type!r}")
+
+            key = name.lower()
+            if word_type in "QPEVC":
+                self._primary.add(key)
+            if word_type in "QSEVC":
+                self._secondary.add(key)
+            self._descriptions[key] = description
+            self._capitalization[key] = name
+
+    def is_primary(self, name):
+        """Return whether *name* may be the primary word of a UCD."""
+        return name.lower() in self._primary
+
+    def is_secondary(self, name):
+        """Return whether *name* may be a secondary word of a UCD."""
+        return name.lower() in self._secondary
+
+    def normalize_capitalization(self, name):
+        """Return the spelling of *name* used by the controlled vocabulary."""
+        return self._capitalization[name.lower()]
+
 
 
 
@@ -193,4 +234,4 @@ def check_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
         )
     except ValueError:
         return False
-    return True
\ No newline at end of file
+    return True
diff --git a/astropy/utils/xml/check.py b/astropy/utils/xml/check.py
index 309bbfa..4938971 100644
--- a/astropy/utils/xml/check.py
+++ b/astropy/utils/xml/check.py
@@ -8,6 +8,24 @@ import re
 import urllib.parse
 
 
+_id_regex = re.compile(r"^[A-Za-z_][A-Za-z0-9_.-]*$")
+_id_char_regex = re.compile(r"[^A-Za-z0-9_.-]")
+
+
+def check_id(ID):
+    """Return whether *ID* is valid in the ASCII XML-ID subset used here."""
+    return _id_regex.fullmatch(ID) is not None
+
+
+def fix_id(ID):
+    """Convert an arbitrary string to the ASCII XML-ID subset used here."""
+    if ID == "":
+        return ID
+
+    prefix = "" if re.match(r"[A-Za-z_]", ID[0]) is not None else "_"
+    return prefix + _id_char_regex.sub("_", ID)
+
+
 
 
 
@@ -49,6 +67,11 @@ _token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"
 
 
 
+def check_token(token):
+    """Return whether *token* is in canonical XML Schema token form."""
+    return re.match(r"^(?![\r\n\t ])[^\r\n\t]*(?<![\r\n\t ])$", token) is not None
+
+
 def check_mime_content_type(content_type):
     """
     Returns `True` if *content_type* is a valid MIME content type
@@ -81,4 +104,4 @@ def check_anyuri(uri):
         urllib.parse.urlparse(uri)
     except Exception:
         return False
-    return True
\ No newline at end of file
+    return True
```

## 原始行 235 · command_execution

命令：
```
/bin/bash -lc 'pytest -q astropy/io/votable/tests astropy/utils/tests/test_xml.py astropy/utils/xml/tests --disable-warnings'
```

退出码：`0`

输出：
```
Internet access disabled
...............................................ssss.........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

........... [ 22%]
..Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

...................................................................... [ 44%]
........................................................................ [ 66%]
........................................................................ [ 88%]
...........Validation report for /testbed/astropy/io/votable/tests/data/empty_table.xml

astropy.io.votable found no violations.

xmllint passed
.......................s.                                     [100%]
319 passed, 5 skipped in 0.96s
```

## 原始行 238 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from pathlib import Path
for l in Path('astropy/utils/xml/check.py').read_text().splitlines():
 if l.startswith('_token_regex'): print(repr(l))
PY"
```

退出码：`0`

输出：
```
'_token_regex = r"(?![\\r\\l\\t ])[^\\r\\l\\t]*(?![\\r\\l\\t ])"'
```

## 原始行 241 · file_change

```
{
  "id": "item_161",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/check.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 243 · command_execution

命令：
```
/bin/bash -lc "sed -n '60,80p' astropy/utils/xml/check.py"
```

退出码：`0`

输出：
```










def check_token(token):
    """Return whether *token* is in canonical XML Schema token form."""
    return re.match(r"^(?![\r\n\t ])[^\r\n\t]*(?<![\r\n\t ])$", token) is not None


def check_mime_content_type(content_type):
    """
    Returns `True` if *content_type* is a valid MIME content type
    (syntactically at least), as defined by RFC 2045.
    """
    ctrls = "".join(chr(x) for x in range(0x20))
```

## 原始行 246 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from pathlib import Path
for l in Path('astropy/utils/xml/check.py').read_text().splitlines():
 if 'return re.match(r\""'^'"' in l: print(repr(l))
PY"
```

退出码：`0`

输出：
```
'    return re.match(r"^(?![\\r\\n\\t ])[^\\r\\n\\t]*(?<![\\r\\n\\t ])$", token) is not None'
```

## 原始行 248 · file_change

```
{
  "id": "item_165",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/check.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 251 · command_execution

命令：
```
/bin/bash -lc 'ruff check astropy/utils/xml/check.py astropy/utils/xml/iterparser.py astropy/io/votable/ucd.py astropy/io/votable/converters.py astropy/io/votable/tree.py astropy/io/votable/exceptions.py'
```

退出码：`127`

输出：
```
/bin/bash: line 1: ruff: command not found
```

## 原始行 253 · agent_message

```
All focused and broader VOTable tests are green. The UTF-16 edge checks also confirm astral characters use two code units, fixed fields pad exactly, masked fixed fields zero-fill, and overflow raises `struct.error` instead of truncating. I’m doing the final workspace sanity check now.
```

## 原始行 255 · command_execution

命令：
```
/bin/bash -lc 'git diff --check && pytest -q astropy/utils/tests/test_xml.py astropy/io/votable/tests/test_ucd.py astropy/io/votable/tests/test_exception.py astropy/io/votable/tests/test_tree.py --disable-warnings && git status --short'
```

退出码：`0`

输出：
```
Internet access disabled
.........s......................................                         [100%]
47 passed, 1 skipped in 0.13s
 M astropy/io/votable/converters.py
 M astropy/io/votable/exceptions.py
 M astropy/io/votable/tree.py
 M astropy/io/votable/ucd.py
 M astropy/utils/xml/check.py
 M astropy/utils/xml/iterparser.py
```

## 原始行 257 · agent_message

```
Implemented the requested VOTable interfaces, including:

- XML ID validation and repair
- UCD vocabulary loading and normalization
- VOTable lookup, metadata, `VALUES`, and resource properties
- String validation and empty-value support
- Correct UTF-16-BE fixed/variable `unicodeChar` serialization
- Required warning, parser, masking, and binary-length helpers

Validation:

- Broader VOTable suite: **319 passed, 5 skipped**
- Final focused suite: **47 passed, 1 skipped**
- `git diff --check` passes.
```
