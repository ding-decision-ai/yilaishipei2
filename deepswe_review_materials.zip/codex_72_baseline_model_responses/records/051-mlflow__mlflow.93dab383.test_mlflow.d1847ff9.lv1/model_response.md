# Codex baseline: mlflow__mlflow.93dab383.test_mlflow.d1847ff9.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the four target modules, their surrounding helpers, and the visible tests, then implement the smallest compatible changes and run focused tests before broader validation.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "pwd && rg -n \"class EndpointType|class Limit\\b|def get_deploy_client|class Endpoint\\b|def http_request\\b\" mlflow tests --glob '*.py'"
```

退出码：`127`

输出：
```
/testbed
/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
`rg` is unavailable in this image, so I’m using scoped `grep`/`find` searches within `/testbed` only.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"class EndpointType|class Limit\\b|def get_deploy_client|class Endpoint\\b|def http_request\\b\" mlflow tests --include='*.py'"
```

退出码：`0`

输出：
```
tests/sagemaker/mock/__init__.py:682:class Endpoint(TimestampedResource):
tests/store/artifact/test_mlflow_artifact_repo.py:296:    def http_request(_host_creds, endpoint, _method, **kwargs):
tests/store/artifact/test_http_artifact_repo.py:309:    def http_request(_host_creds, endpoint, _method, **kwargs):
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "find mlflow/gateway mlflow/deployments mlflow/utils -maxdepth 3 -type f | sort | sed -n '1,240p'
find tests -type f \\( -iname '*gateway*' -o -iname '*deployment*' -o -iname '*rest_utils*' \\) | sort"
```

退出码：`0`

输出：
```
mlflow/deployments/__init__.py
mlflow/deployments/base.py
mlflow/deployments/cli.py
mlflow/deployments/constants.py
mlflow/deployments/databricks/__init__.py
mlflow/deployments/interface.py
mlflow/deployments/mlflow/__init__.py
mlflow/deployments/openai/__init__.py
mlflow/deployments/plugin_manager.py
mlflow/deployments/server/__init__.py
mlflow/deployments/server/config.py
mlflow/deployments/server/constants.py
mlflow/deployments/utils.py
mlflow/gateway/__init__.py
mlflow/gateway/app.py
mlflow/gateway/base_models.py
mlflow/gateway/cli.py
mlflow/gateway/config.py
mlflow/gateway/constants.py
mlflow/gateway/exceptions.py
mlflow/gateway/provider_registry.py
mlflow/gateway/providers/__init__.py
mlflow/gateway/providers/ai21labs.py
mlflow/gateway/providers/anthropic.py
mlflow/gateway/providers/base.py
mlflow/gateway/providers/bedrock.py
mlflow/gateway/providers/cohere.py
mlflow/gateway/providers/gemini.py
mlflow/gateway/providers/huggingface.py
mlflow/gateway/providers/mistral.py
mlflow/gateway/providers/mlflow.py
mlflow/gateway/providers/mosaicml.py
mlflow/gateway/providers/openai.py
mlflow/gateway/providers/palm.py
mlflow/gateway/providers/togetherai.py
mlflow/gateway/providers/utils.py
mlflow/gateway/runner.py
mlflow/gateway/schemas/__init__.py
mlflow/gateway/schemas/chat.py
mlflow/gateway/schemas/completions.py
mlflow/gateway/schemas/embeddings.py
mlflow/gateway/uc_function_utils.py
mlflow/gateway/utils.py
mlflow/utils/__init__.py
mlflow/utils/_capture_modules.py
mlflow/utils/_capture_transformers_modules.py
mlflow/utils/_spark_utils.py
mlflow/utils/_unity_catalog_oss_utils.py
mlflow/utils/_unity_catalog_utils.py
mlflow/utils/annotations.py
mlflow/utils/arguments_utils.py
mlflow/utils/async_logging/__init__.py
mlflow/utils/async_logging/async_artifacts_logging_queue.py
mlflow/utils/async_logging/async_logging_queue.py
mlflow/utils/async_logging/run_artifact.py
mlflow/utils/async_logging/run_batch.py
mlflow/utils/async_logging/run_operations.py
mlflow/utils/autologging_utils/__init__.py
mlflow/utils/autologging_utils/client.py
mlflow/utils/autologging_utils/config.py
mlflow/utils/autologging_utils/events.py
mlflow/utils/autologging_utils/logging_and_warnings.py
mlflow/utils/autologging_utils/metrics_queue.py
mlflow/utils/autologging_utils/safety.py
mlflow/utils/autologging_utils/versioning.py
mlflow/utils/checkpoint_utils.py
mlflow/utils/class_utils.py
mlflow/utils/cli_args.py
mlflow/utils/conda.py
mlflow/utils/credentials.py
mlflow/utils/data_utils.py
mlflow/utils/databricks_tracing_utils.py
mlflow/utils/databricks_utils.py
mlflow/utils/docstring_utils.py
mlflow/utils/doctor.py
mlflow/utils/download_cloud_file_chunk.py
mlflow/utils/env_manager.py
mlflow/utils/env_pack.py
mlflow/utils/environment.py
mlflow/utils/exception_utils.py
mlflow/utils/file_utils.py
mlflow/utils/git_utils.py
mlflow/utils/gorilla.py
mlflow/utils/import_hooks/__init__.py
mlflow/utils/jsonpath_utils.py
mlflow/utils/lazy_load.py
mlflow/utils/logging_utils.py
mlflow/utils/mime_type_utils.py
mlflow/utils/mlflow_tags.py
mlflow/utils/model_utils.py
mlflow/utils/name_utils.py
mlflow/utils/nfs_on_spark.py
mlflow/utils/openai_utils.py
mlflow/utils/os.py
mlflow/utils/oss_registry_utils.py
mlflow/utils/plugins.py
mlflow/utils/process.py
mlflow/utils/promptlab_utils.py
mlflow/utils/proto_json_utils.py
mlflow/utils/request_utils.py
mlflow/utils/requirements_utils.py
mlflow/utils/rest_utils.py
mlflow/utils/search_logged_model_utils.py
mlflow/utils/search_utils.py
mlflow/utils/server_cli_utils.py
mlflow/utils/spark_utils.py
mlflow/utils/string_utils.py
mlflow/utils/thread_utils.py
mlflow/utils/time.py
mlflow/utils/timeout.py
mlflow/utils/uri.py
mlflow/utils/validation.py
mlflow/utils/virtualenv.py
mlflow/utils/warnings_utils.py
mlflow/utils/yaml_utils.py
tests/deployments/test_deployments.py
tests/gateway/test_gateway_app.py
tests/gateway/test_gateway_config_parsing.py
tests/resources/mlflow-test-plugin/mlflow_test_plugin/fake_deployment_plugin.py
tests/sagemaker/test_batch_deployment.py
tests/sagemaker/test_sagemaker_deployment_client.py
tests/utils/test_rest_utils.py
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,400p' mlflow/utils/rest_utils.py"
```

退出码：`0`

输出：
```
import base64
import json
import logging
import random
import time
import warnings
from functools import lru_cache
from typing import Any, Callable

import requests

from mlflow.environment_variables import (
    _MLFLOW_DATABRICKS_TRAFFIC_ID,
    _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT,
    _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT,
    MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT,
    MLFLOW_ENABLE_DB_SDK,
    MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR,
    MLFLOW_HTTP_REQUEST_BACKOFF_JITTER,
    MLFLOW_HTTP_REQUEST_MAX_RETRIES,
    MLFLOW_HTTP_REQUEST_TIMEOUT,
    MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER,
)
from mlflow.exceptions import (
    CUSTOMER_UNAUTHORIZED,
    ERROR_CODE_TO_HTTP_STATUS,
    INVALID_PARAMETER_VALUE,
    InvalidUrlException,
    MlflowException,
    RestException,
    get_error_code,
)
from mlflow.protos import databricks_pb2
from mlflow.protos.databricks_pb2 import ENDPOINT_NOT_FOUND, ErrorCode
from mlflow.utils.proto_json_utils import parse_dict
from mlflow.utils.request_utils import _TRANSIENT_FAILURE_RESPONSE_CODES, augmented_raise_for_status, cloud_storage_http_request







_logger = logging.getLogger(__name__)

RESOURCE_NON_EXISTENT = "RESOURCE_DOES_NOT_EXIST"
_REST_API_PATH_PREFIX = "/api/2.0"
_UC_OSS_REST_API_PATH_PREFIX = "/api/2.1"
_TRACE_REST_API_PATH_PREFIX = f"{_REST_API_PATH_PREFIX}/mlflow/traces"
_V3_REST_API_PATH_PREFIX = "/api/3.0"
_V3_TRACE_REST_API_PATH_PREFIX = f"{_V3_REST_API_PATH_PREFIX}/mlflow/traces"
_V4_REST_API_PATH_PREFIX = "/api/4.0"
_V4_TRACE_REST_API_PATH_PREFIX = f"{_V4_REST_API_PATH_PREFIX}/mlflow/traces"
_ARMERIA_OK = "200 OK"
_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING = (
    "The 'retry_after_secs' parameter of DatabricksError is deprecated"
)












































































































































































































@lru_cache(maxsize=5)
def get_workspace_client(
    use_secret_scope_token,
    host,
    token,
    databricks_auth_profile,
    retry_timeout_seconds=None,
    timeout=None,
):
    from databricks.sdk import WorkspaceClient
    from databricks.sdk.config import Config

    if use_secret_scope_token:
        kwargs = {"host": host, "token": token}
    else:
        kwargs = {"profile": databricks_auth_profile}
    if timeout is not None:
        kwargs["http_timeout_seconds"] = timeout
    config = Config(
        **kwargs,
        retry_timeout_seconds=retry_timeout_seconds
        or MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get(),
    )
    # Note: If we use `config` param, all SDK configurations must be set in `config` object.
    return WorkspaceClient(config=config)


def _can_parse_as_json_object(string):
    try:
        return isinstance(json.loads(string), dict)
    except Exception:
        return False


def http_request_safe(host_creds, endpoint, method, **kwargs):
    """
    Wrapper around ``http_request`` that also verifies that the request succeeds with code 200.
    """
    response = http_request(host_creds=host_creds, endpoint=endpoint, method=method, **kwargs)
    return verify_rest_response(response, endpoint)


def verify_rest_response(response, endpoint):
    """Verify the return code and format, raise exception if the request was not successful."""
    # Handle Armeria-specific response case where response text is "200 OK"
    # v1/traces endpoint might return empty response
    if response.status_code == 200 and response.text.strip() in (_ARMERIA_OK, ""):
        response._content = b"{}"  # Update response content to be an empty JSON dictionary
        return response

    # Handle non-200 status codes
    if response.status_code != 200:
        if _can_parse_as_json_object(response.text):
            raise RestException(json.loads(response.text))
        else:
            base_msg = (
                f"API request to endpoint {endpoint} "
                f"failed with error code {response.status_code} != 200"
            )
            raise MlflowException(
                f"{base_msg}. Response body: '{response.text}'",
                error_code=get_error_code(response.status_code),
            )

    # Skip validation for endpoints (e.g. DBFS file-download API) which may return a non-JSON
    # response
    if endpoint.startswith(_REST_API_PATH_PREFIX) and not _can_parse_as_json_object(response.text):
        base_msg = (
            "API request to endpoint was successful but the response body was not "
            "in a valid JSON format"
        )
        raise MlflowException(f"{base_msg}. Response body: '{response.text}'")

    return response



















































def validate_deployment_timeout_config(timeout: int | None, retry_timeout_seconds: int | None):
    """
    Validate that total retry timeout is not less than single request timeout.

    Args:
        timeout: Maximum time for a single HTTP request (in seconds)
        retry_timeout_seconds: Maximum time for all retry attempts combined (in seconds)
    """
    if timeout is not None and retry_timeout_seconds is not None:
        if retry_timeout_seconds < timeout:
            warnings.warn(
                f"MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT ({retry_timeout_seconds}s) is set "
                f"lower than MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT ({timeout}s). This means the "
                "total retry timeout could expire before a single request completes, causing "
```

## 原始行 17 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,340p' tests/deployments/test_deployments.py
sed -n '1,380p' tests/utils/test_rest_utils.py"
```

退出码：`0`

输出：
```
from unittest import mock

import pytest

from mlflow import deployments
from mlflow.deployments.plugin_manager import DeploymentPlugins
from mlflow.exceptions import MlflowException

f_model_uri = "fake_model_uri"
f_endpoint_name = "fake_endpoint_name"
f_deployment_id = "fake_deployment_name"
f_flavor = "fake_flavor"
f_target = "faketarget"


def test_create_success():
    client = deployments.get_deploy_client(f_target)
    ret = client.create_deployment(f_deployment_id, f_model_uri, f_flavor, config={})
    assert isinstance(ret, dict)
    assert ret["name"] == f_deployment_id
    assert ret["flavor"] == f_flavor

    ret2 = client.create_deployment(f_deployment_id, f_model_uri)
    assert ret2["flavor"] is None


def test_delete_success():
    client = deployments.get_deploy_client(f_target)
    assert client.delete_deployment(f_deployment_id) is None


def test_update_success():
    client = deployments.get_deploy_client(f_target)
    res = client.update_deployment(f_deployment_id, f_model_uri, f_flavor)
    assert res["flavor"] == f_flavor


def test_list_success():
    client = deployments.get_deploy_client(f_target)
    ret = client.list_deployments()
    assert ret[0]["name"] == f_deployment_id


def test_get_success():
    client = deployments.get_deploy_client(f_target)
    ret = client.get_deployment(f_deployment_id)
    assert ret["key1"] == "val1"


def test_endpoint_create_success():
    client = deployments.get_deploy_client(f_target)
    endpoint = client.create_endpoint(f_endpoint_name)
    assert isinstance(endpoint, dict)
    assert endpoint["name"] == f_endpoint_name


def test_endpoint_delete_success():
    client = deployments.get_deploy_client(f_target)
    assert client.delete_endpoint(f_endpoint_name) is None


def test_endpoint_update_success():
    client = deployments.get_deploy_client(f_target)
    assert client.update_endpoint(f_endpoint_name) is None


def test_endpoint_list_success():
    client = deployments.get_deploy_client(f_target)
    endpoints = client.list_endpoints()
    assert endpoints[0]["name"] == f_endpoint_name


def test_endpoint_get_success():
    client = deployments.get_deploy_client(f_target)
    endpoint = client.get_endpoint(f_endpoint_name)
    assert endpoint["name"] == f_endpoint_name


def test_wrong_target_name():
    with pytest.raises(
        MlflowException, match='No plugin found for managing model deployments to "wrong_target"'
    ):
        deployments.get_deploy_client("wrong_target")


def test_plugin_doesnot_have_required_attrib():
    class DummyPlugin:
        pass

    dummy_plugin = DummyPlugin()
    plugin_manager = DeploymentPlugins()
    plugin_manager.registry["dummy"] = dummy_plugin
    with pytest.raises(MlflowException, match="Plugin registered for the target dummy"):
        plugin_manager["dummy"]


def test_plugin_raising_error(monkeypatch):
    client = deployments.get_deploy_client(f_target)
    # special case to raise error
    monkeypatch.setenv("raiseError", "True")
    with pytest.raises(RuntimeError, match="Error requested"):
        client.list_deployments()


def test_target_uri_parsing():
    deployments.get_deploy_client(f_target)
    deployments.get_deploy_client(f"{f_target}:/somesuffix")
    deployments.get_deploy_client(f"{f_target}://somesuffix")


def test_explain_with_no_target_implementation():
    from mlflow_test_plugin import fake_deployment_plugin

    mock_error = MlflowException("MOCK ERROR")
    target_client = deployments.get_deploy_client(f_target)
    plugin = fake_deployment_plugin.PluginDeploymentClient
    with mock.patch.object(plugin, "explain", return_value=mock_error) as mock_explain:
        res = target_client.explain(f_target, "test")
        assert type(res) == MlflowException
        mock_explain.assert_called_once()


def test_explain_with_target_implementation():
    target_client = deployments.get_deploy_client(f_target)
    res = target_client.explain(f_target, "test")
    assert res == "1"
import re
import time
import warnings
from unittest import mock

import numpy
import pytest
import requests

from mlflow.deployments.databricks import DatabricksDeploymentClient
from mlflow.environment_variables import (
    _MLFLOW_DATABRICKS_TRAFFIC_ID,
    MLFLOW_HTTP_REQUEST_TIMEOUT,
)
from mlflow.exceptions import InvalidUrlException, MlflowException, RestException
from mlflow.protos.databricks_pb2 import ENDPOINT_NOT_FOUND, ErrorCode
from mlflow.protos.service_pb2 import GetRun
from mlflow.pyfunc.scoring_server import NumpyEncoder
from mlflow.tracking.request_header.default_request_header_provider import (
    _CLIENT_VERSION,
    _USER_AGENT,
    DefaultRequestHeaderProvider,
)
from mlflow.utils.rest_utils import (
    _DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING,
    MlflowHostCreds,
    _can_parse_as_json_object,
    augmented_raise_for_status,
    call_endpoint,
    call_endpoints,
    get_workspace_client,
    http_request,
    http_request_safe,
)

from tests import helper_functions


@pytest.mark.parametrize(
    "response_mock",
    [
        helper_functions.create_mock_response(400, "Error message but not a JSON string"),
        helper_functions.create_mock_response(400, ""),
        helper_functions.create_mock_response(400, None),
    ],
)
def test_malformed_json_error_response(response_mock):
    with mock.patch("requests.Session.request", return_value=response_mock):
        host_only = MlflowHostCreds("http://my-host")

        response_proto = GetRun.Response()
        with pytest.raises(
            MlflowException, match="API request to endpoint /my/endpoint failed with error code 400"
        ):
            call_endpoint(host_only, "/my/endpoint", "GET", None, response_proto)


def test_call_endpoints():
    with mock.patch("mlflow.utils.rest_utils.call_endpoint") as mock_call_endpoint:
        response_proto = GetRun.Response()
        mock_call_endpoint.side_effect = [
            RestException({"error_code": ErrorCode.Name(ENDPOINT_NOT_FOUND)}),
            None,
        ]
        host_only = MlflowHostCreds("http://my-host")
        endpoints = [("/my/endpoint", "POST"), ("/my/endpoint", "GET")]
        resp = call_endpoints(host_only, endpoints, "", response_proto)
        mock_call_endpoint.assert_has_calls(
            [
                mock.call(host_only, endpoint, method, "", response_proto, None)
                for endpoint, method in endpoints
            ]
        )
        assert resp is None


def test_call_endpoints_raises_exceptions():
    with mock.patch("mlflow.utils.rest_utils.call_endpoint") as mock_call_endpoint:
        response_proto = GetRun.Response()
        mock_call_endpoint.side_effect = [
            RestException({"error_code": ErrorCode.Name(ENDPOINT_NOT_FOUND)}),
            RestException({"error_code": ErrorCode.Name(ENDPOINT_NOT_FOUND)}),
        ]
        host_only = MlflowHostCreds("http://my-host")
        endpoints = [("/my/endpoint", "POST"), ("/my/endpoint", "GET")]
        with pytest.raises(RestException, match="ENDPOINT_NOT_FOUND"):
            call_endpoints(host_only, endpoints, "", response_proto)
        mock_call_endpoint.side_effect = [RestException({}), None]
        with pytest.raises(RestException, match="INTERNAL_ERROR"):
            call_endpoints(host_only, endpoints, "", response_proto)


def test_http_request_hostonly():
    host_only = MlflowHostCreds("http://my-host")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_cleans_hostname():
    # Add a trailing slash, should be removed.
    host_only = MlflowHostCreds("http://my-host/")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_with_basic_auth():
    host_only = MlflowHostCreds("http://my-host", username="user", password="pass")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        headers = DefaultRequestHeaderProvider().request_headers()
        headers["Authorization"] = "Basic dXNlcjpwYXNz"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=headers,
            timeout=120,
        )


def test_http_request_with_aws_sigv4(monkeypatch):
    """This test requires the "requests_auth_aws_sigv4" package to be installed"""

    from requests_auth_aws_sigv4 import AWSSigV4

    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "access-key")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret-key")
    monkeypatch.setenv("AWS_DEFAULT_REGION", "eu-west-1")
    aws_sigv4 = MlflowHostCreds("http://my-host", aws_sigv4=True)
    response = mock.MagicMock()
    response.status_code = 200

    class AuthMatcher:
        def __eq__(self, other):
            return isinstance(other, AWSSigV4)

    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(aws_sigv4, "/my/endpoint", "GET")
        mock_request.assert_called_once_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=mock.ANY,
            headers=mock.ANY,
            timeout=mock.ANY,
            auth=AuthMatcher(),
        )


def test_http_request_with_auth():
    mock_fetch_auth = {"test_name": "test_auth_value"}
    auth = "test_auth_name"
    host_only = MlflowHostCreds("http://my-host", auth=auth)
    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch(
            "mlflow.tracking.request_auth.registry.fetch_auth", return_value=mock_fetch_auth
        ) as mock_fetch_auth_call,
    ):
        http_request(host_only, "/my/endpoint", "GET")

        mock_fetch_auth_call.assert_called_with(auth)

        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=mock.ANY,
            headers=mock.ANY,
            timeout=mock.ANY,
            auth=mock_fetch_auth,
        )


def test_http_request_with_token():
    host_only = MlflowHostCreds("http://my-host", token="my-token")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        headers = DefaultRequestHeaderProvider().request_headers()
        headers["Authorization"] = "Bearer my-token"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=headers,
            timeout=120,
        )


def test_http_request_with_insecure():
    host_only = MlflowHostCreds("http://my-host", ignore_tls_verification=True)
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=False,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_client_cert_path():
    host_only = MlflowHostCreds("http://my-host", client_cert_path="/some/path")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            cert="/some/path",
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_server_cert_path():
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_with_content_type_header():
    host_only = MlflowHostCreds("http://my-host", token="my-token")
    response = mock.MagicMock()
    response.status_code = 200
    extra_headers = {"Content-Type": "text/plain"}
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET", extra_headers=extra_headers)
        headers = DefaultRequestHeaderProvider().request_headers()
        headers["Authorization"] = "Bearer my-token"
        headers["Content-Type"] = "text/plain"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=headers,
            timeout=120,
        )


def test_http_request_request_headers():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
    ):
        host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers={**DefaultRequestHeaderProvider().request_headers(), "test": "header"},
            timeout=120,
        )


def test_http_request_request_headers_default():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    default_headers = DefaultRequestHeaderProvider().request_headers()
    expected_headers = {
        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
    }

    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
        mock.patch.object(
            PluginRequestHeaderProvider,
            "request_headers",
            return_value={_USER_AGENT: "test_user_agent", _CLIENT_VERSION: "test_client_version"},
        ),
    ):
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers=expected_headers,
            timeout=120,
        )


def test_http_request_request_headers_default_and_extra_header():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    default_headers = DefaultRequestHeaderProvider().request_headers()
    expected_headers = {
        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
        "header": "value",
    }

    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
        mock.patch.object(
            PluginRequestHeaderProvider,
            "request_headers",
            return_value={
                _USER_AGENT: "test_user_agent",
                _CLIENT_VERSION: "test_client_version",
                "header": "value",
            },
        ),
    ):
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' mlflow/gateway/config.py
sed -n '1,240p' mlflow/deployments/interface.py
sed -n '1,240p' mlflow/deployments/server/config.py"
```

退出码：`0`

输出：
```
import json
import logging
import os
import pathlib
from enum import Enum
from pathlib import Path
from typing import TYPE_CHECKING, Any, Literal

import pydantic
import yaml
from pydantic import ConfigDict, ValidationError, field_validator, model_validator
from pydantic.json import pydantic_encoder

from mlflow.exceptions import MlflowException
from mlflow.gateway.base_models import ConfigModel, LimitModel, ResponseModel
from mlflow.gateway.constants import (
    MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES,
    MLFLOW_GATEWAY_ROUTE_BASE,
    MLFLOW_QUERY_SUFFIX,
)
from mlflow.gateway.utils import (
    check_configuration_deprecated_fields,
    check_configuration_route_name_collisions,
    is_valid_ai21labs_model,
    is_valid_endpoint_name,
    is_valid_mosiacml_chat_model,
)

_logger = logging.getLogger(__name__)

from pydantic import SerializeAsAny

if TYPE_CHECKING:
    from mlflow.deployments.server.config import Endpoint


class Provider(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    COHERE = "cohere"
    AI21LABS = "ai21labs"
    MLFLOW_MODEL_SERVING = "mlflow-model-serving"
    MOSAICML = "mosaicml"
    HUGGINGFACE_TEXT_GENERATION_INFERENCE = "huggingface-text-generation-inference"
    PALM = "palm"
    GEMINI = "gemini"
    BEDROCK = "bedrock"
    AMAZON_BEDROCK = "amazon-bedrock"  # an alias for bedrock
    # Note: The following providers are only supported on Databricks
    DATABRICKS_MODEL_SERVING = "databricks-model-serving"
    DATABRICKS = "databricks"
    MISTRAL = "mistral"
    TOGETHERAI = "togetherai"

    @classmethod
    def values(cls):
        return {p.value for p in cls}


class TogetherAIConfig(ConfigModel):
    togetherai_api_key: str

    @field_validator("togetherai_api_key", mode="before")
    def validate_togetherai_api_key(cls, value):
        return _resolve_api_key_from_input(value)








class CohereConfig(ConfigModel):
    cohere_api_key: str

    @field_validator("cohere_api_key", mode="before")
    def validate_cohere_api_key(cls, value):
        return _resolve_api_key_from_input(value)


class AI21LabsConfig(ConfigModel):
    ai21labs_api_key: str

    @field_validator("ai21labs_api_key", mode="before")
    def validate_ai21labs_api_key(cls, value):
        return _resolve_api_key_from_input(value)


class MosaicMLConfig(ConfigModel):
    mosaicml_api_key: str
    mosaicml_api_base: str | None = None

    @field_validator("mosaicml_api_key", mode="before")
    def validate_mosaicml_api_key(cls, value):
        return _resolve_api_key_from_input(value)


class OpenAIAPIType(str, Enum):
    OPENAI = "openai"
    AZURE = "azure"
    AZUREAD = "azuread"

    @classmethod
    def _missing_(cls, value):
        """
        Implements case-insensitive matching of API type strings
        """
        for api_type in cls:
            if api_type.value == value.lower():
                return api_type

        raise MlflowException.invalid_parameter_value(f"Invalid OpenAI API type '{value}'")


class OpenAIConfig(ConfigModel):
    openai_api_key: str
    openai_api_type: OpenAIAPIType = OpenAIAPIType.OPENAI
    openai_api_base: str | None = None
    openai_api_version: str | None = None
    openai_deployment_name: str | None = None
    openai_organization: str | None = None

    @field_validator("openai_api_key", mode="before")
    def validate_openai_api_key(cls, value):
        return _resolve_api_key_from_input(value)

    @classmethod
    def _validate_field_compatibility(cls, info: dict[str, Any]):
        if not isinstance(info, dict):
            return info
        api_type = (info.get("openai_api_type") or OpenAIAPIType.OPENAI).lower()
        if api_type == OpenAIAPIType.OPENAI:
            if info.get("openai_deployment_name") is not None:
                raise MlflowException.invalid_parameter_value(
                    f"OpenAI route configuration can only specify a value for "
                    f"'openai_deployment_name' if 'openai_api_type' is '{OpenAIAPIType.AZURE}' "
                    f"or '{OpenAIAPIType.AZUREAD}'. Found type: '{api_type}'"
                )
            if info.get("openai_api_base") is None:
                info["openai_api_base"] = "https://api.openai.com/v1"
        elif api_type in (OpenAIAPIType.AZURE, OpenAIAPIType.AZUREAD):
            if info.get("openai_organization") is not None:
                raise MlflowException.invalid_parameter_value(
                    f"OpenAI route configuration can only specify a value for "
                    f"'openai_organization' if 'openai_api_type' is '{OpenAIAPIType.OPENAI}'"
                )
            base_url = info.get("openai_api_base")
            deployment_name = info.get("openai_deployment_name")
            api_version = info.get("openai_api_version")
            if (base_url, deployment_name, api_version).count(None) > 0:
                raise MlflowException.invalid_parameter_value(
                    f"OpenAI route configuration must specify 'openai_api_base', "
                    f"'openai_deployment_name', and 'openai_api_version' if 'openai_api_type' is "
                    f"'{OpenAIAPIType.AZURE}' or '{OpenAIAPIType.AZUREAD}'."
                )
        else:
            raise MlflowException.invalid_parameter_value(f"Invalid OpenAI API type '{api_type}'")

        return info

    @model_validator(mode="before")
    def validate_field_compatibility(cls, info: dict[str, Any]):
        return cls._validate_field_compatibility(info)


class AnthropicConfig(ConfigModel):
    anthropic_api_key: str
    anthropic_version: str = "2023-06-01"

    @field_validator("anthropic_api_key", mode="before")
    def validate_anthropic_api_key(cls, value):
        return _resolve_api_key_from_input(value)


class PaLMConfig(ConfigModel):
    palm_api_key: str

    @field_validator("palm_api_key", mode="before")
    def validate_palm_api_key(cls, value):
        return _resolve_api_key_from_input(value)


class GeminiConfig(ConfigModel):
    gemini_api_key: str

    @field_validator("gemini_api_key", mode="before")
    def validate_gemini_api_key(cls, value):
        return _resolve_api_key_from_input(value)


class MlflowModelServingConfig(ConfigModel):
    model_server_url: str

    # Workaround to suppress warning that Pydantic raises when a field name starts with "model_".
    # https://github.com/mlflow/mlflow/issues/10335
    model_config = pydantic.ConfigDict(protected_namespaces=())


class HuggingFaceTextGenerationInferenceConfig(ConfigModel):
    hf_server_url: str


class AWSBaseConfig(pydantic.BaseModel):
    aws_region: str | None = None


class AWSRole(AWSBaseConfig):
    aws_role_arn: str
    session_length_seconds: int = 15 * 60


class AWSIdAndKey(AWSBaseConfig):
    aws_access_key_id: str
    aws_secret_access_key: str
    aws_session_token: str | None = None


class AmazonBedrockConfig(ConfigModel):
    # order here is important, at least for pydantic<2
    aws_config: AWSRole | AWSIdAndKey | AWSBaseConfig


class MistralConfig(ConfigModel):
    mistral_api_key: str

    @field_validator("mistral_api_key", mode="before")
    def validate_mistral_api_key(cls, value):
        return _resolve_api_key_from_input(value)


class ModelInfo(ResponseModel):
    name: str | None = None
    provider: Provider


def _resolve_api_key_from_input(api_key_input):
    """
    Resolves the provided API key.

    Input formats accepted:

    - Path to a file as a string which will have the key loaded from it
    - environment variable name that stores the api key
    - the api key itself
    """

    if not isinstance(api_key_input, str):
        raise MlflowException.invalid_parameter_value(
            "The api key provided is not a string. Please provide either an environment "
            "variable key, a path to a file containing the api key, or the api key itself"
        )

    # try reading as an environment variable
    if api_key_input.startswith("$"):
        env_var_name = api_key_input[1:]
        if env_var := os.getenv(env_var_name):
            return env_var
        else:
            raise MlflowException.invalid_parameter_value(
                f"Environment variable {env_var_name!r} is not set"
            )

    # try reading from a local path
    file = pathlib.Path(api_key_input)
    try:
        if file.is_file():
            return file.read_text()
    except OSError:
        # `is_file` throws an OSError if `api_key_input` exceeds the maximum filename length
        # (e.g., 255 characters on Unix).
        pass

    # if the key itself is passed, return
    return api_key_input


class Model(ConfigModel):
    name: str | None = None
    provider: str | Provider
import inspect
from logging import Logger

from mlflow.deployments.base import BaseDeploymentClient
from mlflow.deployments.plugin_manager import DeploymentPlugins
from mlflow.deployments.utils import get_deployments_target
from mlflow.exceptions import MlflowException

plugin_store = DeploymentPlugins()
plugin_store.register("sagemaker", "mlflow.sagemaker")

_logger = Logger(__name__)






















































def run_local(target, name, model_uri, flavor=None, config=None):
    """Deploys the specified model locally, for testing. Note that models deployed locally cannot
    be managed by other deployment APIs (e.g. ``update_deployment``, ``delete_deployment``, etc).

    Args:
        target: Target to deploy to.
        name: Name to use for deployment
        model_uri: URI of model to deploy
        flavor: (optional) Model flavor to deploy. If unspecified, a default flavor
            will be chosen.
        config: (optional) Dict containing updated target-specific configuration for
            the deployment

    Returns:
        None
    """
    return plugin_store[target].run_local(name, model_uri, flavor, config)


def _target_help(target):
    """
    Return a string containing detailed documentation on the current deployment target,
    to be displayed when users invoke the ``mlflow deployments help -t <target-name>`` CLI.
    This method should be defined within the module specified by the plugin author.
    The string should contain:
    * An explanation of target-specific fields in the ``config`` passed to ``create_deployment``,
      ``update_deployment``
    * How to specify a ``target_uri`` (e.g. for AWS SageMaker, ``target_uri``s have a scheme of
      "sagemaker:/<aws-cli-profile-name>", where aws-cli-profile-name is the name of an AWS
      CLI profile https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-profiles.html)
    * Any other target-specific details.

    Args:
        target: Which target to use. This information is used to call the appropriate plugin.
    """
    return plugin_store[target].target_help()from pydantic import ConfigDict

from mlflow.gateway.base_models import ResponseModel
from mlflow.gateway.config import EndpointModelInfo
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,320p' tests/gateway/test_gateway_config_parsing.py
sed -n '1,280p' tests/gateway/test_gateway_app.py"
```

退出码：`0`

输出：
```
import re

import pytest
import yaml

from mlflow.exceptions import MlflowException
from mlflow.gateway.config import (
    AnthropicConfig,
    EndpointConfig,
    OpenAIConfig,
    _load_gateway_config,
    _resolve_api_key_from_input,
    _save_route_config,
)
from mlflow.gateway.utils import assemble_uri_path


@pytest.fixture
def basic_config_dict():
    return {
        "endpoints": [
            {
                "name": "completions-gpt4",
                "endpoint_type": "llm/v1/completions",
                "model": {
                    "name": "gpt-4",
                    "provider": "openai",
                    "config": {
                        "openai_api_key": "mykey",
                        "openai_api_base": "https://api.openai.com/v1",
                        "openai_api_version": "2023-05-10",
                        "openai_api_type": "openai",
                        "openai_organization": "my_company",
                    },
                },
            },
            {
                "name": "chat-gpt4",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "gpt-4",
                    "provider": "openai",
                    "config": {"openai_api_key": "sk-openai"},
                },
            },
            {
                "name": "claude-chat",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "claude-v1",
                    "provider": "anthropic",
                    "config": {
                        "anthropic_api_key": "api_key",
                    },
                },
            },
        ]
    }


@pytest.mark.parametrize(
    ("paths", "expected"),
    [
        (["gateway", "/routes/", "/chat"], "/gateway/routes/chat"),
        (["/gateway/", "/routes", "chat"], "/gateway/routes/chat"),
        (["gateway/routes/", "chat"], "/gateway/routes/chat"),
        (["gateway/", "routes/chat"], "/gateway/routes/chat"),
        (["/gateway/routes", "/chat/"], "/gateway/routes/chat"),
        (["/gateway", "/routes/", "chat/"], "/gateway/routes/chat"),
        (["/"], "/"),
        (["gateway", "", "/routes/", "", "/chat", ""], "/gateway/routes/chat"),
    ],
)
def test_assemble_uri_path(paths, expected):
    assert assemble_uri_path(paths) == expected


def test_api_key_parsing_env(tmp_path, monkeypatch):
    monkeypatch.setenv("KEY_AS_ENV", "my_key")

    assert _resolve_api_key_from_input("$KEY_AS_ENV") == "my_key"
    monkeypatch.delenv("KEY_AS_ENV", raising=False)
    with pytest.raises(MlflowException, match="Environment variable 'KEY_AS_ENV' is not set"):
        _resolve_api_key_from_input("$KEY_AS_ENV")

    string_key = "my_key_as_a_string"

    assert _resolve_api_key_from_input(string_key) == string_key

    conf_path = tmp_path.joinpath("mykey.conf")
    file_key = "Here is my key that sits safely in a file"

    conf_path.write_text(file_key)

    assert _resolve_api_key_from_input(str(conf_path)) == file_key


def test_api_key_input_exceeding_maximum_filename_length():
    assert _resolve_api_key_from_input("a" * 256) == "a" * 256


def test_api_key_parsing_file(tmp_path):
    key_path = tmp_path.joinpath("api.key")
    config = {
        "endpoints": [
            {
                "name": "claude-chat",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "claude-v1",
                    "provider": "anthropic",
                    "config": {
                        "anthropic_api_key": str(key_path),
                    },
                },
            },
        ]
    }

    key_path.write_text("abc")
    config_path = tmp_path.joinpath("config.yaml")
    config_path.write_text(yaml.safe_dump(config))
    loaded_config = _load_gateway_config(config_path)

    assert isinstance(loaded_config.endpoints[0].model.config, AnthropicConfig)
    assert loaded_config.endpoints[0].model.config.anthropic_api_key == "abc"


def test_route_configuration_parsing(basic_config_dict, tmp_path, monkeypatch):
    conf_path = tmp_path.joinpath("config.yaml")

    conf_path.write_text(yaml.safe_dump(basic_config_dict))

    loaded_config = _load_gateway_config(conf_path)

    save_path = tmp_path.joinpath("config2.yaml")
    _save_route_config(loaded_config, save_path)
    loaded_from_save = _load_gateway_config(save_path)

    completions_gpt4 = loaded_from_save.endpoints[0]
    assert completions_gpt4.name == "completions-gpt4"
    assert completions_gpt4.endpoint_type == "llm/v1/completions"
    assert completions_gpt4.model.name == "gpt-4"
    assert completions_gpt4.model.provider == "openai"
    completions_conf = completions_gpt4.model.config
    assert isinstance(completions_conf, OpenAIConfig)
    assert completions_conf.openai_api_key == "mykey"
    assert completions_conf.openai_api_base == "https://api.openai.com/v1"
    assert completions_conf.openai_api_version == "2023-05-10"
    assert completions_conf.openai_api_type == "openai"
    assert completions_conf.openai_organization == "my_company"

    chat_gpt4 = loaded_from_save.endpoints[1]
    assert chat_gpt4.name == "chat-gpt4"
    assert chat_gpt4.endpoint_type == "llm/v1/chat"
    assert chat_gpt4.model.name == "gpt-4"
    assert chat_gpt4.model.provider == "openai"
    chat_conf = chat_gpt4.model.config
    assert isinstance(chat_conf, OpenAIConfig)
    assert chat_conf.openai_api_key == "sk-openai"
    assert chat_conf.openai_api_base == "https://api.openai.com/v1"
    assert chat_conf.openai_api_type == "openai"
    assert chat_conf.openai_api_version is None
    assert chat_conf.openai_organization is None

    claude = loaded_from_save.endpoints[2]
    assert isinstance(claude.model.config, AnthropicConfig)
    assert claude.name == "claude-chat"
    assert claude.endpoint_type == "llm/v1/chat"
    assert claude.model.name == "claude-v1"
    assert claude.model.provider == "anthropic"
    claude_conf = claude.model.config
    assert claude_conf.anthropic_api_key == "api_key"


def test_convert_route_config_to_routes_payload(basic_config_dict, tmp_path):
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(basic_config_dict))
    loaded = _load_gateway_config(conf_path)

    assert all(isinstance(route, EndpointConfig) for route in loaded.endpoints)

    routes = [r.to_endpoint() for r in loaded.endpoints]

    for config in loaded.endpoints:
        route = [x for x in routes if x.name == config.name][0]
        assert route.endpoint_type == config.endpoint_type
        assert route.model.name == config.model.name
        assert route.model.provider == config.model.provider
        # Pydantic doesn't allow undefined elements to be a part of its serialized object.
        # This test is a guard for devs only in case we inadvertently add sensitive keys to the
        # Route definition that would be returned via the GetRoute or SearchRoutes APIs
        assert not hasattr(route.model, "config")


def test_invalid_route_definition(tmp_path):
    invalid_conf = {
        "endpoints": [
            {
                "name": "invalid_route",
                "endpoint_type": "invalid/route",
                "model": {
                    "name": "gpt-4",
                    "provider": "openai",
                    "config": {
                        "openai_api_key": "mykey",
                        "openai_api_base": "https://api.openai.com/v1",
                        "openai_api_version": "2023-05-10",
                        "openai_api_type": "openai/v1/chat/completions",
                        "openai_organization": "my_company",
                    },
                },
            }
        ]
    }
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_conf))

    with pytest.raises(MlflowException, match=r"The route_type 'invalid/route' is not supported."):
        _load_gateway_config(conf_path)


def test_invalid_provider(tmp_path):
    invalid_conf = {
        "endpoints": [
            {
                "name": "invalid_route",
                "endpoint_type": "llm/v1/completions",
                "model": {
                    "name": "gpt-4",
                    "provider": "my_provider",
                    "config": {
                        "openai_api_key": "mykey",
                        "openai_api_base": "https://api.openai.com/v1",
                        "openai_api_version": "2023-05-10",
                        "openai_api_type": "openai/v1/chat/completions",
                        "openai_organization": "my_company",
                    },
                },
            }
        ]
    }
    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_conf))

    with pytest.raises(MlflowException, match=r"The provider 'my_provider' is not supported."):
        _load_gateway_config(conf_path)


def test_invalid_model_definition(tmp_path):
    invalid_partial_config = {
        "endpoints": [
            {
                "name": "some_name",
                "endpoint_type": "llm/v1/completions",
                "model": {
                    "name": "invalid",
                    "provider": "openai",
                    "config": {"openai_api_type": "openai"},
                },
            }
        ]
    }

    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_partial_config))

    with pytest.raises(
        MlflowException, match=re.compile(r"validation error.+openai_api_key", re.DOTALL)
    ):
        _load_gateway_config(conf_path)

    invalid_format_config_key_is_not_string = {
        "endpoints": [
            {
                "name": "some_name",
                "endpoint_type": "llm/v1/chat",
                "model": {
                    "name": "invalid",
                    "provider": "openai",
                    "config": {"openai_api_type": "openai", "openai_api_key": [42]},
                },
            }
        ]
    }

    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_format_config_key_is_not_string))

    with pytest.raises(
        MlflowException,
        match="The api key provided is not a string",
    ):
        _load_gateway_config(conf_path)

    invalid_format_config_key_invalid_path = {
        "endpoints": [
            {
                "name": "some_name",
                "endpoint_type": "llm/v1/embeddings",
                "model": {
                    "name": "invalid",
                    "provider": "openai",
                    "config": {"openai_api_type": "openai", "openai_api_key": "/not/a/real/path"},
                },
            }
        ]
    }

    conf_path = tmp_path.joinpath("config.yaml")
    conf_path.write_text(yaml.safe_dump(invalid_format_config_key_invalid_path))

    assert (
        _load_gateway_config(conf_path).endpoints[0].model.config.openai_api_key
        == "/not/a/real/path"  # pylint: disable=line-too-long
    )

    invalid_no_config = {
        "endpoints": [
            {
from unittest import mock

import pytest
from fastapi.testclient import TestClient

from mlflow.exceptions import MlflowException
from mlflow.gateway.app import create_app_from_config, create_app_from_env
from mlflow.gateway.config import GatewayConfig
from mlflow.gateway.constants import (
    MLFLOW_GATEWAY_CRUD_ENDPOINT_V3_BASE,
    MLFLOW_GATEWAY_CRUD_ROUTE_BASE,
    MLFLOW_GATEWAY_CRUD_ROUTE_V3_BASE,
    MLFLOW_GATEWAY_ROUTE_BASE,
)

from tests.gateway.tools import MockAsyncResponse


@pytest.fixture
def client() -> TestClient:
    config = GatewayConfig(
        **{
            "endpoints": [
                {
                    "name": "completions-gpt4",
                    "endpoint_type": "llm/v1/completions",
                    "model": {
                        "name": "gpt-4",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "mykey",
                            "openai_api_base": "https://api.openai.com/v1",
                            "openai_api_version": "2023-05-10",
                            "openai_api_type": "openai",
                        },
                    },
                },
                {
                    "name": "chat-gpt4",
                    "endpoint_type": "llm/v1/chat",
                    "model": {
                        "name": "gpt-4",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "MY_API_KEY",
                        },
                    },
                },
                {
                    "name": "chat-gpt5",
                    "endpoint_type": "llm/v1/chat",
                    "model": {
                        "name": "gpt-5",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "MY_API_KEY",
                        },
                    },
                },
            ],
            "routes": [
                {
                    "name": "traffic_route1",
                    "task_type": "llm/v1/chat",
                    "destinations": [
                        {
                            "name": "chat-gpt4",
                            "traffic_percentage": 80,
                        },
                        {
                            "name": "chat-gpt5",
                            "traffic_percentage": 20,
                        },
                    ],
                },
            ],
        }
    )
    app = create_app_from_config(config)
    return TestClient(app)


def test_index(client: TestClient):
    response = client.get("/", follow_redirects=False)
    assert response.status_code == 307
    assert response.headers["Location"] == "/docs"


def test_health(client: TestClient):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "OK"}


def test_favicon(client: TestClient):
    response = client.get("/favicon.ico")
    assert response.status_code == 200


def test_docs(client: TestClient):
    response = client.get("/docs")
    assert response.status_code == 200


def test_search_routes(client: TestClient):
    response = client.get(MLFLOW_GATEWAY_CRUD_ROUTE_BASE)
    assert response.status_code == 200
    assert response.json()["routes"] == [
        {
            "name": "completions-gpt4",
            "route_type": "llm/v1/completions",
            "route_url": "/gateway/completions-gpt4/invocations",
            "model": {
                "name": "gpt-4",
                "provider": "openai",
            },
            "limit": None,
        },
        {
            "name": "chat-gpt4",
            "route_type": "llm/v1/chat",
            "route_url": "/gateway/chat-gpt4/invocations",
            "model": {
                "name": "gpt-4",
                "provider": "openai",
            },
            "limit": None,
        },
        {
            "name": "chat-gpt5",
            "route_type": "llm/v1/chat",
            "route_url": "/gateway/chat-gpt5/invocations",
            "model": {
                "name": "gpt-5",
                "provider": "openai",
            },
            "limit": None,
        },
    ]


def test_get_route(client: TestClient):
    response = client.get(f"{MLFLOW_GATEWAY_CRUD_ROUTE_BASE}chat-gpt4")
    assert response.status_code == 200
    assert response.json() == {
        "name": "chat-gpt4",
        "route_type": "llm/v1/chat",
        "route_url": "/gateway/chat-gpt4/invocations",
        "model": {
            "name": "gpt-4",
            "provider": "openai",
        },
        "limit": None,
    }


def test_get_endpoint_v3(client: TestClient):
    response = client.get(f"{MLFLOW_GATEWAY_CRUD_ENDPOINT_V3_BASE}chat-gpt4")
    assert response.status_code == 200
    assert response.json() == {
        "name": "chat-gpt4",
        "endpoint_type": "llm/v1/chat",
        "model": {"name": "gpt-4", "provider": "openai"},
        "endpoint_url": "/gateway/chat-gpt4/invocations",
        "limit": None,
    }


def test_get_route_v3(client: TestClient):
    response = client.get(f"{MLFLOW_GATEWAY_CRUD_ROUTE_V3_BASE}traffic_route1")
    assert response.status_code == 200
    assert response.json() == {
        "name": "traffic_route1",
        "task_type": "llm/v1/chat",
        "destinations": [
            {"name": "chat-gpt4", "traffic_percentage": 80},
            {"name": "chat-gpt5", "traffic_percentage": 20},
        ],
        "routing_strategy": "TRAFFIC_SPLIT",
    }


def test_dynamic_route():
    config = GatewayConfig(
        **{
            "endpoints": [
                {
                    "name": "chat",
                    "endpoint_type": "llm/v1/chat",
                    "model": {
                        "name": "gpt-4",
                        "provider": "openai",
                        "config": {
                            "openai_api_key": "mykey",
                            "openai_api_base": "https://api.openai.com/v1",
                        },
                    },
                    "limit": None,
                }
            ],
            "routes": [
                {
                    "name": "traffic_route",
                    "task_type": "llm/v1/chat",
                    "destinations": [
                        {
                            "name": "chat",
                            "traffic_percentage": 100,
                        }
                    ],
                }
            ],
        }
    )
    app = create_app_from_config(config)
    client = TestClient(app)

    resp = {
        "id": "chatcmpl-abc123",
        "object": "chat.completion",
        "created": 1677858242,
        "model": "gpt-4o-mini",
        "usage": {
            "prompt_tokens": 13,
            "completion_tokens": 7,
            "total_tokens": 20,
        },
        "choices": [
            {
                "message": {
                    "role": "assistant",
                    "content": "\n\nThis is a test!",
                    "refusal": None,
                },
                "finish_reason": "stop",
                "index": 0,
            }
        ],
        "headers": {"Content-Type": "application/json"},
    }
    with mock.patch(
        "aiohttp.ClientSession.post", return_value=MockAsyncResponse(resp)
    ) as mock_post:
        for name in ["chat", "traffic_route"]:
            resp = client.post(
                f"{MLFLOW_GATEWAY_ROUTE_BASE}{name}/invocations",
                json={"messages": [{"role": "user", "content": "Tell me a joke"}]},
            )
            mock_post.assert_called_once()
            assert resp.status_code == 200
            assert resp.json() == {
                "id": "chatcmpl-abc123",
                "object": "chat.completion",
                "created": 1677858242,
                "model": "gpt-4o-mini",
                "usage": {
                    "prompt_tokens": 13,
                    "completion_tokens": 7,
                    "total_tokens": 20,
                },
                "choices": [
                    {
                        "message": {
                            "role": "assistant",
                            "content": "\n\nThis is a test!",
                            "tool_calls": None,
                            "refusal": None,
                        },
                        "finish_reason": "stop",
                        "index": 0,
                    }
                ],
            }

            mock_post.reset_mock()


def test_create_app_from_env_fails_if_MLFLOW_GATEWAY_CONFIG_is_not_set(monkeypatch):
    monkeypatch.delenv("MLFLOW_GATEWAY_CONFIG", raising=False)
    with pytest.raises(MlflowException, match="'MLFLOW_GATEWAY_CONFIG' is not set"):
```

## 原始行 24 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/gateway/config.py | sed -n '200,700p'"
```

退出码：`0`

输出：
```
   200	class HuggingFaceTextGenerationInferenceConfig(ConfigModel):
   201	    hf_server_url: str
   202	
   203	
   204	class AWSBaseConfig(pydantic.BaseModel):
   205	    aws_region: str | None = None
   206	
   207	
   208	class AWSRole(AWSBaseConfig):
   209	    aws_role_arn: str
   210	    session_length_seconds: int = 15 * 60
   211	
   212	
   213	class AWSIdAndKey(AWSBaseConfig):
   214	    aws_access_key_id: str
   215	    aws_secret_access_key: str
   216	    aws_session_token: str | None = None
   217	
   218	
   219	class AmazonBedrockConfig(ConfigModel):
   220	    # order here is important, at least for pydantic<2
   221	    aws_config: AWSRole | AWSIdAndKey | AWSBaseConfig
   222	
   223	
   224	class MistralConfig(ConfigModel):
   225	    mistral_api_key: str
   226	
   227	    @field_validator("mistral_api_key", mode="before")
   228	    def validate_mistral_api_key(cls, value):
   229	        return _resolve_api_key_from_input(value)
   230	
   231	
   232	class ModelInfo(ResponseModel):
   233	    name: str | None = None
   234	    provider: Provider
   235	
   236	
   237	def _resolve_api_key_from_input(api_key_input):
   238	    """
   239	    Resolves the provided API key.
   240	
   241	    Input formats accepted:
   242	
   243	    - Path to a file as a string which will have the key loaded from it
   244	    - environment variable name that stores the api key
   245	    - the api key itself
   246	    """
   247	
   248	    if not isinstance(api_key_input, str):
   249	        raise MlflowException.invalid_parameter_value(
   250	            "The api key provided is not a string. Please provide either an environment "
   251	            "variable key, a path to a file containing the api key, or the api key itself"
   252	        )
   253	
   254	    # try reading as an environment variable
   255	    if api_key_input.startswith("$"):
   256	        env_var_name = api_key_input[1:]
   257	        if env_var := os.getenv(env_var_name):
   258	            return env_var
   259	        else:
   260	            raise MlflowException.invalid_parameter_value(
   261	                f"Environment variable {env_var_name!r} is not set"
   262	            )
   263	
   264	    # try reading from a local path
   265	    file = pathlib.Path(api_key_input)
   266	    try:
   267	        if file.is_file():
   268	            return file.read_text()
   269	    except OSError:
   270	        # `is_file` throws an OSError if `api_key_input` exceeds the maximum filename length
   271	        # (e.g., 255 characters on Unix).
   272	        pass
   273	
   274	    # if the key itself is passed, return
   275	    return api_key_input
   276	
   277	
   278	class Model(ConfigModel):
   279	    name: str | None = None
   280	    provider: str | Provider
   281	    config: SerializeAsAny[ConfigModel] | None = None
   282	
   283	    @field_validator("provider", mode="before")
   284	    def validate_provider(cls, value):
   285	        from mlflow.gateway.provider_registry import provider_registry
   286	
   287	        if isinstance(value, Provider):
   288	            return value
   289	        formatted_value = value.replace("-", "_").upper()
   290	        if formatted_value in Provider.__members__:
   291	            return Provider[formatted_value]
   292	        if value in provider_registry.keys():
   293	            return value
   294	        raise MlflowException.invalid_parameter_value(f"The provider '{value}' is not supported.")
   295	
   296	    @classmethod
   297	    def _validate_config(cls, val, context):
   298	        from mlflow.gateway.provider_registry import provider_registry
   299	
   300	        # For Pydantic v2: 'context' is a ValidationInfo object with a 'data' attribute.
   301	        # For Pydantic v1: 'context' is dict-like 'values'.
   302	        provider = context.data.get("provider")
   303	        if provider:
   304	            config_type = provider_registry.get(provider).CONFIG_TYPE
   305	            return config_type(**val) if isinstance(val, dict) else val
   306	        raise MlflowException.invalid_parameter_value(
   307	            "A provider must be provided for each gateway route."
   308	        )
   309	
   310	    @field_validator("config", mode="before")
   311	    def validate_config(cls, info, values):
   312	        return cls._validate_config(info, values)
   313	
   314	
   315	class AliasedConfigModel(ConfigModel):
   316	    """
   317	    Enables use of field aliases in a configuration model for backwards compatibility
   318	    """
   319	
   320	    model_config = ConfigDict(populate_by_name=True)
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	class LimitsConfig(ConfigModel):
   330	    limits: list[Limit] | None = []
   331	
   332	
   333	class EndpointConfig(AliasedConfigModel):
   334	    name: str
   335	    endpoint_type: EndpointType
   336	    model: Model
   337	    limit: Limit | None = None
   338	
   339	    @field_validator("name")
   340	    def validate_endpoint_name(cls, route_name):
   341	        if not is_valid_endpoint_name(route_name):
   342	            raise MlflowException.invalid_parameter_value(
   343	                "The route name provided contains disallowed characters for a url endpoint. "
   344	                f"'{route_name}' is invalid. Names cannot contain spaces or any non "
   345	                "alphanumeric characters other than hyphen and underscore."
   346	            )
   347	        return route_name
   348	
   349	    @field_validator("model", mode="before")
   350	    def validate_model(cls, model):
   351	        if model:
   352	            model_instance = Model(**model)
   353	            if model_instance.provider in Provider.values() and model_instance.config is None:
   354	                raise MlflowException.invalid_parameter_value(
   355	                    "A config must be supplied when setting a provider. The provider entry for "
   356	                    f"{model_instance.provider} is incorrect."
   357	                )
   358	        return model
   359	
   360	    @model_validator(mode="after")
   361	    def validate_route_type_and_model_name(self):
   362	        if (
   363	            self.model
   364	            and self.model.provider == "mosaicml"
   365	            and self.endpoint_type == EndpointType.LLM_V1_CHAT
   366	            and not is_valid_mosiacml_chat_model(self.model.name)
   367	        ):
   368	            raise MlflowException.invalid_parameter_value(
   369	                f"An invalid model has been specified for the chat route. '{self.model.name}'. "
   370	                f"Ensure the model selected starts with one of: "
   371	                f"{MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES}"
   372	            )
   373	        if (
   374	            self.model
   375	            and self.model.provider == "ai21labs"
   376	            and not is_valid_ai21labs_model(self.model.name)
   377	        ):
   378	            raise MlflowException.invalid_parameter_value(
   379	                f"An Unsupported AI21Labs model has been specified: '{self.model.name}'. "
   380	                f"Please see documentation for supported models."
   381	            )
   382	        return self
   383	
   384	    @field_validator("endpoint_type", mode="before")
   385	    def validate_route_type(cls, value):
   386	        if value in EndpointType._value2member_map_:
   387	            return value
   388	        raise MlflowException.invalid_parameter_value(f"The route_type '{value}' is not supported.")
   389	
   390	    @field_validator("limit", mode="before")
   391	    def validate_limit(cls, value):
   392	        from limits import parse
   393	
   394	        if value:
   395	            limit = Limit(**value)
   396	            try:
   397	                parse(f"{limit.calls}/{limit.renewal_period}")
   398	            except ValueError:
   399	                raise MlflowException.invalid_parameter_value(
   400	                    "Failed to parse the rate limit configuration."
   401	                    "Please make sure limit.calls is a positive number and"
   402	                    "limit.renewal_period is a right granularity"
   403	                )
   404	
   405	        return value
   406	
   407	    def _to_legacy_route(self) -> "_LegacyRoute":
   408	        return _LegacyRoute(
   409	            name=self.name,
   410	            route_type=self.endpoint_type,
   411	            model=EndpointModelInfo(
   412	                name=self.model.name,
   413	                provider=self.model.provider,
   414	            ),
   415	            route_url=f"{MLFLOW_GATEWAY_ROUTE_BASE}{self.name}{MLFLOW_QUERY_SUFFIX}",
   416	            limit=self.limit,
   417	        )
   418	
   419	    def to_endpoint(self) -> "Endpoint":
   420	        from mlflow.deployments.server.config import Endpoint
   421	
   422	        return Endpoint(
   423	            name=self.name,
   424	            endpoint_type=self.endpoint_type,
   425	            model=EndpointModelInfo(
   426	                name=self.model.name,
   427	                provider=self.model.provider,
   428	            ),
   429	            endpoint_url=f"{MLFLOW_GATEWAY_ROUTE_BASE}{self.name}{MLFLOW_QUERY_SUFFIX}",
   430	            limit=self.limit,
   431	        )
   432	
   433	
   434	class RouteDestinationConfig(ConfigModel):
   435	    name: str
   436	    traffic_percentage: int
   437	
   438	
   439	class TrafficRouteConfig(ConfigModel):
   440	    name: str
   441	    task_type: EndpointType
   442	    destinations: list[RouteDestinationConfig]
   443	    routing_strategy: Literal["TRAFFIC_SPLIT"] = "TRAFFIC_SPLIT"
   444	
   445	
   446	class EndpointModelInfo(ResponseModel):
   447	    name: str | None = None
   448	    # Use `str` instead of `Provider` enum to allow gateway backends such as Databricks to
   449	    # support new providers without breaking the gateway client.
   450	    provider: str
   451	
   452	
   453	_ROUTE_EXTRA_SCHEMA = {
   454	    "example": {
   455	        "name": "openai-completions",
   456	        "route_type": "llm/v1/completions",
   457	        "model": {
   458	            "name": "gpt-4o-mini",
   459	            "provider": "openai",
   460	        },
   461	        "route_url": "/gateway/routes/completions/invocations",
   462	    }
   463	}
   464	
   465	
   466	class _LegacyRoute(ConfigModel):
   467	    name: str
   468	    route_type: str
   469	    model: EndpointModelInfo
   470	    route_url: str
   471	    limit: Limit | None = None
   472	
   473	    model_config = ConfigDict(json_schema_extra=_ROUTE_EXTRA_SCHEMA)
   474	
   475	    def to_endpoint(self):
   476	        from mlflow.deployments.server.config import Endpoint
   477	
   478	        return Endpoint(
   479	            name=self.name,
   480	            endpoint_type=self.route_type,
   481	            model=self.model,
   482	            endpoint_url=self.route_url,
   483	            limit=self.limit,
   484	        )
   485	
   486	
   487	class GatewayConfig(AliasedConfigModel):
   488	    endpoints: list[EndpointConfig]
   489	    routes: list[TrafficRouteConfig] | None = None
   490	
   491	
   492	def _load_gateway_config(path: str | Path) -> GatewayConfig:
   493	    """
   494	    Reads the gateway configuration yaml file from the storage location and returns an instance
   495	    of the configuration RouteConfig class
   496	    """
   497	    if isinstance(path, str):
   498	        path = Path(path)
   499	    try:
   500	        configuration = yaml.safe_load(path.read_text())
   501	    except Exception as e:
   502	        raise MlflowException.invalid_parameter_value(
   503	            f"The file at {path} is not a valid yaml file"
   504	        ) from e
   505	    check_configuration_deprecated_fields(configuration)
   506	    check_configuration_route_name_collisions(configuration)
   507	    try:
   508	        return GatewayConfig(**configuration)
   509	    except ValidationError as e:
   510	        raise MlflowException.invalid_parameter_value(
   511	            f"The gateway configuration is invalid: {e}"
   512	        ) from e
   513	
   514	
   515	def _save_route_config(config: GatewayConfig, path: str | Path) -> None:
   516	    if isinstance(path, str):
   517	        path = Path(path)
   518	    path.write_text(
   519	        yaml.safe_dump(json.loads(json.dumps(config.model_dump(), default=pydantic_encoder)))
   520	    )
   521	
   522	
   523	def _validate_config(config_path: str) -> GatewayConfig:
   524	    if not os.path.exists(config_path):
   525	        raise MlflowException.invalid_parameter_value(f"{config_path} does not exist")
   526	
   527	    try:
   528	        return _load_gateway_config(config_path)
   529	    except Exception as e:
   530	        raise MlflowException.invalid_parameter_value(f"Invalid gateway configuration: {e}") from e
```

## 原始行 26 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/utils/rest_utils.py | sed -n '1,360p'
nl -ba mlflow/utils/rest_utils.py | sed -n '360,800p'"
```

退出码：`0`

输出：
```
     1	import base64
     2	import json
     3	import logging
     4	import random
     5	import time
     6	import warnings
     7	from functools import lru_cache
     8	from typing import Any, Callable
     9	
    10	import requests
    11	
    12	from mlflow.environment_variables import (
    13	    _MLFLOW_DATABRICKS_TRAFFIC_ID,
    14	    _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT,
    15	    _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT,
    16	    MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT,
    17	    MLFLOW_ENABLE_DB_SDK,
    18	    MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR,
    19	    MLFLOW_HTTP_REQUEST_BACKOFF_JITTER,
    20	    MLFLOW_HTTP_REQUEST_MAX_RETRIES,
    21	    MLFLOW_HTTP_REQUEST_TIMEOUT,
    22	    MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER,
    23	)
    24	from mlflow.exceptions import (
    25	    CUSTOMER_UNAUTHORIZED,
    26	    ERROR_CODE_TO_HTTP_STATUS,
    27	    INVALID_PARAMETER_VALUE,
    28	    InvalidUrlException,
    29	    MlflowException,
    30	    RestException,
    31	    get_error_code,
    32	)
    33	from mlflow.protos import databricks_pb2
    34	from mlflow.protos.databricks_pb2 import ENDPOINT_NOT_FOUND, ErrorCode
    35	from mlflow.utils.proto_json_utils import parse_dict
    36	from mlflow.utils.request_utils import _TRANSIENT_FAILURE_RESPONSE_CODES, augmented_raise_for_status, cloud_storage_http_request
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	_logger = logging.getLogger(__name__)
    45	
    46	RESOURCE_NON_EXISTENT = "RESOURCE_DOES_NOT_EXIST"
    47	_REST_API_PATH_PREFIX = "/api/2.0"
    48	_UC_OSS_REST_API_PATH_PREFIX = "/api/2.1"
    49	_TRACE_REST_API_PATH_PREFIX = f"{_REST_API_PATH_PREFIX}/mlflow/traces"
    50	_V3_REST_API_PATH_PREFIX = "/api/3.0"
    51	_V3_TRACE_REST_API_PATH_PREFIX = f"{_V3_REST_API_PATH_PREFIX}/mlflow/traces"
    52	_V4_REST_API_PATH_PREFIX = "/api/4.0"
    53	_V4_TRACE_REST_API_PATH_PREFIX = f"{_V4_REST_API_PATH_PREFIX}/mlflow/traces"
    54	_ARMERIA_OK = "200 OK"
    55	_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING = (
    56	    "The 'retry_after_secs' parameter of DatabricksError is deprecated"
    57	)
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	
   210	
   211	
   212	
   213	
   214	
   215	
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	@lru_cache(maxsize=5)
   263	def get_workspace_client(
   264	    use_secret_scope_token,
   265	    host,
   266	    token,
   267	    databricks_auth_profile,
   268	    retry_timeout_seconds=None,
   269	    timeout=None,
   270	):
   271	    from databricks.sdk import WorkspaceClient
   272	    from databricks.sdk.config import Config
   273	
   274	    if use_secret_scope_token:
   275	        kwargs = {"host": host, "token": token}
   276	    else:
   277	        kwargs = {"profile": databricks_auth_profile}
   278	    if timeout is not None:
   279	        kwargs["http_timeout_seconds"] = timeout
   280	    config = Config(
   281	        **kwargs,
   282	        retry_timeout_seconds=retry_timeout_seconds
   283	        or MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get(),
   284	    )
   285	    # Note: If we use `config` param, all SDK configurations must be set in `config` object.
   286	    return WorkspaceClient(config=config)
   287	
   288	
   289	def _can_parse_as_json_object(string):
   290	    try:
   291	        return isinstance(json.loads(string), dict)
   292	    except Exception:
   293	        return False
   294	
   295	
   296	def http_request_safe(host_creds, endpoint, method, **kwargs):
   297	    """
   298	    Wrapper around ``http_request`` that also verifies that the request succeeds with code 200.
   299	    """
   300	    response = http_request(host_creds=host_creds, endpoint=endpoint, method=method, **kwargs)
   301	    return verify_rest_response(response, endpoint)
   302	
   303	
   304	def verify_rest_response(response, endpoint):
   305	    """Verify the return code and format, raise exception if the request was not successful."""
   306	    # Handle Armeria-specific response case where response text is "200 OK"
   307	    # v1/traces endpoint might return empty response
   308	    if response.status_code == 200 and response.text.strip() in (_ARMERIA_OK, ""):
   309	        response._content = b"{}"  # Update response content to be an empty JSON dictionary
   310	        return response
   311	
   312	    # Handle non-200 status codes
   313	    if response.status_code != 200:
   314	        if _can_parse_as_json_object(response.text):
   315	            raise RestException(json.loads(response.text))
   316	        else:
   317	            base_msg = (
   318	                f"API request to endpoint {endpoint} "
   319	                f"failed with error code {response.status_code} != 200"
   320	            )
   321	            raise MlflowException(
   322	                f"{base_msg}. Response body: '{response.text}'",
   323	                error_code=get_error_code(response.status_code),
   324	            )
   325	
   326	    # Skip validation for endpoints (e.g. DBFS file-download API) which may return a non-JSON
   327	    # response
   328	    if endpoint.startswith(_REST_API_PATH_PREFIX) and not _can_parse_as_json_object(response.text):
   329	        base_msg = (
   330	            "API request to endpoint was successful but the response body was not "
   331	            "in a valid JSON format"
   332	        )
   333	        raise MlflowException(f"{base_msg}. Response body: '{response.text}'")
   334	
   335	    return response
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	def validate_deployment_timeout_config(timeout: int | None, retry_timeout_seconds: int | None):
   388	    """
   389	    Validate that total retry timeout is not less than single request timeout.
   390	
   391	    Args:
   392	        timeout: Maximum time for a single HTTP request (in seconds)
   393	        retry_timeout_seconds: Maximum time for all retry attempts combined (in seconds)
   394	    """
   395	    if timeout is not None and retry_timeout_seconds is not None:
   396	        if retry_timeout_seconds < timeout:
   397	            warnings.warn(
   398	                f"MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT ({retry_timeout_seconds}s) is set "
   399	                f"lower than MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT ({timeout}s). This means the "
   400	                "total retry timeout could expire before a single request completes, causing "
   401	                "premature failures. For long-running predictions, ensure "
   402	                "MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT >= MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT. "
   403	                f"Recommended: Set MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT to at least {timeout}s.",
   404	                stacklevel=2,
   405	            )
   406	
   407	
   408	def _time_sleep(seconds: float) -> None:
   409	    """
   410	    This function is specifically mocked in `test_rest_utils.py` to test the backoff logic in
   411	    isolation. We avoid wrapping `time.sleep` globally to prevent interfering with unrelated sleep
   412	    calls elsewhere in the codebase or in third-party libraries.
   413	    """
   414	    time.sleep(seconds)
   415	
   416	
   417	def _retry_databricks_sdk_call_with_exponential_backoff(
   418	    *,
   419	    call_func: Callable[..., Any],
   420	    retry_codes: list[int],
   421	    retry_timeout_seconds: int,
   422	    backoff_factor: int,
   423	    backoff_jitter: float,
   424	    max_retries: int,
   425	):
   426	    """
   427	    Retry a Databricks SDK call with exponential backoff until timeout or max retries reached.
   428	
   429	    Args:
   430	        call_func: Function to call that may raise DatabricksError
   431	        retry_codes: Set of HTTP status codes that should trigger retries
   432	        retry_timeout_seconds: Maximum time to spend retrying in seconds
   433	        backoff_factor: Factor for exponential backoff
   434	        backoff_jitter: Random jitter to add to backoff
   435	        max_retries: Maximum number of retry attempts
   436	
   437	    Returns:
   438	        The result of call_func() on success
   439	
   440	    Raises:
   441	        DatabricksError: If all retries are exhausted or non-retryable error occurs
   442	    """
   443	    from databricks.sdk.errors import STATUS_CODE_MAPPING, DatabricksError
   444	
   445	    start_time = time.time()
   446	    attempt = 0
   447	
   448	    while attempt <= max_retries:
   449	        try:
   450	            return call_func()
   451	        except DatabricksError as e:
   452	            # Get HTTP status code from the error
   453	            status_code = next(
   454	                (code for code, cls in STATUS_CODE_MAPPING.items() if isinstance(e, cls)), 500
   455	            )
   456	            # Check if this is a retryable error
   457	            if status_code not in retry_codes:
   458	                raise
   459	
   460	            # Check if we've exceeded max retries
   461	            if attempt >= max_retries:
   462	                _logger.warning(f"Max retries ({max_retries}) exceeded: {e}")
   463	                raise
   464	
   465	            # Calculate backoff time with exponential backoff and jitter
   466	            # NB: Ideally, we'd use urllib3.Retry to compute the jitter, check whether we've
   467	            # exceed max retries, etc. However, urllib3.Retry in urllib3 version 1.x, which MLflow
   468	            # maintains compatibility with, doesn't support retries with jitter
   469	            if attempt <= 0:
   470	                backoff_time = 0  # No backoff on first retry attempt
   471	            else:
   472	                backoff_time = backoff_factor * (2**attempt)
   473	                if backoff_jitter > 0:
   474	                    backoff_time += random.random() * backoff_jitter
   475	
   476	            # Check if we've exceeded or would exceed timeout
   477	            elapsed_time = time.time() - start_time
   478	            if elapsed_time + backoff_time >= retry_timeout_seconds:
   479	                _logger.warning(f"Retry timeout ({retry_timeout_seconds}s) exceeded: {e}")
   480	                raise
   481	
   482	            _logger.debug(
   483	                f"Databricks SDK call failed with retryable error (status {status_code}): {e}. "
   484	                f"Retrying in {backoff_time:.2f} seconds (attempt {attempt + 1})"
   485	            )
   486	
   487	            _time_sleep(backoff_time)
   488	            attempt += 1
   489	
   490	
   491	def _get_path(path_prefix, endpoint_path):
   492	    return f"{path_prefix}{endpoint_path}"
   493	
   494	
   495	def extract_api_info_for_service(service, path_prefix):
   496	    """Return a dictionary mapping each API method to a tuple (path, HTTP method)"""
   497	    service_methods = service.DESCRIPTOR.methods
   498	    res = {}
   499	    for service_method in service_methods:
   500	        endpoints = service_method.GetOptions().Extensions[databricks_pb2.rpc].endpoints
   501	        endpoint = endpoints[0]
   502	        endpoint_path = _get_path(path_prefix, endpoint.path)
   503	        res[service().GetRequestClass(service_method)] = (endpoint_path, endpoint.method)
   504	    return res
   505	
   506	
   507	def extract_all_api_info_for_service(service, path_prefix):
   508	    """Return a dictionary mapping each API method to a list of tuples [(path, HTTP method)]"""
   509	    service_methods = service.DESCRIPTOR.methods
   510	    res = {}
   511	    for service_method in service_methods:
   512	        endpoints = service_method.GetOptions().Extensions[databricks_pb2.rpc].endpoints
   513	        res[service().GetRequestClass(service_method)] = [
   514	            (_get_path(path_prefix, endpoint.path), endpoint.method) for endpoint in endpoints
   515	        ]
   516	    return res
   517	
   518	
   519	def get_single_trace_endpoint(request_id, use_v3=True):
   520	    """
   521	    Get the endpoint for a single trace.
   522	    For Databricks tracking URIs, use the V3 API.
   523	    For all other tracking URIs, use the V2 API.
   524	
   525	    Args:
   526	        request_id: The trace ID.
   527	        use_v3: Whether to use the V3 API. If True, use the V3 API. If False, use the V2 API.
   528	    """
   529	    if use_v3:
   530	        return f"{_V3_TRACE_REST_API_PATH_PREFIX}/{request_id}"
   531	    return f"{_TRACE_REST_API_PATH_PREFIX}/{request_id}"
   532	
   533	
   534	def get_single_trace_endpoint_v4(location: str, trace_id: str) -> str:
   535	    """
   536	    Get the endpoint for a single trace using the V4 API.
   537	    """
   538	    return f"{_V4_TRACE_REST_API_PATH_PREFIX}/{location}/{trace_id}"
   539	
   540	
   541	def get_single_assessment_endpoint_v4(location: str, trace_id: str, assessment_id: str) -> str:
   542	    """
   543	    Get the endpoint for a single assessment using the V4 API.
   544	    """
   545	    return f"{_V4_TRACE_REST_API_PATH_PREFIX}/{location}/{trace_id}/assessments/{assessment_id}"
   546	
   547	
   548	def get_logged_model_endpoint(model_id: str) -> str:
   549	    return f"{_REST_API_PATH_PREFIX}/mlflow/logged-models/{model_id}"
   550	
   551	
   552	def get_single_assessment_endpoint(trace_id: str, assessment_id: str) -> str:
   553	    """
   554	    Get the endpoint for a single assessment.
   555	
   556	    Args:
   557	        trace_id: The trace ID.
   558	        assessment_id: The assessment ID.
   559	    """
   560	    return f"{_V3_TRACE_REST_API_PATH_PREFIX}/{trace_id}/assessments/{assessment_id}"
   561	
   562	
   563	def get_trace_tag_endpoint(trace_id):
   564	    """Get the endpoint for trace tags. Always use v2 endpoint."""
   565	    return f"{_REST_API_PATH_PREFIX}/mlflow/traces/{trace_id}/tags"
   566	
   567	
   568	def call_endpoint(
   569	    host_creds,
   570	    endpoint,
   571	    method,
   572	    json_body,
   573	    response_proto,
   574	    extra_headers=None,
   575	    retry_timeout_seconds=None,
   576	):
   577	    # Convert json string to json dictionary, to pass to requests
   578	    if json_body is not None:
   579	        json_body = json.loads(json_body)
   580	    call_kwargs = {
   581	        "host_creds": host_creds,
   582	        "endpoint": endpoint,
   583	        "method": method,
   584	    }
   585	    if extra_headers is not None:
   586	        call_kwargs["extra_headers"] = extra_headers
   587	    if retry_timeout_seconds is not None:
   588	        call_kwargs["retry_timeout_seconds"] = retry_timeout_seconds
   589	    if method == "GET":
   590	        call_kwargs["params"] = json_body
   591	        response = http_request(**call_kwargs)
   592	    else:
   593	        call_kwargs["json"] = json_body
   594	        response = http_request(**call_kwargs)
   595	
   596	    response = verify_rest_response(response, endpoint)
   597	    response_to_parse = response.text
   598	    try:
   599	        js_dict = json.loads(response_to_parse)
   600	    except json.JSONDecodeError:
   601	        if len(response_to_parse) > 50:
   602	            response_to_parse = response_to_parse[:50] + "..."
   603	        _logger.warning(f"Response is not a valid JSON object: {response_to_parse}")
   604	        raise
   605	
   606	    parse_dict(js_dict=js_dict, message=response_proto)
   607	    return response_proto
   608	
   609	
   610	def call_endpoints(host_creds, endpoints, json_body, response_proto, extra_headers=None):
   611	    # The order that the endpoints are called in is defined by the order
   612	    # specified in ModelRegistryService in model_registry.proto
   613	    for i, (endpoint, method) in enumerate(endpoints):
   614	        try:
   615	            return call_endpoint(
   616	                host_creds, endpoint, method, json_body, response_proto, extra_headers
   617	            )
   618	        except RestException as e:
   619	            if e.error_code != ErrorCode.Name(ENDPOINT_NOT_FOUND) or i == len(endpoints) - 1:
   620	                raise e
   621	
   622	
   623	class MlflowHostCreds:
   624	    """
   625	    Provides a hostname and optional authentication for talking to an MLflow tracking server.
   626	
   627	    Args:
   628	        host: Hostname (e.g., http://localhost:5000) to MLflow server. Required.
   629	        username: Username to use with Basic authentication when talking to server.
   630	            If this is specified, password must also be specified.
   631	        password: Password to use with Basic authentication when talking to server.
   632	            If this is specified, username must also be specified.
   633	        token: Token to use with Bearer authentication when talking to server.
   634	            If provided, user/password authentication will be ignored.
   635	        aws_sigv4: If true, we will create a signature V4 to be added for any outgoing request.
   636	            Keys for signing the request can be passed via ENV variables,
   637	            or will be fetched via boto3 session.
   638	        auth: If set, the auth will be added for any outgoing request.
   639	            Keys for signing the request can be passed via ENV variables,
   640	        ignore_tls_verification: If true, we will not verify the server's hostname or TLS
   641	            certificate. This is useful for certain testing situations, but should never be
   642	            true in production.
   643	            If this is set to true ``server_cert_path`` must not be set.
   644	        client_cert_path: Path to ssl client cert file (.pem).
   645	            Sets the cert param of the ``requests.request``
   646	            function (see https://requests.readthedocs.io/en/master/api/).
   647	        server_cert_path: Path to a CA bundle to use.
   648	            Sets the verify param of the ``requests.request``
   649	            function (see https://requests.readthedocs.io/en/master/api/).
   650	            If this is set ``ignore_tls_verification`` must be false.
   651	        use_databricks_sdk: A boolean value represent whether using Databricks SDK for
   652	            authentication.
   653	        databricks_auth_profile: The name of the profile used by Databricks SDK for
   654	            authentication.
   655	        client_id: The client ID used by Databricks OAuth
   656	        client_secret: The client secret used by Databricks OAuth
   657	    """
   658	
   659	    def __init__(
   660	        self,
   661	        host,
   662	        username=None,
   663	        password=None,
   664	        token=None,
   665	        aws_sigv4=False,
   666	        auth=None,
   667	        ignore_tls_verification=False,
   668	        client_cert_path=None,
   669	        server_cert_path=None,
   670	        use_databricks_sdk=False,
   671	        databricks_auth_profile=None,
   672	        client_id=None,
   673	        client_secret=None,
   674	        use_secret_scope_token=False,
   675	    ):
   676	        if not host:
   677	            raise MlflowException(
   678	                message="host is a required parameter for MlflowHostCreds",
   679	                error_code=INVALID_PARAMETER_VALUE,
   680	            )
   681	        if ignore_tls_verification and (server_cert_path is not None):
   682	            raise MlflowException(
   683	                message=(
   684	                    "When 'ignore_tls_verification' is true then 'server_cert_path' "
   685	                    "must not be set! This error may have occurred because the "
   686	                    "'MLFLOW_TRACKING_INSECURE_TLS' and 'MLFLOW_TRACKING_SERVER_CERT_PATH' "
   687	                    "environment variables are both set - only one of these environment "
   688	                    "variables may be set."
   689	                ),
   690	                error_code=INVALID_PARAMETER_VALUE,
   691	            )
   692	        self.host = host
   693	        self.username = username
   694	        self.password = password
   695	        self.token = token
   696	        self.aws_sigv4 = aws_sigv4
   697	        self.auth = auth
   698	        self.ignore_tls_verification = ignore_tls_verification
   699	        self.client_cert_path = client_cert_path
   700	        self.server_cert_path = server_cert_path
   701	        self.use_databricks_sdk = use_databricks_sdk
   702	        self.databricks_auth_profile = databricks_auth_profile
   703	        self.client_id = client_id
   704	        self.client_secret = client_secret
   705	        self.use_secret_scope_token = use_secret_scope_token
   706	
   707	    def __eq__(self, other):
   708	        if isinstance(other, self.__class__):
   709	            return self.__dict__ == other.__dict__
   710	        return NotImplemented
   711	
   712	    def __hash__(self):
   713	        return hash(frozenset(self.__dict__.items()))
   714
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/deployments/interface.py | sed -n '1,180p'
nl -ba mlflow/deployments/server/config.py | sed -n '1,220p'
nl -ba mlflow/deployments/__init__.py | sed -n '1,160p'
nl -ba mlflow/deployments/utils.py | sed -n '1,180p'
nl -ba mlflow/deployments/plugin_manager.py | sed -n '1,220p'"
```

退出码：`0`

输出：
```
     1	import inspect
     2	from logging import Logger
     3	
     4	from mlflow.deployments.base import BaseDeploymentClient
     5	from mlflow.deployments.plugin_manager import DeploymentPlugins
     6	from mlflow.deployments.utils import get_deployments_target
     7	from mlflow.exceptions import MlflowException
     8	
     9	plugin_store = DeploymentPlugins()
    10	plugin_store.register("sagemaker", "mlflow.sagemaker")
    11	
    12	_logger = Logger(__name__)
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	def run_local(target, name, model_uri, flavor=None, config=None):
    68	    """Deploys the specified model locally, for testing. Note that models deployed locally cannot
    69	    be managed by other deployment APIs (e.g. ``update_deployment``, ``delete_deployment``, etc).
    70	
    71	    Args:
    72	        target: Target to deploy to.
    73	        name: Name to use for deployment
    74	        model_uri: URI of model to deploy
    75	        flavor: (optional) Model flavor to deploy. If unspecified, a default flavor
    76	            will be chosen.
    77	        config: (optional) Dict containing updated target-specific configuration for
    78	            the deployment
    79	
    80	    Returns:
    81	        None
    82	    """
    83	    return plugin_store[target].run_local(name, model_uri, flavor, config)
    84	
    85	
    86	def _target_help(target):
    87	    """
    88	    Return a string containing detailed documentation on the current deployment target,
    89	    to be displayed when users invoke the ``mlflow deployments help -t <target-name>`` CLI.
    90	    This method should be defined within the module specified by the plugin author.
    91	    The string should contain:
    92	    * An explanation of target-specific fields in the ``config`` passed to ``create_deployment``,
    93	      ``update_deployment``
    94	    * How to specify a ``target_uri`` (e.g. for AWS SageMaker, ``target_uri``s have a scheme of
    95	      "sagemaker:/<aws-cli-profile-name>", where aws-cli-profile-name is the name of an AWS
    96	      CLI profile https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-profiles.html)
    97	    * Any other target-specific details.
    98	
    99	    Args:
   100	        target: Which target to use. This information is used to call the appropriate plugin.
   101	    """
   102	    return plugin_store[target].target_help()
     1	from pydantic import ConfigDict
     2	
     3	from mlflow.gateway.base_models import ResponseModel
     4	from mlflow.gateway.config import EndpointModelInfo
     1	"""
     2	Exposes functionality for deploying MLflow models to custom serving tools.
     3	
     4	Note: model deployment to AWS Sagemaker can currently be performed via the
     5	:py:mod:`mlflow.sagemaker` module. Model deployment to Azure can be performed by using the
     6	`azureml library <https://pypi.org/project/azureml-mlflow/>`_.
     7	
     8	MLflow does not currently provide built-in support for any other deployment targets, but support
     9	for custom targets can be installed via third-party plugins. See a list of known plugins
    10	`here <https://mlflow.org/docs/latest/plugins.html#deployment-plugins>`_.
    11	
    12	This page largely focuses on the user-facing deployment APIs. For instructions on implementing
    13	your own plugin for deployment to a custom serving tool, see
    14	`plugin docs <http://mlflow.org/docs/latest/plugins.html#writing-your-own-mlflow-plugins>`_.
    15	"""
    16	
    17	import contextlib
    18	import json
    19	
    20	from mlflow.deployments.base import BaseDeploymentClient
    21	from mlflow.deployments.databricks import DatabricksDeploymentClient, DatabricksEndpoint
    22	from mlflow.deployments.interface import run_local
    23	from mlflow.deployments.openai import OpenAIDeploymentClient
    24	from mlflow.deployments.utils import get_deployments_target, set_deployments_target
    25	from mlflow.exceptions import MlflowException
    26	from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    27	
    28	with contextlib.suppress(Exception):
    29	    # MlflowDeploymentClient depends on optional dependencies and can't be imported
    30	    # if they are not installed.
    31	    from mlflow.deployments.mlflow import MlflowDeploymentClient
    32	
    33	
    34	class PredictionsResponse(dict):
    35	    """
    36	    Represents the predictions and metadata returned in response to a scoring request, such as a
    37	    REST API request sent to the ``/invocations`` endpoint of an MLflow Model Server.
    38	    """
    39	
    40	    def get_predictions(self, predictions_format="dataframe", dtype=None):
    41	        """Get the predictions returned from the MLflow Model Server in the specified format.
    42	
    43	        Args:
    44	            predictions_format: The format in which to return the predictions. Either
    45	                ``"dataframe"`` or ``"ndarray"``.
    46	            dtype: The NumPy datatype to which to coerce the predictions. Only used when
    47	                the "ndarray" predictions_format is specified.
    48	
    49	        Raises:
    50	            Exception: If the predictions cannot be represented in the specified format.
    51	
    52	        Returns:
    53	            The predictions, represented in the specified format.
    54	
    55	        """
    56	        import numpy as np
    57	        import pandas as pd
    58	        from pandas.core.dtypes.common import is_list_like
    59	
    60	        if predictions_format == "dataframe":
    61	            predictions = self["predictions"]
    62	            if isinstance(predictions, str):
    63	                return pd.DataFrame(data=[predictions])
    64	            if isinstance(predictions, dict) and not any(
    65	                is_list_like(p) and getattr(p, "ndim", 1) == 1 for p in predictions.values()
    66	            ):
    67	                return pd.DataFrame(data=predictions, index=[0])
    68	            return pd.DataFrame(data=predictions)
    69	        elif predictions_format == "ndarray":
    70	            return np.array(self["predictions"], dtype)
    71	        else:
    72	            raise MlflowException(
    73	                f"Unrecognized predictions format: '{predictions_format}'",
    74	                INVALID_PARAMETER_VALUE,
    75	            )
    76	
    77	    def to_json(self, path=None):
    78	        """Get the JSON representation of the MLflow Predictions Response.
    79	
    80	        Args:
    81	            path: If specified, the JSON representation is written to this file path.
    82	
    83	        Returns:
    84	            If ``path`` is unspecified, the JSON representation of the MLflow Predictions
    85	            Response. Else, None.
    86	
    87	        """
    88	        if path is not None:
    89	            with open(path, "w") as f:
    90	                json.dump(dict(self), f)
    91	        else:
    92	            return json.dumps(dict(self))
    93	
    94	    @classmethod
    95	    def from_json(cls, json_str):
    96	        try:
    97	            parsed_response = json.loads(json_str)
    98	        except Exception as e:
    99	            raise MlflowException("Predictions response contents are not valid JSON") from e
   100	        if not isinstance(parsed_response, dict) or "predictions" not in parsed_response:
   101	            raise MlflowException(
   102	                f"Invalid response. Predictions response contents must be a dictionary"
   103	                f" containing a 'predictions' field. Instead, received: {parsed_response}"
   104	            )
   105	        return PredictionsResponse(parsed_response)
   106	
   107	
   108	__all__ = [
   109	    "get_deploy_client",
   110	    "run_local",
   111	    "BaseDeploymentClient",
   112	    "DatabricksDeploymentClient",
   113	    "OpenAIDeploymentClient",
   114	    "DatabricksEndpoint",
   115	    "MlflowDeploymentClient",
   116	    "PredictionsResponse",
   117	    "get_deployments_target",
   118	    "set_deployments_target",
   119	]
     1	import urllib
     2	from urllib.parse import urlparse
     3	
     4	from mlflow.environment_variables import MLFLOW_DEPLOYMENTS_TARGET
     5	from mlflow.exceptions import MlflowException
     6	from mlflow.utils.uri import append_to_uri_path
     7	
     8	_deployments_target: str | None = None
     9	
    10	
    11	
    12	
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	def _is_valid_uri(uri: str) -> bool:
    26	    """
    27	    Evaluates the basic structure of a provided uri to determine if the scheme and
    28	    netloc are provided
    29	    """
    30	    try:
    31	        parsed = urlparse(uri)
    32	        return bool(parsed.scheme and parsed.netloc)
    33	    except ValueError:
    34	        return False
    35	
    36	
    37	def resolve_endpoint_url(base_url: str, endpoint: str) -> str:
    38	    """Performs a validation on whether the returned value is a fully qualified url
    39	    or requires the assembly of a fully qualified url by appending `endpoint`.
    40	
    41	    Args:
    42	        base_url: The base URL. Should include the scheme and domain, e.g.,
    43	            ``http://127.0.0.1:6000``.
    44	        endpoint: The endpoint to be appended to the base URL, e.g., ``/api/2.0/endpoints/`` or,
    45	            in the case of Databricks, the fully qualified url.
    46	
    47	    Returns:
    48	        The complete URL, either directly returned or formed and returned by joining the
    49	        base URL and the endpoint path.
    50	
    51	    """
    52	    return endpoint if _is_valid_uri(endpoint) else append_to_uri_path(base_url, endpoint)
    53	
    54	
    55	def set_deployments_target(target: str):
    56	    """Sets the target deployment client for MLflow deployments
    57	
    58	    Args:
    59	        target: The full uri of a running MLflow AI Gateway or, if running on
    60	            Databricks, "databricks".
    61	    """
    62	    if not _is_valid_target(target):
    63	        raise MlflowException.invalid_parameter_value(
    64	            "The target provided is not a valid uri or 'databricks'"
    65	        )
    66	
    67	    global _deployments_target
    68	    _deployments_target = target
    69	
    70	
    71	def get_deployments_target() -> str:
    72	    """
    73	    Returns the currently set MLflow deployments target iff set.
    74	    If the deployments target has not been set by using ``set_deployments_target``, an
    75	    ``MlflowException`` is raised.
    76	    """
    77	    if _deployments_target is not None:
    78	        return _deployments_target
    79	    elif uri := MLFLOW_DEPLOYMENTS_TARGET.get():
    80	        return uri
    81	    else:
    82	        raise MlflowException(
    83	            "No deployments target has been set. Please either set the MLflow deployments target"
    84	            " via `mlflow.deployments.set_deployments_target()` or set the environment variable "
    85	            f"{MLFLOW_DEPLOYMENTS_TARGET} to the running deployment server's uri"
    86	        )
    87	
    88	
    89	def _is_valid_target(target: str):
    90	    """
    91	    Evaluates the basic structure of a provided target to determine if the scheme and
    92	    netloc are provided
    93	    """
    94	    if target == "databricks":
    95	        return True
    96	    return _is_valid_uri(target)
     1	import abc
     2	import importlib.metadata
     3	import inspect
     4	
     5	import importlib_metadata
     6	
     7	from mlflow.deployments.base import BaseDeploymentClient
     8	
     9	from mlflow.exceptions import MlflowException
    10	from mlflow.protos.databricks_pb2 import INTERNAL_ERROR, RESOURCE_DOES_NOT_EXIST
    11	from mlflow.utils.annotations import developer_stable
    12	from mlflow.utils.plugins import get_entry_points
    13	
    14	# TODO: refactor to have a common base class for all the plugin implementation in MLflow
    15	#   mlflow/tracking/context/registry.py
    16	#   mlflow/tracking/registry
    17	#   mlflow/store/artifact/artifact_repository_registry.py
    18	
    19	
    20	@developer_stable
    21	class PluginManager(abc.ABC):
    22	    """
    23	    Abstract class defining a entrypoint based plugin registration.
    24	
    25	    This class allows the registration of a function or class to provide an implementation
    26	    for a given key/name. Implementations declared though the entrypoints can be automatically
    27	    registered through the `register_entrypoints` method.
    28	    """
    29	
    30	    def __init__(self, group_name):
    31	        self._registry = {}
    32	        self.group_name = group_name
    33	        self._has_registered = None
    34	
    35	    @abc.abstractmethod
    36	    def __getitem__(self, item):
    37	        # Letting the child class create this function so that the child
    38	        # can raise custom exceptions if it needs to
    39	        pass
    40	
    41	    @property
    42	    def registry(self):
    43	        """
    44	        Registry stores the registered plugin as a key value pair where key is the
    45	        name of the plugin and value is the plugin object
    46	        """
    47	        return self._registry
    48	
    49	    @property
    50	    def has_registered(self):
    51	        """
    52	        Returns bool representing whether the "register_entrypoints" has run or not. This
    53	        doesn't return True if `register` method is called outside of `register_entrypoints`
    54	        to register plugins
    55	        """
    56	        return self._has_registered
    57	
    58	    def register(self, target_name, plugin_module):
    59	        """Register a deployment client given its target name and module
    60	        Args:
    61	            target_name: The name of the deployment target. This name will be used by
    62	                `get_deploy_client()` to retrieve a deployment client from
    63	                the plugin store.
    64	            plugin_module: The module that implements the deployment plugin interface.
    65	        """
    66	        self.registry[target_name] = importlib.metadata.EntryPoint(
    67	            target_name, plugin_module, self.group_name
    68	        )
    69	
    70	    def register_entrypoints(self):
    71	        """
    72	        Runs through all the packages that has the `group_name` defined as the entrypoint
    73	        and register that into the registry
    74	        """
    75	        for entrypoint in get_entry_points(self.group_name):
    76	            self.registry[entrypoint.name] = entrypoint
    77	        self._has_registered = True
    78	
    79	
    80	@developer_stable
    81	class DeploymentPlugins(PluginManager):
    82	    def __init__(self):
    83	        super().__init__("mlflow.deployments")
    84	        self.register_entrypoints()
    85	
    86	    def __getitem__(self, item):
    87	        """Override __getitem__ so that we can directly look up plugins via dict-like syntax"""
    88	        try:
    89	            target_name = parse_target_uri(item)
    90	            plugin_like = self.registry[target_name]
    91	        except KeyError:
    92	            msg = (
    93	                f'No plugin found for managing model deployments to "{item}". '
    94	                f'In order to deploy models to "{item}", find and install an appropriate '
    95	                "plugin from "
    96	                "https://mlflow.org/docs/latest/plugins.html#community-plugins using "
    97	                "your package manager (pip, conda etc)."
    98	            )
    99	            raise MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)
   100	
   101	        if isinstance(plugin_like, (importlib_metadata.EntryPoint, importlib.metadata.EntryPoint)):
   102	            try:
   103	                plugin_obj = plugin_like.load()
   104	            except (AttributeError, ImportError) as exc:
   105	                raise RuntimeError(f'Failed to load the plugin "{item}": {exc}')
   106	            self.registry[item] = plugin_obj
   107	        else:
   108	            plugin_obj = plugin_like
   109	
   110	        # Testing whether the plugin is valid or not
   111	        expected = {"target_help", "run_local"}
   112	        deployment_classes = []
   113	        for name, obj in inspect.getmembers(plugin_obj):
   114	            if name in expected:
   115	                expected.remove(name)
   116	            elif (
   117	                inspect.isclass(obj)
   118	                and issubclass(obj, BaseDeploymentClient)
   119	                and not obj == BaseDeploymentClient
   120	            ):
   121	                deployment_classes.append(name)
   122	        if len(expected) > 0:
   123	            raise MlflowException(
   124	                f"Plugin registered for the target {item} does not have all "
   125	                "the required interfaces. Raise an issue with the "
   126	                "plugin developers.\n"
   127	                f"Missing interfaces: {expected}",
   128	                error_code=INTERNAL_ERROR,
   129	            )
   130	        if len(deployment_classes) > 1:
   131	            raise MlflowException(
   132	                f"Plugin registered for the target {item} has more than one "
   133	                "child class of BaseDeploymentClient. Raise an issue with"
   134	                " the plugin developers. "
   135	                f"Classes found are {deployment_classes}"
   136	            )
   137	        elif len(deployment_classes) == 0:
   138	            raise MlflowException(
   139	                f"Plugin registered for the target {item} has no child class"
   140	                " of BaseDeploymentClient. Raise an issue with the "
   141	                "plugin developers"
   142	            )
   143	        return plugin_obj
```

## 原始行 30 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^def test_'"' tests/utils/test_rest_utils.py
grep -R -n \"http_request(\" tests --include='*.py' | head -200"
```

退出码：`0`

输出：
```
47:def test_malformed_json_error_response(response_mock):
58:def test_call_endpoints():
77:def test_call_endpoints_raises_exceptions():
93:def test_http_request_hostonly():
109:def test_http_request_cleans_hostname():
126:def test_http_request_with_basic_auth():
144:def test_http_request_with_aws_sigv4(monkeypatch):
173:def test_http_request_with_auth():
200:def test_http_request_with_token():
218:def test_http_request_with_insecure():
234:def test_http_request_client_cert_path():
251:def test_http_request_server_cert_path():
267:def test_http_request_with_content_type_header():
287:def test_http_request_request_headers():
313:def test_http_request_request_headers_default():
350:def test_http_request_request_headers_default_and_extra_header():
392:def test_http_request_with_invalid_url_raise_invalid_url_exception():
401:def test_http_request_with_invalid_url_raise_mlflow_exception():
410:def test_ignore_tls_verification_not_server_cert_path():
422:def test_http_request_wrapper():
458:def test_numpy_encoder():
465:def test_numpy_encoder_fail():
474:def test_can_parse_as_json_object():
483:def test_http_request_customize_config(monkeypatch):
528:def test_http_request_explains_how_to_increase_timeout_in_error_message():
540:def test_augmented_raise_for_status():
557:def test_provide_redirect_kwarg():
580:def test_http_request_max_retries(monkeypatch):
592:def test_http_request_backoff_factor(monkeypatch):
604:def test_http_request_negative_max_retries():
613:def test_http_request_negative_backoff_factor():
622:def test_suppress_databricks_retry_after_secs_warnings():
645:def test_databricks_sdk_retry_on_transient_errors():
685:def test_databricks_sdk_retry_max_retries_exceeded():
717:def test_databricks_sdk_retry_timeout_exceeded():
757:def test_databricks_sdk_retry_non_retryable_error():
782:def test_databricks_sdk_retry_backoff_calculation():
819:def test_timeout_parameter_propagation_with_timeout():
847:def test_timeout_parameter_propagation_without_timeout():
873:def test_deployment_client_timeout_propagation(monkeypatch):
913:def test_http_request_with_databricks_traffic_id(monkeypatch: pytest.MonkeyPatch):
943:def test_validate_deployment_timeout_config(timeout, retry_timeout_seconds, should_warn):
tests/utils/test_rest_utils.py:98:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:115:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:131:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:161:        http_request(aws_sigv4, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:185:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:205:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:223:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:239:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:256:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:273:        http_request(host_only, "/my/endpoint", "GET", extra_headers=extra_headers)
tests/utils/test_rest_utils.py:302:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:339:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:381:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:398:            http_request(host_only, "/invalid_url", "GET")
tests/utils/test_rest_utils.py:407:            http_request(host_only, "/invalid_url", "GET")
tests/utils/test_rest_utils.py:492:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:512:        http_request(host_only, "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:537:            http_request(MlflowHostCreds("http://my-host"), "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:562:        response = http_request(
tests/utils/test_rest_utils.py:586:            http_request(host_creds, "/endpoint", "GET", max_retries=16)
tests/utils/test_rest_utils.py:588:        http_request(host_creds, "/endpoint", "GET", max_retries=3)
tests/utils/test_rest_utils.py:598:            http_request(host_creds, "/endpoint", "GET", backoff_factor=250)
tests/utils/test_rest_utils.py:600:        http_request(host_creds, "/endpoint", "GET", backoff_factor=10)
tests/utils/test_rest_utils.py:609:            http_request(host_creds, "/endpoint", "GET", max_retries=-1)
tests/utils/test_rest_utils.py:618:            http_request(host_creds, "/endpoint", "GET", backoff_factor=-1)
tests/utils/test_rest_utils.py:637:        http_request(host_creds, "/endpoint", "GET")
tests/utils/test_rest_utils.py:673:        response = http_request(
tests/utils/test_rest_utils.py:706:        response = http_request(host_creds, "/endpoint", "GET", max_retries=3)
tests/utils/test_rest_utils.py:740:        response = http_request(
tests/utils/test_rest_utils.py:776:        response = http_request(host_creds, "/endpoint", "GET", max_retries=5)
tests/utils/test_rest_utils.py:920:        http_request(MlflowHostCreds("http://my-host"), "/my/endpoint", "GET")
tests/utils/test_rest_utils.py:927:        http_request(MlflowHostCreds("http://my-host"), "/my/endpoint", "GET")
tests/utils/test_request_utils.py:71:        response = request_utils.cloud_storage_http_request("GET", "http://localhost:5000")
tests/utils/test_request_utils.py:90:        response = request_utils.cloud_storage_http_request(
tests/utils/test_request_utils.py:112:        response = request_utils.cloud_storage_http_request(
tests/utils/test_request_utils.py:133:        response = request_utils.cloud_storage_http_request(
tests/utils/test_request_utils.py:151:        response = request_utils.cloud_storage_http_request(
tests/data/test_http_dataset_source.py:93:        return cloud_storage_http_request(*args, **kwargs)
tests/data/test_http_dataset_source.py:117:        response = cloud_storage_http_request(*args, **kwargs)
tests/data/test_http_dataset_source.py:148:        response = cloud_storage_http_request(*args, **kwargs)
tests/data/test_http_dataset_source.py:174:        response = cloud_storage_http_request(*args, **kwargs)
tests/store/artifact/test_dbfs_rest_artifact_repo.py:125:        def my_http_request(host_creds, **kwargs):
tests/store/artifact/test_dbfs_rest_artifact_repo.py:128:            return http_request(host_creds, **kwargs)
tests/store/artifact/test_dbfs_rest_artifact_repo.py:147:        def my_http_request(host_creds, **kwargs):
tests/store/artifact/test_dbfs_rest_artifact_repo.py:150:            return http_request(host_creds, **kwargs)
tests/store/artifact/test_dbfs_rest_artifact_repo.py:167:        def my_http_request(host_creds, **kwargs):
tests/store/artifact/test_dbfs_rest_artifact_repo.py:170:            return http_request(host_creds, **kwargs)
tests/store/artifact/test_dbfs_rest_artifact_repo.py:205:        def my_http_request(host_creds, **kwargs):
tests/store/artifact/test_dbfs_rest_artifact_repo.py:211:            return http_request(host_creds, **kwargs)
tests/store/artifact/test_dbfs_rest_artifact_repo.py:275:        def my_http_request(host_creds, **kwargs):
tests/store/artifact/test_dbfs_rest_artifact_repo.py:277:            return http_request(host_creds, **kwargs)
tests/store/artifact/test_mlflow_artifact_repo.py:296:    def http_request(_host_creds, endpoint, _method, **kwargs):
tests/store/artifact/test_http_artifact_repo.py:309:    def http_request(_host_creds, endpoint, _method, **kwargs):
tests/store/tracking/test_databricks_rest_store.py:697:    def mock_http_request(*args, **kwargs):
tests/store/tracking/test_rest_store.py:123:def mock_http_request():
tests/store/tracking/test_rest_store.py:130:def test_successful_http_request():
tests/store/tracking/test_rest_store.py:153:def test_failed_http_request():
tests/store/tracking/test_rest_store.py:247:        mock_http_request() as mock_http,
tests/store/tracking/test_rest_store.py:284:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:291:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:298:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:305:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:310:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:317:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:334:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:342:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:348:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:354:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:364:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:399:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:409:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:432:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:501:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:1608:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:2037:    with mock_http_request() as mock_http:
tests/store/tracking/test_rest_store.py:2056:    with mock_http_request() as mock_http:
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/utils/rest_utils.py | sed -n '1,260p'"
```

退出码：`0`

输出：
```
     1	import base64
     2	import json
     3	import logging
     4	import random
     5	import time
     6	import warnings
     7	from functools import lru_cache
     8	from typing import Any, Callable
     9	
    10	import requests
    11	
    12	from mlflow.environment_variables import (
    13	    _MLFLOW_DATABRICKS_TRAFFIC_ID,
    14	    _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT,
    15	    _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT,
    16	    MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT,
    17	    MLFLOW_ENABLE_DB_SDK,
    18	    MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR,
    19	    MLFLOW_HTTP_REQUEST_BACKOFF_JITTER,
    20	    MLFLOW_HTTP_REQUEST_MAX_RETRIES,
    21	    MLFLOW_HTTP_REQUEST_TIMEOUT,
    22	    MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER,
    23	)
    24	from mlflow.exceptions import (
    25	    CUSTOMER_UNAUTHORIZED,
    26	    ERROR_CODE_TO_HTTP_STATUS,
    27	    INVALID_PARAMETER_VALUE,
    28	    InvalidUrlException,
    29	    MlflowException,
    30	    RestException,
    31	    get_error_code,
    32	)
    33	from mlflow.protos import databricks_pb2
    34	from mlflow.protos.databricks_pb2 import ENDPOINT_NOT_FOUND, ErrorCode
    35	from mlflow.utils.proto_json_utils import parse_dict
    36	from mlflow.utils.request_utils import _TRANSIENT_FAILURE_RESPONSE_CODES, augmented_raise_for_status, cloud_storage_http_request
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	_logger = logging.getLogger(__name__)
    45	
    46	RESOURCE_NON_EXISTENT = "RESOURCE_DOES_NOT_EXIST"
    47	_REST_API_PATH_PREFIX = "/api/2.0"
    48	_UC_OSS_REST_API_PATH_PREFIX = "/api/2.1"
    49	_TRACE_REST_API_PATH_PREFIX = f"{_REST_API_PATH_PREFIX}/mlflow/traces"
    50	_V3_REST_API_PATH_PREFIX = "/api/3.0"
    51	_V3_TRACE_REST_API_PATH_PREFIX = f"{_V3_REST_API_PATH_PREFIX}/mlflow/traces"
    52	_V4_REST_API_PATH_PREFIX = "/api/4.0"
    53	_V4_TRACE_REST_API_PATH_PREFIX = f"{_V4_REST_API_PATH_PREFIX}/mlflow/traces"
    54	_ARMERIA_OK = "200 OK"
    55	_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING = (
    56	    "The 'retry_after_secs' parameter of DatabricksError is deprecated"
    57	)
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	
   210	
   211	
   212	
   213	
   214	
   215	
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260
```

## 原始行 35 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/utils/rest_utils.py | sed -n '260,500p'"
```

退出码：`0`

输出：
```
   260	
   261	
   262	@lru_cache(maxsize=5)
   263	def get_workspace_client(
   264	    use_secret_scope_token,
   265	    host,
   266	    token,
   267	    databricks_auth_profile,
   268	    retry_timeout_seconds=None,
   269	    timeout=None,
   270	):
   271	    from databricks.sdk import WorkspaceClient
   272	    from databricks.sdk.config import Config
   273	
   274	    if use_secret_scope_token:
   275	        kwargs = {"host": host, "token": token}
   276	    else:
   277	        kwargs = {"profile": databricks_auth_profile}
   278	    if timeout is not None:
   279	        kwargs["http_timeout_seconds"] = timeout
   280	    config = Config(
   281	        **kwargs,
   282	        retry_timeout_seconds=retry_timeout_seconds
   283	        or MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get(),
   284	    )
   285	    # Note: If we use `config` param, all SDK configurations must be set in `config` object.
   286	    return WorkspaceClient(config=config)
   287	
   288	
   289	def _can_parse_as_json_object(string):
   290	    try:
   291	        return isinstance(json.loads(string), dict)
   292	    except Exception:
   293	        return False
   294	
   295	
   296	def http_request_safe(host_creds, endpoint, method, **kwargs):
   297	    """
   298	    Wrapper around ``http_request`` that also verifies that the request succeeds with code 200.
   299	    """
   300	    response = http_request(host_creds=host_creds, endpoint=endpoint, method=method, **kwargs)
   301	    return verify_rest_response(response, endpoint)
   302	
   303	
   304	def verify_rest_response(response, endpoint):
   305	    """Verify the return code and format, raise exception if the request was not successful."""
   306	    # Handle Armeria-specific response case where response text is "200 OK"
   307	    # v1/traces endpoint might return empty response
   308	    if response.status_code == 200 and response.text.strip() in (_ARMERIA_OK, ""):
   309	        response._content = b"{}"  # Update response content to be an empty JSON dictionary
   310	        return response
   311	
   312	    # Handle non-200 status codes
   313	    if response.status_code != 200:
   314	        if _can_parse_as_json_object(response.text):
   315	            raise RestException(json.loads(response.text))
   316	        else:
   317	            base_msg = (
   318	                f"API request to endpoint {endpoint} "
   319	                f"failed with error code {response.status_code} != 200"
   320	            )
   321	            raise MlflowException(
   322	                f"{base_msg}. Response body: '{response.text}'",
   323	                error_code=get_error_code(response.status_code),
   324	            )
   325	
   326	    # Skip validation for endpoints (e.g. DBFS file-download API) which may return a non-JSON
   327	    # response
   328	    if endpoint.startswith(_REST_API_PATH_PREFIX) and not _can_parse_as_json_object(response.text):
   329	        base_msg = (
   330	            "API request to endpoint was successful but the response body was not "
   331	            "in a valid JSON format"
   332	        )
   333	        raise MlflowException(f"{base_msg}. Response body: '{response.text}'")
   334	
   335	    return response
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	def validate_deployment_timeout_config(timeout: int | None, retry_timeout_seconds: int | None):
   388	    """
   389	    Validate that total retry timeout is not less than single request timeout.
   390	
   391	    Args:
   392	        timeout: Maximum time for a single HTTP request (in seconds)
   393	        retry_timeout_seconds: Maximum time for all retry attempts combined (in seconds)
   394	    """
   395	    if timeout is not None and retry_timeout_seconds is not None:
   396	        if retry_timeout_seconds < timeout:
   397	            warnings.warn(
   398	                f"MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT ({retry_timeout_seconds}s) is set "
   399	                f"lower than MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT ({timeout}s). This means the "
   400	                "total retry timeout could expire before a single request completes, causing "
   401	                "premature failures. For long-running predictions, ensure "
   402	                "MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT >= MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT. "
   403	                f"Recommended: Set MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT to at least {timeout}s.",
   404	                stacklevel=2,
   405	            )
   406	
   407	
   408	def _time_sleep(seconds: float) -> None:
   409	    """
   410	    This function is specifically mocked in `test_rest_utils.py` to test the backoff logic in
   411	    isolation. We avoid wrapping `time.sleep` globally to prevent interfering with unrelated sleep
   412	    calls elsewhere in the codebase or in third-party libraries.
   413	    """
   414	    time.sleep(seconds)
   415	
   416	
   417	def _retry_databricks_sdk_call_with_exponential_backoff(
   418	    *,
   419	    call_func: Callable[..., Any],
   420	    retry_codes: list[int],
   421	    retry_timeout_seconds: int,
   422	    backoff_factor: int,
   423	    backoff_jitter: float,
   424	    max_retries: int,
   425	):
   426	    """
   427	    Retry a Databricks SDK call with exponential backoff until timeout or max retries reached.
   428	
   429	    Args:
   430	        call_func: Function to call that may raise DatabricksError
   431	        retry_codes: Set of HTTP status codes that should trigger retries
   432	        retry_timeout_seconds: Maximum time to spend retrying in seconds
   433	        backoff_factor: Factor for exponential backoff
   434	        backoff_jitter: Random jitter to add to backoff
   435	        max_retries: Maximum number of retry attempts
   436	
   437	    Returns:
   438	        The result of call_func() on success
   439	
   440	    Raises:
   441	        DatabricksError: If all retries are exhausted or non-retryable error occurs
   442	    """
   443	    from databricks.sdk.errors import STATUS_CODE_MAPPING, DatabricksError
   444	
   445	    start_time = time.time()
   446	    attempt = 0
   447	
   448	    while attempt <= max_retries:
   449	        try:
   450	            return call_func()
   451	        except DatabricksError as e:
   452	            # Get HTTP status code from the error
   453	            status_code = next(
   454	                (code for code, cls in STATUS_CODE_MAPPING.items() if isinstance(e, cls)), 500
   455	            )
   456	            # Check if this is a retryable error
   457	            if status_code not in retry_codes:
   458	                raise
   459	
   460	            # Check if we've exceeded max retries
   461	            if attempt >= max_retries:
   462	                _logger.warning(f"Max retries ({max_retries}) exceeded: {e}")
   463	                raise
   464	
   465	            # Calculate backoff time with exponential backoff and jitter
   466	            # NB: Ideally, we'd use urllib3.Retry to compute the jitter, check whether we've
   467	            # exceed max retries, etc. However, urllib3.Retry in urllib3 version 1.x, which MLflow
   468	            # maintains compatibility with, doesn't support retries with jitter
   469	            if attempt <= 0:
   470	                backoff_time = 0  # No backoff on first retry attempt
   471	            else:
   472	                backoff_time = backoff_factor * (2**attempt)
   473	                if backoff_jitter > 0:
   474	                    backoff_time += random.random() * backoff_jitter
   475	
   476	            # Check if we've exceeded or would exceed timeout
   477	            elapsed_time = time.time() - start_time
   478	            if elapsed_time + backoff_time >= retry_timeout_seconds:
   479	                _logger.warning(f"Retry timeout ({retry_timeout_seconds}s) exceeded: {e}")
   480	                raise
   481	
   482	            _logger.debug(
   483	                f"Databricks SDK call failed with retryable error (status {status_code}): {e}. "
   484	                f"Retrying in {backoff_time:.2f} seconds (attempt {attempt + 1})"
   485	            )
   486	
   487	            _time_sleep(backoff_time)
   488	            attempt += 1
   489	
   490	
   491	def _get_path(path_prefix, endpoint_path):
   492	    return f"{path_prefix}{endpoint_path}"
   493	
   494	
   495	def extract_api_info_for_service(service, path_prefix):
   496	    """Return a dictionary mapping each API method to a tuple (path, HTTP method)"""
   497	    service_methods = service.DESCRIPTOR.methods
   498	    res = {}
   499	    for service_method in service_methods:
   500	        endpoints = service_method.GetOptions().Extensions[databricks_pb2.rpc].endpoints
```

## 原始行 38 · command_execution

命令：
```
/bin/bash -lc "nl -ba tests/utils/test_rest_utils.py | sed -n '460,980p'"
```

退出码：`0`

输出：
```
   460	    ne = NumpyEncoder()
   461	    defaulted_val = ne.default(test_number)
   462	    assert defaulted_val == 42
   463	
   464	
   465	def test_numpy_encoder_fail():
   466	    if not hasattr(numpy, "float128"):
   467	        pytest.skip("numpy on exit this platform has no float128")
   468	    test_number = numpy.float128
   469	    ne = NumpyEncoder()
   470	    with pytest.raises(TypeError, match="not JSON serializable"):
   471	        ne.default(test_number)
   472	
   473	
   474	def test_can_parse_as_json_object():
   475	    assert _can_parse_as_json_object("{}")
   476	    assert _can_parse_as_json_object('{"a": "b"}')
   477	    assert _can_parse_as_json_object('{"a": {"b": "c"}}')
   478	    assert not _can_parse_as_json_object("[0, 1, 2]")
   479	    assert not _can_parse_as_json_object('"abc"')
   480	    assert not _can_parse_as_json_object("123")
   481	
   482	
   483	def test_http_request_customize_config(monkeypatch):
   484	    with mock.patch(
   485	        "mlflow.utils.rest_utils._get_http_response_with_retries"
   486	    ) as mock_get_http_response_with_retries:
   487	        host_only = MlflowHostCreds("http://my-host")
   488	        monkeypatch.delenv("MLFLOW_HTTP_REQUEST_MAX_RETRIES", raising=False)
   489	        monkeypatch.delenv("MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR", raising=False)
   490	        monkeypatch.delenv("MLFLOW_HTTP_REQUEST_TIMEOUT", raising=False)
   491	        monkeypatch.delenv("MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER", raising=False)
   492	        http_request(host_only, "/my/endpoint", "GET")
   493	        mock_get_http_response_with_retries.assert_called_with(
   494	            mock.ANY,
   495	            mock.ANY,
   496	            7,
   497	            2,
   498	            1.0,
   499	            mock.ANY,
   500	            True,
   501	            headers=mock.ANY,
   502	            verify=mock.ANY,
   503	            timeout=120,
   504	            respect_retry_after_header=True,
   505	        )
   506	        mock_get_http_response_with_retries.reset_mock()
   507	        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_MAX_RETRIES", "8")
   508	        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR", "3")
   509	        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_BACKOFF_JITTER", "1.0")
   510	        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_TIMEOUT", "300")
   511	        monkeypatch.setenv("MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER", "false")
   512	        http_request(host_only, "/my/endpoint", "GET")
   513	        mock_get_http_response_with_retries.assert_called_with(
   514	            mock.ANY,
   515	            mock.ANY,
   516	            8,
   517	            3,
   518	            1.0,
   519	            mock.ANY,
   520	            True,
   521	            headers=mock.ANY,
   522	            verify=mock.ANY,
   523	            timeout=300,
   524	            respect_retry_after_header=False,
   525	        )
   526	
   527	
   528	def test_http_request_explains_how_to_increase_timeout_in_error_message():
   529	    with mock.patch("requests.Session.request", side_effect=requests.exceptions.Timeout):
   530	        with pytest.raises(
   531	            MlflowException,
   532	            match=(
   533	                r"To increase the timeout, set the environment variable "
   534	                + re.escape(str(MLFLOW_HTTP_REQUEST_TIMEOUT))
   535	            ),
   536	        ):
   537	            http_request(MlflowHostCreds("http://my-host"), "/my/endpoint", "GET")
   538	
   539	
   540	def test_augmented_raise_for_status():
   541	    response = requests.Response()
   542	    response.status_code = 403
   543	    response._content = b"Token expired"
   544	
   545	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   546	        response = requests.get("https://github.com/mlflow/mlflow.git")
   547	        mock_request.assert_called_once()
   548	
   549	    with pytest.raises(requests.HTTPError, match="Token expired") as e:
   550	        augmented_raise_for_status(response)
   551	
   552	    assert e.value.response == response
   553	    assert e.value.request == response.request
   554	    assert response.text in str(e.value)
   555	
   556	
   557	def test_provide_redirect_kwarg():
   558	    with mock.patch("requests.Session.request") as mock_request:
   559	        mock_request.return_value.status_code = 302
   560	        mock_request.return_value.text = "mock response"
   561	
   562	        response = http_request(
   563	            MlflowHostCreds("http://my-host"),
   564	            "/my/endpoint",
   565	            "GET",
   566	            allow_redirects=False,
   567	        )
   568	
   569	        assert response.text == "mock response"
   570	        mock_request.assert_called_with(
   571	            "GET",
   572	            "http://my-host/my/endpoint",
   573	            allow_redirects=False,
   574	            headers=mock.ANY,
   575	            verify=mock.ANY,
   576	            timeout=120,
   577	        )
   578	
   579	
   580	def test_http_request_max_retries(monkeypatch):
   581	    monkeypatch.setenv("_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT", "15")
   582	    host_creds = MlflowHostCreds("http://example.com")
   583	
   584	    with mock.patch("requests.Session.request") as mock_request:
   585	        with pytest.raises(MlflowException, match="The configured max_retries"):
   586	            http_request(host_creds, "/endpoint", "GET", max_retries=16)
   587	        mock_request.assert_not_called()
   588	        http_request(host_creds, "/endpoint", "GET", max_retries=3)
   589	        mock_request.assert_called_once()
   590	
   591	
   592	def test_http_request_backoff_factor(monkeypatch):
   593	    monkeypatch.setenv("_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT", "200")
   594	    host_creds = MlflowHostCreds("http://example.com")
   595	
   596	    with mock.patch("requests.Session.request") as mock_request:
   597	        with pytest.raises(MlflowException, match="The configured backoff_factor"):
   598	            http_request(host_creds, "/endpoint", "GET", backoff_factor=250)
   599	        mock_request.assert_not_called()
   600	        http_request(host_creds, "/endpoint", "GET", backoff_factor=10)
   601	        mock_request.assert_called_once()
   602	
   603	
   604	def test_http_request_negative_max_retries():
   605	    host_creds = MlflowHostCreds("http://example.com")
   606	
   607	    with mock.patch("requests.Session.request") as mock_request:
   608	        with pytest.raises(MlflowException, match="The max_retries value must be either"):
   609	            http_request(host_creds, "/endpoint", "GET", max_retries=-1)
   610	        mock_request.assert_not_called()
   611	
   612	
   613	def test_http_request_negative_backoff_factor():
   614	    host_creds = MlflowHostCreds("http://example.com")
   615	
   616	    with mock.patch("requests.Session.request") as mock_request:
   617	        with pytest.raises(MlflowException, match="The backoff_factor value must be"):
   618	            http_request(host_creds, "/endpoint", "GET", backoff_factor=-1)
   619	        mock_request.assert_not_called()
   620	
   621	
   622	def test_suppress_databricks_retry_after_secs_warnings():
   623	    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)
   624	
   625	    def mock_do(*args, **kwargs):
   626	        warnings.warn(_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING)
   627	        return mock.MagicMock()
   628	
   629	    with (
   630	        warnings.catch_warnings(record=True) as recorded_warnings,
   631	        mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client,
   632	    ):
   633	        warnings.simplefilter("always")
   634	        mock_workspace_client = mock.MagicMock()
   635	        mock_workspace_client.api_client.do = mock_do
   636	        mock_get_workspace_client.return_value = mock_workspace_client
   637	        http_request(host_creds, "/endpoint", "GET")
   638	        mock_get_workspace_client.assert_called_once()
   639	        assert not any(
   640	            _DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING in str(w.message)
   641	            for w in recorded_warnings
   642	        )
   643	
   644	
   645	def test_databricks_sdk_retry_on_transient_errors():
   646	    """Test that Databricks SDK retries on transient HTTP errors."""
   647	    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)
   648	
   649	    call_count = 0
   650	
   651	    def mock_do_failing_then_success(*args, **kwargs):
   652	        nonlocal call_count
   653	        call_count += 1
   654	        if call_count <= 2:  # Fail first 2 attempts
   655	            from databricks.sdk.errors import DatabricksError
   656	
   657	            from mlflow.protos.databricks_pb2 import ErrorCode
   658	
   659	            raise DatabricksError(
   660	                error_code=ErrorCode.Name(ErrorCode.INTERNAL_ERROR), message="Transient error"
   661	            )
   662	        # Success on 3rd attempt
   663	        response_mock = mock.MagicMock()
   664	        response_mock._response = mock.MagicMock()
   665	        return {"contents": response_mock}
   666	
   667	    with mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client:
   668	        mock_workspace_client = mock.MagicMock()
   669	        mock_workspace_client.api_client.do = mock_do_failing_then_success
   670	        mock_get_workspace_client.return_value = mock_workspace_client
   671	
   672	        # Use smaller retry timeout to make test run faster
   673	        response = http_request(
   674	            host_creds,
   675	            "/endpoint",
   676	            "GET",
   677	            retry_timeout_seconds=10,
   678	            backoff_factor=0.1,  # Very small backoff for faster test
   679	        )
   680	
   681	        assert call_count == 3  # Should retry 2 times, succeed on 3rd
   682	        assert response is not None
   683	
   684	
   685	def test_databricks_sdk_retry_max_retries_exceeded():
   686	    """Test that Databricks SDK stops retrying when max_retries is exceeded."""
   687	    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)
   688	
   689	    call_count = 0
   690	
   691	    def mock_do_always_fail(*args, **kwargs):
   692	        nonlocal call_count
   693	        call_count += 1
   694	        from databricks.sdk.errors import DatabricksError
   695	
   696	        raise DatabricksError(error_code="INTERNAL_ERROR", message="Always fails")
   697	
   698	    with (
   699	        mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client,
   700	        mock.patch("mlflow.utils.rest_utils._logger") as mock_logger,
   701	    ):
   702	        mock_workspace_client = mock.MagicMock()
   703	        mock_workspace_client.api_client.do = mock_do_always_fail
   704	        mock_get_workspace_client.return_value = mock_workspace_client
   705	
   706	        response = http_request(host_creds, "/endpoint", "GET", max_retries=3)
   707	
   708	        assert call_count == 4  # Initial call + 3 retries
   709	        assert response.status_code == 500  # Should return error response
   710	
   711	        # Check that max retries warning was logged
   712	        mock_logger.warning.assert_called()
   713	        warning_call = mock_logger.warning.call_args[0][0]
   714	        assert "Max retries (3) exceeded" in warning_call
   715	
   716	
   717	def test_databricks_sdk_retry_timeout_exceeded():
   718	    """Test that Databricks SDK stops retrying when timeout is exceeded."""
   719	    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)
   720	
   721	    call_count = 0
   722	
   723	    def mock_do_always_fail(*args, **kwargs):
   724	        nonlocal call_count
   725	        call_count += 1
   726	
   727	        time.sleep(0.1)  # Small delay to ensure timeout
   728	        from databricks.sdk.errors import DatabricksError
   729	
   730	        raise DatabricksError(error_code="INTERNAL_ERROR", message="Always fails")
   731	
   732	    with (
   733	        mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client,
   734	        mock.patch("mlflow.utils.rest_utils._logger") as mock_logger,
   735	    ):
   736	        mock_workspace_client = mock.MagicMock()
   737	        mock_workspace_client.api_client.do = mock_do_always_fail
   738	        mock_get_workspace_client.return_value = mock_workspace_client
   739	
   740	        response = http_request(
   741	            host_creds,
   742	            "/endpoint",
   743	            "GET",
   744	            retry_timeout_seconds=0.2,  # Very short timeout
   745	            max_retries=10,  # High retry limit that shouldn't be reached
   746	        )
   747	
   748	        assert call_count >= 1  # At least initial call
   749	        assert response.status_code == 500  # Should return error response
   750	
   751	        # Check that timeout warning was logged
   752	        mock_logger.warning.assert_called()
   753	        warning_call = mock_logger.warning.call_args[0][0]
   754	        assert "Retry timeout (0.2s) exceeded" in warning_call
   755	
   756	
   757	def test_databricks_sdk_retry_non_retryable_error():
   758	    """Test that Databricks SDK doesn't retry on non-retryable errors."""
   759	    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)
   760	
   761	    call_count = 0
   762	
   763	    def mock_do_non_retryable_error(*args, **kwargs):
   764	        nonlocal call_count
   765	        call_count += 1
   766	        from databricks.sdk.errors import InvalidParameterValue
   767	
   768	        # Use an error code that maps to 400 (non-retryable)
   769	        raise InvalidParameterValue(error_code="INVALID_PARAMETER_VALUE", message="Bad request")
   770	
   771	    with mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client:
   772	        mock_workspace_client = mock.MagicMock()
   773	        mock_workspace_client.api_client.do = mock_do_non_retryable_error
   774	        mock_get_workspace_client.return_value = mock_workspace_client
   775	
   776	        response = http_request(host_creds, "/endpoint", "GET", max_retries=5)
   777	
   778	        assert call_count == 1  # Should not retry on non-retryable error
   779	        assert response.status_code == 400  # Should return 400 for INVALID_PARAMETER_VALUE
   780	
   781	
   782	def test_databricks_sdk_retry_backoff_calculation():
   783	    """Test that Databricks SDK uses correct exponential backoff timing."""
   784	    from databricks.sdk.errors import DatabricksError
   785	
   786	    from mlflow.utils.request_utils import _TRANSIENT_FAILURE_RESPONSE_CODES
   787	    from mlflow.utils.rest_utils import _retry_databricks_sdk_call_with_exponential_backoff
   788	
   789	    call_count = 0
   790	
   791	    def mock_failing_call():
   792	        nonlocal call_count
   793	        call_count += 1
   794	
   795	        raise DatabricksError(error_code="INTERNAL_ERROR", message="Mock error")
   796	
   797	    with mock.patch("mlflow.utils.rest_utils._time_sleep") as mock_sleep:
   798	        with pytest.raises(DatabricksError, match="Mock error"):
   799	            _retry_databricks_sdk_call_with_exponential_backoff(
   800	                call_func=mock_failing_call,
   801	                retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,
   802	                retry_timeout_seconds=10,
   803	                backoff_factor=1,  # Use 1 for predictable calculation
   804	                backoff_jitter=0,  # No jitter for predictable calculation
   805	                max_retries=3,
   806	            )
   807	
   808	    # Verify sleep was called with correct intervals
   809	    # attempt 0 (1st retry): 0 seconds (immediate)
   810	    # attempt 1 (2nd retry): 1 * (2^1) = 2 seconds
   811	    # attempt 2 (3rd retry): 1 * (2^2) = 4 seconds
   812	    expected_sleep_times = [0, 2, 4]
   813	    actual_sleep_times = [call.args[0] for call in mock_sleep.call_args_list]
   814	    assert actual_sleep_times == expected_sleep_times
   815	    assert call_count == 4  # Initial + 3 retries
   816	
   817	
   818	@pytest.mark.skip
   819	def test_timeout_parameter_propagation_with_timeout():
   820	    """Test timeout parameter propagation from http_request to get_workspace_client with timeout."""
   821	    with (
   822	        mock.patch("databricks.sdk.WorkspaceClient") as mock_workspace_client,
   823	        mock.patch("databricks.sdk.config.Config") as mock_config,
   824	    ):
   825	        # Test http_request with timeout via get_workspace_client directly
   826	        mock_workspace_client_instance = mock.MagicMock()
   827	        mock_workspace_client_instance.api_client.do.return_value = {"contents": mock.MagicMock()}
   828	        mock_workspace_client.return_value = mock_workspace_client_instance
   829	
   830	        get_workspace_client(
   831	            use_secret_scope_token=False,
   832	            host="http://my-host",
   833	            token=None,
   834	            databricks_auth_profile="my-profile",
   835	            retry_timeout_seconds=None,
   836	            timeout=180,
   837	        )
   838	
   839	        mock_config.assert_called_once_with(
   840	            profile="my-profile",
   841	            http_timeout_seconds=180,
   842	            retry_timeout_seconds=mock.ANY,
   843	        )
   844	
   845	
   846	@pytest.mark.skip
   847	def test_timeout_parameter_propagation_without_timeout():
   848	    """Test timeout param propagation from http_request to get_workspace_client without timeout."""
   849	    with (
   850	        mock.patch("databricks.sdk.WorkspaceClient") as mock_workspace_client,
   851	        mock.patch("databricks.sdk.config.Config") as mock_config,
   852	    ):
   853	        # Test http_request without timeout via get_workspace_client directly
   854	        mock_workspace_client_instance = mock.MagicMock()
   855	        mock_workspace_client_instance.api_client.do.return_value = {"contents": mock.MagicMock()}
   856	        mock_workspace_client.return_value = mock_workspace_client_instance
   857	
   858	        get_workspace_client(
   859	            use_secret_scope_token=False,
   860	            host="http://my-host",
   861	            token=None,
   862	            databricks_auth_profile="my-profile",
   863	            retry_timeout_seconds=None,
   864	            timeout=None,
   865	        )
   866	
   867	        mock_config.assert_called_once_with(
   868	            profile="my-profile",
   869	            retry_timeout_seconds=mock.ANY,
   870	        )
   871	
   872	
   873	def test_deployment_client_timeout_propagation(monkeypatch):
   874	    """Test deployment client propagates timeout to workspace client."""
   875	
   876	    with (
   877	        mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client,
   878	        mock.patch(
   879	            "mlflow.utils.databricks_utils.get_databricks_host_creds"
   880	        ) as mock_get_databricks_host_creds,
   881	        mock.patch(
   882	            "mlflow.deployments.databricks.get_databricks_host_creds"
   883	        ) as mock_deployment_host_creds,
   884	    ):
   885	        # Mock the host creds to use Databricks SDK
   886	        mock_host_creds = MlflowHostCreds("http://my-host", use_databricks_sdk=True)
   887	        mock_get_databricks_host_creds.return_value = mock_host_creds
   888	        mock_deployment_host_creds.return_value = mock_host_creds
   889	
   890	        # Mock workspace client and its response
   891	        mock_workspace_client_instance = mock.MagicMock()
   892	        mock_workspace_client_instance.api_client.do.return_value = {"contents": mock.MagicMock()}
   893	        mock_get_workspace_client.return_value = mock_workspace_client_instance
   894	
   895	        # Set the environment variable to a custom value using monkeypatch
   896	        monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT", "300")
   897	
   898	        # Create deployment client and call predict
   899	        client = DatabricksDeploymentClient("databricks")
   900	        client.predict(endpoint="test-endpoint", inputs={"test": "data"})
   901	
   902	        # Verify get_workspace_client was called with the deployment predict timeout
   903	        mock_get_workspace_client.assert_called_once_with(
   904	            False,  # use_secret_scope_token
   905	            "http://my-host",  # host
   906	            None,  # token
   907	            None,  # databricks_auth_profile
   908	            retry_timeout_seconds=600,
   909	            timeout=300,  # MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT value
   910	        )
   911	
   912	
   913	def test_http_request_with_databricks_traffic_id(monkeypatch: pytest.MonkeyPatch):
   914	    response = mock.MagicMock()
   915	    response.status_code = 200
   916	
   917	    # Test with env var set
   918	    monkeypatch.setenv(_MLFLOW_DATABRICKS_TRAFFIC_ID.name, "test-traffic-id-12345")
   919	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   920	        http_request(MlflowHostCreds("http://my-host"), "/my/endpoint", "GET")
   921	        headers = mock_request.call_args.kwargs["headers"]
   922	        assert headers["x-databricks-traffic-id"] == "test-traffic-id-12345"
   923	
   924	    # Test without env var set
   925	    monkeypatch.delenv(_MLFLOW_DATABRICKS_TRAFFIC_ID.name)
   926	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   927	        http_request(MlflowHostCreds("http://my-host"), "/my/endpoint", "GET")
   928	        headers = mock_request.call_args.kwargs["headers"]
   929	        assert "x-databricks-traffic-id" not in headers
   930	
   931	
   932	@pytest.mark.parametrize(
   933	    ("timeout", "retry_timeout_seconds", "should_warn"),
   934	    [
   935	        (300, 120, True),
   936	        (120, 600, False),
   937	        (300, 300, False),
   938	        (None, 120, False),
   939	        (300, None, False),
   940	        (None, None, False),
   941	    ],
   942	)
   943	def test_validate_deployment_timeout_config(timeout, retry_timeout_seconds, should_warn):
   944	    from mlflow.utils.rest_utils import validate_deployment_timeout_config
   945	
   946	    if should_warn:
   947	        with warnings.catch_warnings(record=True) as w:
   948	            warnings.simplefilter("always")
   949	            validate_deployment_timeout_config(
   950	                timeout=timeout, retry_timeout_seconds=retry_timeout_seconds
   951	            )
   952	            assert len(w) == 1
   953	            warning_msg = str(w[0].message)
   954	            assert "MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT" in warning_msg
   955	            assert f"({retry_timeout_seconds}s)" in warning_msg
   956	            assert f"({timeout}s)" in warning_msg
   957	    else:
   958	        with warnings.catch_warnings(record=True) as w:
   959	            warnings.simplefilter("always")
   960	            validate_deployment_timeout_config(
   961	                timeout=timeout, retry_timeout_seconds=retry_timeout_seconds
   962	            )
   963	            assert len(w) == 0
```

## 原始行 39 · command_execution

命令：
```
/bin/bash -lc "nl -ba tests/utils/test_rest_utils.py | sed -n '1,460p'"
```

退出码：`0`

输出：
```
     1	import re
     2	import time
     3	import warnings
     4	from unittest import mock
     5	
     6	import numpy
     7	import pytest
     8	import requests
     9	
    10	from mlflow.deployments.databricks import DatabricksDeploymentClient
    11	from mlflow.environment_variables import (
    12	    _MLFLOW_DATABRICKS_TRAFFIC_ID,
    13	    MLFLOW_HTTP_REQUEST_TIMEOUT,
    14	)
    15	from mlflow.exceptions import InvalidUrlException, MlflowException, RestException
    16	from mlflow.protos.databricks_pb2 import ENDPOINT_NOT_FOUND, ErrorCode
    17	from mlflow.protos.service_pb2 import GetRun
    18	from mlflow.pyfunc.scoring_server import NumpyEncoder
    19	from mlflow.tracking.request_header.default_request_header_provider import (
    20	    _CLIENT_VERSION,
    21	    _USER_AGENT,
    22	    DefaultRequestHeaderProvider,
    23	)
    24	from mlflow.utils.rest_utils import (
    25	    _DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING,
    26	    MlflowHostCreds,
    27	    _can_parse_as_json_object,
    28	    augmented_raise_for_status,
    29	    call_endpoint,
    30	    call_endpoints,
    31	    get_workspace_client,
    32	    http_request,
    33	    http_request_safe,
    34	)
    35	
    36	from tests import helper_functions
    37	
    38	
    39	@pytest.mark.parametrize(
    40	    "response_mock",
    41	    [
    42	        helper_functions.create_mock_response(400, "Error message but not a JSON string"),
    43	        helper_functions.create_mock_response(400, ""),
    44	        helper_functions.create_mock_response(400, None),
    45	    ],
    46	)
    47	def test_malformed_json_error_response(response_mock):
    48	    with mock.patch("requests.Session.request", return_value=response_mock):
    49	        host_only = MlflowHostCreds("http://my-host")
    50	
    51	        response_proto = GetRun.Response()
    52	        with pytest.raises(
    53	            MlflowException, match="API request to endpoint /my/endpoint failed with error code 400"
    54	        ):
    55	            call_endpoint(host_only, "/my/endpoint", "GET", None, response_proto)
    56	
    57	
    58	def test_call_endpoints():
    59	    with mock.patch("mlflow.utils.rest_utils.call_endpoint") as mock_call_endpoint:
    60	        response_proto = GetRun.Response()
    61	        mock_call_endpoint.side_effect = [
    62	            RestException({"error_code": ErrorCode.Name(ENDPOINT_NOT_FOUND)}),
    63	            None,
    64	        ]
    65	        host_only = MlflowHostCreds("http://my-host")
    66	        endpoints = [("/my/endpoint", "POST"), ("/my/endpoint", "GET")]
    67	        resp = call_endpoints(host_only, endpoints, "", response_proto)
    68	        mock_call_endpoint.assert_has_calls(
    69	            [
    70	                mock.call(host_only, endpoint, method, "", response_proto, None)
    71	                for endpoint, method in endpoints
    72	            ]
    73	        )
    74	        assert resp is None
    75	
    76	
    77	def test_call_endpoints_raises_exceptions():
    78	    with mock.patch("mlflow.utils.rest_utils.call_endpoint") as mock_call_endpoint:
    79	        response_proto = GetRun.Response()
    80	        mock_call_endpoint.side_effect = [
    81	            RestException({"error_code": ErrorCode.Name(ENDPOINT_NOT_FOUND)}),
    82	            RestException({"error_code": ErrorCode.Name(ENDPOINT_NOT_FOUND)}),
    83	        ]
    84	        host_only = MlflowHostCreds("http://my-host")
    85	        endpoints = [("/my/endpoint", "POST"), ("/my/endpoint", "GET")]
    86	        with pytest.raises(RestException, match="ENDPOINT_NOT_FOUND"):
    87	            call_endpoints(host_only, endpoints, "", response_proto)
    88	        mock_call_endpoint.side_effect = [RestException({}), None]
    89	        with pytest.raises(RestException, match="INTERNAL_ERROR"):
    90	            call_endpoints(host_only, endpoints, "", response_proto)
    91	
    92	
    93	def test_http_request_hostonly():
    94	    host_only = MlflowHostCreds("http://my-host")
    95	    response = mock.MagicMock()
    96	    response.status_code = 200
    97	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
    98	        http_request(host_only, "/my/endpoint", "GET")
    99	        mock_request.assert_called_with(
   100	            "GET",
   101	            "http://my-host/my/endpoint",
   102	            allow_redirects=True,
   103	            verify=True,
   104	            headers=DefaultRequestHeaderProvider().request_headers(),
   105	            timeout=120,
   106	        )
   107	
   108	
   109	def test_http_request_cleans_hostname():
   110	    # Add a trailing slash, should be removed.
   111	    host_only = MlflowHostCreds("http://my-host/")
   112	    response = mock.MagicMock()
   113	    response.status_code = 200
   114	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   115	        http_request(host_only, "/my/endpoint", "GET")
   116	        mock_request.assert_called_with(
   117	            "GET",
   118	            "http://my-host/my/endpoint",
   119	            allow_redirects=True,
   120	            verify=True,
   121	            headers=DefaultRequestHeaderProvider().request_headers(),
   122	            timeout=120,
   123	        )
   124	
   125	
   126	def test_http_request_with_basic_auth():
   127	    host_only = MlflowHostCreds("http://my-host", username="user", password="pass")
   128	    response = mock.MagicMock()
   129	    response.status_code = 200
   130	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   131	        http_request(host_only, "/my/endpoint", "GET")
   132	        headers = DefaultRequestHeaderProvider().request_headers()
   133	        headers["Authorization"] = "Basic dXNlcjpwYXNz"
   134	        mock_request.assert_called_with(
   135	            "GET",
   136	            "http://my-host/my/endpoint",
   137	            allow_redirects=True,
   138	            verify=True,
   139	            headers=headers,
   140	            timeout=120,
   141	        )
   142	
   143	
   144	def test_http_request_with_aws_sigv4(monkeypatch):
   145	    """This test requires the "requests_auth_aws_sigv4" package to be installed"""
   146	
   147	    from requests_auth_aws_sigv4 import AWSSigV4
   148	
   149	    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "access-key")
   150	    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret-key")
   151	    monkeypatch.setenv("AWS_DEFAULT_REGION", "eu-west-1")
   152	    aws_sigv4 = MlflowHostCreds("http://my-host", aws_sigv4=True)
   153	    response = mock.MagicMock()
   154	    response.status_code = 200
   155	
   156	    class AuthMatcher:
   157	        def __eq__(self, other):
   158	            return isinstance(other, AWSSigV4)
   159	
   160	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   161	        http_request(aws_sigv4, "/my/endpoint", "GET")
   162	        mock_request.assert_called_once_with(
   163	            "GET",
   164	            "http://my-host/my/endpoint",
   165	            allow_redirects=True,
   166	            verify=mock.ANY,
   167	            headers=mock.ANY,
   168	            timeout=mock.ANY,
   169	            auth=AuthMatcher(),
   170	        )
   171	
   172	
   173	def test_http_request_with_auth():
   174	    mock_fetch_auth = {"test_name": "test_auth_value"}
   175	    auth = "test_auth_name"
   176	    host_only = MlflowHostCreds("http://my-host", auth=auth)
   177	    response = mock.MagicMock()
   178	    response.status_code = 200
   179	    with (
   180	        mock.patch("requests.Session.request", return_value=response) as mock_request,
   181	        mock.patch(
   182	            "mlflow.tracking.request_auth.registry.fetch_auth", return_value=mock_fetch_auth
   183	        ) as mock_fetch_auth_call,
   184	    ):
   185	        http_request(host_only, "/my/endpoint", "GET")
   186	
   187	        mock_fetch_auth_call.assert_called_with(auth)
   188	
   189	        mock_request.assert_called_with(
   190	            "GET",
   191	            "http://my-host/my/endpoint",
   192	            allow_redirects=True,
   193	            verify=mock.ANY,
   194	            headers=mock.ANY,
   195	            timeout=mock.ANY,
   196	            auth=mock_fetch_auth,
   197	        )
   198	
   199	
   200	def test_http_request_with_token():
   201	    host_only = MlflowHostCreds("http://my-host", token="my-token")
   202	    response = mock.MagicMock()
   203	    response.status_code = 200
   204	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   205	        http_request(host_only, "/my/endpoint", "GET")
   206	        headers = DefaultRequestHeaderProvider().request_headers()
   207	        headers["Authorization"] = "Bearer my-token"
   208	        mock_request.assert_called_with(
   209	            "GET",
   210	            "http://my-host/my/endpoint",
   211	            allow_redirects=True,
   212	            verify=True,
   213	            headers=headers,
   214	            timeout=120,
   215	        )
   216	
   217	
   218	def test_http_request_with_insecure():
   219	    host_only = MlflowHostCreds("http://my-host", ignore_tls_verification=True)
   220	    response = mock.MagicMock()
   221	    response.status_code = 200
   222	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   223	        http_request(host_only, "/my/endpoint", "GET")
   224	        mock_request.assert_called_with(
   225	            "GET",
   226	            "http://my-host/my/endpoint",
   227	            allow_redirects=True,
   228	            verify=False,
   229	            headers=DefaultRequestHeaderProvider().request_headers(),
   230	            timeout=120,
   231	        )
   232	
   233	
   234	def test_http_request_client_cert_path():
   235	    host_only = MlflowHostCreds("http://my-host", client_cert_path="/some/path")
   236	    response = mock.MagicMock()
   237	    response.status_code = 200
   238	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   239	        http_request(host_only, "/my/endpoint", "GET")
   240	        mock_request.assert_called_with(
   241	            "GET",
   242	            "http://my-host/my/endpoint",
   243	            allow_redirects=True,
   244	            verify=True,
   245	            cert="/some/path",
   246	            headers=DefaultRequestHeaderProvider().request_headers(),
   247	            timeout=120,
   248	        )
   249	
   250	
   251	def test_http_request_server_cert_path():
   252	    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
   253	    response = mock.MagicMock()
   254	    response.status_code = 200
   255	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   256	        http_request(host_only, "/my/endpoint", "GET")
   257	        mock_request.assert_called_with(
   258	            "GET",
   259	            "http://my-host/my/endpoint",
   260	            allow_redirects=True,
   261	            verify="/some/path",
   262	            headers=DefaultRequestHeaderProvider().request_headers(),
   263	            timeout=120,
   264	        )
   265	
   266	
   267	def test_http_request_with_content_type_header():
   268	    host_only = MlflowHostCreds("http://my-host", token="my-token")
   269	    response = mock.MagicMock()
   270	    response.status_code = 200
   271	    extra_headers = {"Content-Type": "text/plain"}
   272	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   273	        http_request(host_only, "/my/endpoint", "GET", extra_headers=extra_headers)
   274	        headers = DefaultRequestHeaderProvider().request_headers()
   275	        headers["Authorization"] = "Bearer my-token"
   276	        headers["Content-Type"] = "text/plain"
   277	        mock_request.assert_called_with(
   278	            "GET",
   279	            "http://my-host/my/endpoint",
   280	            allow_redirects=True,
   281	            verify=True,
   282	            headers=headers,
   283	            timeout=120,
   284	        )
   285	
   286	
   287	def test_http_request_request_headers():
   288	    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""
   289	
   290	    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider
   291	
   292	    # The test plugin's request header provider always returns False from in_context to avoid
   293	    # polluting request headers in developers' environments. The following mock overrides this to
   294	    # perform the integration test.
   295	    response = mock.MagicMock()
   296	    response.status_code = 200
   297	    with (
   298	        mock.patch("requests.Session.request", return_value=response) as mock_request,
   299	        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
   300	    ):
   301	        host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
   302	        http_request(host_only, "/my/endpoint", "GET")
   303	        mock_request.assert_called_with(
   304	            "GET",
   305	            "http://my-host/my/endpoint",
   306	            allow_redirects=True,
   307	            verify="/some/path",
   308	            headers={**DefaultRequestHeaderProvider().request_headers(), "test": "header"},
   309	            timeout=120,
   310	        )
   311	
   312	
   313	def test_http_request_request_headers_default():
   314	    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""
   315	
   316	    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider
   317	
   318	    # The test plugin's request header provider always returns False from in_context to avoid
   319	    # polluting request headers in developers' environments. The following mock overrides this to
   320	    # perform the integration test.
   321	    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
   322	    default_headers = DefaultRequestHeaderProvider().request_headers()
   323	    expected_headers = {
   324	        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
   325	        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
   326	    }
   327	
   328	    response = mock.MagicMock()
   329	    response.status_code = 200
   330	    with (
   331	        mock.patch("requests.Session.request", return_value=response) as mock_request,
   332	        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
   333	        mock.patch.object(
   334	            PluginRequestHeaderProvider,
   335	            "request_headers",
   336	            return_value={_USER_AGENT: "test_user_agent", _CLIENT_VERSION: "test_client_version"},
   337	        ),
   338	    ):
   339	        http_request(host_only, "/my/endpoint", "GET")
   340	        mock_request.assert_called_with(
   341	            "GET",
   342	            "http://my-host/my/endpoint",
   343	            allow_redirects=True,
   344	            verify="/some/path",
   345	            headers=expected_headers,
   346	            timeout=120,
   347	        )
   348	
   349	
   350	def test_http_request_request_headers_default_and_extra_header():
   351	    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""
   352	
   353	    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider
   354	
   355	    # The test plugin's request header provider always returns False from in_context to avoid
   356	    # polluting request headers in developers' environments. The following mock overrides this to
   357	    # perform the integration test.
   358	    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
   359	    default_headers = DefaultRequestHeaderProvider().request_headers()
   360	    expected_headers = {
   361	        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
   362	        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
   363	        "header": "value",
   364	    }
   365	
   366	    response = mock.MagicMock()
   367	    response.status_code = 200
   368	    with (
   369	        mock.patch("requests.Session.request", return_value=response) as mock_request,
   370	        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
   371	        mock.patch.object(
   372	            PluginRequestHeaderProvider,
   373	            "request_headers",
   374	            return_value={
   375	                _USER_AGENT: "test_user_agent",
   376	                _CLIENT_VERSION: "test_client_version",
   377	                "header": "value",
   378	            },
   379	        ),
   380	    ):
   381	        http_request(host_only, "/my/endpoint", "GET")
   382	        mock_request.assert_called_with(
   383	            "GET",
   384	            "http://my-host/my/endpoint",
   385	            allow_redirects=True,
   386	            verify="/some/path",
   387	            headers=expected_headers,
   388	            timeout=120,
   389	        )
   390	
   391	
   392	def test_http_request_with_invalid_url_raise_invalid_url_exception():
   393	    """InvalidURL exception can be caught by a custom InvalidUrlException"""
   394	    host_only = MlflowHostCreds("http://my-host")
   395	
   396	    with pytest.raises(InvalidUrlException, match="Invalid url: http://my-host/invalid_url"):
   397	        with mock.patch("requests.Session.request", side_effect=requests.exceptions.InvalidURL):
   398	            http_request(host_only, "/invalid_url", "GET")
   399	
   400	
   401	def test_http_request_with_invalid_url_raise_mlflow_exception():
   402	    """The InvalidUrlException can be caught by the MlflowException"""
   403	    host_only = MlflowHostCreds("http://my-host")
   404	
   405	    with pytest.raises(MlflowException, match="Invalid url: http://my-host/invalid_url"):
   406	        with mock.patch("requests.Session.request", side_effect=requests.exceptions.InvalidURL):
   407	            http_request(host_only, "/invalid_url", "GET")
   408	
   409	
   410	def test_ignore_tls_verification_not_server_cert_path():
   411	    with pytest.raises(
   412	        MlflowException,
   413	        match="When 'ignore_tls_verification' is true then 'server_cert_path' must not be set",
   414	    ):
   415	        MlflowHostCreds(
   416	            "http://my-host",
   417	            ignore_tls_verification=True,
   418	            server_cert_path="/some/path",
   419	        )
   420	
   421	
   422	def test_http_request_wrapper():
   423	    host_only = MlflowHostCreds("http://my-host", ignore_tls_verification=True)
   424	    response = mock.MagicMock()
   425	    response.status_code = 200
   426	    response.text = "{}"
   427	    with mock.patch("requests.Session.request", return_value=response) as mock_request:
   428	        http_request_safe(host_only, "/my/endpoint", "GET")
   429	        mock_request.assert_called_with(
   430	            "GET",
   431	            "http://my-host/my/endpoint",
   432	            allow_redirects=True,
   433	            verify=False,
   434	            headers=DefaultRequestHeaderProvider().request_headers(),
   435	            timeout=120,
   436	        )
   437	        response.text = "non json"
   438	        http_request_safe(host_only, "/my/endpoint", "GET")
   439	        mock_request.assert_called_with(
   440	            "GET",
   441	            "http://my-host/my/endpoint",
   442	            allow_redirects=True,
   443	            verify=False,
   444	            headers=DefaultRequestHeaderProvider().request_headers(),
   445	            timeout=120,
   446	        )
   447	        response.status_code = 400
   448	        response.text = ""
   449	        with pytest.raises(MlflowException, match="Response body"):
   450	            http_request_safe(host_only, "/my/endpoint", "GET")
   451	        response.text = (
   452	            '{"error_code": "RESOURCE_DOES_NOT_EXIST", "message": "Node type not supported"}'
   453	        )
   454	        with pytest.raises(RestException, match="RESOURCE_DOES_NOT_EXIST: Node type not supported"):
   455	            http_request_safe(host_only, "/my/endpoint", "GET")
   456	
   457	
   458	def test_numpy_encoder():
   459	    test_number = numpy.int64(42)
   460	    ne = NumpyEncoder()
```

## 原始行 41 · agent_message

```
The repository confirms these are deliberately blanked implementations, while their consumers and focused tests remain intact. I’m now deriving the exact request construction, retry adapter, SDK error mapping, and deployment plugin behavior from those local tests and adjacent helpers.
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc "sed -n '90,430p' tests/utils/test_rest_utils.py"
```

退出码：`0`

输出：
```
            call_endpoints(host_only, endpoints, "", response_proto)


def test_http_request_hostonly():
    host_only = MlflowHostCreds("http://my-host")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_cleans_hostname():
    # Add a trailing slash, should be removed.
    host_only = MlflowHostCreds("http://my-host/")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_with_basic_auth():
    host_only = MlflowHostCreds("http://my-host", username="user", password="pass")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        headers = DefaultRequestHeaderProvider().request_headers()
        headers["Authorization"] = "Basic dXNlcjpwYXNz"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=headers,
            timeout=120,
        )


def test_http_request_with_aws_sigv4(monkeypatch):
    """This test requires the "requests_auth_aws_sigv4" package to be installed"""

    from requests_auth_aws_sigv4 import AWSSigV4

    monkeypatch.setenv("AWS_ACCESS_KEY_ID", "access-key")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "secret-key")
    monkeypatch.setenv("AWS_DEFAULT_REGION", "eu-west-1")
    aws_sigv4 = MlflowHostCreds("http://my-host", aws_sigv4=True)
    response = mock.MagicMock()
    response.status_code = 200

    class AuthMatcher:
        def __eq__(self, other):
            return isinstance(other, AWSSigV4)

    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(aws_sigv4, "/my/endpoint", "GET")
        mock_request.assert_called_once_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=mock.ANY,
            headers=mock.ANY,
            timeout=mock.ANY,
            auth=AuthMatcher(),
        )


def test_http_request_with_auth():
    mock_fetch_auth = {"test_name": "test_auth_value"}
    auth = "test_auth_name"
    host_only = MlflowHostCreds("http://my-host", auth=auth)
    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch(
            "mlflow.tracking.request_auth.registry.fetch_auth", return_value=mock_fetch_auth
        ) as mock_fetch_auth_call,
    ):
        http_request(host_only, "/my/endpoint", "GET")

        mock_fetch_auth_call.assert_called_with(auth)

        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=mock.ANY,
            headers=mock.ANY,
            timeout=mock.ANY,
            auth=mock_fetch_auth,
        )


def test_http_request_with_token():
    host_only = MlflowHostCreds("http://my-host", token="my-token")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        headers = DefaultRequestHeaderProvider().request_headers()
        headers["Authorization"] = "Bearer my-token"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=headers,
            timeout=120,
        )


def test_http_request_with_insecure():
    host_only = MlflowHostCreds("http://my-host", ignore_tls_verification=True)
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=False,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_client_cert_path():
    host_only = MlflowHostCreds("http://my-host", client_cert_path="/some/path")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            cert="/some/path",
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_server_cert_path():
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    response = mock.MagicMock()
    response.status_code = 200
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_with_content_type_header():
    host_only = MlflowHostCreds("http://my-host", token="my-token")
    response = mock.MagicMock()
    response.status_code = 200
    extra_headers = {"Content-Type": "text/plain"}
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET", extra_headers=extra_headers)
        headers = DefaultRequestHeaderProvider().request_headers()
        headers["Authorization"] = "Bearer my-token"
        headers["Content-Type"] = "text/plain"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=headers,
            timeout=120,
        )


def test_http_request_request_headers():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
    ):
        host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers={**DefaultRequestHeaderProvider().request_headers(), "test": "header"},
            timeout=120,
        )


def test_http_request_request_headers_default():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    default_headers = DefaultRequestHeaderProvider().request_headers()
    expected_headers = {
        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
    }

    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
        mock.patch.object(
            PluginRequestHeaderProvider,
            "request_headers",
            return_value={_USER_AGENT: "test_user_agent", _CLIENT_VERSION: "test_client_version"},
        ),
    ):
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers=expected_headers,
            timeout=120,
        )


def test_http_request_request_headers_default_and_extra_header():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    default_headers = DefaultRequestHeaderProvider().request_headers()
    expected_headers = {
        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
        "header": "value",
    }

    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
        mock.patch.object(
            PluginRequestHeaderProvider,
            "request_headers",
            return_value={
                _USER_AGENT: "test_user_agent",
                _CLIENT_VERSION: "test_client_version",
                "header": "value",
            },
        ),
    ):
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers=expected_headers,
            timeout=120,
        )


def test_http_request_with_invalid_url_raise_invalid_url_exception():
    """InvalidURL exception can be caught by a custom InvalidUrlException"""
    host_only = MlflowHostCreds("http://my-host")

    with pytest.raises(InvalidUrlException, match="Invalid url: http://my-host/invalid_url"):
        with mock.patch("requests.Session.request", side_effect=requests.exceptions.InvalidURL):
            http_request(host_only, "/invalid_url", "GET")


def test_http_request_with_invalid_url_raise_mlflow_exception():
    """The InvalidUrlException can be caught by the MlflowException"""
    host_only = MlflowHostCreds("http://my-host")

    with pytest.raises(MlflowException, match="Invalid url: http://my-host/invalid_url"):
        with mock.patch("requests.Session.request", side_effect=requests.exceptions.InvalidURL):
            http_request(host_only, "/invalid_url", "GET")


def test_ignore_tls_verification_not_server_cert_path():
    with pytest.raises(
        MlflowException,
        match="When 'ignore_tls_verification' is true then 'server_cert_path' must not be set",
    ):
        MlflowHostCreds(
            "http://my-host",
            ignore_tls_verification=True,
            server_cert_path="/some/path",
        )


def test_http_request_wrapper():
    host_only = MlflowHostCreds("http://my-host", ignore_tls_verification=True)
    response = mock.MagicMock()
    response.status_code = 200
    response.text = "{}"
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request_safe(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' mlflow/utils/request_utils.py
sed -n '1,260p' mlflow/tracking/request_header/registry.py
sed -n '1,180p' mlflow/tracking/request_header/default_request_header_provider.py"
```

退出码：`0`

输出：
```
# DO NO IMPORT MLFLOW IN THIS FILE.
# This file is imported by download_cloud_file_chunk.py.
# Importing mlflow is time-consuming and we want to avoid that in artifact download subprocesses.
import os
import random
from functools import lru_cache

import requests
import urllib3
from packaging.version import Version
from requests.adapters import HTTPAdapter
from requests.exceptions import HTTPError
from urllib3.util import Retry

# Response codes that generally indicate transient network failures and merit client retries,
# based on guidance from cloud service providers
# (https://docs.microsoft.com/en-us/azure/architecture/best-practices/retry-service-specific#general-rest-and-retry-guidelines)
_TRANSIENT_FAILURE_RESPONSE_CODES = frozenset(
    [
        408,  # Request Timeout
        429,  # Too Many Requests
        500,  # Internal Server Error
        502,  # Bad Gateway
        503,  # Service Unavailable
        504,  # Gateway Timeout
    ]
)


class JitteredRetry(Retry):
    """
    urllib3 < 2 doesn't support `backoff_jitter`. This class is a workaround for that.
    """

    def __init__(self, *args, backoff_jitter=0.0, **kwargs):
        super().__init__(*args, **kwargs)
        self.backoff_jitter = backoff_jitter

    def get_backoff_time(self):
        """
        Source: https://github.com/urllib3/urllib3/commit/214b184923388328919b0a4b0c15bff603aa51be
        """
        backoff_value = super().get_backoff_time()
        if self.backoff_jitter != 0.0:
            backoff_value += random.random() * self.backoff_jitter
        # The attribute `BACKOFF_MAX` was renamed to `DEFAULT_BACKOFF_MAX` in this commit:
        # https://github.com/urllib3/urllib3/commit/f69b1c89f885a74429cabdee2673e030b35979f0
        # which was part of the major release of 2.0 for urllib3 and the support for both
        # constants was added in 1.26.9:
        # https://github.com/urllib3/urllib3/blob/1.26.9/src/urllib3/util/retry.py
        default_backoff = (
            Retry.BACKOFF_MAX
            if Version(urllib3.__version__) < Version("1.26.9")
            else Retry.DEFAULT_BACKOFF_MAX
        )

        return float(max(0, min(default_backoff, backoff_value)))


def augmented_raise_for_status(response):
    """Wrap the standard `requests.response.raise_for_status()` method and return reason"""
    try:
        response.raise_for_status()
    except HTTPError as e:
        if response.text:
            raise HTTPError(
                f"{e}. Response text: {response.text}", request=e.request, response=e.response
            )
        else:
            raise e


def download_chunk(*, range_start, range_end, headers, download_path, http_uri):
    combined_headers = {**headers, "Range": f"bytes={range_start}-{range_end}"}

    with cloud_storage_http_request(
        "get",
        http_uri,
        stream=False,
        headers=combined_headers,
        timeout=10,
    ) as response:
        expected_length = response.headers.get("Content-Length")
        if expected_length is not None:
            actual_length = response.raw.tell()
            expected_length = int(expected_length)
            if actual_length < expected_length:
                raise IOError(
                    "Incomplete read ({} bytes read, {} more expected)".format(
                        actual_length, expected_length - actual_length
                    )
                )
        # File will have been created upstream. Use r+b to ensure chunks
        # don't overwrite the entire file.
        augmented_raise_for_status(response)
        with open(download_path, "r+b") as f:
            f.seek(range_start)
            f.write(response.content)













































































































































def cloud_storage_http_request(
    method,
    url,
    max_retries=5,
    backoff_factor=2,
    backoff_jitter=1.0,
    retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,
    timeout=None,
    **kwargs,
):
    """Performs an HTTP PUT/GET/PATCH request using Python's `requests` module with automatic retry.

    Args:
        method: string of 'PUT' or 'GET' or 'PATCH', specify to do http PUT or GET or PATCH.
        url: the target URL address for the HTTP request.
        max_retries: maximum number of retries before throwing an exception.
        backoff_factor: a time factor for exponential backoff. e.g. value 5 means the HTTP
            request will be retried with interval 5, 10, 20... seconds. A value of 0 turns off the
            exponential backoff.
        backoff_jitter: A random jitter to add to the backoff interval.
        retry_codes: a list of HTTP response error codes that qualifies for retry.
        timeout: wait for timeout seconds for response from remote server for connect and
            read request. Default to None owing to long duration operation in read / write.
        kwargs: Additional keyword arguments to pass to `requests.Session.request()`.

    Returns:
        requests.Response object.
    """
    if method.lower() not in ("put", "get", "patch", "delete"):
        raise ValueError("Illegal http method: " + method)
    return _get_http_response_with_retries(
        method,
        url,
        max_retries,
        backoff_factor,
        backoff_jitter,
        retry_codes,
        timeout=timeout,
        **kwargs,
    )import logging
import warnings

from mlflow.tracking.request_header.databricks_request_header_provider import (
    DatabricksRequestHeaderProvider,
)
from mlflow.tracking.request_header.default_request_header_provider import (
    DefaultRequestHeaderProvider,
)
from mlflow.utils.plugins import get_entry_points

_logger = logging.getLogger(__name__)


class RequestHeaderProviderRegistry:
    def __init__(self):
        self._registry = []

    def register(self, request_header_provider):
        self._registry.append(request_header_provider())

    def register_entrypoints(self):
        """Register tracking stores provided by other packages"""
        for entrypoint in get_entry_points("mlflow.request_header_provider"):
            try:
                self.register(entrypoint.load())
            except (AttributeError, ImportError) as exc:
                warnings.warn(
                    'Failure attempting to register request header provider "{}": {}'.format(
                        entrypoint.name, str(exc)
                    ),
                    stacklevel=2,
                )

    def __iter__(self):
        return iter(self._registry)


_request_header_provider_registry = RequestHeaderProviderRegistry()
_request_header_provider_registry.register(DatabricksRequestHeaderProvider)
_request_header_provider_registry.register(DefaultRequestHeaderProvider)

_request_header_provider_registry.register_entrypoints()


from mlflow import __version__
from mlflow.tracking.request_header.abstract_request_header_provider import RequestHeaderProvider

_USER_AGENT = "User-Agent"
_CLIENT_VERSION = "X-MLflow-Client-Version"
# We need to specify client version in separate header as user agent is overwritten in SDK call path
_DEFAULT_HEADERS = {
    _USER_AGENT: f"mlflow-python-client/{__version__}",
    _CLIENT_VERSION: f"{__version__}",
}


class DefaultRequestHeaderProvider(RequestHeaderProvider):
    """
    Provides default request headers for outgoing request.
    """
```

## 原始行 48 · command_execution

命令：
```
/bin/bash -lc "sed -n '470,825p' tests/utils/test_rest_utils.py"
```

退出码：`0`

输出：
```
    with pytest.raises(TypeError, match="not JSON serializable"):
        ne.default(test_number)


def test_can_parse_as_json_object():
    assert _can_parse_as_json_object("{}")
    assert _can_parse_as_json_object('{"a": "b"}')
    assert _can_parse_as_json_object('{"a": {"b": "c"}}')
    assert not _can_parse_as_json_object("[0, 1, 2]")
    assert not _can_parse_as_json_object('"abc"')
    assert not _can_parse_as_json_object("123")


def test_http_request_customize_config(monkeypatch):
    with mock.patch(
        "mlflow.utils.rest_utils._get_http_response_with_retries"
    ) as mock_get_http_response_with_retries:
        host_only = MlflowHostCreds("http://my-host")
        monkeypatch.delenv("MLFLOW_HTTP_REQUEST_MAX_RETRIES", raising=False)
        monkeypatch.delenv("MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR", raising=False)
        monkeypatch.delenv("MLFLOW_HTTP_REQUEST_TIMEOUT", raising=False)
        monkeypatch.delenv("MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER", raising=False)
        http_request(host_only, "/my/endpoint", "GET")
        mock_get_http_response_with_retries.assert_called_with(
            mock.ANY,
            mock.ANY,
            7,
            2,
            1.0,
            mock.ANY,
            True,
            headers=mock.ANY,
            verify=mock.ANY,
            timeout=120,
            respect_retry_after_header=True,
        )
        mock_get_http_response_with_retries.reset_mock()
        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_MAX_RETRIES", "8")
        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR", "3")
        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_BACKOFF_JITTER", "1.0")
        monkeypatch.setenv("MLFLOW_HTTP_REQUEST_TIMEOUT", "300")
        monkeypatch.setenv("MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER", "false")
        http_request(host_only, "/my/endpoint", "GET")
        mock_get_http_response_with_retries.assert_called_with(
            mock.ANY,
            mock.ANY,
            8,
            3,
            1.0,
            mock.ANY,
            True,
            headers=mock.ANY,
            verify=mock.ANY,
            timeout=300,
            respect_retry_after_header=False,
        )


def test_http_request_explains_how_to_increase_timeout_in_error_message():
    with mock.patch("requests.Session.request", side_effect=requests.exceptions.Timeout):
        with pytest.raises(
            MlflowException,
            match=(
                r"To increase the timeout, set the environment variable "
                + re.escape(str(MLFLOW_HTTP_REQUEST_TIMEOUT))
            ),
        ):
            http_request(MlflowHostCreds("http://my-host"), "/my/endpoint", "GET")


def test_augmented_raise_for_status():
    response = requests.Response()
    response.status_code = 403
    response._content = b"Token expired"

    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        response = requests.get("https://github.com/mlflow/mlflow.git")
        mock_request.assert_called_once()

    with pytest.raises(requests.HTTPError, match="Token expired") as e:
        augmented_raise_for_status(response)

    assert e.value.response == response
    assert e.value.request == response.request
    assert response.text in str(e.value)


def test_provide_redirect_kwarg():
    with mock.patch("requests.Session.request") as mock_request:
        mock_request.return_value.status_code = 302
        mock_request.return_value.text = "mock response"

        response = http_request(
            MlflowHostCreds("http://my-host"),
            "/my/endpoint",
            "GET",
            allow_redirects=False,
        )

        assert response.text == "mock response"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=False,
            headers=mock.ANY,
            verify=mock.ANY,
            timeout=120,
        )


def test_http_request_max_retries(monkeypatch):
    monkeypatch.setenv("_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT", "15")
    host_creds = MlflowHostCreds("http://example.com")

    with mock.patch("requests.Session.request") as mock_request:
        with pytest.raises(MlflowException, match="The configured max_retries"):
            http_request(host_creds, "/endpoint", "GET", max_retries=16)
        mock_request.assert_not_called()
        http_request(host_creds, "/endpoint", "GET", max_retries=3)
        mock_request.assert_called_once()


def test_http_request_backoff_factor(monkeypatch):
    monkeypatch.setenv("_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT", "200")
    host_creds = MlflowHostCreds("http://example.com")

    with mock.patch("requests.Session.request") as mock_request:
        with pytest.raises(MlflowException, match="The configured backoff_factor"):
            http_request(host_creds, "/endpoint", "GET", backoff_factor=250)
        mock_request.assert_not_called()
        http_request(host_creds, "/endpoint", "GET", backoff_factor=10)
        mock_request.assert_called_once()


def test_http_request_negative_max_retries():
    host_creds = MlflowHostCreds("http://example.com")

    with mock.patch("requests.Session.request") as mock_request:
        with pytest.raises(MlflowException, match="The max_retries value must be either"):
            http_request(host_creds, "/endpoint", "GET", max_retries=-1)
        mock_request.assert_not_called()


def test_http_request_negative_backoff_factor():
    host_creds = MlflowHostCreds("http://example.com")

    with mock.patch("requests.Session.request") as mock_request:
        with pytest.raises(MlflowException, match="The backoff_factor value must be"):
            http_request(host_creds, "/endpoint", "GET", backoff_factor=-1)
        mock_request.assert_not_called()


def test_suppress_databricks_retry_after_secs_warnings():
    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)

    def mock_do(*args, **kwargs):
        warnings.warn(_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING)
        return mock.MagicMock()

    with (
        warnings.catch_warnings(record=True) as recorded_warnings,
        mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client,
    ):
        warnings.simplefilter("always")
        mock_workspace_client = mock.MagicMock()
        mock_workspace_client.api_client.do = mock_do
        mock_get_workspace_client.return_value = mock_workspace_client
        http_request(host_creds, "/endpoint", "GET")
        mock_get_workspace_client.assert_called_once()
        assert not any(
            _DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING in str(w.message)
            for w in recorded_warnings
        )


def test_databricks_sdk_retry_on_transient_errors():
    """Test that Databricks SDK retries on transient HTTP errors."""
    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)

    call_count = 0

    def mock_do_failing_then_success(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count <= 2:  # Fail first 2 attempts
            from databricks.sdk.errors import DatabricksError

            from mlflow.protos.databricks_pb2 import ErrorCode

            raise DatabricksError(
                error_code=ErrorCode.Name(ErrorCode.INTERNAL_ERROR), message="Transient error"
            )
        # Success on 3rd attempt
        response_mock = mock.MagicMock()
        response_mock._response = mock.MagicMock()
        return {"contents": response_mock}

    with mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client:
        mock_workspace_client = mock.MagicMock()
        mock_workspace_client.api_client.do = mock_do_failing_then_success
        mock_get_workspace_client.return_value = mock_workspace_client

        # Use smaller retry timeout to make test run faster
        response = http_request(
            host_creds,
            "/endpoint",
            "GET",
            retry_timeout_seconds=10,
            backoff_factor=0.1,  # Very small backoff for faster test
        )

        assert call_count == 3  # Should retry 2 times, succeed on 3rd
        assert response is not None


def test_databricks_sdk_retry_max_retries_exceeded():
    """Test that Databricks SDK stops retrying when max_retries is exceeded."""
    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)

    call_count = 0

    def mock_do_always_fail(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        from databricks.sdk.errors import DatabricksError

        raise DatabricksError(error_code="INTERNAL_ERROR", message="Always fails")

    with (
        mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client,
        mock.patch("mlflow.utils.rest_utils._logger") as mock_logger,
    ):
        mock_workspace_client = mock.MagicMock()
        mock_workspace_client.api_client.do = mock_do_always_fail
        mock_get_workspace_client.return_value = mock_workspace_client

        response = http_request(host_creds, "/endpoint", "GET", max_retries=3)

        assert call_count == 4  # Initial call + 3 retries
        assert response.status_code == 500  # Should return error response

        # Check that max retries warning was logged
        mock_logger.warning.assert_called()
        warning_call = mock_logger.warning.call_args[0][0]
        assert "Max retries (3) exceeded" in warning_call


def test_databricks_sdk_retry_timeout_exceeded():
    """Test that Databricks SDK stops retrying when timeout is exceeded."""
    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)

    call_count = 0

    def mock_do_always_fail(*args, **kwargs):
        nonlocal call_count
        call_count += 1

        time.sleep(0.1)  # Small delay to ensure timeout
        from databricks.sdk.errors import DatabricksError

        raise DatabricksError(error_code="INTERNAL_ERROR", message="Always fails")

    with (
        mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client,
        mock.patch("mlflow.utils.rest_utils._logger") as mock_logger,
    ):
        mock_workspace_client = mock.MagicMock()
        mock_workspace_client.api_client.do = mock_do_always_fail
        mock_get_workspace_client.return_value = mock_workspace_client

        response = http_request(
            host_creds,
            "/endpoint",
            "GET",
            retry_timeout_seconds=0.2,  # Very short timeout
            max_retries=10,  # High retry limit that shouldn't be reached
        )

        assert call_count >= 1  # At least initial call
        assert response.status_code == 500  # Should return error response

        # Check that timeout warning was logged
        mock_logger.warning.assert_called()
        warning_call = mock_logger.warning.call_args[0][0]
        assert "Retry timeout (0.2s) exceeded" in warning_call


def test_databricks_sdk_retry_non_retryable_error():
    """Test that Databricks SDK doesn't retry on non-retryable errors."""
    host_creds = MlflowHostCreds("http://example.com", use_databricks_sdk=True)

    call_count = 0

    def mock_do_non_retryable_error(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        from databricks.sdk.errors import InvalidParameterValue

        # Use an error code that maps to 400 (non-retryable)
        raise InvalidParameterValue(error_code="INVALID_PARAMETER_VALUE", message="Bad request")

    with mock.patch("mlflow.utils.rest_utils.get_workspace_client") as mock_get_workspace_client:
        mock_workspace_client = mock.MagicMock()
        mock_workspace_client.api_client.do = mock_do_non_retryable_error
        mock_get_workspace_client.return_value = mock_workspace_client

        response = http_request(host_creds, "/endpoint", "GET", max_retries=5)

        assert call_count == 1  # Should not retry on non-retryable error
        assert response.status_code == 400  # Should return 400 for INVALID_PARAMETER_VALUE


def test_databricks_sdk_retry_backoff_calculation():
    """Test that Databricks SDK uses correct exponential backoff timing."""
    from databricks.sdk.errors import DatabricksError

    from mlflow.utils.request_utils import _TRANSIENT_FAILURE_RESPONSE_CODES
    from mlflow.utils.rest_utils import _retry_databricks_sdk_call_with_exponential_backoff

    call_count = 0

    def mock_failing_call():
        nonlocal call_count
        call_count += 1

        raise DatabricksError(error_code="INTERNAL_ERROR", message="Mock error")

    with mock.patch("mlflow.utils.rest_utils._time_sleep") as mock_sleep:
        with pytest.raises(DatabricksError, match="Mock error"):
            _retry_databricks_sdk_call_with_exponential_backoff(
                call_func=mock_failing_call,
                retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,
                retry_timeout_seconds=10,
                backoff_factor=1,  # Use 1 for predictable calculation
                backoff_jitter=0,  # No jitter for predictable calculation
                max_retries=3,
            )

    # Verify sleep was called with correct intervals
    # attempt 0 (1st retry): 0 seconds (immediate)
    # attempt 1 (2nd retry): 1 * (2^1) = 2 seconds
    # attempt 2 (3rd retry): 1 * (2^2) = 4 seconds
    expected_sleep_times = [0, 2, 4]
    actual_sleep_times = [call.args[0] for call in mock_sleep.call_args_list]
    assert actual_sleep_times == expected_sleep_times
    assert call_count == 4  # Initial + 3 retries


@pytest.mark.skip
def test_timeout_parameter_propagation_with_timeout():
    """Test timeout parameter propagation from http_request to get_workspace_client with timeout."""
    with (
        mock.patch("databricks.sdk.WorkspaceClient") as mock_workspace_client,
        mock.patch("databricks.sdk.config.Config") as mock_config,
    ):
        # Test http_request with timeout via get_workspace_client directly
```

## 原始行 49 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' mlflow/deployments/plugin_manager.py
sed -n '1,140p' mlflow/deployments/utils.py
grep -n \"get_deploy_client\\|target_uri\\|no target\\|deployments target\" tests/deployments/test_deployments.py mlflow/deployments/__init__.py"
```

退出码：`0`

输出：
```
import abc
import importlib.metadata
import inspect

import importlib_metadata

from mlflow.deployments.base import BaseDeploymentClient

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INTERNAL_ERROR, RESOURCE_DOES_NOT_EXIST
from mlflow.utils.annotations import developer_stable
from mlflow.utils.plugins import get_entry_points

# TODO: refactor to have a common base class for all the plugin implementation in MLflow
#   mlflow/tracking/context/registry.py
#   mlflow/tracking/registry
#   mlflow/store/artifact/artifact_repository_registry.py


@developer_stable
class PluginManager(abc.ABC):
    """
    Abstract class defining a entrypoint based plugin registration.

    This class allows the registration of a function or class to provide an implementation
    for a given key/name. Implementations declared though the entrypoints can be automatically
    registered through the `register_entrypoints` method.
    """

    def __init__(self, group_name):
        self._registry = {}
        self.group_name = group_name
        self._has_registered = None

    @abc.abstractmethod
    def __getitem__(self, item):
        # Letting the child class create this function so that the child
        # can raise custom exceptions if it needs to
        pass

    @property
    def registry(self):
        """
        Registry stores the registered plugin as a key value pair where key is the
        name of the plugin and value is the plugin object
        """
        return self._registry

    @property
    def has_registered(self):
        """
        Returns bool representing whether the "register_entrypoints" has run or not. This
        doesn't return True if `register` method is called outside of `register_entrypoints`
        to register plugins
        """
        return self._has_registered

    def register(self, target_name, plugin_module):
        """Register a deployment client given its target name and module
        Args:
            target_name: The name of the deployment target. This name will be used by
                `get_deploy_client()` to retrieve a deployment client from
                the plugin store.
            plugin_module: The module that implements the deployment plugin interface.
        """
        self.registry[target_name] = importlib.metadata.EntryPoint(
            target_name, plugin_module, self.group_name
        )

    def register_entrypoints(self):
        """
        Runs through all the packages that has the `group_name` defined as the entrypoint
        and register that into the registry
        """
        for entrypoint in get_entry_points(self.group_name):
            self.registry[entrypoint.name] = entrypoint
        self._has_registered = True


@developer_stable
class DeploymentPlugins(PluginManager):
    def __init__(self):
        super().__init__("mlflow.deployments")
        self.register_entrypoints()

    def __getitem__(self, item):
        """Override __getitem__ so that we can directly look up plugins via dict-like syntax"""
        try:
            target_name = parse_target_uri(item)
            plugin_like = self.registry[target_name]
        except KeyError:
            msg = (
                f'No plugin found for managing model deployments to "{item}". '
                f'In order to deploy models to "{item}", find and install an appropriate '
                "plugin from "
                "https://mlflow.org/docs/latest/plugins.html#community-plugins using "
                "your package manager (pip, conda etc)."
            )
            raise MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)

        if isinstance(plugin_like, (importlib_metadata.EntryPoint, importlib.metadata.EntryPoint)):
            try:
                plugin_obj = plugin_like.load()
            except (AttributeError, ImportError) as exc:
                raise RuntimeError(f'Failed to load the plugin "{item}": {exc}')
            self.registry[item] = plugin_obj
        else:
            plugin_obj = plugin_like

        # Testing whether the plugin is valid or not
        expected = {"target_help", "run_local"}
        deployment_classes = []
        for name, obj in inspect.getmembers(plugin_obj):
            if name in expected:
                expected.remove(name)
            elif (
                inspect.isclass(obj)
                and issubclass(obj, BaseDeploymentClient)
                and not obj == BaseDeploymentClient
            ):
                deployment_classes.append(name)
        if len(expected) > 0:
            raise MlflowException(
                f"Plugin registered for the target {item} does not have all "
                "the required interfaces. Raise an issue with the "
                "plugin developers.\n"
                f"Missing interfaces: {expected}",
                error_code=INTERNAL_ERROR,
            )
        if len(deployment_classes) > 1:
            raise MlflowException(
                f"Plugin registered for the target {item} has more than one "
                "child class of BaseDeploymentClient. Raise an issue with"
                " the plugin developers. "
                f"Classes found are {deployment_classes}"
            )
        elif len(deployment_classes) == 0:
            raise MlflowException(
                f"Plugin registered for the target {item} has no child class"
                " of BaseDeploymentClient. Raise an issue with the "
                "plugin developers"
            )
        return plugin_obj
import urllib
from urllib.parse import urlparse

from mlflow.environment_variables import MLFLOW_DEPLOYMENTS_TARGET
from mlflow.exceptions import MlflowException
from mlflow.utils.uri import append_to_uri_path

_deployments_target: str | None = None
















def _is_valid_uri(uri: str) -> bool:
    """
    Evaluates the basic structure of a provided uri to determine if the scheme and
    netloc are provided
    """
    try:
        parsed = urlparse(uri)
        return bool(parsed.scheme and parsed.netloc)
    except ValueError:
        return False


def resolve_endpoint_url(base_url: str, endpoint: str) -> str:
    """Performs a validation on whether the returned value is a fully qualified url
    or requires the assembly of a fully qualified url by appending `endpoint`.

    Args:
        base_url: The base URL. Should include the scheme and domain, e.g.,
            ``http://127.0.0.1:6000``.
        endpoint: The endpoint to be appended to the base URL, e.g., ``/api/2.0/endpoints/`` or,
            in the case of Databricks, the fully qualified url.

    Returns:
        The complete URL, either directly returned or formed and returned by joining the
        base URL and the endpoint path.

    """
    return endpoint if _is_valid_uri(endpoint) else append_to_uri_path(base_url, endpoint)


def set_deployments_target(target: str):
    """Sets the target deployment client for MLflow deployments

    Args:
        target: The full uri of a running MLflow AI Gateway or, if running on
            Databricks, "databricks".
    """
    if not _is_valid_target(target):
        raise MlflowException.invalid_parameter_value(
            "The target provided is not a valid uri or 'databricks'"
        )

    global _deployments_target
    _deployments_target = target


def get_deployments_target() -> str:
    """
    Returns the currently set MLflow deployments target iff set.
    If the deployments target has not been set by using ``set_deployments_target``, an
    ``MlflowException`` is raised.
    """
    if _deployments_target is not None:
        return _deployments_target
    elif uri := MLFLOW_DEPLOYMENTS_TARGET.get():
        return uri
    else:
        raise MlflowException(
            "No deployments target has been set. Please either set the MLflow deployments target"
            " via `mlflow.deployments.set_deployments_target()` or set the environment variable "
            f"{MLFLOW_DEPLOYMENTS_TARGET} to the running deployment server's uri"
        )


def _is_valid_target(target: str):
    """
    Evaluates the basic structure of a provided target to determine if the scheme and
    netloc are provided
    """
    if target == "databricks":
        return True
    return _is_valid_uri(target)tests/deployments/test_deployments.py:17:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:28:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:33:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:39:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:45:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:51:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:58:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:63:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:68:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:74:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:83:        deployments.get_deploy_client("wrong_target")
tests/deployments/test_deployments.py:98:    client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:105:def test_target_uri_parsing():
tests/deployments/test_deployments.py:106:    deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:107:    deployments.get_deploy_client(f"{f_target}:/somesuffix")
tests/deployments/test_deployments.py:108:    deployments.get_deploy_client(f"{f_target}://somesuffix")
tests/deployments/test_deployments.py:115:    target_client = deployments.get_deploy_client(f_target)
tests/deployments/test_deployments.py:124:    target_client = deployments.get_deploy_client(f_target)
mlflow/deployments/__init__.py:109:    "get_deploy_client",
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc "sed -n '260,470p' tests/utils/test_rest_utils.py
sed -n '410,475p' tests/utils/test_rest_utils.py"
```

退出码：`0`

输出：
```
            allow_redirects=True,
            verify="/some/path",
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )


def test_http_request_with_content_type_header():
    host_only = MlflowHostCreds("http://my-host", token="my-token")
    response = mock.MagicMock()
    response.status_code = 200
    extra_headers = {"Content-Type": "text/plain"}
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request(host_only, "/my/endpoint", "GET", extra_headers=extra_headers)
        headers = DefaultRequestHeaderProvider().request_headers()
        headers["Authorization"] = "Bearer my-token"
        headers["Content-Type"] = "text/plain"
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=True,
            headers=headers,
            timeout=120,
        )


def test_http_request_request_headers():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
    ):
        host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers={**DefaultRequestHeaderProvider().request_headers(), "test": "header"},
            timeout=120,
        )


def test_http_request_request_headers_default():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    default_headers = DefaultRequestHeaderProvider().request_headers()
    expected_headers = {
        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
    }

    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
        mock.patch.object(
            PluginRequestHeaderProvider,
            "request_headers",
            return_value={_USER_AGENT: "test_user_agent", _CLIENT_VERSION: "test_client_version"},
        ),
    ):
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers=expected_headers,
            timeout=120,
        )


def test_http_request_request_headers_default_and_extra_header():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    host_only = MlflowHostCreds("http://my-host", server_cert_path="/some/path")
    default_headers = DefaultRequestHeaderProvider().request_headers()
    expected_headers = {
        _USER_AGENT: "{} {}".format(default_headers[_USER_AGENT], "test_user_agent"),
        _CLIENT_VERSION: "{} {}".format(default_headers[_CLIENT_VERSION], "test_client_version"),
        "header": "value",
    }

    response = mock.MagicMock()
    response.status_code = 200
    with (
        mock.patch("requests.Session.request", return_value=response) as mock_request,
        mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True),
        mock.patch.object(
            PluginRequestHeaderProvider,
            "request_headers",
            return_value={
                _USER_AGENT: "test_user_agent",
                _CLIENT_VERSION: "test_client_version",
                "header": "value",
            },
        ),
    ):
        http_request(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify="/some/path",
            headers=expected_headers,
            timeout=120,
        )


def test_http_request_with_invalid_url_raise_invalid_url_exception():
    """InvalidURL exception can be caught by a custom InvalidUrlException"""
    host_only = MlflowHostCreds("http://my-host")

    with pytest.raises(InvalidUrlException, match="Invalid url: http://my-host/invalid_url"):
        with mock.patch("requests.Session.request", side_effect=requests.exceptions.InvalidURL):
            http_request(host_only, "/invalid_url", "GET")


def test_http_request_with_invalid_url_raise_mlflow_exception():
    """The InvalidUrlException can be caught by the MlflowException"""
    host_only = MlflowHostCreds("http://my-host")

    with pytest.raises(MlflowException, match="Invalid url: http://my-host/invalid_url"):
        with mock.patch("requests.Session.request", side_effect=requests.exceptions.InvalidURL):
            http_request(host_only, "/invalid_url", "GET")


def test_ignore_tls_verification_not_server_cert_path():
    with pytest.raises(
        MlflowException,
        match="When 'ignore_tls_verification' is true then 'server_cert_path' must not be set",
    ):
        MlflowHostCreds(
            "http://my-host",
            ignore_tls_verification=True,
            server_cert_path="/some/path",
        )


def test_http_request_wrapper():
    host_only = MlflowHostCreds("http://my-host", ignore_tls_verification=True)
    response = mock.MagicMock()
    response.status_code = 200
    response.text = "{}"
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request_safe(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=False,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )
        response.text = "non json"
        http_request_safe(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=False,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )
        response.status_code = 400
        response.text = ""
        with pytest.raises(MlflowException, match="Response body"):
            http_request_safe(host_only, "/my/endpoint", "GET")
        response.text = (
            '{"error_code": "RESOURCE_DOES_NOT_EXIST", "message": "Node type not supported"}'
        )
        with pytest.raises(RestException, match="RESOURCE_DOES_NOT_EXIST: Node type not supported"):
            http_request_safe(host_only, "/my/endpoint", "GET")


def test_numpy_encoder():
    test_number = numpy.int64(42)
    ne = NumpyEncoder()
    defaulted_val = ne.default(test_number)
    assert defaulted_val == 42


def test_numpy_encoder_fail():
    if not hasattr(numpy, "float128"):
        pytest.skip("numpy on exit this platform has no float128")
    test_number = numpy.float128
    ne = NumpyEncoder()
    with pytest.raises(TypeError, match="not JSON serializable"):
def test_ignore_tls_verification_not_server_cert_path():
    with pytest.raises(
        MlflowException,
        match="When 'ignore_tls_verification' is true then 'server_cert_path' must not be set",
    ):
        MlflowHostCreds(
            "http://my-host",
            ignore_tls_verification=True,
            server_cert_path="/some/path",
        )


def test_http_request_wrapper():
    host_only = MlflowHostCreds("http://my-host", ignore_tls_verification=True)
    response = mock.MagicMock()
    response.status_code = 200
    response.text = "{}"
    with mock.patch("requests.Session.request", return_value=response) as mock_request:
        http_request_safe(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=False,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )
        response.text = "non json"
        http_request_safe(host_only, "/my/endpoint", "GET")
        mock_request.assert_called_with(
            "GET",
            "http://my-host/my/endpoint",
            allow_redirects=True,
            verify=False,
            headers=DefaultRequestHeaderProvider().request_headers(),
            timeout=120,
        )
        response.status_code = 400
        response.text = ""
        with pytest.raises(MlflowException, match="Response body"):
            http_request_safe(host_only, "/my/endpoint", "GET")
        response.text = (
            '{"error_code": "RESOURCE_DOES_NOT_EXIST", "message": "Node type not supported"}'
        )
        with pytest.raises(RestException, match="RESOURCE_DOES_NOT_EXIST: Node type not supported"):
            http_request_safe(host_only, "/my/endpoint", "GET")


def test_numpy_encoder():
    test_number = numpy.int64(42)
    ne = NumpyEncoder()
    defaulted_val = ne.default(test_number)
    assert defaulted_val == 42


def test_numpy_encoder_fail():
    if not hasattr(numpy, "float128"):
        pytest.skip("numpy on exit this platform has no float128")
    test_number = numpy.float128
    ne = NumpyEncoder()
    with pytest.raises(TypeError, match="not JSON serializable"):
        ne.default(test_number)


def test_can_parse_as_json_object():
    assert _can_parse_as_json_object("{}")
```

## 原始行 54 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"EndpointType\\|Limit(\" tests/gateway tests/deployments --include='*.py'
sed -n '1,180p' mlflow/gateway/base_models.py
grep -R -n \"from mlflow.deployments.server.config import Endpoint\\|Endpoint(\" mlflow/deployments mlflow/gateway tests/deployments tests/gateway --include='*.py' | head -120"
```

退出码：`0`

输出：
```
from typing import Any

from pydantic import BaseModel


class RequestModel(
    BaseModel,
    # Allow extra fields for pydantic request models, e.g. to support
    # vendor-specific embeddings parameters
    extra="allow",
):
    """
    A pydantic model representing Gateway request data, such as a chat or completions request
    """


class ResponseModel(
    BaseModel,
    # Ignore extra fields for pydantic response models to ensure a consistent response
    # experience for clients across different backends
    extra="ignore",
):
    """
    A pydantic model representing Gateway response data, such as information about a Gateway
    Route returned in response to a GetRoute request
    """


class ConfigModel(
    BaseModel,
    # Ignore extra fields for pydantic config models, since they are unused
    extra="ignore",
):
    """
    A pydantic model representing Gateway configuration data, such as an OpenAI completions
    route definition including route name, model name, API keys, etc.
    """


class LimitModel(
    BaseModel,
    # Ignore extra fields for pydantic limit models, since they are unused
    extra="ignore",
):
    """
    A pydantic model representing Gateway Limit data, such as renewal period, limit
    key, limit value, etc.
    """


class SetLimitsModel(
    BaseModel,
    # Ignore extra fields for pydantic limit models, since they are unused
    extra="ignore",
):
    route: str
    limits: list[dict[str, Any]]
    """
    A pydantic model representing Gateway SetLimits request body, containing route and limits.
    """
mlflow/deployments/databricks/__init__.py:26:class DatabricksEndpoint(AttrDict):
mlflow/deployments/databricks/__init__.py:32:        endpoint = DatabricksEndpoint(
mlflow/deployments/databricks/__init__.py:166:        return DatabricksEndpoint(response.json())
mlflow/deployments/mlflow/__init__.py:27:    from mlflow.deployments.server.config import Endpoint
mlflow/deployments/mlflow/__init__.py:173:        return Endpoint(
mlflow/deployments/mlflow/__init__.py:189:            Endpoint(
mlflow/gateway/config.py:34:    from mlflow.deployments.server.config import Endpoint
mlflow/gateway/config.py:420:        from mlflow.deployments.server.config import Endpoint
mlflow/gateway/config.py:422:        return Endpoint(
mlflow/gateway/config.py:476:        from mlflow.deployments.server.config import Endpoint
mlflow/gateway/config.py:478:        return Endpoint(
mlflow/gateway/app.py:13:from mlflow.deployments.server.config import Endpoint
```

## 原始行 56 · command_execution

命令：
```
/bin/bash -lc "sed -n '90,145p' mlflow/deployments/__init__.py
sed -n '100,150p' tests/deployments/test_deployments.py
sed -n '1,130p' tests/resources/mlflow-test-plugin/mlflow_test_plugin/fake_deployment_plugin.py
grep -R -n \"get_deploy_client(None\\|get_deploy_client()\\|set_deployments_target\" tests --include='*.py'"
```

退出码：`0`

输出：
```
                json.dump(dict(self), f)
        else:
            return json.dumps(dict(self))

    @classmethod
    def from_json(cls, json_str):
        try:
            parsed_response = json.loads(json_str)
        except Exception as e:
            raise MlflowException("Predictions response contents are not valid JSON") from e
        if not isinstance(parsed_response, dict) or "predictions" not in parsed_response:
            raise MlflowException(
                f"Invalid response. Predictions response contents must be a dictionary"
                f" containing a 'predictions' field. Instead, received: {parsed_response}"
            )
        return PredictionsResponse(parsed_response)


__all__ = [
    "get_deploy_client",
    "run_local",
    "BaseDeploymentClient",
    "DatabricksDeploymentClient",
    "OpenAIDeploymentClient",
    "DatabricksEndpoint",
    "MlflowDeploymentClient",
    "PredictionsResponse",
    "get_deployments_target",
    "set_deployments_target",
]
    monkeypatch.setenv("raiseError", "True")
    with pytest.raises(RuntimeError, match="Error requested"):
        client.list_deployments()


def test_target_uri_parsing():
    deployments.get_deploy_client(f_target)
    deployments.get_deploy_client(f"{f_target}:/somesuffix")
    deployments.get_deploy_client(f"{f_target}://somesuffix")


def test_explain_with_no_target_implementation():
    from mlflow_test_plugin import fake_deployment_plugin

    mock_error = MlflowException("MOCK ERROR")
    target_client = deployments.get_deploy_client(f_target)
    plugin = fake_deployment_plugin.PluginDeploymentClient
    with mock.patch.object(plugin, "explain", return_value=mock_error) as mock_explain:
        res = target_client.explain(f_target, "test")
        assert type(res) == MlflowException
        mock_explain.assert_called_once()


def test_explain_with_target_implementation():
    target_client = deployments.get_deploy_client(f_target)
    res = target_client.explain(f_target, "test")
    assert res == "1"
import os

from mlflow.deployments import BaseDeploymentClient, PredictionsResponse

f_deployment_name = "fake_deployment_name"
f_endpoint_name = "fake_endpoint_name"


class PluginDeploymentClient(BaseDeploymentClient):
    def create_deployment(self, name, model_uri, flavor=None, config=None, endpoint=None):
        if config and config.get("raiseError") == "True":
            raise RuntimeError("Error requested")
        return {"name": f_deployment_name, "flavor": flavor}

    def delete_deployment(self, name, config=None, endpoint=None):
        if config and config.get("raiseError") == "True":
            raise RuntimeError("Error requested")
        return None

    def update_deployment(self, name, model_uri=None, flavor=None, config=None, endpoint=None):
        return {"flavor": flavor}

    def list_deployments(self, endpoint=None):
        if os.environ.get("raiseError") == "True":
            raise RuntimeError("Error requested")
        return [{"name": f_deployment_name}]

    def get_deployment(self, name, endpoint=None):
        return {"key1": "val1", "key2": "val2"}

    def predict(self, deployment_name=None, inputs=None, endpoint=None):
        return PredictionsResponse.from_json('{"predictions": [1,2,3]}')

    def explain(self, deployment_name=None, df=None, endpoint=None):
        return "1"

    def create_endpoint(self, name, config=None):
        if config and config.get("raiseError") == "True":
            raise RuntimeError("Error requested")
        return {"name": f_endpoint_name}

    def update_endpoint(self, endpoint, config=None):
        return None

    def delete_endpoint(self, endpoint):
        return None

    def list_endpoints(self):
        return [{"name": f_endpoint_name}]

    def get_endpoint(self, endpoint):
        return {"name": f_endpoint_name}


def run_local(name, model_uri, flavor=None, config=None):
    print(  # noqa: T201
        f"Deployed locally at the key {name} using the model from {model_uri}. "
        f"It's flavor is {flavor} and config is {config}"
    )


def target_help():
    return "Target help is called"
tests/metrics/genai/test_model_utils.py:464:        mock_get_deploy_client().predict.return_value = _TEST_CHAT_RESPONSE
tests/metrics/genai/test_model_utils.py:492:        mock_get_deploy_client().predict.return_value = _TEST_COMPLETION_RESPONSE
tests/metrics/genai/test_model_utils.py:511:        mock_get_deploy_client().predict.return_value = _TEST_CHAT_RESPONSE
tests/metrics/genai/test_model_utils.py:530:        mock_get_deploy_client().predict.return_value = _TEST_COMPLETION_RESPONSE
tests/metrics/genai/test_model_utils.py:542:        mock_get_deploy_client().predict.return_value = {"result": "ok"}
tests/prompt/test_promptlab_model.py:5:from mlflow.deployments import set_deployments_target
tests/prompt/test_promptlab_model.py:9:set_deployments_target("http://localhost:5000")
tests/deployments/databricks/test_databricks.py:17:def test_get_deploy_client():
tests/deployments/test_interface.py:11:    assert get_deploy_client() is None
tests/deployments/test_interface.py:16:    assert get_deploy_client(None) is None
tests/deployments/test_interface.py:19:def test_get_deploy_client_from_set_deployments_target():
tests/deployments/test_interface.py:20:    from mlflow.deployments import set_deployments_target
tests/deployments/test_interface.py:22:    set_deployments_target("databricks")
tests/deployments/test_interface.py:23:    assert get_deploy_client(None) is not None
tests/deployments/test_interface.py:32:    assert get_deploy_client(None) is not None
tests/deployments/test_utils.py:5:    set_deployments_target,
tests/deployments/test_utils.py:10:def test_set_deployments_target(monkeypatch):
tests/deployments/test_utils.py:14:    set_deployments_target(valid_target)
tests/deployments/test_utils.py:18:    set_deployments_target(valid_uri)
tests/deployments/test_utils.py:25:        set_deployments_target(invalid_uri)
tests/deployments/test_utils.py:40:    set_deployments_target(valid_uri)
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _get_http_response_with_retries\" -B5 -A90 mlflow/utils/request_utils.py
grep -R -n \"_get_http_response_with_retries\" mlflow tests --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/utils/request_utils.py:270:    return _get_http_response_with_retries(
tests/utils/test_rest_utils.py:485:        "mlflow.utils.rest_utils._get_http_response_with_retries"
tests/utils/test_rest_utils.py:486:    ) as mock_get_http_response_with_retries:
tests/utils/test_rest_utils.py:493:        mock_get_http_response_with_retries.assert_called_with(
tests/utils/test_rest_utils.py:506:        mock_get_http_response_with_retries.reset_mock()
tests/utils/test_rest_utils.py:513:        mock_get_http_response_with_retries.assert_called_with(
```

## 原始行 61 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/utils/request_utils.py | sed -n '1,300p'"
```

退出码：`0`

输出：
```
     1	# DO NO IMPORT MLFLOW IN THIS FILE.
     2	# This file is imported by download_cloud_file_chunk.py.
     3	# Importing mlflow is time-consuming and we want to avoid that in artifact download subprocesses.
     4	import os
     5	import random
     6	from functools import lru_cache
     7	
     8	import requests
     9	import urllib3
    10	from packaging.version import Version
    11	from requests.adapters import HTTPAdapter
    12	from requests.exceptions import HTTPError
    13	from urllib3.util import Retry
    14	
    15	# Response codes that generally indicate transient network failures and merit client retries,
    16	# based on guidance from cloud service providers
    17	# (https://docs.microsoft.com/en-us/azure/architecture/best-practices/retry-service-specific#general-rest-and-retry-guidelines)
    18	_TRANSIENT_FAILURE_RESPONSE_CODES = frozenset(
    19	    [
    20	        408,  # Request Timeout
    21	        429,  # Too Many Requests
    22	        500,  # Internal Server Error
    23	        502,  # Bad Gateway
    24	        503,  # Service Unavailable
    25	        504,  # Gateway Timeout
    26	    ]
    27	)
    28	
    29	
    30	class JitteredRetry(Retry):
    31	    """
    32	    urllib3 < 2 doesn't support `backoff_jitter`. This class is a workaround for that.
    33	    """
    34	
    35	    def __init__(self, *args, backoff_jitter=0.0, **kwargs):
    36	        super().__init__(*args, **kwargs)
    37	        self.backoff_jitter = backoff_jitter
    38	
    39	    def get_backoff_time(self):
    40	        """
    41	        Source: https://github.com/urllib3/urllib3/commit/214b184923388328919b0a4b0c15bff603aa51be
    42	        """
    43	        backoff_value = super().get_backoff_time()
    44	        if self.backoff_jitter != 0.0:
    45	            backoff_value += random.random() * self.backoff_jitter
    46	        # The attribute `BACKOFF_MAX` was renamed to `DEFAULT_BACKOFF_MAX` in this commit:
    47	        # https://github.com/urllib3/urllib3/commit/f69b1c89f885a74429cabdee2673e030b35979f0
    48	        # which was part of the major release of 2.0 for urllib3 and the support for both
    49	        # constants was added in 1.26.9:
    50	        # https://github.com/urllib3/urllib3/blob/1.26.9/src/urllib3/util/retry.py
    51	        default_backoff = (
    52	            Retry.BACKOFF_MAX
    53	            if Version(urllib3.__version__) < Version("1.26.9")
    54	            else Retry.DEFAULT_BACKOFF_MAX
    55	        )
    56	
    57	        return float(max(0, min(default_backoff, backoff_value)))
    58	
    59	
    60	def augmented_raise_for_status(response):
    61	    """Wrap the standard `requests.response.raise_for_status()` method and return reason"""
    62	    try:
    63	        response.raise_for_status()
    64	    except HTTPError as e:
    65	        if response.text:
    66	            raise HTTPError(
    67	                f"{e}. Response text: {response.text}", request=e.request, response=e.response
    68	            )
    69	        else:
    70	            raise e
    71	
    72	
    73	def download_chunk(*, range_start, range_end, headers, download_path, http_uri):
    74	    combined_headers = {**headers, "Range": f"bytes={range_start}-{range_end}"}
    75	
    76	    with cloud_storage_http_request(
    77	        "get",
    78	        http_uri,
    79	        stream=False,
    80	        headers=combined_headers,
    81	        timeout=10,
    82	    ) as response:
    83	        expected_length = response.headers.get("Content-Length")
    84	        if expected_length is not None:
    85	            actual_length = response.raw.tell()
    86	            expected_length = int(expected_length)
    87	            if actual_length < expected_length:
    88	                raise IOError(
    89	                    "Incomplete read ({} bytes read, {} more expected)".format(
    90	                        actual_length, expected_length - actual_length
    91	                    )
    92	                )
    93	        # File will have been created upstream. Use r+b to ensure chunks
    94	        # don't overwrite the entire file.
    95	        augmented_raise_for_status(response)
    96	        with open(download_path, "r+b") as f:
    97	            f.seek(range_start)
    98	            f.write(response.content)
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	
   210	
   211	
   212	
   213	
   214	
   215	
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	def cloud_storage_http_request(
   241	    method,
   242	    url,
   243	    max_retries=5,
   244	    backoff_factor=2,
   245	    backoff_jitter=1.0,
   246	    retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,
   247	    timeout=None,
   248	    **kwargs,
   249	):
   250	    """Performs an HTTP PUT/GET/PATCH request using Python's `requests` module with automatic retry.
   251	
   252	    Args:
   253	        method: string of 'PUT' or 'GET' or 'PATCH', specify to do http PUT or GET or PATCH.
   254	        url: the target URL address for the HTTP request.
   255	        max_retries: maximum number of retries before throwing an exception.
   256	        backoff_factor: a time factor for exponential backoff. e.g. value 5 means the HTTP
   257	            request will be retried with interval 5, 10, 20... seconds. A value of 0 turns off the
   258	            exponential backoff.
   259	        backoff_jitter: A random jitter to add to the backoff interval.
   260	        retry_codes: a list of HTTP response error codes that qualifies for retry.
   261	        timeout: wait for timeout seconds for response from remote server for connect and
   262	            read request. Default to None owing to long duration operation in read / write.
   263	        kwargs: Additional keyword arguments to pass to `requests.Session.request()`.
   264	
   265	    Returns:
   266	        requests.Response object.
   267	    """
   268	    if method.lower() not in ("put", "get", "patch", "delete"):
   269	        raise ValueError("Illegal http method: " + method)
   270	    return _get_http_response_with_retries(
   271	        method,
   272	        url,
   273	        max_retries,
   274	        backoff_factor,
   275	        backoff_jitter,
   276	        retry_codes,
   277	        timeout=timeout,
   278	        **kwargs,
   279	    )
```

## 原始行 63 · command_execution

命令：
```
/bin/bash -lc "cat tests/deployments/test_interface.py
cat tests/deployments/databricks/test_databricks.py
sed -n '1,250p' mlflow/deployments/mlflow/__init__.py
sed -n '1,120p' mlflow/deployments/databricks/__init__.py
sed -n '1,100p' mlflow/deployments/openai/__init__.py"
```

退出码：`0`

输出：
```
import pytest

import mlflow.deployments.utils
from mlflow.deployments.interface import get_deploy_client

mlflow.deployments.utils._deployments_target = None


def test_get_deploy_client_no_args():
    mlflow.deployments.utils._deployments_target = None
    assert get_deploy_client() is None


def test_get_deploy_client_none():
    mlflow.deployments.utils._deployments_target = None
    assert get_deploy_client(None) is None


def test_get_deploy_client_from_set_deployments_target():
    from mlflow.deployments import set_deployments_target

    set_deployments_target("databricks")
    assert get_deploy_client(None) is not None


@pytest.fixture
def set_deployment_envs(monkeypatch):
    monkeypatch.setenv("MLFLOW_DEPLOYMENTS_TARGET", "databricks")


def test_get_deploy_client_from_env(set_deployment_envs):
    assert get_deploy_client(None) is not None
import os
import warnings
from unittest import mock

import pytest

from mlflow.deployments import get_deploy_client
from mlflow.exceptions import MlflowException


@pytest.fixture(autouse=True)
def mock_databricks_credentials(monkeypatch):
    monkeypatch.setenv("DATABRICKS_HOST", "https://test.cloud.databricks.com")
    monkeypatch.setenv("DATABRICKS_TOKEN", "secret")


def test_get_deploy_client():
    get_deploy_client("databricks")
    get_deploy_client("databricks://scope:prefix")


def test_create_endpoint():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.create_endpoint(
            name="test",
            config={
                "served_entities": [
                    {
                        "name": "test",
                        "external_model": {
                            "name": "gpt-4",
                            "provider": "openai",
                            "openai_config": {
                                "openai_api_key": "secret",
                            },
                        },
                    }
                ],
                "task": "llm/v1/chat",
            },
        )
        mock_request.assert_called_once()
        assert resp == {"name": "test"}


def test_create_endpoint_config_only():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.create_endpoint(
            config={
                "name": "test_new",
                "config": {
                    "served_entities": [
                        {
                            "name": "test_entity",
                            "external_model": {
                                "name": "gpt-4",
                                "provider": "openai",
                                "task": "llm/v1/chat",
                                "openai_config": {
                                    "openai_api_key": "secret",
                                },
                            },
                        }
                    ],
                    "route_optimized": True,
                },
            },
        )
        mock_request.assert_called_once()
        assert resp == {"name": "test"}


def test_create_endpoint_name_match():
    """Test when name is provided both in config and as named arg with matching values.
    Should emit a deprecation warning about using name parameter.
    """
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        with pytest.warns(
            UserWarning,
            match="Passing 'name' as a parameter is deprecated. "
            "Please specify 'name' only within the config dictionary.",
        ):
            resp = client.create_endpoint(
                name="test",
                config={
                    "name": "test",
                    "config": {
                        "served_entities": [
                            {
                                "name": "test",
                                "external_model": {
                                    "name": "gpt-4",
                                    "provider": "openai",
                                    "openai_config": {
                                        "openai_api_key": "secret",
                                    },
                                },
                            }
                        ],
                        "task": "llm/v1/chat",
                    },
                },
            )
        mock_request.assert_called_once()
        assert resp == {"name": "test"}


def test_create_endpoint_name_mismatch():
    """Test when name is provided both in config and as named arg with different values.
    Should raise an MlflowException.
    """
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        with pytest.raises(
            MlflowException,
            match="Name mismatch. Found 'test1' as parameter and 'test2' "
            "in config. Please specify 'name' only within the config "
            "dictionary as this parameter is deprecated.",
        ):
            client.create_endpoint(
                name="test1",
                config={
                    "name": "test2",
                    "config": {
                        "served_entities": [
                            {
                                "name": "test",
                                "external_model": {
                                    "name": "gpt-4",
                                    "provider": "openai",
                                    "openai_config": {
                                        "openai_api_key": "secret",
                                    },
                                },
                            }
                        ],
                        "task": "llm/v1/chat",
                    },
                },
            )
        mock_request.assert_not_called()


def test_create_endpoint_route_optimized_match():
    """Test when route_optimized is provided both in config and as named arg with matching values.
    Should emit a deprecation warning.
    """
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        with pytest.warns(
            UserWarning,
            match="Passing 'route_optimized' as a parameter is deprecated. "
            "Please specify 'route_optimized' only within the config dictionary.",
        ):
            resp = client.create_endpoint(
                name="test",
                route_optimized=True,
                config={
                    "name": "test",
                    "route_optimized": True,
                    "config": {
                        "served_entities": [
                            {
                                "name": "test",
                                "external_model": {
                                    "name": "gpt-4",
                                    "provider": "openai",
                                    "openai_config": {
                                        "openai_api_key": "secret",
                                    },
                                },
                            }
                        ],
                        "task": "llm/v1/chat",
                    },
                },
            )
        mock_request.assert_called_once()
        assert resp == {"name": "test"}


def test_create_endpoint_route_optimized_mismatch():
    """Test when route_optimized is provided both in config and as named arg with different values.
    Should raise an MlflowException.
    """
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        with pytest.raises(
            MlflowException,
            match="Conflicting 'route_optimized' values found. "
            "Please specify 'route_optimized' only within the config dictionary "
            "as this parameter is deprecated.",
        ):
            client.create_endpoint(
                name="test",
                route_optimized=True,
                config={
                    "name": "test",
                    "route_optimized": False,
                    "config": {
                        "served_entities": [
                            {
                                "name": "test",
                                "external_model": {
                                    "name": "gpt-4",
                                    "provider": "openai",
                                    "openai_config": {
                                        "openai_api_key": "secret",
                                    },
                                },
                            }
                        ],
                        "task": "llm/v1/chat",
                    },
                },
            )
        mock_request.assert_not_called()


def test_create_endpoint_named_name():
    """Test using the legacy format with separate parameters instead of full API payload.
    Should emit a deprecation warning about the old format.
    """
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        with pytest.warns(
            UserWarning,
            match="Passing 'name', 'config', and 'route_optimized' as separate parameters is "
            "deprecated. Please pass the full API request payload as a single dictionary "
            "in the 'config' parameter.",
        ):
            resp = client.create_endpoint(
                name="test",
                config={
                    "served_entities": [
                        {
                            "name": "test",
                            "external_model": {
                                "name": "gpt-4",
                                "provider": "openai",
                                "openai_config": {
                                    "openai_api_key": "secret",
                                },
                            },
                        }
                    ],
                    "task": "llm/v1/chat",
                },
            )
        mock_request.assert_called_once()
        assert resp == {"name": "test"}


def test_create_endpoint_named_route_optimized():
    """Test using the legacy format with route_optimized parameter.
    Should emit a deprecation warning about the old format.
    """
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        with pytest.warns(
            UserWarning,
            match="Passing 'name', 'config', and 'route_optimized' as separate parameters is "
            "deprecated. Please pass the full API request payload as a single dictionary "
            "in the 'config' parameter.",
        ):
            resp = client.create_endpoint(
                name="test",
                route_optimized=True,
                config={
                    "served_entities": [
                        {
                            "name": "test",
                            "external_model": {
                                "name": "gpt-4",
                                "provider": "openai",
                                "openai_config": {
                                    "openai_api_key": "secret",
                                },
                            },
                        }
                    ],
                    "task": "llm/v1/chat",
                },
            )
        mock_request.assert_called_once()
        assert resp == {"name": "test"}


def test_get_endpoint():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"name": "test"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.get_endpoint(endpoint="test")
        mock_request.assert_called_once()
        assert resp == {"name": "test"}


def test_list_endpoints():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"endpoints": [{"name": "test"}]}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.list_endpoints()
        mock_request.assert_called_once()
        assert resp == [{"name": "test"}]


def test_update_endpoint():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        with pytest.warns(
            UserWarning,
            match="The `update_endpoint` method is deprecated. Use the specific update methods—"
            "`update_endpoint_config`, `update_endpoint_tags`, `update_endpoint_rate_limits`, "
            "`update_endpoint_ai_gateway`—instead.",
        ):
            resp = client.update_endpoint(
                endpoint="test",
                config={
                    "served_entities": [
                        {
                            "name": "test",
                            "external_model": {
                                "name": "gpt-4",
                                "provider": "openai",
                                "openai_config": {
                                    "openai_api_key": "secret",
                                },
                            },
                        }
                    ],
                    "task": "llm/v1/chat",
                },
            )
        mock_request.assert_called_once()
        assert resp == {}


def test_update_endpoint_config():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.update_endpoint_config(
            endpoint="test",
            config={
                "served_entities": [
                    {
                        "name": "gpt-4-mini",
                        "external_model": {
                            "name": "gpt-4-mini",
                            "provider": "openai",
                            "task": "llm/v1/chat",
                            "openai_config": {
                                "openai_api_key": "{{secrets/scope/key}}",
                            },
                        },
                    }
                ],
            },
        )
        mock_request.assert_called_once()
        assert resp == {}


def test_update_endpoint_tags():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.update_endpoint_tags(
            endpoint="test",
            config={"add_tags": [{"key": "project", "value": "test"}]},
        )
        mock_request.assert_called_once()
        assert resp == {}


def test_update_endpoint_rate_limits():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.update_endpoint_rate_limits(
            endpoint="test",
            config={"rate_limits": [{"calls": 10, "key": "endpoint", "renewal_period": "minute"}]},
        )
        mock_request.assert_called_once()
        assert resp == {}


def test_update_endpoint_ai_gateway():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.update_endpoint_ai_gateway(
            endpoint="test",
            config={
                "usage_tracking_config": {"enabled": True},
                "inference_table_config": {
                    "enabled": True,
                    "catalog_name": "my_catalog",
                    "schema_name": "my_schema",
                },
            },
        )
        mock_request.assert_called_once()
        assert resp == {}


def test_delete_endpoint():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.delete_endpoint(endpoint="test")
        mock_request.assert_called_once()
        assert resp == {}


def test_predict():
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"foo": "bar"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    with mock.patch("requests.Session.request", return_value=mock_resp) as mock_request:
        resp = client.predict(endpoint="test", inputs={})
        mock_request.assert_called_once()
        assert resp == {"foo": "bar"}


def test_predict_with_total_timeout_env_var(monkeypatch):
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT", "900")
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"foo": "bar"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with mock.patch(
        "mlflow.deployments.databricks.http_request", return_value=mock_resp
    ) as mock_http:
        resp = client.predict(endpoint="test", inputs={})
        mock_http.assert_called_once()
        call_kwargs = mock_http.call_args[1]
        assert call_kwargs["retry_timeout_seconds"] == 900
        assert resp == {"foo": "bar"}


def test_predict_stream_with_total_timeout_env_var(monkeypatch):
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT", "900")
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.iter_lines.return_value = [
        "data: " + '{"id": "1", "choices": [{"delta": {"content": "Hello"}}]}',
        "data: [DONE]",
    ]
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    mock_resp.encoding = "utf-8"

    with mock.patch(
        "mlflow.deployments.databricks.http_request", return_value=mock_resp
    ) as mock_http:
        chunks = list(client.predict_stream(endpoint="test", inputs={}))
        mock_http.assert_called_once()
        call_kwargs = mock_http.call_args[1]
        assert call_kwargs["retry_timeout_seconds"] == 900
        assert len(chunks) == 1


def test_predict_warns_on_misconfigured_timeouts(monkeypatch):
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT", "300")
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT", "120")
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"foo": "bar"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with mock.patch(
        "mlflow.deployments.databricks.http_request", return_value=mock_resp
    ) as mock_http:
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            resp = client.predict(endpoint="test", inputs={})

        mock_http.assert_called_once()
        assert resp == {"foo": "bar"}
        assert len(w) == 1
        warning_msg = str(w[0].message)
        assert "MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT" in warning_msg
        assert "(120s)" in warning_msg
        assert "(300s)" in warning_msg


def test_predict_stream_warns_on_misconfigured_timeouts(monkeypatch):
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT", "300")
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT", "120")
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.iter_lines.return_value = [
        "data: " + '{"id": "1", "choices": [{"delta": {"content": "Hello"}}]}',
        "data: [DONE]",
    ]
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200
    mock_resp.encoding = "utf-8"

    with mock.patch(
        "mlflow.deployments.databricks.http_request", return_value=mock_resp
    ) as mock_http:
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            chunks = list(client.predict_stream(endpoint="test", inputs={}))

        mock_http.assert_called_once()
        assert len(chunks) == 1
        assert len(w) == 1
        warning_msg = str(w[0].message)
        assert "MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT" in warning_msg
        assert "(120s)" in warning_msg
        assert "(300s)" in warning_msg


def test_predict_no_warning_when_timeouts_properly_configured(monkeypatch):
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT", "120")
    monkeypatch.setenv("MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT", "600")
    client = get_deploy_client("databricks")
    mock_resp = mock.Mock()
    mock_resp.json.return_value = {"foo": "bar"}
    mock_resp.url = os.environ["DATABRICKS_HOST"]
    mock_resp.status_code = 200

    with (
        mock.patch(
            "mlflow.deployments.databricks.http_request", return_value=mock_resp
        ) as mock_http,
        mock.patch("mlflow.utils.rest_utils._logger.warning") as mock_warning,
    ):
        resp = client.predict(endpoint="test", inputs={})
        mock_http.assert_called_once()
        assert resp == {"foo": "bar"}
        mock_warning.assert_not_called()
from typing import TYPE_CHECKING, Any

import requests

from mlflow import MlflowException
from mlflow.deployments import BaseDeploymentClient
from mlflow.deployments.constants import (
    MLFLOW_DEPLOYMENT_CLIENT_REQUEST_RETRY_CODES,
)
from mlflow.deployments.server.constants import (
    MLFLOW_DEPLOYMENTS_CRUD_ENDPOINT_BASE,
    MLFLOW_DEPLOYMENTS_ENDPOINTS_BASE,
    MLFLOW_DEPLOYMENTS_QUERY_SUFFIX,
)
from mlflow.deployments.utils import resolve_endpoint_url
from mlflow.environment_variables import (
    MLFLOW_DEPLOYMENT_CLIENT_HTTP_REQUEST_TIMEOUT,
    MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT,
)
from mlflow.protos.databricks_pb2 import BAD_REQUEST
from mlflow.store.entities.paged_list import PagedList
from mlflow.utils.credentials import get_default_host_creds
from mlflow.utils.rest_utils import augmented_raise_for_status
from mlflow.utils.uri import join_paths

if TYPE_CHECKING:
    from mlflow.deployments.server.config import Endpoint


class MlflowDeploymentClient(BaseDeploymentClient):
    """
    Client for interacting with the MLflow AI Gateway.

    Example:

    First, start the MLflow AI Gateway:

    .. code-block:: bash

        mlflow gateway start --config-path path/to/config.yaml

    Then, create a client and use it to interact with the server:

    .. code-block:: python

        from mlflow.deployments import get_deploy_client

        client = get_deploy_client("http://localhost:5000")
        endpoints = client.list_endpoints()
        assert [e.dict() for e in endpoints] == [
            {
                "name": "chat",
                "endpoint_type": "llm/v1/chat",
                "model": {"name": "gpt-4o-mini", "provider": "openai"},
                "endpoint_url": "http://localhost:5000/gateway/chat/invocations",
            },
        ]
    """

    def create_deployment(self, name, model_uri, flavor=None, config=None, endpoint=None):
        """
        .. warning::
            This method is not implemented for `MlflowDeploymentClient`.
        """
        raise NotImplementedError

    def update_deployment(self, name, model_uri=None, flavor=None, config=None, endpoint=None):
        """
        .. warning::
            This method is not implemented for `MlflowDeploymentClient`.
        """
        raise NotImplementedError

    def delete_deployment(self, name, config=None, endpoint=None):
        """
        .. warning::
            This method is not implemented for `MlflowDeploymentClient`.
        """
        raise NotImplementedError

    def list_deployments(self, endpoint=None):
        """
        .. warning::
            This method is not implemented for `MlflowDeploymentClient`.
        """
        raise NotImplementedError

    def get_deployment(self, name, endpoint=None):
        """
        .. warning::
            This method is not implemented for `MLflowDeploymentClient`.
        """
        raise NotImplementedError

    def create_endpoint(self, name, config=None):
        """
        .. warning::
            This method is not implemented for `MlflowDeploymentClient`.
        """
        raise NotImplementedError

    def update_endpoint(self, endpoint, config=None):
        """
        .. warning::
            This method is not implemented for `MlflowDeploymentClient`.
        """
        raise NotImplementedError

    def delete_endpoint(self, endpoint):
        """
        .. warning::
            This method is not implemented for `MlflowDeploymentClient`.
        """
        raise NotImplementedError

    def _call_endpoint(
        self,
        method: str,
        route: str,
        json_body: str | None = None,
        timeout: int | None = None,
    ):
        call_kwargs = {}
        if method.lower() == "get":
            call_kwargs["params"] = json_body
        else:
            call_kwargs["json"] = json_body

        response = http_request(
            host_creds=get_default_host_creds(self.target_uri),
            endpoint=route,
            method=method,
            timeout=MLFLOW_DEPLOYMENT_CLIENT_HTTP_REQUEST_TIMEOUT.get()
            if timeout is None
            else timeout,
            retry_codes=MLFLOW_DEPLOYMENT_CLIENT_REQUEST_RETRY_CODES,
            raise_on_status=False,
            **call_kwargs,
        )
        augmented_raise_for_status(response)
        return response.json()

    def get_endpoint(self, endpoint) -> "Endpoint":
        """
        Gets a specified endpoint configured for the MLflow AI Gateway.

        Args:
            endpoint: The name of the endpoint to retrieve.

        Returns:
            An `Endpoint` object representing the endpoint.

        Example:

        .. code-block:: python

            from mlflow.deployments import get_deploy_client

            client = get_deploy_client("http://localhost:5000")
            endpoint = client.get_endpoint(endpoint="chat")
            assert endpoint.dict() == {
                "name": "chat",
                "endpoint_type": "llm/v1/chat",
                "model": {"name": "gpt-4o-mini", "provider": "openai"},
                "endpoint_url": "http://localhost:5000/gateway/chat/invocations",
            }
        """
        # Delayed import to avoid importing mlflow.gateway in the module scope


        route = join_paths(MLFLOW_DEPLOYMENTS_CRUD_ENDPOINT_BASE, endpoint)
        response = self._call_endpoint("GET", route)
        return Endpoint(
            **{
                **response,
                "endpoint_url": resolve_endpoint_url(self.target_uri, response["endpoint_url"]),
            }
        )

    def _list_endpoints(self, page_token=None) -> "PagedList[Endpoint]":
        # Delayed import to avoid importing mlflow.gateway in the module scope


        params = None if page_token is None else {"page_token": page_token}
        response_json = self._call_endpoint(
            "GET", MLFLOW_DEPLOYMENTS_CRUD_ENDPOINT_BASE, json_body=params
        )
        routes = [
            Endpoint(
                **{
                    **resp,
                    "endpoint_url": resolve_endpoint_url(
                        self.target_uri,
                        resp["endpoint_url"],
                    ),
                }
            )
            for resp in response_json.get("endpoints", [])
        ]
        next_page_token = response_json.get("next_page_token")
        return PagedList(routes, next_page_token)

    def list_endpoints(self) -> "list[Endpoint]":
        """
        List endpoints configured for the MLflow AI Gateway.

        Returns:
            A list of ``Endpoint`` objects.

        Example:

        .. code-block:: python

            from mlflow.deployments import get_deploy_client

            client = get_deploy_client("http://localhost:5000")

            endpoints = client.list_endpoints()
            assert [e.dict() for e in endpoints] == [
                {
                    "name": "chat",
                    "endpoint_type": "llm/v1/chat",
                    "model": {"name": "gpt-4o-mini", "provider": "openai"},
                    "endpoint_url": "http://localhost:5000/gateway/chat/invocations",
                },
            ]

        """
        endpoints = []
        next_page_token = None
        while True:
            page = self._list_endpoints(next_page_token)
            endpoints.extend(page)
            next_page_token = page.token
            if next_page_token is None:
                break
        return endpoints

    def predict(self, deployment_name=None, inputs=None, endpoint=None) -> dict[str, Any]:
        """
        Submit a query to a configured provider endpoint.

        Args:
            deployment_name: Unused.
            inputs: The inputs to the query, as a dictionary.
            endpoint: The name of the endpoint to query.

        Returns:
            A dictionary containing the response from the endpoint.

import json
import posixpath
import warnings
from typing import Any, Iterator

from mlflow.deployments import BaseDeploymentClient
from mlflow.deployments.constants import (
    MLFLOW_DEPLOYMENT_CLIENT_REQUEST_RETRY_CODES,
)
from mlflow.environment_variables import (
    MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT,
    MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT,
    MLFLOW_HTTP_REQUEST_TIMEOUT,
)
from mlflow.exceptions import MlflowException
from mlflow.utils import AttrDict
from mlflow.utils.annotations import deprecated
from mlflow.utils.databricks_utils import get_databricks_host_creds
from mlflow.utils.rest_utils import augmented_raise_for_status, validate_deployment_timeout_config






class DatabricksEndpoint(AttrDict):
    """
    A dictionary-like object representing a Databricks serving endpoint.

    .. code-block:: python

        endpoint = DatabricksEndpoint(
            {
                "name": "chat",
                "creator": "alice@company.com",
                "creation_timestamp": 0,
                "last_updated_timestamp": 0,
                "state": {...},
                "config": {...},
                "tags": [...],
                "id": "88fd3f75a0d24b0380ddc40484d7a31b",
            }
        )
        assert endpoint.name == "chat"
    """


class DatabricksDeploymentClient(BaseDeploymentClient):
    """
    Client for interacting with Databricks serving endpoints.

    Example:

    First, set up credentials for authentication:

    .. code-block:: bash

        export DATABRICKS_HOST=...
        export DATABRICKS_TOKEN=...

    .. seealso::

        See https://docs.databricks.com/en/dev-tools/auth.html for other authentication methods.

    Then, create a deployment client and use it to interact with Databricks serving endpoints:

    .. code-block:: python

        from mlflow.deployments import get_deploy_client

        client = get_deploy_client("databricks")
        endpoints = client.list_endpoints()
        assert endpoints == [
            {
                "name": "chat",
                "creator": "alice@company.com",
                "creation_timestamp": 0,
                "last_updated_timestamp": 0,
                "state": {...},
                "config": {...},
                "tags": [...],
                "id": "88fd3f75a0d24b0380ddc40484d7a31b",
            },
        ]
    """

    def create_deployment(self, name, model_uri, flavor=None, config=None, endpoint=None):
        """
        .. warning::

            This method is not implemented for `DatabricksDeploymentClient`.
        """
        raise NotImplementedError

    def update_deployment(self, name, model_uri=None, flavor=None, config=None, endpoint=None):
        """
        .. warning::

            This method is not implemented for `DatabricksDeploymentClient`.
        """
        raise NotImplementedError

    def delete_deployment(self, name, config=None, endpoint=None):
        """
        .. warning::

            This method is not implemented for `DatabricksDeploymentClient`.
        """
        raise NotImplementedError

    def list_deployments(self, endpoint=None):
        """
        .. warning::

            This method is not implemented for `DatabricksDeploymentClient`.
        """
        raise NotImplementedError

    def get_deployment(self, name, endpoint=None):
        """
import os

from mlflow.deployments import BaseDeploymentClient
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.utils.openai_utils import (
    _OAITokenHolder,
    _OpenAIApiConfig,
    _OpenAIEnvVar,
)
from mlflow.utils.rest_utils import augmented_raise_for_status


class OpenAIDeploymentClient(BaseDeploymentClient):
    """
    Client for interacting with OpenAI endpoints.

    Example:

    First, set up credentials for authentication:

    .. code-block:: bash

        export OPENAI_API_KEY=...

    .. seealso::

        See https://mlflow.org/docs/latest/python_api/openai/index.html for other authentication
        methods.

    Then, create a deployment client and use it to interact with OpenAI endpoints:

    .. code-block:: python

        from mlflow.deployments import get_deploy_client

        client = get_deploy_client("openai")
        client.predict(
            endpoint="gpt-4o-mini",
            inputs={
                "messages": [
                    {"role": "user", "content": "Hello!"},
                ],
            },
        )
    """

    def create_deployment(self, name, model_uri, flavor=None, config=None, endpoint=None):
        """
        .. warning::

            This method is not implemented for `OpenAIDeploymentClient`.
        """
        raise NotImplementedError

    def update_deployment(self, name, model_uri=None, flavor=None, config=None, endpoint=None):
        """
        .. warning::

            This method is not implemented for `OpenAIDeploymentClient`.
        """
        raise NotImplementedError

    def delete_deployment(self, name, config=None, endpoint=None):
        """
        .. warning::

            This method is not implemented for `OpenAIDeploymentClient`.
        """
        raise NotImplementedError

    def list_deployments(self, endpoint=None):
        """
        .. warning::

            This method is not implemented for `OpenAIDeploymentClient`.
        """
        raise NotImplementedError

    def get_deployment(self, name, endpoint=None):
        """
        .. warning::

            This method is not implemented for `OpenAIDeploymentClient`.
        """
        raise NotImplementedError

    def predict(self, deployment_name=None, inputs=None, endpoint=None):
        """Query an OpenAI endpoint.
        See https://platform.openai.com/docs/api-reference for more information.

        Args:
            deployment_name: Unused.
            inputs: A dictionary containing the model inputs to query.
            endpoint: The name of the endpoint to query.

        Returns:
            A dictionary containing the model outputs.

        """
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"request_headers()\\|_request_header_provider_registry\" mlflow --include='*.py' | head -100
sed -n '1,140p' mlflow/tracking/request_header/abstract_request_header_provider.py
cat mlflow/tracking/request_header/default_request_header_provider.py
sed -n '1,140p' mlflow/tracking/request_auth/registry.py"
```

退出码：`0`

输出：
```
mlflow/genai/agent_server/utils.py:25:def get_request_headers() -> dict[str, str]:
mlflow/tracking/request_header/registry.py:39:_request_header_provider_registry = RequestHeaderProviderRegistry()
mlflow/tracking/request_header/registry.py:40:_request_header_provider_registry.register(DatabricksRequestHeaderProvider)
mlflow/tracking/request_header/registry.py:41:_request_header_provider_registry.register(DefaultRequestHeaderProvider)
mlflow/tracking/request_header/registry.py:43:_request_header_provider_registry.register_entrypoints()
from abc import ABCMeta, abstractmethod

from mlflow.utils.annotations import developer_stable


@developer_stable
class RequestHeaderProvider:
    """
    Abstract base class for specifying custom request headers to add to outgoing requests
    (e.g. request headers specifying the environment from which mlflow is running).

    When a request is sent, MLflow will iterate through all registered RequestHeaderProviders.
    For each provider where ``in_context`` returns ``True``, MLflow calls the ``request_headers``
    method on the provider to compute request headers.

    All resulting request headers will then be merged together and sent with the request.
    """

    __metaclass__ = ABCMeta

    @abstractmethod
    def in_context(self):
        """Determine if MLflow is running in this context.

        Returns:
            bool indicating if in this context.

        """

    @abstractmethod
    def request_headers(self):
        """Generate context-specific request headers.

        Returns:
            dict of request headers.
        """
from mlflow import __version__
from mlflow.tracking.request_header.abstract_request_header_provider import RequestHeaderProvider

_USER_AGENT = "User-Agent"
_CLIENT_VERSION = "X-MLflow-Client-Version"
# We need to specify client version in separate header as user agent is overwritten in SDK call path
_DEFAULT_HEADERS = {
    _USER_AGENT: f"mlflow-python-client/{__version__}",
    _CLIENT_VERSION: f"{__version__}",
}


class DefaultRequestHeaderProvider(RequestHeaderProvider):
    """
    Provides default request headers for outgoing request.
    """


import warnings

from mlflow.utils.plugins import get_entry_points

REQUEST_AUTH_PROVIDER_ENTRYPOINT = "mlflow.request_auth_provider"


class RequestAuthProviderRegistry:
    def __init__(self):
        self._registry = []

    def register(self, request_auth_provider):
        self._registry.append(request_auth_provider())

    def register_entrypoints(self):
        for entrypoint in get_entry_points(REQUEST_AUTH_PROVIDER_ENTRYPOINT):
            try:
                self.register(entrypoint.load())
            except (AttributeError, ImportError) as exc:
                warnings.warn(
                    'Failure attempting to register request auth provider "{}": {}'.format(
                        entrypoint.name, str(exc)
                    ),
                    stacklevel=2,
                )

    def __iter__(self):
        return iter(self._registry)


_request_auth_provider_registry = RequestAuthProviderRegistry()
_request_auth_provider_registry.register_entrypoints()


def fetch_auth(request_auth):
    """
    Find the request auth from registered providers based on the auth provider's name.
    The auth provider's name can be provided through environment variable `MLFLOW_TRACKING_AUTH`.

    This function iterates through all request auth providers in the registry. Additional context
    providers can be registered as described in
    :py:class:`mlflow.tracking.request_auth.RequestAuthProvider`.

    Args:
        request_auth: The name of request auth provider.

    Returns:
        The auth object.
    """

    for auth_provider in _request_auth_provider_registry:
        if auth_provider.get_name() == request_auth:
            return auth_provider.get_auth()

    warnings.warn(
        f"Could not find any registered plugin for {request_auth}. "
        "No authentication header will be added. Please check your "
        "provider documentation for installing the right plugin or "
        "correct provider name."
    )
```

## 原始行 67 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"MLFLOW_ENABLE_DB_SDK\\|client_secret\" tests/utils tests --include='*.py' | head -100
grep -n \"class InvalidUrlException\\|ERROR_CODE_TO_HTTP_STATUS\\|CUSTOMER_UNAUTHORIZED\" mlflow/exceptions.py
sed -n '1,160p' mlflow/exceptions.py"
```

退出码：`0`

输出：
```
9:    CUSTOMER_UNAUTHORIZED,
29:ERROR_CODE_TO_HTTP_STATUS = {
46:    ErrorCode.Name(CUSTOMER_UNAUTHORIZED): 401,
53:HTTP_STATUS_TO_ERROR_CODE = {v: k for k, v in ERROR_CODE_TO_HTTP_STATUS.items()}
101:        return ERROR_CODE_TO_HTTP_STATUS.get(self.error_code, 500)
159:class InvalidUrlException(MlflowException):
import json
import logging

from mlflow.protos.databricks_pb2 import (
    ABORTED,
    ALREADY_EXISTS,
    BAD_REQUEST,
    CANCELLED,
    CUSTOMER_UNAUTHORIZED,
    DATA_LOSS,
    DEADLINE_EXCEEDED,
    ENDPOINT_NOT_FOUND,
    INTERNAL_ERROR,
    INVALID_PARAMETER_VALUE,
    INVALID_STATE,
    NOT_FOUND,
    NOT_IMPLEMENTED,
    PERMISSION_DENIED,
    REQUEST_LIMIT_EXCEEDED,
    RESOURCE_ALREADY_EXISTS,
    RESOURCE_CONFLICT,
    RESOURCE_DOES_NOT_EXIST,
    RESOURCE_EXHAUSTED,
    TEMPORARILY_UNAVAILABLE,
    UNAUTHENTICATED,
    ErrorCode,
)

ERROR_CODE_TO_HTTP_STATUS = {
    ErrorCode.Name(INTERNAL_ERROR): 500,
    ErrorCode.Name(INVALID_STATE): 500,
    ErrorCode.Name(DATA_LOSS): 500,
    ErrorCode.Name(NOT_IMPLEMENTED): 501,
    ErrorCode.Name(TEMPORARILY_UNAVAILABLE): 503,
    ErrorCode.Name(DEADLINE_EXCEEDED): 504,
    ErrorCode.Name(REQUEST_LIMIT_EXCEEDED): 429,
    ErrorCode.Name(CANCELLED): 499,
    ErrorCode.Name(RESOURCE_EXHAUSTED): 429,
    ErrorCode.Name(ABORTED): 409,
    ErrorCode.Name(RESOURCE_CONFLICT): 409,
    ErrorCode.Name(ALREADY_EXISTS): 409,
    ErrorCode.Name(NOT_FOUND): 404,
    ErrorCode.Name(ENDPOINT_NOT_FOUND): 404,
    ErrorCode.Name(RESOURCE_DOES_NOT_EXIST): 404,
    ErrorCode.Name(PERMISSION_DENIED): 403,
    ErrorCode.Name(CUSTOMER_UNAUTHORIZED): 401,
    ErrorCode.Name(UNAUTHENTICATED): 401,
    ErrorCode.Name(BAD_REQUEST): 400,
    ErrorCode.Name(RESOURCE_ALREADY_EXISTS): 400,
    ErrorCode.Name(INVALID_PARAMETER_VALUE): 400,
}

HTTP_STATUS_TO_ERROR_CODE = {v: k for k, v in ERROR_CODE_TO_HTTP_STATUS.items()}
HTTP_STATUS_TO_ERROR_CODE[400] = ErrorCode.Name(BAD_REQUEST)
HTTP_STATUS_TO_ERROR_CODE[404] = ErrorCode.Name(ENDPOINT_NOT_FOUND)
HTTP_STATUS_TO_ERROR_CODE[500] = ErrorCode.Name(INTERNAL_ERROR)

_logger = logging.getLogger(__name__)


def get_error_code(http_status):
    return ErrorCode.Value(
        HTTP_STATUS_TO_ERROR_CODE.get(http_status, ErrorCode.Name(INTERNAL_ERROR))
    )


class MlflowException(Exception):
    """
    Generic exception thrown to surface failure information about external-facing operations.
    The error message associated with this exception may be exposed to clients in HTTP responses
    for debugging purposes. If the error text is sensitive, raise a generic `Exception` object
    instead.
    """

    def __init__(self, message, error_code=INTERNAL_ERROR, **kwargs):
        """
        Args:
            message: The message or exception describing the error that occurred. This will be
                included in the exception's serialized JSON representation.
            error_code: An appropriate error code for the error that occurred; it will be
                included in the exception's serialized JSON representation. This should
                be one of the codes listed in the `mlflow.protos.databricks_pb2` proto.
            kwargs: Additional key-value pairs to include in the serialized JSON representation
                of the MlflowException.
        """
        try:
            self.error_code = ErrorCode.Name(error_code)
        except (ValueError, TypeError):
            self.error_code = ErrorCode.Name(INTERNAL_ERROR)
        message = str(message)
        self.message = message
        self.json_kwargs = kwargs
        super().__init__(message)

    def serialize_as_json(self):
        exception_dict = {"error_code": self.error_code, "message": self.message}
        exception_dict.update(self.json_kwargs)
        return json.dumps(exception_dict)

    def get_http_status_code(self):
        return ERROR_CODE_TO_HTTP_STATUS.get(self.error_code, 500)

    @classmethod
    def invalid_parameter_value(cls, message, **kwargs):
        """Constructs an `MlflowException` object with the `INVALID_PARAMETER_VALUE` error code.

        Args:
            message: The message describing the error that occurred. This will be included in the
                exception's serialized JSON representation.
            kwargs: Additional key-value pairs to include in the serialized JSON representation
                of the MlflowException.
        """
        return cls(message, error_code=INVALID_PARAMETER_VALUE, **kwargs)


class RestException(MlflowException):
    """Exception thrown on non 200-level responses from the REST API"""

    def __init__(self, json):
        self.json = json

        error_code = json.get("error_code", ErrorCode.Name(INTERNAL_ERROR))
        message = "{}: {}".format(
            error_code,
            json["message"] if "message" in json else "Response: " + str(json),
        )

        try:
            super().__init__(message, error_code=ErrorCode.Value(error_code))
        except ValueError:
            try:
                # The `error_code` can be an http error code, in which case we convert it to the
                # corresponding `ErrorCode`.
                error_code = HTTP_STATUS_TO_ERROR_CODE[int(error_code)]
                super().__init__(message, error_code=ErrorCode.Value(error_code))
            except ValueError or KeyError:
                _logger.warning(
                    f"Received error code not recognized by MLflow: {error_code}, this may "
                    "indicate your request encountered an error before reaching MLflow server, "
                    "e.g., within a proxy server or authentication / authorization service."
                )
                super().__init__(message)

    def __reduce__(self):
        """
        Overriding `__reduce__` to make `RestException` instance pickle-able.
        """
        return RestException, (self.json,)


class ExecutionException(MlflowException):
    """Exception thrown when executing a project fails"""


class MissingConfigException(MlflowException):
    """Exception thrown when expected configuration file/directory not found"""


class InvalidUrlException(MlflowException):
    """Exception thrown when a http request fails to send due to an invalid URL"""
```

## 原始行 70 · command_execution

命令：
```
/bin/bash -lc "sed -n '15,38p' mlflow/deployments/__init__.py
sed -n '1,90p' mlflow/tracking/request_header/databricks_request_header_provider.py
find . -name AGENTS.md -print"
```

退出码：`0`

输出：
```
"""

import contextlib
import json

from mlflow.deployments.base import BaseDeploymentClient
from mlflow.deployments.databricks import DatabricksDeploymentClient, DatabricksEndpoint
from mlflow.deployments.interface import run_local
from mlflow.deployments.openai import OpenAIDeploymentClient
from mlflow.deployments.utils import get_deployments_target, set_deployments_target
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE

with contextlib.suppress(Exception):
    # MlflowDeploymentClient depends on optional dependencies and can't be imported
    # if they are not installed.
    from mlflow.deployments.mlflow import MlflowDeploymentClient


class PredictionsResponse(dict):
    """
    Represents the predictions and metadata returned in response to a scoring request, such as a
    REST API request sent to the ``/invocations`` endpoint of an MLflow Model Server.
    """
from mlflow.tracking.request_header.abstract_request_header_provider import RequestHeaderProvider
from mlflow.utils import databricks_utils


class DatabricksRequestHeaderProvider(RequestHeaderProvider):
    """
    Provides request headers indicating the type of Databricks environment from which a request
    was made.
    """








    def request_headers(self):
        request_headers = {}
        if databricks_utils.is_in_databricks_notebook():
            request_headers["notebook_id"] = databricks_utils.get_notebook_id()
        if databricks_utils.is_in_databricks_job():
            request_headers["job_id"] = databricks_utils.get_job_id()
            request_headers["job_run_id"] = databricks_utils.get_job_run_id()
            request_headers["job_type"] = databricks_utils.get_job_type()
        if databricks_utils.is_in_cluster():
            request_headers["cluster_id"] = databricks_utils.get_cluster_id()
        command_run_id = databricks_utils.get_command_run_id()
        if command_run_id is not None:
            request_headers["command_run_id"] = command_run_id
        workload_id = databricks_utils.get_workload_id()
        workload_class = databricks_utils.get_workload_class()
        if workload_id is not None:
            request_headers["workload_id"] = workload_id
        if workload_class is not None:
            request_headers["workload_class"] = workload_class

        return request_headers./mlflow/server/AGENTS.md
```

## 原始行 73 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"mlflow.deployments\" pyproject.toml setup.py setup.cfg tests/resources/mlflow-test-plugin | head -80
grep -R -n \"plugin_store.register\" mlflow --include='*.py'
grep -n \"class .*DeploymentClient\\|def __init__\" mlflow/deployments/mlflow/__init__.py mlflow/deployments/databricks/__init__.py mlflow/deployments/openai/__init__.py | head -80
python - <<'PY'
import importlib.metadata
for e in importlib.metadata.entry_points(group='mlflow.deployments'):
 print(e)
PY"
```

退出码：`0`

输出：
```
grep: setup.py: No such file or directory
grep: setup.cfg: No such file or directory
pyproject.toml:137:[project.entry-points."mlflow.deployments"]
pyproject.toml:138:databricks = "mlflow.deployments.databricks"
pyproject.toml:139:http = "mlflow.deployments.mlflow"
pyproject.toml:140:https = "mlflow.deployments.mlflow"
pyproject.toml:141:openai = "mlflow.deployments.openai"
tests/resources/mlflow-test-plugin/pyproject.toml:55:[project.entry-points."mlflow.deployments"]
tests/resources/mlflow-test-plugin/mlflow_test_plugin/fake_deployment_plugin.py:3:from mlflow.deployments import BaseDeploymentClient, PredictionsResponse
mlflow/deployments/interface.py:10:plugin_store.register("sagemaker", "mlflow.sagemaker")
mlflow/deployments/mlflow/__init__.py:30:class MlflowDeploymentClient(BaseDeploymentClient):
mlflow/deployments/databricks/__init__.py:48:class DatabricksDeploymentClient(BaseDeploymentClient):
mlflow/deployments/openai/__init__.py:14:class OpenAIDeploymentClient(BaseDeploymentClient):
EntryPoint(name='databricks', value='mlflow.deployments.databricks', group='mlflow.deployments')
EntryPoint(name='http', value='mlflow.deployments.mlflow', group='mlflow.deployments')
EntryPoint(name='https', value='mlflow.deployments.mlflow', group='mlflow.deployments')
EntryPoint(name='openai', value='mlflow.deployments.openai', group='mlflow.deployments')
```

## 原始行 76 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def __init__\" mlflow/deployments/base.py mlflow/deployments/mlflow/__init__.py mlflow/deployments/databricks/__init__.py mlflow/deployments/openai/__init__.py | head -30
sed -n '1,70p' mlflow/deployments/base.py
sed -n '120,155p' pyproject.toml
python - <<'PY'
import importlib.metadata
for e in importlib.metadata.entry_points(group='mlflow.deployments'):
 print(e.name, e.value)
PY"
```

退出码：`0`

输出：
```
"""
This module contains the base interface implemented by MLflow model deployment plugins.
In particular, a valid deployment plugin module must implement:

1. Exactly one client class subclassed from :py:class:`BaseDeploymentClient`, exposing the primary
   user-facing APIs used to manage deployments.
2. :py:func:`run_local`, for testing deployment by deploying a model locally
3. :py:func:`target_help`, which returns a help message describing target-specific URI format
   and deployment config
"""

import abc

from mlflow.exceptions import MlflowException
from mlflow.utils.annotations import developer_stable


def run_local(target, name, model_uri, flavor=None, config=None):
    """Deploys the specified model locally, for testing. This function should be defined
    within the plugin module. Also note that this function has a signature which is very
    similar to :py:meth:`BaseDeploymentClient.create_deployment` since both does logically
    similar operation.

    .. Note::
        This function is kept here only for documentation purpose and not implementing the
        actual feature. It should be implemented in the plugin's top level namescope and should
        be callable with ``plugin_module.run_local``

    Args:
        target: Which target to use. This information is used to call the appropriate plugin.
        name: Unique name to use for deployment. If another deployment exists with the same
            name, create_deployment will raise a
            :py:class:`mlflow.exceptions.MlflowException`.
        model_uri: URI of model to deploy.
        flavor: (optional) Model flavor to deploy. If unspecified, default flavor is chosen.
        config: (optional) Dict containing updated target-specific config for the deployment.

    Returns:
        None
    """
    raise NotImplementedError(
        "This function should be implemented in the deployment plugin. It is "
        "kept here only for documentation purpose and shouldn't be used in "
        "your application"
    )


def target_help():
    """
    .. Note::
        This function is kept here only for documentation purpose and not implementing the
        actual feature. It should be implemented in the plugin's top level namescope and should
        be callable with ``plugin_module.target_help``

    Return a string containing detailed documentation on the current deployment target, to be
    displayed when users invoke the ``mlflow deployments help -t <target-name>`` CLI. This
    method should be defined within the module specified by the plugin author.
    The string should contain:

    * An explanation of target-specific fields in the ``config`` passed to ``create_deployment``,
      ``update_deployment``
    * How to specify a ``target_uri`` (e.g. for AWS SageMaker, ``target_uri`` have a scheme of
      "sagemaker:/<aws-cli-profile-name>", where aws-cli-profile-name is the name of an AWS
      CLI profile https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-profiles.html)
    * Any other target-specific details.

    """
    raise NotImplementedError(
        "This function should be implemented in the deployment plugin. It is "
        "kept here only for documentation purpose and shouldn't be used in "
auth = ["Flask-WTF<2"]

[project.urls]
homepage = "https://mlflow.org"
issues = "https://github.com/mlflow/mlflow/issues"
documentation = "https://mlflow.org/docs/latest"
repository = "https://github.com/mlflow/mlflow"

[project.scripts]
mlflow = "mlflow.cli:cli"

[project.entry-points."mlflow.app"]
basic-auth = "mlflow.server.auth:create_app"

[project.entry-points."mlflow.app.client"]
basic-auth = "mlflow.server.auth.client:AuthServiceClient"

[project.entry-points."mlflow.deployments"]
databricks = "mlflow.deployments.databricks"
http = "mlflow.deployments.mlflow"
https = "mlflow.deployments.mlflow"
openai = "mlflow.deployments.openai"

[tool.setuptools.package-data]
mlflow = [
  "store/db_migrations/alembic.ini",
  "temporary_db_migrations_for_pre_1_users/alembic.ini",
  "pyspark/ml/log_model_allowlist.txt",
  "server/auth/basic_auth.ini",
  "server/auth/db/migrations/alembic.ini",
  "models/notebook_resources/**/*",
  "ai_commands/**/*.md",
  "models/container/**/*",
  "server/js/build/**/*",
]

databricks mlflow.deployments.databricks
http mlflow.deployments.mlflow
https mlflow.deployments.mlflow
openai mlflow.deployments.openai
```

## 原始行 79 · command_execution

命令：
```
/bin/bash -lc "grep -n \"target_uri\" mlflow/deployments/base.py | head -30
nl -ba mlflow/deployments/base.py | sed -n '75,180p'
grep -n \"self.target_uri\" mlflow/deployments/{mlflow,databricks,openai}/__init__.py | head"
```

退出码：`0`

输出：
```
62:    * How to specify a ``target_uri`` (e.g. for AWS SageMaker, ``target_uri`` have a scheme of
    75	@developer_stable
    76	class BaseDeploymentClient(abc.ABC):
    77	    """
    78	    Base class exposing Python model deployment APIs.
    79	
    80	    Plugin implementors should define target-specific deployment logic via a subclass of
    81	    ``BaseDeploymentClient`` within the plugin module, and customize method docstrings with
    82	    target-specific information.
    83	
    84	    .. Note::
    85	        Subclasses should raise :py:class:`mlflow.exceptions.MlflowException` in error cases (e.g.
    86	        on failure to deploy a model).
    87	    """
    88	
    89	
    90	
    91	
    92	    @abc.abstractmethod
    93	    def create_deployment(self, name, model_uri, flavor=None, config=None, endpoint=None):
    94	        """
    95	        Deploy a model to the specified target. By default, this method should block until
    96	        deployment completes (i.e. until it's possible to perform inference with the deployment).
    97	        In the case of conflicts (e.g. if it's not possible to create the specified deployment
    98	        without due to conflict with an existing deployment), raises a
    99	        :py:class:`mlflow.exceptions.MlflowException` or an `HTTPError` for remote
   100	        deployments. See target-specific plugin documentation
   101	        for additional detail on support for asynchronous deployment and other configuration.
   102	
   103	        Args:
   104	            name: Unique name to use for deployment. If another deployment exists with the same
   105	                name, raises a :py:class:`mlflow.exceptions.MlflowException`
   106	            model_uri: URI of model to deploy
   107	            flavor: (optional) Model flavor to deploy. If unspecified, a default flavor
   108	                will be chosen.
   109	            config: (optional) Dict containing updated target-specific configuration for the
   110	                deployment
   111	            endpoint: (optional) Endpoint to create the deployment under. May not be supported
   112	                by all targets
   113	
   114	        Returns:
   115	            Dict corresponding to created deployment, which must contain the 'name' key.
   116	
   117	        """
   118	
   119	    @abc.abstractmethod
   120	    def update_deployment(self, name, model_uri=None, flavor=None, config=None, endpoint=None):
   121	        """
   122	        Update the deployment with the specified name. You can update the URI of the model, the
   123	        flavor of the deployed model (in which case the model URI must also be specified), and/or
   124	        any target-specific attributes of the deployment (via `config`). By default, this method
   125	        should block until deployment completes (i.e. until it's possible to perform inference
   126	        with the updated deployment). See target-specific plugin documentation for additional
   127	        detail on support for asynchronous deployment and other configuration.
   128	
   129	        Args:
   130	            name: Unique name of deployment to update.
   131	            model_uri: URI of a new model to deploy.
   132	            flavor: (optional) new model flavor to use for deployment. If provided,
   133	                ``model_uri`` must also be specified. If ``flavor`` is unspecified but
   134	                ``model_uri`` is specified, a default flavor will be chosen and the
   135	                deployment will be updated using that flavor.
   136	            config: (optional) dict containing updated target-specific configuration for the
   137	                deployment.
   138	            endpoint: (optional) Endpoint containing the deployment to update. May not be
   139	                supported by all targets.
   140	
   141	        Returns:
   142	            None
   143	
   144	        """
   145	
   146	    @abc.abstractmethod
   147	    def delete_deployment(self, name, config=None, endpoint=None):
   148	        """Delete the deployment with name ``name`` from the specified target.
   149	
   150	        Deletion should be idempotent (i.e. deletion should not fail if retried on a non-existent
   151	        deployment).
   152	
   153	        Args:
   154	            name: Name of deployment to delete
   155	            config: (optional) dict containing updated target-specific configuration for the
   156	                deployment
   157	            endpoint: (optional) Endpoint containing the deployment to delete. May not be
   158	                supported by all targets
   159	
   160	        Returns:
   161	            None
   162	        """
   163	
   164	    @abc.abstractmethod
   165	    def list_deployments(self, endpoint=None):
   166	        """List deployments.
   167	
   168	        This method is expected to return an unpaginated list of all
   169	        deployments (an alternative would be to return a dict with a 'deployments' field
   170	        containing the actual deployments, with plugins able to specify other fields, e.g.
   171	        a next_page_token field, in the returned dictionary for pagination, and to accept
   172	        a `pagination_args` argument to this method for passing pagination-related args).
   173	
   174	        Args:
   175	            endpoint: (optional) List deployments in the specified endpoint. May not be
   176	                supported by all targets
   177	
   178	        Returns:
   179	            A list of dicts corresponding to deployments. Each dict is guaranteed to
   180	            contain a 'name' key containing the deployment name. The other fields of
mlflow/deployments/mlflow/__init__.py:130:            host_creds=get_default_host_creds(self.target_uri),
mlflow/deployments/mlflow/__init__.py:176:                "endpoint_url": resolve_endpoint_url(self.target_uri, response["endpoint_url"]),
mlflow/deployments/mlflow/__init__.py:193:                        self.target_uri,
mlflow/deployments/databricks/__init__.py:155:            host_creds=get_databricks_host_creds(self.target_uri),
mlflow/deployments/databricks/__init__.py:187:            host_creds=get_databricks_host_creds(self.target_uri),
```

## 原始行 82 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/deployments/test_interface.py tests/deployments/test_deployments.py tests/gateway/test_gateway_config_parsing.py tests/gateway/test_gateway_app.py tests/utils/test_rest_utils.py --collect-only'
```

退出码：`2`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 16 items / 4 errors

<Dir testbed>
  <Package tests>
    <Package deployments>
      <Module test_deployments.py>
        <Function test_create_success>
        <Function test_delete_success>
        <Function test_update_success>
        <Function test_list_success>
        <Function test_get_success>
        <Function test_endpoint_create_success>
        <Function test_endpoint_delete_success>
        <Function test_endpoint_update_success>
        <Function test_endpoint_list_success>
        <Function test_endpoint_get_success>
        <Function test_wrong_target_name>
        <Function test_plugin_doesnot_have_required_attrib>
        <Function test_plugin_raising_error>
        <Function test_target_uri_parsing>
        <Function test_explain_with_no_target_implementation>
        <Function test_explain_with_target_implementation>

==================================== ERRORS ====================================
[31m[1m_____________ ERROR collecting tests/deployments/test_interface.py _____________[0m
[31mImportError while importing test module '/testbed/tests/deployments/test_interface.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
tests/deployments/test_interface.py:4: in <module>
    from mlflow.deployments.interface import get_deploy_client
E   ImportError: cannot import name 'get_deploy_client' from 'mlflow.deployments.interface' (/testbed/mlflow/deployments/interface.py)[0m
[31m[1m________ ERROR collecting tests/gateway/test_gateway_config_parsing.py _________[0m
[1m[31mtests/gateway/test_gateway_config_parsing.py[0m:7: in <module>
    [0m[94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mgateway[39;49;00m[04m[96m.[39;49;00m[04m[96mconfig[39;49;00m[90m [39;49;00m[94mimport[39;49;00m ([90m[39;49;00m
        MlflowException = <class 'mlflow.exceptions.MlflowException'>
        __builtins__ = <builtins>
        __cached__ = '/testbed/tests/gateway/__pycache__/test_gateway_config_parsing.cpython-311.pyc'
        __doc__    = None
        __file__   = '/testbed/tests/gateway/test_gateway_config_parsing.py'
        __loader__ = <_pytest.assertion.rewrite.AssertionRewritingHook object at 0x7a28789e1bd0>
        __name__   = 'tests.gateway.test_gateway_config_parsing'
        __package__ = 'tests.gateway'
        __spec__   = ModuleSpec(name='tests.gateway.test_gateway_config_parsing', loader=<_pytest.assertion.rewrite.AssertionRewritingHook object at 0x7a28789e1bd0>, origin='/testbed/tests/gateway/test_gateway_config_parsing.py')
        pytest     = <module 'pytest' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pytest/__init__.py'>
        re         = <module 're' from '/opt/miniconda3/envs/testbed/lib/python3.11/re/__init__.py'>
        yaml       = <module 'yaml' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/yaml/__init__.py'>
[1m[31mmlflow/gateway/config.py[0m:329: in <module>
    [0m[94mclass[39;49;00m[90m [39;49;00m[04m[92mLimitsConfig[39;49;00m(ConfigModel):[90m[39;49;00m
        AI21LabsConfig = <class 'mlflow.gateway.config.AI21LabsConfig'>
        AWSBaseConfig = <class 'mlflow.gateway.config.AWSBaseConfig'>
        AWSIdAndKey = <class 'mlflow.gateway.config.AWSIdAndKey'>
        AWSRole    = <class 'mlflow.gateway.config.AWSRole'>
        AliasedConfigModel = <class 'mlflow.gateway.config.AliasedConfigModel'>
        AmazonBedrockConfig = <class 'mlflow.gateway.config.AmazonBedrockConfig'>
        AnthropicConfig = <class 'mlflow.gateway.config.AnthropicConfig'>
        Any        = typing.Any
        CohereConfig = <class 'mlflow.gateway.config.CohereConfig'>
        ConfigDict = <class 'pydantic.config.ConfigDict'>
        ConfigModel = <class 'mlflow.gateway.base_models.ConfigModel'>
        Enum       = <enum 'Enum'>
        GeminiConfig = <class 'mlflow.gateway.config.GeminiConfig'>
        HuggingFaceTextGenerationInferenceConfig = <class 'mlflow.gateway.config.HuggingFaceTextGenerationInferenceConfig'>
        LimitModel = <class 'mlflow.gateway.base_models.LimitModel'>
        Literal    = typing.Literal
        MLFLOW_AI_GATEWAY_MOSAICML_CHAT_SUPPORTED_MODEL_PREFIXES = ['llama2']
        MLFLOW_GATEWAY_ROUTE_BASE = '/gateway/'
        MLFLOW_QUERY_SUFFIX = '/invocations'
        MistralConfig = <class 'mlflow.gateway.config.MistralConfig'>
        MlflowException = <class 'mlflow.exceptions.MlflowException'>
        MlflowModelServingConfig = <class 'mlflow.gateway.config.MlflowModelServingConfig'>
        Model      = <class 'mlflow.gateway.config.Model'>
        ModelInfo  = <class 'mlflow.gateway.config.ModelInfo'>
        MosaicMLConfig = <class 'mlflow.gateway.config.MosaicMLConfig'>
        OpenAIAPIType = <enum 'OpenAIAPIType'>
        OpenAIConfig = <class 'mlflow.gateway.config.OpenAIConfig'>
        PaLMConfig = <class 'mlflow.gateway.config.PaLMConfig'>
        Path       = <class 'pathlib.Path'>
        Provider   = <enum 'Provider'>
        ResponseModel = <class 'mlflow.gateway.base_models.ResponseModel'>
        SerializeAsAny = <class 'pydantic.functional_serializers.SerializeAsAny'>
        TYPE_CHECKING = False
        TogetherAIConfig = <class 'mlflow.gateway.config.TogetherAIConfig'>
        ValidationError = <class 'pydantic_core._pydantic_core.ValidationError'>
        __builtins__ = <builtins>
        __cached__ = '/testbed/mlflow/gateway/__pycache__/config.cpython-311.pyc'
        __doc__    = None
        __file__   = '/testbed/mlflow/gateway/config.py'
        __loader__ = <_frozen_importlib_external.SourceFileLoader object at 0x7a2815911590>
        __name__   = 'mlflow.gateway.config'
        __package__ = 'mlflow.gateway'
        __spec__   = ModuleSpec(name='mlflow.gateway.config', loader=<_frozen_importlib_external.SourceFileLoader object at 0x7a2815911590>, origin='/testbed/mlflow/gateway/config.py')
        _logger    = <Logger mlflow.gateway.config (INFO)>
        _resolve_api_key_from_input = <function _resolve_api_key_from_input at 0x7a2815b8b2e0>
        check_configuration_deprecated_fields = <function check_configuration_deprecated_fields at 0x7a28163e5440>
        check_configuration_route_name_collisions = <function check_configuration_route_name_collisions at 0x7a28163e53a0>
        field_validator = <function field_validator at 0x7a28770f47c0>
        is_valid_ai21labs_model = <function is_valid_ai21labs_model at 0x7a28163e5ee0>
        is_valid_endpoint_name = <function is_valid_endpoint_name at 0x7a28163e5120>
        is_valid_mosiacml_chat_model = <function is_valid_mosiacml_chat_model at 0x7a28163e5bc0>
        json       = <module 'json' from '/opt/miniconda3/envs/testbed/lib/python3.11/json/__init__.py'>
        logging    = <module 'logging' from '/opt/miniconda3/envs/testbed/lib/python3.11/logging/__init__.py'>
        model_validator = <function model_validator at 0x7a28770f54e0>
        os         = <module 'os' (frozen)>
        pathlib    = <module 'pathlib' from '/opt/miniconda3/envs/testbed/lib/python3.11/pathlib.py'>
        pydantic   = <module 'pydantic' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pydantic/__init__.py'>
        pydantic_encoder = <function pydantic_encoder at 0x7a2815a55f80>
        yaml       = <module 'yaml' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/yaml/__init__.py'>
[1m[31mmlflow/gateway/config.py[0m:330: in LimitsConfig
    [0mlimits: [96mlist[39;49;00m[Limit] | [94mNone[39;49;00m = [][90m[39;49;00m
                 ^^^^^[90m[39;49;00m
[1m[31mE   NameError: name 'Limit' is not defined[0m
        __annotations__ = {}
        __module__ = 'mlflow.gateway.config'
        __qualname__ = 'LimitsConfig'
        limits     = []
[31m[1m______________ ERROR collecting tests/gateway/test_gateway_app.py ______________[0m
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py[0m:44: in <module>
    [0m[94mimport[39;49;00m[90m [39;49;00m[04m[96mhttpx[39;49;00m[90m[39;49;00m
[1m[31mE   ModuleNotFoundError: No module named 'httpx'[0m
        ASGIApp    = typing.Callable[[collections.abc.MutableMapping[str, typing.Any], typing.Callable[[], collections.abc.Awaitable[collec...[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]], collections.abc.Awaitable[None]]
        AbstractContextManager = <class 'contextlib.AbstractContextManager'>
        Any        = typing.Any
        Awaitable  = <class 'collections.abc.Awaitable'>
        Callable   = typing.Callable
        Future     = <class 'concurrent.futures._base.Future'>
        Generator  = <class 'collections.abc.Generator'>
        GeneratorType = <class 'generator'>
        Iterable   = <class 'collections.abc.Iterable'>
        Literal    = typing.Literal
        Mapping    = <class 'collections.abc.Mapping'>
        Message    = collections.abc.MutableMapping[str, typing.Any]
        MutableMapping = <class 'collections.abc.MutableMapping'>
        Receive    = typing.Callable[[], collections.abc.Awaitable[collections.abc.MutableMapping[str, typing.Any]]]
        Scope      = collections.abc.MutableMapping[str, typing.Any]
        Self       = typing.Self
        Send       = typing.Callable[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]
        Sequence   = <class 'collections.abc.Sequence'>
        StapledObjectStream = <class 'anyio.streams.stapled.StapledObjectStream'>
        TypeGuard  = typing.TypeGuard
        TypedDict  = <function TypedDict at 0x7a2879906b60>
        Union      = typing.Union
        WebSocketDisconnect = <class 'starlette.websockets.WebSocketDisconnect'>
        __builtins__ = <builtins>
        __cached__ = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/__pycache__/testclient.cpython-311.pyc'
        __doc__    = None
        __file__   = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py'
        __loader__ = <_frozen_importlib_external.SourceFileLoader object at 0x7a281577bd50>
        __name__   = 'starlette.testclient'
        __package__ = 'starlette'
        __spec__   = ModuleSpec(name='starlette.testclient', loader=<_frozen_importlib_external.SourceFileLoader object at 0x7a281577bd50>, origin='/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py')
        annotations = _Feature((3, 7, 0, 'beta', 1), None, 16777216)
        anyio      = <module 'anyio' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/anyio/__init__.py'>
        cast       = <function cast at 0x7a2879380cc0>
        contextlib = <module 'contextlib' from '/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py'>
        inspect    = <module 'inspect' from '/opt/miniconda3/envs/testbed/lib/python3.11/inspect.py'>
        io         = <module 'io' (frozen)>
        is_async_callable = <function is_async_callable at 0x7a28156c9f80>
        json       = <module 'json' from '/opt/miniconda3/envs/testbed/lib/python3.11/json/__init__.py'>
        math       = <module 'math' from '/opt/miniconda3/envs/testbed/lib/python3.11/lib-dynload/math.cpython-311-x86_64-linux-gnu.so'>
        sys        = <module 'sys' (built-in)>
        unquote    = <function unquote at 0x7a2879642200>
        urljoin    = <function urljoin at 0x7a2879641f80>
        warnings   = <module 'warnings' from '/opt/miniconda3/envs/testbed/lib/python3.11/warnings.py'>

[33mDuring handling of the above exception, another exception occurred:[0m
[1m[31mtests/gateway/test_gateway_app.py[0m:4: in <module>
    [0m[94mfrom[39;49;00m[90m [39;49;00m[04m[96mfastapi[39;49;00m[04m[96m.[39;49;00m[04m[96mtestclient[39;49;00m[90m [39;49;00m[94mimport[39;49;00m TestClient[90m[39;49;00m
        __builtins__ = <builtins>
        __cached__ = '/testbed/tests/gateway/__pycache__/test_gateway_app.cpython-311.pyc'
        __doc__    = None
        __file__   = '/testbed/tests/gateway/test_gateway_app.py'
        __loader__ = <_pytest.assertion.rewrite.AssertionRewritingHook object at 0x7a28789e1bd0>
        __name__   = 'tests.gateway.test_gateway_app'
        __package__ = 'tests.gateway'
        __spec__   = ModuleSpec(name='tests.gateway.test_gateway_app', loader=<_pytest.assertion.rewrite.AssertionRewritingHook object at 0x7a28789e1bd0>, origin='/testbed/tests/gateway/test_gateway_app.py')
        mock       = <module 'unittest.mock' from '/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py'>
        pytest     = <module 'pytest' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pytest/__init__.py'>
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/testclient.py[0m:1: in <module>
    [0m[94mfrom[39;49;00m[90m [39;49;00m[04m[96mstarlette[39;49;00m[04m[96m.[39;49;00m[04m[96mtestclient[39;49;00m[90m [39;49;00m[94mimport[39;49;00m TestClient [94mas[39;49;00m TestClient  [90m# noqa[39;49;00m[90m[39;49;00m
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        __builtins__ = <builtins>
        __cached__ = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/__pycache__/testclient.cpython-311.pyc'
        __doc__    = None
        __file__   = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/testclient.py'
        __loader__ = <_frozen_importlib_external.SourceFileLoader object at 0x7a28158e2a90>
        __name__   = 'fastapi.testclient'
        __package__ = 'fastapi'
        __spec__   = ModuleSpec(name='fastapi.testclient', loader=<_frozen_importlib_external.SourceFileLoader object at 0x7a28158e2a90>, origin='/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/fastapi/testclient.py')
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py[0m:46: in <module>
    [0m[94mraise[39;49;00m [96mRuntimeError[39;49;00m([90m[39;49;00m
[1m[31mE   RuntimeError: The starlette.testclient module requires the httpx package to be installed.[0m
[1m[31mE   You can install this with:[0m
[1m[31mE       $ pip install httpx[0m
        ASGIApp    = typing.Callable[[collections.abc.MutableMapping[str, typing.Any], typing.Callable[[], collections.abc.Awaitable[collec...[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]], collections.abc.Awaitable[None]]
        AbstractContextManager = <class 'contextlib.AbstractContextManager'>
        Any        = typing.Any
        Awaitable  = <class 'collections.abc.Awaitable'>
        Callable   = typing.Callable
        Future     = <class 'concurrent.futures._base.Future'>
        Generator  = <class 'collections.abc.Generator'>
        GeneratorType = <class 'generator'>
        Iterable   = <class 'collections.abc.Iterable'>
        Literal    = typing.Literal
        Mapping    = <class 'collections.abc.Mapping'>
        Message    = collections.abc.MutableMapping[str, typing.Any]
        MutableMapping = <class 'collections.abc.MutableMapping'>
        Receive    = typing.Callable[[], collections.abc.Awaitable[collections.abc.MutableMapping[str, typing.Any]]]
        Scope      = collections.abc.MutableMapping[str, typing.Any]
        Self       = typing.Self
        Send       = typing.Callable[[collections.abc.MutableMapping[str, typing.Any]], collections.abc.Awaitable[None]]
        Sequence   = <class 'collections.abc.Sequence'>
        StapledObjectStream = <class 'anyio.streams.stapled.StapledObjectStream'>
        TypeGuard  = typing.TypeGuard
        TypedDict  = <function TypedDict at 0x7a2879906b60>
        Union      = typing.Union
        WebSocketDisconnect = <class 'starlette.websockets.WebSocketDisconnect'>
        __builtins__ = <builtins>
        __cached__ = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/__pycache__/testclient.cpython-311.pyc'
        __doc__    = None
        __file__   = '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py'
        __loader__ = <_frozen_importlib_external.SourceFileLoader object at 0x7a281577bd50>
        __name__   = 'starlette.testclient'
        __package__ = 'starlette'
        __spec__   = ModuleSpec(name='starlette.testclient', loader=<_frozen_importlib_external.SourceFileLoader object at 0x7a281577bd50>, origin='/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/testclient.py')
        annotations = _Feature((3, 7, 0, 'beta', 1), None, 16777216)
        anyio      = <module 'anyio' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/anyio/__init__.py'>
        cast       = <function cast at 0x7a2879380cc0>
        contextlib = <module 'contextlib' from '/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py'>
        inspect    = <module 'inspect' from '/opt/miniconda3/envs/testbed/lib/python3.11/inspect.py'>
        io         = <module 'io' (frozen)>
        is_async_callable = <function is_async_callable at 0x7a28156c9f80>
        json       = <module 'json' from '/opt/miniconda3/envs/testbed/lib/python3.11/json/__init__.py'>
        math       = <module 'math' from '/opt/miniconda3/envs/testbed/lib/python3.11/lib-dynload/math.cpython-311-x86_64-linux-gnu.so'>
        sys        = <module 'sys' (built-in)>
        unquote    = <function unquote at 0x7a2879642200>
        urljoin    = <function urljoin at 0x7a2879641f80>
        warnings   = <module 'warnings' from '/opt/miniconda3/envs/testbed/lib/python3.11/warnings.py'>
[31m[1m_______________ ERROR collecting tests/utils/test_rest_utils.py ________________[0m
[31mImportError while importing test module '/testbed/tests/utils/test_rest_utils.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
tests/utils/test_rest_utils.py:24: in <module>
    from mlflow.utils.rest_utils import (
E   ImportError: cannot import name 'http_request' from 'mlflow.utils.rest_utils' (/testbed/mlflow/utils/rest_utils.py)[0m
[36m[1m=========================== short test summary info ============================[0m
[31mERROR[0m tests/deployments/test_interface.py
[31mERROR[0m tests/gateway/test_gateway_config_parsing.py - NameError: name 'Limit' is not defined
[31mERROR[0m tests/gateway/test_gateway_app.py - RuntimeError: The starlette.testclient module requires the httpx package to...
[31mERROR[0m tests/utils/test_rest_utils.py
!!!!!!!!!!!!!!!!!!! Interrupted: 4 errors during collection !!!!!!!!!!!!!!!!!!!!
[31m==================== [32m16 tests collected[0m, [31m4 errors[0m[31m in 0.47s[0m[31m =====================[0m
```

## 原始行 85 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,220p' tests/utils/test_request_utils.py"
```

退出码：`0`

输出：
```
import subprocess
import sys
from unittest import mock

import pytest

from mlflow.utils import request_utils


def test_request_utils_does_not_import_mlflow(tmp_path):
    file_content = f"""
import importlib.util
import os
import sys

file_path = r"{request_utils.__file__}"
module_name = "mlflow.utils.request_utils"

spec = importlib.util.spec_from_file_location(module_name, file_path)
module = importlib.util.module_from_spec(spec)
sys.modules[module_name] = module
spec.loader.exec_module(module)

assert "mlflow" not in sys.modules
assert "mlflow.utils.request_utils" in sys.modules
"""
    test_file = tmp_path.joinpath("test_request_utils_does_not_import_mlflow.py")
    test_file.write_text(file_content)

    subprocess.run([sys.executable, str(test_file)], check=True)


class IncompleteResponse:
    def __init__(self):
        self.headers = {"Content-Length": "100"}
        raw = mock.MagicMock()
        raw.tell.return_value = 50
        self.raw = raw

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass


def test_download_chunk_incomplete_read(tmp_path):
    with mock.patch.object(
        request_utils, "cloud_storage_http_request", return_value=IncompleteResponse()
    ):
        download_path = tmp_path / "chunk"
        download_path.touch()
        with pytest.raises(IOError, match="Incomplete read"):
            request_utils.download_chunk(
                range_start=0,
                range_end=999,
                headers={},
                download_path=download_path,
                http_uri="https://example.com",
            )


@pytest.mark.parametrize("env_value", ["0", "false", "False", "FALSE"])
def test_redirects_disabled_if_env_var_set(monkeypatch, env_value):
    monkeypatch.setenv("MLFLOW_ALLOW_HTTP_REDIRECTS", env_value)

    with mock.patch("requests.Session.request") as mock_request:
        mock_request.return_value.status_code = 302
        mock_request.return_value.text = "mock response"

        response = request_utils.cloud_storage_http_request("GET", "http://localhost:5000")

        assert response.text == "mock response"
        mock_request.assert_called_once_with(
            "GET",
            "http://localhost:5000",
            allow_redirects=False,
            timeout=None,
        )


@pytest.mark.parametrize("env_value", ["1", "true", "True", "TRUE"])
def test_redirects_enabled_if_env_var_set(monkeypatch, env_value):
    monkeypatch.setenv("MLFLOW_ALLOW_HTTP_REDIRECTS", env_value)

    with mock.patch("requests.Session.request") as mock_request:
        mock_request.return_value.status_code = 302
        mock_request.return_value.text = "mock response"

        response = request_utils.cloud_storage_http_request(
            "GET",
            "http://localhost:5000",
        )

        assert response.text == "mock response"
        mock_request.assert_called_once_with(
            "GET",
            "http://localhost:5000",
            allow_redirects=True,
            timeout=None,
        )


@pytest.mark.parametrize("env_value", ["0", "false", "False", "FALSE"])
def test_redirect_kwarg_overrides_env_value_false(monkeypatch, env_value):
    monkeypatch.setenv("MLFLOW_ALLOW_HTTP_REDIRECTS", env_value)

    with mock.patch("requests.Session.request") as mock_request:
        mock_request.return_value.status_code = 302
        mock_request.return_value.text = "mock response"

        response = request_utils.cloud_storage_http_request(
            "GET", "http://localhost:5000", allow_redirects=True
        )

        assert response.text == "mock response"
        mock_request.assert_called_once_with(
            "GET",
            "http://localhost:5000",
            allow_redirects=True,
            timeout=None,
        )


@pytest.mark.parametrize("env_value", ["1", "true", "True", "TRUE"])
def test_redirect_kwarg_overrides_env_value_true(monkeypatch, env_value):
    monkeypatch.setenv("MLFLOW_ALLOW_HTTP_REDIRECTS", env_value)

    with mock.patch("requests.Session.request") as mock_request:
        mock_request.return_value.status_code = 302
        mock_request.return_value.text = "mock response"

        response = request_utils.cloud_storage_http_request(
            "GET", "http://localhost:5000", allow_redirects=False
        )

        assert response.text == "mock response"
        mock_request.assert_called_once_with(
            "GET",
            "http://localhost:5000",
            allow_redirects=False,
            timeout=None,
        )


def test_redirects_enabled_by_default():
    with mock.patch("requests.Session.request") as mock_request:
        mock_request.return_value.status_code = 302
        mock_request.return_value.text = "mock response"

        response = request_utils.cloud_storage_http_request(
            "GET",
            "http://localhost:5000",
        )

        assert response.text == "mock response"
        mock_request.assert_called_once_with(
            "GET",
            "http://localhost:5000",
            allow_redirects=True,
            timeout=None,
        )
```

## 原始行 87 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"CUSTOMER_UNAUTHORIZED\\|MLFLOW_ENABLE_DB_SDK\" mlflow --include='*.py' | head -100
sed -n '1,140p' mlflow/environment_variables.py | grep -n -B2 -A3 \"HTTP_REQUEST\\|ENABLE_DB_SDK\\|TRAFFIC_ID\""
```

退出码：`0`

输出：
```
mlflow/exceptions.py:9:    CUSTOMER_UNAUTHORIZED,
mlflow/exceptions.py:46:    ErrorCode.Name(CUSTOMER_UNAUTHORIZED): 401,
mlflow/utils/rest_utils.py:17:    MLFLOW_ENABLE_DB_SDK,
mlflow/utils/rest_utils.py:25:    CUSTOMER_UNAUTHORIZED,
mlflow/utils/databricks_utils.py:21:    MLFLOW_ENABLE_DB_SDK,
mlflow/utils/databricks_utils.py:768:    if MLFLOW_ENABLE_DB_SDK.get():
mlflow/protos/databricks_pb2.py:97:  CUSTOMER_UNAUTHORIZED = 1006
mlflow/environment_variables.py:754:MLFLOW_ENABLE_DB_SDK = _BooleanEnvironmentVariable("MLFLOW_ENABLE_DB_SDK", True)
116-#: Specifies the maximum number of retries with exponential backoff for MLflow HTTP requests
117-#: (default: ``7``)
118:MLFLOW_HTTP_REQUEST_MAX_RETRIES = _EnvironmentVariable(
119:    "MLFLOW_HTTP_REQUEST_MAX_RETRIES",
120-    int,
121-    # Important: It's common for MLflow backends to rate limit requests for more than 1 minute.
122-    # To remain resilient to rate limiting, the MLflow client needs to retry for more than 1
--
128-#: Specifies the backoff increase factor between MLflow HTTP request failures
129-#: (default: ``2``)
130:MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR = _EnvironmentVariable(
131:    "MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR", int, 2
132-)
133-
134-#: Specifies the backoff jitter between MLflow HTTP request failures
135-#: (default: ``1.0``)
136:MLFLOW_HTTP_REQUEST_BACKOFF_JITTER = _EnvironmentVariable(
137:    "MLFLOW_HTTP_REQUEST_BACKOFF_JITTER", float, 1.0
138-)
139-
140-#: Specifies the timeout in seconds for MLflow HTTP requests
```

## 原始行 89 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"DefaultRequestHeaderProvider\\|DatabricksRequestHeaderProvider\\|RequestHeaderProviderRegistry\" tests --include='*.py' | head -100
grep -R -n \"BaseDeploymentClient(\" tests --include='*.py' | head -60"
```

退出码：`0`

输出：
```
tests/tracking/request_header/test_registry.py:8:    DatabricksRequestHeaderProvider,
tests/tracking/request_header/test_registry.py:11:    RequestHeaderProviderRegistry,
tests/tracking/request_header/test_registry.py:25:    registry = RequestHeaderProviderRegistry()
tests/tracking/request_header/test_registry.py:39:        registry = RequestHeaderProviderRegistry()
tests/tracking/request_header/test_registry.py:57:        registry = RequestHeaderProviderRegistry()
tests/tracking/request_header/test_registry.py:74:    expected_classes = {DatabricksRequestHeaderProvider}
tests/tracking/request_header/test_default_request_header_provider.py:3:    DefaultRequestHeaderProvider,
tests/tracking/request_header/test_default_request_header_provider.py:8:    assert DefaultRequestHeaderProvider().in_context()
tests/tracking/request_header/test_default_request_header_provider.py:12:    request_headers = DefaultRequestHeaderProvider().request_headers()
tests/tracking/request_header/test_databricks_request_header_provider.py:7:    DatabricksRequestHeaderProvider,
tests/tracking/request_header/test_databricks_request_header_provider.py:31:            DatabricksRequestHeaderProvider().in_context() == is_in_databricks_notebook
tests/tracking/request_header/test_databricks_request_header_provider.py:63:        request_headers = DatabricksRequestHeaderProvider().request_headers()
tests/projects/test_databricks.py:20:    DefaultRequestHeaderProvider,
tests/projects/test_databricks.py:445:        headers = DefaultRequestHeaderProvider().request_headers()
tests/utils/test_rest_utils.py:22:    DefaultRequestHeaderProvider,
tests/utils/test_rest_utils.py:104:            headers=DefaultRequestHeaderProvider().request_headers(),
tests/utils/test_rest_utils.py:121:            headers=DefaultRequestHeaderProvider().request_headers(),
tests/utils/test_rest_utils.py:132:        headers = DefaultRequestHeaderProvider().request_headers()
tests/utils/test_rest_utils.py:206:        headers = DefaultRequestHeaderProvider().request_headers()
tests/utils/test_rest_utils.py:229:            headers=DefaultRequestHeaderProvider().request_headers(),
tests/utils/test_rest_utils.py:246:            headers=DefaultRequestHeaderProvider().request_headers(),
tests/utils/test_rest_utils.py:262:            headers=DefaultRequestHeaderProvider().request_headers(),
tests/utils/test_rest_utils.py:274:        headers = DefaultRequestHeaderProvider().request_headers()
tests/utils/test_rest_utils.py:308:            headers={**DefaultRequestHeaderProvider().request_headers(), "test": "header"},
tests/utils/test_rest_utils.py:322:    default_headers = DefaultRequestHeaderProvider().request_headers()
tests/utils/test_rest_utils.py:359:    default_headers = DefaultRequestHeaderProvider().request_headers()
tests/utils/test_rest_utils.py:434:            headers=DefaultRequestHeaderProvider().request_headers(),
tests/utils/test_rest_utils.py:444:            headers=DefaultRequestHeaderProvider().request_headers(),
tests/store/tracking/test_rest_store.py:101:    DefaultRequestHeaderProvider,
tests/store/tracking/test_rest_store.py:138:            "headers": DefaultRequestHeaderProvider().request_headers(),
```

## 原始行 91 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from databricks.sdk.errors import STATUS_CODE_MAPPING
for k,v in STATUS_CODE_MAPPING.items(): print(k,v)
from databricks.sdk.errors import DatabricksError
import inspect
print(inspect.signature(DatabricksError))
PY"
```

退出码：`0`

输出：
```
400 <class 'databricks.sdk.errors.platform.BadRequest'>
401 <class 'databricks.sdk.errors.platform.Unauthenticated'>
403 <class 'databricks.sdk.errors.platform.PermissionDenied'>
404 <class 'databricks.sdk.errors.platform.NotFound'>
409 <class 'databricks.sdk.errors.platform.ResourceConflict'>
429 <class 'databricks.sdk.errors.platform.TooManyRequests'>
499 <class 'databricks.sdk.errors.platform.Cancelled'>
500 <class 'databricks.sdk.errors.platform.InternalError'>
501 <class 'databricks.sdk.errors.platform.NotImplemented'>
503 <class 'databricks.sdk.errors.platform.TemporarilyUnavailable'>
504 <class 'databricks.sdk.errors.platform.DeadlineExceeded'>
(message: Optional[str] = None, *, error_code: Optional[str] = None, detail: Optional[str] = None, status: Optional[str] = None, scimType: Optional[str] = None, error: Optional[str] = None, retry_after_secs: Optional[int] = None, details: Optional[List[Dict[str, Any]]] = None, **kwargs)
```

## 原始行 95 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,120p' tests/tracking/request_header/test_default_request_header_provider.py
sed -n '1,110p' tests/tracking/request_header/test_databricks_request_header_provider.py
sed -n '1,110p' tests/tracking/request_header/test_registry.py"
```

退出码：`0`

输出：
```
from mlflow.tracking.request_header.default_request_header_provider import (
    _DEFAULT_HEADERS,
    DefaultRequestHeaderProvider,
)


def test_default_request_header_provider_in_context():
    assert DefaultRequestHeaderProvider().in_context()


def test_default_request_header_provider_request_headers():
    request_headers = DefaultRequestHeaderProvider().request_headers()
    assert request_headers == _DEFAULT_HEADERS
import itertools
from unittest import mock

import pytest

from mlflow.tracking.request_header.databricks_request_header_provider import (
    DatabricksRequestHeaderProvider,
)

bool_values = [True, False]


@pytest.mark.parametrize(
    ("is_in_databricks_notebook", "is_in_databricks_job", "is_in_cluster"),
    itertools.product(bool_values, bool_values, bool_values),
)
def test_databricks_request_header_provider_in_context(
    is_in_databricks_notebook, is_in_databricks_job, is_in_cluster
):
    with (
        mock.patch(
            "mlflow.utils.databricks_utils.is_in_databricks_notebook",
            return_value=is_in_databricks_notebook,
        ),
        mock.patch(
            "mlflow.utils.databricks_utils.is_in_databricks_job", return_value=is_in_databricks_job
        ),
        mock.patch("mlflow.utils.databricks_utils.is_in_cluster", return_value=is_in_cluster),
    ):
        assert (
            DatabricksRequestHeaderProvider().in_context() == is_in_databricks_notebook
            or is_in_databricks_job
            or is_in_cluster
        )


# test that request_headers returns whatever is available
@pytest.mark.parametrize(
    ("is_in_databricks_notebook", "is_in_databricks_job", "is_in_cluster"),
    itertools.product(bool_values, bool_values, bool_values),
)
def test_databricks_request_header_provider_request_headers(
    is_in_databricks_notebook, is_in_databricks_job, is_in_cluster
):
    with (
        mock.patch(
            "mlflow.utils.databricks_utils.is_in_databricks_notebook",
            return_value=is_in_databricks_notebook,
        ),
        mock.patch(
            "mlflow.utils.databricks_utils.is_in_databricks_job", return_value=is_in_databricks_job
        ),
        mock.patch("mlflow.utils.databricks_utils.is_in_cluster", return_value=is_in_cluster),
        mock.patch("mlflow.utils.databricks_utils.get_notebook_id") as notebook_id_mock,
        mock.patch("mlflow.utils.databricks_utils.get_job_id") as job_id_mock,
        mock.patch("mlflow.utils.databricks_utils.get_job_run_id") as job_run_id_mock,
        mock.patch("mlflow.utils.databricks_utils.get_job_type") as job_type_mock,
        mock.patch("mlflow.utils.databricks_utils.get_cluster_id") as cluster_id_mock,
        mock.patch("mlflow.utils.databricks_utils.get_command_run_id") as command_run_id_mock,
        mock.patch("mlflow.utils.databricks_utils.get_workload_id") as workload_id_mock,
        mock.patch("mlflow.utils.databricks_utils.get_workload_class") as workload_class_mock,
    ):
        request_headers = DatabricksRequestHeaderProvider().request_headers()

        if is_in_databricks_notebook:
            assert request_headers["notebook_id"] == notebook_id_mock.return_value
        else:
            assert "notebook_id" not in request_headers

        if is_in_databricks_job:
            assert request_headers["job_id"] == job_id_mock.return_value
            assert request_headers["job_run_id"] == job_run_id_mock.return_value
            assert request_headers["job_type"] == job_type_mock.return_value
        else:
            assert "job_id" not in request_headers
            assert "job_run_id" not in request_headers
            assert "job_type" not in request_headers

        if is_in_cluster:
            assert request_headers["cluster_id"] == cluster_id_mock.return_value
        else:
            assert "cluster_id" not in request_headers

        if command_run_id_mock.return_value is not None:
            assert request_headers["command_run_id"] == command_run_id_mock.return_value
        else:
            assert "command_run_id" not in request_headers

        if workload_id_mock.return_value is not None:
            assert request_headers["workload_id"] == workload_id_mock.return_value
        else:
            assert "workload_id" not in request_headers

        if workload_class_mock.return_value is not None:
            assert request_headers["workload_class"] == workload_class_mock.return_value
        else:
            assert "workload_class" not in request_headers
from importlib import reload
from unittest import mock

import pytest

import mlflow.tracking.request_header.registry
from mlflow.tracking.request_header.databricks_request_header_provider import (
    DatabricksRequestHeaderProvider,
)
from mlflow.tracking.request_header.registry import (
    RequestHeaderProviderRegistry,
    resolve_request_headers,
)


@pytest.fixture(autouse=True)
def reload_registry():
    yield
    reload(mlflow.tracking.request_header.registry)


def test_request_header_context_provider_registry_register():
    provider_class = mock.Mock()

    registry = RequestHeaderProviderRegistry()
    registry.register(provider_class)

    assert set(registry) == {provider_class.return_value}


def test_request_header_provider_registry_register_entrypoints():
    provider_class = mock.Mock()
    mock_entrypoint = mock.Mock()
    mock_entrypoint.load.return_value = provider_class

    with mock.patch(
        "mlflow.utils.plugins._get_entry_points", return_value=[mock_entrypoint]
    ) as mock_get_group_all:
        registry = RequestHeaderProviderRegistry()
        registry.register_entrypoints()

    assert set(registry) == {provider_class.return_value}
    mock_entrypoint.load.assert_called_once_with()
    mock_get_group_all.assert_called_once_with("mlflow.request_header_provider")


@pytest.mark.parametrize(
    "exception", [AttributeError("test exception"), ImportError("test exception")]
)
def test_request_header_provider_registry_register_entrypoints_handles_exception(exception):
    mock_entrypoint = mock.Mock()
    mock_entrypoint.load.side_effect = exception

    with mock.patch(
        "mlflow.utils.plugins._get_entry_points", return_value=[mock_entrypoint]
    ) as mock_get_group_all:
        registry = RequestHeaderProviderRegistry()
        # Check that the raised warning contains the message from the original exception
        with pytest.warns(UserWarning, match="test exception"):
            registry.register_entrypoints()

    mock_entrypoint.load.assert_called_once_with()
    mock_get_group_all.assert_called_once_with("mlflow.request_header_provider")


def _currently_registered_request_header_provider_classes():
    return {
        provider.__class__
        for provider in mlflow.tracking.request_header.registry._request_header_provider_registry
    }


def test_registry_instance_defaults():
    expected_classes = {DatabricksRequestHeaderProvider}
    assert expected_classes.issubset(_currently_registered_request_header_provider_classes())


def test_registry_instance_loads_entrypoints():
    class MockRequestHeaderProvider:
        pass

    mock_entrypoint = mock.Mock()
    mock_entrypoint.load.return_value = MockRequestHeaderProvider

    with mock.patch(
        "mlflow.utils.plugins._get_entry_points", return_value=[mock_entrypoint]
    ) as mock_get_group_all:
        # Entrypoints are registered at import time, so we need to reload the module to register the
        # entrypoint given by the mocked entrypoints.get_group_all
        reload(mlflow.tracking.request_header.registry)

    assert MockRequestHeaderProvider in _currently_registered_request_header_provider_classes()
    mock_get_group_all.assert_called_once_with("mlflow.request_header_provider")


def test_run_context_provider_registry_with_installed_plugin():
    """This test requires the package in tests/resources/mlflow-test-plugin to be installed"""

    reload(mlflow.tracking.request_header.registry)

    from mlflow_test_plugin.request_header_provider import PluginRequestHeaderProvider

    assert PluginRequestHeaderProvider in _currently_registered_request_header_provider_classes()

    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    with mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True):
        assert resolve_request_headers()["test"] == "header"
```

## 原始行 97 · command_execution

命令：
```
/bin/bash -lc "sed -n '730,810p' mlflow/utils/databricks_utils.py
grep -R -n \"use_secret_scope_token\" mlflow --include='*.py' | head -80"
```

退出码：`0`

输出：
```
    def get_config(self):
        scope, key_prefix = get_db_info_from_uri(self.tracking_uri)

        if scope and key_prefix:
            dbutils = _get_dbutils()
            if dbutils:
                # Prefix differentiates users and is provided as path information in the URI
                host = dbutils.secrets.get(scope=scope, key=key_prefix + "-host")
                token = dbutils.secrets.get(scope=scope, key=key_prefix + "-token")
                return DatabricksConfig.from_token(host=host, token=token, insecure=False)

        return None


def get_databricks_host_creds(server_uri=None):
    """
    Reads in configuration necessary to make HTTP requests to a Databricks server. This
    uses Databricks SDK workspace client API,
    If no available credential configuration is found to the server URI, this function
    will attempt to retrieve these credentials from the Databricks Secret Manager. For that to work,
    the server URI will need to be of the following format: "databricks://scope:prefix". In the
    Databricks Secret Manager, we will query for a secret in the scope "<scope>" for secrets with
    keys of the form "<prefix>-host" and "<prefix>-token". Note that this prefix *cannot* be empty
    if trying to authenticate with this method. If found, those host credentials will be used. This
    method will throw an exception if sufficient auth cannot be found.

    Args:
        server_uri: A URI that specifies the Databricks profile you want to use for making
            requests.

    Returns:
        MlflowHostCreds which includes the hostname if databricks sdk authentication is available,
        otherwise includes the hostname and authentication information necessary to
        talk to the Databricks server.

    .. Warning:: This API is deprecated. In the future it might be removed.
    """

    if MLFLOW_ENABLE_DB_SDK.get():
        from databricks.sdk import WorkspaceClient

        profile, key_prefix = get_db_info_from_uri(server_uri)
        profile = profile or os.environ.get("DATABRICKS_CONFIG_PROFILE")
        if key_prefix is not None:
            try:
                config = TrackingURIConfigProvider(server_uri).get_config()
                WorkspaceClient(host=config.host, token=config.token)
                return MlflowHostCreds(
                    config.host,
                    token=config.token,
                    use_databricks_sdk=True,
                    use_secret_scope_token=True,
                )
            except Exception as e:
                raise MlflowException(
                    f"The hostname and credentials configured by {server_uri} is invalid. "
                    "Please create valid hostname secret by command "
                    f"'databricks secrets put-secret {profile} {key_prefix}-host' and "
                    "create valid token secret by command "
                    f"'databricks secrets put-secret {profile} {key_prefix}-token'."
                ) from e
        try:
            # Using databricks-sdk to create Databricks WorkspaceClient instance,
            # If authentication is failed, MLflow falls back to legacy authentication methods,
            # see `SparkTaskContextConfigProvider`, `DatabricksModelServingConfigProvider`,
            # and `TrackingURIConfigProvider`.
            # databricks-sdk supports many kinds of authentication ways,
            # it will try to read authentication information by the following ways:
            # 1. Read dynamic generated token via databricks `dbutils`.
            # 2. parse relevant environment variables (such as DATABRICKS_HOST + DATABRICKS_TOKEN
            #    or DATABRICKS_HOST + DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET)
            #    to get authentication information
            # 3. parse ~/.databrickscfg file (generated by databricks-CLI command-line tool)
            #    to get authentication information.
            # databricks-sdk is designed to hide authentication details and
            # support various authentication ways, so that it does not provide API
            # to get credential values. Instead, we can use ``WorkspaceClient``
            # API to invoke databricks shard restful APIs.
            WorkspaceClient(profile=profile)
            use_databricks_sdk = True
            databricks_auth_profile = profile
mlflow/utils/rest_utils.py:264:    use_secret_scope_token,
mlflow/utils/rest_utils.py:274:    if use_secret_scope_token:
mlflow/utils/rest_utils.py:674:        use_secret_scope_token=False,
mlflow/utils/rest_utils.py:705:        self.use_secret_scope_token = use_secret_scope_token
mlflow/utils/databricks_utils.py:781:                    use_secret_scope_token=True,
```

## 原始行 99 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"raise_on_status=False\\|respect_retry_after_header\\|retry_timeout_seconds=\" mlflow tests --include='*.py' | head -160"
```

退出码：`0`

输出：
```
mlflow/webhooks/delivery.py:84:        respect_retry_after_header=True,  # Automatically handle Retry-After headers
mlflow/webhooks/delivery.py:85:        raise_on_status=False,  # Don't raise on these status codes
mlflow/utils/rest_utils.py:268:    retry_timeout_seconds=None,
mlflow/utils/rest_utils.py:282:        retry_timeout_seconds=retry_timeout_seconds
mlflow/utils/rest_utils.py:575:    retry_timeout_seconds=None,
mlflow/utils/databricks_utils.py:1436:        raise_on_status=False,
mlflow/deployments/databricks/__init__.py:159:            retry_timeout_seconds=retry_timeout_seconds,
mlflow/deployments/databricks/__init__.py:160:            raise_on_status=False,
mlflow/deployments/databricks/__init__.py:191:            retry_timeout_seconds=retry_timeout_seconds,
mlflow/deployments/databricks/__init__.py:192:            raise_on_status=False,
mlflow/deployments/databricks/__init__.py:268:            retry_timeout_seconds=MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT.get(),
mlflow/deployments/databricks/__init__.py:328:            retry_timeout_seconds=MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT.get(),
mlflow/deployments/mlflow/__init__.py:137:            raise_on_status=False,
mlflow/store/artifact/databricks_artifact_repo.py:176:        self, service, api, json_body=None, path_params=None, retry_timeout_seconds=None
mlflow/store/artifact/databricks_artifact_repo.py:203:            retry_timeout_seconds=retry_timeout_seconds,
mlflow/store/artifact/databricks_artifact_repo_resources.py:284:            retry_timeout_seconds=timeout,
mlflow/store/tracking/rest_store.py:179:                retry_timeout_seconds=1,
mlflow/store/tracking/rest_store.py:193:        retry_timeout_seconds=None,
mlflow/store/tracking/rest_store.py:209:            retry_timeout_seconds=retry_timeout_seconds,
mlflow/store/tracking/rest_store.py:369:                retry_timeout_seconds=MLFLOW_ASYNC_TRACE_LOGGING_RETRY_TIMEOUT.get(),
mlflow/store/tracking/databricks_rest_store.py:96:        retry_timeout_seconds=None,
mlflow/store/tracking/databricks_rest_store.py:104:                retry_timeout_seconds=retry_timeout_seconds,
mlflow/store/tracking/databricks_rest_store.py:160:            retry_timeout_seconds=MLFLOW_ASYNC_TRACE_LOGGING_RETRY_TIMEOUT.get(),
tests/utils/test_rest_utils.py:504:            respect_retry_after_header=True,
tests/utils/test_rest_utils.py:524:            respect_retry_after_header=False,
tests/utils/test_rest_utils.py:677:            retry_timeout_seconds=10,
tests/utils/test_rest_utils.py:744:            retry_timeout_seconds=0.2,  # Very short timeout
tests/utils/test_rest_utils.py:802:                retry_timeout_seconds=10,
tests/utils/test_rest_utils.py:835:            retry_timeout_seconds=None,
tests/utils/test_rest_utils.py:842:            retry_timeout_seconds=mock.ANY,
tests/utils/test_rest_utils.py:863:            retry_timeout_seconds=None,
tests/utils/test_rest_utils.py:869:            retry_timeout_seconds=mock.ANY,
tests/utils/test_rest_utils.py:908:            retry_timeout_seconds=600,
tests/utils/test_rest_utils.py:950:                timeout=timeout, retry_timeout_seconds=retry_timeout_seconds
tests/utils/test_rest_utils.py:961:                timeout=timeout, retry_timeout_seconds=retry_timeout_seconds
tests/store/tracking/test_databricks_rest_store.py:92:def _args(host_creds, endpoint, method, json_body, version, retry_timeout_seconds=None):
tests/store/tracking/test_databricks_rest_store.py:114:    retry_timeout_seconds=None,
tests/store/tracking/test_databricks_rest_store.py:168:            retry_timeout_seconds=1,
tests/store/tracking/test_rest_store.py:194:def _args(host_creds, endpoint, method, json_body, use_v3=False, retry_timeout_seconds=None):
tests/store/tracking/test_rest_store.py:211:    http_request, host_creds, endpoint, method, json_body, use_v3=False, retry_timeout_seconds=None
tests/store/tracking/test_rest_store.py:689:            retry_timeout_seconds=1,
tests/store/tracking/test_rest_store.py:2857:            retry_timeout_seconds=1,
```

## 原始行 101 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from databricks.sdk.core import ApiClient
import inspect
print(inspect.signature(ApiClient.do))
print(inspect.getsource(ApiClient.do))
PY"
```

退出码：`0`

输出：
```
(self, method: str, path: Optional[str] = None, url: Optional[str] = None, query: Optional[dict] = None, headers: Optional[dict] = None, body: Optional[dict] = None, raw: bool = False, files=None, data=None, auth: Optional[Callable[[requests.models.PreparedRequest], requests.models.PreparedRequest]] = None, response_headers: Optional[List[str]] = None) -> Union[dict, list, BinaryIO]
    def do(
        self,
        method: str,
        path: Optional[str] = None,
        url: Optional[str] = None,
        query: Optional[dict] = None,
        headers: Optional[dict] = None,
        body: Optional[dict] = None,
        raw: bool = False,
        files=None,
        data=None,
        auth: Optional[Callable[[requests.PreparedRequest], requests.PreparedRequest]] = None,
        response_headers: Optional[List[str]] = None,
    ) -> Union[dict, list, BinaryIO]:
        if url is None:
            # Remove extra `/` from path for Files API
            # Once we've fixed the OpenAPI spec, we can remove this
            path = re.sub("^/api/2.0/fs/files//", "/api/2.0/fs/files/", path)
            url = f"{self._cfg.host}{path}"
        return self._api_client.do(
            method=method,
            url=url,
            query=query,
            headers=headers,
            body=body,
            raw=raw,
            files=files,
            data=data,
            auth=auth,
            response_headers=response_headers,
        )
```

## 原始行 104 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from databricks.sdk.core import ApiClient
print(inspect.getsource(ApiClient)[:1000])
from databricks.sdk.core import _BaseClient
src=inspect.getsource(_BaseClient.do)
print(src)
PY"
```

退出码：`0`

输出：
```
class ApiClient:

    def __init__(self, cfg: Config):
        self._cfg = cfg
        self._api_client = _BaseClient(
            debug_truncate_bytes=cfg.debug_truncate_bytes,
            retry_timeout_seconds=cfg.retry_timeout_seconds,
            user_agent_base=cfg.user_agent,
            header_factory=cfg.authenticate,
            max_connection_pools=cfg.max_connection_pools,
            max_connections_per_pool=cfg.max_connections_per_pool,
            pool_block=True,
            http_timeout_seconds=cfg.http_timeout_seconds,
            extra_error_customizers=[_AddDebugErrorCustomizer(cfg)],
            clock=cfg.clock,
        )

    @property
    def account_id(self) -> str:
        return self._cfg.account_id

    @property
    def is_account_client(self) -> bool:
        return self._cfg.is_account_client

    def get_oauth_token(self, auth_details: str) -> Token:
        if not self._cfg.auth_type:
            self._cfg.authenticate()
        original_token = self._cfg
    def do(
        self,
        method: str,
        url: str,
        query: Optional[dict] = None,
        headers: Optional[dict] = None,
        body: Optional[dict] = None,
        raw: bool = False,
        files=None,
        data=None,
        auth: Optional[Callable[[requests.PreparedRequest], requests.PreparedRequest]] = None,
        response_headers: Optional[List[str]] = None,
    ) -> Union[dict, list, BinaryIO]:
        if headers is None:
            headers = {}
        headers["User-Agent"] = self._user_agent_base

        # Wrap strings and bytes in a seekable stream so that we can rewind them.
        if isinstance(data, (str, bytes)):
            data = io.BytesIO(data.encode("utf-8") if isinstance(data, str) else data)

        if not data:
            # The request is not a stream.
            call = retried(
                timeout=timedelta(seconds=self._retry_timeout_seconds),
                is_retryable=self._is_retryable,
                clock=self._clock,
            )(self._perform)
        elif self._is_seekable_stream(data):
            # Keep track of the initial position of the stream so that we can rewind to it
            # if we need to retry the request.
            initial_data_position = data.tell()

            def rewind():
                logger.debug(f"Rewinding input data to offset {initial_data_position} before retry")
                data.seek(initial_data_position)

            call = retried(
                timeout=timedelta(seconds=self._retry_timeout_seconds),
                is_retryable=self._is_retryable,
                clock=self._clock,
                before_retry=rewind,
            )(self._perform)
        else:
            # Do not retry if the stream is not seekable. This is necessary to avoid bugs
            # where the retry doesn't re-read already read data from the stream.
            logger.debug(f"Retry disabled for non-seekable stream: type={type(data)}")
            call = self._perform

        response = call(
            method,
            url,
            query=query,
            headers=headers,
            body=body,
            raw=raw,
            files=files,
            data=data,
            auth=auth,
        )

        resp = dict()
        for header in response_headers if response_headers else []:
            resp[header] = response.headers.get(Casing.to_header_case(header))
        if raw:
            streaming_response = _StreamingResponse(response)
            streaming_response.set_chunk_size(self._streaming_buffer_size)
            resp["contents"] = streaming_response
            return resp
        if not len(response.content):
            return resp

        json_response = response.json()
        if json_response is None:
            return resp

        if isinstance(json_response, list):
            return json_response

        return {**resp, **json_response}
```

## 原始行 107 · command_execution

命令：
```
/bin/bash -lc "sed -n '108,165p' mlflow/environment_variables.py
sed -n '735,765p' mlflow/environment_variables.py
sed -n '1370,1450p' mlflow/utils/databricks_utils.py
python - <<'PY'
from mlflow.environment_variables import _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT,_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT,MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT
print(_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get(),_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get(),MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get())
PY"
```

退出码：`0`

输出：
```

#: Specifies the ``dfs_tmpdir`` parameter to use for ``mlflow.spark.save_model``,
#: ``mlflow.spark.log_model`` and ``mlflow.spark.load_model``. See
#: https://www.mlflow.org/docs/latest/python_api/mlflow.spark.html#mlflow.spark.save_model
#: for more information.
#: (default: ``/tmp/mlflow``)
MLFLOW_DFS_TMP = _EnvironmentVariable("MLFLOW_DFS_TMP", str, "/tmp/mlflow")

#: Specifies the maximum number of retries with exponential backoff for MLflow HTTP requests
#: (default: ``7``)
MLFLOW_HTTP_REQUEST_MAX_RETRIES = _EnvironmentVariable(
    "MLFLOW_HTTP_REQUEST_MAX_RETRIES",
    int,
    # Important: It's common for MLflow backends to rate limit requests for more than 1 minute.
    # To remain resilient to rate limiting, the MLflow client needs to retry for more than 1
    # minute. Assuming 2 seconds per retry, 7 retries with backoff will take ~ 4 minutes,
    # which is appropriate for most rate limiting scenarios
    7,
)

#: Specifies the backoff increase factor between MLflow HTTP request failures
#: (default: ``2``)
MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR = _EnvironmentVariable(
    "MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR", int, 2
)

#: Specifies the backoff jitter between MLflow HTTP request failures
#: (default: ``1.0``)
MLFLOW_HTTP_REQUEST_BACKOFF_JITTER = _EnvironmentVariable(
    "MLFLOW_HTTP_REQUEST_BACKOFF_JITTER", float, 1.0
)

#: Specifies the timeout in seconds for MLflow HTTP requests
#: (default: ``120``)
MLFLOW_HTTP_REQUEST_TIMEOUT = _EnvironmentVariable("MLFLOW_HTTP_REQUEST_TIMEOUT", int, 120)

#: Specifies the timeout in seconds for MLflow deployment client HTTP requests
#: (non-predict operations). This is separate from MLFLOW_HTTP_REQUEST_TIMEOUT to allow
#: longer timeouts for LLM calls (default: ``300``)
MLFLOW_DEPLOYMENT_CLIENT_HTTP_REQUEST_TIMEOUT = _EnvironmentVariable(
    "MLFLOW_DEPLOYMENT_CLIENT_HTTP_REQUEST_TIMEOUT", int, 300
)

#: Specifies whether to respect Retry-After header on status codes defined as
#: Retry.RETRY_AFTER_STATUS_CODES or not for MLflow HTTP request
#: (default: ``True``)
MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER = _BooleanEnvironmentVariable(
    "MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER", True
)

#: Internal-only configuration that sets an upper bound to the allowable maximum
#: retries for HTTP requests
#: (default: ``10``)
_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT = _EnvironmentVariable(
    "_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT", int, 10
)

#: Internal-only configuration that sets the upper bound for an HTTP backoff_factor
#: variable sets the `pool_maxsize` parameter in the `requests.adapters.HTTPAdapter` constructor.
#: By adjusting this variable, users can enhance the concurrency of HTTP requests made by MLflow.
MLFLOW_HTTP_POOL_MAXSIZE = _EnvironmentVariable("MLFLOW_HTTP_POOL_MAXSIZE", int, 10)

#: Enable Unity Catalog integration for MLflow AI Gateway.
#: (default: ``False``)
MLFLOW_ENABLE_UC_FUNCTIONS = _BooleanEnvironmentVariable("MLFLOW_ENABLE_UC_FUNCTIONS", False)

#: Specifies the length of time in seconds for the asynchronous logging thread to wait before
#: logging a batch.
MLFLOW_ASYNC_LOGGING_BUFFERING_SECONDS = _EnvironmentVariable(
    "MLFLOW_ASYNC_LOGGING_BUFFERING_SECONDS", int, None
)

#: Whether to enable Databricks SDK. If true, MLflow uses databricks-sdk to send HTTP requests
#: to Databricks endpoint, otherwise MLflow uses ``requests`` library to send HTTP requests
#: to Databricks endpoint. Note that if you want to use OAuth authentication, you have to
#: set this environment variable to true.
#: (default: ``True``)
MLFLOW_ENABLE_DB_SDK = _BooleanEnvironmentVariable("MLFLOW_ENABLE_DB_SDK", True)

#: A flag that's set to 'true' in the child process for capturing modules.
_MLFLOW_IN_CAPTURE_MODULE_PROCESS = _BooleanEnvironmentVariable(
    "MLFLOW_IN_CAPTURE_MODULE_PROCESS", False
)

#: Use DatabricksSDKModelsArtifactRepository when registering and loading models to and from
#: Databricks UC. This is required for SEG(Secure Egress Gateway) enabled workspaces and helps
#: eliminate models exfiltration risk associated with temporary scoped token generation used in
#: existing model artifact repo classes.
MLFLOW_USE_DATABRICKS_SDK_MODEL_ARTIFACTS_REPO_FOR_UC = _BooleanEnvironmentVariable(

        class DynamicConfigProvider(DatabricksConfigProvider):
            def get_config(self):
                # Invoking getContext() will attempt to find the credentials related to the
                # current command execution, so it's critical that we execute it on every
                # get_config().
                api_token_option = notebook_utils.getContext().apiToken()
                api_url_option = notebook_utils.getContext().apiUrl()
                ssl_trust_all = entry_point.getDriverConf().workflowSslTrustAll()

                if not api_token_option.isDefined() or not api_url_option.isDefined():
                    return None

                return DatabricksConfig.from_token(
                    host=api_url_option.get(), token=api_token_option.get(), insecure=ssl_trust_all
                )

    _dynamic_token_config_provider = DynamicConfigProvider()


if is_in_databricks_runtime():
    try:
        dbutils = _get_dbutils()
        _init_databricks_dynamic_token_config_provider(dbutils.entry_point)
    except _NoDbutilsError:
        # If there is no dbutils available, it means it is run in databricks driver local suite,
        # in this case, we don't need to initialize databricks token because
        # there is no backend mlflow service available.
        pass


def get_databricks_nfs_temp_dir():
    entry_point = _get_dbutils().entry_point
    if getpass.getuser().lower() == "root":
        return entry_point.getReplNFSTempDir()
    else:
        try:
            # If it is not ROOT user, it means the code is running in Safe-spark.
            # In this case, we should get temporary directory of current user.
            # and `getReplNFSTempDir` will be deprecated for this case.
            return entry_point.getUserNFSTempDir()
        except Exception:
            # fallback
            return entry_point.getReplNFSTempDir()


def get_databricks_local_temp_dir():
    entry_point = _get_dbutils().entry_point
    if getpass.getuser().lower() == "root":
        return entry_point.getReplLocalTempDir()
    else:
        try:
            # If it is not ROOT user, it means the code is running in Safe-spark.
            # In this case, we should get temporary directory of current user.
            # and `getReplLocalTempDir` will be deprecated for this case.
            return entry_point.getUserLocalTempDir()
        except Exception:
            # fallback
            return entry_point.getReplLocalTempDir()


def stage_model_for_databricks_model_serving(model_name: str, model_version: str):
    response = http_request(
        host_creds=get_databricks_host_creds(),
        endpoint="/api/2.0/serving-endpoints:stageDeployment",
        method="POST",
        raise_on_status=False,
        json={
            "model_name": model_name,
            "model_version": model_version,
        },
    )
    augmented_raise_for_status(response)


P = ParamSpec("P")
T = TypeVar("T")


def databricks_api_disabled(api_name: str = "This API", alternative: str | None = None):
    """
10 120 500
```

## 原始行 110 · file_change

```
{
  "id": "item_64",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/deployments/__init__.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/deployments/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/deployments/interface.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/deployments/server/config.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/gateway/config.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracking/request_header/databricks_request_header_provider.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracking/request_header/default_request_header_provider.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracking/request_header/registry.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/utils/request_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 113 · command_execution

命令：
```
/bin/bash -lc "grep -n \"class EndpointType\\|def get_deploy_client\\|class Endpoint(Response\\|def _get_http_response\\|def resolve_request_headers\\|def __init__(self, target_uri\" mlflow/gateway/config.py mlflow/deployments/interface.py mlflow/deployments/server/config.py mlflow/utils/request_utils.py mlflow/tracking/request_header/registry.py mlflow/deployments/base.py"
```

退出码：`0`

输出：
```
mlflow/gateway/config.py:323:class EndpointType(str, Enum):
mlflow/deployments/interface.py:15:def get_deploy_client(target_uri=None):
mlflow/deployments/server/config.py:7:class Endpoint(ResponseModel):
mlflow/utils/request_utils.py:130:def _get_http_response_with_retries(
mlflow/tracking/request_header/registry.py:46:def resolve_request_headers():
mlflow/deployments/base.py:88:    def __init__(self, target_uri):
```

## 原始行 116 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from databricks.sdk.errors import DatabricksError
print([x for x in dir(DatabricksError) if not x.startswith('_')])
e=DatabricksError(error_code='INTERNAL_ERROR',message='x')
print(e.__dict__, str(e))
PY
sed -n '140,170p' mlflow/environment_variables.py"
```

退出码：`0`

输出：
```
['add_note', 'args', 'characters_written', 'errno', 'filename', 'filename2', 'get_error_details', 'get_error_info', 'strerror', 'with_traceback']
{'error_code': 'INTERNAL_ERROR', 'retry_after_secs': None, '_error_details': ErrorDetails(error_info=None, request_info=None, retry_info=None, debug_info=None, quota_failure=None, precondition_failure=None, bad_request=None, resource_info=None, help=None, unknown_details=[]), 'kwargs': {}, 'details': []} x
#: Specifies the timeout in seconds for MLflow HTTP requests
#: (default: ``120``)
MLFLOW_HTTP_REQUEST_TIMEOUT = _EnvironmentVariable("MLFLOW_HTTP_REQUEST_TIMEOUT", int, 120)

#: Specifies the timeout in seconds for MLflow deployment client HTTP requests
#: (non-predict operations). This is separate from MLFLOW_HTTP_REQUEST_TIMEOUT to allow
#: longer timeouts for LLM calls (default: ``300``)
MLFLOW_DEPLOYMENT_CLIENT_HTTP_REQUEST_TIMEOUT = _EnvironmentVariable(
    "MLFLOW_DEPLOYMENT_CLIENT_HTTP_REQUEST_TIMEOUT", int, 300
)

#: Specifies whether to respect Retry-After header on status codes defined as
#: Retry.RETRY_AFTER_STATUS_CODES or not for MLflow HTTP request
#: (default: ``True``)
MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER = _BooleanEnvironmentVariable(
    "MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER", True
)

#: Internal-only configuration that sets an upper bound to the allowable maximum
#: retries for HTTP requests
#: (default: ``10``)
_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT = _EnvironmentVariable(
    "_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT", int, 10
)

#: Internal-only configuration that sets the upper bound for an HTTP backoff_factor
#: (default: ``120``)
_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT = _EnvironmentVariable(
    "_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT", int, 120
)
```

## 原始行 119 · file_change

```
{
  "id": "item_70",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/utils/rest_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 121 · agent_message

```
The first implementation pass is in place, including the locally missing retry-session and request-header helpers that the HTTP interface depends on. I’m running the focused suites now; I’ll use their failures to tighten call signatures and edge-case behavior.
```

## 原始行 123 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/deployments/test_interface.py tests/deployments/test_deployments.py tests/gateway/test_gateway_config_parsing.py tests/utils/test_rest_utils.py tests/utils/test_request_utils.py tests/tracking/request_header/test_default_request_header_provider.py tests/tracking/request_header/test_databricks_request_header_provider.py tests/tracking/request_header/test_registry.py'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 138 items

tests/deployments/test_interface.py [32m.[0m[32m.[0m[31mF[0m[31mF[0m[31m                                 [  2%][0m
tests/deployments/test_deployments.py [31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31m                   [ 14%][0m
tests/gateway/test_gateway_config_parsing.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m     [ 31%][0m
tests/utils/test_rest_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[31m [ 60%]
[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                                                 [ 66%][0m
tests/utils/test_request_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                    [ 80%][0m
tests/tracking/request_header/test_default_request_header_provider.py [32m.[0m[32m.[0m[31m [ 81%]
[0m[31m                                                                         [ 81%][0m
tests/tracking/request_header/test_databricks_request_header_provider.py [32m.[0m[31m [ 82%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                                          [ 93%][0m
tests/tracking/request_header/test_registry.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[31mF[0m[31m                 [100%][0m

=================================== FAILURES ===================================
[31m[1m______________ test_get_deploy_client_from_set_deployments_target ______________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get_deploy_client_from_set_deployments_target[39;49;00m():[90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mdeployments[39;49;00m[90m [39;49;00m[94mimport[39;49;00m set_deployments_target[90m[39;49;00m
    [90m[39;49;00m
        set_deployments_target([33m"[39;49;00m[33mdatabricks[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>       [94massert[39;49;00m get_deploy_client([94mNone[39;49;00m) [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

set_deployments_target = <function set_deployments_target at 0x71d1ec1fd6c0>

[1m[31mtests/deployments/test_interface.py[0m:23: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'databricks'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'databricks'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'databricks'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________ test_get_deploy_client_from_env ________________________[0m

set_deployment_envs = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get_deploy_client_from_env[39;49;00m(set_deployment_envs):[90m[39;49;00m
>       [94massert[39;49;00m get_deploy_client([94mNone[39;49;00m) [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

set_deployment_envs = None

[1m[31mtests/deployments/test_interface.py[0m:32: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'databricks'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'databricks'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'databricks'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________________ test_create_success ______________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_create_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:17: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________________ test_delete_success ______________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_delete_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:28: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________________ test_update_success ______________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_update_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:33: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________________________ test_list_success _______________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_list_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________________ test_get_success _______________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:45: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________ test_endpoint_create_success _________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_create_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:51: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________ test_endpoint_delete_success _________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_delete_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:58: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________ test_endpoint_update_success _________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_update_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:63: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_endpoint_list_success __________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_list_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:68: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_endpoint_get_success ___________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_get_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:74: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m____________________________ test_wrong_target_name ____________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_wrong_target_name[39;49;00m():[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises([90m[39;49;00m
            MlflowException, match=[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33mwrong_target[39;49;00m[33m"[39;49;00m[33m'[39;49;00m[90m[39;49;00m
        ):[90m[39;49;00m
>           deployments.get_deploy_client([33m"[39;49;00m[33mwrong_target[39;49;00m[33m"[39;49;00m)[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:83: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'wrong_target'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'wrong_target'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'wrong_target'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_plugin_doesnot_have_required_attrib ___________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_plugin_doesnot_have_required_attrib[39;49;00m():[90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mDummyPlugin[39;49;00m:[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        dummy_plugin = DummyPlugin()[90m[39;49;00m
        plugin_manager = DeploymentPlugins()[90m[39;49;00m
        plugin_manager.registry[[33m"[39;49;00m[33mdummy[39;49;00m[33m"[39;49;00m] = dummy_plugin[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises(MlflowException, match=[33m"[39;49;00m[33mPlugin registered for the target dummy[39;49;00m[33m"[39;49;00m):[90m[39;49;00m
>           plugin_manager[[33m"[39;49;00m[33mdummy[39;49;00m[33m"[39;49;00m][90m[39;49;00m

DummyPlugin = <class 'tests.deployments.test_deployments.test_plugin_doesnot_have_required_attrib.<locals>.DummyPlugin'>
dummy_plugin = <tests.deployments.test_deployments.test_plugin_doesnot_have_required_attrib.<locals>.DummyPlugin object at 0x71d1e7d68910>
plugin_manager = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1e7d68210>

[1m[31mtests/deployments/test_deployments.py[0m:94: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1e7d68210>
item = 'dummy'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'dummy'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1e7d68210>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_plugin_raising_error ___________________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e7d93b90>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_plugin_raising_error[39;49;00m(monkeypatch):[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e7d93b90>

[1m[31mtests/deployments/test_deployments.py[0m:98: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________________ test_target_uri_parsing ____________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_target_uri_parsing[39;49;00m():[90m[39;49;00m
>       deployments.get_deploy_client(f_target)[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:106: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________ test_explain_with_no_target_implementation __________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_explain_with_no_target_implementation[39;49;00m():[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[90m [39;49;00m[94mimport[39;49;00m fake_deployment_plugin[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'mlflow_test_plugin'[0m


[1m[31mtests/deployments/test_deployments.py[0m:112: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_explain_with_target_implementation ____________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_explain_with_target_implementation[39;49;00m():[90m[39;49;00m
>       target_client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:124: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           target_name = parse_target_uri(item)[90m[39;49;00m
                          ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           NameError: name 'parse_target_uri' is not defined[0m

item       = 'faketarget'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x71d1ec1f6b90>

[1m[31mmlflow/deployments/plugin_manager.py[0m:89: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________ test_route_configuration_parsing _______________________[0m

basic_config_dict = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'model': {'config': {'openai_api_base': 'https://api.openai.com...': {'config': {'anthropic_api_key': 'api_key'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}]}
tmp_path = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e7d08dd0>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_route_configuration_parsing[39;49;00m(basic_config_dict, tmp_path, monkeypatch):[90m[39;49;00m
        conf_path = tmp_path.joinpath([33m"[39;49;00m[33mconfig.yaml[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        conf_path.write_text(yaml.safe_dump(basic_config_dict))[90m[39;49;00m
    [90m[39;49;00m
        loaded_config = _load_gateway_config(conf_path)[90m[39;49;00m
    [90m[39;49;00m
        save_path = tmp_path.joinpath([33m"[39;49;00m[33mconfig2.yaml[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        _save_route_config(loaded_config, save_path)[90m[39;49;00m
>       loaded_from_save = _load_gateway_config(save_path)[90m[39;49;00m
                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

basic_config_dict = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'model': {'config': {'openai_api_base': 'https://api.openai.com...': {'config': {'anthropic_api_key': 'api_key'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}]}
conf_path  = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0/config.yaml')
loaded_config = GatewayConfig(endpoints=[EndpointConfig(name='completions-gpt4', endpoint_type=<EndpointType.LLM_V1_COMPLETIONS: 'llm/...pic'>, config=AnthropicConfig(anthropic_api_key='api_key', anthropic_version='2023-06-01')), limit=None)], routes=None)
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e7d08dd0>
save_path  = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0/config2.yaml')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0')

[1m[31mtests/gateway/test_gateway_config_parsing.py[0m:138: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/gateway/config.py[0m:520: in _load_gateway_config
    [0m[94mreturn[39;49;00m GatewayConfig(**configuration)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        configuration = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'limit': None, 'model': {'config': {'openai_api_base': 'https:/...hropic_version': '2023-06-01'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}], 'routes': None}
        path       = PosixPath('/tmp/pytest-of-root/pytest-0/test_route_configuration_parsi0/config2.yaml')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'mlflow.gateway.config.EndpointConfig'>, value = None

    [0m[37m@field_validator[39;49;00m([33m"[39;49;00m[33mlimit[39;49;00m[33m"[39;49;00m, mode=[33m"[39;49;00m[33mbefore[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mvalidate_limit[39;49;00m([96mcls[39;49;00m, value):[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mlimits[39;49;00m[90m [39;49;00m[94mimport[39;49;00m parse[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'limits'[0m

cls        = <class 'mlflow.gateway.config.EndpointConfig'>
value      = None

[1m[31mmlflow/gateway/config.py[0m:404: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________ test_http_request_with_aws_sigv4 _______________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e7c4bb50>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_with_aws_sigv4[39;49;00m(monkeypatch):[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the "requests_auth_aws_sigv4" package to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mrequests_auth_aws_sigv4[39;49;00m[90m [39;49;00m[94mimport[39;49;00m AWSSigV4[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'requests_auth_aws_sigv4'[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e7c4bb50>

[1m[31mtests/utils/test_rest_utils.py[0m:147: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________________ test_http_request_request_headers _______________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_request_headers[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'mlflow_test_plugin'[0m


[1m[31mtests/utils/test_rest_utils.py[0m:290: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________ test_http_request_request_headers_default ___________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_request_headers_default[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'mlflow_test_plugin'[0m


[1m[31mtests/utils/test_rest_utils.py[0m:316: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________ test_http_request_request_headers_default_and_extra_header __________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_request_headers_default_and_extra_header[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'mlflow_test_plugin'[0m


[1m[31mtests/utils/test_rest_utils.py[0m:353: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____ test_http_request_explains_how_to_increase_timeout_in_error_message ______[0m

host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x71d1e7b5e690>
endpoint = '/my/endpoint', method = 'GET', max_retries = 7, backoff_factor = 2
backoff_jitter = 1.0, extra_headers = None
retry_codes = frozenset({408, 429, 500, 502, 503, 504}), timeout = 120
raise_on_status = True, respect_retry_after_header = True
retry_timeout_seconds = None, kwargs = {}, url = 'http://my-host/my/endpoint'
headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mhttp_request[39;49;00m([90m[39;49;00m
        host_creds,[90m[39;49;00m
        endpoint,[90m[39;49;00m
        method,[90m[39;49;00m
        max_retries=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_factor=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_jitter=[94mNone[39;49;00m,[90m[39;49;00m
        extra_headers=[94mNone[39;49;00m,[90m[39;49;00m
        retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,[90m[39;49;00m
        timeout=[94mNone[39;49;00m,[90m[39;49;00m
        raise_on_status=[94mTrue[39;49;00m,[90m[39;49;00m
        respect_retry_after_header=[94mNone[39;49;00m,[90m[39;49;00m
        retry_timeout_seconds=[94mNone[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Make an authenticated HTTP request to an MLflow service endpoint."""[39;49;00m[90m[39;49;00m
        max_retries = MLFLOW_HTTP_REQUEST_MAX_RETRIES.get() [94mif[39;49;00m max_retries [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m max_retries[90m[39;49;00m
        backoff_factor = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR.get() [94mif[39;49;00m backoff_factor [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_factor[90m[39;49;00m
        )[90m[39;49;00m
        backoff_jitter = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_JITTER.get() [94mif[39;49;00m backoff_jitter [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_jitter[90m[39;49;00m
        )[90m[39;49;00m
        timeout = MLFLOW_HTTP_REQUEST_TIMEOUT.get() [94mif[39;49;00m timeout [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m timeout[90m[39;49;00m
        respect_retry_after_header = ([90m[39;49;00m
            MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER.get()[90m[39;49;00m
            [94mif[39;49;00m respect_retry_after_header [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
            [94melse[39;49;00m respect_retry_after_header[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m max_retries < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe max_retries value must be either zero or a positive integer.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m max_retries > _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured max_retries exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe backoff_factor value must be zero or a positive number.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor > _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured backoff_factor exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_secret [95mand[39;49;00m [95mnot[39;49;00m MLFLOW_ENABLE_DB_SDK.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException([90m[39;49;00m
                [33m"[39;49;00m[33mOAuth authentication requires the Databricks SDK. Set MLFLOW_ENABLE_DB_SDK=true.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                error_code=CUSTOMER_UNAUTHORIZED,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        url = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.host.rstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m/[39;49;00m[33m{[39;49;00mendpoint.lstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        headers = _resolve_request_headers(extra_headers)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.use_databricks_sdk:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mdatabricks[39;49;00m[04m[96m.[39;49;00m[04m[96msdk[39;49;00m[04m[96m.[39;49;00m[04m[96merrors[39;49;00m[90m [39;49;00m[94mimport[39;49;00m DatabricksError[90m[39;49;00m
    [90m[39;49;00m
            retry_timeout = ([90m[39;49;00m
                MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get()[90m[39;49;00m
                [94mif[39;49;00m retry_timeout_seconds [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m retry_timeout_seconds[90m[39;49;00m
            )[90m[39;49;00m
            workspace_client = get_workspace_client([90m[39;49;00m
                host_creds.use_secret_scope_token,[90m[39;49;00m
                host_creds.host,[90m[39;49;00m
                host_creds.token,[90m[39;49;00m
                host_creds.databricks_auth_profile,[90m[39;49;00m
                retry_timeout_seconds=retry_timeout_seconds,[90m[39;49;00m
                timeout=timeout,[90m[39;49;00m
            )[90m[39;49;00m
            sdk_kwargs = {[90m[39;49;00m
                [33m"[39;49;00m[33mmethod[39;49;00m[33m"[39;49;00m: method,[90m[39;49;00m
                [33m"[39;49;00m[33mpath[39;49;00m[33m"[39;49;00m: endpoint,[90m[39;49;00m
                [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
                [33m"[39;49;00m[33mraw[39;49;00m[33m"[39;49;00m: [94mTrue[39;49;00m,[90m[39;49;00m
            }[90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mquery[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mbody[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
            [94mdef[39;49;00m[90m [39;49;00m[92mcall_sdk[39;49;00m():[90m[39;49;00m
                [94mreturn[39;49;00m workspace_client.api_client.do(**sdk_kwargs)[90m[39;49;00m
    [90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mwith[39;49;00m warnings.catch_warnings():[90m[39;49;00m
                    warnings.filterwarnings([90m[39;49;00m
                        [33m"[39;49;00m[33mignore[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        message=[33mf[39;49;00m[33m"[39;49;00m[33m.*[39;49;00m[33m{[39;49;00m_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING[33m}[39;49;00m[33m.*[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m
                    result = _retry_databricks_sdk_call_with_exponential_backoff([90m[39;49;00m
                        call_func=call_sdk,[90m[39;49;00m
                        retry_codes=retry_codes,[90m[39;49;00m
                        retry_timeout_seconds=retry_timeout,[90m[39;49;00m
                        backoff_factor=backoff_factor,[90m[39;49;00m
                        backoff_jitter=backoff_jitter,[90m[39;49;00m
                        max_retries=max_retries,[90m[39;49;00m
                    )[90m[39;49;00m
                contents = result.get([33m"[39;49;00m[33mcontents[39;49;00m[33m"[39;49;00m, result) [94mif[39;49;00m [96misinstance[39;49;00m(result, [96mdict[39;49;00m) [94melse[39;49;00m result[90m[39;49;00m
                [94mreturn[39;49;00m [96mgetattr[39;49;00m(contents, [33m"[39;49;00m[33m_response[39;49;00m[33m"[39;49;00m, contents)[90m[39;49;00m
            [94mexcept[39;49;00m DatabricksError [94mas[39;49;00m e:[90m[39;49;00m
                [94mreturn[39;49;00m _databricks_error_to_response(e, url)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.token:[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mBearer [39;49;00m[33m{[39;49;00mhost_creds.token[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m host_creds.username [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m host_creds.password [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            credentials = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.username[33m}[39;49;00m[33m:[39;49;00m[33m{[39;49;00mhost_creds.password[33m}[39;49;00m[33m"[39;49;00m.encode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33m"[39;49;00m[33mBasic [39;49;00m[33m"[39;49;00m + base64.b64encode(credentials).decode([33m"[39;49;00m[33mascii[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        request_kwargs = {[90m[39;49;00m
            [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
            [33m"[39;49;00m[33mverify[39;49;00m[33m"[39;49;00m: ([90m[39;49;00m
                host_creds.server_cert_path[90m[39;49;00m
                [94mif[39;49;00m host_creds.server_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m [95mnot[39;49;00m host_creds.ignore_tls_verification[90m[39;49;00m
            ),[90m[39;49;00m
            [33m"[39;49;00m[33mtimeout[39;49;00m[33m"[39;49;00m: timeout,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        }[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mcert[39;49;00m[33m"[39;49;00m] = host_creds.client_cert_path[90m[39;49;00m
        [94mif[39;49;00m host_creds.aws_sigv4:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mrequests_auth_aws_sigv4[39;49;00m[90m [39;49;00m[94mimport[39;49;00m AWSSigV4[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = AWSSigV4([33m"[39;49;00m[33mexecute-api[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94melif[39;49;00m host_creds.auth:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_auth[39;49;00m[04m[96m.[39;49;00m[04m[96mregistry[39;49;00m[90m [39;49;00m[94mimport[39;49;00m fetch_auth[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = fetch_auth(host_creds.auth)[90m[39;49;00m
    [90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           [94mreturn[39;49;00m _get_http_response_with_retries([90m[39;49;00m
                method,[90m[39;49;00m
                url,[90m[39;49;00m
                max_retries,[90m[39;49;00m
                backoff_factor,[90m[39;49;00m
                backoff_jitter,[90m[39;49;00m
                retry_codes,[90m[39;49;00m
                raise_on_status,[90m[39;49;00m
                respect_retry_after_header=respect_retry_after_header,[90m[39;49;00m
                **request_kwargs,[90m[39;49;00m
            )[90m[39;49;00m

backoff_factor = 2
backoff_jitter = 1.0
endpoint   = '/my/endpoint'
extra_headers = None
headers    = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}
host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x71d1e7b5e690>
kwargs     = {}
max_retries = 7
method     = 'GET'
raise_on_status = True
request_kwargs = {'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'timeout': 120, 'verify': True}
respect_retry_after_header = True
retry_codes = frozenset({408, 429, 500, 502, 503, 504})
retry_timeout_seconds = None
timeout    = 120
url        = 'http://my-host/my/endpoint'

[1m[31mmlflow/utils/rest_utils.py[0m:235: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/utils/request_utils.py[0m:155: in _get_http_response_with_retries
    [0m[94mreturn[39;49;00m session.request(method, url, timeout=timeout, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        allow_redirects = 'true'
        backoff_factor = 2
        backoff_jitter = 1.0
        kwargs     = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'verify': True}
        max_retries = 7
        method     = 'GET'
        raise_on_status = True
        respect_retry_after_header = True
        retry_codes = (408, 429, 500, 502, 503, 504)
        session    = <requests.sessions.Session object at 0x71d1e7c0e1d0>
        timeout    = 120
        url        = 'http://my-host/my/endpoint'
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1124: in __call__
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._mock_call(*args, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ('GET', 'http://my-host/my/endpoint')
        kwargs     = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'timeout': 120, 'verify': True}
        self       = <MagicMock name='request' id='125146349486480'>
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1128: in _mock_call
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._execute_mock_call(*args, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ('GET', 'http://my-host/my/endpoint')
        kwargs     = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'timeout': 120, 'verify': True}
        self       = <MagicMock name='request' id='125146349486480'>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <MagicMock name='request' id='125146349486480'>
args = ('GET', 'http://my-host/my/endpoint')
kwargs = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'timeout': 120, 'verify': True}
effect = <class 'requests.exceptions.Timeout'>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_execute_mock_call[39;49;00m([96mself[39;49;00m, /, *args, **kwargs):[90m[39;49;00m
        [90m# separate from _increment_mock_call so that awaited functions are[39;49;00m[90m[39;49;00m
        [90m# executed separately from their call, also AsyncMock overrides this method[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        effect = [96mself[39;49;00m.side_effect[90m[39;49;00m
        [94mif[39;49;00m effect [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m _is_exception(effect):[90m[39;49;00m
>               [94mraise[39;49;00m effect[90m[39;49;00m
[1m[31mE               requests.exceptions.Timeout[0m

args       = ('GET', 'http://my-host/my/endpoint')
effect     = <class 'requests.exceptions.Timeout'>
kwargs     = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'timeout': 120, 'verify': True}
self       = <MagicMock name='request' id='125146349486480'>

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1183: Timeout

[33mThe above exception was the direct cause of the following exception:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_explains_how_to_increase_timeout_in_error_message[39;49;00m():[90m[39;49;00m
        [94mwith[39;49;00m mock.patch([33m"[39;49;00m[33mrequests.Session.request[39;49;00m[33m"[39;49;00m, side_effect=requests.exceptions.Timeout):[90m[39;49;00m
            [94mwith[39;49;00m pytest.raises([90m[39;49;00m
                MlflowException,[90m[39;49;00m
                match=([90m[39;49;00m
                    [33mr[39;49;00m[33m"[39;49;00m[33mTo increase the timeout, set the environment variable [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    + re.escape([96mstr[39;49;00m(MLFLOW_HTTP_REQUEST_TIMEOUT))[90m[39;49;00m
                ),[90m[39;49;00m
            ):[90m[39;49;00m
>               http_request(MlflowHostCreds([33m"[39;49;00m[33mhttp://my-host[39;49;00m[33m"[39;49;00m), [33m"[39;49;00m[33m/my/endpoint[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m)[90m[39;49;00m


[1m[31mtests/utils/test_rest_utils.py[0m:537: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x71d1e7b5e690>
endpoint = '/my/endpoint', method = 'GET', max_retries = 7, backoff_factor = 2
backoff_jitter = 1.0, extra_headers = None
retry_codes = frozenset({408, 429, 500, 502, 503, 504}), timeout = 120
raise_on_status = True, respect_retry_after_header = True
retry_timeout_seconds = None, kwargs = {}, url = 'http://my-host/my/endpoint'
headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mhttp_request[39;49;00m([90m[39;49;00m
        host_creds,[90m[39;49;00m
        endpoint,[90m[39;49;00m
        method,[90m[39;49;00m
        max_retries=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_factor=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_jitter=[94mNone[39;49;00m,[90m[39;49;00m
        extra_headers=[94mNone[39;49;00m,[90m[39;49;00m
        retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,[90m[39;49;00m
        timeout=[94mNone[39;49;00m,[90m[39;49;00m
        raise_on_status=[94mTrue[39;49;00m,[90m[39;49;00m
        respect_retry_after_header=[94mNone[39;49;00m,[90m[39;49;00m
        retry_timeout_seconds=[94mNone[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Make an authenticated HTTP request to an MLflow service endpoint."""[39;49;00m[90m[39;49;00m
        max_retries = MLFLOW_HTTP_REQUEST_MAX_RETRIES.get() [94mif[39;49;00m max_retries [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m max_retries[90m[39;49;00m
        backoff_factor = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR.get() [94mif[39;49;00m backoff_factor [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_factor[90m[39;49;00m
        )[90m[39;49;00m
        backoff_jitter = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_JITTER.get() [94mif[39;49;00m backoff_jitter [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_jitter[90m[39;49;00m
        )[90m[39;49;00m
        timeout = MLFLOW_HTTP_REQUEST_TIMEOUT.get() [94mif[39;49;00m timeout [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m timeout[90m[39;49;00m
        respect_retry_after_header = ([90m[39;49;00m
            MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER.get()[90m[39;49;00m
            [94mif[39;49;00m respect_retry_after_header [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
            [94melse[39;49;00m respect_retry_after_header[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m max_retries < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe max_retries value must be either zero or a positive integer.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m max_retries > _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured max_retries exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe backoff_factor value must be zero or a positive number.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor > _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured backoff_factor exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_secret [95mand[39;49;00m [95mnot[39;49;00m MLFLOW_ENABLE_DB_SDK.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException([90m[39;49;00m
                [33m"[39;49;00m[33mOAuth authentication requires the Databricks SDK. Set MLFLOW_ENABLE_DB_SDK=true.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                error_code=CUSTOMER_UNAUTHORIZED,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        url = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.host.rstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m/[39;49;00m[33m{[39;49;00mendpoint.lstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        headers = _resolve_request_headers(extra_headers)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.use_databricks_sdk:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mdatabricks[39;49;00m[04m[96m.[39;49;00m[04m[96msdk[39;49;00m[04m[96m.[39;49;00m[04m[96merrors[39;49;00m[90m [39;49;00m[94mimport[39;49;00m DatabricksError[90m[39;49;00m
    [90m[39;49;00m
            retry_timeout = ([90m[39;49;00m
                MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get()[90m[39;49;00m
                [94mif[39;49;00m retry_timeout_seconds [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m retry_timeout_seconds[90m[39;49;00m
            )[90m[39;49;00m
            workspace_client = get_workspace_client([90m[39;49;00m
                host_creds.use_secret_scope_token,[90m[39;49;00m
                host_creds.host,[90m[39;49;00m
                host_creds.token,[90m[39;49;00m
                host_creds.databricks_auth_profile,[90m[39;49;00m
                retry_timeout_seconds=retry_timeout_seconds,[90m[39;49;00m
                timeout=timeout,[90m[39;49;00m
            )[90m[39;49;00m
            sdk_kwargs = {[90m[39;49;00m
                [33m"[39;49;00m[33mmethod[39;49;00m[33m"[39;49;00m: method,[90m[39;49;00m
                [33m"[39;49;00m[33mpath[39;49;00m[33m"[39;49;00m: endpoint,[90m[39;49;00m
                [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
                [33m"[39;49;00m[33mraw[39;49;00m[33m"[39;49;00m: [94mTrue[39;49;00m,[90m[39;49;00m
            }[90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mquery[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mbody[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
            [94mdef[39;49;00m[90m [39;49;00m[92mcall_sdk[39;49;00m():[90m[39;49;00m
                [94mreturn[39;49;00m workspace_client.api_client.do(**sdk_kwargs)[90m[39;49;00m
    [90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mwith[39;49;00m warnings.catch_warnings():[90m[39;49;00m
                    warnings.filterwarnings([90m[39;49;00m
                        [33m"[39;49;00m[33mignore[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        message=[33mf[39;49;00m[33m"[39;49;00m[33m.*[39;49;00m[33m{[39;49;00m_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING[33m}[39;49;00m[33m.*[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m
                    result = _retry_databricks_sdk_call_with_exponential_backoff([90m[39;49;00m
                        call_func=call_sdk,[90m[39;49;00m
                        retry_codes=retry_codes,[90m[39;49;00m
                        retry_timeout_seconds=retry_timeout,[90m[39;49;00m
                        backoff_factor=backoff_factor,[90m[39;49;00m
                        backoff_jitter=backoff_jitter,[90m[39;49;00m
                        max_retries=max_retries,[90m[39;49;00m
                    )[90m[39;49;00m
                contents = result.get([33m"[39;49;00m[33mcontents[39;49;00m[33m"[39;49;00m, result) [94mif[39;49;00m [96misinstance[39;49;00m(result, [96mdict[39;49;00m) [94melse[39;49;00m result[90m[39;49;00m
                [94mreturn[39;49;00m [96mgetattr[39;49;00m(contents, [33m"[39;49;00m[33m_response[39;49;00m[33m"[39;49;00m, contents)[90m[39;49;00m
            [94mexcept[39;49;00m DatabricksError [94mas[39;49;00m e:[90m[39;49;00m
                [94mreturn[39;49;00m _databricks_error_to_response(e, url)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.token:[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mBearer [39;49;00m[33m{[39;49;00mhost_creds.token[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m host_creds.username [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m host_creds.password [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            credentials = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.username[33m}[39;49;00m[33m:[39;49;00m[33m{[39;49;00mhost_creds.password[33m}[39;49;00m[33m"[39;49;00m.encode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33m"[39;49;00m[33mBasic [39;49;00m[33m"[39;49;00m + base64.b64encode(credentials).decode([33m"[39;49;00m[33mascii[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        request_kwargs = {[90m[39;49;00m
            [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
            [33m"[39;49;00m[33mverify[39;49;00m[33m"[39;49;00m: ([90m[39;49;00m
                host_creds.server_cert_path[90m[39;49;00m
                [94mif[39;49;00m host_creds.server_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m [95mnot[39;49;00m host_creds.ignore_tls_verification[90m[39;49;00m
            ),[90m[39;49;00m
            [33m"[39;49;00m[33mtimeout[39;49;00m[33m"[39;49;00m: timeout,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        }[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mcert[39;49;00m[33m"[39;49;00m] = host_creds.client_cert_path[90m[39;49;00m
        [94mif[39;49;00m host_creds.aws_sigv4:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mrequests_auth_aws_sigv4[39;49;00m[90m [39;49;00m[94mimport[39;49;00m AWSSigV4[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = AWSSigV4([33m"[39;49;00m[33mexecute-api[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94melif[39;49;00m host_creds.auth:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_auth[39;49;00m[04m[96m.[39;49;00m[04m[96mregistry[39;49;00m[90m [39;49;00m[94mimport[39;49;00m fetch_auth[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = fetch_auth(host_creds.auth)[90m[39;49;00m
    [90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            [94mreturn[39;49;00m _get_http_response_with_retries([90m[39;49;00m
                method,[90m[39;49;00m
                url,[90m[39;49;00m
                max_retries,[90m[39;49;00m
                backoff_factor,[90m[39;49;00m
                backoff_jitter,[90m[39;49;00m
                retry_codes,[90m[39;49;00m
                raise_on_status,[90m[39;49;00m
                respect_retry_after_header=respect_retry_after_header,[90m[39;49;00m
                **request_kwargs,[90m[39;49;00m
            )[90m[39;49;00m
        [94mexcept[39;49;00m requests.exceptions.InvalidURL [94mas[39;49;00m e:[90m[39;49;00m
            [94mraise[39;49;00m InvalidUrlException([33mf[39;49;00m[33m"[39;49;00m[33mInvalid url: [39;49;00m[33m{[39;49;00murl[33m}[39;49;00m[33m"[39;49;00m) [94mfrom[39;49;00m[90m [39;49;00m[04m[96me[39;49;00m[90m[39;49;00m
        [94mexcept[39;49;00m requests.exceptions.Timeout [94mas[39;49;00m e:[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mAPI request to [39;49;00m[33m{[39;49;00murl[33m}[39;49;00m[33m timed out. To increase the timeout, set the environment [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mvariable [39;49;00m[33m{[39;49;00mMLFLOW_HTTP_REQUEST_TIMEOUT[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            ) [94mfrom[39;49;00m[90m [39;49;00m[04m[96me[39;49;00m[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: API request to http://my-host/my/endpoint timed out. To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT.[0m

backoff_factor = 2
backoff_jitter = 1.0
endpoint   = '/my/endpoint'
extra_headers = None
headers    = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}
host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x71d1e7b5e690>
kwargs     = {}
max_retries = 7
method     = 'GET'
raise_on_status = True
request_kwargs = {'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'timeout': 120, 'verify': True}
respect_retry_after_header = True
retry_codes = frozenset({408, 429, 500, 502, 503, 504})
retry_timeout_seconds = None
timeout    = 120
url        = 'http://my-host/my/endpoint'

[1m[31mmlflow/utils/rest_utils.py[0m:249: MlflowException

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_explains_how_to_increase_timeout_in_error_message[39;49;00m():[90m[39;49;00m
        [94mwith[39;49;00m mock.patch([33m"[39;49;00m[33mrequests.Session.request[39;49;00m[33m"[39;49;00m, side_effect=requests.exceptions.Timeout):[90m[39;49;00m
>           [94mwith[39;49;00m pytest.raises([90m[39;49;00m
                MlflowException,[90m[39;49;00m
                match=([90m[39;49;00m
                    [33mr[39;49;00m[33m"[39;49;00m[33mTo increase the timeout, set the environment variable [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    + re.escape([96mstr[39;49;00m(MLFLOW_HTTP_REQUEST_TIMEOUT))[90m[39;49;00m
                ),[90m[39;49;00m
            ):[90m[39;49;00m
[1m[31mE           AssertionError: Regex pattern did not match.[0m
[1m[31mE             Expected regex: 'To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT\\ \\(default:\\ 120\\)'[0m
[1m[31mE             Actual message: 'API request to http://my-host/my/endpoint timed out. To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT.'[0m


[1m[31mtests/utils/test_rest_utils.py[0m:530: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:39 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________ test_deployment_client_timeout_propagation __________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e5907210>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_deployment_client_timeout_propagation[39;49;00m(monkeypatch):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Test deployment client propagates timeout to workspace client."""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mwith[39;49;00m ([90m[39;49;00m
            mock.patch([33m"[39;49;00m[33mmlflow.utils.rest_utils.get_workspace_client[39;49;00m[33m"[39;49;00m) [94mas[39;49;00m mock_get_workspace_client,[90m[39;49;00m
            mock.patch([90m[39;49;00m
                [33m"[39;49;00m[33mmlflow.utils.databricks_utils.get_databricks_host_creds[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            ) [94mas[39;49;00m mock_get_databricks_host_creds,[90m[39;49;00m
            mock.patch([90m[39;49;00m
                [33m"[39;49;00m[33mmlflow.deployments.databricks.get_databricks_host_creds[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            ) [94mas[39;49;00m mock_deployment_host_creds,[90m[39;49;00m
        ):[90m[39;49;00m
            [90m# Mock the host creds to use Databricks SDK[39;49;00m[90m[39;49;00m
            mock_host_creds = MlflowHostCreds([33m"[39;49;00m[33mhttp://my-host[39;49;00m[33m"[39;49;00m, use_databricks_sdk=[94mTrue[39;49;00m)[90m[39;49;00m
            mock_get_databricks_host_creds.return_value = mock_host_creds[90m[39;49;00m
            mock_deployment_host_creds.return_value = mock_host_creds[90m[39;49;00m
    [90m[39;49;00m
            [90m# Mock workspace client and its response[39;49;00m[90m[39;49;00m
            mock_workspace_client_instance = mock.MagicMock()[90m[39;49;00m
            mock_workspace_client_instance.api_client.do.return_value = {[33m"[39;49;00m[33mcontents[39;49;00m[33m"[39;49;00m: mock.MagicMock()}[90m[39;49;00m
            mock_get_workspace_client.return_value = mock_workspace_client_instance[90m[39;49;00m
    [90m[39;49;00m
            [90m# Set the environment variable to a custom value using monkeypatch[39;49;00m[90m[39;49;00m
            monkeypatch.setenv([33m"[39;49;00m[33mMLFLOW_DEPLOYMENT_PREDICT_TIMEOUT[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33m300[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
            [90m# Create deployment client and call predict[39;49;00m[90m[39;49;00m
            client = DatabricksDeploymentClient([33m"[39;49;00m[33mdatabricks[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>           client.predict(endpoint=[33m"[39;49;00m[33mtest-endpoint[39;49;00m[33m"[39;49;00m, inputs={[33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m})[90m[39;49;00m

client     = <mlflow.deployments.databricks.DatabricksDeploymentClient object at 0x71d1e5adc090>
mock_deployment_host_creds = <MagicMock name='get_databricks_host_creds' id='125146313597200'>
mock_get_databricks_host_creds = <MagicMock name='get_databricks_host_creds' id='125146313591824'>
mock_get_workspace_client = <MagicMock name='get_workspace_client' id='125146313553296'>
mock_host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x71d1e5911fd0>
mock_workspace_client_instance = <MagicMock name='get_workspace_client()' id='125146313602576'>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x71d1e5907210>

[1m[31mtests/utils/test_rest_utils.py[0m:900: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/databricks/__init__.py[0m:262: in predict
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._call_endpoint([90m[39;49;00m
        deployment_name = None
        endpoint   = 'test-endpoint'
        inputs     = {'test': 'data'}
        self       = <mlflow.deployments.databricks.DatabricksDeploymentClient object at 0x71d1e5adc090>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.databricks.DatabricksDeploymentClient object at 0x71d1e5adc090>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_call_endpoint[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        method: [96mstr[39;49;00m,[90m[39;49;00m
        prefix: [96mstr[39;49;00m = [33m"[39;49;00m[33m/api/2.0[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        route: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        json_body: [96mdict[39;49;00m[[96mstr[39;49;00m, Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        timeout: [96mint[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        retry_timeout_seconds: [96mint[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Args:[39;49;00m
    [33m        method: HTTP method (GET, POST, etc.).[39;49;00m
    [33m        prefix: API prefix path.[39;49;00m
    [33m        route: Endpoint route.[39;49;00m
    [33m        json_body: Request payload.[39;49;00m
    [33m        timeout: Maximum time (in seconds) for a single HTTP request.[39;49;00m
    [33m        retry_timeout_seconds: Maximum time (in seconds) for all retry attempts combined.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        validate_deployment_timeout_config(timeout, retry_timeout_seconds)[90m[39;49;00m
    [90m[39;49;00m
        call_kwargs = {}[90m[39;49;00m
        [94mif[39;49;00m method.lower() == [33m"[39;49;00m[33mget[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            call_kwargs[[33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m] = json_body[90m[39;49;00m
        [94melse[39;49;00m:[90m[39;49;00m
            call_kwargs[[33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m] = json_body[90m[39;49;00m
    [90m[39;49;00m
>       response = http_request([90m[39;49;00m
                   ^^^^^^^^^^^^[90m[39;49;00m
            host_creds=get_databricks_host_creds([96mself[39;49;00m.target_uri),[90m[39;49;00m
            endpoint=posixpath.join(prefix, [33m"[39;49;00m[33mserving-endpoints[39;49;00m[33m"[39;49;00m, route [95mor[39;49;00m [33m"[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            method=method,[90m[39;49;00m
            timeout=MLFLOW_HTTP_REQUEST_TIMEOUT.get() [94mif[39;49;00m timeout [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m timeout,[90m[39;49;00m
            retry_timeout_seconds=retry_timeout_seconds,[90m[39;49;00m
            raise_on_status=[94mFalse[39;49;00m,[90m[39;49;00m
            retry_codes=MLFLOW_DEPLOYMENT_CLIENT_REQUEST_RETRY_CODES,[90m[39;49;00m
            extra_headers={[33m"[39;49;00m[33mX-Databricks-Endpoints-API-Client[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mDatabricks Deployment Client[39;49;00m[33m"[39;49;00m},[90m[39;49;00m
            **call_kwargs,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       NameError: name 'http_request' is not defined[0m

call_kwargs = {'json': {'test': 'data'}}
json_body  = {'test': 'data'}
method     = 'POST'
prefix     = '/'
retry_timeout_seconds = 600
route      = 'test-endpoint/invocations'
self       = <mlflow.deployments.databricks.DatabricksDeploymentClient object at 0x71d1e5adc090>
timeout    = 300

[1m[31mmlflow/deployments/databricks/__init__.py[0m:154: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:55 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________ test_run_context_provider_registry_with_installed_plugin ___________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_run_context_provider_registry_with_installed_plugin[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        reload(mlflow.tracking.request_header.registry)[90m[39;49;00m
    [90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'mlflow_test_plugin'[0m


[1m[31mtests/tracking/request_header/test_registry.py[0m:101: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:55 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________ test_resolve_request_headers _________________________[0m

mock_request_header_providers = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_resolve_request_headers[39;49;00m(mock_request_header_providers):[90m[39;49;00m
        request_headers_arg = {[33m"[39;49;00m[33mtwo[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33marg-override[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33marg[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33marg-val[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
>       [94massert[39;49;00m resolve_request_headers(request_headers_arg) == {[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
            [33m"[39;49;00m[33mone[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mone-val override[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mtwo[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33marg-override[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mthree[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mthree-val[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mnew[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mnew-val[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33marg[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33marg-val[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
[1m[31mE       TypeError: resolve_request_headers() takes 0 positional arguments but 1 was given[0m

mock_request_header_providers = None
request_headers_arg = {'arg': 'arg-val', 'two': 'arg-override'}

[1m[31mtests/tracking/request_header/test_registry.py[0m:150: TypeError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:55 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________ test_resolve_request_headers_no_arg ______________________[0m

mock_request_header_providers = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_resolve_request_headers_no_arg[39;49;00m(mock_request_header_providers):[90m[39;49;00m
>       [94massert[39;49;00m resolve_request_headers() == {[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
            [33m"[39;49;00m[33mone[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mone-val override[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mtwo[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mtwo-val[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mthree[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mthree-val[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mnew[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mnew-val[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m

mock_request_header_providers = None

[1m[31mtests/tracking/request_header/test_registry.py[0m:160: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/tracking/request_header/registry.py[0m:53: in resolve_request_headers
    [0m[94mfor[39;49;00m name, value [95min[39;49;00m provider.request_headers().items():[90m[39;49;00m
                       ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        append_headers = {'User-Agent', 'X-MLflow-Client-Version'}
        headers    = {'one': 'one-val', 'three': 'three-val', 'two': 'two-val'}
        name       = 'three'
        provider   = <Mock id='125146314267152'>
        value      = 'three-val'
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1124: in __call__
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._mock_call(*args, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ()
        kwargs     = {}
        self       = <Mock name='mock.request_headers' id='125146314269008'>
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1128: in _mock_call
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._execute_mock_call(*args, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ()
        kwargs     = {}
        self       = <Mock name='mock.request_headers' id='125146314269008'>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <Mock name='mock.request_headers' id='125146314269008'>, args = ()
kwargs = {}
effect = Exception('This should be caught by logic in resolve_request_headers()')

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_execute_mock_call[39;49;00m([96mself[39;49;00m, /, *args, **kwargs):[90m[39;49;00m
        [90m# separate from _increment_mock_call so that awaited functions are[39;49;00m[90m[39;49;00m
        [90m# executed separately from their call, also AsyncMock overrides this method[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        effect = [96mself[39;49;00m.side_effect[90m[39;49;00m
        [94mif[39;49;00m effect [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m _is_exception(effect):[90m[39;49;00m
>               [94mraise[39;49;00m effect[90m[39;49;00m
[1m[31mE               Exception: This should be caught by logic in resolve_request_headers()[0m

args       = ()
effect     = Exception('This should be caught by logic in resolve_request_headers()')
kwargs     = {}
self       = <Mock name='mock.request_headers' id='125146314269008'>

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1183: Exception
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:30:55 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
13.35s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_max_retries_exceeded
0.43s call     tests/utils/test_rest_utils.py::test_suppress_databricks_retry_after_secs_warnings
0.36s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_on_transient_errors
0.20s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_timeout_exceeded
0.06s call     tests/utils/test_request_utils.py::test_request_utils_does_not_import_mlflow
0.03s call     tests/gateway/test_gateway_config_parsing.py::test_api_key_parsing_file
0.01s call     tests/deployments/test_deployments.py::test_plugin_doesnot_have_required_attrib
0.01s call     tests/utils/test_rest_utils.py::test_http_request_with_auth
0.01s teardown tests/tracking/request_header/test_registry.py::test_resolve_request_headers_no_arg

(1 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                             | Duration | Tests | Min    | Max     | Avg    |
| ---- | -------------------------------- | -------- | ----- | ------ | ------- | ------ |
| 1    | `tests/utils/test_rest_utils.py` | 14.53s   | 49    | 0.000s | 13.352s | 0.296s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/deployments/test_interface.py::test_get_deploy_client_from_set_deployments_target' 'tests/deployments/test_interface.py::test_get_deploy_client_from_env' 'tests/deployments/test_deployments.py::test_create_success' 'tests/deployments/test_deployments.py::test_delete_success' 'tests/deployments/test_deployments.py::test_update_success' 'tests/deployments/test_deployments.py::test_list_success' 'tests/deployments/test_deployments.py::test_get_success' 'tests/deployments/test_deployments.py::test_endpoint_create_success' 'tests/deployments/test_deployments.py::test_endpoint_delete_success' 'tests/deployments/test_deployments.py::test_endpoint_update_success' 'tests/deployments/test_deployments.py::test_endpoint_list_success' 'tests/deployments/test_deployments.py::test_endpoint_get_success' 'tests/deployments/test_deployments.py::test_wrong_target_name' 'tests/deployments/test_deployments.py::test_plugin_doesnot_have_required_attrib' 'tests/deployments/test_deployments.py::test_plugin_raising_error' 'tests/deployments/test_deployments.py::test_target_uri_parsing' 'tests/deployments/test_deployments.py::test_explain_with_no_target_implementation' 'tests/deployments/test_deployments.py::test_explain_with_target_implementation' 'tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing' 'tests/utils/test_rest_utils.py::test_http_request_with_aws_sigv4' 'tests/utils/test_rest_utils.py::test_http_request_request_headers' 'tests/utils/test_rest_utils.py::test_http_request_request_headers_default' 'tests/utils/test_rest_utils.py::test_http_request_request_headers_default_and_extra_header' 'tests/utils/test_rest_utils.py::test_http_request_explains_how_to_increase_timeout_in_error_message' 'tests/utils/test_rest_utils.py::test_deployment_client_timeout_propagation' 'tests/tracking/request_header/test_registry.py::test_run_context_provider_registry_with_installed_plugin' 'tests/tracking/request_header/test_registry.py::test_resolve_request_headers' 'tests/tracking/request_header/test_registry.py::test_resolve_request_headers_no_arg'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_interface.py::[1mtest_get_deploy_client_from_set_deployments_target[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_interface.py::[1mtest_get_deploy_client_from_env[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_create_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_delete_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_update_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_list_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_get_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_create_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_delete_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_update_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_list_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_get_success[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_wrong_target_name[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_plugin_doesnot_have_required_attrib[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_plugin_raising_error[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_target_uri_parsing[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_explain_with_no_target_implementation[0m - ModuleNotFoundError: No module named 'mlflow_test_plugin'
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_explain_with_target_implementation[0m - NameError: name 'parse_target_uri' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/gateway/test_gateway_config_parsing.py::[1mtest_route_configuration_parsing[0m - ModuleNotFoundError: No module named 'limits'
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_with_aws_sigv4[0m - ModuleNotFoundError: No module named 'requests_auth_aws_sigv4'
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_request_headers[0m - ModuleNotFoundError: No module named 'mlflow_test_plugin'
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_request_headers_default[0m - ModuleNotFoundError: No module named 'mlflow_test_plugin'
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_request_headers_default_and_extra_header[0m - ModuleNotFoundError: No module named 'mlflow_test_plugin'
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_explains_how_to_increase_timeout_in_error_message[0m - AssertionError: Regex pattern did not match.
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_deployment_client_timeout_propagation[0m - NameError: name 'http_request' is not defined
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/tracking/request_header/test_registry.py::[1mtest_run_context_provider_registry_with_installed_plugin[0m - ModuleNotFoundError: No module named 'mlflow_test_plugin'
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/tracking/request_header/test_registry.py::[1mtest_resolve_request_headers[0m - TypeError: resolve_request_headers() takes 0 positional arguments but 1 was...
[31mFAILED | MEM 11.6/46.9 GB | DISK 832.5/915.7 GB[0m tests/tracking/request_header/test_registry.py::[1mtest_resolve_request_headers_no_arg[0m - Exception: This should be caught by logic in resolve_request_headers()
[31m================== [31m[1m28 failed[0m, [32m108 passed[0m, [33m2 skipped[0m[31m in 15.21s[0m[31m ==================[0m
```

## 原始行 127 · command_execution

命令：
```
/bin/bash -lc 'grep -n "limit" tests/gateway/test_gateway_config_parsing.py | head -50
grep -n "http_request" mlflow/deployments/databricks/__init__.py mlflow/deployments/mlflow/__init__.py mlflow/deployments/openai/__init__.py'
```

退出码：`0`

输出：
```
mlflow/deployments/databricks/__init__.py:154:        response = http_request(
mlflow/deployments/databricks/__init__.py:186:        response = http_request(
mlflow/deployments/mlflow/__init__.py:129:        response = http_request(
```

## 原始行 129 · command_execution

命令：
```
/bin/bash -lc "sed -n '105,180p' tests/tracking/request_header/test_registry.py
nl -ba mlflow/deployments/plugin_manager.py | sed -n '1,55p'
sed -n '1,32p' mlflow/deployments/databricks/__init__.py
sed -n '1,38p' mlflow/deployments/mlflow/__init__.py"
```

退出码：`0`

输出：
```
    # The test plugin's request header provider always returns False from in_context to avoid
    # polluting request headers in developers' environments. The following mock overrides this to
    # perform the integration test.
    with mock.patch.object(PluginRequestHeaderProvider, "in_context", return_value=True):
        assert resolve_request_headers()["test"] == "header"


@pytest.fixture
def mock_request_header_providers():
    base_provider = mock.Mock()
    base_provider.in_context.return_value = True
    base_provider.request_headers.return_value = {
        "one": "one-val",
        "two": "two-val",
        "three": "three-val",
    }

    skipped_provider = mock.Mock()
    skipped_provider.in_context.return_value = False

    exception_provider = mock.Mock()
    exception_provider.in_context.return_value = True
    exception_provider.request_headers.return_value = {
        "random-header": "This val will never make it to header resolution"
    }
    exception_provider.request_headers.side_effect = Exception(
        "This should be caught by logic in resolve_request_headers()"
    )

    override_provider = mock.Mock()
    override_provider.in_context.return_value = True
    override_provider.request_headers.return_value = {"one": "override", "new": "new-val"}

    providers = [base_provider, skipped_provider, exception_provider, override_provider]

    with mock.patch(
        "mlflow.tracking.request_header.registry._request_header_provider_registry", providers
    ):
        yield

    skipped_provider.tags.assert_not_called()


def test_resolve_request_headers(mock_request_header_providers):
    request_headers_arg = {"two": "arg-override", "arg": "arg-val"}
    assert resolve_request_headers(request_headers_arg) == {
        "one": "one-val override",
        "two": "arg-override",
        "three": "three-val",
        "new": "new-val",
        "arg": "arg-val",
    }


def test_resolve_request_headers_no_arg(mock_request_header_providers):
    assert resolve_request_headers() == {
        "one": "one-val override",
        "two": "two-val",
        "three": "three-val",
        "new": "new-val",
    }
     1	import abc
     2	import importlib.metadata
     3	import inspect
     4	
     5	import importlib_metadata
     6	
     7	from mlflow.deployments.base import BaseDeploymentClient
     8	
     9	from mlflow.exceptions import MlflowException
    10	from mlflow.protos.databricks_pb2 import INTERNAL_ERROR, RESOURCE_DOES_NOT_EXIST
    11	from mlflow.utils.annotations import developer_stable
    12	from mlflow.utils.plugins import get_entry_points
    13	
    14	# TODO: refactor to have a common base class for all the plugin implementation in MLflow
    15	#   mlflow/tracking/context/registry.py
    16	#   mlflow/tracking/registry
    17	#   mlflow/store/artifact/artifact_repository_registry.py
    18	
    19	
    20	@developer_stable
    21	class PluginManager(abc.ABC):
    22	    """
    23	    Abstract class defining a entrypoint based plugin registration.
    24	
    25	    This class allows the registration of a function or class to provide an implementation
    26	    for a given key/name. Implementations declared though the entrypoints can be automatically
    27	    registered through the `register_entrypoints` method.
    28	    """
    29	
    30	    def __init__(self, group_name):
    31	        self._registry = {}
    32	        self.group_name = group_name
    33	        self._has_registered = None
    34	
    35	    @abc.abstractmethod
    36	    def __getitem__(self, item):
    37	        # Letting the child class create this function so that the child
    38	        # can raise custom exceptions if it needs to
    39	        pass
    40	
    41	    @property
    42	    def registry(self):
    43	        """
    44	        Registry stores the registered plugin as a key value pair where key is the
    45	        name of the plugin and value is the plugin object
    46	        """
    47	        return self._registry
    48	
    49	    @property
    50	    def has_registered(self):
    51	        """
    52	        Returns bool representing whether the "register_entrypoints" has run or not. This
    53	        doesn't return True if `register` method is called outside of `register_entrypoints`
    54	        to register plugins
    55	        """
import json
import posixpath
import warnings
from typing import Any, Iterator

from mlflow.deployments import BaseDeploymentClient
from mlflow.deployments.constants import (
    MLFLOW_DEPLOYMENT_CLIENT_REQUEST_RETRY_CODES,
)
from mlflow.environment_variables import (
    MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT,
    MLFLOW_DEPLOYMENT_PREDICT_TOTAL_TIMEOUT,
    MLFLOW_HTTP_REQUEST_TIMEOUT,
)
from mlflow.exceptions import MlflowException
from mlflow.utils import AttrDict
from mlflow.utils.annotations import deprecated
from mlflow.utils.databricks_utils import get_databricks_host_creds
from mlflow.utils.rest_utils import augmented_raise_for_status, validate_deployment_timeout_config






class DatabricksEndpoint(AttrDict):
    """
    A dictionary-like object representing a Databricks serving endpoint.

    .. code-block:: python

        endpoint = DatabricksEndpoint(
from typing import TYPE_CHECKING, Any

import requests

from mlflow import MlflowException
from mlflow.deployments import BaseDeploymentClient
from mlflow.deployments.constants import (
    MLFLOW_DEPLOYMENT_CLIENT_REQUEST_RETRY_CODES,
)
from mlflow.deployments.server.constants import (
    MLFLOW_DEPLOYMENTS_CRUD_ENDPOINT_BASE,
    MLFLOW_DEPLOYMENTS_ENDPOINTS_BASE,
    MLFLOW_DEPLOYMENTS_QUERY_SUFFIX,
)
from mlflow.deployments.utils import resolve_endpoint_url
from mlflow.environment_variables import (
    MLFLOW_DEPLOYMENT_CLIENT_HTTP_REQUEST_TIMEOUT,
    MLFLOW_DEPLOYMENT_PREDICT_TIMEOUT,
)
from mlflow.protos.databricks_pb2 import BAD_REQUEST
from mlflow.store.entities.paged_list import PagedList
from mlflow.utils.credentials import get_default_host_creds
from mlflow.utils.rest_utils import augmented_raise_for_status
from mlflow.utils.uri import join_paths

if TYPE_CHECKING:
    from mlflow.deployments.server.config import Endpoint


class MlflowDeploymentClient(BaseDeploymentClient):
    """
    Client for interacting with the MLflow AI Gateway.

    Example:

    First, start the MLflow AI Gateway:

    .. code-block:: bash
```

## 原始行 132 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing -vv'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0 -- /opt/miniconda3/envs/testbed/bin/python3.11
cachedir: .pytest_cache
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
[1mcollecting ... [0mcollected 1 item

tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing [31mFAILED | MEM 13.3/46.9 GB | DISK 833.0/915.7 GB[0m[31m [100%][0m

=================================== FAILURES ===================================
[31m[1m_______________________ test_route_configuration_parsing _______________________[0m

basic_config_dict = {'endpoints': [{'endpoint_type': 'llm/v1/completions', 'model': {'config': {'openai_api_base': 'https://api.openai.com...': {'config': {'anthropic_api_key': 'api_key'}, 'name': 'claude-v1', 'provider': 'anthropic'}, 'name': 'claude-chat'}]}
tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_route_configuration_parsi0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x76b976d877d0>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_route_configuration_parsing[39;49;00m(basic_config_dict, tmp_path, monkeypatch):[90m[39;49;00m
        conf_path = tmp_path.joinpath([33m"[39;49;00m[33mconfig.yaml[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        conf_path.write_text(yaml.safe_dump(basic_config_dict))[90m[39;49;00m
    [90m[39;49;00m
        loaded_config = _load_gateway_config(conf_path)[90m[39;49;00m
    [90m[39;49;00m
        save_path = tmp_path.joinpath([33m"[39;49;00m[33mconfig2.yaml[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        _save_route_config(loaded_config, save_path)[90m[39;49;00m
>       loaded_from_save = _load_gateway_config(save_path)[90m[39;49;00m
                           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

basic_config_dict = {'endpoints': [{'endpoint_type': 'llm/v1/completions',
                'model': {'config': {'openai_api_base': 'https://api.openai.com/v1',
                                     'openai_api_key': 'mykey',
                                     'openai_api_type': 'openai',
                                     'openai_api_version': '2023-05-10',
                                     'openai_organization': 'my_company'},
                          'name': 'gpt-4',
                          'provider': 'openai'},
                'name': 'completions-gpt4'},
               {'endpoint_type': 'llm/v1/chat',
                'model': {'config': {'openai_api_key': 'sk-openai'},
                          'name': 'gpt-4',
                          'provider': 'openai'},
                'name': 'chat-gpt4'},
               {'endpoint_type': 'llm/v1/chat',
                'model': {'config': {'anthropic_api_key': 'api_key'},
                          'name': 'claude-v1',
                          'provider': 'anthropic'},
                'name': 'claude-chat'}]}
conf_path  = PosixPath('/tmp/pytest-of-root/pytest-1/test_route_configuration_parsi0/config.yaml')
loaded_config = GatewayConfig(endpoints=[EndpointConfig(name='completions-gpt4', endpoint_type=<EndpointType.LLM_V1_COMPLETIONS: 'llm/v1/completions'>, model=Model(name='gpt-4', provider=<Provider.OPENAI: 'openai'>, config=OpenAIConfig(openai_api_key='mykey', openai_api_type=<OpenAIAPIType.OPENAI: 'openai'>, openai_api_base='https://api.openai.com/v1', openai_api_version='2023-05-10', openai_deployment_name=None, openai_organization='my_company')), limit=None), EndpointConfig(name='chat-gpt4', endpoint_type=<EndpointType.LLM_V1_CHAT: 'llm/v1/chat'>, model=Model(name='gpt-4', provider=<Provider.OPENAI: 'openai'>, config=OpenAIConfig(openai_api_key='sk-openai', openai_api_type=<OpenAIAPIType.OPENAI: 'openai'>, openai_api_base='https://api.openai.com/v1', openai_api_version=None, openai_deployment_name=None, openai_organization=None)), limit=None), EndpointConfig(name='claude-chat', endpoint_type=<EndpointType.LLM_V1_CHAT: 'llm/v1/chat'>, model=Model(name='claude-v1', provider=<Provider.ANTHROPIC: 'anthropic'>, config=AnthropicConfig(anthropic_api_key='api_key', anthropic_version='2023-06-01')), limit=None)], routes=None)
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x76b976d877d0>
save_path  = PosixPath('/tmp/pytest-of-root/pytest-1/test_route_configuration_parsi0/config2.yaml')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_route_configuration_parsi0')

[1m[31mtests/gateway/test_gateway_config_parsing.py[0m:138: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/gateway/config.py[0m:520: in _load_gateway_config
    [0m[94mreturn[39;49;00m GatewayConfig(**configuration)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        configuration = {'endpoints': [{'endpoint_type': 'llm/v1/completions',
                'limit': None,
                'model': {'config': {'openai_api_base': 'https://api.openai.com/v1',
                                     'openai_api_key': 'mykey',
                                     'openai_api_type': 'openai',
                                     'openai_api_version': '2023-05-10',
                                     'openai_deployment_name': None,
                                     'openai_organization': 'my_company'},
                          'name': 'gpt-4',
                          'provider': 'openai'},
                'name': 'completions-gpt4'},
               {'endpoint_type': 'llm/v1/chat',
                'limit': None,
                'model': {'config': {'openai_api_base': 'https://api.openai.com/v1',
                                     'openai_api_key': 'sk-openai',
                                     'openai_api_type': 'openai',
                                     'openai_api_version': None,
                                     'openai_deployment_name': None,
                                     'openai_organization': None},
                          'name': 'gpt-4',
                          'provider': 'openai'},
                'name': 'chat-gpt4'},
               {'endpoint_type': 'llm/v1/chat',
                'limit': None,
                'model': {'config': {'anthropic_api_key': 'api_key',
                                     'anthropic_version': '2023-06-01'},
                          'name': 'claude-v1',
                          'provider': 'anthropic'},
                'name': 'claude-chat'}],
 'routes': None}
        path       = PosixPath('/tmp/pytest-of-root/pytest-1/test_route_configuration_parsi0/config2.yaml')
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'mlflow.gateway.config.EndpointConfig'>, value = None

    [0m[37m@field_validator[39;49;00m([33m"[39;49;00m[33mlimit[39;49;00m[33m"[39;49;00m, mode=[33m"[39;49;00m[33mbefore[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mvalidate_limit[39;49;00m([96mcls[39;49;00m, value):[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mlimits[39;49;00m[90m [39;49;00m[94mimport[39;49;00m parse[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'limits'[0m

cls        = <class 'mlflow.gateway.config.EndpointConfig'>
value      = None

[1m[31mmlflow/gateway/config.py[0m:404: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:07 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
0.08s call     tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing
0.01s setup    tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing
0.00s teardown tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing
========================= command to run failed tests ==========================
pytest 'tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 13.3/46.9 GB | DISK 833.0/915.7 GB[0m tests/gateway/test_gateway_config_parsing.py::[1mtest_route_configuration_parsing[0m - ModuleNotFoundError: No module named 'limits'
[31m============================== [31m[1m1 failed[0m[31m in 0.37s[0m[31m ===============================[0m
```

## 原始行 133 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/utils/test_rest_utils.py::test_http_request_explains_how_to_increase_timeout_in_error_message -vv'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0 -- /opt/miniconda3/envs/testbed/bin/python3.11
cachedir: .pytest_cache
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
[1mcollecting ... [0mcollected 1 item

tests/utils/test_rest_utils.py::test_http_request_explains_how_to_increase_timeout_in_error_message [31mFAILED | MEM 13.4/46.9 GB | DISK 833.1/915.7 GB[0m[31m [100%][0m

=================================== FAILURES ===================================
[31m[1m_____ test_http_request_explains_how_to_increase_timeout_in_error_message ______[0m

host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x7cf9f35554d0>
endpoint = '/my/endpoint', method = 'GET', max_retries = 7, backoff_factor = 2
backoff_jitter = 1.0, extra_headers = None
retry_codes = frozenset({408, 429, 500, 502, 503, 504}), timeout = 120
raise_on_status = True, respect_retry_after_header = True
retry_timeout_seconds = None, kwargs = {}, url = 'http://my-host/my/endpoint'
headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mhttp_request[39;49;00m([90m[39;49;00m
        host_creds,[90m[39;49;00m
        endpoint,[90m[39;49;00m
        method,[90m[39;49;00m
        max_retries=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_factor=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_jitter=[94mNone[39;49;00m,[90m[39;49;00m
        extra_headers=[94mNone[39;49;00m,[90m[39;49;00m
        retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,[90m[39;49;00m
        timeout=[94mNone[39;49;00m,[90m[39;49;00m
        raise_on_status=[94mTrue[39;49;00m,[90m[39;49;00m
        respect_retry_after_header=[94mNone[39;49;00m,[90m[39;49;00m
        retry_timeout_seconds=[94mNone[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Make an authenticated HTTP request to an MLflow service endpoint."""[39;49;00m[90m[39;49;00m
        max_retries = MLFLOW_HTTP_REQUEST_MAX_RETRIES.get() [94mif[39;49;00m max_retries [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m max_retries[90m[39;49;00m
        backoff_factor = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR.get() [94mif[39;49;00m backoff_factor [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_factor[90m[39;49;00m
        )[90m[39;49;00m
        backoff_jitter = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_JITTER.get() [94mif[39;49;00m backoff_jitter [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_jitter[90m[39;49;00m
        )[90m[39;49;00m
        timeout = MLFLOW_HTTP_REQUEST_TIMEOUT.get() [94mif[39;49;00m timeout [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m timeout[90m[39;49;00m
        respect_retry_after_header = ([90m[39;49;00m
            MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER.get()[90m[39;49;00m
            [94mif[39;49;00m respect_retry_after_header [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
            [94melse[39;49;00m respect_retry_after_header[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m max_retries < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe max_retries value must be either zero or a positive integer.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m max_retries > _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured max_retries exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe backoff_factor value must be zero or a positive number.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor > _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured backoff_factor exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_secret [95mand[39;49;00m [95mnot[39;49;00m MLFLOW_ENABLE_DB_SDK.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException([90m[39;49;00m
                [33m"[39;49;00m[33mOAuth authentication requires the Databricks SDK. Set MLFLOW_ENABLE_DB_SDK=true.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                error_code=CUSTOMER_UNAUTHORIZED,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        url = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.host.rstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m/[39;49;00m[33m{[39;49;00mendpoint.lstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        headers = _resolve_request_headers(extra_headers)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.use_databricks_sdk:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mdatabricks[39;49;00m[04m[96m.[39;49;00m[04m[96msdk[39;49;00m[04m[96m.[39;49;00m[04m[96merrors[39;49;00m[90m [39;49;00m[94mimport[39;49;00m DatabricksError[90m[39;49;00m
    [90m[39;49;00m
            retry_timeout = ([90m[39;49;00m
                MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get()[90m[39;49;00m
                [94mif[39;49;00m retry_timeout_seconds [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m retry_timeout_seconds[90m[39;49;00m
            )[90m[39;49;00m
            workspace_client = get_workspace_client([90m[39;49;00m
                host_creds.use_secret_scope_token,[90m[39;49;00m
                host_creds.host,[90m[39;49;00m
                host_creds.token,[90m[39;49;00m
                host_creds.databricks_auth_profile,[90m[39;49;00m
                retry_timeout_seconds=retry_timeout_seconds,[90m[39;49;00m
                timeout=timeout,[90m[39;49;00m
            )[90m[39;49;00m
            sdk_kwargs = {[90m[39;49;00m
                [33m"[39;49;00m[33mmethod[39;49;00m[33m"[39;49;00m: method,[90m[39;49;00m
                [33m"[39;49;00m[33mpath[39;49;00m[33m"[39;49;00m: endpoint,[90m[39;49;00m
                [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
                [33m"[39;49;00m[33mraw[39;49;00m[33m"[39;49;00m: [94mTrue[39;49;00m,[90m[39;49;00m
            }[90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mquery[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mbody[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
            [94mdef[39;49;00m[90m [39;49;00m[92mcall_sdk[39;49;00m():[90m[39;49;00m
                [94mreturn[39;49;00m workspace_client.api_client.do(**sdk_kwargs)[90m[39;49;00m
    [90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mwith[39;49;00m warnings.catch_warnings():[90m[39;49;00m
                    warnings.filterwarnings([90m[39;49;00m
                        [33m"[39;49;00m[33mignore[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        message=[33mf[39;49;00m[33m"[39;49;00m[33m.*[39;49;00m[33m{[39;49;00m_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING[33m}[39;49;00m[33m.*[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m
                    result = _retry_databricks_sdk_call_with_exponential_backoff([90m[39;49;00m
                        call_func=call_sdk,[90m[39;49;00m
                        retry_codes=retry_codes,[90m[39;49;00m
                        retry_timeout_seconds=retry_timeout,[90m[39;49;00m
                        backoff_factor=backoff_factor,[90m[39;49;00m
                        backoff_jitter=backoff_jitter,[90m[39;49;00m
                        max_retries=max_retries,[90m[39;49;00m
                    )[90m[39;49;00m
                contents = result.get([33m"[39;49;00m[33mcontents[39;49;00m[33m"[39;49;00m, result) [94mif[39;49;00m [96misinstance[39;49;00m(result, [96mdict[39;49;00m) [94melse[39;49;00m result[90m[39;49;00m
                [94mreturn[39;49;00m [96mgetattr[39;49;00m(contents, [33m"[39;49;00m[33m_response[39;49;00m[33m"[39;49;00m, contents)[90m[39;49;00m
            [94mexcept[39;49;00m DatabricksError [94mas[39;49;00m e:[90m[39;49;00m
                [94mreturn[39;49;00m _databricks_error_to_response(e, url)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.token:[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mBearer [39;49;00m[33m{[39;49;00mhost_creds.token[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m host_creds.username [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m host_creds.password [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            credentials = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.username[33m}[39;49;00m[33m:[39;49;00m[33m{[39;49;00mhost_creds.password[33m}[39;49;00m[33m"[39;49;00m.encode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33m"[39;49;00m[33mBasic [39;49;00m[33m"[39;49;00m + base64.b64encode(credentials).decode([33m"[39;49;00m[33mascii[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        request_kwargs = {[90m[39;49;00m
            [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
            [33m"[39;49;00m[33mverify[39;49;00m[33m"[39;49;00m: ([90m[39;49;00m
                host_creds.server_cert_path[90m[39;49;00m
                [94mif[39;49;00m host_creds.server_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m [95mnot[39;49;00m host_creds.ignore_tls_verification[90m[39;49;00m
            ),[90m[39;49;00m
            [33m"[39;49;00m[33mtimeout[39;49;00m[33m"[39;49;00m: timeout,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        }[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mcert[39;49;00m[33m"[39;49;00m] = host_creds.client_cert_path[90m[39;49;00m
        [94mif[39;49;00m host_creds.aws_sigv4:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mrequests_auth_aws_sigv4[39;49;00m[90m [39;49;00m[94mimport[39;49;00m AWSSigV4[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = AWSSigV4([33m"[39;49;00m[33mexecute-api[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94melif[39;49;00m host_creds.auth:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_auth[39;49;00m[04m[96m.[39;49;00m[04m[96mregistry[39;49;00m[90m [39;49;00m[94mimport[39;49;00m fetch_auth[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = fetch_auth(host_creds.auth)[90m[39;49;00m
    [90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           [94mreturn[39;49;00m _get_http_response_with_retries([90m[39;49;00m
                method,[90m[39;49;00m
                url,[90m[39;49;00m
                max_retries,[90m[39;49;00m
                backoff_factor,[90m[39;49;00m
                backoff_jitter,[90m[39;49;00m
                retry_codes,[90m[39;49;00m
                raise_on_status,[90m[39;49;00m
                respect_retry_after_header=respect_retry_after_header,[90m[39;49;00m
                **request_kwargs,[90m[39;49;00m
            )[90m[39;49;00m

backoff_factor = 2
backoff_jitter = 1.0
endpoint   = '/my/endpoint'
extra_headers = None
headers    = {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
 'X-MLflow-Client-Version': '3.6.1.dev0'}
host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x7cf9f35554d0>
kwargs     = {}
max_retries = 7
method     = 'GET'
raise_on_status = True
request_kwargs = {'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
             'X-MLflow-Client-Version': '3.6.1.dev0'},
 'timeout': 120,
 'verify': True}
respect_retry_after_header = True
retry_codes = frozenset({504, 429, 500, 502, 503, 408})
retry_timeout_seconds = None
timeout    = 120
url        = 'http://my-host/my/endpoint'

[1m[31mmlflow/utils/rest_utils.py[0m:235: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/utils/request_utils.py[0m:155: in _get_http_response_with_retries
    [0m[94mreturn[39;49;00m session.request(method, url, timeout=timeout, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        allow_redirects = 'true'
        backoff_factor = 2
        backoff_jitter = 1.0
        kwargs     = {'allow_redirects': True,
 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
             'X-MLflow-Client-Version': '3.6.1.dev0'},
 'verify': True}
        max_retries = 7
        method     = 'GET'
        raise_on_status = True
        respect_retry_after_header = True
        retry_codes = (408, 429, 500, 502, 503, 504)
        session    = <requests.sessions.Session object at 0x7cf9f354e950>
        timeout    = 120
        url        = 'http://my-host/my/endpoint'
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1124: in __call__
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._mock_call(*args, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ('GET', 'http://my-host/my/endpoint')
        kwargs     = {'allow_redirects': True,
 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
             'X-MLflow-Client-Version': '3.6.1.dev0'},
 'timeout': 120,
 'verify': True}
        self       = <MagicMock name='request' id='137412971164048'>
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1128: in _mock_call
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._execute_mock_call(*args, **kwargs)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ('GET', 'http://my-host/my/endpoint')
        kwargs     = {'allow_redirects': True,
 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
             'X-MLflow-Client-Version': '3.6.1.dev0'},
 'timeout': 120,
 'verify': True}
        self       = <MagicMock name='request' id='137412971164048'>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <MagicMock name='request' id='137412971164048'>
args = ('GET', 'http://my-host/my/endpoint')
kwargs = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, 'timeout': 120, 'verify': True}
effect = <class 'requests.exceptions.Timeout'>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_execute_mock_call[39;49;00m([96mself[39;49;00m, /, *args, **kwargs):[90m[39;49;00m
        [90m# separate from _increment_mock_call so that awaited functions are[39;49;00m[90m[39;49;00m
        [90m# executed separately from their call, also AsyncMock overrides this method[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        effect = [96mself[39;49;00m.side_effect[90m[39;49;00m
        [94mif[39;49;00m effect [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            [94mif[39;49;00m _is_exception(effect):[90m[39;49;00m
>               [94mraise[39;49;00m effect[90m[39;49;00m
[1m[31mE               requests.exceptions.Timeout[0m

args       = ('GET', 'http://my-host/my/endpoint')
effect     = <class 'requests.exceptions.Timeout'>
kwargs     = {'allow_redirects': True,
 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
             'X-MLflow-Client-Version': '3.6.1.dev0'},
 'timeout': 120,
 'verify': True}
self       = <MagicMock name='request' id='137412971164048'>

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1183: Timeout

[33mThe above exception was the direct cause of the following exception:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_explains_how_to_increase_timeout_in_error_message[39;49;00m():[90m[39;49;00m
        [94mwith[39;49;00m mock.patch([33m"[39;49;00m[33mrequests.Session.request[39;49;00m[33m"[39;49;00m, side_effect=requests.exceptions.Timeout):[90m[39;49;00m
            [94mwith[39;49;00m pytest.raises([90m[39;49;00m
                MlflowException,[90m[39;49;00m
                match=([90m[39;49;00m
                    [33mr[39;49;00m[33m"[39;49;00m[33mTo increase the timeout, set the environment variable [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    + re.escape([96mstr[39;49;00m(MLFLOW_HTTP_REQUEST_TIMEOUT))[90m[39;49;00m
                ),[90m[39;49;00m
            ):[90m[39;49;00m
>               http_request(MlflowHostCreds([33m"[39;49;00m[33mhttp://my-host[39;49;00m[33m"[39;49;00m), [33m"[39;49;00m[33m/my/endpoint[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m)[90m[39;49;00m


[1m[31mtests/utils/test_rest_utils.py[0m:537: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x7cf9f35554d0>
endpoint = '/my/endpoint', method = 'GET', max_retries = 7, backoff_factor = 2
backoff_jitter = 1.0, extra_headers = None
retry_codes = frozenset({408, 429, 500, 502, 503, 504}), timeout = 120
raise_on_status = True, respect_retry_after_header = True
retry_timeout_seconds = None, kwargs = {}, url = 'http://my-host/my/endpoint'
headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mhttp_request[39;49;00m([90m[39;49;00m
        host_creds,[90m[39;49;00m
        endpoint,[90m[39;49;00m
        method,[90m[39;49;00m
        max_retries=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_factor=[94mNone[39;49;00m,[90m[39;49;00m
        backoff_jitter=[94mNone[39;49;00m,[90m[39;49;00m
        extra_headers=[94mNone[39;49;00m,[90m[39;49;00m
        retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,[90m[39;49;00m
        timeout=[94mNone[39;49;00m,[90m[39;49;00m
        raise_on_status=[94mTrue[39;49;00m,[90m[39;49;00m
        respect_retry_after_header=[94mNone[39;49;00m,[90m[39;49;00m
        retry_timeout_seconds=[94mNone[39;49;00m,[90m[39;49;00m
        **kwargs,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Make an authenticated HTTP request to an MLflow service endpoint."""[39;49;00m[90m[39;49;00m
        max_retries = MLFLOW_HTTP_REQUEST_MAX_RETRIES.get() [94mif[39;49;00m max_retries [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m max_retries[90m[39;49;00m
        backoff_factor = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR.get() [94mif[39;49;00m backoff_factor [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_factor[90m[39;49;00m
        )[90m[39;49;00m
        backoff_jitter = ([90m[39;49;00m
            MLFLOW_HTTP_REQUEST_BACKOFF_JITTER.get() [94mif[39;49;00m backoff_jitter [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m backoff_jitter[90m[39;49;00m
        )[90m[39;49;00m
        timeout = MLFLOW_HTTP_REQUEST_TIMEOUT.get() [94mif[39;49;00m timeout [95mis[39;49;00m [94mNone[39;49;00m [94melse[39;49;00m timeout[90m[39;49;00m
        respect_retry_after_header = ([90m[39;49;00m
            MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER.get()[90m[39;49;00m
            [94mif[39;49;00m respect_retry_after_header [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
            [94melse[39;49;00m respect_retry_after_header[90m[39;49;00m
        )[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m max_retries < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe max_retries value must be either zero or a positive integer.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m max_retries > _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured max_retries exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor < [94m0[39;49;00m:[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe backoff_factor value must be zero or a positive number.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m backoff_factor > _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe configured backoff_factor exceeds the allowed maximum of [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00m_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get()[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_secret [95mand[39;49;00m [95mnot[39;49;00m MLFLOW_ENABLE_DB_SDK.get():[90m[39;49;00m
            [94mraise[39;49;00m MlflowException([90m[39;49;00m
                [33m"[39;49;00m[33mOAuth authentication requires the Databricks SDK. Set MLFLOW_ENABLE_DB_SDK=true.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                error_code=CUSTOMER_UNAUTHORIZED,[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        url = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.host.rstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m/[39;49;00m[33m{[39;49;00mendpoint.lstrip([33m'[39;49;00m[33m/[39;49;00m[33m'[39;49;00m)[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        headers = _resolve_request_headers(extra_headers)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.use_databricks_sdk:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mdatabricks[39;49;00m[04m[96m.[39;49;00m[04m[96msdk[39;49;00m[04m[96m.[39;49;00m[04m[96merrors[39;49;00m[90m [39;49;00m[94mimport[39;49;00m DatabricksError[90m[39;49;00m
    [90m[39;49;00m
            retry_timeout = ([90m[39;49;00m
                MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get()[90m[39;49;00m
                [94mif[39;49;00m retry_timeout_seconds [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m retry_timeout_seconds[90m[39;49;00m
            )[90m[39;49;00m
            workspace_client = get_workspace_client([90m[39;49;00m
                host_creds.use_secret_scope_token,[90m[39;49;00m
                host_creds.host,[90m[39;49;00m
                host_creds.token,[90m[39;49;00m
                host_creds.databricks_auth_profile,[90m[39;49;00m
                retry_timeout_seconds=retry_timeout_seconds,[90m[39;49;00m
                timeout=timeout,[90m[39;49;00m
            )[90m[39;49;00m
            sdk_kwargs = {[90m[39;49;00m
                [33m"[39;49;00m[33mmethod[39;49;00m[33m"[39;49;00m: method,[90m[39;49;00m
                [33m"[39;49;00m[33mpath[39;49;00m[33m"[39;49;00m: endpoint,[90m[39;49;00m
                [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
                [33m"[39;49;00m[33mraw[39;49;00m[33m"[39;49;00m: [94mTrue[39;49;00m,[90m[39;49;00m
            }[90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mquery[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mparams[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mbody[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mjson[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mfiles[39;49;00m[33m"[39;49;00m][90m[39;49;00m
            [94mif[39;49;00m [33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m [95min[39;49;00m kwargs:[90m[39;49;00m
                sdk_kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m] = kwargs[[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
            [94mdef[39;49;00m[90m [39;49;00m[92mcall_sdk[39;49;00m():[90m[39;49;00m
                [94mreturn[39;49;00m workspace_client.api_client.do(**sdk_kwargs)[90m[39;49;00m
    [90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mwith[39;49;00m warnings.catch_warnings():[90m[39;49;00m
                    warnings.filterwarnings([90m[39;49;00m
                        [33m"[39;49;00m[33mignore[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        message=[33mf[39;49;00m[33m"[39;49;00m[33m.*[39;49;00m[33m{[39;49;00m_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING[33m}[39;49;00m[33m.*[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m
                    result = _retry_databricks_sdk_call_with_exponential_backoff([90m[39;49;00m
                        call_func=call_sdk,[90m[39;49;00m
                        retry_codes=retry_codes,[90m[39;49;00m
                        retry_timeout_seconds=retry_timeout,[90m[39;49;00m
                        backoff_factor=backoff_factor,[90m[39;49;00m
                        backoff_jitter=backoff_jitter,[90m[39;49;00m
                        max_retries=max_retries,[90m[39;49;00m
                    )[90m[39;49;00m
                contents = result.get([33m"[39;49;00m[33mcontents[39;49;00m[33m"[39;49;00m, result) [94mif[39;49;00m [96misinstance[39;49;00m(result, [96mdict[39;49;00m) [94melse[39;49;00m result[90m[39;49;00m
                [94mreturn[39;49;00m [96mgetattr[39;49;00m(contents, [33m"[39;49;00m[33m_response[39;49;00m[33m"[39;49;00m, contents)[90m[39;49;00m
            [94mexcept[39;49;00m DatabricksError [94mas[39;49;00m e:[90m[39;49;00m
                [94mreturn[39;49;00m _databricks_error_to_response(e, url)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m host_creds.token:[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33mf[39;49;00m[33m"[39;49;00m[33mBearer [39;49;00m[33m{[39;49;00mhost_creds.token[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        [94melif[39;49;00m host_creds.username [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m [95mand[39;49;00m host_creds.password [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            credentials = [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mhost_creds.username[33m}[39;49;00m[33m:[39;49;00m[33m{[39;49;00mhost_creds.password[33m}[39;49;00m[33m"[39;49;00m.encode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
            headers[[33m"[39;49;00m[33mAuthorization[39;49;00m[33m"[39;49;00m] = [33m"[39;49;00m[33mBasic [39;49;00m[33m"[39;49;00m + base64.b64encode(credentials).decode([33m"[39;49;00m[33mascii[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        request_kwargs = {[90m[39;49;00m
            [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: headers,[90m[39;49;00m
            [33m"[39;49;00m[33mverify[39;49;00m[33m"[39;49;00m: ([90m[39;49;00m
                host_creds.server_cert_path[90m[39;49;00m
                [94mif[39;49;00m host_creds.server_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
                [94melse[39;49;00m [95mnot[39;49;00m host_creds.ignore_tls_verification[90m[39;49;00m
            ),[90m[39;49;00m
            [33m"[39;49;00m[33mtimeout[39;49;00m[33m"[39;49;00m: timeout,[90m[39;49;00m
            **kwargs,[90m[39;49;00m
        }[90m[39;49;00m
        [94mif[39;49;00m host_creds.client_cert_path [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mcert[39;49;00m[33m"[39;49;00m] = host_creds.client_cert_path[90m[39;49;00m
        [94mif[39;49;00m host_creds.aws_sigv4:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mrequests_auth_aws_sigv4[39;49;00m[90m [39;49;00m[94mimport[39;49;00m AWSSigV4[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = AWSSigV4([33m"[39;49;00m[33mexecute-api[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94melif[39;49;00m host_creds.auth:[90m[39;49;00m
            [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_auth[39;49;00m[04m[96m.[39;49;00m[04m[96mregistry[39;49;00m[90m [39;49;00m[94mimport[39;49;00m fetch_auth[90m[39;49;00m
    [90m[39;49;00m
            request_kwargs[[33m"[39;49;00m[33mauth[39;49;00m[33m"[39;49;00m] = fetch_auth(host_creds.auth)[90m[39;49;00m
    [90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            [94mreturn[39;49;00m _get_http_response_with_retries([90m[39;49;00m
                method,[90m[39;49;00m
                url,[90m[39;49;00m
                max_retries,[90m[39;49;00m
                backoff_factor,[90m[39;49;00m
                backoff_jitter,[90m[39;49;00m
                retry_codes,[90m[39;49;00m
                raise_on_status,[90m[39;49;00m
                respect_retry_after_header=respect_retry_after_header,[90m[39;49;00m
                **request_kwargs,[90m[39;49;00m
            )[90m[39;49;00m
        [94mexcept[39;49;00m requests.exceptions.InvalidURL [94mas[39;49;00m e:[90m[39;49;00m
            [94mraise[39;49;00m InvalidUrlException([33mf[39;49;00m[33m"[39;49;00m[33mInvalid url: [39;49;00m[33m{[39;49;00murl[33m}[39;49;00m[33m"[39;49;00m) [94mfrom[39;49;00m[90m [39;49;00m[04m[96me[39;49;00m[90m[39;49;00m
        [94mexcept[39;49;00m requests.exceptions.Timeout [94mas[39;49;00m e:[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mAPI request to [39;49;00m[33m{[39;49;00murl[33m}[39;49;00m[33m timed out. To increase the timeout, set the environment [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33mvariable [39;49;00m[33m{[39;49;00mMLFLOW_HTTP_REQUEST_TIMEOUT[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            ) [94mfrom[39;49;00m[90m [39;49;00m[04m[96me[39;49;00m[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: API request to http://my-host/my/endpoint timed out. To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT.[0m

backoff_factor = 2
backoff_jitter = 1.0
endpoint   = '/my/endpoint'
extra_headers = None
headers    = {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
 'X-MLflow-Client-Version': '3.6.1.dev0'}
host_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x7cf9f35554d0>
kwargs     = {}
max_retries = 7
method     = 'GET'
raise_on_status = True
request_kwargs = {'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0',
             'X-MLflow-Client-Version': '3.6.1.dev0'},
 'timeout': 120,
 'verify': True}
respect_retry_after_header = True
retry_codes = frozenset({504, 429, 500, 502, 503, 408})
retry_timeout_seconds = None
timeout    = 120
url        = 'http://my-host/my/endpoint'

[1m[31mmlflow/utils/rest_utils.py[0m:249: MlflowException

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_explains_how_to_increase_timeout_in_error_message[39;49;00m():[90m[39;49;00m
        [94mwith[39;49;00m mock.patch([33m"[39;49;00m[33mrequests.Session.request[39;49;00m[33m"[39;49;00m, side_effect=requests.exceptions.Timeout):[90m[39;49;00m
>           [94mwith[39;49;00m pytest.raises([90m[39;49;00m
                MlflowException,[90m[39;49;00m
                match=([90m[39;49;00m
                    [33mr[39;49;00m[33m"[39;49;00m[33mTo increase the timeout, set the environment variable [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    + re.escape([96mstr[39;49;00m(MLFLOW_HTTP_REQUEST_TIMEOUT))[90m[39;49;00m
                ),[90m[39;49;00m
            ):[90m[39;49;00m
[1m[31mE           AssertionError: Regex pattern did not match.[0m
[1m[31mE             Expected regex: 'To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT\\ \\(default:\\ 120\\)'[0m
[1m[31mE             Actual message: 'API request to http://my-host/my/endpoint timed out. To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT.'[0m


[1m[31mtests/utils/test_rest_utils.py[0m:530: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:07 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
0.02s call     tests/utils/test_rest_utils.py::test_http_request_explains_how_to_increase_timeout_in_error_message
0.00s setup    tests/utils/test_rest_utils.py::test_http_request_explains_how_to_increase_timeout_in_error_message
0.00s teardown tests/utils/test_rest_utils.py::test_http_request_explains_how_to_increase_timeout_in_error_message
========================= command to run failed tests ==========================
pytest 'tests/utils/test_rest_utils.py::test_http_request_explains_how_to_increase_timeout_in_error_message'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 13.4/46.9 GB | DISK 833.1/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_explains_how_to_increase_timeout_in_error_message[0m - AssertionError: Regex pattern did not match.
  Expected regex: 'To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT\\ \\(default:\\ 120\\)'
  Actual message: 'API request to http://my-host/my/endpoint timed out. To increase the timeout, set the environment variable MLFLOW_HTTP_REQUEST_TIMEOUT.'
[31m============================== [31m[1m1 failed[0m[31m in 0.54s[0m[31m ===============================[0m
```

## 原始行 136 · file_change

```
{
  "id": "item_81",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/deployments/databricks/__init__.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/deployments/mlflow/__init__.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/deployments/plugin_manager.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/gateway/config.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracking/request_header/registry.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/utils/rest_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 139 · file_change

```
{
  "id": "item_83",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/utils/rest_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 142 · command_execution

命令：
```
/bin/bash -lc "PYTHONPATH=/testbed/tests/resources/mlflow-test-plugin pytest -q tests/deployments/test_interface.py tests/deployments/test_deployments.py tests/gateway/test_gateway_config_parsing.py tests/utils/test_rest_utils.py tests/tracking/request_header/test_registry.py --ignore-glob='*nothing*' -k 'not aws_sigv4'"
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 101 items / 1 deselected / 100 selected

tests/deployments/test_interface.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                 [  4%][0m
tests/deployments/test_deployments.py [31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31m                   [ 20%][0m
tests/gateway/test_gateway_config_parsing.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m     [ 43%][0m
tests/utils/test_rest_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[32m.[0m[31m [ 84%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                                                  [ 91%][0m
tests/tracking/request_header/test_registry.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[31m                 [100%][0m

=================================== FAILURES ===================================
[31m[1m_____________________________ test_create_success ______________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_create_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:17: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________________ test_delete_success ______________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_delete_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:28: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________________ test_update_success ______________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_update_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:33: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________________________ test_list_success _______________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_list_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________________ test_get_success _______________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:45: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________ test_endpoint_create_success _________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_create_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:51: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________ test_endpoint_delete_success _________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_delete_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:58: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________ test_endpoint_update_success _________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_update_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:63: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_endpoint_list_success __________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_list_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:68: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_endpoint_get_success ___________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_endpoint_get_success[39;49;00m():[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:74: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_plugin_raising_error ___________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x798d6dfe5190>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_plugin_raising_error[39;49;00m(monkeypatch):[90m[39;49;00m
>       client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x798d6dfe5190>

[1m[31mtests/deployments/test_deployments.py[0m:98: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________________ test_target_uri_parsing ____________________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_target_uri_parsing[39;49;00m():[90m[39;49;00m
>       deployments.get_deploy_client(f_target)[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:106: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________ test_explain_with_no_target_implementation __________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_explain_with_no_target_implementation[39;49;00m():[90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[90m [39;49;00m[94mimport[39;49;00m fake_deployment_plugin[90m[39;49;00m
    [90m[39;49;00m
        mock_error = MlflowException([33m"[39;49;00m[33mMOCK ERROR[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>       target_client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

fake_deployment_plugin = <module 'mlflow_test_plugin.fake_deployment_plugin' from '/testbed/tests/resources/mlflow-test-plugin/mlflow_test_plugin/fake_deployment_plugin.py'>
mock_error = MlflowException('MOCK ERROR')

[1m[31mtests/deployments/test_deployments.py[0m:115: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_explain_with_target_implementation ____________________[0m

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
>           plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           KeyError: 'faketarget'[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:95: KeyError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_explain_with_target_implementation[39;49;00m():[90m[39;49;00m
>       target_client = deployments.get_deploy_client(f_target)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/deployments/test_deployments.py[0m:124: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/deployments/interface.py[0m:32: in get_deploy_client
    [0mplugin = plugin_store[target_uri][90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        target_uri = 'faketarget'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
item = 'faketarget'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__getitem__[39;49;00m([96mself[39;49;00m, item):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Override __getitem__ so that we can directly look up plugins via dict-like syntax"""[39;49;00m[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            target_name = parse_target_uri(item)[90m[39;49;00m
            plugin_like = [96mself[39;49;00m.registry[target_name][90m[39;49;00m
        [94mexcept[39;49;00m [96mKeyError[39;49;00m:[90m[39;49;00m
            msg = ([90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mNo plugin found for managing model deployments to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m. [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m'[39;49;00m[33mIn order to deploy models to [39;49;00m[33m"[39;49;00m[33m{[39;49;00mitem[33m}[39;49;00m[33m"[39;49;00m[33m, find and install an appropriate [39;49;00m[33m'[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mplugin from [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mhttps://mlflow.org/docs/latest/plugins.html#community-plugins using [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33myour package manager (pip, conda etc).[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException(msg, error_code=RESOURCE_DOES_NOT_EXIST)[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and install an appropriate plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).[0m

item       = 'faketarget'
msg        = 'No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketarget", find and i...plugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'
self       = <mlflow.deployments.plugin_manager.DeploymentPlugins object at 0x798d6f409790>
target_name = 'faketarget'

[1m[31mmlflow/deployments/plugin_manager.py[0m:104: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________________ test_http_request_request_headers _______________________[0m

self = <MagicMock name='request' id='133648347503696'>
args = ('GET', 'http://my-host/my/endpoint')
kwargs = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0', 'test': 'header'}, 'timeout': 120, 'verify': '/some/path'}
expected = call('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0', 'test': 'header'}, timeout=120)
actual = call('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)
_error_message = <function NonCallableMock.assert_called_with.<locals>._error_message at 0x798d6ded9440>
cause = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92massert_called_with[39;49;00m([96mself[39;49;00m, /, *args, **kwargs):[90m[39;49;00m
    [90m    [39;49;00m[33m"""assert that the last call was made with the specified arguments.[39;49;00m
    [33m[39;49;00m
    [33m    Raises an AssertionError if the args and keyword args passed in are[39;49;00m
    [33m    different to the last call to the mock."""[39;49;00m[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.call_args [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            expected = [96mself[39;49;00m._format_mock_call_signature(args, kwargs)[90m[39;49;00m
            actual = [33m'[39;49;00m[33mnot called.[39;49;00m[33m'[39;49;00m[90m[39;49;00m
            error_message = ([33m'[39;49;00m[33mexpected call not found.[39;49;00m[33m\n[39;49;00m[33mExpected: [39;49;00m[33m%s[39;49;00m[33m\n[39;49;00m[33m  Actual: [39;49;00m[33m%s[39;49;00m[33m'[39;49;00m[90m[39;49;00m
                    % (expected, actual))[90m[39;49;00m
            [94mraise[39;49;00m [96mAssertionError[39;49;00m(error_message)[90m[39;49;00m
    [90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92m_error_message[39;49;00m():[90m[39;49;00m
            msg = [96mself[39;49;00m._format_mock_failure_message(args, kwargs)[90m[39;49;00m
            [94mreturn[39;49;00m msg[90m[39;49;00m
        expected = [96mself[39;49;00m._call_matcher(_Call((args, kwargs), two=[94mTrue[39;49;00m))[90m[39;49;00m
        actual = [96mself[39;49;00m._call_matcher([96mself[39;49;00m.call_args)[90m[39;49;00m
        [94mif[39;49;00m actual != expected:[90m[39;49;00m
            cause = expected [94mif[39;49;00m [96misinstance[39;49;00m(expected, [96mException[39;49;00m) [94melse[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
>           [94mraise[39;49;00m [96mAssertionError[39;49;00m(_error_message()) [94mfrom[39;49;00m[90m [39;49;00m[04m[96mcause[39;49;00m[90m[39;49;00m
[1m[31mE           AssertionError: expected call not found.[0m
[1m[31mE           Expected: request('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0', 'test': 'header'}, timeout=120)[0m
[1m[31mE             Actual: request('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)[0m

_error_message = <function NonCallableMock.assert_called_with.<locals>._error_message at 0x798d6ded9440>
actual     = call('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)
args       = ('GET', 'http://my-host/my/endpoint')
cause      = None
expected   = call('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0', 'test': 'header'}, timeout=120)
kwargs     = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0', 'test': 'header'}, 'timeout': 120, 'verify': '/some/path'}
self       = <MagicMock name='request' id='133648347503696'>

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:939: AssertionError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_request_headers[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
    [90m[39;49;00m
        [90m# The test plugin's request header provider always returns False from in_context to avoid[39;49;00m[90m[39;49;00m
        [90m# polluting request headers in developers' environments. The following mock overrides this to[39;49;00m[90m[39;49;00m
        [90m# perform the integration test.[39;49;00m[90m[39;49;00m
        response = mock.MagicMock()[90m[39;49;00m
        response.status_code = [94m200[39;49;00m[90m[39;49;00m
        [94mwith[39;49;00m ([90m[39;49;00m
            mock.patch([33m"[39;49;00m[33mrequests.Session.request[39;49;00m[33m"[39;49;00m, return_value=response) [94mas[39;49;00m mock_request,[90m[39;49;00m
            mock.patch.object(PluginRequestHeaderProvider, [33m"[39;49;00m[33min_context[39;49;00m[33m"[39;49;00m, return_value=[94mTrue[39;49;00m),[90m[39;49;00m
        ):[90m[39;49;00m
            host_only = MlflowHostCreds([33m"[39;49;00m[33mhttp://my-host[39;49;00m[33m"[39;49;00m, server_cert_path=[33m"[39;49;00m[33m/some/path[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
            http_request(host_only, [33m"[39;49;00m[33m/my/endpoint[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>           mock_request.assert_called_with([90m[39;49;00m
                [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mhttp://my-host/my/endpoint[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                allow_redirects=[94mTrue[39;49;00m,[90m[39;49;00m
                verify=[33m"[39;49;00m[33m/some/path[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                headers={**DefaultRequestHeaderProvider().request_headers(), [33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mheader[39;49;00m[33m"[39;49;00m},[90m[39;49;00m
                timeout=[94m120[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
[1m[31mE           AssertionError: expected call not found.[0m
[1m[31mE           Expected: request('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0', 'test': 'header'}, timeout=120)[0m
[1m[31mE             Actual: request('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)[0m
[1m[31mE           [0m
[1m[31mE           pytest introspection follows:[0m
[1m[31mE           [0m
[1m[31mE           Kwargs:[0m
[1m[31mE           assert {'allow_redir... '/some/path'} == {'allow_redir... '/some/path'}[0m
[1m[31mE             [0m
[1m[31mE             Omitting 3 identical items, use -vv to show[0m
[1m[31mE             Differing items:[0m
[1m[31mE             [0m{[33m'[39;49;00m[33mheaders[39;49;00m[33m'[39;49;00m: {[33m'[39;49;00m[33mUser-Agent[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33mmlflow-python-client/3.6.1.dev0[39;49;00m[33m'[39;49;00m, [33m'[39;49;00m[33mX-MLflow-Client-Version[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33m3.6.1.dev0[39;49;00m[33m'[39;49;00m}}[90m[39;49;00m != [0m{[33m'[39;49;00m[33mheaders[39;49;00m[33m'[39;49;00m: {[33m'[39;49;00m[33mUser-Agent[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33mm...[0m
[1m[31mE             [0m
[1m[31mE             ...Full output truncated (2 lines hidden), use '-vv' to show[0m

PluginRequestHeaderProvider = <class 'mlflow_test_plugin.request_header_provider.PluginRequestHeaderProvider'>
host_only  = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x798d6e104750>
mock_request = <MagicMock name='request' id='133648347503696'>
response   = <MagicMock id='133648344215248'>

[1m[31mtests/utils/test_rest_utils.py[0m:303: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________ test_http_request_request_headers_default ___________________[0m

self = <MagicMock name='request' id='133648341483792'>
args = ('GET', 'http://my-host/my/endpoint')
kwargs = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version'}, 'timeout': 120, 'verify': '/some/path'}
expected = call('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version'}, timeout=120)
actual = call('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)
_error_message = <function NonCallableMock.assert_called_with.<locals>._error_message at 0x798d6dedbc40>
cause = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92massert_called_with[39;49;00m([96mself[39;49;00m, /, *args, **kwargs):[90m[39;49;00m
    [90m    [39;49;00m[33m"""assert that the last call was made with the specified arguments.[39;49;00m
    [33m[39;49;00m
    [33m    Raises an AssertionError if the args and keyword args passed in are[39;49;00m
    [33m    different to the last call to the mock."""[39;49;00m[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.call_args [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            expected = [96mself[39;49;00m._format_mock_call_signature(args, kwargs)[90m[39;49;00m
            actual = [33m'[39;49;00m[33mnot called.[39;49;00m[33m'[39;49;00m[90m[39;49;00m
            error_message = ([33m'[39;49;00m[33mexpected call not found.[39;49;00m[33m\n[39;49;00m[33mExpected: [39;49;00m[33m%s[39;49;00m[33m\n[39;49;00m[33m  Actual: [39;49;00m[33m%s[39;49;00m[33m'[39;49;00m[90m[39;49;00m
                    % (expected, actual))[90m[39;49;00m
            [94mraise[39;49;00m [96mAssertionError[39;49;00m(error_message)[90m[39;49;00m
    [90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92m_error_message[39;49;00m():[90m[39;49;00m
            msg = [96mself[39;49;00m._format_mock_failure_message(args, kwargs)[90m[39;49;00m
            [94mreturn[39;49;00m msg[90m[39;49;00m
        expected = [96mself[39;49;00m._call_matcher(_Call((args, kwargs), two=[94mTrue[39;49;00m))[90m[39;49;00m
        actual = [96mself[39;49;00m._call_matcher([96mself[39;49;00m.call_args)[90m[39;49;00m
        [94mif[39;49;00m actual != expected:[90m[39;49;00m
            cause = expected [94mif[39;49;00m [96misinstance[39;49;00m(expected, [96mException[39;49;00m) [94melse[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
>           [94mraise[39;49;00m [96mAssertionError[39;49;00m(_error_message()) [94mfrom[39;49;00m[90m [39;49;00m[04m[96mcause[39;49;00m[90m[39;49;00m
[1m[31mE           AssertionError: expected call not found.[0m
[1m[31mE           Expected: request('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version'}, timeout=120)[0m
[1m[31mE             Actual: request('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)[0m

_error_message = <function NonCallableMock.assert_called_with.<locals>._error_message at 0x798d6dedbc40>
actual     = call('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)
args       = ('GET', 'http://my-host/my/endpoint')
cause      = None
expected   = call('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version'}, timeout=120)
kwargs     = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version'}, 'timeout': 120, 'verify': '/some/path'}
self       = <MagicMock name='request' id='133648341483792'>

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:939: AssertionError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_request_headers_default[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
    [90m[39;49;00m
        [90m# The test plugin's request header provider always returns False from in_context to avoid[39;49;00m[90m[39;49;00m
        [90m# polluting request headers in developers' environments. The following mock overrides this to[39;49;00m[90m[39;49;00m
        [90m# perform the integration test.[39;49;00m[90m[39;49;00m
        host_only = MlflowHostCreds([33m"[39;49;00m[33mhttp://my-host[39;49;00m[33m"[39;49;00m, server_cert_path=[33m"[39;49;00m[33m/some/path[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        default_headers = DefaultRequestHeaderProvider().request_headers()[90m[39;49;00m
        expected_headers = {[90m[39;49;00m
            _USER_AGENT: [33m"[39;49;00m[33m{}[39;49;00m[33m [39;49;00m[33m{}[39;49;00m[33m"[39;49;00m.format(default_headers[_USER_AGENT], [33m"[39;49;00m[33mtest_user_agent[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            _CLIENT_VERSION: [33m"[39;49;00m[33m{}[39;49;00m[33m [39;49;00m[33m{}[39;49;00m[33m"[39;49;00m.format(default_headers[_CLIENT_VERSION], [33m"[39;49;00m[33mtest_client_version[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        response = mock.MagicMock()[90m[39;49;00m
        response.status_code = [94m200[39;49;00m[90m[39;49;00m
        [94mwith[39;49;00m ([90m[39;49;00m
            mock.patch([33m"[39;49;00m[33mrequests.Session.request[39;49;00m[33m"[39;49;00m, return_value=response) [94mas[39;49;00m mock_request,[90m[39;49;00m
            mock.patch.object(PluginRequestHeaderProvider, [33m"[39;49;00m[33min_context[39;49;00m[33m"[39;49;00m, return_value=[94mTrue[39;49;00m),[90m[39;49;00m
            mock.patch.object([90m[39;49;00m
                PluginRequestHeaderProvider,[90m[39;49;00m
                [33m"[39;49;00m[33mrequest_headers[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                return_value={_USER_AGENT: [33m"[39;49;00m[33mtest_user_agent[39;49;00m[33m"[39;49;00m, _CLIENT_VERSION: [33m"[39;49;00m[33mtest_client_version[39;49;00m[33m"[39;49;00m},[90m[39;49;00m
            ),[90m[39;49;00m
        ):[90m[39;49;00m
            http_request(host_only, [33m"[39;49;00m[33m/my/endpoint[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>           mock_request.assert_called_with([90m[39;49;00m
                [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mhttp://my-host/my/endpoint[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                allow_redirects=[94mTrue[39;49;00m,[90m[39;49;00m
                verify=[33m"[39;49;00m[33m/some/path[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                headers=expected_headers,[90m[39;49;00m
                timeout=[94m120[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
[1m[31mE           AssertionError: expected call not found.[0m
[1m[31mE           Expected: request('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version'}, timeout=120)[0m
[1m[31mE             Actual: request('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)[0m
[1m[31mE           [0m
[1m[31mE           pytest introspection follows:[0m
[1m[31mE           [0m
[1m[31mE           Kwargs:[0m
[1m[31mE           assert {'allow_redir... '/some/path'} == {'allow_redir... '/some/path'}[0m
[1m[31mE             [0m
[1m[31mE             Omitting 3 identical items, use -vv to show[0m
[1m[31mE             Differing items:[0m
[1m[31mE             [0m{[33m'[39;49;00m[33mheaders[39;49;00m[33m'[39;49;00m: {[33m'[39;49;00m[33mUser-Agent[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33mmlflow-python-client/3.6.1.dev0[39;49;00m[33m'[39;49;00m, [33m'[39;49;00m[33mX-MLflow-Client-Version[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33m3.6.1.dev0[39;49;00m[33m'[39;49;00m}}[90m[39;49;00m != [0m{[33m'[39;49;00m[33mheaders[39;49;00m[33m'[39;49;00m: {[33m'[39;49;00m[33mUser-Agent[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33mm...[0m
[1m[31mE             [0m
[1m[31mE             ...Full output truncated (2 lines hidden), use '-vv' to show[0m

PluginRequestHeaderProvider = <class 'mlflow_test_plugin.request_header_provider.PluginRequestHeaderProvider'>
default_headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}
expected_headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version'}
host_only  = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x798d6deb4a90>
mock_request = <MagicMock name='request' id='133648341483792'>
response   = <MagicMock id='133648341499408'>

[1m[31mtests/utils/test_rest_utils.py[0m:340: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________ test_http_request_request_headers_default_and_extra_header __________[0m

self = <MagicMock name='request' id='133648340764368'>
args = ('GET', 'http://my-host/my/endpoint')
kwargs = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version', 'header': 'value'}, 'timeout': 120, 'verify': '/some/path'}
expected = call('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-py....1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version', 'header': 'value'}, timeout=120)
actual = call('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)
_error_message = <function NonCallableMock.assert_called_with.<locals>._error_message at 0x798d6df784a0>
cause = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92massert_called_with[39;49;00m([96mself[39;49;00m, /, *args, **kwargs):[90m[39;49;00m
    [90m    [39;49;00m[33m"""assert that the last call was made with the specified arguments.[39;49;00m
    [33m[39;49;00m
    [33m    Raises an AssertionError if the args and keyword args passed in are[39;49;00m
    [33m    different to the last call to the mock."""[39;49;00m[90m[39;49;00m
        [94mif[39;49;00m [96mself[39;49;00m.call_args [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            expected = [96mself[39;49;00m._format_mock_call_signature(args, kwargs)[90m[39;49;00m
            actual = [33m'[39;49;00m[33mnot called.[39;49;00m[33m'[39;49;00m[90m[39;49;00m
            error_message = ([33m'[39;49;00m[33mexpected call not found.[39;49;00m[33m\n[39;49;00m[33mExpected: [39;49;00m[33m%s[39;49;00m[33m\n[39;49;00m[33m  Actual: [39;49;00m[33m%s[39;49;00m[33m'[39;49;00m[90m[39;49;00m
                    % (expected, actual))[90m[39;49;00m
            [94mraise[39;49;00m [96mAssertionError[39;49;00m(error_message)[90m[39;49;00m
    [90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92m_error_message[39;49;00m():[90m[39;49;00m
            msg = [96mself[39;49;00m._format_mock_failure_message(args, kwargs)[90m[39;49;00m
            [94mreturn[39;49;00m msg[90m[39;49;00m
        expected = [96mself[39;49;00m._call_matcher(_Call((args, kwargs), two=[94mTrue[39;49;00m))[90m[39;49;00m
        actual = [96mself[39;49;00m._call_matcher([96mself[39;49;00m.call_args)[90m[39;49;00m
        [94mif[39;49;00m actual != expected:[90m[39;49;00m
            cause = expected [94mif[39;49;00m [96misinstance[39;49;00m(expected, [96mException[39;49;00m) [94melse[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
>           [94mraise[39;49;00m [96mAssertionError[39;49;00m(_error_message()) [94mfrom[39;49;00m[90m [39;49;00m[04m[96mcause[39;49;00m[90m[39;49;00m
[1m[31mE           AssertionError: expected call not found.[0m
[1m[31mE           Expected: request('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version', 'header': 'value'}, timeout=120)[0m
[1m[31mE             Actual: request('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)[0m

_error_message = <function NonCallableMock.assert_called_with.<locals>._error_message at 0x798d6df784a0>
actual     = call('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)
args       = ('GET', 'http://my-host/my/endpoint')
cause      = None
expected   = call('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-py....1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version', 'header': 'value'}, timeout=120)
kwargs     = {'allow_redirects': True, 'headers': {'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version', 'header': 'value'}, 'timeout': 120, 'verify': '/some/path'}
self       = <MagicMock name='request' id='133648340764368'>

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:939: AssertionError

[33mDuring handling of the above exception, another exception occurred:[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_http_request_request_headers_default_and_extra_header[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
    [90m[39;49;00m
        [90m# The test plugin's request header provider always returns False from in_context to avoid[39;49;00m[90m[39;49;00m
        [90m# polluting request headers in developers' environments. The following mock overrides this to[39;49;00m[90m[39;49;00m
        [90m# perform the integration test.[39;49;00m[90m[39;49;00m
        host_only = MlflowHostCreds([33m"[39;49;00m[33mhttp://my-host[39;49;00m[33m"[39;49;00m, server_cert_path=[33m"[39;49;00m[33m/some/path[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        default_headers = DefaultRequestHeaderProvider().request_headers()[90m[39;49;00m
        expected_headers = {[90m[39;49;00m
            _USER_AGENT: [33m"[39;49;00m[33m{}[39;49;00m[33m [39;49;00m[33m{}[39;49;00m[33m"[39;49;00m.format(default_headers[_USER_AGENT], [33m"[39;49;00m[33mtest_user_agent[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            _CLIENT_VERSION: [33m"[39;49;00m[33m{}[39;49;00m[33m [39;49;00m[33m{}[39;49;00m[33m"[39;49;00m.format(default_headers[_CLIENT_VERSION], [33m"[39;49;00m[33mtest_client_version[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            [33m"[39;49;00m[33mheader[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mvalue[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        response = mock.MagicMock()[90m[39;49;00m
        response.status_code = [94m200[39;49;00m[90m[39;49;00m
        [94mwith[39;49;00m ([90m[39;49;00m
            mock.patch([33m"[39;49;00m[33mrequests.Session.request[39;49;00m[33m"[39;49;00m, return_value=response) [94mas[39;49;00m mock_request,[90m[39;49;00m
            mock.patch.object(PluginRequestHeaderProvider, [33m"[39;49;00m[33min_context[39;49;00m[33m"[39;49;00m, return_value=[94mTrue[39;49;00m),[90m[39;49;00m
            mock.patch.object([90m[39;49;00m
                PluginRequestHeaderProvider,[90m[39;49;00m
                [33m"[39;49;00m[33mrequest_headers[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                return_value={[90m[39;49;00m
                    _USER_AGENT: [33m"[39;49;00m[33mtest_user_agent[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    _CLIENT_VERSION: [33m"[39;49;00m[33mtest_client_version[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    [33m"[39;49;00m[33mheader[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mvalue[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                },[90m[39;49;00m
            ),[90m[39;49;00m
        ):[90m[39;49;00m
            http_request(host_only, [33m"[39;49;00m[33m/my/endpoint[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>           mock_request.assert_called_with([90m[39;49;00m
                [33m"[39;49;00m[33mGET[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mhttp://my-host/my/endpoint[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                allow_redirects=[94mTrue[39;49;00m,[90m[39;49;00m
                verify=[33m"[39;49;00m[33m/some/path[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                headers=expected_headers,[90m[39;49;00m
                timeout=[94m120[39;49;00m,[90m[39;49;00m
            )[90m[39;49;00m
[1m[31mE           AssertionError: expected call not found.[0m
[1m[31mE           Expected: request('GET', 'http://my-host/my/endpoint', allow_redirects=True, verify='/some/path', headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version', 'header': 'value'}, timeout=120)[0m
[1m[31mE             Actual: request('GET', 'http://my-host/my/endpoint', timeout=120, headers={'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}, verify='/some/path', allow_redirects=True)[0m
[1m[31mE           [0m
[1m[31mE           pytest introspection follows:[0m
[1m[31mE           [0m
[1m[31mE           Kwargs:[0m
[1m[31mE           assert {'allow_redir... '/some/path'} == {'allow_redir... '/some/path'}[0m
[1m[31mE             [0m
[1m[31mE             Omitting 3 identical items, use -vv to show[0m
[1m[31mE             Differing items:[0m
[1m[31mE             [0m{[33m'[39;49;00m[33mheaders[39;49;00m[33m'[39;49;00m: {[33m'[39;49;00m[33mUser-Agent[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33mmlflow-python-client/3.6.1.dev0[39;49;00m[33m'[39;49;00m, [33m'[39;49;00m[33mX-MLflow-Client-Version[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33m3.6.1.dev0[39;49;00m[33m'[39;49;00m}}[90m[39;49;00m != [0m{[33m'[39;49;00m[33mheaders[39;49;00m[33m'[39;49;00m: {[33m'[39;49;00m[33mUser-Agent[39;49;00m[33m'[39;49;00m: [33m'[39;49;00m[33mm...[0m
[1m[31mE             [0m
[1m[31mE             ...Full output truncated (2 lines hidden), use '-vv' to show[0m

PluginRequestHeaderProvider = <class 'mlflow_test_plugin.request_header_provider.PluginRequestHeaderProvider'>
default_headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0', 'X-MLflow-Client-Version': '3.6.1.dev0'}
expected_headers = {'User-Agent': 'mlflow-python-client/3.6.1.dev0 test_user_agent', 'X-MLflow-Client-Version': '3.6.1.dev0 test_client_version', 'header': 'value'}
host_only  = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x798d6dfc6c50>
mock_request = <MagicMock name='request' id='133648340764368'>
response   = <MagicMock id='133648342608272'>

[1m[31mtests/utils/test_rest_utils.py[0m:382: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:29 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________ test_run_context_provider_registry_with_installed_plugin ___________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_run_context_provider_registry_with_installed_plugin[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""This test requires the package in tests/resources/mlflow-test-plugin to be installed"""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        reload(mlflow.tracking.request_header.registry)[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow_test_plugin[39;49;00m[04m[96m.[39;49;00m[04m[96mrequest_header_provider[39;49;00m[90m [39;49;00m[94mimport[39;49;00m PluginRequestHeaderProvider[90m[39;49;00m
    [90m[39;49;00m
>       [94massert[39;49;00m PluginRequestHeaderProvider [95min[39;49;00m _currently_registered_request_header_provider_classes()[90m[39;49;00m
[1m[31mE       AssertionError: assert <class 'mlflow_test_plugin.request_header_provider.PluginRequestHeaderProvider'> in {<class 'mlflow.tracking.request_header.default_request_header_provider.DefaultRequestHeaderProvider'>, <class 'mlflow.tracking.request_header.databricks_request_header_provider.DatabricksRequestHeaderProvider'>}[0m
[1m[31mE        +  where {<class 'mlflow.tracking.request_header.default_request_header_provider.DefaultRequestHeaderProvider'>, <class 'mlflow.tracking.request_header.databricks_request_header_provider.DatabricksRequestHeaderProvider'>} = _currently_registered_request_header_provider_classes()[0m

PluginRequestHeaderProvider = <class 'mlflow_test_plugin.request_header_provider.PluginRequestHeaderProvider'>

[1m[31mtests/tracking/request_header/test_registry.py[0m:103: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:31:44 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
13.37s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_max_retries_exceeded
0.43s call     tests/utils/test_rest_utils.py::test_suppress_databricks_retry_after_secs_warnings
0.37s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_on_transient_errors
0.21s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_timeout_exceeded
0.06s call     tests/utils/test_rest_utils.py::test_malformed_json_error_response[response_mock1]
0.02s call     tests/gateway/test_gateway_config_parsing.py::test_api_key_parsing_file
0.02s call     tests/utils/test_rest_utils.py::test_http_request_request_headers
0.01s teardown tests/tracking/request_header/test_registry.py::test_request_header_provider_registry_register_entrypoints_handles_exception[exception0]
0.01s teardown tests/tracking/request_header/test_registry.py::test_request_header_provider_registry_register_entrypoints
0.01s teardown tests/tracking/request_header/test_registry.py::test_resolve_request_headers

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                             | Duration | Tests | Min    | Max     | Avg    |
| ---- | -------------------------------- | -------- | ----- | ------ | ------- | ------ |
| 1    | `tests/utils/test_rest_utils.py` | 14.75s   | 48    | 0.001s | 13.376s | 0.307s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/deployments/test_deployments.py::test_create_success' 'tests/deployments/test_deployments.py::test_delete_success' 'tests/deployments/test_deployments.py::test_update_success' 'tests/deployments/test_deployments.py::test_list_success' 'tests/deployments/test_deployments.py::test_get_success' 'tests/deployments/test_deployments.py::test_endpoint_create_success' 'tests/deployments/test_deployments.py::test_endpoint_delete_success' 'tests/deployments/test_deployments.py::test_endpoint_update_success' 'tests/deployments/test_deployments.py::test_endpoint_list_success' 'tests/deployments/test_deployments.py::test_endpoint_get_success' 'tests/deployments/test_deployments.py::test_plugin_raising_error' 'tests/deployments/test_deployments.py::test_target_uri_parsing' 'tests/deployments/test_deployments.py::test_explain_with_no_target_implementation' 'tests/deployments/test_deployments.py::test_explain_with_target_implementation' 'tests/utils/test_rest_utils.py::test_http_request_request_headers' 'tests/utils/test_rest_utils.py::test_http_request_request_headers_default' 'tests/utils/test_rest_utils.py::test_http_request_request_headers_default_and_extra_header' 'tests/tracking/request_header/test_registry.py::test_run_context_provider_registry_with_installed_plugin'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_create_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_delete_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_update_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_list_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_get_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_create_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_delete_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_update_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_list_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_endpoint_get_success[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_plugin_raising_error[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_target_uri_parsing[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_explain_with_no_target_implementation[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/deployments/test_deployments.py::[1mtest_explain_with_target_implementation[0m - mlflow.exceptions.MlflowException: No plugin found for managing model deplo...
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_request_headers[0m - AssertionError: expected call not found.
[31mFAILED | MEM 13.7/46.9 GB | DISK 832.9/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_request_headers_default[0m - AssertionError: expected call not found.
[31mFAILED | MEM 13.6/46.9 GB | DISK 832.9/915.7 GB[0m tests/utils/test_rest_utils.py::[1mtest_http_request_request_headers_default_and_extra_header[0m - AssertionError: expected call not found.
[31mFAILED | MEM 13.6/46.9 GB | DISK 832.9/915.7 GB[0m tests/tracking/request_header/test_registry.py::[1mtest_run_context_provider_registry_with_installed_plugin[0m - AssertionError: assert <class 'mlflow_test_plugin.request_header_provider.P...
[31m=========== [31m[1m18 failed[0m, [32m80 passed[0m, [33m2 skipped[0m, [33m1 deselected[0m[31m in 15.26s[0m[31m ============[0m
```

## 原始行 145 · agent_message

```
The core HTTP tests now pass apart from tests whose optional test plugin/AWS package is not installed in this container. The remaining genuine failures exposed two more masked local dependencies (target-URI parsing and deployment-client HTTP imports), which are fixed; I’m validating the built-in Databricks and MLflow deployment clients next.
```

## 原始行 147 · command_execution

命令：
```
/bin/bash -lc "pytest -q tests/deployments/test_interface.py tests/deployments/databricks/test_databricks.py tests/deployments/mlflow tests/utils/test_rest_utils.py -k 'not aws_sigv4 and not request_headers'"
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 76 items / 4 deselected / 72 selected

tests/deployments/test_interface.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                 [  5%][0m
tests/deployments/databricks/test_databricks.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m  [ 37%][0m
tests/utils/test_rest_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m [ 94%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                                                                     [100%][0m

[33m=============================== warnings summary ===============================[0m
tests/deployments/databricks/test_databricks.py::test_create_endpoint
  /testbed/mlflow/deployments/databricks/__init__.py:493: UserWarning: Passing 'name', 'config', and 'route_optimized' as separate parameters is deprecated. Please pass the full API request payload as a single dictionary in the 'config' parameter.
    warnings.warn("\n".join(warnings_list), UserWarning)

tests/deployments/databricks/test_databricks.py::test_update_endpoint
  /testbed/tests/deployments/databricks/test_databricks.py:366: FutureWarning: ``mlflow.deployments.databricks.DatabricksDeploymentClient.update_endpoint`` is deprecated. This method will be removed in a future release. Use ``update_endpoint_config, update_endpoint_tags, update_endpoint_rate_limits, or update_endpoint_ai_gateway`` instead.
    resp = client.update_endpoint(

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
13.14s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_max_retries_exceeded
0.85s call     tests/deployments/databricks/test_databricks.py::test_create_endpoint
0.63s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_on_transient_errors
0.20s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_timeout_exceeded
0.01s call     tests/deployments/databricks/test_databricks.py::test_get_endpoint
0.01s call     tests/utils/test_rest_utils.py::test_http_request_with_auth
0.01s call     tests/deployments/databricks/test_databricks.py::test_create_endpoint_named_route_optimized
0.01s call     tests/deployments/databricks/test_databricks.py::test_create_endpoint_named_name
0.01s teardown tests/deployments/databricks/test_databricks.py::test_create_endpoint_route_optimized_match
0.01s call     tests/deployments/databricks/test_databricks.py::test_create_endpoint_name_match

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                              | Duration | Tests | Min    | Max     | Avg    |
| ---- | ------------------------------------------------- | -------- | ----- | ------ | ------- | ------ |
| 1    | `tests/utils/test_rest_utils.py`                  | 14.08s   | 45    | 0.000s | 13.141s | 0.313s |
| 2    | `tests/deployments/databricks/test_databricks.py` | 1.01s    | 23    | 0.003s | 0.855s  | 0.044s |

::endgroup::

[33m=========== [32m70 passed[0m, [33m[1m2 skipped[0m, [33m[1m4 deselected[0m, [33m[1m2 warnings[0m[33m in 15.24s[0m[33m ===========[0m
```

## 原始行 150 · command_execution

命令：
```
/bin/bash -lc 'find tests/deployments -maxdepth 2 -type f -print | sort'
```

退出码：`0`

输出：
```
tests/deployments/__init__.py
tests/deployments/__pycache__/__init__.cpython-311.pyc
tests/deployments/__pycache__/test_deployments.cpython-311-pytest-9.0.1.pyc
tests/deployments/__pycache__/test_interface.cpython-311-pytest-9.0.1.pyc
tests/deployments/databricks/__init__.py
tests/deployments/databricks/test_databricks.py
tests/deployments/mlflow/__init__.py
tests/deployments/openai/__init__.py
tests/deployments/openai/test_openai.py
tests/deployments/test_cli.py
tests/deployments/test_deployments.py
tests/deployments/test_interface.py
tests/deployments/test_utils.py
```

## 原始行 152 · command_execution

命令：
```
/bin/bash -lc 'git diff -- mlflow/gateway/config.py mlflow/deployments/interface.py mlflow/deployments/server/config.py mlflow/utils/rest_utils.py mlflow/utils/request_utils.py mlflow/deployments/base.py mlflow/deployments/plugin_manager.py mlflow/deployments/__init__.py mlflow/deployments/databricks/__init__.py mlflow/deployments/mlflow/__init__.py mlflow/tracking/request_header'
```

退出码：`0`

输出：
```
diff --git a/mlflow/deployments/__init__.py b/mlflow/deployments/__init__.py
index 33d590f..9d35458 100644
--- a/mlflow/deployments/__init__.py
+++ b/mlflow/deployments/__init__.py
@@ -19,7 +19,7 @@ import json
 
 from mlflow.deployments.base import BaseDeploymentClient
 from mlflow.deployments.databricks import DatabricksDeploymentClient, DatabricksEndpoint
-from mlflow.deployments.interface import run_local
+from mlflow.deployments.interface import get_deploy_client, run_local
 from mlflow.deployments.openai import OpenAIDeploymentClient
 from mlflow.deployments.utils import get_deployments_target, set_deployments_target
 from mlflow.exceptions import MlflowException
diff --git a/mlflow/deployments/base.py b/mlflow/deployments/base.py
index c78d4bb..c42daa2 100644
--- a/mlflow/deployments/base.py
+++ b/mlflow/deployments/base.py
@@ -85,8 +85,8 @@ class BaseDeploymentClient(abc.ABC):
         Subclasses should raise :py:class:`mlflow.exceptions.MlflowException` in error cases (e.g.
         on failure to deploy a model).
     """
-
-
+    def __init__(self, target_uri):
+        self.target_uri = target_uri
 
 
     @abc.abstractmethod
@@ -355,4 +355,4 @@ class BaseDeploymentClient(abc.ABC):
         raise MlflowException(
             "Method is unimplemented in base client. Implementation should be "
             "provided by specific target plugins."
-        )
\ No newline at end of file
+        )
diff --git a/mlflow/deployments/databricks/__init__.py b/mlflow/deployments/databricks/__init__.py
index 2e2cc04..ef787eb 100644
--- a/mlflow/deployments/databricks/__init__.py
+++ b/mlflow/deployments/databricks/__init__.py
@@ -16,7 +16,11 @@ from mlflow.exceptions import MlflowException
 from mlflow.utils import AttrDict
 from mlflow.utils.annotations import deprecated
 from mlflow.utils.databricks_utils import get_databricks_host_creds
-from mlflow.utils.rest_utils import augmented_raise_for_status, validate_deployment_timeout_config
+from mlflow.utils.rest_utils import (
+    augmented_raise_for_status,
+    http_request,
+    validate_deployment_timeout_config,
+)
 
 
 
diff --git a/mlflow/deployments/interface.py b/mlflow/deployments/interface.py
index b7242ca..5f8abb1 100644
--- a/mlflow/deployments/interface.py
+++ b/mlflow/deployments/interface.py
@@ -12,6 +12,32 @@ plugin_store.register("sagemaker", "mlflow.sagemaker")
 _logger = Logger(__name__)
 
 
+def get_deploy_client(target_uri=None):
+    """Return the deployment client registered for ``target_uri``.
+
+    When no URI is supplied, the configured deployments target is used.  For
+    backwards compatibility, an absent configured target produces ``None``.
+    """
+    if target_uri is None:
+        try:
+            target_uri = get_deployments_target()
+        except MlflowException:
+            _logger.info(
+                "No deployments target has been set. Set one with "
+                "mlflow.deployments.set_deployments_target() or the "
+                "MLFLOW_DEPLOYMENTS_TARGET environment variable."
+            )
+            return None
+
+    plugin = plugin_store[target_uri]
+    for _, candidate in inspect.getmembers(plugin, inspect.isclass):
+        if candidate is not BaseDeploymentClient and issubclass(candidate, BaseDeploymentClient):
+            return candidate(target_uri)
+
+    # DeploymentPlugins validates this invariant, so this is defensive only.
+    raise MlflowException(f"No deployment client implementation found for target {target_uri!r}")
+
+
 
 
 
@@ -99,4 +125,4 @@ def _target_help(target):
     Args:
         target: Which target to use. This information is used to call the appropriate plugin.
     """
-    return plugin_store[target].target_help()
\ No newline at end of file
+    return plugin_store[target].target_help()
diff --git a/mlflow/deployments/mlflow/__init__.py b/mlflow/deployments/mlflow/__init__.py
index d40fb7b..e7a4a77 100644
--- a/mlflow/deployments/mlflow/__init__.py
+++ b/mlflow/deployments/mlflow/__init__.py
@@ -20,7 +20,7 @@ from mlflow.environment_variables import (
 from mlflow.protos.databricks_pb2 import BAD_REQUEST
 from mlflow.store.entities.paged_list import PagedList
 from mlflow.utils.credentials import get_default_host_creds
-from mlflow.utils.rest_utils import augmented_raise_for_status
+from mlflow.utils.rest_utils import augmented_raise_for_status, http_request
 from mlflow.utils.uri import join_paths
 
 if TYPE_CHECKING:
diff --git a/mlflow/deployments/plugin_manager.py b/mlflow/deployments/plugin_manager.py
index 2e94f93..d90fc33 100644
--- a/mlflow/deployments/plugin_manager.py
+++ b/mlflow/deployments/plugin_manager.py
@@ -17,6 +17,11 @@ from mlflow.utils.plugins import get_entry_points
 #   mlflow/store/artifact/artifact_repository_registry.py
 
 
+def parse_target_uri(target_uri):
+    """Return the deployment plugin name encoded by a target URI."""
+    return target_uri.split(":", 1)[0]
+
+
 @developer_stable
 class PluginManager(abc.ABC):
     """
diff --git a/mlflow/deployments/server/config.py b/mlflow/deployments/server/config.py
index 79995f0..0d07191 100644
--- a/mlflow/deployments/server/config.py
+++ b/mlflow/deployments/server/config.py
@@ -1,4 +1,24 @@
 from pydantic import ConfigDict
 
 from mlflow.gateway.base_models import ResponseModel
-from mlflow.gateway.config import EndpointModelInfo
+from mlflow.gateway.config import EndpointModelInfo, Limit
+
+
+class Endpoint(ResponseModel):
+    name: str
+    endpoint_type: str
+    model: EndpointModelInfo
+    endpoint_url: str
+    limit: Limit | None
+
+    model_config = ConfigDict(
+        json_schema_extra={
+            "example": {
+                "name": "openai-completions",
+                "endpoint_type": "llm/v1/completions",
+                "model": {"name": "gpt-4o-mini", "provider": "openai"},
+                "endpoint_url": "/endpoints/completions/invocations",
+                "limit": {"calls": 1, "key": None, "renewal_period": "minute"},
+            }
+        }
+    )
diff --git a/mlflow/gateway/config.py b/mlflow/gateway/config.py
index 2069851..f1a98b0 100644
--- a/mlflow/gateway/config.py
+++ b/mlflow/gateway/config.py
@@ -320,6 +320,18 @@ class AliasedConfigModel(ConfigModel):
     model_config = ConfigDict(populate_by_name=True)
 
 
+class EndpointType(str, Enum):
+    LLM_V1_COMPLETIONS = "llm/v1/completions"
+    LLM_V1_CHAT = "llm/v1/chat"
+    LLM_V1_EMBEDDINGS = "llm/v1/embeddings"
+
+
+class Limit(LimitModel):
+    calls: int
+    key: str | None = None
+    renewal_period: str
+
+
 
 
 
@@ -389,9 +401,9 @@ class EndpointConfig(AliasedConfigModel):
 
     @field_validator("limit", mode="before")
     def validate_limit(cls, value):
-        from limits import parse
-
         if value:
+            from limits import parse
+
             limit = Limit(**value)
             try:
                 parse(f"{limit.calls}/{limit.renewal_period}")
@@ -527,4 +539,4 @@ def _validate_config(config_path: str) -> GatewayConfig:
     try:
         return _load_gateway_config(config_path)
     except Exception as e:
-        raise MlflowException.invalid_parameter_value(f"Invalid gateway configuration: {e}") from e
\ No newline at end of file
+        raise MlflowException.invalid_parameter_value(f"Invalid gateway configuration: {e}") from e
diff --git a/mlflow/tracking/request_header/databricks_request_header_provider.py b/mlflow/tracking/request_header/databricks_request_header_provider.py
index c51ecd4..a6e2c1d 100644
--- a/mlflow/tracking/request_header/databricks_request_header_provider.py
+++ b/mlflow/tracking/request_header/databricks_request_header_provider.py
@@ -7,7 +7,12 @@ class DatabricksRequestHeaderProvider(RequestHeaderProvider):
     Provides request headers indicating the type of Databricks environment from which a request
     was made.
     """
-
+    def in_context(self):
+        return (
+            databricks_utils.is_in_databricks_notebook()
+            or databricks_utils.is_in_databricks_job()
+            or databricks_utils.is_in_cluster()
+        )
 
 
 
@@ -35,4 +40,4 @@ class DatabricksRequestHeaderProvider(RequestHeaderProvider):
         if workload_class is not None:
             request_headers["workload_class"] = workload_class
 
-        return request_headers
\ No newline at end of file
+        return request_headers
diff --git a/mlflow/tracking/request_header/default_request_header_provider.py b/mlflow/tracking/request_header/default_request_header_provider.py
index 8b125ce..e854e7a 100644
--- a/mlflow/tracking/request_header/default_request_header_provider.py
+++ b/mlflow/tracking/request_header/default_request_header_provider.py
@@ -14,5 +14,8 @@ class DefaultRequestHeaderProvider(RequestHeaderProvider):
     """
     Provides default request headers for outgoing request.
     """
+    def in_context(self):
+        return True
 
-
+    def request_headers(self):
+        return _DEFAULT_HEADERS.copy()
diff --git a/mlflow/tracking/request_header/registry.py b/mlflow/tracking/request_header/registry.py
index 6c51778..4e64199 100644
--- a/mlflow/tracking/request_header/registry.py
+++ b/mlflow/tracking/request_header/registry.py
@@ -43,3 +43,21 @@ _request_header_provider_registry.register(DefaultRequestHeaderProvider)
 _request_header_provider_registry.register_entrypoints()
 
 
+def resolve_request_headers(request_headers=None):
+    """Resolve and merge headers from all providers active in this context."""
+    headers = {}
+    for provider in _request_header_provider_registry:
+        if not provider.in_context():
+            continue
+        try:
+            provider_headers = provider.request_headers()
+        except Exception as e:
+            _logger.warning(
+                "Encountered an unexpected error while resolving request headers: %s", e
+            )
+            continue
+        for name, value in provider_headers.items():
+            headers[name] = f"{headers[name]} {value}" if name in headers else value
+    if request_headers:
+        headers.update(request_headers)
+    return headers
diff --git a/mlflow/utils/request_utils.py b/mlflow/utils/request_utils.py
index eaf4e57..b5f1cdc 100644
--- a/mlflow/utils/request_utils.py
+++ b/mlflow/utils/request_utils.py
@@ -98,6 +98,63 @@ def download_chunk(*, range_start, range_end, headers, download_path, http_uri):
             f.write(response.content)
 
 
+@lru_cache(maxsize=8)
+def _cached_get_request_session(
+    max_retries,
+    backoff_factor,
+    backoff_jitter,
+    retry_codes,
+    raise_on_status,
+    respect_retry_after_header,
+):
+    retry = JitteredRetry(
+        total=max_retries,
+        connect=max_retries,
+        read=max_retries,
+        redirect=max_retries,
+        status=max_retries,
+        allowed_methods=None,
+        status_forcelist=retry_codes,
+        backoff_factor=backoff_factor,
+        backoff_jitter=backoff_jitter,
+        raise_on_status=raise_on_status,
+        respect_retry_after_header=respect_retry_after_header,
+    )
+    adapter = HTTPAdapter(max_retries=retry)
+    session = requests.Session()
+    session.mount("http://", adapter)
+    session.mount("https://", adapter)
+    return session
+
+
+def _get_http_response_with_retries(
+    method,
+    url,
+    max_retries,
+    backoff_factor,
+    backoff_jitter,
+    retry_codes,
+    raise_on_status=True,
+    timeout=None,
+    respect_retry_after_header=True,
+    **kwargs,
+):
+    """Issue a request using a cached session configured with urllib3 retries."""
+    retry_codes = tuple(sorted(retry_codes))
+    session = _cached_get_request_session(
+        max_retries,
+        backoff_factor,
+        backoff_jitter,
+        retry_codes,
+        raise_on_status,
+        respect_retry_after_header,
+    )
+    if "allow_redirects" not in kwargs:
+        allow_redirects = os.getenv("MLFLOW_ALLOW_HTTP_REDIRECTS", "true").lower()
+        kwargs["allow_redirects"] = allow_redirects in {"1", "true"}
+    return session.request(method, url, timeout=timeout, **kwargs)
+
+
 
 
 
@@ -276,4 +333,4 @@ def cloud_storage_http_request(
         retry_codes,
         timeout=timeout,
         **kwargs,
-    )
\ No newline at end of file
+    )
diff --git a/mlflow/utils/rest_utils.py b/mlflow/utils/rest_utils.py
index 063b65f..46642f8 100644
--- a/mlflow/utils/rest_utils.py
+++ b/mlflow/utils/rest_utils.py
@@ -33,7 +33,12 @@ from mlflow.exceptions import (
 from mlflow.protos import databricks_pb2
 from mlflow.protos.databricks_pb2 import ENDPOINT_NOT_FOUND, ErrorCode
 from mlflow.utils.proto_json_utils import parse_dict
-from mlflow.utils.request_utils import _TRANSIENT_FAILURE_RESPONSE_CODES, augmented_raise_for_status, cloud_storage_http_request
+from mlflow.utils.request_utils import (
+    _TRANSIENT_FAILURE_RESPONSE_CODES,
+    _get_http_response_with_retries,
+    augmented_raise_for_status,
+    cloud_storage_http_request,
+)
 
 
 
@@ -57,6 +62,196 @@ _DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING = (
 )
 
 
+def _resolve_request_headers(extra_headers=None):
+    from mlflow.tracking.request_header.registry import resolve_request_headers
+
+    headers = resolve_request_headers(extra_headers)
+    traffic_id = _MLFLOW_DATABRICKS_TRAFFIC_ID.get()
+    if traffic_id:
+        headers["x-databricks-traffic-id"] = traffic_id
+    return headers
+
+
+def _databricks_error_to_response(error, url):
+    from databricks.sdk.errors import STATUS_CODE_MAPPING
+
+    status_code = next(
+        (code for code, error_type in STATUS_CODE_MAPPING.items() if isinstance(error, error_type)),
+        ERROR_CODE_TO_HTTP_STATUS.get(getattr(error, "error_code", None), 500),
+    )
+    response = requests.Response()
+    response.status_code = status_code
+    response.url = url
+    response._content = json.dumps(
+        {
+            "error_code": getattr(error, "error_code", None) or "INTERNAL_ERROR",
+            "message": str(error),
+        }
+    ).encode("utf-8")
+    response.headers["Content-Type"] = "application/json"
+    return response
+
+
+def http_request(
+    host_creds,
+    endpoint,
+    method,
+    max_retries=None,
+    backoff_factor=None,
+    backoff_jitter=None,
+    extra_headers=None,
+    retry_codes=_TRANSIENT_FAILURE_RESPONSE_CODES,
+    timeout=None,
+    raise_on_status=True,
+    respect_retry_after_header=None,
+    retry_timeout_seconds=None,
+    **kwargs,
+):
+    """Make an authenticated HTTP request to an MLflow service endpoint."""
+    max_retries = MLFLOW_HTTP_REQUEST_MAX_RETRIES.get() if max_retries is None else max_retries
+    backoff_factor = (
+        MLFLOW_HTTP_REQUEST_BACKOFF_FACTOR.get() if backoff_factor is None else backoff_factor
+    )
+    backoff_jitter = (
+        MLFLOW_HTTP_REQUEST_BACKOFF_JITTER.get() if backoff_jitter is None else backoff_jitter
+    )
+    timeout = MLFLOW_HTTP_REQUEST_TIMEOUT.get() if timeout is None else timeout
+    respect_retry_after_header = (
+        MLFLOW_HTTP_RESPECT_RETRY_AFTER_HEADER.get()
+        if respect_retry_after_header is None
+        else respect_retry_after_header
+    )
+
+    if max_retries < 0:
+        raise MlflowException.invalid_parameter_value(
+            "The max_retries value must be either zero or a positive integer."
+        )
+    if max_retries > _MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get():
+        raise MlflowException.invalid_parameter_value(
+            "The configured max_retries exceeds the allowed maximum of "
+            f"{_MLFLOW_HTTP_REQUEST_MAX_RETRIES_LIMIT.get()}."
+        )
+    if backoff_factor < 0:
+        raise MlflowException.invalid_parameter_value(
+            "The backoff_factor value must be zero or a positive number."
+        )
+    if backoff_factor > _MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get():
+        raise MlflowException.invalid_parameter_value(
+            "The configured backoff_factor exceeds the allowed maximum of "
+            f"{_MLFLOW_HTTP_REQUEST_MAX_BACKOFF_FACTOR_LIMIT.get()}."
+        )
+    if host_creds.client_secret and not MLFLOW_ENABLE_DB_SDK.get():
+        raise MlflowException(
+            "OAuth authentication requires the Databricks SDK. Set MLFLOW_ENABLE_DB_SDK=true.",
+            error_code=CUSTOMER_UNAUTHORIZED,
+        )
+
+    url = f"{host_creds.host.rstrip('/')}/{endpoint.lstrip('/')}"
+    headers = _resolve_request_headers(extra_headers)
+
+    if host_creds.use_databricks_sdk:
+        from databricks.sdk.errors import DatabricksError
+
+        retry_timeout = (
+            MLFLOW_DATABRICKS_ENDPOINT_HTTP_RETRY_TIMEOUT.get()
+            if retry_timeout_seconds is None
+            else retry_timeout_seconds
+        )
+        workspace_client = get_workspace_client(
+            host_creds.use_secret_scope_token,
+            host_creds.host,
+            host_creds.token,
+            host_creds.databricks_auth_profile,
+            retry_timeout_seconds=retry_timeout_seconds,
+            timeout=timeout,
+        )
+        sdk_kwargs = {
+            "method": method,
+            "path": endpoint,
+            "headers": headers,
+            "raw": True,
+        }
+        if "params" in kwargs:
+            sdk_kwargs["query"] = kwargs["params"]
+        if "json" in kwargs:
+            sdk_kwargs["body"] = kwargs["json"]
+        if "files" in kwargs:
+            sdk_kwargs["files"] = kwargs["files"]
+        if "data" in kwargs:
+            sdk_kwargs["data"] = kwargs["data"]
+
+        def call_sdk():
+            return workspace_client.api_client.do(**sdk_kwargs)
+
+        try:
+            with warnings.catch_warnings():
+                warnings.filterwarnings(
+                    "ignore",
+                    message=f".*{_DATABRICKS_SDK_RETRY_AFTER_SECS_DEPRECATION_WARNING}.*",
+                )
+                result = _retry_databricks_sdk_call_with_exponential_backoff(
+                    call_func=call_sdk,
+                    retry_codes=retry_codes,
+                    retry_timeout_seconds=retry_timeout,
+                    backoff_factor=backoff_factor,
+                    backoff_jitter=backoff_jitter,
+                    max_retries=max_retries,
+                )
+            contents = result.get("contents", result) if isinstance(result, dict) else result
+            return getattr(contents, "_response", contents)
+        except DatabricksError as e:
+            return _databricks_error_to_response(e, url)
+
+    if host_creds.token:
+        headers["Authorization"] = f"Bearer {host_creds.token}"
+    elif host_creds.username is not None and host_creds.password is not None:
+        credentials = f"{host_creds.username}:{host_creds.password}".encode("utf-8")
+        headers["Authorization"] = "Basic " + base64.b64encode(credentials).decode("ascii")
+
+    request_kwargs = {
+        "headers": headers,
+        "verify": (
+            host_creds.server_cert_path
+            if host_creds.server_cert_path is not None
+            else not host_creds.ignore_tls_verification
+        ),
+        "timeout": timeout,
+        **kwargs,
+    }
+    if host_creds.client_cert_path is not None:
+        request_kwargs["cert"] = host_creds.client_cert_path
+    if host_creds.aws_sigv4:
+        from requests_auth_aws_sigv4 import AWSSigV4
+
+        request_kwargs["auth"] = AWSSigV4("execute-api")
+    elif host_creds.auth:
+        from mlflow.tracking.request_auth.registry import fetch_auth
+
+        request_kwargs["auth"] = fetch_auth(host_creds.auth)
+
+    try:
+        return _get_http_response_with_retries(
+            method,
+            url,
+            max_retries,
+            backoff_factor,
+            backoff_jitter,
+            retry_codes,
+            raise_on_status,
+            respect_retry_after_header=respect_retry_after_header,
+            **request_kwargs,
+        )
+    except requests.exceptions.InvalidURL as e:
+        raise InvalidUrlException(f"Invalid url: {url}") from e
+    except requests.exceptions.Timeout as e:
+        raise MlflowException(
+            f"API request to {url} timed out. To increase the timeout, set the environment "
+            f"variable {str(MLFLOW_HTTP_REQUEST_TIMEOUT)}."
+        ) from e
+    except requests.exceptions.RequestException as e:
+        raise MlflowException(f"API request to {url} failed with exception {e}") from e
+
+
 
 
 
@@ -711,4 +906,3 @@ class MlflowHostCreds:
 
     def __hash__(self):
         return hash(frozenset(self.__dict__.items()))
-
```

## 原始行 154 · command_execution

命令：
```
/bin/bash -lc "python -m compileall -q mlflow/gateway/config.py mlflow/deployments mlflow/utils/rest_utils.py mlflow/utils/request_utils.py mlflow/tracking/request_header && python - <<'PY'
from mlflow.gateway.config import EndpointType, Limit, EndpointModelInfo
from mlflow.deployments.server.config import Endpoint
print([x.value for x in EndpointType])
print(Limit(calls=1, renewal_period='minute').model_dump())
print(Endpoint(name='x', endpoint_type='llm/v1/chat', model=EndpointModelInfo(name='m', provider='p'), endpoint_url='/x', limit=None).model_dump())
PY"
```

退出码：`0`

输出：
```
['llm/v1/completions', 'llm/v1/chat', 'llm/v1/embeddings']
{'calls': 1, 'key': None, 'renewal_period': 'minute'}
{'name': 'x', 'endpoint_type': 'llm/v1/chat', 'model': {'name': 'm', 'provider': 'p'}, 'endpoint_url': '/x', 'limit': None}
```

## 原始行 157 · command_execution

命令：
```
/bin/bash -lc 'ruff check mlflow/gateway/config.py mlflow/deployments/interface.py mlflow/deployments/server/config.py mlflow/utils/rest_utils.py mlflow/utils/request_utils.py mlflow/deployments/base.py mlflow/deployments/plugin_manager.py mlflow/deployments/__init__.py mlflow/deployments/databricks/__init__.py mlflow/deployments/mlflow/__init__.py mlflow/tracking/request_header || true'
```

退出码：`0`

输出：
```
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 160 · command_execution

命令：
```
/bin/bash -lc 'ruff check --isolated mlflow/gateway/config.py mlflow/deployments/interface.py mlflow/deployments/server/config.py mlflow/utils/rest_utils.py mlflow/utils/request_utils.py mlflow/deployments/base.py mlflow/deployments/plugin_manager.py mlflow/deployments/__init__.py mlflow/deployments/databricks/__init__.py mlflow/deployments/mlflow/__init__.py mlflow/tracking/request_header'
```

退出码：`1`

输出：
```
E402 Module level import not at top of file
  --> mlflow/gateway/config.py:31:1
   |
29 | _logger = logging.getLogger(__name__)
30 |
31 | from pydantic import SerializeAsAny
   | ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
32 |
33 | if TYPE_CHECKING:
   |

F401 [*] `mlflow.utils.request_utils.augmented_raise_for_status` imported but unused
  --> mlflow/utils/rest_utils.py:39:5
   |
37 |     _TRANSIENT_FAILURE_RESPONSE_CODES,
38 |     _get_http_response_with_retries,
39 |     augmented_raise_for_status,
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^
40 |     cloud_storage_http_request,
41 | )
   |
help: Remove unused import

F401 [*] `mlflow.utils.request_utils.cloud_storage_http_request` imported but unused
  --> mlflow/utils/rest_utils.py:40:5
   |
38 |     _get_http_response_with_retries,
39 |     augmented_raise_for_status,
40 |     cloud_storage_http_request,
   |     ^^^^^^^^^^^^^^^^^^^^^^^^^^
41 | )
   |
help: Remove unused import

Found 3 errors.
[*] 2 fixable with the `--fix` option.
```

## 原始行 163 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"renewal_period\\|calls.*limit\\|Failed to parse the rate limit\" tests/gateway tests/deployments --include='*.py' | head -100
python - <<'PY'
try:
 import limits
 print('limits yes')
except Exception as e: print(type(e).__name__, e)
PY
sed -n '430,560p' tests/gateway/test_gateway_config_parsing.py"
```

退出码：`0`

输出：
```
tests/deployments/databricks/test_databricks.py:441:            config={"rate_limits": [{"calls": 10, "key": "endpoint", "renewal_period": "minute"}]},
ModuleNotFoundError No module named 'limits'
```

## 原始行 166 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/deployments/openai/test_openai.py tests/deployments/test_utils.py tests/deployments/test_cli.py'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 24 items

tests/deployments/openai/test_openai.py [32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[31mF[0m[31m                        [ 37%][0m
tests/deployments/test_utils.py [32m.[0m[32m.[0m[31m                                       [ 45%][0m
tests/deployments/test_cli.py [31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[32m.[0m[31m                              [100%][0m

=================================== FAILURES ===================================
[31m[1m_____________________________ test_predict_openai ______________________________[0m

mock_openai_creds = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_predict_openai[39;49;00m(mock_openai_creds):[90m[39;49;00m
        client = get_deploy_client([33m"[39;49;00m[33mopenai[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        mock_resp = {[90m[39;49;00m
            [33m"[39;49;00m[33mid[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mchatcmpl-abc123[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mobject[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mchat.completion[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcreated[39;49;00m[33m"[39;49;00m: [94m1677858242[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mmodel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mgpt-4o-mini[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33musage[39;49;00m[33m"[39;49;00m: {[90m[39;49;00m
                [33m"[39;49;00m[33mprompt_tokens[39;49;00m[33m"[39;49;00m: [94m13[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mcompletion_tokens[39;49;00m[33m"[39;49;00m: [94m7[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mtotal_tokens[39;49;00m[33m"[39;49;00m: [94m20[39;49;00m,[90m[39;49;00m
            },[90m[39;49;00m
            [33m"[39;49;00m[33mchoices[39;49;00m[33m"[39;49;00m: [[90m[39;49;00m
                {[90m[39;49;00m
                    [33m"[39;49;00m[33mmessage[39;49;00m[33m"[39;49;00m: {[90m[39;49;00m
                        [33m"[39;49;00m[33mrole[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33massistant[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        [33m"[39;49;00m[33mcontent[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m\n[39;49;00m[33m\n[39;49;00m[33mThis is a test![39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    },[90m[39;49;00m
                    [33m"[39;49;00m[33mfinish_reason[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mstop[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    [33m"[39;49;00m[33mindex[39;49;00m[33m"[39;49;00m: [94m0[39;49;00m,[90m[39;49;00m
                }[90m[39;49;00m
            ],[90m[39;49;00m
            [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mContent-Type[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mapplication/json[39;49;00m[33m"[39;49;00m},[90m[39;49;00m
        }[90m[39;49;00m
>       [94mwith[39;49;00m mock.patch([90m[39;49;00m
            [33m"[39;49;00m[33mopenai.OpenAI[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        ) [94mas[39;49;00m mock_client:[90m[39;49;00m

client     = <mlflow.deployments.openai.OpenAIDeploymentClient object at 0x7321b4b718d0>
mock_openai_creds = None
mock_resp  = {'choices': [{'finish_reason': 'stop', 'index': 0, 'message': {'content': '\n\nThis is a test!', 'role': 'assistant'}}], 'created': 1677858242, 'headers': {'Content-Type': 'application/json'}, 'id': 'chatcmpl-abc123', ...}

[1m[31mtests/deployments/openai/test_openai.py[0m:59: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1430: in __enter__
    [0m[96mself[39;49;00m.target = [96mself[39;49;00m.getter()[90m[39;49;00m
                  ^^^^^^^^^^^^^[90m[39;49;00m
        autospec   = None
        kwargs     = {}
        new        = sentinel.DEFAULT
        new_callable = None
        self       = <unittest.mock._patch object at 0x7321b4b71a90>
        spec       = None
        spec_set   = None
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/pkgutil.py[0m:700: in resolve_name
    [0mmod = importlib.import_module(modname)[90m[39;49;00m
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        gd         = {'cln': None, 'obj': None, 'pkg': 'openai'}
        m          = <re.Match object; span=(0, 6), match='openai'>
        modname    = 'openai'
        name       = 'openai'
        parts      = []
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py[0m:126: in import_module
    [0m[94mreturn[39;49;00m _bootstrap._gcd_import(name[level:], package, level)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        level      = 0
        name       = 'openai'
        package    = None
[1m[31m<frozen importlib._bootstrap>[0m:1204: in _gcd_import
    [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
        level      = 0
        name       = 'openai'
        package    = None
[1m[31m<frozen importlib._bootstrap>[0m:1176: in _find_and_load
    [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
        import_    = <function _gcd_import at 0x7322188c7d80>
        module     = <object object at 0x7322188fc050>
        name       = 'openai'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'openai', import_ = <function _gcd_import at 0x7322188c7d80>

>   [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
[1m[31mE   ModuleNotFoundError: No module named 'openai'[0m

import_    = <function _gcd_import at 0x7322188c7d80>
name       = 'openai'
parent     = ''
parent_spec = None
path       = None
spec       = None

[1m[31m<frozen importlib._bootstrap>[0m:1140: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_predict_azure_openai ___________________________[0m

mock_azure_openai_creds = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_predict_azure_openai[39;49;00m(mock_azure_openai_creds):[90m[39;49;00m
        client = get_deploy_client([33m"[39;49;00m[33mopenai[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        mock_resp = {[90m[39;49;00m
            [33m"[39;49;00m[33mid[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mchatcmpl-abc123[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mobject[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mchat.completion[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mcreated[39;49;00m[33m"[39;49;00m: [94m1677858242[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mmodel[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mgpt-4o-mini[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33musage[39;49;00m[33m"[39;49;00m: {[90m[39;49;00m
                [33m"[39;49;00m[33mprompt_tokens[39;49;00m[33m"[39;49;00m: [94m13[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mcompletion_tokens[39;49;00m[33m"[39;49;00m: [94m7[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mtotal_tokens[39;49;00m[33m"[39;49;00m: [94m20[39;49;00m,[90m[39;49;00m
            },[90m[39;49;00m
            [33m"[39;49;00m[33mchoices[39;49;00m[33m"[39;49;00m: [[90m[39;49;00m
                {[90m[39;49;00m
                    [33m"[39;49;00m[33mmessage[39;49;00m[33m"[39;49;00m: {[90m[39;49;00m
                        [33m"[39;49;00m[33mrole[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33massistant[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        [33m"[39;49;00m[33mcontent[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m\n[39;49;00m[33m\n[39;49;00m[33mThis is a test![39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    },[90m[39;49;00m
                    [33m"[39;49;00m[33mfinish_reason[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mstop[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    [33m"[39;49;00m[33mindex[39;49;00m[33m"[39;49;00m: [94m0[39;49;00m,[90m[39;49;00m
                }[90m[39;49;00m
            ],[90m[39;49;00m
            [33m"[39;49;00m[33mheaders[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mContent-Type[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mapplication/json[39;49;00m[33m"[39;49;00m},[90m[39;49;00m
        }[90m[39;49;00m
>       [94mwith[39;49;00m mock.patch([33m"[39;49;00m[33mopenai.AzureOpenAI[39;49;00m[33m"[39;49;00m) [94mas[39;49;00m mock_client:[90m[39;49;00m

client     = <mlflow.deployments.openai.OpenAIDeploymentClient object at 0x7321b4646c50>
mock_azure_openai_creds = None
mock_resp  = {'choices': [{'finish_reason': 'stop', 'index': 0, 'message': {'content': '\n\nThis is a test!', 'role': 'assistant'}}], 'created': 1677858242, 'headers': {'Content-Type': 'application/json'}, 'id': 'chatcmpl-abc123', ...}

[1m[31mtests/deployments/openai/test_openai.py[0m:173: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1430: in __enter__
    [0m[96mself[39;49;00m.target = [96mself[39;49;00m.getter()[90m[39;49;00m
                  ^^^^^^^^^^^^^[90m[39;49;00m
        autospec   = None
        kwargs     = {}
        new        = sentinel.DEFAULT
        new_callable = None
        self       = <unittest.mock._patch object at 0x7321b4646ed0>
        spec       = None
        spec_set   = None
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/pkgutil.py[0m:700: in resolve_name
    [0mmod = importlib.import_module(modname)[90m[39;49;00m
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        gd         = {'cln': None, 'obj': None, 'pkg': 'openai'}
        m          = <re.Match object; span=(0, 6), match='openai'>
        modname    = 'openai'
        name       = 'openai'
        parts      = []
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py[0m:126: in import_module
    [0m[94mreturn[39;49;00m _bootstrap._gcd_import(name[level:], package, level)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        level      = 0
        name       = 'openai'
        package    = None
[1m[31m<frozen importlib._bootstrap>[0m:1204: in _gcd_import
    [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
        level      = 0
        name       = 'openai'
        package    = None
[1m[31m<frozen importlib._bootstrap>[0m:1176: in _find_and_load
    [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
        import_    = <function _gcd_import at 0x7322188c7d80>
        module     = <object object at 0x7322188fc050>
        name       = 'openai'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'openai', import_ = <function _gcd_import at 0x7322188c7d80>

>   [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
[1m[31mE   ModuleNotFoundError: No module named 'openai'[0m

import_    = <function _gcd_import at 0x7322188c7d80>
name       = 'openai'
parent     = ''
parent_spec = None
path       = None
spec       = None

[1m[31m<frozen importlib._bootstrap>[0m:1140: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m____________________________ test_openai_exception _____________________________[0m

mock_openai_creds = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_openai_exception[39;49;00m(mock_openai_creds):[90m[39;49;00m
        client = get_deploy_client([33m"[39;49;00m[33mopenai[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>       [94mwith[39;49;00m mock.patch([33m"[39;49;00m[33mopenai.OpenAI[39;49;00m[33m"[39;49;00m) [94mas[39;49;00m mock_client:[90m[39;49;00m

client     = <mlflow.deployments.openai.OpenAIDeploymentClient object at 0x7321b4942690>
mock_openai_creds = None

[1m[31mtests/deployments/openai/test_openai.py[0m:205: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py[0m:1430: in __enter__
    [0m[96mself[39;49;00m.target = [96mself[39;49;00m.getter()[90m[39;49;00m
                  ^^^^^^^^^^^^^[90m[39;49;00m
        autospec   = None
        kwargs     = {}
        new        = sentinel.DEFAULT
        new_callable = None
        self       = <unittest.mock._patch object at 0x7321b49436d0>
        spec       = None
        spec_set   = None
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/pkgutil.py[0m:700: in resolve_name
    [0mmod = importlib.import_module(modname)[90m[39;49;00m
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        gd         = {'cln': None, 'obj': None, 'pkg': 'openai'}
        m          = <re.Match object; span=(0, 6), match='openai'>
        modname    = 'openai'
        name       = 'openai'
        parts      = []
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py[0m:126: in import_module
    [0m[94mreturn[39;49;00m _bootstrap._gcd_import(name[level:], package, level)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        level      = 0
        name       = 'openai'
        package    = None
[1m[31m<frozen importlib._bootstrap>[0m:1204: in _gcd_import
    [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
        level      = 0
        name       = 'openai'
        package    = None
[1m[31m<frozen importlib._bootstrap>[0m:1176: in _find_and_load
    [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
        import_    = <function _gcd_import at 0x7322188c7d80>
        module     = <object object at 0x7322188fc050>
        name       = 'openai'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'openai', import_ = <function _gcd_import at 0x7322188c7d80>

>   [0m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[04m[91m?[39;49;00m[90m[39;49;00m
[1m[31mE   ModuleNotFoundError: No module named 'openai'[0m

import_    = <function _gcd_import at 0x7322188c7d80>
name       = 'openai'
parent     = ''
parent_spec = None
path       = None
spec       = None

[1m[31m<frozen importlib._bootstrap>[0m:1140: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________________ test_create __________________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_create[39;49;00m():[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.create_deployment,[90m[39;49;00m
            [[33m"[39;49;00m[33m--flavor[39;49;00m[33m"[39;49;00m, f_flavor, [33m"[39;49;00m[33m--model-uri[39;49;00m[33m"[39;49;00m, f_model_uri, [33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target, [33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name],[90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [33mf[39;49;00m[33m"[39;49;00m[33m{[39;49;00mf_flavor[33m}[39;49;00m[33m deployment [39;49;00m[33m{[39;49;00mf_name[33m}[39;49;00m[33m is created[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert 'fake_flavor deployment fake_deployment_name is created' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:23: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________________ test_update __________________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_update[39;49;00m():[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.update_deployment,[90m[39;49;00m
            [[33m"[39;49;00m[33m--flavor[39;49;00m[33m"[39;49;00m, f_flavor, [33m"[39;49;00m[33m--model-uri[39;49;00m[33m"[39;49;00m, f_model_uri, [33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target, [33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name],[90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [33mf[39;49;00m[33m"[39;49;00m[33mDeployment [39;49;00m[33m{[39;49;00mf_name[33m}[39;49;00m[33m is updated (with flavor [39;49;00m[33m{[39;49;00mf_flavor[33m}[39;49;00m[33m)[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert 'Deployment fake_deployment_name is updated (with flavor fake_flavor)' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:35: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________________ test_delete __________________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_delete[39;49;00m():[90m[39;49;00m
        res = runner.invoke(cli.delete_deployment, [[33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name, [33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target])[90m[39;49;00m
>       [94massert[39;49;00m [33mf[39;49;00m[33m"[39;49;00m[33mDeployment [39;49;00m[33m{[39;49;00mf_name[33m}[39;49;00m[33m is deleted[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert 'Deployment fake_deployment_name is deleted' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:40: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m____________________________ test_update_no_flavor _____________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_update_no_flavor[39;49;00m():[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.update_deployment, [[33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name, [33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target, [33m"[39;49;00m[33m-m[39;49;00m[33m"[39;49;00m, f_model_uri][90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [33mf[39;49;00m[33m"[39;49;00m[33mDeployment [39;49;00m[33m{[39;49;00mf_name[33m}[39;49;00m[33m is updated (with flavor None)[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert 'Deployment fake_deployment_name is updated (with flavor None)' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:47: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________________ test_list ___________________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_list[39;49;00m():[90m[39;49;00m
        res = runner.invoke(cli.list_deployment, [[33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target])[90m[39;49;00m
>       [94massert[39;49;00m [33mf[39;49;00m[33m"[39;49;00m[33m[[39;49;00m[33m{{[39;49;00m[33m'[39;49;00m[33mname[39;49;00m[33m'[39;49;00m[33m: [39;49;00m[33m'[39;49;00m[33m{[39;49;00mf_name[33m}[39;49;00m[33m'[39;49;00m[33m}}[39;49;00m[33m][39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert "[{'name': 'fake_deployment_name'}]" in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:52: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_create_deployment_with_custom_args ____________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_create_deployment_with_custom_args[39;49;00m():[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.create_deployment,[90m[39;49;00m
            [[90m[39;49;00m
                [33m"[39;49;00m[33m--model-uri[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                f_model_uri,[90m[39;49;00m
                [33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                f_target,[90m[39;49;00m
                [33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                f_name,[90m[39;49;00m
                [33m"[39;49;00m[33m-C[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                [33m"[39;49;00m[33mraiseError=True[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            ],[90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [96misinstance[39;49;00m(res.exception, [96mRuntimeError[39;49;00m)[90m[39;49;00m
[1m[31mE       assert False[0m
[1m[31mE        +  where False = isinstance(MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketar...lugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'), RuntimeError)[0m
[1m[31mE        +    where MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketar...lugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).') = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.exception[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:69: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_delete_deployment_with_custom_args ____________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_delete_deployment_with_custom_args[39;49;00m():[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.delete_deployment,[90m[39;49;00m
            [[33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target, [33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name, [33m"[39;49;00m[33m-C[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mraiseError=True[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [96misinstance[39;49;00m(res.exception, [96mRuntimeError[39;49;00m)[90m[39;49;00m
[1m[31mE       assert False[0m
[1m[31mE        +  where False = isinstance(MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketar...lugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).'), RuntimeError)[0m
[1m[31mE        +    where MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to "faketar...lugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).') = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.exception[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:77: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________________________ test_get ___________________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get[39;49;00m():[90m[39;49;00m
        res = runner.invoke(cli.get_deployment, [[33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name, [33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target])[90m[39;49;00m
>       [94massert[39;49;00m [33m"[39;49;00m[33mkey1: val1[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert 'key1: val1' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:82: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________________ test_predict _________________________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-5/test_predict0')

    [0m[37m@pytest[39;49;00m.mark.skipif([90m[39;49;00m
        [33m"[39;49;00m[33mMLFLOW_SKINNY[39;49;00m[33m"[39;49;00m [95min[39;49;00m os.environ,[90m[39;49;00m
        reason=[33m"[39;49;00m[33mSkinny Client does not support predict due to the pandas dependency[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_predict[39;49;00m(tmp_path):[90m[39;49;00m
        temp_input_file_path = tmp_path.joinpath([33m"[39;49;00m[33minput.json[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        temp_input_file_path.write_text([33m'[39;49;00m[33m{[39;49;00m[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m[33m: [5000]}[39;49;00m[33m'[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        temp_output_file_path = tmp_path.joinpath([33m"[39;49;00m[33moutput.json[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.predict, [[33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target, [33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name, [33m"[39;49;00m[33m--input-path[39;49;00m[33m"[39;49;00m, temp_input_file_path][90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [33m'[39;49;00m[33m{[39;49;00m[33m"[39;49;00m[33mpredictions[39;49;00m[33m"[39;49;00m[33m: [1, 2, 3]}[39;49;00m[33m'[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert '{"predictions": [1, 2, 3]}' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>
temp_input_file_path = PosixPath('/tmp/pytest-of-root/pytest-5/test_predict0/input.json')
temp_output_file_path = PosixPath('/tmp/pytest-of-root/pytest-5/test_predict0/output.json')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-5/test_predict0')

[1m[31mtests/deployments/test_cli.py[0m:98: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________________ test_target_help _______________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_target_help[39;49;00m():[90m[39;49;00m
        res = runner.invoke(cli.target_help, [[33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target])[90m[39;49;00m
>       [94massert[39;49;00m [33m"[39;49;00m[33mTarget help is called[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert 'Target help is called' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:119: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m________________________________ test_run_local ________________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_run_local[39;49;00m():[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.run_local, [[33m"[39;49;00m[33m-f[39;49;00m[33m"[39;49;00m, f_flavor, [33m"[39;49;00m[33m-m[39;49;00m[33m"[39;49;00m, f_model_uri, [33m"[39;49;00m[33m-t[39;49;00m[33m"[39;49;00m, f_target, [33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name][90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [33mf[39;49;00m[33m"[39;49;00m[33mDeployed locally at the key [39;49;00m[33m{[39;49;00mf_name[33m}[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert 'Deployed locally at the key fake_deployment_name' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>

[1m[31mtests/deployments/test_cli.py[0m:126: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________________ test_explain _________________________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-5/test_explain0')

    [0m[37m@pytest[39;49;00m.mark.skipif([90m[39;49;00m
        [33m"[39;49;00m[33mMLFLOW_SKINNY[39;49;00m[33m"[39;49;00m [95min[39;49;00m os.environ,[90m[39;49;00m
        reason=[33m"[39;49;00m[33mSkinny Client does not support explain due to the pandas dependency[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_explain[39;49;00m(tmp_path):[90m[39;49;00m
        temp_input_file_path = tmp_path.joinpath([33m"[39;49;00m[33minput.json[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        temp_input_file_path.write_text([33m'[39;49;00m[33m{[39;49;00m[33m"[39;49;00m[33mdata[39;49;00m[33m"[39;49;00m[33m: [5000]}[39;49;00m[33m'[39;49;00m)[90m[39;49;00m
        res = runner.invoke([90m[39;49;00m
            cli.explain, [[33m"[39;49;00m[33m--target[39;49;00m[33m"[39;49;00m, f_target, [33m"[39;49;00m[33m--name[39;49;00m[33m"[39;49;00m, f_name, [33m"[39;49;00m[33m--input-path[39;49;00m[33m"[39;49;00m, temp_input_file_path][90m[39;49;00m
        )[90m[39;49;00m
>       [94massert[39;49;00m [33m"[39;49;00m[33m1[39;49;00m[33m"[39;49;00m [95min[39;49;00m res.stdout[90m[39;49;00m
[1m[31mE       assert '1' in ''[0m
[1m[31mE        +  where '' = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>.stdout[0m

res        = <Result MlflowException('No plugin found for managing model deployments to "faketarget". In order to deploy models to ...ugin from https://mlflow.org/docs/latest/plugins.html#community-plugins using your package manager (pip, conda etc).')>
temp_input_file_path = PosixPath('/tmp/pytest-of-root/pytest-5/test_explain0/input.json')
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-5/test_explain0')

[1m[31mtests/deployments/test_cli.py[0m:141: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 18:32:52 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================

(10 durations < 0.005s hidden.  Use -vv to show these durations.)
========================= command to run failed tests ==========================
pytest 'tests/deployments/openai/test_openai.py::test_predict_openai' 'tests/deployments/openai/test_openai.py::test_predict_azure_openai' 'tests/deployments/openai/test_openai.py::test_openai_exception' 'tests/deployments/test_cli.py::test_create' 'tests/deployments/test_cli.py::test_update' 'tests/deployments/test_cli.py::test_delete' 'tests/deployments/test_cli.py::test_update_no_flavor' 'tests/deployments/test_cli.py::test_list' 'tests/deployments/test_cli.py::test_create_deployment_with_custom_args' 'tests/deployments/test_cli.py::test_delete_deployment_with_custom_args' 'tests/deployments/test_cli.py::test_get' 'tests/deployments/test_cli.py::test_predict' 'tests/deployments/test_cli.py::test_target_help' 'tests/deployments/test_cli.py::test_run_local' 'tests/deployments/test_cli.py::test_explain'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/openai/test_openai.py::[1mtest_predict_openai[0m - ModuleNotFoundError: No module named 'openai'
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/openai/test_openai.py::[1mtest_predict_azure_openai[0m - ModuleNotFoundError: No module named 'openai'
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/openai/test_openai.py::[1mtest_openai_exception[0m - ModuleNotFoundError: No module named 'openai'
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_create[0m - assert 'fake_flavor deployment fake_deployment_name is created' in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_update[0m - assert 'Deployment fake_deployment_name is updated (with flavor fake_flavor...
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_delete[0m - assert 'Deployment fake_deployment_name is deleted' in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_update_no_flavor[0m - assert 'Deployment fake_deployment_name is updated (with flavor None)' in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_list[0m - assert "[{'name': 'fake_deployment_name'}]" in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_create_deployment_with_custom_args[0m - assert False
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_delete_deployment_with_custom_args[0m - assert False
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_get[0m - assert 'key1: val1' in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_predict[0m - assert '{"predictions": [1, 2, 3]}' in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_target_help[0m - assert 'Target help is called' in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_run_local[0m - assert 'Deployed locally at the key fake_deployment_name' in ''
[31mFAILED | MEM 12.4/46.9 GB | DISK 832.7/915.7 GB[0m tests/deployments/test_cli.py::[1mtest_explain[0m - assert '1' in ''
[31m========================= [31m[1m15 failed[0m, [32m9 passed[0m[31m in 0.36s[0m[31m =========================[0m
```

## 原始行 171 · error

```
{
  "id": "item_102",
  "type": "error",
  "message": "Falling back from WebSockets to HTTPS transport. stream disconnected before completion: tls handshake eof"
}
```

## 原始行 176 · file_change

```
{
  "id": "item_105",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracking/request_header/registry.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 178 · command_execution

命令：
```
/bin/bash -lc "PYTHONPATH=/testbed/tests/resources/mlflow-test-plugin python - <<'PY'
from mlflow.deployments.interface import plugin_store, get_deploy_client
plugin_store.register('faketarget', 'mlflow_test_plugin.fake_deployment_plugin')
for target in ('faketarget', 'faketarget:/suffix', 'faketarget://suffix'):
 c = get_deploy_client(target)
 print(target, type(c).__name__, c.target_uri)
PY
pytest -q tests/tracking/request_header/test_registry.py -k 'resolve_request_headers' tests/utils/test_request_utils.py tests/gateway/test_gateway_config_parsing.py tests/deployments/test_interface.py"
```

退出码：`0`

输出：
```
faketarget PluginDeploymentClient faketarget
faketarget:/suffix PluginDeploymentClient faketarget:/suffix
faketarget://suffix PluginDeploymentClient faketarget://suffix
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 55 items / 53 deselected / 2 selected

tests/tracking/request_header/test_registry.py [32m.[0m[32m.[0m[32m                        [100%][0m

============================= slowest 10 durations =============================

(6 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m======================= [32m[1m2 passed[0m, [33m53 deselected[0m[32m in 0.06s[0m[32m =======================[0m
```

## 原始行 181 · command_execution

命令：
```
/bin/bash -lc "git status --short
python - <<'PY'
import inspect
from mlflow.deployments.interface import get_deploy_client
from mlflow.utils.rest_utils import http_request
print(inspect.signature(get_deploy_client))
print(inspect.signature(http_request))
PY"
```

退出码：`0`

输出：
```
 M mlflow/deployments/__init__.py
 M mlflow/deployments/base.py
 M mlflow/deployments/databricks/__init__.py
 M mlflow/deployments/interface.py
 M mlflow/deployments/mlflow/__init__.py
 M mlflow/deployments/plugin_manager.py
 M mlflow/deployments/server/config.py
 M mlflow/gateway/config.py
 M mlflow/tracking/request_header/databricks_request_header_provider.py
 M mlflow/tracking/request_header/default_request_header_provider.py
 M mlflow/tracking/request_header/registry.py
 M mlflow/utils/request_utils.py
 M mlflow/utils/rest_utils.py
(target_uri=None)
(host_creds, endpoint, method, max_retries=None, backoff_factor=None, backoff_jitter=None, extra_headers=None, retry_codes=frozenset({504, 429, 500, 502, 503, 408}), timeout=None, raise_on_status=True, respect_retry_after_header=None, retry_timeout_seconds=None, **kwargs)
```

## 原始行 186 · file_change

```
{
  "id": "item_112",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/utils/rest_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 188 · agent_message

```
The built-in Databricks deployment suite and all available standard/SDK HTTP tests are passing. I’ve also tightened SDK retry classification so base Databricks errors use their MLflow error code rather than being treated as generic 500s; the final pass now covers models, discovery, retry sessions, headers, and deployment consumers together.
```

## 原始行 190 · command_execution

命令：
```
/bin/bash -lc "pytest -q tests/deployments/test_interface.py tests/deployments/databricks/test_databricks.py tests/gateway/test_gateway_config_parsing.py tests/utils/test_rest_utils.py tests/utils/test_request_utils.py tests/tracking/request_header/test_default_request_header_provider.py tests/tracking/request_header/test_databricks_request_header_provider.py tests/tracking/request_header/test_registry.py -k 'not aws_sigv4 and not test_http_request_request_headers and not test_run_context_provider_registry_with_installed_plugin'"
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 145 items / 5 deselected / 140 selected

tests/deployments/test_interface.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                 [  2%][0m
tests/deployments/databricks/test_databricks.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m  [ 19%][0m
tests/gateway/test_gateway_config_parsing.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m     [ 35%][0m
tests/utils/test_rest_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m [ 65%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                                                                     [ 67%][0m
tests/utils/test_request_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                    [ 81%][0m
tests/tracking/request_header/test_default_request_header_provider.py [32m.[0m[32m.[0m[33m [ 82%]
[0m[33m                                                                         [ 82%][0m
tests/tracking/request_header/test_databricks_request_header_provider.py [32m.[0m[33m [ 83%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                                                          [ 94%][0m
tests/tracking/request_header/test_registry.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                  [100%][0m

[33m=============================== warnings summary ===============================[0m
tests/deployments/databricks/test_databricks.py::test_create_endpoint
  /testbed/mlflow/deployments/databricks/__init__.py:493: UserWarning: Passing 'name', 'config', and 'route_optimized' as separate parameters is deprecated. Please pass the full API request payload as a single dictionary in the 'config' parameter.
    warnings.warn("\n".join(warnings_list), UserWarning)

tests/deployments/databricks/test_databricks.py::test_update_endpoint
  /testbed/tests/deployments/databricks/test_databricks.py:366: FutureWarning: ``mlflow.deployments.databricks.DatabricksDeploymentClient.update_endpoint`` is deprecated. This method will be removed in a future release. Use ``update_endpoint_config, update_endpoint_tags, update_endpoint_rate_limits, or update_endpoint_ai_gateway`` instead.
    resp = client.update_endpoint(

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
13.45s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_max_retries_exceeded
0.98s call     tests/deployments/databricks/test_databricks.py::test_create_endpoint
0.21s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_on_transient_errors
0.20s call     tests/utils/test_rest_utils.py::test_databricks_sdk_retry_timeout_exceeded
0.16s call     tests/utils/test_request_utils.py::test_request_utils_does_not_import_mlflow
0.04s call     tests/gateway/test_gateway_config_parsing.py::test_api_key_parsing_file
0.02s call     tests/gateway/test_gateway_config_parsing.py::test_route_configuration_parsing
0.01s teardown tests/tracking/request_header/test_registry.py::test_resolve_request_headers
0.01s call     tests/utils/test_rest_utils.py::test_http_request_with_auth
0.01s teardown tests/tracking/request_header/test_registry.py::test_registry_instance_loads_entrypoints

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                              | Duration | Tests | Min    | Max     | Avg    |
| ---- | ------------------------------------------------- | -------- | ----- | ------ | ------- | ------ |
| 1    | `tests/utils/test_rest_utils.py`                  | 14.17s   | 45    | 0.001s | 13.453s | 0.315s |
| 2    | `tests/deployments/databricks/test_databricks.py` | 1.15s    | 23    | 0.003s | 0.980s  | 0.050s |

::endgroup::

[33m========== [32m138 passed[0m, [33m[1m2 skipped[0m, [33m[1m5 deselected[0m, [33m[1m2 warnings[0m[33m in 16.25s[0m[33m ===========[0m
```

## 原始行 192 · agent_message

```
Implemented all requested MLflow deployment and gateway interfaces:

- Gateway endpoint types and `Limit` model
- Deployment-client discovery and target URI parsing
- Gateway `Endpoint` response model
- Standard and Databricks SDK HTTP request handling
- Authentication, headers, retries, backoff, timeout, TLS, and error conversion
- Required supporting deployment and request-header helpers

Validation: 138 focused tests passed, 2 skipped. Five optional-dependency tests were deselected because the environment lacks their test-only packages.
```
