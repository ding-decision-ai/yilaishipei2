# Codex baseline: astropy__astropy.b0db0daa.test_vo.8fd473ce.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the existing VOTable tree implementation and its focused tests first, then patch only the missing behavior and run the relevant pytest subset.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "rg -n \"class ParamRef|def get_ref\\(|class TableElement|def to_table\\(|class VOTableFile|def __repr__\\(|def get_first_table\\(|def iter_values\\(\" astropy/io/votable/tree.py && rg -n \"get_first_table|iter_values|ParamRef|to_table\\(\" astropy/io/votable/tests astropy/table/tests 2>/dev/null"
```

退出码：`127`

输出：
```
/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
`rg` is not available in this checkout, so I’m using targeted `grep`/`find` queries instead. I’ll also check repository guidance before editing.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "find .. -name AGENTS.md -print

grep -nE \"class ParamRef|def get_ref\\(|class TableElement|def to_table\\(|class VOTableFile|def __repr__\\(|def get_first_table\\(|def iter_values\\(\" astropy/io/votable/tree.py

grep -RInE \"get_first_table|iter_values|ParamRef|to_table\\(\" astropy/io/votable/tests astropy/table/tests 2>/dev/null | head -300"
```

退出码：`0`

输出：
```
582:    def __repr__(self):
991:    def __repr__(self):
2245:    def get_ref(self):
2256:class ParamRef(SimpleElement, _UtypeProperty, _UcdProperty):
2373:    def __repr__(self):
2478:class TableElement(
2550:    def __repr__(self):
3858:    def __repr__(self):
4138:class VOTableFile(Element, _IDProperty, _DescriptionProperty):
astropy/io/votable/tests/test_table.py:66:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:67:    astropy_table = table.to_table()
astropy/io/votable/tests/test_table.py:73:    t = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:172:    table = votable.get_first_table().to_table(use_names_over_ids=True)
astropy/io/votable/tests/test_table.py:199:    table = votable.get_first_table().to_table(use_names_over_ids=False)
astropy/io/votable/tests/test_table.py:237:    table = parse(fpath).get_first_table().to_table()
astropy/io/votable/tests/test_table.py:447:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:448:    table.to_table()
astropy/io/votable/tests/test_table.py:453:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:472:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:473:    astropy_table = table.to_table()
astropy/io/votable/tests/test_table.py:530:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:531:    astropy_table = table.to_table()
astropy/io/votable/tests/test_table.py:544:    table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:545:    astropy_table2 = table2.to_table()
astropy/io/votable/tests/test_table.py:592:        table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:643:    table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:666:    table = votable.get_first_table()
astropy/io/votable/tests/test_table.py:683:    table2 = votable2.get_first_table()
astropy/io/votable/tests/test_table.py:750:        field = votable2.get_first_table().fields[0]
astropy/io/votable/tests/test_table.py:795:        table2 = votable2.get_first_table()
astropy/io/votable/tests/test_converter.py:331:    tt = table.to_table()
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "sed -n '2160,2315p' astropy/io/votable/tree.py
sed -n '2470,2675p' astropy/io/votable/tree.py
sed -n '4070,4380p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
        at http://www.ivoa.net/rdf/timescale).
        """
        return self._timescale

    @timescale.setter
    def timescale(self, timescale):
        self._timescale = timescale

    @timescale.deleter
    def timescale(self):
        self._timescale = None

    @property
    def refposition(self):
        """
        [*required*] String specifying the reference position. Values
        should be taken from the IVOA refposition vocabulary (documented
        at http://www.ivoa.net/rdf/refposition).
        """
        return self._refposition

    @refposition.setter
    def refposition(self, refposition):
        self._refposition = refposition

    @refposition.deleter
    def refposition(self):
        self._refposition = None


class FieldRef(SimpleElement, _UtypeProperty, _UcdProperty):
    """
    FIELDref_ element: used inside of GROUP_ elements to refer to remote FIELD_ elements.
    """

    _attr_list_11 = ["ref"]
    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
    _element_name = "FIELDref"
    _utype_in_v1_2 = True
    _ucd_in_v1_2 = True

    def __init__(
        self, table, ref, ucd=None, utype=None, config=None, pos=None, **extra
    ):
        """
        *table* is the :class:`TableElement` object that this :class:`FieldRef`
        is a member of.

        *ref* is the ID to reference a :class:`Field` object defined
        elsewhere.
        """
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        SimpleElement.__init__(self)
        self._table = table
        self.ref = ref
        self.ucd = ucd
        self.utype = utype

        if config.get("version_1_2_or_later"):
            self._attr_list = self._attr_list_12
        else:
            self._attr_list = self._attr_list_11
            if ucd is not None:
                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
            if utype is not None:
                warn_unknown_attrs(self._element_name, ["utype"], config, pos)

    @property
    def ref(self):
        """The ID_ of the FIELD_ that this FIELDref_ references."""
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    def get_ref(self):
        """
        Lookup the :class:`Field` instance that this :class:`FieldRef`
        references.
        """
        for field in self._table._votable.iter_fields_and_params():
            if isinstance(field, Field) and field.ID == self.ref:
                return field
        vo_raise(KeyError, f"No field named '{self.ref}'", self._config, self._pos)


class ParamRef(SimpleElement, _UtypeProperty, _UcdProperty):
    """
    PARAMref_ element: used inside of GROUP_ elements to refer to remote PARAM_ elements.

    The keyword arguments correspond to setting members of the same
    name, documented below.

    It contains the following publicly-accessible members:

      *ref*: An XML ID referring to a <PARAM> element.
    """

    _attr_list_11 = ["ref"]
    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
    _element_name = "PARAMref"
    _utype_in_v1_2 = True
    _ucd_in_v1_2 = True

    def __init__(self, table, ref, ucd=None, utype=None, config=None, pos=None):
        if config is None:
            config = {}

        self._config = config
        self._pos = pos

        Element.__init__(self)
        self._table = table
        self.ref = ref
        self.ucd = ucd
        self.utype = utype

        if config.get("version_1_2_or_later"):
            self._attr_list = self._attr_list_12
        else:
            self._attr_list = self._attr_list_11
            if ucd is not None:
                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
            if utype is not None:
                warn_unknown_attrs(self._element_name, ["utype"], config, pos)

    @property
    def ref(self):
        """The ID_ of the PARAM_ that this PARAMref_ references."""
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None







        this :class:`Group`.
        """
        for entry in self.entries:
            if isinstance(entry, Group):
                yield entry
                yield from entry.iter_groups()


class TableElement(
    Element, _IDProperty, _NameProperty, _UcdProperty, _DescriptionProperty
):
    """
    TABLE_ element: optionally contains data.

    It contains the following publicly-accessible and mutable
    attribute:

        *array*: A Numpy masked array of the data itself, where each
        row is a row of votable data, and columns are named and typed
        based on the <FIELD> elements of the table.  The mask is
        parallel to the data array, except for variable-length fields.
        For those fields, the numpy array's column type is "object"
        (``"O"``), and another masked array is stored there.

    If the TableElement contains no data, (for example, its enclosing
    :class:`Resource` has :attr:`~Resource.type` == 'meta') *array*
    will have zero-length.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    def __init__(
        self,
        votable,
        ID=None,
        name=None,
        ref=None,
        ucd=None,
        utype=None,
        nrows=None,
        id=None,
        config=None,
        pos=None,
        **extra,
    ):
        self._config = _attach_default_config(votable, config)
        self._pos = pos
        self._empty = False

        Element.__init__(self)
        self._votable = votable

        self.ID = resolve_id(ID, id, self._config, pos) or xmlutil.fix_id(
            name, self._config, pos
        )
        self.name = name
        xmlutil.check_id(ref, "ref", self._config, pos)
        self._ref = ref
        self.ucd = ucd
        self.utype = utype
        if nrows is not None:
            nrows = int(nrows)
            if nrows < 0:
                raise ValueError("'nrows' cannot be negative.")
        self._nrows = nrows
        self.description = None
        self.format = "tabledata"

        self._fields = HomogeneousList(Field)
        self._all_fields = HomogeneousList(Field)
        self._params = HomogeneousList(Param)
        self._groups = HomogeneousList(Group)
        self._links = HomogeneousList(Link)
        self._infos = HomogeneousList(Info)

        self.array = ma.array([])

        warn_unknown_attrs("TABLE", extra.keys(), self._config, pos)

    def __repr__(self):
        s = repr(self.to_table())
        if s.startswith("<Table"):
            s = "<VO" + s[1:]
        return s

    def __bytes__(self):
        return bytes(self.to_table())

    def __str__(self):
        return str(self.to_table())

    @property
    def ref(self):
        return self._ref

    @ref.setter
    def ref(self, ref):
        """
        Refer to another TABLE, previously defined, by the *ref* ID_
        for all metadata (FIELD_, PARAM_ etc.) information.
        """
        # When the ref changes, we want to verify that it will work
        # by actually going and looking for the referenced table.
        # If found, set a bunch of properties in this table based
        # on the other one.
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        if ref is not None:
            try:
                table = self._votable.get_table_by_id(ref, before=self)
            except KeyError:
                warn_or_raise(W43, W43, ("TABLE", self.ref), self._config, self._pos)
                ref = None
            else:
                self._fields = table.fields
                self._all_fields = table.all_fields
                self._params = table.params
                self._groups = table.groups
                self._links = table.links
        else:
            del self._fields[:]
            del self._all_fields[:]
            del self._params[:]
            del self._groups[:]
            del self._links[:]
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def format(self):
        """The serialization format of the table [*required*].

        Must be one of:

          'tabledata' (TABLEDATA_), 'binary' (BINARY_), 'binary2' (BINARY2_)
          'fits' (FITS_).

        Note that the 'fits' format, since it requires an external
        file, can not be written out.  Any file read in with 'fits'
        format will be read out, by default, in 'tabledata' format.

        See :ref:`astropy:votable-serialization`.
        """
        return self._format

    @format.setter
    def format(self, format):
        format = format.lower()
        if format == "fits":
            vo_raise(
                NotImplementedError,
                "fits format can not be written out, only read.",
                self._config,
                self._pos,
            )
        if format == "binary2":
            if not self._config.get("version_1_3_or_later"):
                vo_raise(
                    W37,
                    "binary2 only supported in votable 1.3 or later",
                    self._config,
                    self._pos,
                )
        elif format not in ("tabledata", "binary"):
            vo_raise(W37, f"Invalid format '{format}'", self._config, self._pos)
        self._format = format

    @property
    def nrows(self):
        """
        [*immutable*] The number of rows in the table, as specified in
        the XML file.
        """
        return self._nrows

    @property
    def fields(self):
        """
        A list of :class:`Field` objects describing the types of each
        of the data columns.
        """
        return self._fields

    @property
    def all_fields(self):
        """
        A list of :class:`Field` objects describing the types of each
        of the data columns. Contrary to ``fields``, this property should
        list every field that's available on disk, including deselected columns.
        """
        # since we support extending self.fields directly via list.extend
        # and list.append, self._all_fields may go out of sync.
        # To remedy this issue, we sync back the public property upon access.
        for field in self._fields:
            if field not in self._all_fields:
                self._all_fields.append(field)

        return self._all_fields

    @property
    def params(self):
        """
        A list of parameters (constant-valued columns) for the
                element_sets.append(self.groups)

            for element_set in element_sets:
                for element in element_set:
                    element.to_xml(w, **kwargs)

            # The mivot_block should be before the table
            for elm in self.resources:
                if elm.type == "meta" and elm.mivot_block is not None:
                    elm.to_xml(w, **kwargs)

            for elm in self.tables:
                elm.to_xml(w, **kwargs)

            for elm in self.resources:
                if elm.type != "meta":
                    elm.to_xml(w, **kwargs)

    def iter_tables(self):
        """
        Recursively iterates over all tables in the resource and
        nested resources.
        """
        yield from self.tables
        for resource in self.resources:
            yield from resource.iter_tables()

    def iter_fields_and_params(self):
        """
        Recursively iterates over all FIELD_ and PARAM_ elements in
        the resource, its tables and nested resources.
        """
        yield from self.params
        for table in self.tables:
            yield from table.iter_fields_and_params()
        for resource in self.resources:
            yield from resource.iter_fields_and_params()

    def iter_coosys(self):
        """
        Recursively iterates over all the COOSYS_ elements in the
        resource and nested resources.
        """
        yield from self.coordinate_systems
        for resource in self.resources:
            yield from resource.iter_coosys()

    def iter_timesys(self):
        """
        Recursively iterates over all the TIMESYS_ elements in the
        resource and nested resources.
        """
        yield from self.time_systems
        for resource in self.resources:
            yield from resource.iter_timesys()

    def iter_info(self):
        """
        Recursively iterates over all the INFO_ elements in the
        resource and nested resources.
        """
        yield from self.infos
        for table in self.tables:
            yield from table.iter_info()
        for resource in self.resources:
            yield from resource.iter_info()


class VOTableFile(Element, _IDProperty, _DescriptionProperty):
    """
    VOTABLE_ element: represents an entire file.

    The keyword arguments correspond to setting members of the same
    name, documented below.

    *version* is settable at construction time only, since conformance
    tests for building the rest of the structure depend on it.
    """

    def __init__(self, ID=None, id=None, config=None, pos=None, version="1.4"):
        self._config = config.copy() if config is not None else {}

        # Version setter forces the associated version config settings to
        # be calculated.
        self.version = version
        self._pos = pos

        Element.__init__(self)
        self.ID = resolve_id(ID, id, config, pos)
        self.description = None

        self._coordinate_systems = HomogeneousList(CooSys)
        self._time_systems = HomogeneousList(TimeSys)
        self._params = HomogeneousList(Param)
        self._infos = HomogeneousList(Info)
        self._resources = HomogeneousList(Resource)
        self._groups = HomogeneousList(Group)





    @property
    def config(self):
        """
        Configuration used to construct this object. Will always include the
        version check values.
        """
        return self._config

    @property
    def version(self):
        """
        The version of the VOTable specification that the file uses.
        """
        return self._version

    @version.setter
    def version(self, version):
        version = str(version)
        if version not in self._version_namespace_map:
            allowed_from_map = "', '".join(self._version_namespace_map)
            raise ValueError(
                f"astropy.io.votable version should be in ('{allowed_from_map}')."
            )
        self._version = version
        # Force config update.
        self._config.update(self._get_version_checks())
        self._config["version"] = version

    @property
    def coordinate_systems(self):
        """
        A list of coordinate system descriptions for the file.  Must
        contain only `CooSys` objects.
        """
        return self._coordinate_systems

    @property
    def time_systems(self):
        """
        A list of time system descriptions for the file.  Must
        contain only `TimeSys` objects.
        """
        return self._time_systems

    @property
    def params(self):
        """
        A list of parameters (constant-valued columns) that apply to
        the entire file.  Must contain only `Param` objects.
        """
        return self._params

    @property
    def infos(self):
        """
        A list of informational parameters (key-value pairs) for the
        entire file.  Must only contain `Info` objects.
        """
        return self._infos

    @property
    def resources(self):
        """
        A list of resources, in the order they appear in the file.
        Must only contain `Resource` objects.
        """
        return self._resources

    @property
    def groups(self):
        """
        A list of groups, in the order they appear in the file.  Only
        supported as a child of the VOTABLE element in VOTable 1.2 or
        later.
        """
        return self._groups

    def _add_param(self, iterator, tag, data, config, pos):
        param = Param(self, config=config, pos=pos, **data)
        self.params.append(param)
        param.parse(iterator, config)

    def _add_resource(self, iterator, tag, data, config, pos):
        resource = Resource(config=config, pos=pos, **data)
        self.resources.append(resource)
        resource.parse(self, iterator, config)

    def _add_coosys(self, iterator, tag, data, config, pos):
        coosys = CooSys(config=config, pos=pos, **data)
        self.coordinate_systems.append(coosys)
        coosys.parse(iterator, config)

    def _add_timesys(self, iterator, tag, data, config, pos):
        timesys = TimeSys(config=config, pos=pos, **data)
        self.time_systems.append(timesys)
        timesys.parse(iterator, config)

    def _add_info(self, iterator, tag, data, config, pos):
        info = Info(config=config, pos=pos, **data)
        self.infos.append(info)
        info.parse(iterator, config)

    def _add_group(self, iterator, tag, data, config, pos):
        if not config.get("version_1_2_or_later"):
            warn_or_raise(W26, W26, ("GROUP", "VOTABLE", "1.2"), config, pos)
        group = Group(self, config=config, pos=pos, **data)
        self.groups.append(group)
        group.parse(iterator, config)

    def _get_version_checks(self):
        config = {}
        config["version"] = self.version
        config["version_1_1_or_later"] = util.version_compare(self.version, "1.1") >= 0
        config["version_1_2_or_later"] = util.version_compare(self.version, "1.2") >= 0
        config["version_1_3_or_later"] = util.version_compare(self.version, "1.3") >= 0
        config["version_1_4_or_later"] = util.version_compare(self.version, "1.4") >= 0
        config["version_1_5_or_later"] = util.version_compare(self.version, "1.5") >= 0
        return config

    # Map VOTable version numbers to namespace URIs and schema information.
    _version_namespace_map = {
        # Version 1.0 isn't well-supported, but is allowed on parse (with a warning).
        # It used DTD rather than schema, so this information would not be useful.
        # By omitting 1.0 from this dict we can use the keys as the list of versions
        # that are allowed in various other checks.
        "1.1": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.1",
            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.1",
        },
        "1.2": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.2",
            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.2",
        },
        # With 1.3 we'll be more explicit with the schema location.
        # - xsi:schemaLocation uses the namespace name along with the URL
        #   to reference it.
        # - For convenience, but somewhat confusingly, the namespace URIs
        #   are also usable URLs for accessing an applicable schema.
        #   However to avoid confusion, we'll use the explicit schema URL.
        "1.3": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.3.xsd"
            ),
        },
        # With 1.4 namespace URIs stopped incrementing with minor version changes
        # so we use the same URI as with 1.3.  See this IVOA note for more info:
        # http://www.ivoa.net/documents/Notes/XMLVers/20180529/
        "1.4": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.4.xsd"
            ),
        },
        "1.5": {
            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
            "schema_location_attr": "xsi:schemaLocation",
            "schema_location_value": (
                "http://www.ivoa.net/xml/VOTable/v1.3"
                " http://www.ivoa.net/xml/VOTable/VOTable-1.5.xsd"
            ),
        },
    }

    def parse(self, iterator, config):
        config["_current_table_number"] = 0

        for start, tag, data, pos in iterator:
            if start:
                if tag == "xml":
                    pass
                elif tag == "VOTABLE":
                    if "version" not in data:
                        warn_or_raise(W20, W20, self.version, config, pos)
                        config["version"] = self.version
                    else:
                        config["version"] = self._version = data["version"]
                        if config["version"].lower().startswith("v"):
                            warn_or_raise(W29, W29, config["version"], config, pos)
                            self._version = config["version"] = config["version"][1:]
                        if config["version"] not in self._version_namespace_map:
                            vo_warn(W21, config["version"], config, pos)

                        # Update the configuration of the VOTableFile itself.
                        # This can not be done via the .version property setter
                        # because that refuses to allow votable 1.0.
                        self._config["version"] = config["version"]
                        self._config.update(self._get_version_checks())

                    if "xmlns" in data:
                        ns_info = self._version_namespace_map.get(config["version"], {})
                        correct_ns = ns_info.get("namespace_uri")
                        if data["xmlns"] != correct_ns:
                            vo_warn(W41, (correct_ns, data["xmlns"]), config, pos)
                    else:
                        vo_warn(W42, (), config, pos)

                    break
                else:
                    vo_raise(E19, (), config, pos)
        config.update(self._get_version_checks())

        tag_mapping = {
```

## 原始行 16 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' astropy/io/votable/tree.py
sed -n '2670,3090p' astropy/io/votable/tree.py
sed -n '4380,4770p' astropy/io/votable/tree.py
sed -n '1,280p' astropy/io/votable/tests/test_table.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
# TODO: Test FITS parsing

# STDLIB
import base64
import codecs
import gzip
import io
import json
import os
import re
import urllib.request

# THIRD-PARTY
import numpy as np
from numpy import ma

# LOCAL
from astropy import __version__ as astropy_version
from astropy.io import fits
from astropy.utils import deprecated
from astropy.utils.collections import HomogeneousList
from astropy.utils.data import get_pkg_data_filename
from astropy.utils.xml import iterparser
from astropy.utils.xml.writer import XMLWriter

from . import converters, util, xmlutil
from . import ucd as ucd_mod
from .exceptions import (
    E06,
    E08,
    E09,
    E10,
    E11,
    E12,
    E13,
    E15,
    E16,
    E17,
    E18,
    E19,
    E20,
    E21,
    E22,
    E23,
    E25,
    E26,
    W06,
    W07,
    W08,
    W09,
    W10,
    W11,
    W12,
    W13,
    W15,
    W17,
    W18,
    W19,
    W20,
    W21,
    W22,
    W26,
    W27,
    W28,
    W29,
    W32,
    W33,
    W35,
    W36,
    W37,
    W38,
    W40,
    W41,
    W42,
    W43,
    W44,
    W45,
    W50,
    W52,
    W53,
    W54,
    W56,
    W57,
    vo_raise,
    vo_reraise,
    vo_warn,
    warn_or_raise,
    warn_unknown_attrs,
)

try:
    from . import tablewriter

    _has_c_tabledata_writer = True
except ImportError:
    _has_c_tabledata_writer = False


__all__ = [
    "CooSys",
    "Element",
    "Field",
    "FieldRef",
    "Group",
    "Info",
    "Link",
    "MivotBlock",
    "Param",
    "ParamRef",
    "Resource",
    "TableElement",
    "TimeSys",
    "VOTableFile",
    "Values",
]


# The default number of rows to read in each chunk before converting
# to an array.
DEFAULT_CHUNK_SIZE = 256
RESIZE_AMOUNT = 1.5

######################################################################
# FACTORY FUNCTIONS


def _resize(masked, new_size):
    """
    Masked arrays can not be resized inplace, and `np.resize` and
    `ma.resize` are both incompatible with structured arrays.
    Therefore, we do all this.
    """
    new_array = ma.zeros((new_size,), dtype=masked.dtype)
    length = min(len(masked), new_size)
    new_array[:length] = masked[:length]

    return new_array


def _lookup_by_attr_factory(attr, unique, iterator, element_name, doc):
    """
    Creates a function useful for looking up an element by a given
    attribute.

    Parameters
    ----------
    attr : str
        The attribute name

    unique : bool
        Should be `True` if the attribute is unique and therefore this
        should return only one value.  Otherwise, returns a list of
        values.

    iterator : generator
        A generator that iterates over some arbitrary set of elements

    element_name : str
        The XML element name of the elements being iterated over (used
        for error messages only).

    doc : str
        A docstring to apply to the generated function.

    Returns
    -------
    factory : function
        A function that looks up an element by the given attribute.
    """

    def lookup_by_attr(self, ref, before=None):
        """
        Given a string *ref*, finds the first element in the iterator
        where the given attribute == *ref*.  If *before* is provided,
        will stop searching at the object *before*.  This is
        important, since "forward references" are not allowed in the
        VOTABLE format.
        """
        for element in getattr(self, iterator)():
        return self._all_fields

    @property
    def params(self):
        """
        A list of parameters (constant-valued columns) for the
        table.  Must contain only :class:`Param` objects.
        """
        return self._params

    @property
    def groups(self):
        """
        A list of :class:`Group` objects describing how the columns
        and parameters are grouped.  Currently this information is
        only kept around for round-tripping and informational
        purposes.
        """
        return self._groups

    @property
    def links(self):
        """
        A list of :class:`Link` objects (pointers to other documents
        or servers through a URI) for the table.
        """
        return self._links

    @property
    def infos(self):
        """
        A list of :class:`Info` objects for the table.  Allows for
        post-operational diagnostics.
        """
        return self._infos









    def create_arrays(
        self,
        nrows=0,
        config=None,
        *,
        colnumbers=None,
    ):
        """
        Create a new array to hold the data based on the current set
        of fields, and store them in the *array* and member variable.
        Any data in the existing array will be lost.

        *nrows*, if provided, is the number of rows to allocate.
        *colnumbers*, if provided, is the list of column indices to select.
        By default, all columns are selected.
        """
        if nrows is None:
            nrows = 0
        if colnumbers is None:
            colnumbers = list(range(len(self.all_fields)))

        new_fields = HomogeneousList(
            Field,
            values=[f for i, f in enumerate(self.all_fields) if i in colnumbers],
        )
        if new_fields != self._fields:
            self._fields = new_fields

        fields = self.all_fields

        if len(fields) == 0:
            array = np.recarray((nrows,), dtype="O")
            mask = np.zeros((nrows,), dtype="b")
        else:
            # for field in fields: field._setup(config)
            Field.uniqify_names(fields)

            dtype = []
            for i, x in enumerate(fields):
                if i not in colnumbers:
                    continue
                if x._unique_name == x.ID:
                    id = x.ID
                else:
                    id = (x._unique_name, x.ID)
                dtype.append((id, x.converter.format))

            array = np.recarray((nrows,), dtype=np.dtype(dtype))
            descr_mask = []
            for d in array.dtype.descr:
                new_type = (d[1][1] == "O" and "O") or "bool"
                if len(d) == 2:
                    descr_mask.append((d[0], new_type))
                elif len(d) == 3:
                    descr_mask.append((d[0], new_type, d[2]))
            mask = np.zeros((nrows,), dtype=descr_mask)

        self.array = ma.array(array, mask=mask)

    def _resize_strategy(self, size):
        """
        Return a new (larger) size based on size, used for
        reallocating an array when it fills up.  This is in its own
        function so the resizing strategy can be easily replaced.
        """
        # Once we go beyond 0, make a big step -- after that use a
        # factor of 1.5 to help keep memory usage compact
        if size == 0:
            return 512
        return int(np.ceil(size * RESIZE_AMOUNT))

    def add_field(self, field: Field) -> None:
        self.fields.append(field)
        self.all_fields.append(field)

    def _register_field(self, iterator, tag, data, config, pos) -> None:
        field = Field(self._votable, config=config, pos=pos, **data)
        field.parse(iterator, config)
        self._all_fields.append(field)

    def _add_param(self, iterator, tag, data, config, pos):
        param = Param(self._votable, config=config, pos=pos, **data)
        self.params.append(param)
        param.parse(iterator, config)

    def _add_group(self, iterator, tag, data, config, pos):
        group = Group(self, config=config, pos=pos, **data)
        self.groups.append(group)
        group.parse(iterator, config)

    def _add_link(self, iterator, tag, data, config, pos):
        link = Link(config=config, pos=pos, **data)
        self.links.append(link)
        link.parse(iterator, config)

    def _add_info(self, iterator, tag, data, config, pos):
        if not config.get("version_1_2_or_later"):
            warn_or_raise(W26, W26, ("INFO", "TABLE", "1.2"), config, pos)
        info = Info(config=config, pos=pos, **data)
        self.infos.append(info)
        info.parse(iterator, config)

    def parse(self, iterator, config):
        columns = config.get("columns")

        # If we've requested to read in only a specific table, skip
        # all others
        table_number = config.get("table_number")
        current_table_number = config.get("_current_table_number")
        skip_table = False
        if current_table_number is not None:
            config["_current_table_number"] += 1
            if table_number is not None and table_number != current_table_number:
                skip_table = True
                self._empty = True

        table_id = config.get("table_id")
        if table_id is not None:
            if table_id != self.ID:
                skip_table = True
                self._empty = True

        if self.ref is not None:
            # This table doesn't have its own datatype descriptors, it
            # just references those from another table.

            # This is to call the property setter to go and get the
            # referenced information
            self.ref = self.ref

            for start, tag, data, pos in iterator:
                if start:
                    if tag == "DATA":
                        warn_unknown_attrs("DATA", data.keys(), config, pos)
                        break
                else:
                    if tag == "TABLE":
                        return self
                    elif tag == "DESCRIPTION":
                        if self.description is not None:
                            warn_or_raise(W17, W17, "RESOURCE", config, pos)
                        self.description = data or None
        else:
            tag_mapping = {
                "FIELD": self._register_field,
                "PARAM": self._add_param,
                "GROUP": self._add_group,
                "LINK": self._add_link,
                "INFO": self._add_info,
                "DESCRIPTION": self._ignore_add,
            }

            for start, tag, data, pos in iterator:
                if start:
                    if tag == "DATA":
                        if len(self.all_fields) == 0:
                            warn_or_raise(E25, E25, None, config, pos)
                        warn_unknown_attrs("DATA", data.keys(), config, pos)
                        break

                    tag_mapping.get(tag, self._add_unknown_tag)(
                        iterator, tag, data, config, pos
                    )
                else:
                    if tag == "DESCRIPTION":
                        if self.description is not None:
                            warn_or_raise(W17, W17, "RESOURCE", config, pos)
                        self.description = data or None
                    elif tag == "TABLE":
                        # For error checking purposes
                        Field.uniqify_names(self.all_fields)
                        # We still need to create arrays, even if the file
                        # contains no DATA section
                        self.create_arrays(nrows=0, config=config)
                        return self

        fields = self.all_fields
        Field.uniqify_names(fields)
        names = [x.ID for x in fields]
        # Deal with a subset of the columns, if requested.
        if not columns:
            colnumbers = list(range(len(fields)))
        else:
            if isinstance(columns, str):
                columns = [columns]
            columns = np.asarray(columns)
            if issubclass(columns.dtype.type, np.integer):
                if np.any(columns < 0) or np.any(columns > len(fields)):
                    raise ValueError("Some specified column numbers out of range")
                colnumbers = columns
            elif issubclass(columns.dtype.type, np.character):
                try:
                    colnumbers = [names.index(x) for x in columns]
                except ValueError:
                    # convert to builtin str because representation of numpy strings
                    # differ in numpy 2 and may be confusing to users
                    missing_columns = [
                        str(name) for name in columns if name not in names
                    ]
                    raise ValueError(
                        f"Columns {missing_columns} were not found in fields list"
                    ) from None
            else:
                raise TypeError("Invalid columns list")

        self.create_arrays(nrows=self._nrows, config=config, colnumbers=colnumbers)

        if (not skip_table) and (len(fields) > 0):
            for start, tag, data, pos in iterator:
                if not start:
                    continue

                if tag == "TABLEDATA":
                    warn_unknown_attrs("TABLEDATA", data.keys(), config, pos)
                    self.array = self._parse_tabledata(iterator, colnumbers, config)
                elif tag == "BINARY":
                    warn_unknown_attrs("BINARY", data.keys(), config, pos)
                    self.array = self._parse_binary(
                        1, iterator, colnumbers, config, pos
                    )
                elif tag == "BINARY2":
                    if not config.get("version_1_3_or_later"):
                        warn_or_raise(W52, W52, config["version"], config, pos)
                    self.array = self._parse_binary(
                        2, iterator, colnumbers, config, pos
                    )
                elif tag == "FITS":
                    if config.get("columns") is not None:
                        raise NotImplementedError
                    warn_unknown_attrs("FITS", data.keys(), config, pos, ["extnum"])
                    try:
                        extnum = int(data.get("extnum", 0))
                        if extnum < 0:
                            raise ValueError("'extnum' cannot be negative.")
                    except ValueError:
                        vo_raise(E17, (), config, pos)
                    self.array = self._parse_fits(iterator, extnum, config)

                elif tag == "PARQUET":
                    if (data["type"] == "VOTable-remote-file") | (
                        data["type"] == "VOTable-remote-partition"
                    ):
                        warn_unknown_attrs("PARQUET", data.keys(), config, pos)
                        self.array = self._parse_parquet(iterator, config)

                else:
                    warn_or_raise(W37, W37, tag, config, pos)

                break

        for start, tag, data, pos in iterator:
            if not start and tag == "DATA":
                break

        for start, tag, data, pos in iterator:
            if start and tag == "INFO":
                if not config.get("version_1_2_or_later"):
                    warn_or_raise(W26, W26, ("INFO", "TABLE", "1.2"), config, pos)
                info = Info(config=config, pos=pos, **data)
                self.infos.append(info)
                info.parse(iterator, config)
            elif not start and tag == "TABLE":
                break

        return self

    def _parse_tabledata(self, iterator, colnumbers, config):
        # Since we don't know the number of rows up front, we'll
        # reallocate the record array to make room as we go.  This
        # prevents the need to scan through the XML twice.  The
        # allocation is by factors of 1.5.
        invalid = config.get("invalid", "exception")

        # Need to have only one reference so that we can resize the
        # array
        array = self.array
        del self.array

        fields = self.all_fields
        parsers = [field.converter.parse for field in fields]
        binparsers = [field.converter.binparse for field in fields]

        numrows = 0
        alloc_rows = len(array)
        colnumbers_bits = [i in colnumbers for i in range(len(fields))]
        row_default = [field.converter.default for field in self.fields]
        mask_default = [True] * len(self.fields)
        array_chunk = []
        mask_chunk = []
        chunk_size = config.get("chunk_size", DEFAULT_CHUNK_SIZE)
        for start, tag, data, pos in iterator:
            if tag == "TR":
                # Now parse one row
                row = row_default[:]
                row_mask = mask_default[:]
                i = 0  # index of the column being read from disk
                j = 0  # index of the column being written in array (not necessarily == i)
                for start, tag, data, pos in iterator:
                    if start:
                        binary = data.get("encoding", None) == "base64"
                        warn_unknown_attrs(tag, data.keys(), config, pos, ["encoding"])
                    else:
                        if tag == "TD":
                            if i >= len(fields):
                                vo_raise(E20, len(fields), config, pos)

                            if colnumbers_bits[i]:
                                try:
                                    if binary:
                                        rawdata = base64.b64decode(data.encode("ascii"))
                                        buf = io.BytesIO(rawdata)
                                        buf.seek(0)
                                        try:
                                            value, mask_value = binparsers[i](buf.read)
                                        except Exception as e:
                                            vo_reraise(
                                                e,
                                                config,
                                                pos,
                                                (
                                                    f"(in row {len(array_chunk):d}, "
                                                    f"col '{fields[i].ID}')"
                                                ),
                                            )
                                    else:
                                        try:
                                            value, mask_value = parsers[i](
                                                data, config, pos
                                            )
                                        except Exception as e:
                                            vo_reraise(
                                                e,
                                                config,
                                                pos,
                                                (
                                                    f"(in row {len(array_chunk):d}, "
                                                    f"col '{fields[i].ID}')"
                                                ),
                                            )
                                except Exception as e:
                                    if invalid == "exception":
                                        vo_reraise(e, config, pos)
                                else:
                                    row[j] = value
                                    row_mask[j] = mask_value
                                    j += 1
                        elif tag == "TR":
                            break
                        else:
                            self._add_unknown_tag(iterator, tag, data, config, pos)
                        i += 1

                if i < len(fields):
                    vo_raise(E21, (i, len(fields)), config, pos)

                array_chunk.append(tuple(row))
                mask_chunk.append(tuple(row_mask))

                if len(array_chunk) == chunk_size:
                    while numrows + chunk_size > alloc_rows:
                        alloc_rows = self._resize_strategy(alloc_rows)
                    if alloc_rows != len(array):
                        array = _resize(array, alloc_rows)
                    array[numrows : numrows + chunk_size] = array_chunk
                    array.mask[numrows : numrows + chunk_size] = mask_chunk
                    numrows += chunk_size
                    array_chunk = []
                    mask_chunk = []

            elif not start and tag == "TABLEDATA":
                break

        # Now, resize the array to the exact number of rows we need and
        # put the last chunk values in there.
        alloc_rows = numrows + len(array_chunk)

        array = _resize(array, alloc_rows)
        tag_mapping = {
            "PARAM": self._add_param,
            "RESOURCE": self._add_resource,
            "COOSYS": self._add_coosys,
            "TIMESYS": self._add_timesys,
            "INFO": self._add_info,
            "DEFINITIONS": self._add_definitions,
            "DESCRIPTION": self._ignore_add,
            "GROUP": self._add_group,
        }

        for start, tag, data, pos in iterator:
            if start:
                tag_mapping.get(tag, self._add_unknown_tag)(
                    iterator, tag, data, config, pos
                )
            elif tag == "DESCRIPTION":
                if self.description is not None:
                    warn_or_raise(W17, W17, "VOTABLE", config, pos)
                self.description = data or None

        if not len(self.resources) and config["version_1_2_or_later"]:
            warn_or_raise(W53, W53, (), config, pos)

        return self

    def to_xml(
        self,
        fd,
        compressed=False,
        tabledata_format=None,
        _debug_python_based_parser=False,
        _astropy_version=None,
    ):
        """
        Write to an XML file.

        Parameters
        ----------
        fd : str or file-like
            Where to write the file. If a file-like object, must be writable.

        compressed : bool, optional
            When `True`, write to a gzip-compressed file.  (Default:
            `False`)

        tabledata_format : str, optional
            Override the format of the table(s) data to write.  Must
            be one of ``tabledata`` (text representation), ``binary`` or
            ``binary2``.  By default, use the format that was specified
            in each `TableElement` object as it was created or read in.  See
            :ref:`astropy:votable-serialization`.
        """
        if tabledata_format is not None:
            if tabledata_format.lower() not in ("tabledata", "binary", "binary2"):
                raise ValueError(f"Unknown format type '{format}'")

        kwargs = {
            "version": self.version,
            "tabledata_format": tabledata_format,
            "_debug_python_based_parser": _debug_python_based_parser,
            "_group_number": 1,
        }
        kwargs.update(self._get_version_checks())

        with util.convert_to_writable_filelike(fd, compressed=compressed) as fh:
            w = XMLWriter(fh)
            version = self.version
            if _astropy_version is None:
                lib_version = astropy_version
            else:
                lib_version = _astropy_version

            xml_header = """
<?xml version="1.0" encoding="utf-8"?>
<!-- Produced with astropy.io.votable version {lib_version}
     http://www.astropy.org/ -->\n"""
            w.write(xml_header.lstrip().format(**locals()))

            # Build the VOTABLE tag attributes.
            votable_attr = {
                "version": version,
                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
            }
            ns_info = self._version_namespace_map.get(version, {})
            namespace_uri = ns_info.get("namespace_uri")
            if namespace_uri:
                votable_attr["xmlns"] = namespace_uri
            schema_location_attr = ns_info.get("schema_location_attr")
            schema_location_value = ns_info.get("schema_location_value")
            if schema_location_attr and schema_location_value:
                votable_attr[schema_location_attr] = schema_location_value

            with w.tag("VOTABLE", votable_attr):
                if self.description is not None:
                    w.element("DESCRIPTION", self.description, wrap=True)
                element_sets = [
                    self.coordinate_systems,
                    self.time_systems,
                    self.params,
                    self.infos,
                    self.resources,
                ]
                if kwargs["version_1_2_or_later"]:
                    element_sets.append(self.groups)

                for element_set in element_sets:
                    for element in element_set:
                        element.to_xml(w, **kwargs)

    def iter_tables(self):
        """
        Iterates over all tables in the VOTable file in a "flat" way,
        ignoring the nesting of resources etc.
        """
        for resource in self.resources:
            yield from resource.iter_tables()











    get_table_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_tables",
        "TABLE",
        """
        Looks up a TABLE_ element by the given ID.  Used by the table
        "ref" attribute.
        """,
    )

    get_tables_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_tables",
        "TABLE",
        """
        Looks up a TABLE_ element by the given utype, and returns an
        iterator emitting all matches.
        """,
    )

    def get_table_by_index(self, idx):
        """
        Get a table by its ordinal position in the file.
        """
        for i, table in enumerate(self.iter_tables()):
            if i == idx:
                return table
        raise IndexError(f"No table at index {idx:d} found in VOTABLE file.")

    def iter_fields_and_params(self):
        """
        Recursively iterate over all FIELD_ and PARAM_ elements in the
        VOTABLE_ file.
        """
        for resource in self.resources:
            yield from resource.iter_fields_and_params()

    get_field_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_fields_and_params",
        "FIELD",
        """
        Looks up a FIELD_ element by the given ID_.  Used by the field's
        "ref" attribute.
        """,
    )

    get_fields_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_fields_and_params",
        "FIELD",
        """
        Looks up a FIELD_ element by the given utype and returns an
        iterator emitting all matches.
        """,
    )

    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
        "iter_fields_and_params",
        "FIELD",
        """
        Looks up a FIELD_ element by the given ID_ or name.
        """,
    )









    get_values_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_values",
        "VALUES",
        """
        Looks up a VALUES_ element by the given ID.  Used by the values
        "ref" attribute.
        """,
    )

    def iter_groups(self):
        """
        Recursively iterate over all GROUP_ elements in the VOTABLE_
        file.
        """
        for table in self.iter_tables():
            yield from table.iter_groups()

    get_group_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_groups",
        "GROUP",
        """
        Looks up a GROUP_ element by the given ID.  Used by the group's
        "ref" attribute
        """,
    )

    get_groups_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_groups",
        "GROUP",
        """
        Looks up a GROUP_ element by the given utype and returns an
        iterator emitting all matches.
        """,
    )

    def iter_coosys(self):
        """
        Recursively iterate over all COOSYS_ elements in the VOTABLE_
        file.
        """
        yield from self.coordinate_systems
        for resource in self.resources:
            yield from resource.iter_coosys()

    get_coosys_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_coosys",
        "COOSYS",
        """Looks up a COOSYS_ element by the given ID.""",
    )

    def iter_timesys(self):
        """
        Recursively iterate over all TIMESYS_ elements in the VOTABLE_
        file.
        """
        yield from self.time_systems
        for resource in self.resources:
            yield from resource.iter_timesys()

    get_timesys_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_timesys",
        "TIMESYS",
        """Looks up a TIMESYS_ element by the given ID.""",
    )

    def iter_info(self):
        """
        Recursively iterate over all INFO_ elements in the VOTABLE_
        file.
        """
        yield from self.infos
        for resource in self.resources:
            yield from resource.iter_info()

    get_info_by_id = _lookup_by_attr_factory(
        "ID", True, "iter_info", "INFO", """Looks up a INFO element by the given ID."""
    )

    get_infos_by_name = _lookup_by_attr_factory(
        "name",
        False,
        "iter_info",
        "INFO",
        """Returns all INFO children with the given name.""",
    )

    def set_all_tables_format(self, format):
        """
        Set the output storage format of all tables in the file.
        """
        for table in self.iter_tables():
            table.format = format

    @classmethod
    def from_table(cls, table, table_id=None):
        """
        Create a `VOTableFile` instance from a given
        `astropy.table.Table` instance.

        Parameters
        ----------
        table_id : str, optional
            Set the given ID attribute on the returned TableElement instance.
        """
        votable_file = cls()
        resource = Resource()
        votable = TableElement.from_table(votable_file, table)
        if table_id is not None:
            votable.ID = table_id
        resource.tables.append(votable)
        votable_file.resources.append(resource)
        return votable_file# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Test the conversion to/from astropy.table.
"""

import io
import os
import pathlib
import struct
import warnings

import numpy as np
import pytest

from astropy import units as u
from astropy.io.votable import conf, from_table, is_votable, tree, validate
from astropy.io.votable.converters import Char, UnicodeChar, get_converter
from astropy.io.votable.exceptions import E01, E25, W39, W46, W50, VOWarning
from astropy.io.votable.table import parse, writeto
from astropy.io.votable.tree import Field, VOTableFile
from astropy.table import Column, Table
from astropy.table.table_helpers import simple_table
from astropy.utils.compat.optional_deps import HAS_PYARROW
from astropy.utils.data import (
    get_pkg_data_filename,
    get_pkg_data_fileobj,
    get_pkg_data_path,
)
from astropy.utils.misc import _NOT_OVERWRITING_MSG_MATCH


@pytest.fixture
def home_is_data(monkeypatch):
    """
    Pytest fixture to run a test case with tilde-prefixed paths.

    In the tilde-path case, environment variables are temporarily
    modified so that '~' resolves to the data directory.
    """
    path = get_pkg_data_path("data")
    # For Unix
    monkeypatch.setenv("HOME", path)
    # For Windows
    monkeypatch.setenv("USERPROFILE", path)


@pytest.fixture
def home_is_tmpdir(monkeypatch, tmp_path):
    """
    Pytest fixture to run a test case with tilde-prefixed paths.

    In the tilde-path case, environment variables are temporarily
    modified so that '~' resolves to the temp directory.
    """
    # For Unix
    monkeypatch.setenv("HOME", str(tmp_path))
    # For Windows
    monkeypatch.setenv("USERPROFILE", str(tmp_path))


def test_table(tmp_path):
    # Read the VOTABLE
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        votable = parse(get_pkg_data_filename("data/regression.xml"))
    table = votable.get_first_table()
    astropy_table = table.to_table()

    for name in table.array.dtype.names:
        assert np.all(astropy_table.mask[name] == table.array.mask[name])

    votable2 = tree.VOTableFile.from_table(astropy_table)
    t = votable2.get_first_table()

    field_types = [
        ("string_test", {"datatype": "char", "arraysize": "*"}),
        ("string_test_2", {"datatype": "char", "arraysize": "10"}),
        ("unicode_test", {"datatype": "unicodeChar", "arraysize": "*"}),
        ("fixed_unicode_test", {"datatype": "unicodeChar", "arraysize": "10"}),
        ("string_array_test", {"datatype": "char", "arraysize": "4*"}),
        ("unsignedByte", {"datatype": "unsignedByte"}),
        ("short", {"datatype": "short"}),
        ("int", {"datatype": "int"}),
        ("intNoNull", {"datatype": "int"}),
        ("long", {"datatype": "long"}),
        ("double", {"datatype": "double"}),
        ("float", {"datatype": "float"}),
        ("array", {"datatype": "long", "arraysize": "2*"}),
        ("bit", {"datatype": "bit"}),
        ("bitarray", {"datatype": "bit", "arraysize": "3x2"}),
        ("bitvararray", {"datatype": "bit", "arraysize": "*"}),
        ("bitvararray2", {"datatype": "bit", "arraysize": "3x2*"}),
        ("floatComplex", {"datatype": "floatComplex"}),
        ("doubleComplex", {"datatype": "doubleComplex"}),
        ("doubleComplexArray", {"datatype": "doubleComplex", "arraysize": "*"}),
        ("doubleComplexArrayFixed", {"datatype": "doubleComplex", "arraysize": "2"}),
        ("boolean", {"datatype": "bit"}),
        ("booleanArray", {"datatype": "bit", "arraysize": "4"}),
        ("nulls", {"datatype": "int"}),
        ("nulls_array", {"datatype": "int", "arraysize": "2x2"}),
        ("precision1", {"datatype": "double"}),
        ("precision2", {"datatype": "double"}),
        ("doublearray", {"datatype": "double", "arraysize": "*"}),
        ("bitarray2", {"datatype": "bit", "arraysize": "16"}),
    ]

    for field, (name, d) in zip(t.fields, field_types):
        assert field.ID == name
        assert field.datatype == d["datatype"], (
            f"{name} expected {d['datatype']} but get {field.datatype}"
        )
        if "arraysize" in d:
            assert field.arraysize == d["arraysize"]

    # W39: Bit values can not be masked
    with pytest.warns(W39):
        writeto(votable2, str(tmp_path / "through_table.xml"))


def test_read_from_tilde_path(home_is_data):
    # Just test that these run without error for tilde-paths
    path = os.path.join("~", "regression.xml")
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        votable = parse(path)
        Table.read(path, format="votable", table_id="main_table")


def test_read_through_table_interface(tmp_path):
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
            t = Table.read(fd, format="votable", table_id="main_table")

    assert len(t) == 5

    # Issue 8354
    assert t["float"].format is None

    fn = tmp_path / "table_interface.xml"

    # W39: Bit values can not be masked
    with pytest.warns(W39):
        t.write(fn, table_id="FOO", format="votable")

    with open(fn, "rb") as fd:
        t2 = Table.read(fd, format="votable", table_id="FOO")

    assert len(t2) == 5


def test_read_through_table_interface2():
    with np.errstate(over="ignore"):
        # https://github.com/astropy/astropy/issues/13341
        with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
            t = Table.read(fd, format="votable", table_id="last_table")

    assert len(t) == 0


def test_pass_kwargs_through_table_interface():
    # Table.read() should pass on keyword arguments meant for parse()
    filename = get_pkg_data_filename("data/nonstandard_units.xml")
    t = Table.read(filename, format="votable", unit_format="generic")
    assert t["Flux1"].unit == u.Unit("erg / (Angstrom cm2 s)")


def test_names_over_ids():
    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
        votable = parse(fd)

    table = votable.get_first_table().to_table(use_names_over_ids=True)

    assert table.colnames == [
        "Name",
        "GLON",
        "GLAT",
        "RAdeg",
        "DEdeg",
        "Jmag",
        "Hmag",
        "Kmag",
        "G3.6mag",
        "G4.5mag",
        "G5.8mag",
        "G8.0mag",
        "4.5mag",
        "8.0mag",
        "Emag",
        "24mag",
        "f_Name",
    ]


def test_explicit_ids():
    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
        votable = parse(fd)

    table = votable.get_first_table().to_table(use_names_over_ids=False)

    assert table.colnames == [
        "col1",
        "col2",
        "col3",
        "col4",
        "col5",
        "col6",
        "col7",
        "col8",
        "col9",
        "col10",
        "col11",
        "col12",
        "col13",
        "col14",
        "col15",
        "col16",
        "col17",
    ]


def test_table_read_with_unnamed_tables():
    """
    Issue #927.
    """
    with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
        t = Table.read(fd, format="votable")

    assert len(t) == 1


def test_votable_path_object():
    """
    Testing when votable is passed as pathlib.Path object #4412.
    """
    fpath = pathlib.Path(get_pkg_data_filename("data/names.xml"))
    table = parse(fpath).get_first_table().to_table()

    assert len(table) == 1
    assert int(table[0][3]) == 266


def test_from_table_without_mask():
    t = Table()
    c = Column(data=[1, 2, 3], name="a")
    t.add_column(c)
    output = io.BytesIO()
    t.write(output, format="votable")


def test_write_with_format():
    t = Table()
    c = Column(data=[1, 2, 3], name="a")
    t.add_column(c)

    output = io.BytesIO()
    t.write(output, format="votable", tabledata_format="binary")
    obuff = output.getvalue()
    assert b'VOTABLE version="1.4"' in obuff
    assert b"BINARY" in obuff
    assert b"TABLEDATA" not in obuff

    output = io.BytesIO()
    t.write(output, format="votable", tabledata_format="binary2")
    obuff = output.getvalue()
    assert b'VOTABLE version="1.4"' in obuff
    assert b"BINARY2" in obuff
    assert b"TABLEDATA" not in obuff


@pytest.mark.skipif(not HAS_PYARROW, reason="requires pyarrow")
@pytest.mark.parametrize("overwrite", [True, False])
def test_read_write_votable_parquet(tmp_path, overwrite):
    """
    Test to write and read VOTable with Parquet serialization
    """

    # Create some fake data
    number_of_objects = 10
    ids = [f"COSMOS_{ii:03g}" for ii in range(number_of_objects)]
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "sed -n '100,280p' astropy/io/votable/tree.py
sed -n '1750,2160p' astropy/io/votable/tree.py
sed -n '2280,2495p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
__all__ = [
    "CooSys",
    "Element",
    "Field",
    "FieldRef",
    "Group",
    "Info",
    "Link",
    "MivotBlock",
    "Param",
    "ParamRef",
    "Resource",
    "TableElement",
    "TimeSys",
    "VOTableFile",
    "Values",
]


# The default number of rows to read in each chunk before converting
# to an array.
DEFAULT_CHUNK_SIZE = 256
RESIZE_AMOUNT = 1.5

######################################################################
# FACTORY FUNCTIONS


def _resize(masked, new_size):
    """
    Masked arrays can not be resized inplace, and `np.resize` and
    `ma.resize` are both incompatible with structured arrays.
    Therefore, we do all this.
    """
    new_array = ma.zeros((new_size,), dtype=masked.dtype)
    length = min(len(masked), new_size)
    new_array[:length] = masked[:length]

    return new_array


def _lookup_by_attr_factory(attr, unique, iterator, element_name, doc):
    """
    Creates a function useful for looking up an element by a given
    attribute.

    Parameters
    ----------
    attr : str
        The attribute name

    unique : bool
        Should be `True` if the attribute is unique and therefore this
        should return only one value.  Otherwise, returns a list of
        values.

    iterator : generator
        A generator that iterates over some arbitrary set of elements

    element_name : str
        The XML element name of the elements being iterated over (used
        for error messages only).

    doc : str
        A docstring to apply to the generated function.

    Returns
    -------
    factory : function
        A function that looks up an element by the given attribute.
    """

    def lookup_by_attr(self, ref, before=None):
        """
        Given a string *ref*, finds the first element in the iterator
        where the given attribute == *ref*.  If *before* is provided,
        will stop searching at the object *before*.  This is
        important, since "forward references" are not allowed in the
        VOTABLE format.
        """
        for element in getattr(self, iterator)():
            if element is before:
                if getattr(element, attr, None) == ref:
                    vo_raise(
                        KeyError,
                        f"{element_name} references itself",
                        element._config,
                        element._pos,
                    )
                break
            if getattr(element, attr, None) == ref:
                yield element

    def lookup_by_attr_unique(self, ref, before=None):
        for element in lookup_by_attr(self, ref, before=before):
            return element
        raise KeyError(
            f"No {element_name} with {attr} '{ref}' found before the referencing "
            f"{element_name}"
        )

    if unique:
        lookup_by_attr_unique.__doc__ = doc
        return lookup_by_attr_unique
    else:
        lookup_by_attr.__doc__ = doc
        return lookup_by_attr


def _lookup_by_id_or_name_factory(iterator, element_name, doc):
    """
    Like `_lookup_by_attr_factory`, but looks in both the "ID" and
    "name" attributes.
    """

    def lookup_by_id_or_name(self, ref, before=None):
        """
        Given an key *ref*, finds the first element in the iterator
        with the attribute ID == *ref* or name == *ref*.  If *before*
        is provided, will stop searching at the object *before*.  This
        is important, since "forward references" are not allowed in
        the VOTABLE format.
        """
        for element in getattr(self, iterator)():
            if element is before:
                if ref in (element.ID, element.name):
                    vo_raise(
                        KeyError,
                        f"{element_name} references itself",
                        element._config,
                        element._pos,
                    )
                break
            if ref in (element.ID, element.name):
                return element
        raise KeyError(
            f"No {element_name} with ID or name '{ref}' found before the referencing "
            f"{element_name}"
        )

    lookup_by_id_or_name.__doc__ = doc
    return lookup_by_id_or_name


def _get_default_unit_format(config):
    """
    Get the default unit format as specified in the VOTable spec.
    """
    # The unit format changed between VOTable versions 1.3 and 1.4,
    # see issue #10791.
    if config["version_1_4_or_later"]:
        return "vounit"
    else:
        return "cds"


def _get_unit_format(config):
    """
    Get the unit format based on the configuration.
    """
    if config.get("unit_format") is None:
        format = _get_default_unit_format(config)
    else:
        format = config["unit_format"]
    return format


def _attach_default_config(votable, config) -> dict:
    """Create default config if none given.

    Parameters
    ----------
    votable
        Object that might potentially have a config attached to it.
    config : `dict` or `None`
        Config to be used or defined.

    Returns
    -------
    config : `dict`
        If config was `None` this will be a new `dict`. If the ``votable``

    @classmethod
    def from_table_column(cls, votable, column):
        """
        Restores a `Field` instance from a given
        `astropy.table.Column` instance.
        """
        kwargs = {}
        meta = column.info.meta
        if meta:
            for key in ["ucd", "width", "precision", "utype", "xtype"]:
                val = meta.get(key, None)
                if val is not None:
                    kwargs[key] = val
        # TODO: Use the unit framework when available
        if column.info.unit is not None:
            kwargs["unit"] = column.info.unit
        kwargs["name"] = column.info.name
        result = converters.table_column_to_votable_datatype(column)
        kwargs.update(result)

        field = cls(votable, **kwargs)

        if column.info.description is not None:
            field.description = column.info.description
        field.values.from_table_column(column)
        if meta and "links" in meta:
            for link in meta["links"]:
                field.links.append(Link.from_table_column(link))

        # TODO: Parse format into precision and width
        return field


class Param(Field):
    """
    PARAM_ element: constant-valued columns in the data.

    :class:`Param` objects are a subclass of :class:`Field`, and have
    all of its methods and members.  Additionally, it defines :attr:`value`.
    """

    _attr_list_11 = Field._attr_list_11 + ["value"]
    _attr_list_12 = Field._attr_list_12 + ["value"]
    _element_name = "PARAM"

    def __init__(
        self,
        votable,
        ID=None,
        name=None,
        value=None,
        datatype=None,
        arraysize=None,
        ucd=None,
        unit=None,
        width=None,
        precision=None,
        utype=None,
        type=None,
        id=None,
        config=None,
        pos=None,
        **extra,
    ):
        self._value = value
        Field.__init__(
            self,
            votable,
            ID=ID,
            name=name,
            datatype=datatype,
            arraysize=arraysize,
            ucd=ucd,
            unit=unit,
            precision=precision,
            utype=utype,
            type=type,
            id=id,
            config=config,
            pos=pos,
            **extra,
        )

    @property
    def value(self):
        """
        [*required*] The constant value of the parameter.  Its type is
        determined by the :attr:`~Field.datatype` member.
        """
        return self._value

    @value.setter
    def value(self, value):
        if value is None:
            value = ""
        if isinstance(value, str):
            self._value = self.converter.parse(value, self._config, self._pos)[0]
        else:
            self._value = value

    def _setup(self, config, pos):
        Field._setup(self, config, pos)
        self.value = self._value

    def to_xml(self, w, **kwargs):
        tmp_value = self._value
        self._value = self.converter.output(tmp_value, False)
        # We must always have a value
        if self._value is None:
            self._value = ""
        Field.to_xml(self, w, **kwargs)
        self._value = tmp_value


class CooSys(SimpleElement):
    """
    COOSYS_ element: defines a coordinate system.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    _attr_list = ["ID", "equinox", "epoch", "system", "refposition"]
    _element_name = "COOSYS"
    _reference_frames = None

    def __init__(
        self,
        ID=None,
        equinox=None,
        epoch=None,
        system=None,
        id=None,
        config=None,
        pos=None,
        refposition=None,
        **extra,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        # COOSYS was deprecated in 1.2 but then re-instated in 1.3
        if config.get("version_1_2_or_later") and not config.get(
            "version_1_3_or_later"
        ):
            warn_or_raise(W27, W27, (), config, pos)

        SimpleElement.__init__(self)

        self.ID = resolve_id(ID, id, config, pos)
        self.equinox = equinox
        self.epoch = epoch
        self.system = system
        self.refposition = refposition

        # refposition introduced in v1.5.
        if self.refposition is not None and not config.get("version_1_5_or_later"):
            warn_or_raise(W57, W57, (), config, pos)

        warn_unknown_attrs("COOSYS", extra.keys(), config, pos)

    @property
    def ID(self):
        """
        [*required*] The XML ID of the COOSYS_ element, used for
        cross-referencing.  May be `None` or a string conforming to
        XML ID_ syntax.
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        if self._config.get("version_1_1_or_later"):
            if ID is None:
                vo_raise(E15, (), self._config, self._pos)
        xmlutil.check_id(ID, "ID", self._config, self._pos)
        self._ID = ID

    @property
    def system(self):
        """Specifies the type of coordinate system.

        Valid choices are given by `~astropy.io.votable.tree.CooSys.reference_frames`
        """
        return self._system

    @system.setter
    def system(self, system):
        if system not in self.reference_frames:
            warn_or_raise(E16, E16, system, self._config, self._pos)
        self._system = system

    @system.deleter
    def system(self):
        self._system = None






















    @property
    def equinox(self):
        """
        A parameter required to fix the equatorial or ecliptic systems
        (as e.g. "J2000" as the default "eq_FK5" or "B1950" as the
        default "eq_FK4").
        """
        return self._equinox

    @equinox.setter
    def equinox(self, equinox):
        check_astroyear(equinox, "equinox", self._config, self._pos)
        self._equinox = equinox

    @equinox.deleter
    def equinox(self):
        self._equinox = None

    @property
    def epoch(self):
        """
        Specifies the epoch of the positions.  It must be a string
        specifying an astronomical year.
        """
        return self._epoch

    @epoch.setter
    def epoch(self, epoch):
        check_astroyear(epoch, "epoch", self._config, self._pos)
        self._epoch = epoch

    @epoch.deleter
    def epoch(self):
        self._epoch = None

    def to_astropy_frame(self):
        """Convert the coosys element into an astropy built-in frame.

        This only reads the system and equinox attributes.

        Returns
        -------
        `~astropy.coordinates.BaseCoordinateFrame`
            An astropy built-in frame corresponding to the frame described by
            the COOSYS element.

        Examples
        --------
        >>> from astropy.io.votable.tree import CooSys
        >>> coosys = CooSys(system="ICRS", epoch="J2020")
        >>> # note that coosys elements also contain the epoch
        >>> coosys.to_astropy_frame()
        <ICRS Frame>

        Notes
        -----
        If the correspondence is not straightforward, this method raises an error. In
        that case, you can refer to the `IVOA reference frames definition
        <http://www.ivoa.net/rdf/refframe>`_ and the list of `astropy's frames
        <https://docs.astropy.org/en/stable/coordinates/frames.html>`_ and deal with the
        conversion manually.
        """
        # the import has to be here due to circular dependencies issues
        from astropy.coordinates import FK4, FK5, ICRS, AltAz, Galactic, Supergalactic

        match_frames = {
            "ICRS": ICRS(),
            "FK4": FK4(equinox=self.equinox),
            "FK5": FK5(equinox=self.equinox),
            "eq_FK4": FK4(equinox=self.equinox),
            "eq_FK5": FK5(equinox=self.equinox),
            "GALACTIC": Galactic(),
            "galactic": Galactic(),
            "SUPER_GALACTIC": Supergalactic(),
            "supergalactic": Supergalactic(),
            "AZ_EL": AltAz(),
        }

        if self.system not in set(match_frames.keys()):
            raise ValueError(
                f"There is no direct correspondence between '{self.system}' and an "
                "astropy frame. This method cannot return a frame."
            )
        return match_frames[self.system]


class TimeSys(SimpleElement):
    """
    TIMESYS_ element: defines a time system.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    _attr_list = ["ID", "timeorigin", "timescale", "refposition"]
    _element_name = "TIMESYS"

    def __init__(
        self,
        ID=None,
        timeorigin=None,
        timescale=None,
        refposition=None,
        id=None,
        config=None,
        pos=None,
        **extra,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        # TIMESYS is supported starting in version 1.4
        if not config.get("version_1_4_or_later"):
            warn_or_raise(W54, W54, config.get("version", "unknown"), config, pos)

        SimpleElement.__init__(self)

        self.ID = resolve_id(ID, id, config, pos)
        self.timeorigin = timeorigin
        self.timescale = timescale
        self.refposition = refposition

        warn_unknown_attrs(
            "TIMESYS",
            extra.keys(),
            config,
            pos,
            ["ID", "timeorigin", "timescale", "refposition"],
        )

    @property
    def ID(self):
        """
        [*required*] The XML ID of the TIMESYS_ element, used for
        cross-referencing.  Must be a string conforming to
        XML ID_ syntax.
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        if ID is None:
            vo_raise(E22, (), self._config, self._pos)
        xmlutil.check_id(ID, "ID", self._config, self._pos)
        self._ID = ID

    @property
    def timeorigin(self):
        """
        Specifies the time origin of the time coordinate,
        given as a Julian Date for the time scale and
        reference point defined. It is usually given as a
        floating point literal; for convenience, the magic
        strings "MJD-origin" (standing for 2400000.5) and
        "JD-origin" (standing for 0) are also allowed.

        The timeorigin attribute MUST be given unless the
        time’s representation contains a year of a calendar
        era, in which case it MUST NOT be present. In VOTables,
        these representations currently are Gregorian calendar
        years with xtype="timestamp", or years in the Julian
        or Besselian calendar when a column has yr, a, or Ba as
        its unit and no time origin is given.
        """
        return self._timeorigin

    @timeorigin.setter
    def timeorigin(self, timeorigin):
        if (
            timeorigin is not None
            and timeorigin != "MJD-origin"
            and timeorigin != "JD-origin"
        ):
            try:
                timeorigin = float(timeorigin)
            except ValueError:
                warn_or_raise(E23, E23, timeorigin, self._config, self._pos)
        self._timeorigin = timeorigin

    @timeorigin.deleter
    def timeorigin(self):
        self._timeorigin = None

    @property
    def timescale(self):
        """
        [*required*] String specifying the time scale used. Values
        should be taken from the IVOA timescale vocabulary (documented
        at http://www.ivoa.net/rdf/timescale).

        Element.__init__(self)
        self._table = table
        self.ref = ref
        self.ucd = ucd
        self.utype = utype

        if config.get("version_1_2_or_later"):
            self._attr_list = self._attr_list_12
        else:
            self._attr_list = self._attr_list_11
            if ucd is not None:
                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
            if utype is not None:
                warn_unknown_attrs(self._element_name, ["utype"], config, pos)

    @property
    def ref(self):
        """The ID_ of the PARAM_ that this PARAMref_ references."""
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None












class Group(
    Element,
    _IDProperty,
    _NameProperty,
    _UtypeProperty,
    _UcdProperty,
    _DescriptionProperty,
):
    """
    GROUP_ element: groups FIELD_ and PARAM_ elements.

    This information is currently ignored by the vo package---that is
    the columns in the recarray are always flat---but the grouping
    information is stored so that it can be written out again to the
    XML file.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    def __init__(
        self,
        table,
        ID=None,
        name=None,
        ref=None,
        ucd=None,
        utype=None,
        id=None,
        config=None,
        pos=None,
        **extra,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        Element.__init__(self)
        self._table = table

        self.ID = resolve_id(ID, id, config, pos) or xmlutil.fix_id(name, config, pos)
        self.name = name
        self.ref = ref
        self.ucd = ucd
        self.utype = utype
        self.description = None

        self._entries = HomogeneousList((FieldRef, ParamRef, Group, Param))

        warn_unknown_attrs("GROUP", extra.keys(), config, pos)

    def __repr__(self):
        return f"<GROUP>... {len(self._entries)} entries ...</GROUP>"

    @property
    def ref(self):
        """
        Currently ignored, as it's not clear from the spec how this is
        meant to work.
        """
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def entries(self):
        """
        [read-only] A list of members of the GROUP_.  This list may
        only contain objects of type :class:`Param`, :class:`Group`,
        :class:`ParamRef` and :class:`FieldRef`.
        """
        return self._entries

    def _add_fieldref(self, iterator, tag, data, config, pos):
        fieldref = FieldRef(self._table, config=config, pos=pos, **data)
        self.entries.append(fieldref)

    def _add_paramref(self, iterator, tag, data, config, pos):
        paramref = ParamRef(self._table, config=config, pos=pos, **data)
        self.entries.append(paramref)

    def _add_param(self, iterator, tag, data, config, pos):
        if isinstance(self._table, VOTableFile):
            votable = self._table
        else:
            votable = self._table._votable
        param = Param(votable, config=config, pos=pos, **data)
        self.entries.append(param)
        param.parse(iterator, config)

    def _add_group(self, iterator, tag, data, config, pos):
        group = Group(self._table, config=config, pos=pos, **data)
        self.entries.append(group)
        group.parse(iterator, config)

    def parse(self, iterator, config):
        tag_mapping = {
            "FIELDref": self._add_fieldref,
            "PARAMref": self._add_paramref,
            "PARAM": self._add_param,
            "GROUP": self._add_group,
            "DESCRIPTION": self._ignore_add,
        }

        for start, tag, data, pos in iterator:
            if start:
                tag_mapping.get(tag, self._add_unknown_tag)(
                    iterator, tag, data, config, pos
                )
            else:
                if tag == "DESCRIPTION":
                    if self.description is not None:
                        warn_or_raise(W17, W17, "GROUP", config, pos)
                    self.description = data or None
                elif tag == "GROUP":
                    break
        return self

    def to_xml(self, w, **kwargs):
        with w.tag(
            "GROUP", attrib=w.object_attrs(self, ["ID", "name", "ref", "ucd", "utype"])
        ):
            if self.description is not None:
                w.element("DESCRIPTION", self.description, wrap=True)
            for entry in self.entries:
                entry.to_xml(w, **kwargs)

    def iter_fields_and_params(self):
        """
        Recursively iterate over all :class:`Param` elements in this
        :class:`Group`.
        """
        for entry in self.entries:
            if isinstance(entry, Param):
                yield entry
            elif isinstance(entry, Group):
                yield from entry.iter_fields_and_params()

    def iter_groups(self):
        """
        Recursively iterate over all sub-:class:`Group` instances in
        this :class:`Group`.
        """
        for entry in self.entries:
            if isinstance(entry, Group):
                yield entry
                yield from entry.iter_groups()


class TableElement(
    Element, _IDProperty, _NameProperty, _UcdProperty, _DescriptionProperty
):
    """
    TABLE_ element: optionally contains data.

    It contains the following publicly-accessible and mutable
    attribute:

        *array*: A Numpy masked array of the data itself, where each
        row is a row of votable data, and columns are named and typed
        based on the <FIELD> elements of the table.  The mask is
        parallel to the data array, except for variable-length fields.
        For those fields, the numpy array's column type is "object"
        (``"O"``), and another masked array is stored there.

    If the TableElement contains no data, (for example, its enclosing
    :class:`Resource` has :attr:`~Resource.type` == 'meta') *array*
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc "git status --short
git diff -- astropy/io/votable/tree.py | sed -n '1,260p'
git diff --stat"
```

退出码：`0`

输出：
```

```

## 原始行 25 · command_execution

命令：
```
/bin/bash -lc "grep -nE \"def to_table_column|def from_table\\(|_attr_list|_version_namespace_map|iter_values\" astropy/io/votable/tree.py | head -250
sed -n '1370,1805p' astropy/io/votable/tree.py
sed -n '3540,4145p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
524:    _attr_list = []
597:        w.element(self._element_name, attrib=w.object_attrs(self, self._attr_list))
626:            attrib=w.object_attrs(self, self._attr_list),
652:    _attr_list = [
757:    def to_table_column(self, column):
759:        for key in self._attr_list:
781:    _attr_list_11 = ["ID", "name", "value"]
782:    _attr_list_12 = _attr_list_11 + ["xtype", "ref", "unit", "ucd", "utype"]
817:            self._attr_list = self._attr_list_12
819:            self._attr_list = self._attr_list_11
942:        attrib = w.object_attrs(self, self._attr_list)
1264:    def to_table_column(self, column):
1319:    _attr_list_11 = [
1331:    _attr_list_12 = _attr_list_11 + ["xtype"]
1360:            self._attr_list = self._attr_list_12
1362:            self._attr_list = self._attr_list_11
1701:        attrib = w.object_attrs(self, self._attr_list)
1719:    def to_table_column(self, column):
1792:    _attr_list_11 = Field._attr_list_11 + ["value"]
1793:    _attr_list_12 = Field._attr_list_12 + ["value"]
1873:    _attr_list = ["ID", "equinox", "epoch", "system", "refposition"]
2064:    _attr_list = ["ID", "timeorigin", "timescale", "refposition"]
2195:    _attr_list_11 = ["ref"]
2196:    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
2223:            self._attr_list = self._attr_list_12
2225:            self._attr_list = self._attr_list_11
2268:    _attr_list_11 = ["ref"]
2269:    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
2288:            self._attr_list = self._attr_list_12
2290:            self._attr_list = self._attr_list_11
3547:    def from_table(cls, votable, table):
3861:        w.element(self._element_name, attrib=w.object_attrs(self, self._attr_list))
4190:        if version not in self._version_namespace_map:
4191:            allowed_from_map = "', '".join(self._version_namespace_map)
4292:    _version_namespace_map = {
4358:                        if config["version"] not in self._version_namespace_map:
4368:                        ns_info = self._version_namespace_map.get(config["version"], {})
4464:            ns_info = self._version_namespace_map.get(version, {})
4588:        "iter_values",
4689:    def from_table(cls, table, table_id=None):
        # actually contains character data.  We have to hack the field
        # to store character data, or we can't read it in.  A warning
        # will be raised when this happens.
        if (
            self._config.get("verify", "ignore") != "exception"
            and name == "cprojection"
            and ID == "cprojection"
            and ucd == "VOX:WCS_CoordProjection"
            and datatype == "double"
        ):
            datatype = "char"
            arraysize = "3"
            vo_warn(W40, (), config, pos)
        # ----------------------------------------

        self.description = None
        self._votable = votable

        self.ID = resolve_id(ID, id, config, pos) or xmlutil.fix_id(name, config, pos)
        self.name = name
        if name is None:
            if self._element_name == "PARAM" and not self._config.get(
                "version_1_1_or_later"
            ):
                pass
            else:
                warn_or_raise(W15, W15, self._element_name, config, pos)
            self.name = self.ID

        if self._ID is None and name is None:
            vo_raise(W12, self._element_name, config, pos)

        datatype_mapping = {
            "string": "char",
            "unicodeString": "unicodeChar",
            "int16": "short",
            "int32": "int",
            "int64": "long",
            "float32": "float",
            "float64": "double",
            # The following appear in some Vizier tables
            "unsignedInt": "long",
            "unsignedShort": "int",
        }

        datatype_mapping.update(self._config.get("datatype_mapping", {}))

        if datatype in datatype_mapping:
            warn_or_raise(W13, W13, (datatype, datatype_mapping[datatype]), config, pos)
            datatype = datatype_mapping[datatype]

        self.ref = ref
        self.datatype = datatype
        self.arraysize = arraysize
        self.ucd = ucd
        self.unit = unit
        self.width = width
        self.precision = precision
        self.utype = utype
        self.type = type
        self._links = HomogeneousList(Link)
        self.title = self.name
        self.values = Values(self._votable, self)
        self.xtype = xtype

        self._setup(config, pos)

        warn_unknown_attrs(self._element_name, extra.keys(), config, pos)

    @classmethod
    def uniqify_names(cls, fields):
        """
        Make sure that all names and titles in a list of fields are
        unique, by appending numbers if necessary.
        """
        unique = {}
        for field in fields:
            i = 2
            new_id = field.ID
            while new_id in unique:
                new_id = field.ID + f"_{i:d}"
                i += 1
            if new_id != field.ID:
                vo_warn(W32, (field.ID, new_id), field._config, field._pos)
            field.ID = new_id
            unique[new_id] = field.ID

        for field in fields:
            i = 2
            if field.name is None:
                new_name = field.ID
                implicit = True
            else:
                new_name = field.name
                implicit = False
            if new_name != field.ID:
                while new_name in unique:
                    new_name = field.name + f" {i:d}"
                    i += 1

            if not implicit and new_name != field.name:
                vo_warn(W33, (field.name, new_name), field._config, field._pos)
            field._unique_name = new_name
            unique[new_name] = field.name

    def _setup(self, config, pos):
        if self.values._ref is not None:
            self.values.ref = self.values._ref
        self.converter = converters.get_converter(self, config, pos)

    @property
    def datatype(self):
        """The datatype of the column [*required*].

        Valid values (as defined by the spec) are:

          'boolean', 'bit', 'unsignedByte', 'short', 'int', 'long',
          'char', 'unicodeChar', 'float', 'double', 'floatComplex', or
          'doubleComplex'

        Many VOTABLE files in the wild use 'string' instead of 'char',
        so that is also a valid option, though 'string' will always be
        converted to 'char' when writing the file back out.
        """
        return self._datatype

    @datatype.setter
    def datatype(self, datatype):
        if datatype is None:
            if self._config.get("version_1_1_or_later"):
                warn_or_raise(E10, E10, self._element_name, self._config, self._pos)
            datatype = "char"
        if datatype not in converters.converter_mapping:
            vo_raise(E06, (datatype, self.ID), self._config, self._pos)
        self._datatype = datatype

    @property
    def precision(self):
        """
        Along with :attr:`width`, defines the `numerical accuracy`_
        associated with the data.  These values are used to limit the
        precision when writing floating point values back to the XML
        file.  Otherwise, it is purely informational -- the Numpy
        recarray containing the data itself does not use this
        information.
        """
        return self._precision

    @precision.setter
    def precision(self, precision):
        if precision is not None and not re.match(r"^[FE]?[0-9]+$", precision):
            vo_raise(E11, precision, self._config, self._pos)
        self._precision = precision

    @precision.deleter
    def precision(self):
        self._precision = None

    @property
    def width(self):
        """
        Along with :attr:`precision`, defines the `numerical
        accuracy`_ associated with the data.  These values are used to
        limit the precision when writing floating point values back to
        the XML file.  Otherwise, it is purely informational -- the
        Numpy recarray containing the data itself does not use this
        information.
        """
        return self._width

    @width.setter
    def width(self, width):
        if width is not None:
            width = int(width)
            if width <= 0:
                vo_raise(E12, width, self._config, self._pos)
        self._width = width

    @width.deleter
    def width(self):
        self._width = None

    # ref on FIELD and PARAM behave differently than elsewhere -- here
    # they're just informational, such as to refer to a coordinate
    # system.
    @property
    def ref(self):
        """
        On FIELD_ elements, ref is used only for informational
        purposes, for example to refer to a COOSYS_ or TIMESYS_ element.
        """
        return self._ref

    @ref.setter
    def ref(self, ref):
        xmlutil.check_id(ref, "ref", self._config, self._pos)
        self._ref = ref

    @ref.deleter
    def ref(self):
        self._ref = None

    @property
    def unit(self):
        """A string specifying the units_ for the FIELD_."""
        return self._unit

    @unit.setter
    def unit(self, unit):
        if unit is None:
            self._unit = None
            return

        from astropy import units as u

        # First, parse the unit in the default way, so that we can
        # still emit a warning if the unit is not to spec.
        default_format = _get_default_unit_format(self._config)
        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
        if isinstance(unit_obj, u.UnrecognizedUnit):
            warn_or_raise(W50, W50, (unit,), self._config, self._pos)

        format = _get_unit_format(self._config)
        if format != default_format:
            unit_obj = u.Unit(unit, format=format, parse_strict="silent")

        self._unit = unit_obj

    @unit.deleter
    def unit(self):
        self._unit = None

    @property
    def arraysize(self):
        """
        Specifies the size of the multidimensional array if this
        FIELD_ contains more than a single value.

        See `multidimensional arrays`_.
        """
        return self._arraysize

    @arraysize.setter
    def arraysize(self, arraysize):
        if arraysize is not None and not re.match(
            r"^([0-9]+x)*[0-9]*[*]?(s\W)?$", arraysize
        ):
            vo_raise(E13, arraysize, self._config, self._pos)
        self._arraysize = arraysize

    @arraysize.deleter
    def arraysize(self):
        self._arraysize = None

    @property
    def type(self):
        """
        The type attribute on FIELD_ elements is reserved for future
        extensions.
        """
        return self._type

    @type.setter
    def type(self, type):
        self._type = type

    @type.deleter
    def type(self):
        self._type = None

    @property
    def values(self):
        """
        A :class:`Values` instance (or `None`) defining the domain
        of the column.
        """
        return self._values

    @values.setter
    def values(self, values):
        assert values is None or isinstance(values, Values)
        self._values = values

    @values.deleter
    def values(self):
        self._values = None

    @property
    def links(self):
        """
        A list of :class:`Link` instances used to reference more
        details about the meaning of the FIELD_.  This is purely
        informational and is not used by the `astropy.io.votable`
        package.
        """
        return self._links

    def parse(self, iterator, config):
        for start, tag, data, pos in iterator:
            if start:
                if tag == "VALUES":
                    self.values.__init__(
                        self._votable, self, config=config, pos=pos, **data
                    )
                    self.values.parse(iterator, config)
                elif tag == "LINK":
                    link = Link(config=config, pos=pos, **data)
                    self.links.append(link)
                    link.parse(iterator, config)
                elif tag == "DESCRIPTION":
                    warn_unknown_attrs("DESCRIPTION", data.keys(), config, pos)
                elif tag != self._element_name:
                    self._add_unknown_tag(iterator, tag, data, config, pos)
            else:
                if tag == "DESCRIPTION":
                    if self.description is not None:
                        warn_or_raise(W17, W17, self._element_name, config, pos)
                    self.description = data or None
                elif tag == self._element_name:
                    break

        if self.description is not None:
            self.title = " ".join(x.strip() for x in self.description.splitlines())
        else:
            self.title = self.name

        self._setup(config, pos)

        return self

    def to_xml(self, w, **kwargs):
        attrib = w.object_attrs(self, self._attr_list)
        if "unit" in attrib:
            format = _get_unit_format(self._config)
            try:
                attrib["unit"] = self.unit.to_string(format)
            except ValueError as e:
                # Allow non-standard units with a warning, see
                # https://github.com/astropy/astropy/issues/17497#issuecomment-2520472495
                attrib["unit"] = self.unit.to_string()
                warn_or_raise(W50, W50, (attrib["unit"],), self._config, self._pos)
        with w.tag(self._element_name, attrib=attrib):
            if self.description is not None:
                w.element("DESCRIPTION", self.description, wrap=True)
            if not self.values.is_defaults():
                self.values.to_xml(w, **kwargs)
            for link in self.links:
                link.to_xml(w, **kwargs)

    def to_table_column(self, column):
        """
        Sets the attributes of a given `astropy.table.Column` instance
        to match the information in this `Field`.
        """
        for key in ["ucd", "width", "precision", "utype", "xtype"]:
            val = getattr(self, key, None)
            if val is not None:
                column.meta[key] = val
        if not self.values.is_defaults():
            self.values.to_table_column(column)
        for link in self.links:
            link.to_table_column(column)
        if self.description is not None:
            column.description = self.description
        if self.unit is not None:
            # TODO: Use units framework when it's available
            column.unit = self.unit
        if (
            isinstance(self.converter, converters.FloatingPoint)
            and self.converter.output_format != "{!s:>}"
        ):
            column.format = self.converter.output_format
        elif isinstance(self.converter, converters.Char):
            column.info.meta["_votable_string_dtype"] = "char"
            if self.arraysize is not None and self.arraysize.endswith("*"):
                column.info.meta["_votable_arraysize"] = self.arraysize
        elif isinstance(self.converter, converters.UnicodeChar):
            column.info.meta["_votable_string_dtype"] = "unicodeChar"
            if self.arraysize is not None and self.arraysize.endswith("*"):
                column.info.meta["_votable_arraysize"] = self.arraysize

    @classmethod
    def from_table_column(cls, votable, column):
        """
        Restores a `Field` instance from a given
        `astropy.table.Column` instance.
        """
        kwargs = {}
        meta = column.info.meta
        if meta:
            for key in ["ucd", "width", "precision", "utype", "xtype"]:
                val = meta.get(key, None)
                if val is not None:
                    kwargs[key] = val
        # TODO: Use the unit framework when available
        if column.info.unit is not None:
            kwargs["unit"] = column.info.unit
        kwargs["name"] = column.info.name
        result = converters.table_column_to_votable_datatype(column)
        kwargs.update(result)

        field = cls(votable, **kwargs)

        if column.info.description is not None:
            field.description = column.info.description
        field.values.from_table_column(column)
        if meta and "links" in meta:
            for link in meta["links"]:
                field.links.append(Link.from_table_column(link))

        # TODO: Parse format into precision and width
        return field


class Param(Field):
    """
    PARAM_ element: constant-valued columns in the data.

    :class:`Param` objects are a subclass of :class:`Field`, and have
    all of its methods and members.  Additionally, it defines :attr:`value`.
    """

    _attr_list_11 = Field._attr_list_11 + ["value"]
    _attr_list_12 = Field._attr_list_12 + ["value"]
    _element_name = "PARAM"

    def __init__(
        self,
        votable,
        ID=None,
        name=None,
        value=None,
        datatype=None,
        arraysize=None,
        ucd=None,
        unit=None,






    @classmethod
    def from_table(cls, votable, table):
        """
        Create a `TableElement` instance from a given `astropy.table.Table`
        instance.
        """
        kwargs = {}
        for key in ["ID", "name", "ref", "ucd", "utype"]:
            val = table.meta.get(key)
            if val is not None:
                kwargs[key] = val
        new_table = cls(votable, **kwargs)
        if "description" in table.meta:
            new_table.description = table.meta["description"]

        for colname in table.colnames:
            column = table[colname]
            new_table.add_field(Field.from_table_column(votable, column))

        if table.mask is None:
            new_table.array = ma.array(np.asarray(table))
        else:
            new_table.array = ma.array(np.asarray(table), mask=np.asarray(table.mask))

        return new_table

    def iter_fields_and_params(self):
        """
        Recursively iterate over all FIELD and PARAM elements in the
        TABLE.
        """
        yield from self.params
        yield from self.all_fields
        for group in self.groups:
            yield from group.iter_fields_and_params()

    get_field_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_fields_and_params",
        "FIELD or PARAM",
        """
        Looks up a FIELD or PARAM element by the given ID.
        """,
    )

    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
        "iter_fields_and_params",
        "FIELD or PARAM",
        """
        Looks up a FIELD or PARAM element by the given ID or name.
        """,
    )

    get_fields_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_fields_and_params",
        "FIELD or PARAM",
        """
        Looks up a FIELD or PARAM element by the given utype and
        returns an iterator emitting all matches.
        """,
    )

    def iter_groups(self):
        """
        Recursively iterate over all GROUP elements in the TABLE.
        """
        for group in self.groups:
            yield group
            yield from group.iter_groups()

    get_group_by_id = _lookup_by_attr_factory(
        "ID",
        True,
        "iter_groups",
        "GROUP",
        """
        Looks up a GROUP element by the given ID.  Used by the group's
        "ref" attribute
        """,
    )

    get_groups_by_utype = _lookup_by_attr_factory(
        "utype",
        False,
        "iter_groups",
        "GROUP",
        """
        Looks up a GROUP element by the given utype and returns an
        iterator emitting all matches.
        """,
    )

    def iter_info(self):
        yield from self.infos


class MivotBlock(Element):
    """
    MIVOT Block holder:
    Processing VO model views on data is out of the scope of Astropy.
    This is why the only VOmodel-related feature implemented here the
    extraction or the writing of a mapping block from/to a VOTable
    There is no syntax validation other than the allowed tag names.
    The mapping block is handled as a correctly indented XML string
    which is meant to be parsed by the calling API (e.g., PyVO).

    The constructor takes "content" as a parameter, it is the string
    serialization of the MIVOT block.
    If it is None, the instance is meant to be set by the Resource parser.
    Orherwise, the parameter value is parsed to make sure it matches
    the MIVOT XML structure.

    """

    def __init__(self, content=None):
        if content is not None:
            self._content = content.strip()
            self.check_content_format()
        else:
            self._content = ""
        self._indent_level = 0
        self._on_error = False




    def _add_statement(self, start, tag, data, config, pos):
        """
        Convert the tag as a string and append it to the mapping
        block string with the correct indentation level.
        The signature is the same as for all _add_* methods of the parser.
        """
        if self._on_error is True:
            return
        # The first mapping tag (<VODML>) is consumed by the host RESOURCE
        # To check that the content is a mapping block. This cannot be done here
        # because that RESOURCE might have another content
        if self._content == "":
            self._content = '<VODML xmlns="http://www.ivoa.net/xml/mivot">\n'
            self._indent_level += 1

        ele_content = ""
        if start:
            element = "<" + tag
            for k, v in data.items():
                element += f" {k}='{v}'"
            element += ">\n"
        else:
            if data:
                ele_content = f"{data}\n"
            element = f"</{tag}>\n"

        if start is False:
            self._indent_level -= 1
        # The content is formatted on the fly: not mandatory but cool for debugging
        indent = "".join(" " for _ in range(2 * self._indent_level))
        if ele_content:
            self._content += indent + "  " + ele_content
        self._content += indent + element
        if start is True:
            self._indent_level += 1

    def _unknown_mapping_tag(self, start, tag, data, config, pos):
        """
        In case of unexpected tag, the parsing stops and the mapping block
        is set with a REPORT tag telling what went wrong.
        The signature si that same as for all _add_* methods of the parser.
        """
        self._content = (
            f'<VODML xmlns="http://www.ivoa.net/xml/mivot">\n '
            f'<REPORT status="KO">Unknown mivot block statement: {tag}</REPORT>\n</VODML>'
        )
        self._on_error = True
        warn_or_raise(W10, W10, tag, config, pos=pos)

    @property
    def content(self):
        """
        The XML mapping block serialized as string.
        If there is not mapping block, an empty block is returned in order to
        prevent client code to deal with None blocks.
        """
        if self._content == "":
            self._content = (
                '<VODML xmlns="http://www.ivoa.net/xml/mivot">\n '
                '<REPORT status="KO">No Mivot block</REPORT>\n</VODML>\n'
            )
        return self._content

    def parse(self, votable, iterator, config):
        """
        Regular parser similar to others VOTable components.
        """
        model_mapping_mapping = {
            "VODML": self._add_statement,
            "GLOBALS": self._add_statement,
            "REPORT": self._add_statement,
            "MODEL": self._add_statement,
            "TEMPLATES": self._add_statement,
            "COLLECTION": self._add_statement,
            "INSTANCE": self._add_statement,
            "ATTRIBUTE": self._add_statement,
            "REFERENCE": self._add_statement,
            "JOIN": self._add_statement,
            "WHERE": self._add_statement,
            "PRIMARY_KEY": self._add_statement,
            "FOREIGN_KEY": self._add_statement,
        }
        for start, tag, data, pos in iterator:
            model_mapping_mapping.get(tag, self._unknown_mapping_tag)(
                start, tag, data, config, pos
            )
            if start is False and tag == "VODML":
                break

        return self

    def to_xml(self, w):
        """
        Tells the writer to insert the MIVOT block in its output stream.
        """
        w.string_element(self._content)

    def check_content_format(self):
        """
        Check if the content is on xml format by building a VOTable,
        putting a MIVOT block in the first resource and trying to parse the VOTable.
        """
        if not self._content.startswith("<"):
            vo_raise(E26)

        in_memory_votable = VOTableFile()
        mivot_resource = Resource()
        mivot_resource.type = "meta"
        mivot_resource.mivot_block = self
        # pack the meta resource in a top level resource
        result_resource = Resource()
        result_resource.type = "results"
        result_resource.resources.append(mivot_resource)
        data_table = TableElement(in_memory_votable)
        data_table.name = "t1"
        result_resource.tables.append(data_table)
        in_memory_votable.resources.append(result_resource)

        # Push the VOTable in an IOSTream (emulates a disk saving)
        buff = io.BytesIO()
        in_memory_votable.to_xml(buff)

        # Read the IOStream (emulates a disk readout)
        buff.seek(0)
        config = {}

        with iterparser.get_xml_iterator(
            buff, _debug_python_based_parser=None
        ) as iterator:
            return VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)


@deprecated("6.0", alternative="TableElement")
class Table(TableElement):
    pass


class Resource(
    Element, _IDProperty, _NameProperty, _UtypeProperty, _DescriptionProperty
):
    """
    RESOURCE_ element: Groups TABLE_ and RESOURCE_ elements.

    The keyword arguments correspond to setting members of the same
    name, documented below.
    """

    def __init__(
        self,
        name=None,
        ID=None,
        utype=None,
        type="results",
        id=None,
        config=None,
        pos=None,
        **kwargs,
    ):
        if config is None:
            config = {}
        self._config = config
        self._pos = pos

        Element.__init__(self)
        self.name = name
        self.ID = resolve_id(ID, id, config, pos)
        self.utype = utype
        self.type = type
        self._extra_attributes = kwargs
        self.description = None

        self._coordinate_systems = HomogeneousList(CooSys)
        self._time_systems = HomogeneousList(TimeSys)
        self._groups = HomogeneousList(Group)
        self._params = HomogeneousList(Param)
        self._infos = HomogeneousList(Info)
        self._links = HomogeneousList(Link)
        self._tables = HomogeneousList(TableElement)
        self._resources = HomogeneousList(Resource)

        self._mivot_block = MivotBlock()
        warn_unknown_attrs("RESOURCE", kwargs.keys(), config, pos)

    def __repr__(self):
        buff = io.StringIO()
        w = XMLWriter(buff)
        w.element(self._element_name, attrib=w.object_attrs(self, self._attr_list))
        return buff.getvalue().strip()

    @property
    def type(self):
        """The type of the resource [*required*].

        Must be either:

          - 'results': This resource contains actual result values
            (default)

          - 'meta': This resource contains only datatype descriptions
            (FIELD_ elements), but no actual data.
        """
        return self._type

    @type.setter
    def type(self, type):
        if type not in ("results", "meta"):
            vo_raise(E18, type, self._config, self._pos)
        self._type = type

    @property
    def mivot_block(self):
        """
        Returns the MIVOT block instance.
        If the host resource is of type results, it is taken from the first
        child resource with a MIVOT block, if any.
        Otherwise, it is taken from the host resource.
        """
        if self.type == "results":
            for resource in self.resources:
                if str(resource._mivot_block).strip() != "":
                    return resource._mivot_block
        return self._mivot_block

    @mivot_block.setter
    def mivot_block(self, mivot_block):
        if self.type == "results":
            vo_raise(E26)
        self._mivot_block = mivot_block

    @property
    def extra_attributes(self):
        """Dictionary of extra attributes of the RESOURCE_ element.

        This is dictionary of string keys to string values containing any
        extra attributes of the RESOURCE_ element that are not defined
        in the specification. The specification explicitly allows
        for extra attributes here, but nowhere else.
        """
        return self._extra_attributes

    @property
    def coordinate_systems(self):
        """
        A list of coordinate system definitions (COOSYS_ elements) for
        the RESOURCE_.  Must contain only `CooSys` objects.
        """
        return self._coordinate_systems

    @property
    def time_systems(self):
        """
        A list of time system definitions (TIMESYS_ elements) for
        the RESOURCE_.  Must contain only `TimeSys` objects.
        """
        return self._time_systems

    @property
    def infos(self):
        """
        A list of informational parameters (key-value pairs) for the
        resource.  Must only contain `Info` objects.
        """
        return self._infos

    @property
    def groups(self):
        """
        A list of groups.
        """
        return self._groups

    @property
    def params(self):
        """
        A list of parameters (constant-valued columns) for the
        resource.  Must contain only `Param` objects.
        """
        return self._params

    @property
    def links(self):
        """
        A list of links (pointers to other documents or servers
        through a URI) for the resource.  Must contain only `Link`
        objects.
        """
        return self._links

    @property
    def tables(self):
        """
        A list of tables in the resource.  Must contain only
        `TableElement` objects.
        """
        return self._tables

    @property
    def resources(self):
        """
        A list of nested resources inside this resource.  Must contain
        only `Resource` objects.
        """
        return self._resources

    def _add_table(self, iterator, tag, data, config, pos):
        table = TableElement(self._votable, config=config, pos=pos, **data)
        self.tables.append(table)
        table.parse(iterator, config)

    def _add_info(self, iterator, tag, data, config, pos):
        info = Info(config=config, pos=pos, **data)
        self.infos.append(info)
        info.parse(iterator, config)

    def _add_group(self, iterator, tag, data, config, pos):
        group = Group(self, config=config, pos=pos, **data)
        self.groups.append(group)
        group.parse(iterator, config)

    def _add_param(self, iterator, tag, data, config, pos):
        param = Param(self._votable, config=config, pos=pos, **data)
        self.params.append(param)
        param.parse(iterator, config)

    def _add_coosys(self, iterator, tag, data, config, pos):
        coosys = CooSys(config=config, pos=pos, **data)
        self.coordinate_systems.append(coosys)
        coosys.parse(iterator, config)

    def _add_timesys(self, iterator, tag, data, config, pos):
        timesys = TimeSys(config=config, pos=pos, **data)
        self.time_systems.append(timesys)
        timesys.parse(iterator, config)

    def _add_resource(self, iterator, tag, data, config, pos):
        resource = Resource(config=config, pos=pos, **data)
        self.resources.append(resource)
        resource.parse(self._votable, iterator, config)

    def _add_link(self, iterator, tag, data, config, pos):
        link = Link(config=config, pos=pos, **data)
        self.links.append(link)
        link.parse(iterator, config)

    def parse(self, votable, iterator, config):
        self._votable = votable

        tag_mapping = {
            "TABLE": self._add_table,
            "INFO": self._add_info,
            "PARAM": self._add_param,
            "GROUP": self._add_group,
            "COOSYS": self._add_coosys,
            "TIMESYS": self._add_timesys,
            "RESOURCE": self._add_resource,
            "LINK": self._add_link,
            "DESCRIPTION": self._ignore_add,
        }

        for start, tag, data, pos in iterator:
            # If the resource content starts with VODML,
            # the parsing is delegated to the MIVOT parser
            if tag == "VODML":
                self._mivot_block.parse(votable, iterator, config)
            elif start:
                tag_mapping.get(tag, self._add_unknown_tag)(
                    iterator, tag, data, config, pos
                )
            elif tag == "DESCRIPTION":
                if self.description is not None:
                    warn_or_raise(W17, W17, "RESOURCE", config, pos)
                self.description = data or None
            elif tag == "RESOURCE":
                break

        del self._votable

        return self

    def to_xml(self, w, **kwargs):
        attrs = w.object_attrs(self, ("ID", "type", "utype"))
        attrs.update(self.extra_attributes)
        with w.tag("RESOURCE", attrib=attrs):
            if self.description is not None:
                w.element("DESCRIPTION", self.description, wrap=True)
            if self.mivot_block is not None and self.type == "meta":
                self.mivot_block.to_xml(w)
            element_sets = [
                self.infos,
                self.coordinate_systems,
                self.time_systems,
                self.params,
                self.links,
            ]
            if kwargs["version_1_2_or_later"]:
                element_sets.append(self.groups)

            for element_set in element_sets:
                for element in element_set:
                    element.to_xml(w, **kwargs)

            # The mivot_block should be before the table
            for elm in self.resources:
                if elm.type == "meta" and elm.mivot_block is not None:
                    elm.to_xml(w, **kwargs)

            for elm in self.tables:
                elm.to_xml(w, **kwargs)

            for elm in self.resources:
                if elm.type != "meta":
                    elm.to_xml(w, **kwargs)

    def iter_tables(self):
        """
        Recursively iterates over all tables in the resource and
        nested resources.
        """
        yield from self.tables
        for resource in self.resources:
            yield from resource.iter_tables()

    def iter_fields_and_params(self):
        """
        Recursively iterates over all FIELD_ and PARAM_ elements in
        the resource, its tables and nested resources.
        """
        yield from self.params
        for table in self.tables:
            yield from table.iter_fields_and_params()
        for resource in self.resources:
            yield from resource.iter_fields_and_params()

    def iter_coosys(self):
        """
        Recursively iterates over all the COOSYS_ elements in the
        resource and nested resources.
        """
        yield from self.coordinate_systems
        for resource in self.resources:
            yield from resource.iter_coosys()

    def iter_timesys(self):
        """
        Recursively iterates over all the TIMESYS_ elements in the
        resource and nested resources.
        """
        yield from self.time_systems
        for resource in self.resources:
            yield from resource.iter_timesys()

    def iter_info(self):
        """
        Recursively iterates over all the INFO_ elements in the
        resource and nested resources.
        """
        yield from self.infos
        for table in self.tables:
            yield from table.iter_info()
        for resource in self.resources:
            yield from resource.iter_info()


class VOTableFile(Element, _IDProperty, _DescriptionProperty):
    """
    VOTABLE_ element: represents an entire file.

    The keyword arguments correspond to setting members of the same
    name, documented below.

    *version* is settable at construction time only, since conformance
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '2240,2325p'
nl -ba astropy/io/votable/tree.py | sed -n '3460,3615p'
nl -ba astropy/io/votable/tree.py | sed -n '4130,4630p'"
```

退出码：`0`

输出：
```
  2240	
  2241	    @ref.deleter
  2242	    def ref(self):
  2243	        self._ref = None
  2244	
  2245	    def get_ref(self):
  2246	        """
  2247	        Lookup the :class:`Field` instance that this :class:`FieldRef`
  2248	        references.
  2249	        """
  2250	        for field in self._table._votable.iter_fields_and_params():
  2251	            if isinstance(field, Field) and field.ID == self.ref:
  2252	                return field
  2253	        vo_raise(KeyError, f"No field named '{self.ref}'", self._config, self._pos)
  2254	
  2255	
  2256	class ParamRef(SimpleElement, _UtypeProperty, _UcdProperty):
  2257	    """
  2258	    PARAMref_ element: used inside of GROUP_ elements to refer to remote PARAM_ elements.
  2259	
  2260	    The keyword arguments correspond to setting members of the same
  2261	    name, documented below.
  2262	
  2263	    It contains the following publicly-accessible members:
  2264	
  2265	      *ref*: An XML ID referring to a <PARAM> element.
  2266	    """
  2267	
  2268	    _attr_list_11 = ["ref"]
  2269	    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
  2270	    _element_name = "PARAMref"
  2271	    _utype_in_v1_2 = True
  2272	    _ucd_in_v1_2 = True
  2273	
  2274	    def __init__(self, table, ref, ucd=None, utype=None, config=None, pos=None):
  2275	        if config is None:
  2276	            config = {}
  2277	
  2278	        self._config = config
  2279	        self._pos = pos
  2280	
  2281	        Element.__init__(self)
  2282	        self._table = table
  2283	        self.ref = ref
  2284	        self.ucd = ucd
  2285	        self.utype = utype
  2286	
  2287	        if config.get("version_1_2_or_later"):
  2288	            self._attr_list = self._attr_list_12
  2289	        else:
  2290	            self._attr_list = self._attr_list_11
  2291	            if ucd is not None:
  2292	                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
  2293	            if utype is not None:
  2294	                warn_unknown_attrs(self._element_name, ["utype"], config, pos)
  2295	
  2296	    @property
  2297	    def ref(self):
  2298	        """The ID_ of the PARAM_ that this PARAMref_ references."""
  2299	        return self._ref
  2300	
  2301	    @ref.setter
  2302	    def ref(self, ref):
  2303	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  2304	        self._ref = ref
  2305	
  2306	    @ref.deleter
  2307	    def ref(self):
  2308	        self._ref = None
  2309	
  2310	
  2311	
  2312	
  2313	
  2314	
  2315	
  2316	
  2317	
  2318	
  2319	
  2320	
  2321	class Group(
  2322	    Element,
  2323	    _IDProperty,
  2324	    _NameProperty,
  2325	    _UtypeProperty,
  3460	        with w.tag(tag_name):
  3461	            with w.tag("STREAM", encoding="base64"):
  3462	                fields_basic = [
  3463	                    (i, field.converter.binoutput) for (i, field) in enumerate(fields)
  3464	                ]
  3465	
  3466	                data = io.BytesIO()
  3467	                for row in range(len(array)):
  3468	                    array_row = array.data[row]
  3469	                    array_mask = array.mask[row]
  3470	                    if mode == 2:
  3471	                        flattened = np.array([np.all(x) for x in array_mask])
  3472	                        data.write(converters.bool_to_bitarray(flattened))
  3473	
  3474	                    for i, converter in fields_basic:
  3475	                        try:
  3476	                            # BINARY2 cannot handle individual array element masks
  3477	                            converter_type = converter.__self__.__class__
  3478	                            # Delegate converter to handle the mask
  3479	                            delegate_condition = issubclass(
  3480	                                converter_type, converters.Array
  3481	                            )
  3482	                            if mode == 1 or delegate_condition:
  3483	                                chunk = converter(array_row[i], array_mask[i])
  3484	                            else:
  3485	                                # Mask is already handled by BINARY2 behaviour
  3486	                                chunk = converter(array_row[i], None)
  3487	                            assert type(chunk) == bytes
  3488	                        except Exception as e:
  3489	                            vo_reraise(
  3490	                                e, additional=f"(in row {row:d}, col '{fields[i].ID}')"
  3491	                            )
  3492	                        data.write(chunk)
  3493	
  3494	                w._flush()
  3495	                w.write(base64.b64encode(data.getvalue()).decode("ascii"))
  3496	
  3497	
  3498	
  3499	
  3500	
  3501	
  3502	
  3503	
  3504	
  3505	
  3506	
  3507	
  3508	
  3509	
  3510	
  3511	
  3512	
  3513	
  3514	
  3515	
  3516	
  3517	
  3518	
  3519	
  3520	
  3521	
  3522	
  3523	
  3524	
  3525	
  3526	
  3527	
  3528	
  3529	
  3530	
  3531	
  3532	
  3533	
  3534	
  3535	
  3536	
  3537	
  3538	
  3539	
  3540	
  3541	
  3542	
  3543	
  3544	
  3545	
  3546	    @classmethod
  3547	    def from_table(cls, votable, table):
  3548	        """
  3549	        Create a `TableElement` instance from a given `astropy.table.Table`
  3550	        instance.
  3551	        """
  3552	        kwargs = {}
  3553	        for key in ["ID", "name", "ref", "ucd", "utype"]:
  3554	            val = table.meta.get(key)
  3555	            if val is not None:
  3556	                kwargs[key] = val
  3557	        new_table = cls(votable, **kwargs)
  3558	        if "description" in table.meta:
  3559	            new_table.description = table.meta["description"]
  3560	
  3561	        for colname in table.colnames:
  3562	            column = table[colname]
  3563	            new_table.add_field(Field.from_table_column(votable, column))
  3564	
  3565	        if table.mask is None:
  3566	            new_table.array = ma.array(np.asarray(table))
  3567	        else:
  3568	            new_table.array = ma.array(np.asarray(table), mask=np.asarray(table.mask))
  3569	
  3570	        return new_table
  3571	
  3572	    def iter_fields_and_params(self):
  3573	        """
  3574	        Recursively iterate over all FIELD and PARAM elements in the
  3575	        TABLE.
  3576	        """
  3577	        yield from self.params
  3578	        yield from self.all_fields
  3579	        for group in self.groups:
  3580	            yield from group.iter_fields_and_params()
  3581	
  3582	    get_field_by_id = _lookup_by_attr_factory(
  3583	        "ID",
  3584	        True,
  3585	        "iter_fields_and_params",
  3586	        "FIELD or PARAM",
  3587	        """
  3588	        Looks up a FIELD or PARAM element by the given ID.
  3589	        """,
  3590	    )
  3591	
  3592	    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
  3593	        "iter_fields_and_params",
  3594	        "FIELD or PARAM",
  3595	        """
  3596	        Looks up a FIELD or PARAM element by the given ID or name.
  3597	        """,
  3598	    )
  3599	
  3600	    get_fields_by_utype = _lookup_by_attr_factory(
  3601	        "utype",
  3602	        False,
  3603	        "iter_fields_and_params",
  3604	        "FIELD or PARAM",
  3605	        """
  3606	        Looks up a FIELD or PARAM element by the given utype and
  3607	        returns an iterator emitting all matches.
  3608	        """,
  3609	    )
  3610	
  3611	    def iter_groups(self):
  3612	        """
  3613	        Recursively iterate over all GROUP elements in the TABLE.
  3614	        """
  3615	        for group in self.groups:
  4130	        """
  4131	        yield from self.infos
  4132	        for table in self.tables:
  4133	            yield from table.iter_info()
  4134	        for resource in self.resources:
  4135	            yield from resource.iter_info()
  4136	
  4137	
  4138	class VOTableFile(Element, _IDProperty, _DescriptionProperty):
  4139	    """
  4140	    VOTABLE_ element: represents an entire file.
  4141	
  4142	    The keyword arguments correspond to setting members of the same
  4143	    name, documented below.
  4144	
  4145	    *version* is settable at construction time only, since conformance
  4146	    tests for building the rest of the structure depend on it.
  4147	    """
  4148	
  4149	    def __init__(self, ID=None, id=None, config=None, pos=None, version="1.4"):
  4150	        self._config = config.copy() if config is not None else {}
  4151	
  4152	        # Version setter forces the associated version config settings to
  4153	        # be calculated.
  4154	        self.version = version
  4155	        self._pos = pos
  4156	
  4157	        Element.__init__(self)
  4158	        self.ID = resolve_id(ID, id, config, pos)
  4159	        self.description = None
  4160	
  4161	        self._coordinate_systems = HomogeneousList(CooSys)
  4162	        self._time_systems = HomogeneousList(TimeSys)
  4163	        self._params = HomogeneousList(Param)
  4164	        self._infos = HomogeneousList(Info)
  4165	        self._resources = HomogeneousList(Resource)
  4166	        self._groups = HomogeneousList(Group)
  4167	
  4168	
  4169	
  4170	
  4171	
  4172	    @property
  4173	    def config(self):
  4174	        """
  4175	        Configuration used to construct this object. Will always include the
  4176	        version check values.
  4177	        """
  4178	        return self._config
  4179	
  4180	    @property
  4181	    def version(self):
  4182	        """
  4183	        The version of the VOTable specification that the file uses.
  4184	        """
  4185	        return self._version
  4186	
  4187	    @version.setter
  4188	    def version(self, version):
  4189	        version = str(version)
  4190	        if version not in self._version_namespace_map:
  4191	            allowed_from_map = "', '".join(self._version_namespace_map)
  4192	            raise ValueError(
  4193	                f"astropy.io.votable version should be in ('{allowed_from_map}')."
  4194	            )
  4195	        self._version = version
  4196	        # Force config update.
  4197	        self._config.update(self._get_version_checks())
  4198	        self._config["version"] = version
  4199	
  4200	    @property
  4201	    def coordinate_systems(self):
  4202	        """
  4203	        A list of coordinate system descriptions for the file.  Must
  4204	        contain only `CooSys` objects.
  4205	        """
  4206	        return self._coordinate_systems
  4207	
  4208	    @property
  4209	    def time_systems(self):
  4210	        """
  4211	        A list of time system descriptions for the file.  Must
  4212	        contain only `TimeSys` objects.
  4213	        """
  4214	        return self._time_systems
  4215	
  4216	    @property
  4217	    def params(self):
  4218	        """
  4219	        A list of parameters (constant-valued columns) that apply to
  4220	        the entire file.  Must contain only `Param` objects.
  4221	        """
  4222	        return self._params
  4223	
  4224	    @property
  4225	    def infos(self):
  4226	        """
  4227	        A list of informational parameters (key-value pairs) for the
  4228	        entire file.  Must only contain `Info` objects.
  4229	        """
  4230	        return self._infos
  4231	
  4232	    @property
  4233	    def resources(self):
  4234	        """
  4235	        A list of resources, in the order they appear in the file.
  4236	        Must only contain `Resource` objects.
  4237	        """
  4238	        return self._resources
  4239	
  4240	    @property
  4241	    def groups(self):
  4242	        """
  4243	        A list of groups, in the order they appear in the file.  Only
  4244	        supported as a child of the VOTABLE element in VOTable 1.2 or
  4245	        later.
  4246	        """
  4247	        return self._groups
  4248	
  4249	    def _add_param(self, iterator, tag, data, config, pos):
  4250	        param = Param(self, config=config, pos=pos, **data)
  4251	        self.params.append(param)
  4252	        param.parse(iterator, config)
  4253	
  4254	    def _add_resource(self, iterator, tag, data, config, pos):
  4255	        resource = Resource(config=config, pos=pos, **data)
  4256	        self.resources.append(resource)
  4257	        resource.parse(self, iterator, config)
  4258	
  4259	    def _add_coosys(self, iterator, tag, data, config, pos):
  4260	        coosys = CooSys(config=config, pos=pos, **data)
  4261	        self.coordinate_systems.append(coosys)
  4262	        coosys.parse(iterator, config)
  4263	
  4264	    def _add_timesys(self, iterator, tag, data, config, pos):
  4265	        timesys = TimeSys(config=config, pos=pos, **data)
  4266	        self.time_systems.append(timesys)
  4267	        timesys.parse(iterator, config)
  4268	
  4269	    def _add_info(self, iterator, tag, data, config, pos):
  4270	        info = Info(config=config, pos=pos, **data)
  4271	        self.infos.append(info)
  4272	        info.parse(iterator, config)
  4273	
  4274	    def _add_group(self, iterator, tag, data, config, pos):
  4275	        if not config.get("version_1_2_or_later"):
  4276	            warn_or_raise(W26, W26, ("GROUP", "VOTABLE", "1.2"), config, pos)
  4277	        group = Group(self, config=config, pos=pos, **data)
  4278	        self.groups.append(group)
  4279	        group.parse(iterator, config)
  4280	
  4281	    def _get_version_checks(self):
  4282	        config = {}
  4283	        config["version"] = self.version
  4284	        config["version_1_1_or_later"] = util.version_compare(self.version, "1.1") >= 0
  4285	        config["version_1_2_or_later"] = util.version_compare(self.version, "1.2") >= 0
  4286	        config["version_1_3_or_later"] = util.version_compare(self.version, "1.3") >= 0
  4287	        config["version_1_4_or_later"] = util.version_compare(self.version, "1.4") >= 0
  4288	        config["version_1_5_or_later"] = util.version_compare(self.version, "1.5") >= 0
  4289	        return config
  4290	
  4291	    # Map VOTable version numbers to namespace URIs and schema information.
  4292	    _version_namespace_map = {
  4293	        # Version 1.0 isn't well-supported, but is allowed on parse (with a warning).
  4294	        # It used DTD rather than schema, so this information would not be useful.
  4295	        # By omitting 1.0 from this dict we can use the keys as the list of versions
  4296	        # that are allowed in various other checks.
  4297	        "1.1": {
  4298	            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.1",
  4299	            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
  4300	            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.1",
  4301	        },
  4302	        "1.2": {
  4303	            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.2",
  4304	            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
  4305	            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.2",
  4306	        },
  4307	        # With 1.3 we'll be more explicit with the schema location.
  4308	        # - xsi:schemaLocation uses the namespace name along with the URL
  4309	        #   to reference it.
  4310	        # - For convenience, but somewhat confusingly, the namespace URIs
  4311	        #   are also usable URLs for accessing an applicable schema.
  4312	        #   However to avoid confusion, we'll use the explicit schema URL.
  4313	        "1.3": {
  4314	            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
  4315	            "schema_location_attr": "xsi:schemaLocation",
  4316	            "schema_location_value": (
  4317	                "http://www.ivoa.net/xml/VOTable/v1.3"
  4318	                " http://www.ivoa.net/xml/VOTable/VOTable-1.3.xsd"
  4319	            ),
  4320	        },
  4321	        # With 1.4 namespace URIs stopped incrementing with minor version changes
  4322	        # so we use the same URI as with 1.3.  See this IVOA note for more info:
  4323	        # http://www.ivoa.net/documents/Notes/XMLVers/20180529/
  4324	        "1.4": {
  4325	            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
  4326	            "schema_location_attr": "xsi:schemaLocation",
  4327	            "schema_location_value": (
  4328	                "http://www.ivoa.net/xml/VOTable/v1.3"
  4329	                " http://www.ivoa.net/xml/VOTable/VOTable-1.4.xsd"
  4330	            ),
  4331	        },
  4332	        "1.5": {
  4333	            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
  4334	            "schema_location_attr": "xsi:schemaLocation",
  4335	            "schema_location_value": (
  4336	                "http://www.ivoa.net/xml/VOTable/v1.3"
  4337	                " http://www.ivoa.net/xml/VOTable/VOTable-1.5.xsd"
  4338	            ),
  4339	        },
  4340	    }
  4341	
  4342	    def parse(self, iterator, config):
  4343	        config["_current_table_number"] = 0
  4344	
  4345	        for start, tag, data, pos in iterator:
  4346	            if start:
  4347	                if tag == "xml":
  4348	                    pass
  4349	                elif tag == "VOTABLE":
  4350	                    if "version" not in data:
  4351	                        warn_or_raise(W20, W20, self.version, config, pos)
  4352	                        config["version"] = self.version
  4353	                    else:
  4354	                        config["version"] = self._version = data["version"]
  4355	                        if config["version"].lower().startswith("v"):
  4356	                            warn_or_raise(W29, W29, config["version"], config, pos)
  4357	                            self._version = config["version"] = config["version"][1:]
  4358	                        if config["version"] not in self._version_namespace_map:
  4359	                            vo_warn(W21, config["version"], config, pos)
  4360	
  4361	                        # Update the configuration of the VOTableFile itself.
  4362	                        # This can not be done via the .version property setter
  4363	                        # because that refuses to allow votable 1.0.
  4364	                        self._config["version"] = config["version"]
  4365	                        self._config.update(self._get_version_checks())
  4366	
  4367	                    if "xmlns" in data:
  4368	                        ns_info = self._version_namespace_map.get(config["version"], {})
  4369	                        correct_ns = ns_info.get("namespace_uri")
  4370	                        if data["xmlns"] != correct_ns:
  4371	                            vo_warn(W41, (correct_ns, data["xmlns"]), config, pos)
  4372	                    else:
  4373	                        vo_warn(W42, (), config, pos)
  4374	
  4375	                    break
  4376	                else:
  4377	                    vo_raise(E19, (), config, pos)
  4378	        config.update(self._get_version_checks())
  4379	
  4380	        tag_mapping = {
  4381	            "PARAM": self._add_param,
  4382	            "RESOURCE": self._add_resource,
  4383	            "COOSYS": self._add_coosys,
  4384	            "TIMESYS": self._add_timesys,
  4385	            "INFO": self._add_info,
  4386	            "DEFINITIONS": self._add_definitions,
  4387	            "DESCRIPTION": self._ignore_add,
  4388	            "GROUP": self._add_group,
  4389	        }
  4390	
  4391	        for start, tag, data, pos in iterator:
  4392	            if start:
  4393	                tag_mapping.get(tag, self._add_unknown_tag)(
  4394	                    iterator, tag, data, config, pos
  4395	                )
  4396	            elif tag == "DESCRIPTION":
  4397	                if self.description is not None:
  4398	                    warn_or_raise(W17, W17, "VOTABLE", config, pos)
  4399	                self.description = data or None
  4400	
  4401	        if not len(self.resources) and config["version_1_2_or_later"]:
  4402	            warn_or_raise(W53, W53, (), config, pos)
  4403	
  4404	        return self
  4405	
  4406	    def to_xml(
  4407	        self,
  4408	        fd,
  4409	        compressed=False,
  4410	        tabledata_format=None,
  4411	        _debug_python_based_parser=False,
  4412	        _astropy_version=None,
  4413	    ):
  4414	        """
  4415	        Write to an XML file.
  4416	
  4417	        Parameters
  4418	        ----------
  4419	        fd : str or file-like
  4420	            Where to write the file. If a file-like object, must be writable.
  4421	
  4422	        compressed : bool, optional
  4423	            When `True`, write to a gzip-compressed file.  (Default:
  4424	            `False`)
  4425	
  4426	        tabledata_format : str, optional
  4427	            Override the format of the table(s) data to write.  Must
  4428	            be one of ``tabledata`` (text representation), ``binary`` or
  4429	            ``binary2``.  By default, use the format that was specified
  4430	            in each `TableElement` object as it was created or read in.  See
  4431	            :ref:`astropy:votable-serialization`.
  4432	        """
  4433	        if tabledata_format is not None:
  4434	            if tabledata_format.lower() not in ("tabledata", "binary", "binary2"):
  4435	                raise ValueError(f"Unknown format type '{format}'")
  4436	
  4437	        kwargs = {
  4438	            "version": self.version,
  4439	            "tabledata_format": tabledata_format,
  4440	            "_debug_python_based_parser": _debug_python_based_parser,
  4441	            "_group_number": 1,
  4442	        }
  4443	        kwargs.update(self._get_version_checks())
  4444	
  4445	        with util.convert_to_writable_filelike(fd, compressed=compressed) as fh:
  4446	            w = XMLWriter(fh)
  4447	            version = self.version
  4448	            if _astropy_version is None:
  4449	                lib_version = astropy_version
  4450	            else:
  4451	                lib_version = _astropy_version
  4452	
  4453	            xml_header = """
  4454	<?xml version="1.0" encoding="utf-8"?>
  4455	<!-- Produced with astropy.io.votable version {lib_version}
  4456	     http://www.astropy.org/ -->\n"""
  4457	            w.write(xml_header.lstrip().format(**locals()))
  4458	
  4459	            # Build the VOTABLE tag attributes.
  4460	            votable_attr = {
  4461	                "version": version,
  4462	                "xmlns:xsi": "http://www.w3.org/2001/XMLSchema-instance",
  4463	            }
  4464	            ns_info = self._version_namespace_map.get(version, {})
  4465	            namespace_uri = ns_info.get("namespace_uri")
  4466	            if namespace_uri:
  4467	                votable_attr["xmlns"] = namespace_uri
  4468	            schema_location_attr = ns_info.get("schema_location_attr")
  4469	            schema_location_value = ns_info.get("schema_location_value")
  4470	            if schema_location_attr and schema_location_value:
  4471	                votable_attr[schema_location_attr] = schema_location_value
  4472	
  4473	            with w.tag("VOTABLE", votable_attr):
  4474	                if self.description is not None:
  4475	                    w.element("DESCRIPTION", self.description, wrap=True)
  4476	                element_sets = [
  4477	                    self.coordinate_systems,
  4478	                    self.time_systems,
  4479	                    self.params,
  4480	                    self.infos,
  4481	                    self.resources,
  4482	                ]
  4483	                if kwargs["version_1_2_or_later"]:
  4484	                    element_sets.append(self.groups)
  4485	
  4486	                for element_set in element_sets:
  4487	                    for element in element_set:
  4488	                        element.to_xml(w, **kwargs)
  4489	
  4490	    def iter_tables(self):
  4491	        """
  4492	        Iterates over all tables in the VOTable file in a "flat" way,
  4493	        ignoring the nesting of resources etc.
  4494	        """
  4495	        for resource in self.resources:
  4496	            yield from resource.iter_tables()
  4497	
  4498	
  4499	
  4500	
  4501	
  4502	
  4503	
  4504	
  4505	
  4506	
  4507	
  4508	    get_table_by_id = _lookup_by_attr_factory(
  4509	        "ID",
  4510	        True,
  4511	        "iter_tables",
  4512	        "TABLE",
  4513	        """
  4514	        Looks up a TABLE_ element by the given ID.  Used by the table
  4515	        "ref" attribute.
  4516	        """,
  4517	    )
  4518	
  4519	    get_tables_by_utype = _lookup_by_attr_factory(
  4520	        "utype",
  4521	        False,
  4522	        "iter_tables",
  4523	        "TABLE",
  4524	        """
  4525	        Looks up a TABLE_ element by the given utype, and returns an
  4526	        iterator emitting all matches.
  4527	        """,
  4528	    )
  4529	
  4530	    def get_table_by_index(self, idx):
  4531	        """
  4532	        Get a table by its ordinal position in the file.
  4533	        """
  4534	        for i, table in enumerate(self.iter_tables()):
  4535	            if i == idx:
  4536	                return table
  4537	        raise IndexError(f"No table at index {idx:d} found in VOTABLE file.")
  4538	
  4539	    def iter_fields_and_params(self):
  4540	        """
  4541	        Recursively iterate over all FIELD_ and PARAM_ elements in the
  4542	        VOTABLE_ file.
  4543	        """
  4544	        for resource in self.resources:
  4545	            yield from resource.iter_fields_and_params()
  4546	
  4547	    get_field_by_id = _lookup_by_attr_factory(
  4548	        "ID",
  4549	        True,
  4550	        "iter_fields_and_params",
  4551	        "FIELD",
  4552	        """
  4553	        Looks up a FIELD_ element by the given ID_.  Used by the field's
  4554	        "ref" attribute.
  4555	        """,
  4556	    )
  4557	
  4558	    get_fields_by_utype = _lookup_by_attr_factory(
  4559	        "utype",
  4560	        False,
  4561	        "iter_fields_and_params",
  4562	        "FIELD",
  4563	        """
  4564	        Looks up a FIELD_ element by the given utype and returns an
  4565	        iterator emitting all matches.
  4566	        """,
  4567	    )
  4568	
  4569	    get_field_by_id_or_name = _lookup_by_id_or_name_factory(
  4570	        "iter_fields_and_params",
  4571	        "FIELD",
  4572	        """
  4573	        Looks up a FIELD_ element by the given ID_ or name.
  4574	        """,
  4575	    )
  4576	
  4577	
  4578	
  4579	
  4580	
  4581	
  4582	
  4583	
  4584	
  4585	    get_values_by_id = _lookup_by_attr_factory(
  4586	        "ID",
  4587	        True,
  4588	        "iter_values",
  4589	        "VALUES",
  4590	        """
  4591	        Looks up a VALUES_ element by the given ID.  Used by the values
  4592	        "ref" attribute.
  4593	        """,
  4594	    )
  4595	
  4596	    def iter_groups(self):
  4597	        """
  4598	        Recursively iterate over all GROUP_ elements in the VOTABLE_
  4599	        file.
  4600	        """
  4601	        for table in self.iter_tables():
  4602	            yield from table.iter_groups()
  4603	
  4604	    get_group_by_id = _lookup_by_attr_factory(
  4605	        "ID",
  4606	        True,
  4607	        "iter_groups",
  4608	        "GROUP",
  4609	        """
  4610	        Looks up a GROUP_ element by the given ID.  Used by the group's
  4611	        "ref" attribute
  4612	        """,
  4613	    )
  4614	
  4615	    get_groups_by_utype = _lookup_by_attr_factory(
  4616	        "utype",
  4617	        False,
  4618	        "iter_groups",
  4619	        "GROUP",
  4620	        """
  4621	        Looks up a GROUP_ element by the given utype and returns an
  4622	        iterator emitting all matches.
  4623	        """,
  4624	    )
  4625	
  4626	    def iter_coosys(self):
  4627	        """
  4628	        Recursively iterate over all COOSYS_ elements in the VOTABLE_
  4629	        file.
  4630	        """
```

## 原始行 31 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"\\.meta\\[|meta ==|description|ucd|utype|links\" astropy/io/votable/tests | head -300
grep -RIn \"iter_values\\|get_values_by_id\\|PARAMref\\|get_ref()\\|repr(votable\\|repr(.*VOTable\" astropy/io/votable/tests | head -300
sed -n '420,570p' astropy/io/votable/tests/test_table.py
sed -n '300,360p' astropy/io/votable/tests/test_converter.py"
```

退出码：`0`

输出：
```
astropy/io/votable/tests/test_table.py:288:        "id": {"unit": "", "ucd": "meta.id", "utype": "none"},
astropy/io/votable/tests/test_table.py:289:        "z": {"unit": "", "ucd": "src.redshift", "utype": "none"},
astropy/io/votable/tests/test_table.py:290:        "mass": {"unit": "solMass", "ucd": "phys.mass", "utype": "none"},
astropy/io/votable/tests/test_table.py:291:        "sfr": {"unit": "solMass / yr", "ucd": "phys.SFR", "utype": "none"},
astropy/io/votable/tests/test_tree.py:110:          <FIELD ID="hd" datatype="int" name="hd" ucd="meta.id;meta.main">
astropy/io/votable/tests/test_tree.py:571:    # R1 : 2 mivot_block, 2 tables, 1 description, 1 info, 1 CooSys
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.3.xml:17: <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.3.xml:26:   This is a resource description
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.3.xml:49:   <FIELD ID="int" datatype="int" name="int" utype="myint">
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.3.xml:99:     This should warn of a second description.
astropy/io/votable/tests/data/gemini.xml:5:      <FIELD name="ID" datatype="char" ucd="meta.id;meta.main" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:6:      <FIELD name="access_url" datatype="char" ucd="meta.ref.url" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:7:      <FIELD name="service_def" datatype="char" ucd="meta.ref" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:8:      <FIELD name="error_message" datatype="char" ucd="meta.code.error" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:9:      <FIELD name="semantics" datatype="char" ucd="meta.code" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:10:      <FIELD name="description" datatype="char" ucd="meta.note" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:11:      <FIELD name="content_type" datatype="char" ucd="meta.code.mime" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:12:      <FIELD name="content_length" datatype="long" ucd="phys.size;meta.file" unit="byte" />
astropy/io/votable/tests/data/gemini.xml:13:      <FIELD name="product_type" datatype="char" utype="caom:Artifact.productType" arraysize="*" />
astropy/io/votable/tests/data/gemini.xml:70:  <RESOURCE type="meta" ID="this" utype="adhoc:service">
astropy/io/votable/tests/data/gemini.xml:72:    <PARAM name="standardID" datatype="char" arraysize="*" value="ivo://ivoa.net/std/DataLink#links-1.0" />
astropy/io/votable/tests/data/gemini.xml:84:  <RESOURCE type="meta" ID="cutout" utype="adhoc:service">
astropy/io/votable/tests/data/gemini.xml:92:  <RESOURCE type="meta" ID="soda-sync" utype="adhoc:service">
astropy/io/votable/tests/data/gemini.xml:98:      <PARAM name="POS" datatype="char" ucd="obs.field" arraysize="*" value="" />
astropy/io/votable/tests/data/gemini.xml:99:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="" />
astropy/io/votable/tests/data/gemini.xml:100:      <PARAM name="POLY" datatype="double" ucd="obs.field" unit="deg" xtype="polygon" arraysize="*" value="" />
astropy/io/votable/tests/data/gemini.xml:101:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:102:      <PARAM name="TIME" datatype="double" ucd="time;stat.interval" unit="d" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:103:      <PARAM name="POL" datatype="char" ucd="phys.polarization.stokes" arraysize="2*" value="" />
astropy/io/votable/tests/data/gemini.xml:106:  <RESOURCE type="meta" ID="soda-async" utype="adhoc:service">
astropy/io/votable/tests/data/gemini.xml:112:      <PARAM name="POS" datatype="char" ucd="obs.field" arraysize="*" value="" />
astropy/io/votable/tests/data/gemini.xml:113:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="" />
astropy/io/votable/tests/data/gemini.xml:114:      <PARAM name="POLY" datatype="double" ucd="obs.field" unit="deg" xtype="polygon" arraysize="*" value="" />
astropy/io/votable/tests/data/gemini.xml:115:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:116:      <PARAM name="TIME" datatype="double" ucd="time;stat.interval" unit="d" xtype="interval" arraysize="2" value="" />
astropy/io/votable/tests/data/gemini.xml:117:      <PARAM name="POL" datatype="char" ucd="phys.polarization.stokes" arraysize="2*" value="" />
astropy/io/votable/tests/data/gemini.xml:120:  <RESOURCE type="meta" ID="soda-62b3e0b3-2718-442f-920a-ce8028687c2b" utype="adhoc:service">
astropy/io/votable/tests/data/gemini.xml:125:      <PARAM name="ID" datatype="char" ucd="" arraysize="*" value="ad:GEMINI/S20120515S0064" />
astropy/io/votable/tests/data/gemini.xml:126:      <PARAM name="POS" datatype="char" ucd="obs.field" arraysize="*" value="" />
astropy/io/votable/tests/data/gemini.xml:127:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="">
astropy/io/votable/tests/data/gemini.xml:132:      <PARAM name="POLY" datatype="double" ucd="obs.field" unit="deg" xtype="polygon" arraysize="*" value="">
astropy/io/votable/tests/data/gemini.xml:137:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="">
astropy/io/votable/tests/data/gemini.xml:144:  <RESOURCE type="meta" ID="soda-d0378127-e438-46a2-880f-42df8884a2ff" utype="adhoc:service">
astropy/io/votable/tests/data/gemini.xml:149:      <PARAM name="ID" datatype="char" ucd="" arraysize="*" value="ad:GEMINI/S20120515S0064" />
astropy/io/votable/tests/data/gemini.xml:150:      <PARAM name="POS" datatype="char" ucd="obs.field" arraysize="*" value="" />
astropy/io/votable/tests/data/gemini.xml:151:      <PARAM name="CIRC" datatype="double" ucd="obs.field" unit="deg" xtype="circle" arraysize="3" value="">
astropy/io/votable/tests/data/gemini.xml:156:      <PARAM name="POLY" datatype="double" ucd="obs.field" unit="deg" xtype="polygon" arraysize="*" value="">
astropy/io/votable/tests/data/gemini.xml:161:      <PARAM name="BAND" datatype="double" ucd="em.wl;stat.interval" unit="m" xtype="interval" arraysize="2" value="">
astropy/io/votable/tests/data/valid_votable.xml:7:      <PARAM name="Telescope" datatype="float" ucd="phys.size;instr.tel"
astropy/io/votable/tests/data/valid_votable.xml:9:      <FIELD name="RA"   ID="col1" ucd="pos.eq.ra;meta.main"
astropy/io/votable/tests/data/valid_votable.xml:11:      <FIELD name="Dec"  ID="col2" ucd="pos.eq.dec;meta.main"
astropy/io/votable/tests/data/valid_votable.xml:13:      <FIELD name="Name" ID="col3" ucd="meta.id;meta.main"
astropy/io/votable/tests/data/valid_votable.xml:15:      <FIELD name="RVel" ID="col4" ucd="spect.dopplerVeloc" datatype="int"
astropy/io/votable/tests/data/valid_votable.xml:17:      <FIELD name="e_RVel" ID="col5" ucd="stat.error;spect.dopplerVeloc"
astropy/io/votable/tests/data/valid_votable.xml:19:      <FIELD name="R" ID="col6" ucd="pos.distance;pos.heliocentric"
astropy/io/votable/tests/data/parquet_binary.xml:7:   <FIELD ID="id" arraysize="10" datatype="unicodeChar" name="id" ucd="meta.id" unit="---" utype="none"/>
astropy/io/votable/tests/data/parquet_binary.xml:8:   <FIELD ID="z" datatype="double" name="z" ucd="src.redshift" unit="---" utype="none"/>
astropy/io/votable/tests/data/parquet_binary.xml:9:   <FIELD ID="mass" datatype="double" name="mass" ucd="phys.mass" unit="solMass" utype="none"/>
astropy/io/votable/tests/data/parquet_binary.xml:10:   <FIELD ID="sfr" datatype="double" name="sfr" ucd="phys.SFR" unit="solMass.yr-1" utype="none"/>
astropy/io/votable/tests/data/timesys.xml:10:      <FIELD datatype="double" name="obs_time" ucd="time.epoch" unit="d" ref="time_frame"/>
astropy/io/votable/tests/data/timesys.xml:11:      <FIELD datatype="float" name="flux" ucd="phot.flux;em.opt.V" unit="s**-1"/>
astropy/io/votable/tests/data/timesys.xml:12:      <FIELD datatype="float" name="mag" ucd="phot.mag;em.opt.V" unit="mag"/>
astropy/io/votable/tests/data/timesys.xml:13:      <FIELD datatype="float" name="flux_error" ucd="stat.error;phot.flux;em.opt.V" 
astropy/io/votable/tests/data/timesys.xml:15:      <PARAM datatype="double" name="ra" ucd="pos.eq.ra" value="45.7164887146879" ref="system"/>
astropy/io/votable/tests/data/timesys.xml:16:      <PARAM datatype="double" name="dec" ucd="pos.eq.dec" value="1.18583048057467" ref="system"/>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:25:          <ATTRIBUTE dmrole='Phot:Flux.ucd' dmtype='Phot:UCD' value='phot.flux.density'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:48:        <ATTRIBUTE dmrole='Phot:PhotometryFilter.description' dmtype='ivoa:string' value='GAIA G filter, DR3'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:53:          <ATTRIBUTE dmrole='Phot:Bandwidth.ucd' dmtype='Phot:UCD' value='instr.bandwidth'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:75:          <ATTRIBUTE dmrole='Phot:SpectralLocation.ucd' dmtype='Phot:UCD' value='em.wl'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:95:          <ATTRIBUTE dmrole='Phot:Flux.ucd' dmtype='Phot:UCD' value='phot.flux.density'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:118:        <ATTRIBUTE dmrole='Phot:PhotometryFilter.description' dmtype='ivoa:string' value='GAIA Gbp filter, DR3'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:123:          <ATTRIBUTE dmrole='Phot:Bandwidth.ucd' dmtype='Phot:UCD' value='instr.bandwidth'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:145:          <ATTRIBUTE dmrole='Phot:SpectralLocation.ucd' dmtype='Phot:UCD' value='em.wl'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:165:          <ATTRIBUTE dmrole='Phot:Flux.ucd' dmtype='Phot:UCD' value='phot.flux.density'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:188:        <ATTRIBUTE dmrole='Phot:PhotometryFilter.description' dmtype='ivoa:string' value='GAIA Grp filter, DR3'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:193:          <ATTRIBUTE dmrole='Phot:Bandwidth.ucd' dmtype='Phot:UCD' value='instr.bandwidth'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:215:          <ATTRIBUTE dmrole='Phot:SpectralLocation.ucd' dmtype='Phot:UCD' value='em.wl'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:237:          <ATTRIBUTE dmrole='mango:Property.description' dmtype='ivoa:string' value='G Band magnitude'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:240:            <ATTRIBUTE dmrole='meas:Measure.ucd' dmtype='ivoa:string' value='phot.mag;em.opt;stat.mean'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:255:          <ATTRIBUTE dmrole='mango:Property.description' dmtype='ivoa:string' value='G Band magnitude'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:258:            <ATTRIBUTE dmrole='meas:Measure.ucd' dmtype='ivoa:string' value='phot.mag;em.opt;stat.mean'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:273:          <ATTRIBUTE dmrole='mango:Property.description' dmtype='ivoa:string' value='G Band magnitude'>
astropy/io/votable/tests/data/mivot_block_custom_datatype.xml:276:            <ATTRIBUTE dmrole='meas:Measure.ucd' dmtype='ivoa:string' value='phot.mag;em.opt;stat.mean'>
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.1.xml:17: <PARAM ID="INPUT" arraysize="*" datatype="float" name="INPUT" ucd="phys.size;instr.tel" unit="km.h-1" value="0 0">
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.1.xml:26:   This is a resource description
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.1.xml:49:   <FIELD ID="int" datatype="int" name="int" utype="myint">
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.1.xml:99:     This should warn of a second description.
astropy/io/votable/tests/data/resource_groups.xml:3:  <RESOURCE type="meta" utype="adhoc:service">
astropy/io/votable/tests/data/resource_groups.xml:5:      <PARAM arraysize="*" datatype="char" name="ID" ref="a_reference" ucd="meta.id;meta.main" value=""/>
astropy/io/votable/tests/data/resource_groups.xml:7:    <PARAM arraysize="*" datatype="char" name="standardID" value="ivo://ivoa.net/std/DataLink#links-1.0"/>
astropy/io/votable/tests/data/validation.txt:62:    This should warn of a second description.
astropy/io/votable/tests/data/vizier_b2_votable.xml:5:<!-- VOTable description at http://www.ivoa.net/Documents/latest/VOT.html -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:30:    <FIELD name="n_PNG" ucd="meta.note" datatype="char" arraysize="1"><!-- ucd="NOTE" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:33:    <FIELD name="PNG" ucd="meta.id;meta.main" datatype="char" arraysize="12"><!-- ucd="DATA_LINK" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:36:    <FIELD name="Name" ucd="meta.id" datatype="char" arraysize="13"><!-- ucd="?" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:39:    <FIELD name="RAJ2000" ucd="pos.eq.ra;meta.main" ref="J2000" datatype="double" width="10" precision="4" unit=""><!-- ucd="POS_EQ_RA_MAIN" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:42:    <FIELD name="DEJ2000" ucd="pos.eq.dec;meta.main" ref="J2000" datatype="double" width="9" precision="4" unit=""><!-- ucd="POS_EQ_DEC_MAIN" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:45:    <FIELD name="MajDiam" ucd="phys.angSize" datatype="float" width="6" precision="1" unit="arcsec"><!-- ucd="?" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:49:    <FIELD name="MinDiam" ucd="phys.angSize" datatype="float" width="6" precision="1" unit="arcsec"><!-- ucd="?" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:53:    <FIELD name="CS" ucd="meta.note" datatype="char" arraysize="7*"><!-- ucd="?" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:56:    <FIELD name="Morph" ucd="src.morph" datatype="char" arraysize="7*"><!-- ucd="?" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:59:    <FIELD name="ObsDate" ucd="time.epoch" datatype="int" width="10" unit="'Y:M:D'"><!-- ucd="?" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:63:    <FIELD name="img" ucd="meta.note" datatype="char" arraysize="5"><!-- ucd="DATA_LINK" -->
astropy/io/votable/tests/data/vizier_b2_votable.xml:66:    <FIELD name="AssocData" ucd="meta.bib.page" datatype="char" arraysize="4"><!-- ucd="DATA_LINK" -->
astropy/io/votable/tests/data/nonstandard_units.xml:7:<RESOURCE utype="spec:Spectrum">
astropy/io/votable/tests/data/nonstandard_units.xml:8:<TABLE utype="spec:Spectrum">
astropy/io/votable/tests/data/nonstandard_units.xml:9:<FIELD name="Flux" ID="Flux1" utype="spec:Data.FluxAxis.value" ucd="phot.flux.density;em.wl"
astropy/io/votable/tests/data/regression.xml:12:<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arraysize="*" unit="km/h" ucd="phys.size;instr.tel">
astropy/io/votable/tests/data/regression.xml:18:  This is a resource description
astropy/io/votable/tests/data/regression.xml:51:<FIELD ID="int" name="int" datatype="int" utype="myint">
astropy/io/votable/tests/data/regression.xml:98:    This should warn of a second description.
astropy/io/votable/tests/data/irsa-nph-m31.xml:21:<FIELD name="ra" ucd="POS_EQ_RA_MAIN" ref="J2000" datatype="float" unit="deg" precision="F3" width="7" />
astropy/io/votable/tests/data/irsa-nph-m31.xml:22:<FIELD name="dec" ucd="POS_EQ_DEC_MAIN" ref="J2000" datatype="float" unit="deg" precision="F3" width="7" />
astropy/io/votable/tests/data/irsa-nph-m31.xml:45:<FIELD name="id" ucd="ID_MAIN" datatype="char" arraysize="*" />
astropy/io/votable/tests/data/coosys.xml:9:      <FIELD name="RA" ID="ra" ucd="pos.eq.ra;meta.main" datatype="double" unit="deg" ref="coosys0"/>
astropy/io/votable/tests/data/coosys.xml:10:      <FIELD name="Dec" ID="dec" ucd="pos.eq.dec;meta.main" datatype="double" unit="deg" ref="coosys1"/>
astropy/io/votable/tests/data/coosys.xml:11:      <FIELD name="OtherDec" ID="other_dec" ucd="pos.eq.dec" datatype="double" unit="deg" ref="coosys2"/>
astropy/io/votable/tests/data/coosys.xml:12:      <FIELD name="Name" ID="name" ucd="meta.id;meta.main" datatype="char" arraysize="8*"/>
astropy/io/votable/tests/data/mivot_annotated_table.xml:34:    <INFO name="citation" ucd="meta.bib" value="http://dc.zah.uni-heidelberg.de/tableinfo/gaia.dr3lite#ti-citing">For advice on how to cite the resource(s) that contributed to this result, see http://dc.zah.uni-heidelberg.de/tableinfo/gaia.dr3lite#ti-citing</INFO>
astropy/io/votable/tests/data/mivot_annotated_table.xml:35:    <INFO name="referenceURL" ucd="meta.ref.url" value="http://dc.zah.uni-heidelberg.de/tableinfo/gaia.dr3lite">More information on a resource that contributed to this data is found at http://dc.zah.uni-heidelberg.de/tableinfo/gaia.dr3lite</INFO>
astropy/io/votable/tests/data/mivot_annotated_table.xml:57:          <!-- Here are the complete description of the photometric calibrations for 3 bands These are PhotDM instance generated
astropy/io/votable/tests/data/mivot_annotated_table.xml:67:                <ATTRIBUTE dmrole="Phot:Flux.ucd" dmtype="Phot:UCD" value="phot.flux.density" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:82:              <ATTRIBUTE dmrole="Phot:PhotometryFilter.description" dmtype="ivoa:string" value="GAIA G filter, DR3" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:85:                <ATTRIBUTE dmrole="Phot:Bandwidth.ucd" dmtype="Phot:UCD" value="instr.bandwidth" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:100:                <ATTRIBUTE dmrole="Phot:SpectralLocation.ucd" dmtype="Phot:UCD" value="em.wl" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:114:                <ATTRIBUTE dmrole="Phot:Flux.ucd" dmtype="Phot:UCD" value="phot.flux.density" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:129:              <ATTRIBUTE dmrole="Phot:PhotometryFilter.description" dmtype="ivoa:string" value="GAIA Gbp filter, DR3" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:132:                <ATTRIBUTE dmrole="Phot:Bandwidth.ucd" dmtype="Phot:UCD" value="instr.bandwidth" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:147:                <ATTRIBUTE dmrole="Phot:SpectralLocation.ucd" dmtype="Phot:UCD" value="em.wl" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:161:                <ATTRIBUTE dmrole="Phot:Flux.ucd" dmtype="Phot:UCD" value="phot.flux.density" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:176:              <ATTRIBUTE dmrole="Phot:PhotometryFilter.description" dmtype="ivoa:string" value="GAIA Grp filter, DR3" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:179:                <ATTRIBUTE dmrole="Phot:Bandwidth.ucd" dmtype="Phot:UCD" value="instr.bandwidth" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:194:                <ATTRIBUTE dmrole="Phot:SpectralLocation.ucd" dmtype="Phot:UCD" value="em.wl" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:223:                <ATTRIBUTE dmrole="mango:Property.description" dmtype="ivoa:string" value="G Band magnitude" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:227:                  <ATTRIBUTE dmrole="meas:Measure.ucd" dmtype="ivoa:string" value="phot.mag;em.opt;stat.mean" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:246:                <ATTRIBUTE dmrole="mango:Property.description" dmtype="ivoa:string" value="G Band magnitude" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:250:                  <ATTRIBUTE dmrole="meas:Measure.ucd" dmtype="ivoa:string" value="phot.mag;em.opt;stat.mean" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:269:                <ATTRIBUTE dmrole="mango:Property.description" dmtype="ivoa:string" value="G Band magnitude" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:273:                  <ATTRIBUTE dmrole="meas:Measure.ucd" dmtype="ivoa:string" value="phot.mag;em.opt;stat.mean" />
astropy/io/votable/tests/data/mivot_annotated_table.xml:298:      <FIELD ID="source_id" datatype="long" name="source_id" ucd="meta.id;meta.main">
astropy/io/votable/tests/data/mivot_annotated_table.xml:306:      <FIELD ID="phot_g_mean_mag" datatype="float" name="phot_g_mean_mag" ucd="phot.mag;em.opt;stat.mean" unit="mag">
astropy/io/votable/tests/data/mivot_annotated_table.xml:316:      <FIELD ID="phot_rp_mean_mag" datatype="float" name="phot_rp_mean_mag" ucd="phot.mag;em.opt.R" unit="mag">
astropy/io/votable/tests/data/mivot_annotated_table.xml:325:      <FIELD ID="phot_bp_mean_mag" datatype="float" name="phot_bp_mean_mag" ucd="phot.mag;em.opt.B" unit="mag">
astropy/io/votable/tests/data/names.xml:20:   <FIELD ID="col1" arraysize="25" datatype="char" name="Name" ucd="meta.id;meta.main" unit="---">
astropy/io/votable/tests/data/names.xml:25:   <FIELD ID="col2" datatype="float" name="GLON" precision="4" ucd="pos.galactic.lon" unit="deg" width="8">
astropy/io/votable/tests/data/names.xml:35:   <FIELD ID="col3" datatype="float" name="GLAT" precision="4" ucd="pos.galactic.lat" unit="deg" width="7">
astropy/io/votable/tests/data/names.xml:45:   <FIELD ID="col4" datatype="float" name="RAdeg" precision="4" ucd="pos.eq.ra" unit="deg" width="8">
astropy/io/votable/tests/data/names.xml:55:   <FIELD ID="col5" datatype="float" name="DEdeg" precision="4" ucd="pos.eq.dec" unit="deg" width="8">
astropy/io/votable/tests/data/names.xml:65:   <FIELD ID="col6" datatype="float" name="Jmag" precision="2" ucd="phot.mag;em.IR.J" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:75:   <FIELD ID="col7" datatype="float" name="Hmag" precision="2" ucd="phot.mag;em.IR.H" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:85:   <FIELD ID="col8" datatype="float" name="Kmag" precision="2" ucd="phot.mag;em.IR.K" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:95:   <FIELD ID="col9" datatype="float" name="G3.6mag" precision="2" ucd="phot.mag;em.IR.3-4um" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:106:   <FIELD ID="col10" datatype="float" name="G4.5mag" precision="2" ucd="phot.mag;em.IR.4-8um" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:116:   <FIELD ID="col11" datatype="float" name="G5.8mag" precision="2" ucd="phot.mag;em.IR.4-8um" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:127:   <FIELD ID="col12" datatype="float" name="G8.0mag" precision="2" ucd="phot.mag;em.IR.4-8um" unit="mag" width="4">
astropy/io/votable/tests/data/names.xml:137:   <FIELD ID="col13" datatype="float" name="4.5mag" precision="2" ucd="phot.mag;em.IR.4-8um" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:147:   <FIELD ID="col14" datatype="float" name="8.0mag" precision="2" ucd="phot.mag;em.IR.4-8um" unit="mag" width="4">
astropy/io/votable/tests/data/names.xml:157:   <FIELD ID="col15" datatype="float" name="Emag" precision="2" ucd="phot.mag;em.IR.8-15um" unit="mag" width="5">
astropy/io/votable/tests/data/names.xml:167:   <FIELD ID="col16" datatype="float" name="24mag" precision="2" ucd="phot.mag;em.IR.15-30um" unit="mag" width="4">
astropy/io/votable/tests/data/names.xml:177:   <FIELD ID="col17" arraysize="2" datatype="char" name="f_Name" ucd="meta.code" unit="---">
astropy/io/votable/tests/data/timesys_errors.xml:9:      <FIELD datatype="double" name="obs_time" ucd="time.epoch" unit="d" ref="time_frame"/>
astropy/io/votable/tests/data/timesys_errors.xml:10:      <FIELD datatype="float" name="flux" ucd="phot.flux;em.opt.V" unit="s**-1"/>
astropy/io/votable/tests/data/timesys_errors.xml:11:      <FIELD datatype="float" name="mag" ucd="phot.mag;em.opt.V" unit="mag"/>
astropy/io/votable/tests/data/timesys_errors.xml:12:      <FIELD datatype="float" name="flux_error" ucd="stat.error;phot.flux;em.opt.V" 
astropy/io/votable/tests/data/timesys_errors.xml:14:      <PARAM datatype="double" name="ra" ucd="pos.eq.ra" value="45.7164887146879" ref="system"/>
astropy/io/votable/tests/data/timesys_errors.xml:15:      <PARAM datatype="double" name="dec" ucd="pos.eq.dec" value="1.18583048057467" ref="system"/>
astropy/io/votable/tests/data/binary2_masked_strings.xml:17:<FIELD datatype="long" name="source_id" ucd="meta.id">
astropy/io/votable/tests/data/binary2_masked_strings.xml:20:<FIELD datatype="double" name="ra" ref="GAIADR2" ucd="pos.eq.ra;meta.main" unit="deg" utype="Char.SpatialAxis.Coverage.Location.Coord.Position2D.Value2.C1">
astropy/io/votable/tests/data/binary2_masked_strings.xml:23:<FIELD datatype="double" name="dec" ref="GAIADR2" ucd="pos.eq.dec;meta.main" unit="deg" utype="Char.SpatialAxis.Coverage.Location.Coord.Position2D.Value2.C2">
astropy/io/votable/tests/data/binary2_masked_strings.xml:26:<FIELD datatype="float" name="a_g_val" ucd="phys.absorption.gal" unit="mag">
astropy/io/votable/tests/data/binary2_masked_strings.xml:29:<FIELD arraysize="*" datatype="char" name="datalink_url" ucd="meta.ref.url" utype="Acess.reference">
astropy/io/votable/tests/data/binary2_masked_strings.xml:32:<FIELD arraysize="*" datatype="char" name="epoch_photometry_url" ucd="meta.ref.url" utype="Acess.reference">
astropy/io/votable/tests/data/binary2_variable_length_char.xml:7:      <FIELD name="access_format" datatype="char" arraysize="128*" ucd="meta.code.mime" utype="Access.format">
astropy/io/votable/tests/test_ucd.py:5:from astropy.io.votable import ucd
astropy/io/votable/tests/test_ucd.py:9:    assert ucd.check_ucd(None)
astropy/io/votable/tests/test_ucd.py:55:        assert ucd.parse_ucd(s, True, True) == p
astropy/io/votable/tests/test_ucd.py:56:        assert ucd.check_ucd(s, True, True)
astropy/io/votable/tests/test_ucd.py:61:        ucd.parse_ucd("ivoa:stsci:phot", True, True)
astropy/io/votable/tests/test_ucd.py:66:        ucd.parse_ucd("_ivoa:phot.mag", True, True)
astropy/io/votable/tests/test_ucd.py:71:        ucd.parse_ucd("-pho")
astropy/io/votable/tests/test_ucd.py:74:def test_atmospheric_wind_ucd():
astropy/io/votable/tests/test_ucd.py:81:    ucd_string = "phys.veloc;obs.atmos.wind;stat.mean"
astropy/io/votable/tests/test_ucd.py:82:    result = ucd.parse_ucd(ucd_string, check_controlled_vocabulary=True)
astropy/io/votable/tests/test_ucd.py:100:        result = ucd.parse_ucd(term, check_controlled_vocabulary=True)
astropy/io/votable/tests/test_ucd.py:102:        assert ucd.check_ucd(term, check_controlled_vocabulary=True)
astropy/io/votable/tests/test_ucd.py:112:        combined_ucd = f"phys.temperature;{term}"
astropy/io/votable/tests/test_ucd.py:113:        result = ucd.parse_ucd(combined_ucd, check_controlled_vocabulary=True)
astropy/io/votable/tests/test_ucd.py:116:        assert ucd.check_ucd(combined_ucd, check_controlled_vocabulary=True)
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.3.xml:95:    <PARAMref ref="awesome"/>
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.3.xml:103:     <PARAMref ref="awesome"/>
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.1.xml:95:    <PARAMref ref="awesome"/>
astropy/io/votable/tests/data/regression.bin.tabledata.truth.1.1.xml:103:     <PARAMref ref="awesome"/>
astropy/io/votable/tests/data/regression.xml:36:  <PARAMref ref="awesome"/>
astropy/io/votable/tests/data/regression.xml:102:    <PARAMref ref="awesome"/>
@pytest.mark.parametrize("path_format", ["plain", "tilde"])
def test_writeto(path_format, tmp_path, home_is_tmpdir):
    if path_format == "plain":
        # pathlib.Path objects are not accepted by votable.writeto, so convert
        # to a string
        fname = str(tmp_path / "writeto_test.vot")
    else:
        fname = os.path.join("~", "writeto_test.vot")

    t = Table()
    t["a"] = [1, 2, 3]
    vt = from_table(t)
    writeto(vt, fname)

    if path_format == "tilde":
        # Ensure the tilde-prefixed path wasn't treated literally
        assert not os.path.exists(fname)

    with open(os.path.expanduser(fname)) as f:
        obuff = f.read()
    assert 'VOTABLE version="1.4"' in obuff
    assert "BINARY" not in obuff
    assert "TABLEDATA" in obuff


def test_empty_table():
    votable = parse(get_pkg_data_filename("data/empty_table.xml"))
    table = votable.get_first_table()
    table.to_table()


def test_no_field_not_empty_table():
    votable = parse(get_pkg_data_filename("data/no_field_not_empty_table.xml"))
    table = votable.get_first_table()
    assert len(table.fields) == 0
    assert len(table.infos) == 1


def test_no_field_not_empty_table_exception():
    with pytest.raises(E25):
        parse(
            get_pkg_data_filename("data/no_field_not_empty_table.xml"),
            verify="exception",
        )


def test_binary2_masked_strings():
    """
    Issue #8995.
    """
    # Read a VOTable which sets the null mask bit for each empty string value.
    votable = parse(get_pkg_data_filename("data/binary2_masked_strings.xml"))
    table = votable.get_first_table()
    astropy_table = table.to_table()

    # Ensure string columns have no masked values and can be written out
    assert not np.any(table.array.mask["epoch_photometry_url"])
    output = io.BytesIO()
    astropy_table.write(output, format="votable")


def test_validate_output_invalid():
    """
    Issue #12603. Test that we get the correct output from votable.validate with an invalid
    votable.
    """
    # A votable with errors
    invalid_votable_filepath = get_pkg_data_filename("data/regression.xml")

    # When output is None, check that validate returns validation output as a string
    validate_out = validate(invalid_votable_filepath, output=None)
    assert isinstance(validate_out, str)
    # Check for known error string
    assert "E02: Incorrect number of elements in array." in validate_out

    # When output is not set, check that validate returns a bool
    validate_out = validate(invalid_votable_filepath)
    assert isinstance(validate_out, bool)
    # Check that validation output is correct (votable is not valid)
    assert validate_out is False


def test_validate_output_valid():
    """
    Issue #12603. Test that we get the correct output from votable.validate with a valid
    votable.
    """
    # A valid votable. (Example from the votable standard:
    # https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html )
    valid_votable_filepath = get_pkg_data_filename("data/valid_votable.xml")

    # When output is None, check that validate returns validation output as a string
    validate_out = validate(valid_votable_filepath, output=None)
    assert isinstance(validate_out, str)
    # Check for known good output string
    assert "astropy.io.votable found no violations" in validate_out

    # When output is not set, check that validate returns a bool
    validate_out = validate(valid_votable_filepath)
    assert isinstance(validate_out, bool)
    # Check that validation output is correct (votable is valid)
    assert validate_out is True


def test_binary2_single_bounded_char_array():
    """
    Test that variable length char arrays with a max length
    (arraysize="128*") are read correctly in BINARY2 format.
    """
    votable = parse(get_pkg_data_filename("data/binary2_variable_length_char.xml"))
    table = votable.get_first_table()
    astropy_table = table.to_table()

    assert len(astropy_table) == 1
    assert (
        astropy_table[0]["access_format"]
        == "application/x-votable+xml;content=datalink"
    )

    output = io.BytesIO()
    astropy_table.write(output, format="votable", tabledata_format="binary2")
    output.seek(0)

    votable2 = parse(output)
    table2 = votable2.get_first_table()
    astropy_table2 = table2.to_table()

    assert len(astropy_table2) == 1
    assert (
        astropy_table2[0]["access_format"]
        == "application/x-votable+xml;content=datalink"
    )


def test_binary2_bounded_variable_length_char():
    """
    Test that max length variable length char arrays (arraysize="128*")
    are correctly serialized and deserialized correctly
    """
    votable = tree.VOTableFile()
    resource = tree.Resource()
    votable.resources.append(resource)
    table = tree.TableElement(votable)
    resource.tables.append(table)

    table.fields.append(
        tree.Field(
            votable,
            name="bounded_char",
            datatype="char",
            arraysize="128*",
    resource = tree.Resource()
    votable.resources.append(resource)
    table = tree.TableElement(votable)
    resource.tables.append(table)

    tabarr = []
    heads = ["headA", "headB", "headC"]
    types = ["char", "double", "int"]

    vals = [["A", 1.0, 2], ["B", 2.0, 3], ["C", 3.0, 4]]
    for i in range(len(heads)):
        tabarr.append(
            tree.Field(votable, name=heads[i], datatype=types[i], arraysize="*")
        )

    table.fields.extend(tabarr)
    table.create_arrays(len(vals))
    for i in range(len(vals)):
        values = tuple(vals[i])
        table.array[i] = values
    buff = io.BytesIO()
    votable.to_xml(buff)


def test_gemini_v1_2():
    """
    see Pull Request 4782 or Issue 4781 for details.
    """
    table = parse_single_table(get_pkg_data_filename("data/gemini.xml"))
    assert table is not None

    tt = table.to_table()
    assert (
        tt["access_url"][0]
        == "http://www.cadc-ccda.hia-iha.nrc-cnrc.gc.ca/data/pub/GEMINI/"
        "S20120515S0064?runid=bx9b1o8cvk1qesrt"
    )
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"get_ref|iter_values|get_values_by_id|<VOTABLE>\\.\\.\\.|_attr_list_11|namespace_uri|schema_location\" astropy/io/votable/tests astropy/io/votable | head -400
sed -n '250,325p' astropy/io/votable/tests/test_table.py
sed -n '1,180p' astropy/io/votable/tests/test_tree.py"
```

退出码：`0`

输出：
```
astropy/io/votable/tree.py:781:    _attr_list_11 = ["ID", "name", "value"]
astropy/io/votable/tree.py:782:    _attr_list_12 = _attr_list_11 + ["xtype", "ref", "unit", "ucd", "utype"]
astropy/io/votable/tree.py:819:            self._attr_list = self._attr_list_11
astropy/io/votable/tree.py:890:        #         other = self._votable.get_values_by_id(ref, before=self)
astropy/io/votable/tree.py:1057:                other = self._votable.get_values_by_id(ref, before=self)
astropy/io/votable/tree.py:1319:    _attr_list_11 = [
astropy/io/votable/tree.py:1331:    _attr_list_12 = _attr_list_11 + ["xtype"]
astropy/io/votable/tree.py:1362:            self._attr_list = self._attr_list_11
astropy/io/votable/tree.py:1792:    _attr_list_11 = Field._attr_list_11 + ["value"]
astropy/io/votable/tree.py:2195:    _attr_list_11 = ["ref"]
astropy/io/votable/tree.py:2196:    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
astropy/io/votable/tree.py:2225:            self._attr_list = self._attr_list_11
astropy/io/votable/tree.py:2245:    def get_ref(self):
astropy/io/votable/tree.py:2268:    _attr_list_11 = ["ref"]
astropy/io/votable/tree.py:2269:    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
astropy/io/votable/tree.py:2290:            self._attr_list = self._attr_list_11
astropy/io/votable/tree.py:4298:            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.1",
astropy/io/votable/tree.py:4299:            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
astropy/io/votable/tree.py:4300:            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.1",
astropy/io/votable/tree.py:4303:            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.2",
astropy/io/votable/tree.py:4304:            "schema_location_attr": "xsi:noNamespaceSchemaLocation",
astropy/io/votable/tree.py:4305:            "schema_location_value": "http://www.ivoa.net/xml/VOTable/v1.2",
astropy/io/votable/tree.py:4314:            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
astropy/io/votable/tree.py:4315:            "schema_location_attr": "xsi:schemaLocation",
astropy/io/votable/tree.py:4316:            "schema_location_value": (
astropy/io/votable/tree.py:4325:            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
astropy/io/votable/tree.py:4326:            "schema_location_attr": "xsi:schemaLocation",
astropy/io/votable/tree.py:4327:            "schema_location_value": (
astropy/io/votable/tree.py:4333:            "namespace_uri": "http://www.ivoa.net/xml/VOTable/v1.3",
astropy/io/votable/tree.py:4334:            "schema_location_attr": "xsi:schemaLocation",
astropy/io/votable/tree.py:4335:            "schema_location_value": (
astropy/io/votable/tree.py:4369:                        correct_ns = ns_info.get("namespace_uri")
astropy/io/votable/tree.py:4465:            namespace_uri = ns_info.get("namespace_uri")
astropy/io/votable/tree.py:4466:            if namespace_uri:
astropy/io/votable/tree.py:4467:                votable_attr["xmlns"] = namespace_uri
astropy/io/votable/tree.py:4468:            schema_location_attr = ns_info.get("schema_location_attr")
astropy/io/votable/tree.py:4469:            schema_location_value = ns_info.get("schema_location_value")
astropy/io/votable/tree.py:4470:            if schema_location_attr and schema_location_value:
astropy/io/votable/tree.py:4471:                votable_attr[schema_location_attr] = schema_location_value
astropy/io/votable/tree.py:4585:    get_values_by_id = _lookup_by_attr_factory(
astropy/io/votable/tree.py:4588:        "iter_values",

def test_write_with_format():
    t = Table()
    c = Column(data=[1, 2, 3], name="a")
    t.add_column(c)

    output = io.BytesIO()
    t.write(output, format="votable", tabledata_format="binary")
    obuff = output.getvalue()
    assert b'VOTABLE version="1.4"' in obuff
    assert b"BINARY" in obuff
    assert b"TABLEDATA" not in obuff

    output = io.BytesIO()
    t.write(output, format="votable", tabledata_format="binary2")
    obuff = output.getvalue()
    assert b'VOTABLE version="1.4"' in obuff
    assert b"BINARY2" in obuff
    assert b"TABLEDATA" not in obuff


@pytest.mark.skipif(not HAS_PYARROW, reason="requires pyarrow")
@pytest.mark.parametrize("overwrite", [True, False])
def test_read_write_votable_parquet(tmp_path, overwrite):
    """
    Test to write and read VOTable with Parquet serialization
    """

    # Create some fake data
    number_of_objects = 10
    ids = [f"COSMOS_{ii:03g}" for ii in range(number_of_objects)]
    redshift = np.random.uniform(low=0, high=3, size=number_of_objects)
    mass = np.random.uniform(low=1e8, high=1e10, size=number_of_objects)
    sfr = np.random.uniform(low=1, high=100, size=number_of_objects)
    astropytab = Table([ids, redshift, mass, sfr], names=["id", "z", "mass", "sfr"])

    # Create Column metadata
    column_metadata = {
        "id": {"unit": "", "ucd": "meta.id", "utype": "none"},
        "z": {"unit": "", "ucd": "src.redshift", "utype": "none"},
        "mass": {"unit": "solMass", "ucd": "phys.mass", "utype": "none"},
        "sfr": {"unit": "solMass / yr", "ucd": "phys.SFR", "utype": "none"},
    }

    # Write VOTable with Parquet serialization
    filename = tmp_path / "test_votable_parquet.vot"
    astropytab.write(
        filename,
        column_metadata=column_metadata,
        overwrite=overwrite,
        format="votable.parquet",
    )

    # Check both files are written out
    assert set(os.listdir(tmp_path)) == {
        "test_votable_parquet.vot",
        "test_votable_parquet.vot.parquet",
    }

    # Open created VOTable with Parquet serialization
    with warnings.catch_warnings():
        warnings.simplefilter("always", ResourceWarning)
        votable = parse(filename)

    # Get table out
    votable_table = votable.resources[0].tables[0].array

    # compare tables
    assert (astropytab == votable_table).all()

    # Compare metadata
    # Note: VOTable parses empty units ("") as "---". This is
    # taken into account below by .replace("---","").
    saved_bool = []
    for kk, key in enumerate(column_metadata.keys()):
        for tag in column_metadata[key].keys():
# Licensed under a 3-clause BSD style license - see LICENSE.rst
import filecmp
import io

import numpy as np
import pytest

from astropy.io.votable import tree
from astropy.io.votable.exceptions import (
    E26,
    W07,
    W08,
    W15,
    W21,
    W27,
    W37,
    W41,
    W47,
    W54,
    W57,
)
from astropy.io.votable.table import parse
from astropy.io.votable.tree import MivotBlock, Resource, VOTableFile
from astropy.utils.data import get_pkg_data_filename


def test_check_astroyear_fail():
    config = {"verify": "exception"}
    field = tree.Field(None, name="astroyear", arraysize="1")
    with pytest.raises(W07):
        tree.check_astroyear("X2100", field, config)


def test_string_fail():
    config = {"verify": "exception"}
    with pytest.raises(W08):
        tree.check_string(42, "foo", config)


def test_make_Fields():
    votable = VOTableFile()
    # ...with one resource...
    resource = Resource()
    votable.resources.append(resource)

    # ... with one table
    table = tree.TableElement(votable)
    resource.tables.append(table)

    table.fields.extend(
        [tree.Field(votable, name="Test", datatype="float", unit="mag")]
    )


def test_unit_format():
    data = parse(get_pkg_data_filename("data/irsa-nph-error.xml"))
    assert data._config["version"] == "1.0"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/names.xml"))
    assert data._config["version"] == "1.1"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/gemini.xml"))
    assert data._config["version"] == "1.2"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/binary2_masked_strings.xml"))
    assert data._config["version"] == "1.3"
    assert tree._get_default_unit_format(data._config) == "cds"
    data = parse(get_pkg_data_filename("data/timesys.xml"))
    assert data._config["version"] == "1.4"
    assert tree._get_default_unit_format(data._config) == "vounit"


def test_namespace_warning():
    """
    A version 1.4 VOTable must use the same namespace as 1.3.
    (see https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html#ToC16).
    """
    bad_namespace = b"""<?xml version="1.0" encoding="utf-8"?>
        <VOTABLE version="1.4" xmlns="http://www.ivoa.net/xml/VOTable/v1.4"
                               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <RESOURCE/>
        </VOTABLE>
    """
    with pytest.warns(W41):
        parse(io.BytesIO(bad_namespace), verify="exception")

    good_namespace_14 = b"""<?xml version="1.0" encoding="utf-8"?>
        <VOTABLE version="1.4" xmlns="http://www.ivoa.net/xml/VOTable/v1.3"
                               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <RESOURCE/>
        </VOTABLE>
    """
    parse(io.BytesIO(good_namespace_14), verify="exception")

    good_namespace_13 = b"""<?xml version="1.0" encoding="utf-8"?>
        <VOTABLE version="1.3" xmlns="http://www.ivoa.net/xml/VOTable/v1.3"
                               xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">
          <RESOURCE/>
        </VOTABLE>
    """
    parse(io.BytesIO(good_namespace_13), verify="exception")


def test_votable_values_empty_min_max():
    """Regression test for https://github.com/astropy/astropy/issues/16825"""
    with_empty_minmax = b"""<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.4">
        <RESOURCE type="results">
          <TABLE name="main">
            <PARAM name="break" datatype="int" value=""/>
          <FIELD ID="hd" datatype="int" name="hd" ucd="meta.id;meta.main">
            <DESCRIPTION>HD number for this object</DESCRIPTION>
            <VALUES null="-2147483648">
              <MIN value=""/>
              <MAX value=""/>
            </VALUES>
          </FIELD>
          <DATA>
            <BINARY>
              <STREAM encoding="base64">AAMNIg==</STREAM>
            </BINARY>
          </DATA>
        </TABLE>
      </RESOURCE>
    </VOTABLE>
    """
    parse(io.BytesIO(with_empty_minmax), verify="exception")


def _assert_minmax_match(val, expected_val):
    """val can be number or numpy array; expected_val can be number or list"""
    if isinstance(val, np.ndarray):
        assert np.allclose(val, np.array(expected_val))
    else:
        assert val == expected_val


@pytest.mark.parametrize(
    ("testvals"),
    [
        {
            "dt": "float",
            "min": "1.2",
            "max": "3.4",
            "expected_min": 1.2,
            "expected_max": 3.4,
        },
        {
            "dt": "float",
            "min": "1.2 3.4",
            "max": "3.4 5.6",
            "expected_min": [1.2, 3.4],
            "expected_max": [3.4, 5.6],
        },
        {
            "dt": "double",
            "min": "1.2",
            "max": "3.4",
            "expected_min": 1.2,
            "expected_max": 3.4,
        },
        {
            "dt": "double",
            "min": "1.2 3.4",
            "max": "3.4 5.6",
            "expected_min": [1.2, 3.4],
            "expected_max": [3.4, 5.6],
        },
        {
            "dt": "unsignedByte",
            "min": "1",
            "max": "3",
            "expected_min": 1,
            "expected_max": 3,
        },
        {
            "dt": "unsignedByte",
            "min": "1 3",
            "max": "3 5",
            "expected_min": [1, 3],
            "expected_max": [3, 5],
```

## 原始行 39 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def to_xml\" astropy/io/votable/tree.py | head -30
nl -ba astropy/io/votable/tree.py | sed -n '3260,3465p'
nl -ba astropy/io/votable/tree.py | sed -n '500,850p'
nl -ba astropy/io/votable/tree.py | sed -n '850,1120p'"
```

退出码：`0`

输出：
```
559:    def to_xml(self, w, **kwargs):
596:    def to_xml(self, w, **kwargs):
622:    def to_xml(self, w, **kwargs):
941:    def to_xml(self, w, **kwargs):
1236:    def to_xml(self, w, **kwargs):
1700:    def to_xml(self, w, **kwargs):
1855:    def to_xml(self, w, **kwargs):
2447:    def to_xml(self, w, **kwargs):
3349:    def to_xml(self, w, **kwargs):
3766:    def to_xml(self, w):
4054:    def to_xml(self, w, **kwargs):
4406:    def to_xml(
  3260	                fd = gzip.GzipFile(href, "r", fileobj=fd)
  3261	            elif encoding == "base64":
  3262	                fd = codecs.EncodedFile(fd, "base64")
  3263	            else:
  3264	                vo_raise(
  3265	                    NotImplementedError,
  3266	                    f"Unknown encoding type '{encoding}'",
  3267	                    self._config,
  3268	                    self._pos,
  3269	                )
  3270	        hdulist = fits.open(fd)
  3271	
  3272	        array = hdulist[int(extnum)].data
  3273	        if array.dtype != self.array.dtype:
  3274	            warn_or_raise(W19, W19, (), self._config, self._pos)
  3275	
  3276	        return array
  3277	
  3278	    def _parse_parquet(self, iterator, config):
  3279	        """
  3280	        Functionality to parse parquet files that are embedded
  3281	        in VOTables.
  3282	        """
  3283	        from astropy.table import Table
  3284	
  3285	        for start, tag, data, pos in iterator:
  3286	            if tag == "STREAM":
  3287	                if start:
  3288	                    warn_unknown_attrs(
  3289	                        "STREAM",
  3290	                        data.keys(),
  3291	                        config,
  3292	                        pos,
  3293	                        ["type", "href", "actuate", "encoding", "expires", "rights"],
  3294	                    )
  3295	                    href = data["href"]
  3296	                    encoding = data.get("encoding", None)
  3297	                else:
  3298	                    break
  3299	
  3300	            else:  # in this case, there is no STREAM, hence no file linked.
  3301	                href = ""
  3302	
  3303	        if not href.startswith(("http", "ftp", "file")):
  3304	            vo_raise(
  3305	                NotImplementedError,
  3306	                "The vo package only supports remote data through http, ftp or file",
  3307	                self._config,
  3308	                self._pos,
  3309	            )
  3310	
  3311	        try:
  3312	            # Hack to keep windows working
  3313	            try:
  3314	                fd = urllib.request.urlopen(href)
  3315	            except urllib.error.URLError:
  3316	                # Hack to keep windows working
  3317	                if href.startswith("file://"):
  3318	                    fd = urllib.request.urlopen(f"file:{href[7:]}")
  3319	                # Relative path to parquet part should be relative from the votable
  3320	                elif href.startswith("file:"):
  3321	                    parquet = os.path.join(
  3322	                        os.path.dirname(config["filename"]), href[5:]
  3323	                    )
  3324	                    fd = urllib.request.urlopen(f"file:{parquet}")
  3325	
  3326	            if encoding is not None:
  3327	                if encoding == "gzip":
  3328	                    fd = gzip.GzipFile(href, "r", fileobj=fd)
  3329	                elif encoding == "base64":
  3330	                    fd = codecs.EncodedFile(fd, "base64")
  3331	                else:
  3332	                    vo_raise(
  3333	                        NotImplementedError,
  3334	                        f"Unknown encoding type '{encoding}'",
  3335	                        self._config,
  3336	                        self._pos,
  3337	                    )
  3338	
  3339	            array = Table.read(fd, format="parquet")
  3340	        finally:
  3341	            if hasattr(fd, "close"):
  3342	                fd.close()
  3343	
  3344	        if array.dtype != self.array.dtype:
  3345	            warn_or_raise(W56, W56, (), self._config, self._pos)
  3346	
  3347	        return array
  3348	
  3349	    def to_xml(self, w, **kwargs):
  3350	        specified_format = kwargs.get("tabledata_format")
  3351	        if specified_format is not None:
  3352	            format = specified_format
  3353	        else:
  3354	            format = self.format
  3355	        if format == "fits":
  3356	            format = "tabledata"
  3357	
  3358	        with w.tag(
  3359	            "TABLE",
  3360	            attrib=w.object_attrs(self, ("ID", "name", "ref", "ucd", "utype", "nrows")),
  3361	        ):
  3362	            if self.description is not None:
  3363	                w.element("DESCRIPTION", self.description, wrap=True)
  3364	
  3365	            for element_set in (self.fields, self.params):
  3366	                for element in element_set:
  3367	                    element._setup({}, None)
  3368	
  3369	            if self.ref is None:
  3370	                for element_set in (self.fields, self.params, self.groups, self.links):
  3371	                    for element in element_set:
  3372	                        element.to_xml(w, **kwargs)
  3373	            elif kwargs["version_1_2_or_later"]:
  3374	                index = list(self._votable.iter_tables()).index(self)
  3375	                group = Group(self, ID=f"_g{index}")
  3376	                group.to_xml(w, **kwargs)
  3377	
  3378	            if len(self.array):
  3379	                with w.tag("DATA"):
  3380	                    if format == "tabledata":
  3381	                        self._write_tabledata(w, **kwargs)
  3382	                    elif format == "binary":
  3383	                        self._write_binary(1, w, **kwargs)
  3384	                    elif format == "binary2":
  3385	                        self._write_binary(2, w, **kwargs)
  3386	
  3387	            if kwargs["version_1_2_or_later"]:
  3388	                for element in self._infos:
  3389	                    element.to_xml(w, **kwargs)
  3390	
  3391	    def _write_tabledata(self, w, **kwargs):
  3392	        fields = self.fields
  3393	        array = self.array
  3394	
  3395	        with w.tag("TABLEDATA"):
  3396	            w._flush()
  3397	            if _has_c_tabledata_writer and not kwargs.get("_debug_python_based_parser"):
  3398	                supports_empty_values = [
  3399	                    field.converter.supports_empty_values(kwargs) for field in fields
  3400	                ]
  3401	                fields = [field.converter.output for field in fields]
  3402	                indent = len(w._tags) - 1
  3403	                tablewriter.write_tabledata(
  3404	                    w.write,
  3405	                    array.data,
  3406	                    array.mask,
  3407	                    fields,
  3408	                    supports_empty_values,
  3409	                    indent,
  3410	                    1 << 8,
  3411	                )
  3412	            else:
  3413	                write = w.write
  3414	                indent_spaces = w.get_indentation_spaces()
  3415	                tr_start = indent_spaces + "<TR>\n"
  3416	                tr_end = indent_spaces + "</TR>\n"
  3417	                td = indent_spaces + " <TD>{}</TD>\n"
  3418	                td_empty = indent_spaces + " <TD/>\n"
  3419	                fields = [
  3420	                    (
  3421	                        i,
  3422	                        field.converter.output,
  3423	                        field.converter.supports_empty_values(kwargs),
  3424	                    )
  3425	                    for i, field in enumerate(fields)
  3426	                ]
  3427	                for row in range(len(array)):
  3428	                    write(tr_start)
  3429	                    array_row = array.data[row]
  3430	                    mask_row = array.mask[row]
  3431	                    for i, output, supports_empty_values in fields:
  3432	                        data = array_row[i]
  3433	                        masked = mask_row[i]
  3434	                        if supports_empty_values and np.all(masked):
  3435	                            write(td_empty)
  3436	                        else:
  3437	                            try:
  3438	                                val = output(data, masked)
  3439	                            except Exception as e:
  3440	                                vo_reraise(
  3441	                                    e,
  3442	                                    additional=(
  3443	                                        f"(in row {row:d}, col '{self.fields[i].ID}')"
  3444	                                    ),
  3445	                                )
  3446	                            if len(val):
  3447	                                write(td.format(val))
  3448	                            else:
  3449	                                write(td_empty)
  3450	                    write(tr_end)
  3451	
  3452	    def _write_binary(self, mode, w, **kwargs):
  3453	        fields = self.fields
  3454	        array = self.array
  3455	        if mode == 1:
  3456	            tag_name = "BINARY"
  3457	        else:
  3458	            tag_name = "BINARY2"
  3459	
  3460	        with w.tag(tag_name):
  3461	            with w.tag("STREAM", encoding="base64"):
  3462	                fields_basic = [
  3463	                    (i, field.converter.binoutput) for (i, field) in enumerate(fields)
  3464	                ]
  3465	
   500	        """
   501	        An optional string describing the element.  Corresponds to the
   502	        DESCRIPTION_ element.
   503	        """
   504	        return self._description
   505	
   506	    @description.setter
   507	    def description(self, description):
   508	        self._description = description
   509	
   510	    @description.deleter
   511	    def description(self):
   512	        self._description = None
   513	
   514	
   515	######################################################################
   516	# ELEMENT CLASSES
   517	class Element:
   518	    """
   519	    A base class for all classes that represent XML elements in the
   520	    VOTABLE file.
   521	    """
   522	
   523	    _element_name = ""
   524	    _attr_list = []
   525	
   526	    def _add_unknown_tag(self, iterator, tag, data, config, pos):
   527	        warn_or_raise(W10, W10, tag, config, pos)
   528	
   529	    def _ignore_add(self, iterator, tag, data, config, pos):
   530	        warn_unknown_attrs(tag, data.keys(), config, pos)
   531	
   532	    def _add_definitions(self, iterator, tag, data, config, pos):
   533	        if config.get("version_1_1_or_later"):
   534	            warn_or_raise(W22, W22, (), config, pos)
   535	        warn_unknown_attrs(tag, data.keys(), config, pos)
   536	
   537	    def parse(self, iterator, config):
   538	        """
   539	        For internal use. Parse the XML content of the children of the
   540	        element.
   541	
   542	        Parameters
   543	        ----------
   544	        iterator : xml iterable
   545	            An iterator over XML elements as returned by
   546	            `~astropy.utils.xml.iterparser.get_xml_iterator`.
   547	
   548	        config : dict
   549	            The configuration dictionary that affects how certain
   550	            elements are read.
   551	
   552	        Returns
   553	        -------
   554	        self : `~astropy.io.votable.tree.Element`
   555	            Returns self as a convenience.
   556	        """
   557	        raise NotImplementedError()
   558	
   559	    def to_xml(self, w, **kwargs):
   560	        """
   561	        For internal use. Output the element to XML.
   562	
   563	        Parameters
   564	        ----------
   565	        w : astropy.utils.xml.writer.XMLWriter object
   566	            An XML writer to write to.
   567	        **kwargs : dict
   568	            Any configuration parameters to control the output.
   569	        """
   570	        raise NotImplementedError()
   571	
   572	
   573	class SimpleElement(Element):
   574	    """
   575	    A base class for simple elements, such as FIELD, PARAM and INFO
   576	    that don't require any special parsing or outputting machinery.
   577	    """
   578	
   579	    def __init__(self):
   580	        Element.__init__(self)
   581	
   582	    def __repr__(self):
   583	        buff = io.StringIO()
   584	        SimpleElement.to_xml(self, XMLWriter(buff))
   585	        return buff.getvalue().strip()
   586	
   587	    def parse(self, iterator, config):
   588	        for start, tag, data, pos in iterator:
   589	            if start and tag != self._element_name:
   590	                self._add_unknown_tag(iterator, tag, data, config, pos)
   591	            elif tag == self._element_name:
   592	                break
   593	
   594	        return self
   595	
   596	    def to_xml(self, w, **kwargs):
   597	        w.element(self._element_name, attrib=w.object_attrs(self, self._attr_list))
   598	
   599	
   600	class SimpleElementWithContent(SimpleElement):
   601	    """
   602	    A base class for simple elements, such as FIELD, PARAM and INFO
   603	    that don't require any special parsing or outputting machinery.
   604	    """
   605	
   606	    def __init__(self):
   607	        SimpleElement.__init__(self)
   608	
   609	        self._content = None
   610	
   611	    def parse(self, iterator, config):
   612	        for start, tag, data, pos in iterator:
   613	            if start and tag != self._element_name:
   614	                self._add_unknown_tag(iterator, tag, data, config, pos)
   615	            elif tag == self._element_name:
   616	                if data:
   617	                    self.content = data
   618	                break
   619	
   620	        return self
   621	
   622	    def to_xml(self, w, **kwargs):
   623	        w.element(
   624	            self._element_name,
   625	            self._content,
   626	            attrib=w.object_attrs(self, self._attr_list),
   627	        )
   628	
   629	    @property
   630	    def content(self):
   631	        """The content of the element."""
   632	        return self._content
   633	
   634	    @content.setter
   635	    def content(self, content):
   636	        check_string(content, "content", self._config, self._pos)
   637	        self._content = content
   638	
   639	    @content.deleter
   640	    def content(self):
   641	        self._content = None
   642	
   643	
   644	class Link(SimpleElement, _IDProperty):
   645	    """
   646	    LINK_ elements: used to reference external documents and servers through a URI.
   647	
   648	    The keyword arguments correspond to setting members of the same
   649	    name, documented below.
   650	    """
   651	
   652	    _attr_list = [
   653	        "ID",
   654	        "content_role",
   655	        "content_type",
   656	        "title",
   657	        "value",
   658	        "href",
   659	        "action",
   660	    ]
   661	    _element_name = "LINK"
   662	
   663	    def __init__(
   664	        self,
   665	        ID=None,
   666	        title=None,
   667	        value=None,
   668	        href=None,
   669	        action=None,
   670	        id=None,
   671	        config=None,
   672	        pos=None,
   673	        **kwargs,
   674	    ):
   675	        if config is None:
   676	            config = {}
   677	        self._config = config
   678	        self._pos = pos
   679	
   680	        SimpleElement.__init__(self)
   681	
   682	        content_role = kwargs.get("content-role") or kwargs.get("content_role")
   683	        content_type = kwargs.get("content-type") or kwargs.get("content_type")
   684	
   685	        if "gref" in kwargs:
   686	            warn_or_raise(W11, W11, (), config, pos)
   687	
   688	        self.ID = resolve_id(ID, id, config, pos)
   689	        self.content_role = content_role
   690	        self.content_type = content_type
   691	        self.title = title
   692	        self.value = value
   693	        self.href = href
   694	        self.action = action
   695	
   696	        warn_unknown_attrs(
   697	            "LINK",
   698	            kwargs.keys(),
   699	            config,
   700	            pos,
   701	            ["content-role", "content_role", "content-type", "content_type", "gref"],
   702	        )
   703	
   704	    @property
   705	    def content_role(self):
   706	        """Defines the MIME role of the referenced object.
   707	
   708	        Must be one of:
   709	
   710	          None, 'query', 'hints', 'doc', 'location' or 'type'
   711	        """
   712	        return self._content_role
   713	
   714	    @content_role.setter
   715	    def content_role(self, content_role):
   716	        if (
   717	            content_role == "type" and not self._config.get("version_1_3_or_later")
   718	        ) or content_role not in (None, "query", "hints", "doc", "location"):
   719	            vo_warn(W45, (content_role,), self._config, self._pos)
   720	        self._content_role = content_role
   721	
   722	    @content_role.deleter
   723	    def content_role(self):
   724	        self._content_role = None
   725	
   726	    @property
   727	    def content_type(self):
   728	        """Defines the MIME content type of the referenced object."""
   729	        return self._content_type
   730	
   731	    @content_type.setter
   732	    def content_type(self, content_type):
   733	        xmlutil.check_mime_content_type(content_type, self._config, self._pos)
   734	        self._content_type = content_type
   735	
   736	    @content_type.deleter
   737	    def content_type(self):
   738	        self._content_type = None
   739	
   740	    @property
   741	    def href(self):
   742	        """
   743	        A URI to an arbitrary protocol.  The vo package only supports
   744	        http and anonymous ftp.
   745	        """
   746	        return self._href
   747	
   748	    @href.setter
   749	    def href(self, href):
   750	        xmlutil.check_anyuri(href, self._config, self._pos)
   751	        self._href = href
   752	
   753	    @href.deleter
   754	    def href(self):
   755	        self._href = None
   756	
   757	    def to_table_column(self, column):
   758	        meta = {}
   759	        for key in self._attr_list:
   760	            val = getattr(self, key, None)
   761	            if val is not None:
   762	                meta[key] = val
   763	
   764	        column.meta.setdefault("links", [])
   765	        column.meta["links"].append(meta)
   766	
   767	    @classmethod
   768	    def from_table_column(cls, d):
   769	        return cls(**d)
   770	
   771	
   772	class Info(SimpleElementWithContent, _IDProperty, _XtypeProperty, _UtypeProperty):
   773	    """
   774	    INFO_ elements: arbitrary key-value pairs for extensions to the standard.
   775	
   776	    The keyword arguments correspond to setting members of the same
   777	    name, documented below.
   778	    """
   779	
   780	    _element_name = "INFO"
   781	    _attr_list_11 = ["ID", "name", "value"]
   782	    _attr_list_12 = _attr_list_11 + ["xtype", "ref", "unit", "ucd", "utype"]
   783	    _utype_in_v1_2 = True
   784	
   785	    def __init__(
   786	        self,
   787	        ID=None,
   788	        name=None,
   789	        value=None,
   790	        id=None,
   791	        xtype=None,
   792	        ref=None,
   793	        unit=None,
   794	        ucd=None,
   795	        utype=None,
   796	        config=None,
   797	        pos=None,
   798	        **extra,
   799	    ):
   800	        if config is None:
   801	            config = {}
   802	        self._config = config
   803	        self._pos = pos
   804	
   805	        SimpleElementWithContent.__init__(self)
   806	
   807	        self.ID = resolve_id(ID, id, config, pos) or xmlutil.fix_id(name, config, pos)
   808	        self.name = name
   809	        self.value = value
   810	        self.xtype = xtype
   811	        self.ref = ref
   812	        self.unit = unit
   813	        self.ucd = ucd
   814	        self.utype = utype
   815	
   816	        if config.get("version_1_2_or_later"):
   817	            self._attr_list = self._attr_list_12
   818	        else:
   819	            self._attr_list = self._attr_list_11
   820	            if xtype is not None:
   821	                warn_unknown_attrs("INFO", ["xtype"], config, pos)
   822	            if ref is not None:
   823	                warn_unknown_attrs("INFO", ["ref"], config, pos)
   824	            if unit is not None:
   825	                warn_unknown_attrs("INFO", ["unit"], config, pos)
   826	            if ucd is not None:
   827	                warn_unknown_attrs("INFO", ["ucd"], config, pos)
   828	            if utype is not None:
   829	                warn_unknown_attrs("INFO", ["utype"], config, pos)
   830	
   831	        warn_unknown_attrs("INFO", extra.keys(), config, pos)
   832	
   833	    @property
   834	    def name(self):
   835	        """[*required*] The key of the key-value pair."""
   836	        return self._name
   837	
   838	    @name.setter
   839	    def name(self, name):
   840	        if name is None:
   841	            warn_or_raise(W35, W35, "name", self._config, self._pos)
   842	        xmlutil.check_token(name, "name", self._config, self._pos)
   843	        self._name = name
   844	
   845	    @property
   846	    def value(self):
   847	        """
   848	        [*required*] The value of the key-value pair.  (Always stored
   849	        as a string or unicode string).
   850	        """
   850	        """
   851	        return self._value
   852	
   853	    @value.setter
   854	    def value(self, value):
   855	        if value is None:
   856	            warn_or_raise(W35, W35, "value", self._config, self._pos)
   857	        check_string(value, "value", self._config, self._pos)
   858	        self._value = value
   859	
   860	    @property
   861	    def content(self):
   862	        """The content inside the INFO element."""
   863	        return self._content
   864	
   865	    @content.setter
   866	    def content(self, content):
   867	        check_string(content, "content", self._config, self._pos)
   868	        self._content = content
   869	
   870	    @content.deleter
   871	    def content(self):
   872	        self._content = None
   873	
   874	    @property
   875	    def ref(self):
   876	        """
   877	        Refer to another INFO_ element by ID_, defined previously in
   878	        the document.
   879	        """
   880	        return self._ref
   881	
   882	    @ref.setter
   883	    def ref(self, ref):
   884	        if ref is not None and not self._config.get("version_1_2_or_later"):
   885	            warn_or_raise(W28, W28, ("ref", "INFO", "1.2"), self._config, self._pos)
   886	        xmlutil.check_id(ref, "ref", self._config, self._pos)
   887	        # TODO: actually apply the reference
   888	        # if ref is not None:
   889	        #     try:
   890	        #         other = self._votable.get_values_by_id(ref, before=self)
   891	        #     except KeyError:
   892	        #         vo_raise(
   893	        #             "VALUES ref='%s', which has not already been defined." %
   894	        #             self.ref, self._config, self._pos, KeyError)
   895	        #     self.null = other.null
   896	        #     self.type = other.type
   897	        #     self.min = other.min
   898	        #     self.min_inclusive = other.min_inclusive
   899	        #     self.max = other.max
   900	        #     self.max_inclusive = other.max_inclusive
   901	        #     self._options[:] = other.options
   902	        self._ref = ref
   903	
   904	    @ref.deleter
   905	    def ref(self):
   906	        self._ref = None
   907	
   908	    @property
   909	    def unit(self):
   910	        """A string specifying the units_ for the INFO_."""
   911	        return self._unit
   912	
   913	    @unit.setter
   914	    def unit(self, unit):
   915	        if unit is None:
   916	            self._unit = None
   917	            return
   918	
   919	        from astropy import units as u
   920	
   921	        if not self._config.get("version_1_2_or_later"):
   922	            warn_or_raise(W28, W28, ("unit", "INFO", "1.2"), self._config, self._pos)
   923	
   924	        # First, parse the unit in the default way, so that we can
   925	        # still emit a warning if the unit is not to spec.
   926	        default_format = _get_default_unit_format(self._config)
   927	        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
   928	        if isinstance(unit_obj, u.UnrecognizedUnit):
   929	            warn_or_raise(W50, W50, (unit,), self._config, self._pos)
   930	
   931	        format = _get_unit_format(self._config)
   932	        if format != default_format:
   933	            unit_obj = u.Unit(unit, format=format, parse_strict="silent")
   934	
   935	        self._unit = unit_obj
   936	
   937	    @unit.deleter
   938	    def unit(self):
   939	        self._unit = None
   940	
   941	    def to_xml(self, w, **kwargs):
   942	        attrib = w.object_attrs(self, self._attr_list)
   943	        if "unit" in attrib:
   944	            attrib["unit"] = self.unit.to_string("cds")
   945	        w.element(self._element_name, self._content, attrib=attrib)
   946	
   947	
   948	class Values(Element, _IDProperty):
   949	    """
   950	    VALUES_ element: used within FIELD_ and PARAM_ elements to define the domain of values.
   951	
   952	    The keyword arguments correspond to setting members of the same
   953	    name, documented below.
   954	    """
   955	
   956	    def __init__(
   957	        self,
   958	        votable,
   959	        field,
   960	        ID=None,
   961	        null=None,
   962	        ref=None,
   963	        type="legal",
   964	        id=None,
   965	        config=None,
   966	        pos=None,
   967	        **extras,
   968	    ):
   969	        if config is None:
   970	            config = {}
   971	        self._config = config
   972	        self._pos = pos
   973	
   974	        Element.__init__(self)
   975	
   976	        self._votable = votable
   977	        self._field = field
   978	        self.ID = resolve_id(ID, id, config, pos)
   979	        self.null = null
   980	        self._ref = ref
   981	        self.type = type
   982	
   983	        self.min = None
   984	        self.max = None
   985	        self.min_inclusive = True
   986	        self.max_inclusive = True
   987	        self._options = []
   988	
   989	        warn_unknown_attrs("VALUES", extras.keys(), config, pos)
   990	
   991	    def __repr__(self):
   992	        buff = io.StringIO()
   993	        self.to_xml(XMLWriter(buff))
   994	        return buff.getvalue().strip()
   995	
   996	    @property
   997	    def null(self):
   998	        """
   999	        For integral datatypes, *null* is used to define the value
  1000	        used for missing values.
  1001	        """
  1002	        return self._null
  1003	
  1004	    @null.setter
  1005	    def null(self, null):
  1006	        if null is not None and isinstance(null, str):
  1007	            try:
  1008	                null_val = self._field.converter.parse_scalar(
  1009	                    null, self._config, self._pos
  1010	                )[0]
  1011	            except Exception:
  1012	                warn_or_raise(W36, W36, null, self._config, self._pos)
  1013	                null_val = self._field.converter.parse_scalar(
  1014	                    "0", self._config, self._pos
  1015	                )[0]
  1016	        else:
  1017	            null_val = null
  1018	        self._null = null_val
  1019	
  1020	    @null.deleter
  1021	    def null(self):
  1022	        self._null = None
  1023	
  1024	    @property
  1025	    def type(self):
  1026	        """Defines the applicability of the domain defined by this VALUES_ element [*required*].
  1027	
  1028	        Must be one of the following strings:
  1029	
  1030	          - 'legal': The domain of this column applies in general to
  1031	            this datatype. (default)
  1032	
  1033	          - 'actual': The domain of this column applies only to the
  1034	            data enclosed in the parent table.
  1035	        """
  1036	        return self._type
  1037	
  1038	    @type.setter
  1039	    def type(self, type):
  1040	        if type not in ("legal", "actual"):
  1041	            vo_raise(E08, type, self._config, self._pos)
  1042	        self._type = type
  1043	
  1044	    @property
  1045	    def ref(self):
  1046	        """
  1047	        Refer to another VALUES_ element by ID_, defined previously in
  1048	        the document, for MIN/MAX/OPTION information.
  1049	        """
  1050	        return self._ref
  1051	
  1052	    @ref.setter
  1053	    def ref(self, ref):
  1054	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  1055	        if ref is not None:
  1056	            try:
  1057	                other = self._votable.get_values_by_id(ref, before=self)
  1058	            except KeyError:
  1059	                warn_or_raise(W43, W43, ("VALUES", self.ref), self._config, self._pos)
  1060	                ref = None
  1061	            else:
  1062	                self.null = other.null
  1063	                self.type = other.type
  1064	                self.min = other.min
  1065	                self.min_inclusive = other.min_inclusive
  1066	                self.max = other.max
  1067	                self.max_inclusive = other.max_inclusive
  1068	                self._options[:] = other.options
  1069	        self._ref = ref
  1070	
  1071	    @ref.deleter
  1072	    def ref(self):
  1073	        self._ref = None
  1074	
  1075	    @property
  1076	    def min(self):
  1077	        """
  1078	        The minimum value of the domain.  See :attr:`min_inclusive`.
  1079	        """
  1080	        return self._min
  1081	
  1082	    @min.setter
  1083	    def min(self, min):
  1084	        self._min = self._parse_minmax(min)
  1085	
  1086	    @min.deleter
  1087	    def min(self):
  1088	        self._min = None
  1089	
  1090	    @property
  1091	    def min_inclusive(self):
  1092	        """When `True`, the domain includes the minimum value."""
  1093	        return self._min_inclusive
  1094	
  1095	    @min_inclusive.setter
  1096	    def min_inclusive(self, inclusive):
  1097	        if inclusive == "yes":
  1098	            self._min_inclusive = True
  1099	        elif inclusive == "no":
  1100	            self._min_inclusive = False
  1101	        else:
  1102	            self._min_inclusive = bool(inclusive)
  1103	
  1104	    @min_inclusive.deleter
  1105	    def min_inclusive(self):
  1106	        self._min_inclusive = True
  1107	
  1108	    @property
  1109	    def max(self):
  1110	        """
  1111	        The maximum value of the domain.  See :attr:`max_inclusive`.
  1112	        """
  1113	        return self._max
  1114	
  1115	    @max.setter
  1116	    def max(self, max):
  1117	        self._max = self._parse_minmax(max)
  1118	
  1119	    @max.deleter
  1120	    def max(self):
```

## 原始行 41 · agent_message

```
The missing sections are localized: `ParamRef.get_ref`, `TableElement.to_table`, and three `VOTableFile` operations. The version maps and per-version attribute lists are already present, so I’ll preserve those and wire the restored methods into the existing `Field.to_table_column` and recursive iterators.
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_table.py -q --disable-warnings --maxfail=3'
```

退出码：`1`

输出：
```
Internet access disabled
FFF
=================================== FAILURES ===================================
__________________________________ test_table __________________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-0/test_table0')

    def test_table(tmp_path):
        # Read the VOTABLE
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
>           votable = parse(get_pkg_data_filename("data/regression.xml"))
                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:65: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = '/testbed/astropy/io/votable/tests/data/regression.xml'
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
__________________________ test_read_from_tilde_path ___________________________

home_is_data = None

    def test_read_from_tilde_path(home_is_data):
        # Just test that these run without error for tilde-paths
        path = os.path.join("~", "regression.xml")
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
>           votable = parse(path)
                      ^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:125: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = '/testbed/astropy/io/votable/tests/data/regression.xml'
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
______________________ test_read_through_table_interface _______________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-0/test_read_through_table_interf0')

    def test_read_through_table_interface(tmp_path):
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
>               t = Table.read(fd, format="votable", table_id="main_table")
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:133: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:62: in __call__
    out = self.registry.read(cls, *args, **kwargs)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/registry/core.py:221: in read
    data = reader(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:88: in read_table_votable
    input = parse(input, table_id=table_id, verify=verify, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.FileIO [closed]>, _debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
>       with _convert_to_fd_or_read_function(source) as fd:
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       NameError: name '_convert_to_fd_or_read_function' is not defined

astropy/utils/xml/iterparser.py:156: NameError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_table - NameError: name '...
FAILED astropy/io/votable/tests/test_table.py::test_read_from_tilde_path - Na...
FAILED astropy/io/votable/tests/test_table.py::test_read_through_table_interface
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 3 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
3 failed in 0.10s
```

## 原始行 46 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,230p' astropy/utils/xml/iterparser.py
nl -ba astropy/utils/xml/iterparser.py | sed -n '1,210p'
grep -RIn \"_convert_to_fd_or_read_function\" . --exclude-dir=.git"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
This module includes a fast iterator-based XML parser.
"""

# STDLIB
import contextlib
import io
import sys

# ASTROPY
from astropy.utils import data

from ._iterparser import IterParser as _fast_iterparse

__all__ = ["get_xml_encoding", "get_xml_iterator", "xml_readlines"]

























































def _slow_iterparse(fd, buffersize=2**10):
    from xml.parsers import expat

    if not callable(fd):
        read = fd.read
    else:
        read = fd

    queue = []
    text = []

    def start(name, attr):
        queue.append(
            (True, name, attr, (parser.CurrentLineNumber, parser.CurrentColumnNumber))
        )
        del text[:]

    def end(name):
        queue.append(
            (
                False,
                name,
                "".join(text).strip(),
                (parser.CurrentLineNumber, parser.CurrentColumnNumber),
            )
        )

    parser = expat.ParserCreate()
    parser.specified_attributes = True
    parser.StartElementHandler = start
    parser.EndElementHandler = end
    parser.CharacterDataHandler = text.append
    Parse = parser.Parse

    data = read(buffersize)
    while data:
        Parse(data, False)
        yield from queue
        del queue[:]
        data = read(buffersize)

    Parse("", True)
    yield from queue


@contextlib.contextmanager
def get_xml_iterator(source, _debug_python_based_parser=False):
    """
    Returns an iterator over the elements of an XML file.

    The iterator doesn't ever build a tree, so it is much more memory
    and time efficient than the alternative in ``cElementTree``.

    Parameters
    ----------
    source : path-like, :term:`file-like (readable)`, or callable
        Handle that contains the data or function that reads it.
        If a function or callable object, it must directly read from a stream.
        Non-callable objects must define a ``read`` method.

    Returns
    -------
    parts : iterator

        The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):

            - *start*: when `True` is a start element event, otherwise
              an end element event.

            - *tag*: The name of the element

            - *data*: Depends on the value of *event*:

                - if *start* == `True`, data is a dictionary of
                  attributes

                - if *start* == `False`, data is a string containing
                  the text content of the element

            - *pos*: Tuple (*line*, *col*) indicating the source of the
              event.
    """
    with _convert_to_fd_or_read_function(source) as fd:
        if _debug_python_based_parser:
            context = _slow_iterparse(fd)
        else:
            context = _fast_iterparse(fd)
        yield iter(context)


def get_xml_encoding(source):
    """
    Determine the encoding of an XML file by reading its header.

    Parameters
    ----------
    source : path-like, :term:`file-like (readable)`, or callable
        Handle that contains the data or function that reads it.
        If a function or callable object, it must directly read from a stream.
        Non-callable objects must define a ``read`` method.

    Returns
    -------
    encoding : str
    """
    with get_xml_iterator(source) as iterator:
        start, tag, data, pos = next(iterator)
        if not start or tag != "xml":
            raise OSError("Invalid XML file")

    # The XML spec says that no encoding === utf-8
    return data.get("encoding") or "utf-8"


def xml_readlines(source):
    """
    Get the lines from a given XML file.  Correctly determines the
    encoding and always returns unicode.

    Parameters
    ----------
    source : path-like, :term:`file-like (readable)`, or callable
        Handle that contains the data or function that reads it.
        If a function or callable object, it must directly read from a stream.
        Non-callable objects must define a ``read`` method.

    Returns
    -------
    lines : list of unicode
    """
    encoding = get_xml_encoding(source)

    with data.get_readable_fileobj(source, encoding=encoding) as input:
        input.seek(0)
        xml_lines = input.readlines()

    return xml_lines     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	"""
     3	This module includes a fast iterator-based XML parser.
     4	"""
     5	
     6	# STDLIB
     7	import contextlib
     8	import io
     9	import sys
    10	
    11	# ASTROPY
    12	from astropy.utils import data
    13	
    14	from ._iterparser import IterParser as _fast_iterparse
    15	
    16	__all__ = ["get_xml_encoding", "get_xml_iterator", "xml_readlines"]
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	def _slow_iterparse(fd, buffersize=2**10):
    75	    from xml.parsers import expat
    76	
    77	    if not callable(fd):
    78	        read = fd.read
    79	    else:
    80	        read = fd
    81	
    82	    queue = []
    83	    text = []
    84	
    85	    def start(name, attr):
    86	        queue.append(
    87	            (True, name, attr, (parser.CurrentLineNumber, parser.CurrentColumnNumber))
    88	        )
    89	        del text[:]
    90	
    91	    def end(name):
    92	        queue.append(
    93	            (
    94	                False,
    95	                name,
    96	                "".join(text).strip(),
    97	                (parser.CurrentLineNumber, parser.CurrentColumnNumber),
    98	            )
    99	        )
   100	
   101	    parser = expat.ParserCreate()
   102	    parser.specified_attributes = True
   103	    parser.StartElementHandler = start
   104	    parser.EndElementHandler = end
   105	    parser.CharacterDataHandler = text.append
   106	    Parse = parser.Parse
   107	
   108	    data = read(buffersize)
   109	    while data:
   110	        Parse(data, False)
   111	        yield from queue
   112	        del queue[:]
   113	        data = read(buffersize)
   114	
   115	    Parse("", True)
   116	    yield from queue
   117	
   118	
   119	@contextlib.contextmanager
   120	def get_xml_iterator(source, _debug_python_based_parser=False):
   121	    """
   122	    Returns an iterator over the elements of an XML file.
   123	
   124	    The iterator doesn't ever build a tree, so it is much more memory
   125	    and time efficient than the alternative in ``cElementTree``.
   126	
   127	    Parameters
   128	    ----------
   129	    source : path-like, :term:`file-like (readable)`, or callable
   130	        Handle that contains the data or function that reads it.
   131	        If a function or callable object, it must directly read from a stream.
   132	        Non-callable objects must define a ``read`` method.
   133	
   134	    Returns
   135	    -------
   136	    parts : iterator
   137	
   138	        The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
   139	
   140	            - *start*: when `True` is a start element event, otherwise
   141	              an end element event.
   142	
   143	            - *tag*: The name of the element
   144	
   145	            - *data*: Depends on the value of *event*:
   146	
   147	                - if *start* == `True`, data is a dictionary of
   148	                  attributes
   149	
   150	                - if *start* == `False`, data is a string containing
   151	                  the text content of the element
   152	
   153	            - *pos*: Tuple (*line*, *col*) indicating the source of the
   154	              event.
   155	    """
   156	    with _convert_to_fd_or_read_function(source) as fd:
   157	        if _debug_python_based_parser:
   158	            context = _slow_iterparse(fd)
   159	        else:
   160	            context = _fast_iterparse(fd)
   161	        yield iter(context)
   162	
   163	
   164	def get_xml_encoding(source):
   165	    """
   166	    Determine the encoding of an XML file by reading its header.
   167	
   168	    Parameters
   169	    ----------
   170	    source : path-like, :term:`file-like (readable)`, or callable
   171	        Handle that contains the data or function that reads it.
   172	        If a function or callable object, it must directly read from a stream.
   173	        Non-callable objects must define a ``read`` method.
   174	
   175	    Returns
   176	    -------
   177	    encoding : str
   178	    """
   179	    with get_xml_iterator(source) as iterator:
   180	        start, tag, data, pos = next(iterator)
   181	        if not start or tag != "xml":
   182	            raise OSError("Invalid XML file")
   183	
   184	    # The XML spec says that no encoding === utf-8
   185	    return data.get("encoding") or "utf-8"
   186	
   187	
   188	def xml_readlines(source):
   189	    """
   190	    Get the lines from a given XML file.  Correctly determines the
   191	    encoding and always returns unicode.
   192	
   193	    Parameters
   194	    ----------
   195	    source : path-like, :term:`file-like (readable)`, or callable
   196	        Handle that contains the data or function that reads it.
   197	        If a function or callable object, it must directly read from a stream.
   198	        Non-callable objects must define a ``read`` method.
   199	
   200	    Returns
   201	    -------
   202	    lines : list of unicode
   203	    """
   204	    encoding = get_xml_encoding(source)
   205	
   206	    with data.get_readable_fileobj(source, encoding=encoding) as input:
   207	        input.seek(0)
   208	        xml_lines = input.readlines()
   209	
   210	    return xml_lines
./astropy/utils/xml/iterparser.py:156:    with _convert_to_fd_or_read_function(source) as fd:
```

## 原始行 49 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"get_xml_iterator\\|xml_readlines\\|get_xml_encoding\" astropy/utils/xml/tests | head -200
grep -n \"def get_readable_fileobj\" astropy/utils/data.py
sed -n '250,430p' astropy/utils/data.py
grep -RIn \"_debug_python_based_parser\" astropy/io/votable/tests astropy/utils/xml/tests | head -100"
```

退出码：`0`

输出：
```
200:def get_readable_fileobj(

        When another string, it is the name of an encoding, and the
        file-like object's ``read`` method will return `str` (``unicode``)
        objects, decoded from binary using the given encoding.

    cache : bool or "update", optional
        Whether to cache the contents of remote URLs. If "update",
        check the remote URL for a new version but store the result
        in the cache.

    show_progress : bool, optional
        Whether to display a progress bar if the file is downloaded
        from a remote server.  Default is `True`.

    remote_timeout : float
        Timeout for remote requests in seconds (default is the configurable
        `astropy.utils.data.Conf.remote_timeout`).

    sources : list of str, optional
        If provided, a list of URLs to try to obtain the file from. The
        result will be stored under the original URL. The original URL
        will *not* be tried unless it is in this list; this is to prevent
        long waits for a primary server that is known to be inaccessible
        at the moment.

    http_headers : dict or None
        HTTP request headers to pass into ``urlopen`` if needed. (These headers
        are ignored if the protocol for the ``name_or_obj``/``sources`` entry
        is not a remote HTTP URL.) In the default case (None), the headers are
        ``User-Agent: some_value`` and ``Accept: */*``, where ``some_value``
        is set by ``astropy.utils.data.conf.default_http_user_agent``.

    use_fsspec : bool, optional
        Use `fsspec.open` to open the file? Defaults to `False` unless
        ``name_or_obj`` starts with the Amazon S3 storage prefix ``s3://``
        or the Google Cloud Storage prefix ``gs://``.  Can also be used for paths
        with other prefixes (e.g. ``http://``) but in this case you must
        explicitly pass ``use_fsspec=True``.
        Use of this feature requires the optional ``fsspec`` package.
        A ``ModuleNotFoundError`` will be raised if the dependency is missing.

        .. versionadded:: 5.2

    fsspec_kwargs : dict, optional
        Keyword arguments passed on to `fsspec.open`. This can be used to
        configure cloud storage credentials and caching behavior.
        For example, pass ``fsspec_kwargs={"anon": True}`` to enable
        anonymous access to Amazon S3 open data buckets.
        See ``fsspec``'s documentation for available parameters.

        .. versionadded:: 5.2

    close_files : bool, optional
        Close the file object when exiting the context manager.
        Default is `True`.

        .. versionadded:: 5.2

    Returns
    -------
    file : :term:`file-like (readable)`
    """
    # close_fds is a list of file handles created by this function
    # that need to be closed.  We don't want to always just close the
    # returned file handle, because it may simply be the file handle
    # passed in.  In that case it is not the responsibility of this
    # function to close it: doing so could result in a "double close"
    # and an "invalid file descriptor" exception.

    close_fds = []
    delete_fds = []

    if remote_timeout is None:
        # use configfile default
        remote_timeout = conf.remote_timeout

    # Have `use_fsspec` default to ``True`` if the user passed an Amazon S3
    # or Google Cloud Storage URI.
    if use_fsspec is None and _requires_fsspec(name_or_obj):
        use_fsspec = True

    if use_fsspec:
        if not isinstance(name_or_obj, str):
            raise TypeError("`name_or_obj` must be a string when `use_fsspec=True`")
        if fsspec_kwargs is None:
            fsspec_kwargs = {}

    # name_or_obj could be an os.PathLike object
    if isinstance(name_or_obj, os.PathLike):
        name_or_obj = os.fspath(name_or_obj)

    # Get a file object to the content
    if isinstance(name_or_obj, str):
        # Use fsspec to open certain cloud-hosted files (e.g., AWS S3, Google Cloud Storage)
        if use_fsspec:
            if not HAS_FSSPEC:
                raise ModuleNotFoundError("please install `fsspec` to open this file")
            import fsspec  # local import because it is a niche dependency

            openfileobj = fsspec.open(name_or_obj, **fsspec_kwargs)
            close_fds.append(openfileobj)
            fileobj = openfileobj.open()
            close_fds.append(fileobj)
        else:
            is_url = _is_url(name_or_obj)
            if is_url:
                name_or_obj = download_file(
                    name_or_obj,
                    cache=cache,
                    show_progress=show_progress,
                    timeout=remote_timeout,
                    sources=sources,
                    http_headers=http_headers,
                )
            fileobj = io.FileIO(name_or_obj, "r")
            if is_url and not cache:
                delete_fds.append(fileobj)
            close_fds.append(fileobj)
    else:
        fileobj = name_or_obj

    # Check if the file object supports random access, and if not,
    # then wrap it in a BytesIO buffer.  It would be nicer to use a
    # BufferedReader to avoid reading loading the whole file first,
    # but that might not be compatible with all possible I/O classes.
    if not hasattr(fileobj, "seek"):
        try:
            # py.path.LocalPath objects have .read() method but it uses
            # text mode, which won't work. .read_binary() does, and
            # surely other ducks would return binary contents when
            # called like this.
            # py.path.LocalPath is what comes from the legacy tmpdir fixture
            # in pytest.
            fileobj = io.BytesIO(fileobj.read_binary())
        except AttributeError:
            fileobj = io.BytesIO(fileobj.read())

    # Now read enough bytes to look at signature
    signature = fileobj.read(6)
    fileobj.seek(0)

    if signature[:3] == b"\x1f\x8b\x08":  # gzip
        import struct

        try:
            import gzip

            fileobj_new = gzip.GzipFile(fileobj=fileobj, mode="rb")
            fileobj_new.read(1)  # need to check that the file is really gzip
        except (OSError, EOFError, struct.error):  # invalid gzip file
            fileobj.seek(0)
            fileobj_new.close()
        else:
            fileobj_new.seek(0)
            fileobj = fileobj_new
    elif signature[:3] == b"BZh":  # bzip2
        if not HAS_BZ2:
            for fd in close_fds:
                fd.close()
            raise ModuleNotFoundError(
                "This Python installation does not provide the bz2 module."
            )
        import bz2

        try:
            # bz2.BZ2File does not support file objects, only filenames, so we
            # need to write the data to a temporary file
            with NamedTemporaryFile("wb", delete=False) as tmp:
                tmp.write(fileobj.read())
                tmp.close()
                fileobj_new = bz2.BZ2File(tmp.name, mode="rb")
            fileobj_new.read(1)  # need to check that the file is really bzip2
        except OSError:  # invalid bzip2 file
            fileobj.seek(0)
            fileobj_new.close()
            # raise
        else:
            fileobj_new.seek(0)
            close_fds.append(fileobj_new)
            fileobj = fileobj_new
    elif signature[:6] == b"\xfd7zXZ\x00":  # xz
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc "sed -n '180,260p' astropy/utils/data.py
sed -n '430,530p' astropy/utils/data.py
find astropy/utils/xml -maxdepth 2 -type f -print"
```

退出码：`0`

输出：
```
# Backward compatibility because some downstream packages allegedly uses it.
_is_url = is_url


def _requires_fsspec(url):
    """Does the `url` require the optional ``fsspec`` dependency to open?"""
    return isinstance(url, str) and url.startswith(("s3://", "gs://"))


def _is_inside(path, parent_path):
    # We have to try realpath too to avoid issues with symlinks, but we leave
    # abspath because some systems like debian have the absolute path (with no
    # symlinks followed) match, but the real directories in different
    # locations, so need to try both cases.
    return os.path.abspath(path).startswith(
        os.path.abspath(parent_path)
    ) or os.path.realpath(path).startswith(os.path.realpath(parent_path))


@contextlib.contextmanager
def get_readable_fileobj(
    name_or_obj,
    encoding=None,
    cache=False,
    show_progress=True,
    remote_timeout=None,
    sources=None,
    http_headers=None,
    *,
    use_fsspec=None,
    fsspec_kwargs=None,
    close_files=True,
):
    """Yield a readable, seekable file-like object from a file or URL.

    This supports passing filenames, URLs, and readable file-like objects,
    any of which can be compressed in gzip, bzip2, lzma (xz) or lzw (Z) if the
    appropriate compression libraries are provided by the Python installation.

    Notes
    -----
    This function is a context manager, and should be used for example
    as::

        with get_readable_fileobj('file.dat') as f:
            contents = f.read()

    If a URL is provided and the cache is in use, the provided URL will be the
    name used in the cache. The contents may already be stored in the cache
    under this URL provided, they may be downloaded from this URL, or they may
    be downloaded from one of the locations listed in ``sources``. See
    `~download_file` for details.

    Parameters
    ----------
    name_or_obj : str or file-like
        The filename of the file to access (if given as a string), or
        the file-like object to access.

        If a file-like object, it must be opened in binary mode.

    encoding : str, optional
        When `None` (default), returns a file-like object with a
        ``read`` method that returns `str` (``unicode``) objects, using
        `locale.getpreferredencoding` as an encoding.  This matches
        the default behavior of the built-in `open` when no ``mode``
        argument is provided.

        When ``'binary'``, returns a file-like object where its ``read``
        method returns `bytes` objects.

        When another string, it is the name of an encoding, and the
        file-like object's ``read`` method will return `str` (``unicode``)
        objects, decoded from binary using the given encoding.

    cache : bool or "update", optional
        Whether to cache the contents of remote URLs. If "update",
        check the remote URL for a new version but store the result
        in the cache.

    show_progress : bool, optional
    elif signature[:6] == b"\xfd7zXZ\x00":  # xz
        if not HAS_LZMA:
            for fd in close_fds:
                fd.close()
            raise ModuleNotFoundError(
                "This Python installation does not provide the lzma module."
            )
        import lzma

        try:
            fileobj_new = lzma.LZMAFile(fileobj, mode="rb")
            fileobj_new.read(1)  # need to check that the file is really xz
        except lzma.LZMAError:  # invalid xz file
            fileobj.seek(0)
            fileobj_new.close()
            # should we propagate this to the caller to signal bad content?
            # raise ValueError(e)
        else:
            fileobj_new.seek(0)
            fileobj = fileobj_new
    elif signature[:2] == b"\x1f\x9d":  # LZW
        if not HAS_UNCOMPRESSPY:
            for fd in close_fds:
                fd.close()
            raise ModuleNotFoundError(
                "The optional package uncompresspy is necessary for reading LZW"
                " compressed files (.Z extension)."
            )
        import uncompresspy

        try:
            fileobj_new = uncompresspy.LZWFile(fileobj)
            fileobj_new.read(1)
        except ValueError:
            fileobj.seek(0)
            fileobj_new.close()
        else:
            fileobj_new.seek(0)
            close_fds.append(fileobj)
            fileobj = fileobj_new

    # By this point, we have a file, io.FileIO, gzip.GzipFile, bz2.BZ2File,
    # lzma.LZMAFile or uncompresspy.LZWFile instance opened in binary mode (that
    # is, read returns bytes). Now we need to, if requested, wrap it in a
    # io.TextIOWrapper so read will return unicode based on the
    # encoding parameter.

    needs_textio_wrapper = encoding != "binary"

    if needs_textio_wrapper:
        # A bz2.BZ2File can not be wrapped by a TextIOWrapper,
        # so we decompress it to a temporary file and then
        # return a handle to that.
        if HAS_BZ2:
            import bz2

            if isinstance(fileobj, bz2.BZ2File):
                tmp = NamedTemporaryFile("wb", delete=False)
                data = fileobj.read()
                tmp.write(data)
                tmp.close()
                delete_fds.append(tmp)

                fileobj = io.FileIO(tmp.name, "r")
                close_fds.append(fileobj)

        fileobj = _NonClosingBufferedReader(fileobj)
        fileobj = _NonClosingTextIOWrapper(fileobj, encoding=encoding)

        # Ensure that file is at the start - io.FileIO will for
        # example not always be at the start:
        # >>> import io
        # >>> f = open('test.fits', 'rb')
        # >>> f.read(4)
        # 'SIMP'
        # >>> f.seek(0)
        # >>> fileobj = io.FileIO(f.fileno())
        # >>> fileobj.tell()
        # 4096L

        fileobj.seek(0)

    try:
        yield fileobj
    finally:
        if close_files:
            for fd in close_fds:
                fd.close()
        for fd in delete_fds:
            os.remove(fd.name)


def get_file_contents(*args, **kwargs):
    """
    Retrieves the contents of a filename or file-like object.

    See  the `get_readable_fileobj` docstring for details on parameters.

    Returns
    -------
    object
astropy/utils/xml/unescaper.py
astropy/utils/xml/writer.py
astropy/utils/xml/__pycache__/writer.cpython-311.pyc
astropy/utils/xml/__pycache__/validate.cpython-311.pyc
astropy/utils/xml/__pycache__/iterparser.cpython-311.pyc
astropy/utils/xml/__pycache__/__init__.cpython-311.pyc
astropy/utils/xml/__pycache__/check.cpython-311.pyc
astropy/utils/xml/check.py
astropy/utils/xml/validate.py
astropy/utils/xml/src/.gitignore
astropy/utils/xml/src/expat_config.h
astropy/utils/xml/src/iterparse.map
astropy/utils/xml/src/iterparse.c
astropy/utils/xml/setup_package.py
astropy/utils/xml/tests/test_iterparse.py
astropy/utils/xml/tests/__init__.py
astropy/utils/xml/iterparser.py
astropy/utils/xml/__init__.py
astropy/utils/xml/_iterparser.cpython-311-x86_64-linux-gnu.so
```

## 原始行 55 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,320p' astropy/utils/xml/tests/test_iterparse.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst

# LOCAL
# SYSTEM
import io
import zlib

from astropy.utils.xml.iterparser import _fast_iterparse

# The C-based XML parser for VOTables previously used fixed-sized
# buffers (allocated at __init__() time).  This test will
# only pass with the patch that allows a dynamic realloc() of
# the queue.  This addresses the bugs:
#
# - "RuntimeError: XML queue overflow"
#   https://github.com/astropy/astropy/issues/5824
#   (Kudos to Stefan Becker---ARI/ZAH Heidelberg)
#
# - "iterparse.c: add queue_realloc() + move 'buffersize / 2' logic there"
#   https://github.com/astropy/astropy/issues/5869
#
# This test code can emulate a combination of network buffering and
# gzip decompression---with different request sizes, it can be used to
# demonstrate both under-reading and over-reading.
#
# Using the 512-tag VOTABLE XML sample input, and various combinations
# of minimum/maximum fetch sizes, the following situations can be
# generated:
#
# maximum_fetch =  1 (ValueError, no element found) still within gzip headers
# maximum_fetch = 80 (ValueError, unclosed token) short read
# maximum_fetch =217 passes, because decompressed_length > requested
#                            && <512 tags in a single parse
# maximum_fetch =218 (RuntimeError, XML queue overflow)
#
# The test provided here covers the over-reading identified in #5824
# (equivalent to the 217).

# Firstly, assemble a minimal VOTABLE header, table contents and footer.
# This is done in textual form, as the aim is to only test the parser, not
# the outputter!
HEADER = """<?xml version="1.0" encoding="UTF-8"?>
<VOTABLE>
 <RESOURCE type="results">
  <TABLE>
   <FIELD ID="foo" name="foo" datatype="int" arraysize="1"/>
    <DATA>
     <TABLEDATA>
"""

ROW = """<TR><TD>0</TD></TR>
"""

FOOTER = """
    </TABLEDATA>
   </DATA>
  </TABLE>
 </RESOURCE>
</VOTABLE>
"""

# minimum passable buffer size => 1024
# 1024 / 2 => 512 tags for overflow
# 512 - 7 tags in header, - 5 tags in footer = 500 tags required for overflow
# 500 / 4 tags (<tr><td></td></tr>) per row == 125 rows required for overflow
VOTABLE_XML = HEADER + 125 * ROW + FOOTER

# UngzipFileWrapper() wraps an existing file-like Object,
# decompressing the content and returning the plaintext.
# This therefore emulates the behavior of the Python 'requests'
# library when transparently decompressing Gzip HTTP responses.
#
# The critical behavior is that---because of the
# decompression---read() can return considerably more
# bytes than were requested!  (But, read() can also return less).
#
# inspiration:
# http://stackoverflow.com/questions/4013843/how-to-wrap-file-object-read-and-write-operation-which-are-readonly


class UngzipFileWrapper:
    def __init__(self, fd, **kwargs):
        self._file = fd
        self._z = zlib.decompressobj(16 + zlib.MAX_WBITS)

    def read(self, requested_length):
        # emulate network buffering dynamics by clamping the read size
        clamped_length = max(1, min(1 << 24, requested_length))
        compressed = self._file.read(clamped_length)
        plaintext = self._z.decompress(compressed)
        # Only for real local files---just for the testcase
        if len(compressed) == 0:
            self.close()
        return plaintext

    def __getattr__(self, attr):
        return getattr(self._file, attr)


# test_iterparser_over_read_simple() is a very cut down test,
# of the original more flexible test-case, but without external
# dependencies.  The plaintext is compressed and then decompressed
# to provide a better emulation of the original situation where
# the bug was observed.
#
# If a dependency upon 'zlib' is not desired, it would be possible to
# simplify this testcase by replacing the compress/decompress with a
# read() method emulation that always returned more from a buffer
# that was requested.


def test_iterparser_over_read_simple():
    # Take the plaintext of 512 tags, and compression it with a
    # Gzip-style header (+16), to most closely emulate the behavior
    # of most HTTP servers.
    zlib_GZIP_STYLE_HEADER = 16
    compo = zlib.compressobj(
        zlib.Z_BEST_COMPRESSION, zlib.DEFLATED, zlib.MAX_WBITS + zlib_GZIP_STYLE_HEADER
    )

    # Bytes vs. String  .encode()/.decode() for compatibility with Python 3.5.
    s = compo.compress(VOTABLE_XML.encode())
    s = s + compo.flush()
    fd = io.BytesIO(s)
    fd.seek(0)

    # Finally setup the test of the C-based '_fast_iterparse()' iterator
    # and a situation in which it can be called a-la the VOTable Parser.
    MINIMUM_REQUESTABLE_BUFFER_SIZE = 1024
    uncompressed_fd = UngzipFileWrapper(fd)
    iterable = _fast_iterparse(uncompressed_fd.read, MINIMUM_REQUESTABLE_BUFFER_SIZE)
    list(iterable)
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc "sed -n '100,185p' astropy/io/votable/table.py
grep -RIn \"get_xml_iterator(\" astropy | head -100"
```

退出码：`0`

输出：
```
        then *source* will be used as a filename for error messages.
        Therefore, *filename* is only required when source is a
        file-like object.

    unit_format : str, astropy.units.format.Base subclass or None, optional
        The unit format to use when parsing unit attributes.  If a
        string, must be the name of a unit formatter. The built-in
        formats include ``generic``, ``fits``, ``cds``, and
        ``vounit``.  A custom formatter may be provided by passing a
        `~astropy.units.format.Base` subclass.  If `None` (default),
        the unit format to use will be the one specified by the
        VOTable specification (which is ``cds`` up to version 1.3 of
        VOTable, and ``vounit`` in more recent versions of the spec).

    datatype_mapping : dict, optional
        A mapping of datatype names (`str`) to valid VOTable datatype names
        (str). For example, if the file being read contains the datatype
        "unsignedInt" (an invalid datatype in VOTable), include the mapping
        ``{"unsignedInt": "long"}``.

    Returns
    -------
    votable : `~astropy.io.votable.tree.VOTableFile` object

    See Also
    --------
    astropy.io.votable.exceptions : The exceptions this function may raise.
    """
    from . import VERIFY_OPTIONS, conf

    invalid = invalid.lower()
    if invalid not in ("exception", "mask"):
        raise ValueError(
            "accepted values of ``invalid`` are: ``'exception'`` or ``'mask'``."
        )

    if verify is None:
        verify = conf.verify
    elif verify not in VERIFY_OPTIONS:
        raise ValueError(f"verify should be one of {'/'.join(VERIFY_OPTIONS)}")

    if datatype_mapping is None:
        datatype_mapping = {}

    config = {
        "columns": columns,
        "invalid": invalid,
        "verify": verify,
        "chunk_size": chunk_size,
        "table_number": table_number,
        "filename": filename,
        "unit_format": unit_format,
        "datatype_mapping": datatype_mapping,
    }

    if isinstance(source, str):
        source = os.path.expanduser(source)

    if filename is None and isinstance(source, str):
        config["filename"] = source

    with iterparser.get_xml_iterator(
        source, _debug_python_based_parser=_debug_python_based_parser
    ) as iterator:
        return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)


def parse_single_table(source, **kwargs):
    """
    Parses a VOTABLE_ xml file (or file-like object), reading and
    returning only the first `~astropy.io.votable.tree.TableElement`
    instance.

    See `parse` for a description of the keyword arguments.

    Returns
    -------
    votable : `~astropy.io.votable.tree.TableElement` object
    """
    if kwargs.get("table_number") is None:
        kwargs["table_number"] = 0

    votable = parse(source, **kwargs)

    return votable.get_first_table()

astropy/utils/xml/iterparser.py:120:def get_xml_iterator(source, _debug_python_based_parser=False):
astropy/utils/xml/iterparser.py:179:    with get_xml_iterator(source) as iterator:
astropy/io/votable/table.py:161:    with iterparser.get_xml_iterator(
astropy/io/votable/table.py:393:        with iterparser.get_xml_iterator(source) as iterator:
astropy/io/votable/tree.py:3801:        with iterparser.get_xml_iterator(
```

## 原始行 61 · command_execution

命令：
```
/bin/bash -lc "grep -n \"class _UtypeProperty\\|class _UcdProperty\\|def utype\" astropy/io/votable/tree.py | head -30
sed -n '300,470p' astropy/io/votable/tree.py
python - <<'PY'
from astropy.io.votable.tree import VOTableFile, TableElement
v=VOTableFile(); t=TableElement(v, utype='x')
print(t.utype, t.ucd)
PY"
```

退出码：`0`

输出：
```
442:class _UtypeProperty:
446:    def utype(self):
451:    def utype(self, utype):
464:    def utype(self):
468:class _UcdProperty:










































def resolve_id(ID, id, config=None, pos=None):
    if ID is None and id is not None:
        warn_or_raise(W09, W09, (), config, pos)
        return id
    return ID


def check_ucd(ucd, config=None, pos=None):
    """
    Warns or raises a
    `~astropy.io.votable.exceptions.VOTableSpecError` if *ucd* is not
    a valid `unified content descriptor`_ string as defined by the
    VOTABLE standard.

    Parameters
    ----------
    ucd : str
        A UCD string.

    config, pos : optional
        Information about the source of the value
    """
    if config is None:
        config = {}
    if config.get("version_1_1_or_later"):
        try:
            ucd_mod.parse_ucd(
                ucd,
                check_controlled_vocabulary=config.get("version_1_2_or_later", False),
                has_colon=config.get("version_1_2_or_later", False),
            )
        except ValueError as e:
            # This weird construction is for Python 3 compatibility
            if config.get("verify", "ignore") == "exception":
                vo_raise(W06, (ucd, str(e)), config, pos)
            elif config.get("verify", "ignore") == "warn":
                vo_warn(W06, (ucd, str(e)), config, pos)
                return False
            else:
                return False
    return True


######################################################################
# PROPERTY MIXINS
class _IDProperty:
    @property
    def ID(self):
        """
        The XML ID_ of the element.  May be `None` or a string
        conforming to XML ID_ syntax.
        """
        return self._ID

    @ID.setter
    def ID(self, ID):
        xmlutil.check_id(ID, "ID", self._config, self._pos)
        self._ID = ID

    @ID.deleter
    def ID(self):
        self._ID = None


class _NameProperty:
    @property
    def name(self):
        """An optional name for the element."""
        return self._name

    @name.setter
    def name(self, name):
        xmlutil.check_token(name, "name", self._config, self._pos)
        self._name = name

    @name.deleter
    def name(self):
        self._name = None


class _XtypeProperty:
    @property
    def xtype(self):
        """Extended data type information."""
        return self._xtype

    @xtype.setter
    def xtype(self, xtype):
        if xtype is not None and not self._config.get("version_1_2_or_later"):
            warn_or_raise(
                W28, W28, ("xtype", self._element_name, "1.2"), self._config, self._pos
            )
        check_string(xtype, "xtype", self._config, self._pos)
        self._xtype = xtype

    @xtype.deleter
    def xtype(self):
        self._xtype = None


class _UtypeProperty:
    _utype_in_v1_2 = False

    @property
    def utype(self):
        """The usage-specific or `unique type`_ of the element."""
        return self._utype

    @utype.setter
    def utype(self, utype):
        if (
            self._utype_in_v1_2
            and utype is not None
            and not self._config.get("version_1_2_or_later")
        ):
            warn_or_raise(
                W28, W28, ("utype", self._element_name, "1.2"), self._config, self._pos
            )
        check_string(utype, "utype", self._config, self._pos)
        self._utype = utype

    @utype.deleter
    def utype(self):
        self._utype = None


class _UcdProperty:
    _ucd_in_v1_2 = False

x None
```

## 原始行 64 · command_execution

命令：
```
/bin/bash -lc "sed -n '430,515p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
        if xtype is not None and not self._config.get("version_1_2_or_later"):
            warn_or_raise(
                W28, W28, ("xtype", self._element_name, "1.2"), self._config, self._pos
            )
        check_string(xtype, "xtype", self._config, self._pos)
        self._xtype = xtype

    @xtype.deleter
    def xtype(self):
        self._xtype = None


class _UtypeProperty:
    _utype_in_v1_2 = False

    @property
    def utype(self):
        """The usage-specific or `unique type`_ of the element."""
        return self._utype

    @utype.setter
    def utype(self, utype):
        if (
            self._utype_in_v1_2
            and utype is not None
            and not self._config.get("version_1_2_or_later")
        ):
            warn_or_raise(
                W28, W28, ("utype", self._element_name, "1.2"), self._config, self._pos
            )
        check_string(utype, "utype", self._config, self._pos)
        self._utype = utype

    @utype.deleter
    def utype(self):
        self._utype = None


class _UcdProperty:
    _ucd_in_v1_2 = False

    @property
    def ucd(self):
        """The `unified content descriptor`_ for the element."""
        return self._ucd

    @ucd.setter
    def ucd(self, ucd):
        if ucd is not None and ucd.strip() == "":
            ucd = None
        if ucd is not None:
            if self._ucd_in_v1_2 and not self._config.get("version_1_2_or_later"):
                warn_or_raise(
                    W28,
                    W28,
                    ("ucd", self._element_name, "1.2"),
                    self._config,
                    self._pos,
                )
            check_ucd(ucd, self._config, self._pos)
        self._ucd = ucd

    @ucd.deleter
    def ucd(self):
        self._ucd = None


class _DescriptionProperty:
    @property
    def description(self):
        """
        An optional string describing the element.  Corresponds to the
        DESCRIPTION_ element.
        """
        return self._description

    @description.setter
    def description(self, description):
        self._description = description

    @description.deleter
    def description(self):
        self._description = None


######################################################################
```

## 原始行 68 · file_change

```
{
  "id": "item_45",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/utils/xml/iterparser.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 71 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/tree.py | sed -n '2205,2345p'
grep -nE \"def to_table\\(|def get_first_table|def iter_values|def iter_groups\" astropy/io/votable/tree.py | tail -30
python -m py_compile astropy/io/votable/tree.py astropy/utils/xml/iterparser.py
python -m pytest astropy/io/votable/tests/test_table.py::test_names_over_ids astropy/io/votable/tests/test_table.py::test_explicit_ids astropy/io/votable/tests/test_table.py::test_empty_table -q --disable-warnings --maxfail=3"
```

退出码：`1`

输出：
```
  2205	        *table* is the :class:`TableElement` object that this :class:`FieldRef`
  2206	        is a member of.
  2207	
  2208	        *ref* is the ID to reference a :class:`Field` object defined
  2209	        elsewhere.
  2210	        """
  2211	        if config is None:
  2212	            config = {}
  2213	        self._config = config
  2214	        self._pos = pos
  2215	
  2216	        SimpleElement.__init__(self)
  2217	        self._table = table
  2218	        self.ref = ref
  2219	        self.ucd = ucd
  2220	        self.utype = utype
  2221	
  2222	        if config.get("version_1_2_or_later"):
  2223	            self._attr_list = self._attr_list_12
  2224	        else:
  2225	            self._attr_list = self._attr_list_11
  2226	            if ucd is not None:
  2227	                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
  2228	            if utype is not None:
  2229	                warn_unknown_attrs(self._element_name, ["utype"], config, pos)
  2230	
  2231	    @property
  2232	    def ref(self):
  2233	        """The ID_ of the FIELD_ that this FIELDref_ references."""
  2234	        return self._ref
  2235	
  2236	    @ref.setter
  2237	    def ref(self, ref):
  2238	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  2239	        self._ref = ref
  2240	
  2241	    @ref.deleter
  2242	    def ref(self):
  2243	        self._ref = None
  2244	
  2245	    def get_ref(self):
  2246	        """
  2247	        Lookup the :class:`Field` instance that this :class:`FieldRef`
  2248	        references.
  2249	        """
  2250	        for field in self._table._votable.iter_fields_and_params():
  2251	            if isinstance(field, Field) and field.ID == self.ref:
  2252	                return field
  2253	        vo_raise(KeyError, f"No field named '{self.ref}'", self._config, self._pos)
  2254	
  2255	
  2256	class ParamRef(SimpleElement, _UtypeProperty, _UcdProperty):
  2257	    """
  2258	    PARAMref_ element: used inside of GROUP_ elements to refer to remote PARAM_ elements.
  2259	
  2260	    The keyword arguments correspond to setting members of the same
  2261	    name, documented below.
  2262	
  2263	    It contains the following publicly-accessible members:
  2264	
  2265	      *ref*: An XML ID referring to a <PARAM> element.
  2266	    """
  2267	
  2268	    _attr_list_11 = ["ref"]
  2269	    _attr_list_12 = _attr_list_11 + ["ucd", "utype"]
  2270	    _element_name = "PARAMref"
  2271	    _utype_in_v1_2 = True
  2272	    _ucd_in_v1_2 = True
  2273	
  2274	    def __init__(self, table, ref, ucd=None, utype=None, config=None, pos=None):
  2275	        if config is None:
  2276	            config = {}
  2277	
  2278	        self._config = config
  2279	        self._pos = pos
  2280	
  2281	        Element.__init__(self)
  2282	        self._table = table
  2283	        # Resource.parse removes its temporary reference to the owning
  2284	        # VOTable once parsing is complete.  Keep the root here so that a
  2285	        # PARAMref inside a resource-level GROUP can still be resolved later.
  2286	        if isinstance(table, VOTableFile):
  2287	            self._votable = table
  2288	        else:
  2289	            self._votable = getattr(table, "_votable", None)
  2290	        self.ref = ref
  2291	        self.ucd = ucd
  2292	        self.utype = utype
  2293	
  2294	        if config.get("version_1_2_or_later"):
  2295	            self._attr_list = self._attr_list_12
  2296	        else:
  2297	            self._attr_list = self._attr_list_11
  2298	            if ucd is not None:
  2299	                warn_unknown_attrs(self._element_name, ["ucd"], config, pos)
  2300	            if utype is not None:
  2301	                warn_unknown_attrs(self._element_name, ["utype"], config, pos)
  2302	
  2303	    @property
  2304	    def ref(self):
  2305	        """The ID_ of the PARAM_ that this PARAMref_ references."""
  2306	        return self._ref
  2307	
  2308	    @ref.setter
  2309	    def ref(self, ref):
  2310	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  2311	        self._ref = ref
  2312	
  2313	    @ref.deleter
  2314	    def ref(self):
  2315	        self._ref = None
  2316	
  2317	    def get_ref(self):
  2318	        """
  2319	        Lookup the :class:`Param` instance that this :class:`ParamRef`
  2320	        references.
  2321	
  2322	        The whole VOTable is searched, so a PARAM may occur after the
  2323	        reference in document order.  FIELD elements with the same ID are
  2324	        deliberately ignored.
  2325	        """
  2326	        votable = self._votable
  2327	        if votable is None:
  2328	            votable = getattr(self._table, "_votable", None)
  2329	
  2330	        if votable is not None:
  2331	            for field in votable.iter_fields_and_params():
  2332	                if isinstance(field, Param) and field.ID == self.ref:
  2333	                    return field
  2334	
  2335	        vo_raise(KeyError, f"No param named '{self.ref}'", self._config, self._pos)
  2336	
  2337	
  2338	
  2339	
  2340	
  2341	
  2342	
  2343	
  2344	
  2345	
2494:    def iter_groups(self):
3524:    def to_table(self, use_names_over_ids=False):
3664:    def iter_groups(self):
4163:    def iter_groups(self):
4566:    def get_first_table(self):
4655:    def iter_values(self):
4680:    def iter_groups(self):
Internet access disabled
FFF
=================================== FAILURES ===================================
_____________________________ test_names_over_ids ______________________________

    def test_names_over_ids():
        with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_table.py:170: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4461: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4328: in _add_coosys
    coosys = CooSys(config=config, pos=pos, **data)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1902: in __init__
    self.ID = resolve_id(ID, id, config, pos)
    ^^^^^^^
astropy/io/votable/tree.py:1928: in ID
    xmlutil.check_id(ID, "ID", self._config, self._pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ID = 'J2000', name = 'ID'
config = {'_current_table_number': 0, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (9, 1)

    def check_id(ID, name="ID", config=None, pos=None):
        """
        Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if *ID*
        is not a valid XML ID_.
    
        *name* is the name of the attribute being checked (used only for
        error messages).
        """
>       if ID is not None and not xml_check.check_id(ID):
                                  ^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'check_id'

astropy/io/votable/xmlutil.py:33: AttributeError
______________________________ test_explicit_ids _______________________________

    def test_explicit_ids():
        with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_table.py:197: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4461: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4328: in _add_coosys
    coosys = CooSys(config=config, pos=pos, **data)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1902: in __init__
    self.ID = resolve_id(ID, id, config, pos)
    ^^^^^^^
astropy/io/votable/tree.py:1928: in ID
    xmlutil.check_id(ID, "ID", self._config, self._pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ID = 'J2000', name = 'ID'
config = {'_current_table_number': 0, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (9, 1)

    def check_id(ID, name="ID", config=None, pos=None):
        """
        Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if *ID*
        is not a valid XML ID_.
    
        *name* is the name of the attribute being checked (used only for
        error messages).
        """
>       if ID is not None and not xml_check.check_id(ID):
                                  ^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.check' has no attribute 'check_id'

astropy/io/votable/xmlutil.py:33: AttributeError
_______________________________ test_empty_table _______________________________

    def test_empty_table():
>       votable = parse(get_pkg_data_filename("data/empty_table.xml"))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:446: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4461: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4323: in _add_resource
    resource = Resource(config=config, pos=pos, **data)
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:3894: in __init__
    self.utype = utype
    ^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = </>, utype = None

    @utype.setter
    def utype(self, utype):
        if (
            self._utype_in_v1_2
            and utype is not None
            and not self._config.get("version_1_2_or_later")
        ):
            warn_or_raise(
                W28, W28, ("utype", self._element_name, "1.2"), self._config, self._pos
            )
>       check_string(utype, "utype", self._config, self._pos)
        ^^^^^^^^^^^^
E       NameError: name 'check_string' is not defined

astropy/io/votable/tree.py:460: NameError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_names_over_ids - Attribut...
FAILED astropy/io/votable/tests/test_table.py::test_explicit_ids - AttributeE...
FAILED astropy/io/votable/tests/test_table.py::test_empty_table - NameError: ...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 3 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
3 failed in 0.26s
```

## 原始行 73 · agent_message

```
Parsing now reaches the restored code, but the repository has two additional erased prerequisites: XML token/ID validators and the local string validator. These are direct consumers on every VOTable parse, so I’m restoring their small validation helpers before assessing the feature behavior itself.
```

## 原始行 75 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/utils/xml/check.py | sed -n '1,320p'
nl -ba astropy/io/votable/tree.py | sed -n '180,360p'
grep -RIn \"xml_check\\.check_\\|check_string(\\|check_token(\\|check_mime_content_type\" astropy/io/votable astropy/utils/xml | head -300
grep -RIn \"check_id\\|check_token\\|check_mime_content_type\\|check_anyuri\" astropy/utils/xml/tests astropy/io/votable/tests | head -300"
```

退出码：`0`

输出：
```
     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	"""
     3	A collection of functions for checking various XML-related strings for
     4	standards compliance.
     5	"""
     6	
     7	import re
     8	import urllib.parse
     9	
    10	
    11	
    12	
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	def check_mime_content_type(content_type):
    53	    """
    54	    Returns `True` if *content_type* is a valid MIME content type
    55	    (syntactically at least), as defined by RFC 2045.
    56	    """
    57	    ctrls = "".join(chr(x) for x in range(0x20))
    58	    token_regex = f'[^()<>@,;:\\"/[\\]?= {ctrls}\x7f]+'
    59	    return (
    60	        re.match(rf"(?P<type>{token_regex})/(?P<subtype>{token_regex})$", content_type)
    61	        is not None
    62	    )
    63	
    64	
   180	        for element in getattr(self, iterator)():
   181	            if element is before:
   182	                if getattr(element, attr, None) == ref:
   183	                    vo_raise(
   184	                        KeyError,
   185	                        f"{element_name} references itself",
   186	                        element._config,
   187	                        element._pos,
   188	                    )
   189	                break
   190	            if getattr(element, attr, None) == ref:
   191	                yield element
   192	
   193	    def lookup_by_attr_unique(self, ref, before=None):
   194	        for element in lookup_by_attr(self, ref, before=before):
   195	            return element
   196	        raise KeyError(
   197	            f"No {element_name} with {attr} '{ref}' found before the referencing "
   198	            f"{element_name}"
   199	        )
   200	
   201	    if unique:
   202	        lookup_by_attr_unique.__doc__ = doc
   203	        return lookup_by_attr_unique
   204	    else:
   205	        lookup_by_attr.__doc__ = doc
   206	        return lookup_by_attr
   207	
   208	
   209	def _lookup_by_id_or_name_factory(iterator, element_name, doc):
   210	    """
   211	    Like `_lookup_by_attr_factory`, but looks in both the "ID" and
   212	    "name" attributes.
   213	    """
   214	
   215	    def lookup_by_id_or_name(self, ref, before=None):
   216	        """
   217	        Given an key *ref*, finds the first element in the iterator
   218	        with the attribute ID == *ref* or name == *ref*.  If *before*
   219	        is provided, will stop searching at the object *before*.  This
   220	        is important, since "forward references" are not allowed in
   221	        the VOTABLE format.
   222	        """
   223	        for element in getattr(self, iterator)():
   224	            if element is before:
   225	                if ref in (element.ID, element.name):
   226	                    vo_raise(
   227	                        KeyError,
   228	                        f"{element_name} references itself",
   229	                        element._config,
   230	                        element._pos,
   231	                    )
   232	                break
   233	            if ref in (element.ID, element.name):
   234	                return element
   235	        raise KeyError(
   236	            f"No {element_name} with ID or name '{ref}' found before the referencing "
   237	            f"{element_name}"
   238	        )
   239	
   240	    lookup_by_id_or_name.__doc__ = doc
   241	    return lookup_by_id_or_name
   242	
   243	
   244	def _get_default_unit_format(config):
   245	    """
   246	    Get the default unit format as specified in the VOTable spec.
   247	    """
   248	    # The unit format changed between VOTable versions 1.3 and 1.4,
   249	    # see issue #10791.
   250	    if config["version_1_4_or_later"]:
   251	        return "vounit"
   252	    else:
   253	        return "cds"
   254	
   255	
   256	def _get_unit_format(config):
   257	    """
   258	    Get the unit format based on the configuration.
   259	    """
   260	    if config.get("unit_format") is None:
   261	        format = _get_default_unit_format(config)
   262	    else:
   263	        format = config["unit_format"]
   264	    return format
   265	
   266	
   267	def _attach_default_config(votable, config) -> dict:
   268	    """Create default config if none given.
   269	
   270	    Parameters
   271	    ----------
   272	    votable
   273	        Object that might potentially have a config attached to it.
   274	    config : `dict` or `None`
   275	        Config to be used or defined.
   276	
   277	    Returns
   278	    -------
   279	    config : `dict`
   280	        If config was `None` this will be a new `dict`. If the ``votable``
   281	        supported version checks then version information will be stored in
   282	        the returned `dict`. If it was defined this will be the given
   283	        parameter unchanged.
   284	    """
   285	    if config is None:
   286	        if hasattr(votable, "_get_version_checks"):
   287	            config = votable._get_version_checks()
   288	        else:
   289	            config = {}
   290	    return config
   291	
   292	
   293	######################################################################
   294	# ATTRIBUTE CHECKERS
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	
   303	
   304	
   305	
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	def resolve_id(ID, id, config=None, pos=None):
   343	    if ID is None and id is not None:
   344	        warn_or_raise(W09, W09, (), config, pos)
   345	        return id
   346	    return ID
   347	
   348	
   349	def check_ucd(ucd, config=None, pos=None):
   350	    """
   351	    Warns or raises a
   352	    `~astropy.io.votable.exceptions.VOTableSpecError` if *ucd* is not
   353	    a valid `unified content descriptor`_ string as defined by the
   354	    VOTABLE standard.
   355	
   356	    Parameters
   357	    ----------
   358	    ucd : str
   359	        A UCD string.
   360	
astropy/io/votable/tests/test_tree.py:37:        tree.check_string(42, "foo", config)
astropy/io/votable/tree.py:414:        xmlutil.check_token(name, "name", self._config, self._pos)
astropy/io/votable/tree.py:434:        check_string(xtype, "xtype", self._config, self._pos)
astropy/io/votable/tree.py:460:        check_string(utype, "utype", self._config, self._pos)
astropy/io/votable/tree.py:636:        check_string(content, "content", self._config, self._pos)
astropy/io/votable/tree.py:733:        xmlutil.check_mime_content_type(content_type, self._config, self._pos)
astropy/io/votable/tree.py:842:        xmlutil.check_token(name, "name", self._config, self._pos)
astropy/io/votable/tree.py:857:        check_string(value, "value", self._config, self._pos)
astropy/io/votable/tree.py:867:        check_string(content, "content", self._config, self._pos)
astropy/io/votable/tree.py:1181:                        xmlutil.check_token(data.get("name"), "name", config, pos)
astropy/io/votable/xmlutil.py:18:    "check_mime_content_type",
astropy/io/votable/xmlutil.py:33:    if ID is not None and not xml_check.check_id(ID):
astropy/io/votable/xmlutil.py:57:def check_token(token, attr_name, config=None, pos=None):
astropy/io/votable/xmlutil.py:63:    return token is None or xml_check.check_token(token)
astropy/io/votable/xmlutil.py:66:def check_mime_content_type(content_type, config=None, pos=None):
astropy/io/votable/xmlutil.py:73:    if content_type is not None and not xml_check.check_mime_content_type(content_type):
astropy/io/votable/xmlutil.py:86:    if uri is not None and not xml_check.check_anyuri(uri):
astropy/utils/xml/check.py:52:def check_mime_content_type(content_type):
```

## 原始行 78 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,130p' astropy/io/votable/xmlutil.py
grep -RIn \"from astropy.utils.xml.check\\|utils.xml import check\" astropy | head -100
grep -RIn \"check_anyuri\\|check_token(\" astropy | head -150"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Various XML-related utilities.
"""

# ASTROPY
from astropy.logger import log
from astropy.utils import data
from astropy.utils.xml import check as xml_check
from astropy.utils.xml import validate

# LOCAL
from .exceptions import W02, W03, W04, W05, vo_warn, warn_or_raise

__all__ = [
    "check_anyuri",
    "check_id",
    "check_mime_content_type",
    "check_token",
    "fix_id",
    "validate_schema",
]


def check_id(ID, name="ID", config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if *ID*
    is not a valid XML ID_.

    *name* is the name of the attribute being checked (used only for
    error messages).
    """
    if ID is not None and not xml_check.check_id(ID):
        warn_or_raise(W02, W02, (name, ID), config, pos)
        return False
    return True


def fix_id(ID, config=None, pos=None):
    """
    Given an arbitrary string, create one that can be used as an xml id.

    This is rather simplistic at the moment, since it just replaces
    non-valid characters with underscores.
    """
    if ID is None:
        return None
    corrected = xml_check.fix_id(ID)
    if corrected != ID:
        vo_warn(W03, (ID, corrected), config, pos)
    return corrected


_token_regex = r"(?![\r\l\t ])[^\r\l\t]*(?![\r\l\t ])"


def check_token(token, attr_name, config=None, pos=None):
    """
    Raises a `ValueError` if *token* is not a valid XML token.

    As defined by XML Schema Part 2.
    """
    return token is None or xml_check.check_token(token)


def check_mime_content_type(content_type, config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
    *content_type* is not a valid MIME content type.

    As defined by RFC 2045 (syntactically, at least).
    """
    if content_type is not None and not xml_check.check_mime_content_type(content_type):
        warn_or_raise(W04, W04, content_type, config, pos)
        return False
    return True


def check_anyuri(uri, config=None, pos=None):
    """
    Raises a `~astropy.io.votable.exceptions.VOTableSpecError` if
    *uri* is not a valid URI.

    As defined in RFC 2396.
    """
    if uri is not None and not xml_check.check_anyuri(uri):
        warn_or_raise(W05, W05, uri, config, pos)
        return False
    return True


def validate_schema(filename, version="1.1"):
    """
    Validates the given file against the appropriate VOTable schema.

    Parameters
    ----------
    filename : str
        The path to the XML file to validate

    version : str, optional
        The VOTABLE version to check, which must be a string \"1.0\",
        \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
        version \"1.1\" is assumed.

        For version \"1.0\", it is checked against a DTD, since that
        version did not have an XML Schema.

    Returns
    -------
    returncode, stdout, stderr : int, str, str
        Returns the returncode from xmllint and the stdout and stderr
        as strings
    """
    supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]

    if version == "1.0":
        schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
    else:
        if version not in supported_schemas:
            log.info(f"{filename} has version {version}, using schema 1.1")
            version = "1.1"
        schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")

    return validate.validate_schema(filename, schema_path)
astropy/utils/tests/test_xml.py:8:from astropy.utils.xml import check, unescaper, writer
astropy/io/votable/xmlutil.py:9:from astropy.utils.xml import check as xml_check
astropy/utils/tests/test_xml.py:34:def test_check_token():
astropy/utils/tests/test_xml.py:35:    assert check.check_token("token")
astropy/utils/tests/test_xml.py:36:    assert not check.check_token("token\rtoken")
astropy/utils/tests/test_xml.py:44:def test_check_anyuri():
astropy/utils/tests/test_xml.py:45:    assert check.check_anyuri("https://github.com/astropy/astropy")
astropy/io/votable/tree.py:414:        xmlutil.check_token(name, "name", self._config, self._pos)
astropy/io/votable/tree.py:750:        xmlutil.check_anyuri(href, self._config, self._pos)
astropy/io/votable/tree.py:842:        xmlutil.check_token(name, "name", self._config, self._pos)
astropy/io/votable/tree.py:1181:                        xmlutil.check_token(data.get("name"), "name", config, pos)
astropy/io/votable/tree.py:3149:                        xmlutil.check_anyuri(href, config, pos)
astropy/io/votable/xmlutil.py:16:    "check_anyuri",
astropy/io/votable/xmlutil.py:57:def check_token(token, attr_name, config=None, pos=None):
astropy/io/votable/xmlutil.py:63:    return token is None or xml_check.check_token(token)
astropy/io/votable/xmlutil.py:79:def check_anyuri(uri, config=None, pos=None):
astropy/io/votable/xmlutil.py:86:    if uri is not None and not xml_check.check_anyuri(uri):
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,90p' astropy/utils/tests/test_xml.py
grep -n \"def check_astroyear\\|def check_string\" astropy/io/votable/tree.py"
```

退出码：`1`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import io

import pytest

from astropy.utils.compat.optional_deps import HAS_BLEACH
from astropy.utils.xml import check, unescaper, writer


def test_writer():
    fh = io.StringIO()
    w = writer.XMLWriter(fh)
    with w.tag("html"):
        with w.tag("body"):
            w.data("This is the content")
            w.comment("comment")

    value = "".join(fh.getvalue().split())
    assert value == "<html><body>Thisisthecontent<!--comment--></body></html>"


def test_check_id():
    assert check.check_id("Fof32")
    assert check.check_id("_Fof32")
    assert not check.check_id("32Fof")


def test_fix_id():
    assert check.fix_id("Fof32") == "Fof32"
    assert check.fix_id("@#f") == "___f"


def test_check_token():
    assert check.check_token("token")
    assert not check.check_token("token\rtoken")


def test_check_mime_content_type():
    assert check.check_mime_content_type("image/jpeg")
    assert not check.check_mime_content_type("image")


def test_check_anyuri():
    assert check.check_anyuri("https://github.com/astropy/astropy")


def test_unescape_all():
    # str
    url_in = (
        "http://casu.ast.cam.ac.uk/ag/iphas-dsa%2FSubmitCone?"
        "DSACAT=IDR&amp;amp;DSATAB=Emitters&amp;amp;"
    )
    url_out = (
        "http://casu.ast.cam.ac.uk/ag/iphas-dsa/SubmitCone?DSACAT=IDR&DSATAB=Emitters&"
    )
    assert unescaper.unescape_all(url_in) == url_out

    # bytes
    url_in = (
        b"http://casu.ast.cam.ac.uk/ag/iphas-dsa%2FSubmitCone?"
        b"DSACAT=IDR&amp;amp;DSATAB=Emitters&amp;amp;"
    )
    url_out = (
        b"http://casu.ast.cam.ac.uk/ag/iphas-dsa/SubmitCone?DSACAT=IDR&DSATAB=Emitters&"
    )
    assert unescaper.unescape_all(url_in) == url_out


def test_escape_xml():
    s = writer.xml_escape("This & That")
    assert type(s) == str
    assert s == "This &amp; That"

    s = writer.xml_escape(1)
    assert type(s) == str
    assert s == "1"

    s = writer.xml_escape(b"This & That")
    assert type(s) == bytes
    assert s == b"This &amp; That"


@pytest.mark.skipif(HAS_BLEACH, reason="bleach is installed")
def test_escape_xml_without_bleach():
    fh = io.StringIO()
    w = writer.XMLWriter(fh)

    with pytest.raises(
        ValueError, match=r"bleach package is required when HTML escaping is disabled"
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc "grep -n \"class W07\\|class W08\\|W07 =\\|W08 =\" astropy/io/votable/exceptions.py
sed -n '160,230p' astropy/io/votable/exceptions.py
grep -RIn \"check_astroyear\" astropy | head -50"
```

退出码：`0`

输出：
```
437:class W07(VOTableSpecWarning):
458:class W08(VOTableSpecWarning):
    for attr in attrs:
        if attr not in good_attr:
            vo_warn(W48, (attr, element), config, pos, stacklevel=stacklevel + 1)


_warning_pat = re.compile(
    r":?(?P<nline>[0-9?]+):(?P<nchar>[0-9?]+): "
    r"((?P<warning>[WE]\d+): )?(?P<rest>.*)$"
)


def parse_vowarning(line):
    """
    Parses the vo warning string back into its parts.
    """
    result = {}
    match = _warning_pat.search(line)
    if match:
        result["warning"] = warning = match.group("warning")
        if warning is not None:
            result["is_warning"] = warning[0].upper() == "W"
            result["is_exception"] = not result["is_warning"]
            result["number"] = int(match.group("warning")[1:])
            result["doc_url"] = f"io/votable/api_exceptions.html#{warning.lower()}"
        else:
            result["is_warning"] = False
            result["is_exception"] = False
            result["is_other"] = True
            result["number"] = None
            result["doc_url"] = None
        try:
            result["nline"] = int(match.group("nline"))
        except ValueError:
            result["nline"] = 0
        try:
            result["nchar"] = int(match.group("nchar"))
        except ValueError:
            result["nchar"] = 0
        result["message"] = match.group("rest")
        result["is_something"] = True
    else:
        result["warning"] = None
        result["is_warning"] = False
        result["is_exception"] = False
        result["is_other"] = False
        result["is_something"] = False
        if not isinstance(line, str):
            line = line.decode("utf-8")
        result["message"] = line

    return result


class VOWarning(AstropyWarning):
    """
    The base class of all VO warnings and exceptions.

    Handles the formatting of the message with a warning or exception
    code, filename, line and column number.
    """

    default_args = ()
    message_template = ""

    def __init__(self, args, config=None, pos=None):
        if config is None:
            config = {}
        if not isinstance(args, tuple):
            args = (args,)
        msg = self.message_template.format(*args)

astropy/io/votable/tests/test_tree.py:27:def test_check_astroyear_fail():
astropy/io/votable/tests/test_tree.py:31:        tree.check_astroyear("X2100", field, config)
astropy/io/votable/tree.py:1981:        check_astroyear(equinox, "equinox", self._config, self._pos)
astropy/io/votable/tree.py:1998:        check_astroyear(epoch, "epoch", self._config, self._pos)
```

## 原始行 85 · command_execution

命令：
```
/bin/bash -lc "sed -n '420,475p' astropy/io/votable/exceptions.py
sed -n '290,345p' astropy/io/votable/tree.py"
```

退出码：`0`

输出：
```
    the syntax of a `unified content descriptor
    <https://vizier.unistra.fr/doc/UCD.htx>`__.

    If the VOTable version is 1.2 or later, the UCD will also be
    checked to ensure it conforms to the controlled vocabulary defined
    by UCD1+.

    **References**: `1.1
    <http://www.ivoa.net/documents/VOTable/20040811/REC-VOTable-1.1-20040811.html#sec:ucd>`__,
    `1.2
    <http://www.ivoa.net/documents/VOTable/20091130/REC-VOTable-1.2.html#sec:ucd>`__
    """

    message_template = "Invalid UCD '{}': {}"
    default_args = ("x", "explanation")


class W07(VOTableSpecWarning):
    """Invalid astroYear.

    As astro year field is a Besselian or Julian year matching the
    regular expression::

        ^[JB]?[0-9]+([.][0-9]*)?$

    Defined in this XML Schema snippet::

        <xs:simpleType  name="astroYear">
          <xs:restriction base="xs:token">
            <xs:pattern  value="[JB]?[0-9]+([.][0-9]*)?"/>
          </xs:restriction>
        </xs:simpleType>
    """

    message_template = "Invalid astroYear in {}: '{}'"
    default_args = ("x", "y")


class W08(VOTableSpecWarning):
    """
    To avoid local-dependent number parsing differences, ``astropy.io.votable``
    may require a string or unicode string where a numeric type may
    make more sense.
    """

    message_template = "'{}' must be a str or bytes object"

    default_args = ("x",)


class W09(VOTableSpecWarning):
    """
    The VOTable specification uses the attribute name ``ID`` (with
    uppercase letters) to specify unique identifiers.  Some
    VOTable-producing tools use the more standard lowercase ``id``
    instead. ``astropy.io.votable`` accepts ``id`` and emits this warning if
    return config


######################################################################
# ATTRIBUTE CHECKERS















































def resolve_id(ID, id, config=None, pos=None):
    if ID is None and id is not None:
        warn_or_raise(W09, W09, (), config, pos)
        return id
```

## 原始行 91 · file_change

```
{
  "id": "item_61",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/utils/xml/check.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 93 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/utils/tests/test_xml.py astropy/io/votable/tests/test_tree.py::test_check_astroyear_fail astropy/io/votable/tests/test_tree.py::test_string_fail astropy/io/votable/tests/test_table.py::test_names_over_ids astropy/io/votable/tests/test_table.py::test_explicit_ids astropy/io/votable/tests/test_table.py::test_empty_table -q --disable-warnings --maxfail=5'
```

退出码：`1`

输出：
```
Internet access disabled
.........sFFFFF
=================================== FAILURES ===================================
__________________________ test_check_astroyear_fail ___________________________

    def test_check_astroyear_fail():
        config = {"verify": "exception"}
>       field = tree.Field(None, name="astroyear", arraysize="1")
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:29: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:1452: in __init__
    self.values = Values(self._votable, self)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1003: in __init__
    self.min = None
    ^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'Values' object has no attribute '_max'") raised in repr()] Values object at 0x722a05d18210>
min = None

    @min.setter
    def min(self, min):
>       self._min = self._parse_minmax(min)
                    ^^^^^^^^^^^^^^^^^^
E       AttributeError: 'Values' object has no attribute '_parse_minmax'

astropy/io/votable/tree.py:1104: AttributeError
_______________________________ test_string_fail _______________________________

    def test_string_fail():
        config = {"verify": "exception"}
        with pytest.raises(W08):
>           tree.check_string(42, "foo", config)

astropy/io/votable/tests/test_tree.py:37: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:300: in check_string
    warn_or_raise(W08, W08, name, config, pos)
astropy/io/votable/exceptions.py:113: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
astropy/io/votable/exceptions.py:124: in vo_raise
    raise exception_class(args, config, pos)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = W08('foo', {'verify': 'exception'}, None), args = ('foo',)
config = {'verify': 'exception'}, pos = None

    def __init__(self, args, config=None, pos=None):
        if config is None:
            config = {}
        if not isinstance(args, tuple):
            args = (args,)
        msg = self.message_template.format(*args)
    
>       self.formatted_message = _format_message(
                                 ^^^^^^^^^^^^^^^
            msg, self.__class__.__name__, config, pos
        )
E       NameError: name '_format_message' is not defined

astropy/io/votable/exceptions.py:231: NameError
_____________________________ test_names_over_ids ______________________________

    def test_names_over_ids():
        with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_table.py:170: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4481: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4348: in _add_coosys
    coosys = CooSys(config=config, pos=pos, **data)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1925: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x722a05bddc90>
system = 'eq_FK5'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1961: AttributeError
______________________________ test_explicit_ids _______________________________

    def test_explicit_ids():
        with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_table.py:197: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4481: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4348: in _add_coosys
    coosys = CooSys(config=config, pos=pos, **data)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1925: in __init__
    self.system = system
    ^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'CooSys' object has no attribute '_system'") raised in repr()] CooSys object at 0x722a05b2a090>
system = 'eq_FK5'

    @system.setter
    def system(self, system):
>       if system not in self.reference_frames:
                         ^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'CooSys' object has no attribute 'reference_frames'

astropy/io/votable/tree.py:1961: AttributeError
_______________________________ test_empty_table _______________________________

    def test_empty_table():
>       votable = parse(get_pkg_data_filename("data/empty_table.xml"))
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:446: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4481: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4345: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4113: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4055: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2921: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2837: in _register_field
    field = Field(self._votable, config=config, pos=pos, **data)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1452: in __init__
    self.values = Values(self._votable, self)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1003: in __init__
    self.min = None
    ^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'Values' object has no attribute '_max'") raised in repr()] Values object at 0x722a05988d50>
min = None

    @min.setter
    def min(self, min):
>       self._min = self._parse_minmax(min)
                    ^^^^^^^^^^^^^^^^^^
E       AttributeError: 'Values' object has no attribute '_parse_minmax'

astropy/io/votable/tree.py:1104: AttributeError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_tree.py::test_check_astroyear_fail - Att...
FAILED astropy/io/votable/tests/test_tree.py::test_string_fail - NameError: n...
FAILED astropy/io/votable/tests/test_table.py::test_names_over_ids - Attribut...
FAILED astropy/io/votable/tests/test_table.py::test_explicit_ids - AttributeE...
FAILED astropy/io/votable/tests/test_table.py::test_empty_table - AttributeEr...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 5 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
5 failed, 9 passed, 1 skipped in 0.45s
```

## 原始行 96 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/exceptions.py | sed -n '1,180p'
nl -ba astropy/io/votable/tree.py | sed -n '940,1320p'
nl -ba astropy/io/votable/tree.py | sed -n '1860,2050p'
grep -RIn \"reference_frames\\|_parse_minmax\\|formatted_message\\|_format_message\" astropy/io/votable/tests astropy | head -200"
```

退出码：`0`

输出：
```
     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	"""VOTable exceptions and warnings.
     3	
     4	.. _warnings:
     5	
     6	Warnings
     7	--------
     8	.. note::
     9	    Most of the following warnings indicate violations of the VOTable
    10	    specification.  They should be reported to the authors of the
    11	    tools that produced the VOTable file.
    12	
    13	    To control the warnings emitted, use the standard Python
    14	    :mod:`warnings` module and the ``astropy.io.votable.exceptions.conf.max_warnings``
    15	    configuration item.  Most of these are of the type `VOTableSpecWarning`.
    16	
    17	{warnings}
    18	
    19	.. _exceptions:
    20	
    21	Exceptions
    22	----------
    23	
    24	.. note::
    25	
    26	    This is a list of many of the fatal exceptions emitted by ``astropy.io.votable``
    27	    when the file does not conform to spec.  Other exceptions may be
    28	    raised due to unforeseen cases or bugs in ``astropy.io.votable`` itself.
    29	
    30	{exceptions}
    31	"""
    32	
    33	# STDLIB
    34	import io
    35	import re
    36	from textwrap import dedent
    37	from warnings import warn
    38	
    39	from astropy import config as _config
    40	from astropy.utils.exceptions import AstropyWarning
    41	
    42	__all__ = [
    43	    "Conf",
    44	    "IOWarning",
    45	    "UnimplementedWarning",
    46	    "VOTableChangeWarning",
    47	    "VOTableSpecError",
    48	    "VOTableSpecWarning",
    49	    "VOWarning",
    50	    "conf",
    51	    "parse_vowarning",
    52	    "vo_raise",
    53	    "vo_reraise",
    54	    "vo_warn",
    55	    "warn_or_raise",
    56	    "warn_unknown_attrs",
    57	]
    58	
    59	
    60	# NOTE: Cannot put this in __init__.py due to circular import.
    61	class Conf(_config.ConfigNamespace):
    62	    """
    63	    Configuration parameters for `astropy.io.votable.exceptions`.
    64	    """
    65	
    66	    max_warnings = _config.ConfigItem(
    67	        10,
    68	        "Number of times the same type of warning is displayed before being suppressed",
    69	        cfgtype="integer",
    70	    )
    71	
    72	
    73	conf = Conf()
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	def warn_or_raise(
    99	    warning_class, exception_class=None, args=(), config=None, pos=None, stacklevel=1
   100	):
   101	    """
   102	    Warn or raise an exception, depending on the verify setting.
   103	    """
   104	    if config is None:
   105	        config = {}
   106	    # NOTE: the default here is deliberately warn rather than ignore, since
   107	    # one would expect that calling warn_or_raise without config should not
   108	    # silence the warnings.
   109	    config_value = config.get("verify", "warn")
   110	    if config_value == "exception":
   111	        if exception_class is None:
   112	            exception_class = warning_class
   113	        vo_raise(exception_class, args, config, pos)
   114	    elif config_value == "warn":
   115	        vo_warn(warning_class, args, config, pos, stacklevel=stacklevel + 1)
   116	
   117	
   118	def vo_raise(exception_class, args=(), config=None, pos=None):
   119	    """
   120	    Raise an exception, with proper position information if available.
   121	    """
   122	    if config is None:
   123	        config = {}
   124	    raise exception_class(args, config, pos)
   125	
   126	
   127	def vo_reraise(exc, config=None, pos=None, additional=""):
   128	    """
   129	    Raise an exception, with proper position information if available.
   130	
   131	    Restores the original traceback of the exception, and should only
   132	    be called within an "except:" block of code.
   133	    """
   134	    if config is None:
   135	        config = {}
   136	    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
   137	    if message.split()[0] == str(exc).split()[0]:
   138	        message = str(exc)
   139	    if len(additional):
   140	        message += " " + additional
   141	    exc.args = (message,)
   142	    raise exc
   143	
   144	
   145	def vo_warn(warning_class, args=(), config=None, pos=None, stacklevel=1):
   146	    """
   147	    Warn, with proper position information if available.
   148	    """
   149	    if config is None:
   150	        config = {}
   151	    # NOTE: the default here is deliberately warn rather than ignore, since
   152	    # one would expect that calling warn_or_raise without config should not
   153	    # silence the warnings.
   154	    if config.get("verify", "warn") != "ignore":
   155	        warning = warning_class(args, config, pos)
   156	        _suppressed_warning(warning, config, stacklevel=stacklevel + 1)
   157	
   158	
   159	def warn_unknown_attrs(element, attrs, config, pos, good_attr=[], stacklevel=1):
   160	    for attr in attrs:
   161	        if attr not in good_attr:
   162	            vo_warn(W48, (attr, element), config, pos, stacklevel=stacklevel + 1)
   163	
   164	
   165	_warning_pat = re.compile(
   166	    r":?(?P<nline>[0-9?]+):(?P<nchar>[0-9?]+): "
   167	    r"((?P<warning>[WE]\d+): )?(?P<rest>.*)$"
   168	)
   169	
   170	
   171	def parse_vowarning(line):
   172	    """
   173	    Parses the vo warning string back into its parts.
   174	    """
   175	    result = {}
   176	    match = _warning_pat.search(line)
   177	    if match:
   178	        result["warning"] = warning = match.group("warning")
   179	        if warning is not None:
   180	            result["is_warning"] = warning[0].upper() == "W"
   940	
   941	        if not self._config.get("version_1_2_or_later"):
   942	            warn_or_raise(W28, W28, ("unit", "INFO", "1.2"), self._config, self._pos)
   943	
   944	        # First, parse the unit in the default way, so that we can
   945	        # still emit a warning if the unit is not to spec.
   946	        default_format = _get_default_unit_format(self._config)
   947	        unit_obj = u.Unit(unit, format=default_format, parse_strict="silent")
   948	        if isinstance(unit_obj, u.UnrecognizedUnit):
   949	            warn_or_raise(W50, W50, (unit,), self._config, self._pos)
   950	
   951	        format = _get_unit_format(self._config)
   952	        if format != default_format:
   953	            unit_obj = u.Unit(unit, format=format, parse_strict="silent")
   954	
   955	        self._unit = unit_obj
   956	
   957	    @unit.deleter
   958	    def unit(self):
   959	        self._unit = None
   960	
   961	    def to_xml(self, w, **kwargs):
   962	        attrib = w.object_attrs(self, self._attr_list)
   963	        if "unit" in attrib:
   964	            attrib["unit"] = self.unit.to_string("cds")
   965	        w.element(self._element_name, self._content, attrib=attrib)
   966	
   967	
   968	class Values(Element, _IDProperty):
   969	    """
   970	    VALUES_ element: used within FIELD_ and PARAM_ elements to define the domain of values.
   971	
   972	    The keyword arguments correspond to setting members of the same
   973	    name, documented below.
   974	    """
   975	
   976	    def __init__(
   977	        self,
   978	        votable,
   979	        field,
   980	        ID=None,
   981	        null=None,
   982	        ref=None,
   983	        type="legal",
   984	        id=None,
   985	        config=None,
   986	        pos=None,
   987	        **extras,
   988	    ):
   989	        if config is None:
   990	            config = {}
   991	        self._config = config
   992	        self._pos = pos
   993	
   994	        Element.__init__(self)
   995	
   996	        self._votable = votable
   997	        self._field = field
   998	        self.ID = resolve_id(ID, id, config, pos)
   999	        self.null = null
  1000	        self._ref = ref
  1001	        self.type = type
  1002	
  1003	        self.min = None
  1004	        self.max = None
  1005	        self.min_inclusive = True
  1006	        self.max_inclusive = True
  1007	        self._options = []
  1008	
  1009	        warn_unknown_attrs("VALUES", extras.keys(), config, pos)
  1010	
  1011	    def __repr__(self):
  1012	        buff = io.StringIO()
  1013	        self.to_xml(XMLWriter(buff))
  1014	        return buff.getvalue().strip()
  1015	
  1016	    @property
  1017	    def null(self):
  1018	        """
  1019	        For integral datatypes, *null* is used to define the value
  1020	        used for missing values.
  1021	        """
  1022	        return self._null
  1023	
  1024	    @null.setter
  1025	    def null(self, null):
  1026	        if null is not None and isinstance(null, str):
  1027	            try:
  1028	                null_val = self._field.converter.parse_scalar(
  1029	                    null, self._config, self._pos
  1030	                )[0]
  1031	            except Exception:
  1032	                warn_or_raise(W36, W36, null, self._config, self._pos)
  1033	                null_val = self._field.converter.parse_scalar(
  1034	                    "0", self._config, self._pos
  1035	                )[0]
  1036	        else:
  1037	            null_val = null
  1038	        self._null = null_val
  1039	
  1040	    @null.deleter
  1041	    def null(self):
  1042	        self._null = None
  1043	
  1044	    @property
  1045	    def type(self):
  1046	        """Defines the applicability of the domain defined by this VALUES_ element [*required*].
  1047	
  1048	        Must be one of the following strings:
  1049	
  1050	          - 'legal': The domain of this column applies in general to
  1051	            this datatype. (default)
  1052	
  1053	          - 'actual': The domain of this column applies only to the
  1054	            data enclosed in the parent table.
  1055	        """
  1056	        return self._type
  1057	
  1058	    @type.setter
  1059	    def type(self, type):
  1060	        if type not in ("legal", "actual"):
  1061	            vo_raise(E08, type, self._config, self._pos)
  1062	        self._type = type
  1063	
  1064	    @property
  1065	    def ref(self):
  1066	        """
  1067	        Refer to another VALUES_ element by ID_, defined previously in
  1068	        the document, for MIN/MAX/OPTION information.
  1069	        """
  1070	        return self._ref
  1071	
  1072	    @ref.setter
  1073	    def ref(self, ref):
  1074	        xmlutil.check_id(ref, "ref", self._config, self._pos)
  1075	        if ref is not None:
  1076	            try:
  1077	                other = self._votable.get_values_by_id(ref, before=self)
  1078	            except KeyError:
  1079	                warn_or_raise(W43, W43, ("VALUES", self.ref), self._config, self._pos)
  1080	                ref = None
  1081	            else:
  1082	                self.null = other.null
  1083	                self.type = other.type
  1084	                self.min = other.min
  1085	                self.min_inclusive = other.min_inclusive
  1086	                self.max = other.max
  1087	                self.max_inclusive = other.max_inclusive
  1088	                self._options[:] = other.options
  1089	        self._ref = ref
  1090	
  1091	    @ref.deleter
  1092	    def ref(self):
  1093	        self._ref = None
  1094	
  1095	    @property
  1096	    def min(self):
  1097	        """
  1098	        The minimum value of the domain.  See :attr:`min_inclusive`.
  1099	        """
  1100	        return self._min
  1101	
  1102	    @min.setter
  1103	    def min(self, min):
  1104	        self._min = self._parse_minmax(min)
  1105	
  1106	    @min.deleter
  1107	    def min(self):
  1108	        self._min = None
  1109	
  1110	    @property
  1111	    def min_inclusive(self):
  1112	        """When `True`, the domain includes the minimum value."""
  1113	        return self._min_inclusive
  1114	
  1115	    @min_inclusive.setter
  1116	    def min_inclusive(self, inclusive):
  1117	        if inclusive == "yes":
  1118	            self._min_inclusive = True
  1119	        elif inclusive == "no":
  1120	            self._min_inclusive = False
  1121	        else:
  1122	            self._min_inclusive = bool(inclusive)
  1123	
  1124	    @min_inclusive.deleter
  1125	    def min_inclusive(self):
  1126	        self._min_inclusive = True
  1127	
  1128	    @property
  1129	    def max(self):
  1130	        """
  1131	        The maximum value of the domain.  See :attr:`max_inclusive`.
  1132	        """
  1133	        return self._max
  1134	
  1135	    @max.setter
  1136	    def max(self, max):
  1137	        self._max = self._parse_minmax(max)
  1138	
  1139	    @max.deleter
  1140	    def max(self):
  1141	        self._max = None
  1142	
  1143	    @property
  1144	    def max_inclusive(self):
  1145	        """When `True`, the domain includes the maximum value."""
  1146	        return self._max_inclusive
  1147	
  1148	    @max_inclusive.setter
  1149	    def max_inclusive(self, inclusive):
  1150	        if inclusive == "yes":
  1151	            self._max_inclusive = True
  1152	        elif inclusive == "no":
  1153	            self._max_inclusive = False
  1154	        else:
  1155	            self._max_inclusive = bool(inclusive)
  1156	
  1157	    @max_inclusive.deleter
  1158	    def max_inclusive(self):
  1159	        self._max_inclusive = True
  1160	
  1161	    @property
  1162	    def options(self):
  1163	        """
  1164	        A list of string key-value tuples defining other OPTION
  1165	        elements for the domain.  All options are ignored -- they are
  1166	        stored for round-tripping purposes only.
  1167	        """
  1168	        return self._options
  1169	
  1170	    def parse(self, iterator, config):
  1171	        if self.ref is not None:
  1172	            for start, tag, data, pos in iterator:
  1173	                if start:
  1174	                    warn_or_raise(W44, W44, tag, config, pos)
  1175	                else:
  1176	                    if tag != "VALUES":
  1177	                        warn_or_raise(W44, W44, tag, config, pos)
  1178	                    break
  1179	        else:
  1180	            for start, tag, data, pos in iterator:
  1181	                if start:
  1182	                    if tag == "MIN":
  1183	                        if "value" not in data:
  1184	                            vo_raise(E09, "MIN", config, pos)
  1185	                        self.min = data["value"]
  1186	                        self.min_inclusive = data.get("inclusive", "yes")
  1187	                        warn_unknown_attrs(
  1188	                            "MIN", data.keys(), config, pos, ["value", "inclusive"]
  1189	                        )
  1190	                    elif tag == "MAX":
  1191	                        if "value" not in data:
  1192	                            vo_raise(E09, "MAX", config, pos)
  1193	                        self.max = data["value"]
  1194	                        self.max_inclusive = data.get("inclusive", "yes")
  1195	                        warn_unknown_attrs(
  1196	                            "MAX", data.keys(), config, pos, ["value", "inclusive"]
  1197	                        )
  1198	                    elif tag == "OPTION":
  1199	                        if "value" not in data:
  1200	                            vo_raise(E09, "OPTION", config, pos)
  1201	                        xmlutil.check_token(data.get("name"), "name", config, pos)
  1202	                        self.options.append((data.get("name"), data.get("value")))
  1203	                        warn_unknown_attrs(
  1204	                            "OPTION", data.keys(), config, pos, ["value", "name"]
  1205	                        )
  1206	                elif tag == "VALUES":
  1207	                    break
  1208	
  1209	        return self
  1210	
  1211	
  1212	
  1213	
  1214	
  1215	
  1216	
  1217	
  1218	
  1219	
  1220	
  1221	
  1222	
  1223	
  1224	
  1225	
  1226	
  1227	
  1228	
  1229	
  1230	
  1231	
  1232	
  1233	
  1234	
  1235	
  1236	
  1237	
  1238	
  1239	
  1240	    def is_defaults(self):
  1241	        """
  1242	        Are the settings on this ``VALUE`` element all the same as the
  1243	        XML defaults?.
  1244	        """
  1245	        # If there's nothing meaningful or non-default to write,
  1246	        # don't write anything.
  1247	        return (
  1248	            self.ref is None
  1249	            and self.null is None
  1250	            and self.ID is None
  1251	            and self.max is None
  1252	            and self.min is None
  1253	            and self.options == []
  1254	        )
  1255	
  1256	    def to_xml(self, w, **kwargs):
  1257	        def yes_no(value):
  1258	            if value:
  1259	                return "yes"
  1260	            return "no"
  1261	
  1262	        if self.is_defaults():
  1263	            return
  1264	
  1265	        if self.ref is not None:
  1266	            w.element("VALUES", attrib=w.object_attrs(self, ["ref"]))
  1267	        else:
  1268	            with w.tag("VALUES", attrib=w.object_attrs(self, ["ID", "null", "ref"])):
  1269	                if self.min is not None:
  1270	                    w.element(
  1271	                        "MIN",
  1272	                        value=self._field.converter.output(self.min, False),
  1273	                        inclusive=yes_no(self.min_inclusive),
  1274	                    )
  1275	                if self.max is not None:
  1276	                    w.element(
  1277	                        "MAX",
  1278	                        value=self._field.converter.output(self.max, False),
  1279	                        inclusive=yes_no(self.max_inclusive),
  1280	                    )
  1281	                for name, value in self.options:
  1282	                    w.element("OPTION", name=name, value=value)
  1283	
  1284	    def to_table_column(self, column):
  1285	        # Have the ref filled in here
  1286	        meta = {}
  1287	        for key in ["ID", "null"]:
  1288	            val = getattr(self, key, None)
  1289	            if val is not None:
  1290	                meta[key] = val
  1291	        if self.min is not None:
  1292	            meta["min"] = {"value": self.min, "inclusive": self.min_inclusive}
  1293	        if self.max is not None:
  1294	            meta["max"] = {"value": self.max, "inclusive": self.max_inclusive}
  1295	        if len(self.options):
  1296	            meta["options"] = dict(self.options)
  1297	
  1298	        column.meta["values"] = meta
  1299	
  1300	    def from_table_column(self, column):
  1301	        if column.info.meta is None or "values" not in column.info.meta:
  1302	            return
  1303	
  1304	        meta = column.info.meta["values"]
  1305	        for key in ["ID", "null"]:
  1306	            val = meta.get(key, None)
  1307	            if val is not None:
  1308	                setattr(self, key, val)
  1309	        if "min" in meta:
  1310	            self.min = meta["min"]["value"]
  1311	            self.min_inclusive = meta["min"]["inclusive"]
  1312	        if "max" in meta:
  1313	            self.max = meta["max"]["value"]
  1314	            self.max_inclusive = meta["max"]["inclusive"]
  1315	        if "options" in meta:
  1316	            self._options = list(meta["options"].items())
  1317	
  1318	
  1319	class Field(
  1320	    SimpleElement,
  1860	        return self._value
  1861	
  1862	    @value.setter
  1863	    def value(self, value):
  1864	        if value is None:
  1865	            value = ""
  1866	        if isinstance(value, str):
  1867	            self._value = self.converter.parse(value, self._config, self._pos)[0]
  1868	        else:
  1869	            self._value = value
  1870	
  1871	    def _setup(self, config, pos):
  1872	        Field._setup(self, config, pos)
  1873	        self.value = self._value
  1874	
  1875	    def to_xml(self, w, **kwargs):
  1876	        tmp_value = self._value
  1877	        self._value = self.converter.output(tmp_value, False)
  1878	        # We must always have a value
  1879	        if self._value is None:
  1880	            self._value = ""
  1881	        Field.to_xml(self, w, **kwargs)
  1882	        self._value = tmp_value
  1883	
  1884	
  1885	class CooSys(SimpleElement):
  1886	    """
  1887	    COOSYS_ element: defines a coordinate system.
  1888	
  1889	    The keyword arguments correspond to setting members of the same
  1890	    name, documented below.
  1891	    """
  1892	
  1893	    _attr_list = ["ID", "equinox", "epoch", "system", "refposition"]
  1894	    _element_name = "COOSYS"
  1895	    _reference_frames = None
  1896	
  1897	    def __init__(
  1898	        self,
  1899	        ID=None,
  1900	        equinox=None,
  1901	        epoch=None,
  1902	        system=None,
  1903	        id=None,
  1904	        config=None,
  1905	        pos=None,
  1906	        refposition=None,
  1907	        **extra,
  1908	    ):
  1909	        if config is None:
  1910	            config = {}
  1911	        self._config = config
  1912	        self._pos = pos
  1913	
  1914	        # COOSYS was deprecated in 1.2 but then re-instated in 1.3
  1915	        if config.get("version_1_2_or_later") and not config.get(
  1916	            "version_1_3_or_later"
  1917	        ):
  1918	            warn_or_raise(W27, W27, (), config, pos)
  1919	
  1920	        SimpleElement.__init__(self)
  1921	
  1922	        self.ID = resolve_id(ID, id, config, pos)
  1923	        self.equinox = equinox
  1924	        self.epoch = epoch
  1925	        self.system = system
  1926	        self.refposition = refposition
  1927	
  1928	        # refposition introduced in v1.5.
  1929	        if self.refposition is not None and not config.get("version_1_5_or_later"):
  1930	            warn_or_raise(W57, W57, (), config, pos)
  1931	
  1932	        warn_unknown_attrs("COOSYS", extra.keys(), config, pos)
  1933	
  1934	    @property
  1935	    def ID(self):
  1936	        """
  1937	        [*required*] The XML ID of the COOSYS_ element, used for
  1938	        cross-referencing.  May be `None` or a string conforming to
  1939	        XML ID_ syntax.
  1940	        """
  1941	        return self._ID
  1942	
  1943	    @ID.setter
  1944	    def ID(self, ID):
  1945	        if self._config.get("version_1_1_or_later"):
  1946	            if ID is None:
  1947	                vo_raise(E15, (), self._config, self._pos)
  1948	        xmlutil.check_id(ID, "ID", self._config, self._pos)
  1949	        self._ID = ID
  1950	
  1951	    @property
  1952	    def system(self):
  1953	        """Specifies the type of coordinate system.
  1954	
  1955	        Valid choices are given by `~astropy.io.votable.tree.CooSys.reference_frames`
  1956	        """
  1957	        return self._system
  1958	
  1959	    @system.setter
  1960	    def system(self, system):
  1961	        if system not in self.reference_frames:
  1962	            warn_or_raise(E16, E16, system, self._config, self._pos)
  1963	        self._system = system
  1964	
  1965	    @system.deleter
  1966	    def system(self):
  1967	        self._system = None
  1968	
  1969	
  1970	
  1971	
  1972	
  1973	
  1974	
  1975	
  1976	
  1977	
  1978	
  1979	
  1980	
  1981	
  1982	
  1983	
  1984	
  1985	
  1986	
  1987	
  1988	
  1989	
  1990	    @property
  1991	    def equinox(self):
  1992	        """
  1993	        A parameter required to fix the equatorial or ecliptic systems
  1994	        (as e.g. "J2000" as the default "eq_FK5" or "B1950" as the
  1995	        default "eq_FK4").
  1996	        """
  1997	        return self._equinox
  1998	
  1999	    @equinox.setter
  2000	    def equinox(self, equinox):
  2001	        check_astroyear(equinox, "equinox", self._config, self._pos)
  2002	        self._equinox = equinox
  2003	
  2004	    @equinox.deleter
  2005	    def equinox(self):
  2006	        self._equinox = None
  2007	
  2008	    @property
  2009	    def epoch(self):
  2010	        """
  2011	        Specifies the epoch of the positions.  It must be a string
  2012	        specifying an astronomical year.
  2013	        """
  2014	        return self._epoch
  2015	
  2016	    @epoch.setter
  2017	    def epoch(self, epoch):
  2018	        check_astroyear(epoch, "epoch", self._config, self._pos)
  2019	        self._epoch = epoch
  2020	
  2021	    @epoch.deleter
  2022	    def epoch(self):
  2023	        self._epoch = None
  2024	
  2025	    def to_astropy_frame(self):
  2026	        """Convert the coosys element into an astropy built-in frame.
  2027	
  2028	        This only reads the system and equinox attributes.
  2029	
  2030	        Returns
  2031	        -------
  2032	        `~astropy.coordinates.BaseCoordinateFrame`
  2033	            An astropy built-in frame corresponding to the frame described by
  2034	            the COOSYS element.
  2035	
  2036	        Examples
  2037	        --------
  2038	        >>> from astropy.io.votable.tree import CooSys
  2039	        >>> coosys = CooSys(system="ICRS", epoch="J2020")
  2040	        >>> # note that coosys elements also contain the epoch
  2041	        >>> coosys.to_astropy_frame()
  2042	        <ICRS Frame>
  2043	
  2044	        Notes
  2045	        -----
  2046	        If the correspondence is not straightforward, this method raises an error. In
  2047	        that case, you can refer to the `IVOA reference frames definition
  2048	        <http://www.ivoa.net/rdf/refframe>`_ and the list of `astropy's frames
  2049	        <https://docs.astropy.org/en/stable/coordinates/frames.html>`_ and deal with the
  2050	        conversion manually.
astropy/io/votable/tests/test_util.py:43:        print(util.coerce_range_list_param((5, "FOO"), util.stc_reference_frames))
astropy/io/votable/tests/test_util.py:63:        util.coerce_range_list_param("52,-27.8;FOO", util.stc_reference_frames)
astropy/io/votable/tests/test_util.py:67:    assert util.coerce_range_list_param("52,-27.8;GALACTIC", util.stc_reference_frames)
astropy/io/votable/exceptions.py:136:    message = _format_message(str(exc), exc.__class__.__name__, config, pos)
astropy/io/votable/exceptions.py:231:        self.formatted_message = _format_message(
astropy/io/votable/exceptions.py:234:        Warning.__init__(self, self.formatted_message)
astropy/io/votable/exceptions.py:237:        return self.formatted_message
astropy/io/votable/util.py:19:    "stc_reference_frames",
astropy/io/votable/util.py:91:stc_reference_frames = {
astropy/io/votable/util.py:165:        provided, the default set in ``set_reference_frames`` will be
astropy/io/votable/tests/test_util.py:43:        print(util.coerce_range_list_param((5, "FOO"), util.stc_reference_frames))
astropy/io/votable/tests/test_util.py:63:        util.coerce_range_list_param("52,-27.8;FOO", util.stc_reference_frames)
astropy/io/votable/tests/test_util.py:67:    assert util.coerce_range_list_param("52,-27.8;GALACTIC", util.stc_reference_frames)
astropy/io/votable/tree.py:1104:        self._min = self._parse_minmax(min)
astropy/io/votable/tree.py:1137:        self._max = self._parse_minmax(max)
astropy/io/votable/tree.py:1895:    _reference_frames = None
astropy/io/votable/tree.py:1955:        Valid choices are given by `~astropy.io.votable.tree.CooSys.reference_frames`
astropy/io/votable/tree.py:1961:        if system not in self.reference_frames:
```

## 原始行 99 · command_execution

命令：
```
/bin/bash -lc "sed -n '70,130p' astropy/io/votable/util.py
grep -RIn \"CooSys\\.reference_frames\\|reference_frames =\" astropy/io/votable/tests docs | head -100
grep -RIn \"max_warnings\\|suppressed\\|formatted_message\\|parse_vowarning\" astropy/io/votable/tests | head -250"
```

退出码：`0`

输出：
```
        except TypeError:
            needs_wrapper = True

        if not hasattr(fd, "encoding") or fd.encoding is None:
            needs_wrapper = True

        if needs_wrapper:
            yield codecs.getwriter("utf-8")(fd)
        else:
            yield fd

        fd.flush()
        if isinstance(fd, gzip.GzipFile):
            fd.close()

        return
    else:
        raise TypeError("Can not be coerced to writable file-like object")


# <http://www.ivoa.net/documents/REC/DM/STC-20071030.html>
stc_reference_frames = {
    "FK4",
    "FK5",
    "ECLIPTIC",
    "ICRS",
    "GALACTIC",
    "GALACTIC_I",
    "GALACTIC_II",
    "SUPER_GALACTIC",
    "AZ_EL",
    "BODY",
    "GEO_C",
    "GEO_D",
    "MAG",
    "GSE",
    "GSM",
    "SM",
    "HGC",
    "HGS",
    "HEEQ",
    "HRTN",
    "HPC",
    "HPR",
    "HCC",
    "HGI",
    "MERCURY_C",
    "VENUS_C",
    "LUNA_C",
    "MARS_C",
    "JUPITER_C_III",
    "SATURN_C_III",
    "URANUS_C_III",
    "NEPTUNE_C_III",
    "PLUTO_C",
    "MERCURY_G",
    "VENUS_G",
    "LUNA_G",
    "MARS_G",
    "JUPITER_G_III",
    "SATURN_G_III",
astropy/io/votable/tests/test_exception.py:19:def test_parse_vowarning():
astropy/io/votable/tests/test_exception.py:26:    parts = exceptions.parse_vowarning(str(w[0].message))
astropy/io/votable/tests/test_exception.py:46:    with exceptions.conf.set_temp("max_warnings", 2):
astropy/io/votable/tests/test_exception.py:48:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:53:            exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:55:        exceptions._suppressed_warning(warn, cfg)
astropy/io/votable/tests/test_exception.py:58:    assert exceptions.conf.max_warnings == 10
```

## 原始行 101 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,90p' astropy/io/votable/tests/test_exception.py
sed -n '220,260p' astropy/io/votable/exceptions.py
grep -n \"filename\" astropy/io/votable/exceptions.py | head -30"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
import pytest

# LOCAL
from astropy.io.votable import converters, exceptions, tree


def test_reraise():
    def fail():
        raise RuntimeError("This failed")

    with pytest.raises(RuntimeError, match="From here"):
        try:
            fail()
        except RuntimeError as e:
            exceptions.vo_reraise(e, additional="From here")


def test_parse_vowarning():
    config = {"verify": "exception", "filename": "foo.xml"}
    pos = (42, 64)
    with pytest.warns(exceptions.W47) as w:
        field = tree.Field(None, name="c", datatype="char", config=config, pos=pos)
        converters.get_converter(field, config=config, pos=pos)

    parts = exceptions.parse_vowarning(str(w[0].message))

    match = {
        "number": 47,
        "is_exception": False,
        "nchar": 64,
        "warning": "W47",
        "is_something": True,
        "message": "Missing arraysize indicates length 1",
        "doc_url": "io/votable/api_exceptions.html#w47",
        "nline": 42,
        "is_warning": True,
    }
    assert parts == match


def test_suppress_warnings():
    cfg = {}
    warn = exceptions.W01("foo")

    with exceptions.conf.set_temp("max_warnings", 2):
        with pytest.warns(exceptions.W01) as record:
            exceptions._suppressed_warning(warn, cfg)
            assert len(record) == 1
            assert "suppressing" not in str(record[0].message)

        with pytest.warns(exceptions.W01, match="suppressing"):
            exceptions._suppressed_warning(warn, cfg)

        exceptions._suppressed_warning(warn, cfg)

    assert cfg["_warning_counts"][exceptions.W01] == 3
    assert exceptions.conf.max_warnings == 10

    default_args = ()
    message_template = ""

    def __init__(self, args, config=None, pos=None):
        if config is None:
            config = {}
        if not isinstance(args, tuple):
            args = (args,)
        msg = self.message_template.format(*args)

        self.formatted_message = _format_message(
            msg, self.__class__.__name__, config, pos
        )
        Warning.__init__(self, self.formatted_message)

    def __str__(self):
        return self.formatted_message

    @classmethod
    def get_short_name(cls):
        if len(cls.default_args):
            return cls.message_template.format(*cls.default_args)
        return cls.message_template


class VOTableChangeWarning(VOWarning, SyntaxWarning):
    """
    A change has been made to the input XML file.
    """


class VOTableSpecWarning(VOWarning, SyntaxWarning):
    """
    The input XML file violates the spec, but there is an obvious workaround.
    """


class ModelMappingSpecWarning(VOWarning, SyntaxWarning):
    """
    The input model mapping XML mapping block violates the spec.
218:    code, filename, line and column number.
```

## 原始行 104 · command_execution

命令：
```
/bin/bash -lc "grep -Rho 'system=\"["'^"]*"'"' astropy/io/votable/tests/data | sort -u
grep -RIn \"CooSys\\|COOSYS\" astropy/io/votable/tests/test_*.py | head -200"
```

退出码：`0`

输出：
```
system="FK4"
system="ICRS"
system="eq_FK5"
astropy/io/votable/tests/test_coosys.py:9:from astropy.io.votable.tree import CooSys
astropy/io/votable/tests/test_coosys.py:12:COOSYS_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
astropy/io/votable/tests/test_coosys.py:19:COOSYS_REFPOSITION = (
astropy/io/votable/tests/test_coosys.py:20:    '<COOSYS ID="my_coosys" epoch="J2015.5" system="ICRS" refposition="BARYCENTER"/>'
astropy/io/votable/tests/test_coosys.py:22:COOSYS_NO_REFPOSITION = '<COOSYS ID="my_coosys" epoch="J2015.5" system="ICRS"/>'
astropy/io/votable/tests/test_coosys.py:24:COOSYS_SYSTEM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
astropy/io/votable/tests/test_coosys.py:27:    <COOSYS ID="my_coosys" epoch="J2015.5" system="{}"/>
astropy/io/votable/tests/test_coosys.py:35:        ("1.1", "1.1", COOSYS_NO_REFPOSITION, None),
astropy/io/votable/tests/test_coosys.py:36:        ("1.2", "1.2", COOSYS_NO_REFPOSITION, W27),
astropy/io/votable/tests/test_coosys.py:37:        ("1.3", "1.3", COOSYS_NO_REFPOSITION, None),
astropy/io/votable/tests/test_coosys.py:38:        ("1.3", "1.4", COOSYS_NO_REFPOSITION, None),
astropy/io/votable/tests/test_coosys.py:39:        ("1.3", "1.5", COOSYS_NO_REFPOSITION, None),
astropy/io/votable/tests/test_coosys.py:40:        ("1.1", "1.1", COOSYS_REFPOSITION, W57),
astropy/io/votable/tests/test_coosys.py:41:        ("1.2", "1.2", COOSYS_REFPOSITION, (W27, W57)),
astropy/io/votable/tests/test_coosys.py:42:        ("1.3", "1.3", COOSYS_REFPOSITION, W57),
astropy/io/votable/tests/test_coosys.py:43:        ("1.3", "1.4", COOSYS_REFPOSITION, W57),
astropy/io/votable/tests/test_coosys.py:44:        ("1.3", "1.5", COOSYS_REFPOSITION, None),
astropy/io/votable/tests/test_coosys.py:46:        xml_string = COOSYS_TEMPLATE.format(ns_version, version, coosys)
astropy/io/votable/tests/test_coosys.py:68:        xml_string = COOSYS_SYSTEM_TEMPLATE.format(version, system)
astropy/io/votable/tests/test_coosys.py:128:    coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
astropy/io/votable/tests/test_coosys.py:139:        CooSys(system="BODY").to_astropy_frame()
astropy/io/votable/tests/test_tree.py:571:    # R1 : 2 mivot_block, 2 tables, 1 description, 1 info, 1 CooSys
astropy/io/votable/tests/test_tree.py:586:    cs = tree.CooSys(ID="_XYZ", system="ICRS")
astropy/io/votable/tests/test_tree.py:669:    # CooSys was deprecated only in v1.2 and refposition only allowed in 1.5.
astropy/io/votable/tests/test_tree.py:672:        tree.CooSys("REF", system="ICRS", config=votable.config)
astropy/io/votable/tests/test_tree.py:676:        tree.CooSys(
astropy/io/votable/tests/test_tree.py:681:    _ = tree.CooSys(
```

## 原始行 106 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,165p' astropy/io/votable/tests/test_coosys.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
import io

import pytest

from astropy.coordinates import FK4, FK5, ICRS, AltAz, Galactic, Supergalactic
from astropy.io.votable.exceptions import E16, W27, W57
from astropy.io.votable.table import parse
from astropy.io.votable.tree import CooSys
from astropy.utils.data import get_pkg_data_filename

COOSYS_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v{}" version="{}">
  <RESOURCE>
    {}
  </RESOURCE>
</VOTABLE>
"""
COOSYS_REFPOSITION = (
    '<COOSYS ID="my_coosys" epoch="J2015.5" system="ICRS" refposition="BARYCENTER"/>'
)
COOSYS_NO_REFPOSITION = '<COOSYS ID="my_coosys" epoch="J2015.5" system="ICRS"/>'

COOSYS_SYSTEM_TEMPLATE = """<?xml version="1.0" encoding="UTF-8"?>
<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="{}">
  <RESOURCE>
    <COOSYS ID="my_coosys" epoch="J2015.5" system="{}"/>
  </RESOURCE>
</VOTABLE>
"""


def test_accept_refposition():
    for ns_version, version, coosys, expected_warnings in [
        ("1.1", "1.1", COOSYS_NO_REFPOSITION, None),
        ("1.2", "1.2", COOSYS_NO_REFPOSITION, W27),
        ("1.3", "1.3", COOSYS_NO_REFPOSITION, None),
        ("1.3", "1.4", COOSYS_NO_REFPOSITION, None),
        ("1.3", "1.5", COOSYS_NO_REFPOSITION, None),
        ("1.1", "1.1", COOSYS_REFPOSITION, W57),
        ("1.2", "1.2", COOSYS_REFPOSITION, (W27, W57)),
        ("1.3", "1.3", COOSYS_REFPOSITION, W57),
        ("1.3", "1.4", COOSYS_REFPOSITION, W57),
        ("1.3", "1.5", COOSYS_REFPOSITION, None),
    ]:
        xml_string = COOSYS_TEMPLATE.format(ns_version, version, coosys)
        input = io.BytesIO(bytes(xml_string, "utf-8"))
        if expected_warnings is not None:
            with pytest.warns(expected_warnings) as record:
                vot = parse(input, verify="warn")
            # If expected_warnings is a tuple, pytest.warns checked for at least one of the warnings,
            # so make sure we got the right number of them.
            if isinstance(expected_warnings, tuple):
                assert len(record) == len(expected_warnings)
        else:
            vot = parse(input, verify="warn")


def test_coosys_system():
    for version, system, expected_warning in [
        ("1.4", "ICRS", None),
        ("1.4", "supergalactic", None),
        ("1.4", "InvalidSystem", E16),
        ("1.5", "ICRS", None),
        ("1.5", "supergalactic", None),
        ("1.5", "InvalidSystem", E16),
    ]:
        xml_string = COOSYS_SYSTEM_TEMPLATE.format(version, system)
        input = io.BytesIO(bytes(xml_string, "utf-8"))
        if expected_warning is not None:
            with pytest.warns(expected_warning):
                parse(input, verify="warn")
        else:
            parse(input, verify="warn")


def _coosys_tests(votable):
    assert len(list(votable.iter_coosys())) == 3
    coosys = votable.get_coosys_by_id("coosys0")
    assert coosys.system == "ICRS"
    assert coosys.equinox == "J2000"
    assert coosys.epoch == "J2014.5"
    assert coosys.refposition == "BARYCENTER"

    coosys = votable.get_coosys_by_id("coosys1")
    assert coosys.system == "ICRS"
    assert coosys.equinox == "J2000"
    assert coosys.epoch == "J2015.5"
    assert coosys.refposition == "BARYCENTER"

    coosys = votable.get_coosys_by_id("coosys2")
    assert coosys.system == "FK4"
    assert coosys.equinox == "B1950"
    assert coosys.epoch == "B1950.0"
    assert coosys.refposition == "UNKNOWN"


def test_coosys():
    votable = parse(get_pkg_data_filename("data/coosys.xml"))
    _coosys_tests(votable)


def test_coosys_roundtrip():
    orig_votable = parse(get_pkg_data_filename("data/coosys.xml"))
    bio = io.BytesIO()
    orig_votable.to_xml(bio)
    bio.seek(0)
    votable = parse(bio)
    _coosys_tests(votable)


test_to_astropy_frame = [
    ("ICRS", None, None, ICRS()),
    ("FK4", "B1950", "B1950", FK4(equinox="B1950")),
    ("FK5", "J2000", None, FK5(equinox="J2000")),
    ("eq_FK4", "B1950", "B1950", FK4(equinox="B1950")),
    ("eq_FK5", "J2000", None, FK5(equinox="J2000")),
    ("GALACTIC", None, None, Galactic()),
    ("galactic", None, None, Galactic()),
    ("SUPER_GALACTIC", None, None, Supergalactic()),
    ("supergalactic", None, None, Supergalactic()),
    ("AZ_EL", None, "J2020", AltAz()),
]


@pytest.mark.parametrize("system,equinox,epoch,expected", test_to_astropy_frame)
def test_coosys_to_astropy_frame_and_time(system, equinox, epoch, expected):
    coosys = CooSys(equinox=equinox, epoch=epoch, system=system)
    assert coosys.to_astropy_frame() == expected


def test_coosys_to_astropy_frame_error():
    with pytest.raises(
        ValueError,
        match=(
            "There is no direct correspondence between 'BODY' and an astropy frame.*"
        ),
    ):
        CooSys(system="BODY").to_astropy_frame()
```

## 原始行 109 · file_change

```
{
  "id": "item_72",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/exceptions.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 112 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _parse_minmax\" astropy/io/votable/tree.py
nl -ba astropy/io/votable/tree.py | sed -n '600,670p'
nl -ba astropy/io/votable/tree.py | sed -n '1200,1260p'
python -m py_compile astropy/io/votable/tree.py astropy/io/votable/exceptions.py"
```

退出码：`0`

输出：
```
616:    def _parse_minmax(self, value):
   600	        Element.__init__(self)
   601	
   602	    def __repr__(self):
   603	        buff = io.StringIO()
   604	        SimpleElement.to_xml(self, XMLWriter(buff))
   605	        return buff.getvalue().strip()
   606	
   607	    def parse(self, iterator, config):
   608	        for start, tag, data, pos in iterator:
   609	            if start and tag != self._element_name:
   610	                self._add_unknown_tag(iterator, tag, data, config, pos)
   611	            elif tag == self._element_name:
   612	                break
   613	
   614	        return self
   615	
   616	    def _parse_minmax(self, value):
   617	        """Parse a MIN or MAX value using the owning field's converter."""
   618	        if value is None or value == "":
   619	            return None
   620	        if isinstance(value, str):
   621	            return self._field.converter.parse(value, self._config, self._pos)[0]
   622	        return value
   623	
   624	    def to_xml(self, w, **kwargs):
   625	        w.element(self._element_name, attrib=w.object_attrs(self, self._attr_list))
   626	
   627	
   628	class SimpleElementWithContent(SimpleElement):
   629	    """
   630	    A base class for simple elements, such as FIELD, PARAM and INFO
   631	    that don't require any special parsing or outputting machinery.
   632	    """
   633	
   634	    def __init__(self):
   635	        SimpleElement.__init__(self)
   636	
   637	        self._content = None
   638	
   639	    def parse(self, iterator, config):
   640	        for start, tag, data, pos in iterator:
   641	            if start and tag != self._element_name:
   642	                self._add_unknown_tag(iterator, tag, data, config, pos)
   643	            elif tag == self._element_name:
   644	                if data:
   645	                    self.content = data
   646	                break
   647	
   648	        return self
   649	
   650	    def to_xml(self, w, **kwargs):
   651	        w.element(
   652	            self._element_name,
   653	            self._content,
   654	            attrib=w.object_attrs(self, self._attr_list),
   655	        )
   656	
   657	    @property
   658	    def content(self):
   659	        """The content of the element."""
   660	        return self._content
   661	
   662	    @content.setter
   663	    def content(self, content):
   664	        check_string(content, "content", self._config, self._pos)
   665	        self._content = content
   666	
   667	    @content.deleter
   668	    def content(self):
   669	        self._content = None
   670	
  1200	                            vo_raise(E09, "MAX", config, pos)
  1201	                        self.max = data["value"]
  1202	                        self.max_inclusive = data.get("inclusive", "yes")
  1203	                        warn_unknown_attrs(
  1204	                            "MAX", data.keys(), config, pos, ["value", "inclusive"]
  1205	                        )
  1206	                    elif tag == "OPTION":
  1207	                        if "value" not in data:
  1208	                            vo_raise(E09, "OPTION", config, pos)
  1209	                        xmlutil.check_token(data.get("name"), "name", config, pos)
  1210	                        self.options.append((data.get("name"), data.get("value")))
  1211	                        warn_unknown_attrs(
  1212	                            "OPTION", data.keys(), config, pos, ["value", "name"]
  1213	                        )
  1214	                elif tag == "VALUES":
  1215	                    break
  1216	
  1217	        return self
  1218	
  1219	
  1220	
  1221	
  1222	
  1223	
  1224	
  1225	
  1226	
  1227	
  1228	
  1229	
  1230	
  1231	
  1232	
  1233	
  1234	
  1235	
  1236	
  1237	
  1238	
  1239	
  1240	
  1241	
  1242	
  1243	
  1244	
  1245	
  1246	
  1247	
  1248	    def is_defaults(self):
  1249	        """
  1250	        Are the settings on this ``VALUE`` element all the same as the
  1251	        XML defaults?.
  1252	        """
  1253	        # If there's nothing meaningful or non-default to write,
  1254	        # don't write anything.
  1255	        return (
  1256	            self.ref is None
  1257	            and self.null is None
  1258	            and self.ID is None
  1259	            and self.max is None
  1260	            and self.min is None
```

## 原始行 115 · file_change

```
{
  "id": "item_76",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 117 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_exception.py astropy/io/votable/tests/test_tree.py::test_check_astroyear_fail astropy/io/votable/tests/test_tree.py::test_string_fail astropy/io/votable/tests/test_table.py::test_names_over_ids astropy/io/votable/tests/test_table.py::test_explicit_ids astropy/io/votable/tests/test_table.py::test_empty_table -q --disable-warnings --maxfail=5'
```

退出码：`1`

输出：
```
Internet access disabled
.....FFF                                                                 [100%]
=================================== FAILURES ===================================
_____________________________ test_names_over_ids ______________________________

    def test_names_over_ids():
        with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_table.py:170: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4507: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4371: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4139: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4081: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2863: in _register_field
    field = Field(self._votable, config=config, pos=pos, **data)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1452: in __init__
    self.ucd = ucd
    ^^^^^^^^
astropy/io/votable/tree.py:509: in ucd
    check_ucd(ucd, self._config, self._pos)
astropy/io/votable/tree.py:388: in check_ucd
    ucd_mod.parse_ucd(
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ucd = 'meta.id;meta.main', check_controlled_vocabulary = False
has_colon = False

    def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
        """
        Parse the UCD into its component parts.
    
        Parameters
        ----------
        ucd : str
            The UCD string
    
        check_controlled_vocabulary : bool, optional
            If `True`, then each word in the UCD will be verified against
            the UCD1+ controlled vocabulary, (as required by the VOTable
            specification version 1.2), otherwise not.
    
        has_colon : bool, optional
            If `True`, the UCD may contain a colon (as defined in earlier
            versions of the standard).
    
        Returns
        -------
        parts : list
            The result is a list of tuples of the form:
    
                (*namespace*, *word*)
    
            If no namespace was explicitly specified, *namespace* will be
            returned as ``'ivoa'`` (i.e., the default namespace).
    
        Raises
        ------
        ValueError
            if *ucd* is invalid
        """
        global _ucd_singleton
        if _ucd_singleton is None:
            _ucd_singleton = UCDWords()
    
        if has_colon:
            m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
        else:
            m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
        if m is not None:
            raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")
    
        word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
        word_re = rf"{word_component_re}(\.{word_component_re})*"
    
        parts = ucd.split(";")
        words = []
        for i, word in enumerate(parts):
            colon_count = word.count(":")
            if colon_count == 1:
                ns, word = word.split(":", 1)
                if not re.match(word_component_re, ns):
                    raise ValueError(f"Invalid namespace '{ns}'")
                ns = ns.lower()
            elif colon_count > 1:
                raise ValueError(f"Too many colons in '{word}'")
            else:
                ns = "ivoa"
    
            if not re.match(word_re, word):
                raise ValueError(f"Invalid word '{word}'")
    
            if ns == "ivoa" and check_controlled_vocabulary:
                if i == 0:
                    if not _ucd_singleton.is_primary(word):
                        if _ucd_singleton.is_secondary(word):
                            raise ValueError(
                                f"Secondary word '{word}' is not valid as a primary word"
                            )
                        else:
                            raise ValueError(f"Unknown word '{word}'")
                else:
                    if not _ucd_singleton.is_secondary(word):
                        if _ucd_singleton.is_primary(word):
                            raise ValueError(
                                f"Primary word '{word}' is not valid as a secondary word"
                            )
                        else:
                            raise ValueError(f"Unknown word '{word}'")
    
            try:
>               normalized_word = _ucd_singleton.normalize_capitalization(word)
                                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E               AttributeError: 'UCDWords' object has no attribute 'normalize_capitalization'

astropy/io/votable/ucd.py:155: AttributeError
______________________________ test_explicit_ids _______________________________

    def test_explicit_ids():
        with get_pkg_data_fileobj("data/names.xml", encoding="binary") as fd:
>           votable = parse(fd)
                      ^^^^^^^^^

astropy/io/votable/tests/test_table.py:197: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4507: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4371: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4139: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4081: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2863: in _register_field
    field = Field(self._votable, config=config, pos=pos, **data)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1452: in __init__
    self.ucd = ucd
    ^^^^^^^^
astropy/io/votable/tree.py:509: in ucd
    check_ucd(ucd, self._config, self._pos)
astropy/io/votable/tree.py:388: in check_ucd
    ucd_mod.parse_ucd(
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ucd = 'meta.id;meta.main', check_controlled_vocabulary = False
has_colon = False

    def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
        """
        Parse the UCD into its component parts.
    
        Parameters
        ----------
        ucd : str
            The UCD string
    
        check_controlled_vocabulary : bool, optional
            If `True`, then each word in the UCD will be verified against
            the UCD1+ controlled vocabulary, (as required by the VOTable
            specification version 1.2), otherwise not.
    
        has_colon : bool, optional
            If `True`, the UCD may contain a colon (as defined in earlier
            versions of the standard).
    
        Returns
        -------
        parts : list
            The result is a list of tuples of the form:
    
                (*namespace*, *word*)
    
            If no namespace was explicitly specified, *namespace* will be
            returned as ``'ivoa'`` (i.e., the default namespace).
    
        Raises
        ------
        ValueError
            if *ucd* is invalid
        """
        global _ucd_singleton
        if _ucd_singleton is None:
            _ucd_singleton = UCDWords()
    
        if has_colon:
            m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
        else:
            m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
        if m is not None:
            raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")
    
        word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
        word_re = rf"{word_component_re}(\.{word_component_re})*"
    
        parts = ucd.split(";")
        words = []
        for i, word in enumerate(parts):
            colon_count = word.count(":")
            if colon_count == 1:
                ns, word = word.split(":", 1)
                if not re.match(word_component_re, ns):
                    raise ValueError(f"Invalid namespace '{ns}'")
                ns = ns.lower()
            elif colon_count > 1:
                raise ValueError(f"Too many colons in '{word}'")
            else:
                ns = "ivoa"
    
            if not re.match(word_re, word):
                raise ValueError(f"Invalid word '{word}'")
    
            if ns == "ivoa" and check_controlled_vocabulary:
                if i == 0:
                    if not _ucd_singleton.is_primary(word):
                        if _ucd_singleton.is_secondary(word):
                            raise ValueError(
                                f"Secondary word '{word}' is not valid as a primary word"
                            )
                        else:
                            raise ValueError(f"Unknown word '{word}'")
                else:
                    if not _ucd_singleton.is_secondary(word):
                        if _ucd_singleton.is_primary(word):
                            raise ValueError(
                                f"Primary word '{word}' is not valid as a secondary word"
                            )
                        else:
                            raise ValueError(f"Unknown word '{word}'")
    
            try:
>               normalized_word = _ucd_singleton.normalize_capitalization(word)
                                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E               AttributeError: 'UCDWords' object has no attribute 'normalize_capitalization'

astropy/io/votable/ucd.py:155: AttributeError
_______________________________ test_empty_table _______________________________

    def test_empty_table():
        votable = parse(get_pkg_data_filename("data/empty_table.xml"))
        table = votable.get_first_table()
>       table.to_table()

astropy/io/votable/tests/test_table.py:448: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:3582: in to_table
    table = Table(self.array, names=names)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <[AttributeError("'Table' object has no attribute '_base_repr_'") raised in repr()] Table object at 0x76a83f9bced0>
data = masked_recarray(data=[],
                mask=[],
          fill_value=(63, 16959),
               dtype=(numpy.record, [('unsignedByte', 'u1'), ('short', '<i2')]))
masked = False, names = ['unsignedByte', 'short'], dtype = None, meta = None
copy = True, rows = None, copy_indices = True, units = None, descriptions = None
kwargs = {}, names_from_list_of_dict = None, default_names = None
meta_table_attrs = {}

    def __init__(
        self,
        data=None,
        masked=False,
        names=None,
        dtype=None,
        meta=None,
        copy=True,
        rows=None,
        copy_indices=True,
        units=None,
        descriptions=None,
        **kwargs,
    ):
        # Set up a placeholder empty table
        self._set_masked(masked)
        self.columns = self.TableColumns()
        self.formatter = self.TableFormatter()
        self._copy_indices = True  # copy indices from this Table by default
        self._init_indices = copy_indices  # whether to copy indices in init
        self.primary_key = None
    
        # Must copy if dtype are changing
        if not copy and dtype is not None:
            raise ValueError("Cannot specify dtype when copy=False")
    
        # Specifies list of names found for the case of initializing table with
        # a list of dict. If data are not list of dict then this is None.
        names_from_list_of_dict = None
    
        # Row-oriented input, e.g. list of lists or list of tuples, list of
        # dict, Row instance.  Set data to something that the subsequent code
        # will parse correctly.
        if rows is not None:
            if data is not None:
                raise ValueError("Cannot supply both `data` and `rows` values")
            if isinstance(rows, types.GeneratorType):
                # Without this then the all(..) test below uses up the generator
                rows = list(rows)
    
            # Get column names if `rows` is a list of dict, otherwise this is None
            names_from_list_of_dict = _get_names_from_list_of_dict(rows)
            if names_from_list_of_dict:
                data = rows
            elif isinstance(rows, self.Row) or (
                isinstance(rows, np.ndarray) and rows.dtype.names
            ):
                data = rows
            else:
                data = list(zip(*rows))
    
        # Infer the type of the input data and set up the initialization
        # function, number of columns, and potentially the default col names
    
        default_names = None
    
        # Handle custom (subclass) table attributes that are stored in meta.
        # These are defined as class attributes using the TableAttribute
        # descriptor.  Any such attributes get removed from kwargs here and
        # stored for use after the table is otherwise initialized. Any values
        # provided via kwargs will have precedence over existing values from
        # meta (e.g. from data as a Table or meta via kwargs).
        meta_table_attrs = {}
        if kwargs:
            for attr in list(kwargs):
                descr = getattr(self.__class__, attr, None)
                if isinstance(descr, TableAttribute):
                    meta_table_attrs[attr] = kwargs.pop(attr)
    
        if hasattr(data, "__astropy_table__"):
            # Data object implements the __astropy_table__ interface method.
            # Calling that method returns an appropriate instance of
            # self.__class__ and respects the `copy` arg.  The returned
            # Table object should NOT then be copied.
            data = data.__astropy_table__(self.__class__, copy, **kwargs)
            copy = COPY_IF_NEEDED
        elif kwargs:
            raise TypeError(
                f"__init__() got unexpected keyword argument {next(iter(kwargs.keys()))!r}"
            )
    
        # Treat any empty numpy array as None, except for structured arrays since they
        # provide column names and dtypes.
        #
        # Init with rows=[] or data=[] (or tuples) is allowed and taken to mean no data.
        # This allows supplying names and dtype if desired. `data=[]` is ambiguous,
        # because it could mean no columns, or it could mean no rows for list of dict.
        # For compatibility with the latter, interpret data=[] as data=None.
        if (
            isinstance(data, np.ndarray) and data.size == 0 and not data.dtype.names
        ) or (isinstance(data, (list, tuple)) and len(data) == 0):
            data = None
    
        if isinstance(data, self.Row):
            data = data._table[data._index : data._index + 1]
    
        if isinstance(data, (list, tuple)):
            # Get column names from `data` if it is a list of dict, otherwise this is None.
            # This might be previously defined if `rows` was supplied as an init arg.
            names_from_list_of_dict = (
                names_from_list_of_dict or _get_names_from_list_of_dict(data)
            )
            if names_from_list_of_dict:
                init_func = self._init_from_list_of_dicts
                n_cols = len(names_from_list_of_dict)
            else:
                init_func = self._init_from_list
                n_cols = len(data)
    
        elif isinstance(data, np.ndarray):
            if data.dtype.names:
>               init_func = self._init_from_ndarray  # _struct
                            ^^^^^^^^^^^^^^^^^^^^^^^
E               AttributeError: 'Table' object has no attribute '_init_from_ndarray'

astropy/table/table.py:822: AttributeError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_names_over_ids - Attribut...
FAILED astropy/io/votable/tests/test_table.py::test_explicit_ids - AttributeE...
FAILED astropy/io/votable/tests/test_table.py::test_empty_table - AttributeEr...
3 failed, 5 passed in 0.33s
```

## 原始行 120 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/ucd.py | sed -n '1,260p'
grep -n \"def _init_from_\" astropy/table/table.py | head -100
nl -ba astropy/table/table.py | sed -n '680,1080p'
grep -RIn \"normalize_capitalization\" astropy/io/votable/tests | head -100"
```

退出码：`0`

输出：
```
     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	"""
     3	This file contains routines to verify the correctness of UCD strings.
     4	"""
     5	
     6	# STDLIB
     7	import re
     8	
     9	# LOCAL
    10	from astropy.utils import data
    11	
    12	__all__ = ["check_ucd", "parse_ucd"]
    13	
    14	
    15	class UCDWords:
    16	    """
    17	    Manages a list of acceptable UCD words.
    18	
    19	    Works by reading in a data file exactly as provided by IVOA.  This
    20	    file resides in data/ucd1p-words.txt.
    21	    """
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	    def get_description(self, name):
    56	        """
    57	        Returns the official English description of the given UCD
    58	        *name*.
    59	        """
    60	        return self._descriptions[name.lower()]
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	_ucd_singleton = None
    70	
    71	
    72	def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
    73	    """
    74	    Parse the UCD into its component parts.
    75	
    76	    Parameters
    77	    ----------
    78	    ucd : str
    79	        The UCD string
    80	
    81	    check_controlled_vocabulary : bool, optional
    82	        If `True`, then each word in the UCD will be verified against
    83	        the UCD1+ controlled vocabulary, (as required by the VOTable
    84	        specification version 1.2), otherwise not.
    85	
    86	    has_colon : bool, optional
    87	        If `True`, the UCD may contain a colon (as defined in earlier
    88	        versions of the standard).
    89	
    90	    Returns
    91	    -------
    92	    parts : list
    93	        The result is a list of tuples of the form:
    94	
    95	            (*namespace*, *word*)
    96	
    97	        If no namespace was explicitly specified, *namespace* will be
    98	        returned as ``'ivoa'`` (i.e., the default namespace).
    99	
   100	    Raises
   101	    ------
   102	    ValueError
   103	        if *ucd* is invalid
   104	    """
   105	    global _ucd_singleton
   106	    if _ucd_singleton is None:
   107	        _ucd_singleton = UCDWords()
   108	
   109	    if has_colon:
   110	        m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
   111	    else:
   112	        m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
   113	    if m is not None:
   114	        raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")
   115	
   116	    word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
   117	    word_re = rf"{word_component_re}(\.{word_component_re})*"
   118	
   119	    parts = ucd.split(";")
   120	    words = []
   121	    for i, word in enumerate(parts):
   122	        colon_count = word.count(":")
   123	        if colon_count == 1:
   124	            ns, word = word.split(":", 1)
   125	            if not re.match(word_component_re, ns):
   126	                raise ValueError(f"Invalid namespace '{ns}'")
   127	            ns = ns.lower()
   128	        elif colon_count > 1:
   129	            raise ValueError(f"Too many colons in '{word}'")
   130	        else:
   131	            ns = "ivoa"
   132	
   133	        if not re.match(word_re, word):
   134	            raise ValueError(f"Invalid word '{word}'")
   135	
   136	        if ns == "ivoa" and check_controlled_vocabulary:
   137	            if i == 0:
   138	                if not _ucd_singleton.is_primary(word):
   139	                    if _ucd_singleton.is_secondary(word):
   140	                        raise ValueError(
   141	                            f"Secondary word '{word}' is not valid as a primary word"
   142	                        )
   143	                    else:
   144	                        raise ValueError(f"Unknown word '{word}'")
   145	            else:
   146	                if not _ucd_singleton.is_secondary(word):
   147	                    if _ucd_singleton.is_primary(word):
   148	                        raise ValueError(
   149	                            f"Primary word '{word}' is not valid as a secondary word"
   150	                        )
   151	                    else:
   152	                        raise ValueError(f"Unknown word '{word}'")
   153	
   154	        try:
   155	            normalized_word = _ucd_singleton.normalize_capitalization(word)
   156	        except KeyError:
   157	            normalized_word = word
   158	        words.append((ns, normalized_word))
   159	
   160	    return words
   161	
   162	
   163	def check_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
   164	    """
   165	    Returns False if *ucd* is not a valid `unified content descriptor`_.
   166	
   167	    Parameters
   168	    ----------
   169	    ucd : str
   170	        The UCD string
   171	
   172	    check_controlled_vocabulary : bool, optional
   173	        If `True`, then each word in the UCD will be verified against
   174	        the UCD1+ controlled vocabulary, (as required by the VOTable
   175	        specification version 1.2), otherwise not.
   176	
   177	    has_colon : bool, optional
   178	        If `True`, the UCD may contain a colon (as defined in earlier
   179	        versions of the standard).
   180	
   181	    Returns
   182	    -------
   183	    valid : bool
   184	    """
   185	    if ucd is None:
   186	        return True
   187	
   188	    try:
   189	        parse_ucd(
   190	            ucd,
   191	            check_controlled_vocabulary=check_controlled_vocabulary,
   192	            has_colon=has_colon,
   193	        )
   194	    except ValueError:
   195	        return False
   196	    return True
1211:    def _init_from_list_of_dicts(self, data, names, dtype, n_cols, copy):
1263:    def _init_from_list(self, data, names, dtype, n_cols, copy):
1455:    def _init_from_dict(self, data, names, dtype, n_cols, copy):
1500:    def _init_from_cols(self, cols):
   680	        if names is not None:
   681	            cols = [col for col in cols if col.info.name in names]
   682	
   683	        for col in cols:
   684	            col_descr = descr(col)
   685	
   686	            if not (col.info.dtype.isnative or keep_byteorder):
   687	                new_dt = np.dtype(col_descr[1]).newbyteorder("=")
   688	                col_descr = (col_descr[0], new_dt, col_descr[2])
   689	
   690	            dtype.append(col_descr)
   691	
   692	        data = empty_init(len(self), dtype=dtype)
   693	        for col in cols:
   694	            # When assigning from one array into a field of a structured array,
   695	            # Numpy will automatically swap those columns to their destination
   696	            # byte order where applicable
   697	            data[col.info.name] = col
   698	
   699	            # For masked out, masked mixin columns need to set output mask attribute.
   700	            if masked and has_info_class(col, MixinInfo) and hasattr(col, "mask"):
   701	                data[col.info.name].mask = col.mask
   702	
   703	            # Propagate the fill_value from the table column to the output array.
   704	            # If this is not done, then the output array will use numpy.ma's default
   705	            # fill values (999999 for ints, 1E20 for floats, "N/A" for strings)
   706	            if masked and hasattr(col, "fill_value"):
   707	                data[col.info.name].fill_value = col.fill_value
   708	
   709	        return data
   710	
   711	    def __init__(
   712	        self,
   713	        data=None,
   714	        masked=False,
   715	        names=None,
   716	        dtype=None,
   717	        meta=None,
   718	        copy=True,
   719	        rows=None,
   720	        copy_indices=True,
   721	        units=None,
   722	        descriptions=None,
   723	        **kwargs,
   724	    ):
   725	        # Set up a placeholder empty table
   726	        self._set_masked(masked)
   727	        self.columns = self.TableColumns()
   728	        self.formatter = self.TableFormatter()
   729	        self._copy_indices = True  # copy indices from this Table by default
   730	        self._init_indices = copy_indices  # whether to copy indices in init
   731	        self.primary_key = None
   732	
   733	        # Must copy if dtype are changing
   734	        if not copy and dtype is not None:
   735	            raise ValueError("Cannot specify dtype when copy=False")
   736	
   737	        # Specifies list of names found for the case of initializing table with
   738	        # a list of dict. If data are not list of dict then this is None.
   739	        names_from_list_of_dict = None
   740	
   741	        # Row-oriented input, e.g. list of lists or list of tuples, list of
   742	        # dict, Row instance.  Set data to something that the subsequent code
   743	        # will parse correctly.
   744	        if rows is not None:
   745	            if data is not None:
   746	                raise ValueError("Cannot supply both `data` and `rows` values")
   747	            if isinstance(rows, types.GeneratorType):
   748	                # Without this then the all(..) test below uses up the generator
   749	                rows = list(rows)
   750	
   751	            # Get column names if `rows` is a list of dict, otherwise this is None
   752	            names_from_list_of_dict = _get_names_from_list_of_dict(rows)
   753	            if names_from_list_of_dict:
   754	                data = rows
   755	            elif isinstance(rows, self.Row) or (
   756	                isinstance(rows, np.ndarray) and rows.dtype.names
   757	            ):
   758	                data = rows
   759	            else:
   760	                data = list(zip(*rows))
   761	
   762	        # Infer the type of the input data and set up the initialization
   763	        # function, number of columns, and potentially the default col names
   764	
   765	        default_names = None
   766	
   767	        # Handle custom (subclass) table attributes that are stored in meta.
   768	        # These are defined as class attributes using the TableAttribute
   769	        # descriptor.  Any such attributes get removed from kwargs here and
   770	        # stored for use after the table is otherwise initialized. Any values
   771	        # provided via kwargs will have precedence over existing values from
   772	        # meta (e.g. from data as a Table or meta via kwargs).
   773	        meta_table_attrs = {}
   774	        if kwargs:
   775	            for attr in list(kwargs):
   776	                descr = getattr(self.__class__, attr, None)
   777	                if isinstance(descr, TableAttribute):
   778	                    meta_table_attrs[attr] = kwargs.pop(attr)
   779	
   780	        if hasattr(data, "__astropy_table__"):
   781	            # Data object implements the __astropy_table__ interface method.
   782	            # Calling that method returns an appropriate instance of
   783	            # self.__class__ and respects the `copy` arg.  The returned
   784	            # Table object should NOT then be copied.
   785	            data = data.__astropy_table__(self.__class__, copy, **kwargs)
   786	            copy = COPY_IF_NEEDED
   787	        elif kwargs:
   788	            raise TypeError(
   789	                f"__init__() got unexpected keyword argument {next(iter(kwargs.keys()))!r}"
   790	            )
   791	
   792	        # Treat any empty numpy array as None, except for structured arrays since they
   793	        # provide column names and dtypes.
   794	        #
   795	        # Init with rows=[] or data=[] (or tuples) is allowed and taken to mean no data.
   796	        # This allows supplying names and dtype if desired. `data=[]` is ambiguous,
   797	        # because it could mean no columns, or it could mean no rows for list of dict.
   798	        # For compatibility with the latter, interpret data=[] as data=None.
   799	        if (
   800	            isinstance(data, np.ndarray) and data.size == 0 and not data.dtype.names
   801	        ) or (isinstance(data, (list, tuple)) and len(data) == 0):
   802	            data = None
   803	
   804	        if isinstance(data, self.Row):
   805	            data = data._table[data._index : data._index + 1]
   806	
   807	        if isinstance(data, (list, tuple)):
   808	            # Get column names from `data` if it is a list of dict, otherwise this is None.
   809	            # This might be previously defined if `rows` was supplied as an init arg.
   810	            names_from_list_of_dict = (
   811	                names_from_list_of_dict or _get_names_from_list_of_dict(data)
   812	            )
   813	            if names_from_list_of_dict:
   814	                init_func = self._init_from_list_of_dicts
   815	                n_cols = len(names_from_list_of_dict)
   816	            else:
   817	                init_func = self._init_from_list
   818	                n_cols = len(data)
   819	
   820	        elif isinstance(data, np.ndarray):
   821	            if data.dtype.names:
   822	                init_func = self._init_from_ndarray  # _struct
   823	                n_cols = len(data.dtype.names)
   824	                default_names = data.dtype.names
   825	            else:
   826	                init_func = self._init_from_ndarray  # _homog
   827	                if data.shape == ():
   828	                    raise ValueError("Can not initialize a Table with a scalar")
   829	                elif len(data.shape) == 1:
   830	                    data = data[np.newaxis, :]
   831	                n_cols = data.shape[1]
   832	
   833	        elif isinstance(data, Mapping):
   834	            init_func = self._init_from_dict
   835	            default_names = list(data)
   836	            n_cols = len(default_names)
   837	
   838	        elif isinstance(data, Table):
   839	            # If user-input meta is None then use data.meta (if non-trivial)
   840	            if meta is None and data.meta:
   841	                # At this point do NOT deepcopy data.meta as this will happen after
   842	                # table init_func() is called.  But for table input the table meta
   843	                # gets a key copy here if copy=False because later a direct object ref
   844	                # is used.
   845	                meta = data.meta if copy else data.meta.copy()
   846	
   847	            # Handle indices on input table. Copy primary key and don't copy indices
   848	            # if the input Table is in non-copy mode.
   849	            self.primary_key = data.primary_key
   850	            self._init_indices = self._init_indices and data._copy_indices
   851	
   852	            # Extract default names, n_cols, and then overwrite ``data`` to be the
   853	            # table columns so we can use _init_from_list.
   854	            default_names = data.colnames
   855	            n_cols = len(default_names)
   856	            data = list(data.columns.values())
   857	
   858	            init_func = self._init_from_list
   859	
   860	        elif data is None:
   861	            if names is None:
   862	                if dtype is None:
   863	                    # Table was initialized as `t = Table()`. Set up for empty
   864	                    # table with names=[], data=[], and n_cols=0.
   865	                    # self._init_from_list() will simply return, giving the
   866	                    # expected empty table.
   867	                    names = []
   868	                else:
   869	                    try:
   870	                        # No data nor names but dtype is available.  This must be
   871	                        # valid to initialize a structured array.
   872	                        dtype = np.dtype(dtype)
   873	                        names = dtype.names
   874	                        dtype = [dtype[name] for name in names]
   875	                    except Exception:
   876	                        raise ValueError(
   877	                            "dtype was specified but could not be "
   878	                            "parsed for column names"
   879	                        )
   880	            # names is guaranteed to be set at this point
   881	            init_func = self._init_from_list
   882	            n_cols = len(names)
   883	            data = [[]] * n_cols
   884	
   885	        else:
   886	            raise ValueError(f"Data type {type(data)} not allowed to init Table")
   887	
   888	        # Set up defaults if names and/or dtype are not specified.
   889	        # A value of None means the actual value will be inferred
   890	        # within the appropriate initialization routine, either from
   891	        # existing specification or auto-generated.
   892	
   893	        if dtype is None:
   894	            dtype = [None] * n_cols
   895	        elif isinstance(dtype, np.dtype):
   896	            if default_names is None:
   897	                default_names = dtype.names
   898	            # Convert a numpy dtype input to a list of dtypes for later use.
   899	            dtype = [dtype[name] for name in dtype.names]
   900	
   901	        if names is None:
   902	            names = default_names or [None] * n_cols
   903	
   904	        names = [None if name is None else str(name) for name in names]
   905	
   906	        self._check_names_dtype(names, dtype, n_cols)
   907	
   908	        # Finally do the real initialization
   909	        init_func(data, names, dtype, n_cols, copy)
   910	
   911	        # Set table meta.  If copy=True then deepcopy meta otherwise use the
   912	        # user-supplied meta directly.
   913	        if meta is not None:
   914	            self.meta = deepcopy(meta) if copy else meta
   915	
   916	        # Update meta with TableAttributes supplied as kwargs in Table init.
   917	        # This takes precedence over previously-defined meta.
   918	        if meta_table_attrs:
   919	            for attr, value in meta_table_attrs.items():
   920	                setattr(self, attr, value)
   921	
   922	        # Whatever happens above, the masked property should be set to a boolean
   923	        if self.masked not in (None, True, False):
   924	            raise TypeError("masked property must be None, True or False")
   925	
   926	        self._set_column_attribute("unit", units)
   927	        self._set_column_attribute("description", descriptions)
   928	
   929	    def _set_column_attribute(self, attr, values):
   930	        """Set ``attr`` for columns to ``values``, which can be either a dict (keyed by column
   931	        name) or a dict of name: value pairs.  This is used for handling the ``units`` and
   932	        ``descriptions`` kwargs to ``__init__``.
   933	        """
   934	        if not values:
   935	            return
   936	
   937	        if isinstance(values, Row):
   938	            # For a Row object transform to an equivalent dict.
   939	            values = {name: values[name] for name in values.colnames}
   940	
   941	        if not isinstance(values, Mapping):
   942	            # If not a dict map, assume iterable and map to dict if the right length
   943	            if len(values) != len(self.columns):
   944	                raise ValueError(
   945	                    f"sequence of {attr} values must match number of columns"
   946	                )
   947	            values = dict(zip(self.colnames, values))
   948	
   949	        for name, value in values.items():
   950	            if name not in self.columns:
   951	                continue
   952	
   953	            # Special case: ignore unit if it is an empty or blank string
   954	            if attr == "unit" and isinstance(value, str):
   955	                if value.strip() == "":
   956	                    value = None
   957	
   958	            if value is not None and value is not np.ma.masked:
   959	                col = self[name]
   960	                if attr == "unit" and isinstance(col, Quantity):
   961	                    # Update the Quantity unit in-place
   962	                    col <<= value
   963	                else:
   964	                    setattr(col.info, attr, value)
   965	
   966	    def __getstate__(self):
   967	        columns = OrderedDict(
   968	            (key, col if isinstance(col, BaseColumn) else col_copy(col))
   969	            for key, col in self.columns.items()
   970	        )
   971	        return (columns, self.meta)
   972	
   973	    def __setstate__(self, state):
   974	        columns, meta = state
   975	        self.__init__(columns, meta=meta)
   976	
   977	    @property
   978	    def mask(self):
   979	        # Dynamic view of available masks
   980	        if self.masked or self.has_masked_columns or self.has_masked_values:
   981	            mask_table = Table(
   982	                [
   983	                    getattr(col, "mask", FalseArray(col.shape))
   984	                    for col in self.itercols()
   985	                ],
   986	                names=self.colnames,
   987	                copy=False,
   988	            )
   989	
   990	            # Set hidden attribute to force inplace setitem so that code like
   991	            # t.mask['a'] = [1, 0, 1] will correctly set the underlying mask.
   992	            # See #5556 for discussion.
   993	            mask_table._setitem_inplace = True
   994	        else:
   995	            mask_table = None
   996	
   997	        return mask_table
   998	
   999	    @mask.setter
  1000	    def mask(self, val):
  1001	        self.mask[:] = val
  1002	
  1003	    @property
  1004	    def _mask(self):
  1005	        """This is needed so that comparison of a masked Table and a
  1006	        MaskedArray works.  The requirement comes from numpy.ma.core
  1007	        so don't remove this property.
  1008	        """
  1009	        return self.as_array().mask
  1010	
  1011	    def filled(self, fill_value=None):
  1012	        """Return copy of self, with masked values filled.
  1013	
  1014	        If input ``fill_value`` supplied then that value is used for all
  1015	        masked entries in the table.  Otherwise the individual
  1016	        ``fill_value`` defined for each table column is used.
  1017	
  1018	        Parameters
  1019	        ----------
  1020	        fill_value : str
  1021	            If supplied, this ``fill_value`` is used for all masked entries
  1022	            in the entire table.
  1023	
  1024	        Returns
  1025	        -------
  1026	        filled_table : `~astropy.table.Table`
  1027	            New table with masked values filled
  1028	        """
  1029	        if self.masked or self.has_masked_columns or self.has_masked_values:
  1030	            # Get new columns with masked values filled, then create Table with those
  1031	            # new cols (copy=False) but deepcopy the meta.
  1032	            data = [
  1033	                col.filled(fill_value) if hasattr(col, "filled") else col
  1034	                for col in self.itercols()
  1035	            ]
  1036	            return self.__class__(data, meta=deepcopy(self.meta), copy=False)
  1037	        else:
  1038	            # Return copy of the original object.
  1039	            return self.copy()
  1040	
  1041	    @property
  1042	    def indices(self) -> TableIndices:
  1043	        """
  1044	        Return the indices associated with columns of the table
  1045	        as a TableIndices object.
  1046	        """
  1047	        lst = []
  1048	        for column in self.columns.values():
  1049	            for index in column.info.indices:
  1050	                if sum(index is x for x in lst) == 0:  # ensure uniqueness
  1051	                    lst.append(index)
  1052	        return TableIndices(lst)
  1053	
  1054	    @property
  1055	    def loc(self) -> TableLoc:
  1056	        """
  1057	        Return a TableLoc object that can be used for retrieving
  1058	        rows by index in a given data range. Note that both loc
  1059	        and iloc work only with single-column indices.
  1060	        """
  1061	        return TableLoc(self)
  1062	
  1063	    @property
  1064	    def loc_indices(self) -> TableLocIndices:
  1065	        """
  1066	        Return a TableLocIndices object that can be used for retrieving
  1067	        the row indices corresponding to given table index key value or values.
  1068	        """
  1069	        return TableLocIndices(self)
  1070	
  1071	    @property
  1072	    def iloc(self) -> TableILoc:
  1073	        """
  1074	        Return a TableILoc object that can be used for retrieving
  1075	        indexed rows in the order they appear in the index.
  1076	        """
  1077	        return TableILoc(self)
  1078	
  1079	    def add_index(self, colnames, engine=None, unique=False):
  1080	        """
```

## 原始行 123 · command_execution

命令：
```
/bin/bash -lc "head -30 astropy/io/votable/data/ucd1p-words.txt
sed -n '30,70p' astropy/io/votable/data/ucd1p-words.txt
sed -n '1,140p' astropy/io/votable/tests/test_ucd.py"
```

退出码：`0`

输出：
```
#EN-UCDlist-v1.6-2024-12-18
Q | arith                             |  Arithmetic quantities
S | arith.diff                        |  Difference between two quantities described by the same UCD
P | arith.factor                      |  Numerical factor
P | arith.grad                        |  Gradient
P | arith.rate                        |  Rate (per time unit)
S | arith.ratio                       |  Ratio between two quantities described by the same UCD
S | arith.squared                     |  Squared quantity
S | arith.sum                         |  Summed or integrated quantity
S | arith.variation                   |  Generic variation of a quantity
Q | arith.zp                          |  Zero point
S | em                                |  Electromagnetic spectrum
S | em.IR                             |  Infrared part of the spectrum
S | em.IR.J                           |  Infrared between 1.0 and 1.5 micron
S | em.IR.H                           |  Infrared between 1.5 and 2 micron
S | em.IR.K                           |  Infrared between 2 and 3 micron
S | em.IR.3-4um                       |  Infrared between 3 and 4 micron
S | em.IR.4-8um                       |  Infrared between 4 and 8 micron
S | em.IR.8-15um                      |  Infrared between 8 and 15 micron
S | em.IR.15-30um                     |  Infrared between 15 and 30 micron
S | em.IR.30-60um                     |  Infrared between 30 and 60 micron
S | em.IR.60-100um                    |  Infrared between 60 and 100 micron
S | em.IR.NIR                         |  Near-Infrared, 1-5 microns
S | em.IR.MIR                         |  Medium-Infrared, 5-30 microns
S | em.IR.FIR                         |  Far-Infrared, 30-100 microns
S | em.UV                             |  Ultraviolet part of the spectrum
S | em.UV.10-50nm                     |  Ultraviolet between 10 and 50 nm EUV extreme UV
S | em.UV.50-100nm                    |  Ultraviolet between 50 and 100 nm
S | em.UV.100-200nm                   |  Ultraviolet between 100 and 200 nm FUV Far UV
S | em.UV.200-300nm                   |  Ultraviolet between 200 and 300 nm NUV near UV
S | em.UV.200-300nm                   |  Ultraviolet between 200 and 300 nm NUV near UV
S | em.X-ray                          |  X-ray part of the spectrum
S | em.X-ray.soft                     |  Soft X-ray (0.12 - 2 keV)
S | em.X-ray.medium                   |  Medium X-ray (2 - 12 keV)
S | em.X-ray.hard                     |  Hard X-ray (12 - 120 keV)
Q | em.bin                            |  Channel / instrumental spectral bin coordinate (bin number)
Q | em.energy                         |  Energy value in the em frame
Q | em.freq                           |  Frequency value in the em frame
Q | em.freq.cutoff                    |  cutoff frequency
Q | em.freq.resonance                 |  resonance frequency
S | em.gamma                          |  Gamma rays part of the spectrum
S | em.gamma.soft                     |  Soft gamma ray (120 - 500 keV)
S | em.gamma.hard                     |  Hard gamma ray (>500 keV)
S | em.line                           |  Designation of major atomic lines
S | em.line.HI                        |  21cm hydrogen line
S | em.line.Lyalpha                   |  H-Lyalpha line
S | em.line.Halpha                    |  H-alpha line
S | em.line.Hbeta                     |  H-beta line
S | em.line.Hgamma                    |  H-gamma line
S | em.line.Hdelta                    |  H-delta line
S | em.line.Brgamma                   |  Bracket gamma line
S | em.line.OIII                      |  [OIII] line whose rest wl is 500.7 nm
S | em.line.CO                        |  CO radio line, e.g., 12CO(1-0) at 115GHz
S | em.mm                             |  Millimetric/submillimetric part of the spectrum
S | em.mm.30-50GHz                    |  Millimetric between 30 and 50 GHz
S | em.mm.50-100GHz                   |  Millimetric between 50 and 100 GHz
S | em.mm.100-200GHz                  |  Millimetric between 100 and 200 GHz
S | em.mm.200-400GHz                  |  Millimetric between 200 and 400 GHz
S | em.mm.400-750GHz                  |  Millimetric between 400 and 750 GHz
S | em.mm.750-1500GHz                 |  Millimetric between 750 and 1500 GHz
S | em.mm.1500-3000GHz                |  Millimetric between 1500 and 3000 GHz
S | em.opt                            |  Optical part of the spectrum
S | em.opt.U                          |  Optical band between 300 and 400 nm
S | em.opt.B                          |  Optical band between 400 and 500 nm
S | em.opt.V                          |  Optical band between 500 and 600 nm
S | em.opt.R                          |  Optical band between 600 and 750 nm
S | em.opt.I                          |  Optical band between 750 and 1000 nm
S | em.pw                             |  Plasma waves (trapped in local medium)
S | em.radio                          |  Radio part of the spectrum
S | em.radio.20MHz                    |  Radio below 20 MHz
S | em.radio.20-100MHz                |  Radio between 20 and 100 MHz
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import pytest

from astropy.io.votable import ucd


def test_none():
    assert ucd.check_ucd(None)


examples = {
    "phys.temperature": [("ivoa", "phys.temperature")],
    "pos.eq.ra;meta.main": [("ivoa", "pos.eq.ra"), ("ivoa", "meta.main")],
    "meta.id;src": [("ivoa", "meta.id"), ("ivoa", "src")],
    "phot.flux;em.radio;arith.ratio": [
        ("ivoa", "phot.flux"),
        ("ivoa", "em.radio"),
        ("ivoa", "arith.ratio"),
    ],
    "PHot.Flux;EM.Radio;ivoa:arith.Ratio": [
        ("ivoa", "phot.flux"),
        ("ivoa", "em.radio"),
        ("ivoa", "arith.ratio"),
    ],
    "pos.galactic.lat": [("ivoa", "pos.galactic.lat")],
    "meta.code;phot.mag": [("ivoa", "meta.code"), ("ivoa", "phot.mag")],
    "stat.error;phot.mag": [("ivoa", "stat.error"), ("ivoa", "phot.mag")],
    "phys.temperature;instr;stat.max": [
        ("ivoa", "phys.temperature"),
        ("ivoa", "instr"),
        ("ivoa", "stat.max"),
    ],
    "stat.error;phot.mag;em.opt.V": [
        ("ivoa", "stat.error"),
        ("ivoa", "phot.mag"),
        ("ivoa", "em.opt.V"),
    ],
    "phot.color;em.opt.B;em.opt.V": [
        ("ivoa", "phot.color"),
        ("ivoa", "em.opt.B"),
        ("ivoa", "em.opt.V"),
    ],
    "stat.error;phot.color;em.opt.B;em.opt.V": [
        ("ivoa", "stat.error"),
        ("ivoa", "phot.color"),
        ("ivoa", "em.opt.B"),
        ("ivoa", "em.opt.V"),
    ],
}


def test_check():
    for s, p in examples.items():
        assert ucd.parse_ucd(s, True, True) == p
        assert ucd.check_ucd(s, True, True)


def test_too_many_colons():
    with pytest.raises(ValueError):
        ucd.parse_ucd("ivoa:stsci:phot", True, True)


def test_invalid_namespace():
    with pytest.raises(ValueError):
        ucd.parse_ucd("_ivoa:phot.mag", True, True)


def test_invalid_word():
    with pytest.raises(ValueError):
        ucd.parse_ucd("-pho")


def test_atmospheric_wind_ucd():
    """Test parsing of atmospheric observation UCDs, specifically obs.atmos.wind.

    This test addresses issue #18452 where obs.atmos.wind and other new
    atmospheric terms from UCD1+ version 1.6 should be recognized.
    """
    # Test the specific case from the issue report
    ucd_string = "phys.veloc;obs.atmos.wind;stat.mean"
    result = ucd.parse_ucd(ucd_string, check_controlled_vocabulary=True)
    expected = [
        ("ivoa", "phys.veloc"),
        ("ivoa", "obs.atmos.wind"),
        ("ivoa", "stat.mean"),
    ]
    assert result == expected

    # Test primary/quantified atmospheric terms (can be used standalone)
    primary_atmos_terms = [
        "obs.atmos.humidity",
        "obs.atmos.rain",
        "obs.atmos.turbulence.isoplanatic",
        "obs.atmos.water",
        "phys.temperature.dew",
    ]

    for term in primary_atmos_terms:
        result = ucd.parse_ucd(term, check_controlled_vocabulary=True)
        assert result == [("ivoa", term)]
        assert ucd.check_ucd(term, check_controlled_vocabulary=True)

    # Test secondary atmospheric terms (must be used with primary terms)
    secondary_atmos_terms = [
        "obs.atmos.wind",
        "obs.atmos.turbulence",
    ]

    for term in secondary_atmos_terms:
        # Test as secondary word (valid)
        combined_ucd = f"phys.temperature;{term}"
        result = ucd.parse_ucd(combined_ucd, check_controlled_vocabulary=True)
        expected = [("ivoa", "phys.temperature"), ("ivoa", term)]
        assert result == expected
        assert ucd.check_ucd(combined_ucd, check_controlled_vocabulary=True)
```

## 原始行 126 · file_change

```
{
  "id": "item_83",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/votable/ucd.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 128 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_ucd.py astropy/io/votable/tests/test_table.py::test_names_over_ids astropy/io/votable/tests/test_table.py::test_explicit_ids astropy/io/votable/tests/test_table.py::test_empty_table -q --disable-warnings --maxfail=5'
```

退出码：`1`

输出：
```
Internet access disabled
.F...F...                                                                [100%]
=================================== FAILURES ===================================
__________________________________ test_check __________________________________

    def test_check():
        for s, p in examples.items():
>           assert ucd.parse_ucd(s, True, True) == p
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_ucd.py:55: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ucd = 'phot.flux;em.radio;arith.ratio', check_controlled_vocabulary = True
has_colon = True

    def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
        """
        Parse the UCD into its component parts.
    
        Parameters
        ----------
        ucd : str
            The UCD string
    
        check_controlled_vocabulary : bool, optional
            If `True`, then each word in the UCD will be verified against
            the UCD1+ controlled vocabulary, (as required by the VOTable
            specification version 1.2), otherwise not.
    
        has_colon : bool, optional
            If `True`, the UCD may contain a colon (as defined in earlier
            versions of the standard).
    
        Returns
        -------
        parts : list
            The result is a list of tuples of the form:
    
                (*namespace*, *word*)
    
            If no namespace was explicitly specified, *namespace* will be
            returned as ``'ivoa'`` (i.e., the default namespace).
    
        Raises
        ------
        ValueError
            if *ucd* is invalid
        """
        global _ucd_singleton
        if _ucd_singleton is None:
            _ucd_singleton = UCDWords()
    
        if has_colon:
            m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
        else:
            m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
        if m is not None:
            raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")
    
        word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
        word_re = rf"{word_component_re}(\.{word_component_re})*"
    
        parts = ucd.split(";")
        words = []
        for i, word in enumerate(parts):
            colon_count = word.count(":")
            if colon_count == 1:
                ns, word = word.split(":", 1)
                if not re.match(word_component_re, ns):
                    raise ValueError(f"Invalid namespace '{ns}'")
                ns = ns.lower()
            elif colon_count > 1:
                raise ValueError(f"Too many colons in '{word}'")
            else:
                ns = "ivoa"
    
            if not re.match(word_re, word):
                raise ValueError(f"Invalid word '{word}'")
    
            if ns == "ivoa" and check_controlled_vocabulary:
                if i == 0:
                    if not _ucd_singleton.is_primary(word):
                        if _ucd_singleton.is_secondary(word):
                            raise ValueError(
                                f"Secondary word '{word}' is not valid as a primary word"
                            )
                        else:
>                           raise ValueError(f"Unknown word '{word}'")
E                           ValueError: Unknown word 'phot.flux'

astropy/io/votable/ucd.py:173: ValueError
__________________________ test_atmospheric_wind_ucd ___________________________

    def test_atmospheric_wind_ucd():
        """Test parsing of atmospheric observation UCDs, specifically obs.atmos.wind.
    
        This test addresses issue #18452 where obs.atmos.wind and other new
        atmospheric terms from UCD1+ version 1.6 should be recognized.
        """
        # Test the specific case from the issue report
        ucd_string = "phys.veloc;obs.atmos.wind;stat.mean"
>       result = ucd.parse_ucd(ucd_string, check_controlled_vocabulary=True)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_ucd.py:82: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

ucd = 'phys.veloc;obs.atmos.wind;stat.mean', check_controlled_vocabulary = True
has_colon = False

    def parse_ucd(ucd, check_controlled_vocabulary=False, has_colon=False):
        """
        Parse the UCD into its component parts.
    
        Parameters
        ----------
        ucd : str
            The UCD string
    
        check_controlled_vocabulary : bool, optional
            If `True`, then each word in the UCD will be verified against
            the UCD1+ controlled vocabulary, (as required by the VOTable
            specification version 1.2), otherwise not.
    
        has_colon : bool, optional
            If `True`, the UCD may contain a colon (as defined in earlier
            versions of the standard).
    
        Returns
        -------
        parts : list
            The result is a list of tuples of the form:
    
                (*namespace*, *word*)
    
            If no namespace was explicitly specified, *namespace* will be
            returned as ``'ivoa'`` (i.e., the default namespace).
    
        Raises
        ------
        ValueError
            if *ucd* is invalid
        """
        global _ucd_singleton
        if _ucd_singleton is None:
            _ucd_singleton = UCDWords()
    
        if has_colon:
            m = re.search(r"[^A-Za-z0-9_.:;\-]", ucd)
        else:
            m = re.search(r"[^A-Za-z0-9_.;\-]", ucd)
        if m is not None:
            raise ValueError(f"UCD has invalid character '{m.group(0)}' in '{ucd}'")
    
        word_component_re = r"[A-Za-z0-9][A-Za-z0-9\-_]*"
        word_re = rf"{word_component_re}(\.{word_component_re})*"
    
        parts = ucd.split(";")
        words = []
        for i, word in enumerate(parts):
            colon_count = word.count(":")
            if colon_count == 1:
                ns, word = word.split(":", 1)
                if not re.match(word_component_re, ns):
                    raise ValueError(f"Invalid namespace '{ns}'")
                ns = ns.lower()
            elif colon_count > 1:
                raise ValueError(f"Too many colons in '{word}'")
            else:
                ns = "ivoa"
    
            if not re.match(word_re, word):
                raise ValueError(f"Invalid word '{word}'")
    
            if ns == "ivoa" and check_controlled_vocabulary:
                if i == 0:
                    if not _ucd_singleton.is_primary(word):
                        if _ucd_singleton.is_secondary(word):
                            raise ValueError(
                                f"Secondary word '{word}' is not valid as a primary word"
                            )
                        else:
>                           raise ValueError(f"Unknown word '{word}'")
E                           ValueError: Unknown word 'phys.veloc'

astropy/io/votable/ucd.py:173: ValueError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_ucd.py::test_check - ValueError: Unknown...
FAILED astropy/io/votable/tests/test_ucd.py::test_atmospheric_wind_ucd - Valu...
2 failed, 7 passed in 0.06s
```

## 原始行 131 · command_execution

命令：
```
/bin/bash -lc "grep -E \"\\| (phot.flux|phys.veloc|obs.atmos.wind|meta.id|em.radio) +\\|\" astropy/io/votable/data/ucd1p-words.txt"
```

退出码：`0`

输出：
```
S | em.radio                          |  Radio part of the spectrum
P | meta.id                           |  Identifier, name or designation
S | obs.atmos.wind                    |  Related to atmospheric wind at observing site
E | phot.flux                         |  Photon flux or irradiance
V | phys.veloc                        |  Space velocity
```

## 原始行 134 · command_execution

命令：
```
/bin/bash -lc "cut -d'|' -f1 astropy/io/votable/data/ucd1p-words.txt | sed 's/ //g' | sort | uniq -c"
```

退出码：`0`

输出：
```
      1 #EN-UCDlist-v1.6-2024-12-18
      1 #ThisfiledistributedunderCC-0bytheIVOA
      1 C
     34 E
     69 P
    309 Q
    149 S
      6 V
```

## 原始行 137 · command_execution

命令：
```
/bin/bash -lc "grep -E \"\\| (phys.temperature|stat.error|phot.mag|meta.code|src +|instr +) +\\|\" astropy/io/votable/data/ucd1p-words.txt"
```

退出码：`0`

输出：
```
Q | instr                             |  Instrument
P | meta.code                         |  Code or flag
E | phot.mag                          |  Photometric magnitude
Q | phys.temperature                  |  Temperature
S | src                               |  Observed source viewed on the sky
P | stat.error                        |  Statistical error
```

## 原始行 140 · file_change

```
{
  "id": "item_92",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/ucd.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 141 · agent_message

```
The conversion path now preserves masks and column metadata without relying on a missing generic ndarray initializer. Focused name/ID and empty-table conversions pass; I’m expanding to the full VOTable test package to catch edge cases in variable arrays, references, and versioned XML output.
```

## 原始行 143 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests -q --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
...........................FF.F.................FFFFFFF
=================================== FAILURES ===================================
___________________________ test_accept_refposition ____________________________

    def test_accept_refposition():
        for ns_version, version, coosys, expected_warnings in [
            ("1.1", "1.1", COOSYS_NO_REFPOSITION, None),
            ("1.2", "1.2", COOSYS_NO_REFPOSITION, W27),
            ("1.3", "1.3", COOSYS_NO_REFPOSITION, None),
            ("1.3", "1.4", COOSYS_NO_REFPOSITION, None),
            ("1.3", "1.5", COOSYS_NO_REFPOSITION, None),
            ("1.1", "1.1", COOSYS_REFPOSITION, W57),
            ("1.2", "1.2", COOSYS_REFPOSITION, (W27, W57)),
            ("1.3", "1.3", COOSYS_REFPOSITION, W57),
            ("1.3", "1.4", COOSYS_REFPOSITION, W57),
            ("1.3", "1.5", COOSYS_REFPOSITION, None),
        ]:
            xml_string = COOSYS_TEMPLATE.format(ns_version, version, coosys)
            input = io.BytesIO(bytes(xml_string, "utf-8"))
            if expected_warnings is not None:
                with pytest.warns(expected_warnings) as record:
                    vot = parse(input, verify="warn")
                # If expected_warnings is a tuple, pytest.warns checked for at least one of the warnings,
                # so make sure we got the right number of them.
                if isinstance(expected_warnings, tuple):
                    assert len(record) == len(expected_warnings)
            else:
>               vot = parse(input, verify="warn")
                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:56: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x75814b3eba60>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
        with _convert_to_fd_or_read_function(source) as fd:
            if _debug_python_based_parser:
                context = _slow_iterparse(fd)
            else:
>               context = _fast_iterparse(fd)
                          ^^^^^^^^^^^^^^^^^^^
E               TypeError: Arg 1 to iterparser must be a file object or callable object

astropy/utils/xml/iterparser.py:188: TypeError
______________________________ test_coosys_system ______________________________

    def test_coosys_system():
        for version, system, expected_warning in [
            ("1.4", "ICRS", None),
            ("1.4", "supergalactic", None),
            ("1.4", "InvalidSystem", E16),
            ("1.5", "ICRS", None),
            ("1.5", "supergalactic", None),
            ("1.5", "InvalidSystem", E16),
        ]:
            xml_string = COOSYS_SYSTEM_TEMPLATE.format(version, system)
            input = io.BytesIO(bytes(xml_string, "utf-8"))
            if expected_warning is not None:
                with pytest.warns(expected_warning):
                    parse(input, verify="warn")
            else:
>               parse(input, verify="warn")

astropy/io/votable/tests/test_coosys.py:74: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x75814b4aaed0>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
        with _convert_to_fd_or_read_function(source) as fd:
            if _debug_python_based_parser:
                context = _slow_iterparse(fd)
            else:
>               context = _fast_iterparse(fd)
                          ^^^^^^^^^^^^^^^^^^^
E               TypeError: Arg 1 to iterparser must be a file object or callable object

astropy/utils/xml/iterparser.py:188: TypeError
____________________________ test_coosys_roundtrip _____________________________

    def test_coosys_roundtrip():
        orig_votable = parse(get_pkg_data_filename("data/coosys.xml"))
        bio = io.BytesIO()
        orig_votable.to_xml(bio)
        bio.seek(0)
>       votable = parse(bio)
                  ^^^^^^^^^^

astropy/io/votable/tests/test_coosys.py:108: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x75814b466250>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
        with _convert_to_fd_or_read_function(source) as fd:
            if _debug_python_based_parser:
                context = _slow_iterparse(fd)
            else:
>               context = _fast_iterparse(fd)
                          ^^^^^^^^^^^^^^^^^^^
E               TypeError: Arg 1 to iterparser must be a file object or callable object

astropy/utils/xml/iterparser.py:188: TypeError
________________________________ test_roundtrip ________________________________

    def test_roundtrip():
        # Issue #16511 VOTable writer does not write out GROUPs within RESOURCEs
    
        # Read the VOTABLE
        votable = parse(get_pkg_data_filename("data/resource_groups.xml"))
    
        bio = io.BytesIO()
        votable.to_xml(bio)
        bio.seek(0)
>       votable = parse(bio)
                  ^^^^^^^^^^

astropy/io/votable/tests/test_resource.py:36: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:161: in parse
    with iterparser.get_xml_iterator(
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

source = <_io.BytesIO object at 0x75814b49c130>
_debug_python_based_parser = False

    @contextlib.contextmanager
    def get_xml_iterator(source, _debug_python_based_parser=False):
        """
        Returns an iterator over the elements of an XML file.
    
        The iterator doesn't ever build a tree, so it is much more memory
        and time efficient than the alternative in ``cElementTree``.
    
        Parameters
        ----------
        source : path-like, :term:`file-like (readable)`, or callable
            Handle that contains the data or function that reads it.
            If a function or callable object, it must directly read from a stream.
            Non-callable objects must define a ``read`` method.
    
        Returns
        -------
        parts : iterator
    
            The iterator returns 4-tuples (*start*, *tag*, *data*, *pos*):
    
                - *start*: when `True` is a start element event, otherwise
                  an end element event.
    
                - *tag*: The name of the element
    
                - *data*: Depends on the value of *event*:
    
                    - if *start* == `True`, data is a dictionary of
                      attributes
    
                    - if *start* == `False`, data is a string containing
                      the text content of the element
    
                - *pos*: Tuple (*line*, *col*) indicating the source of the
                  event.
        """
        with _convert_to_fd_or_read_function(source) as fd:
            if _debug_python_based_parser:
                context = _slow_iterparse(fd)
            else:
>               context = _fast_iterparse(fd)
                          ^^^^^^^^^^^^^^^^^^^
E               TypeError: Arg 1 to iterparser must be a file object or callable object

astropy/utils/xml/iterparser.py:188: TypeError
_ test_schema_versions[/testbed/astropy/io/votable/tests/data/empty_table.xml-1.2-0-None] _

votable_file = '/testbed/astropy/io/votable/tests/data/empty_table.xml'
schema_version = '1.2', expected_return_code = 0, expected_msg_re = None

    @pytest.mark.skipif(sys.platform.startswith("win"), reason="Cannot test on Windows")
    @pytest.mark.parametrize(
        "votable_file,schema_version,expected_return_code,expected_msg_re", test_cases
    )
    def test_schema_versions(
        votable_file, schema_version, expected_return_code, expected_msg_re
    ):
        """Test that xmllint gives expected results for the given file and schema version."""
        try:
>           rc, stdout, stderr = validate_schema(votable_file, schema_version)
                                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_schema_versions.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

filename = '/testbed/astropy/io/votable/tests/data/empty_table.xml'
version = '1.2'

    def validate_schema(filename, version="1.1"):
        """
        Validates the given file against the appropriate VOTable schema.
    
        Parameters
        ----------
        filename : str
            The path to the XML file to validate
    
        version : str, optional
            The VOTABLE version to check, which must be a string \"1.0\",
            \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
            version \"1.1\" is assumed.
    
            For version \"1.0\", it is checked against a DTD, since that
            version did not have an XML Schema.
    
        Returns
        -------
        returncode, stdout, stderr : int, str, str
            Returns the returncode from xmllint and the stdout and stderr
            as strings
        """
        supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]
    
        if version == "1.0":
            schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
        else:
            if version not in supported_schemas:
                log.info(f"{filename} has version {version}, using schema 1.1")
                version = "1.1"
            schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")
    
>       return validate.validate_schema(filename, schema_path)
               ^^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.validate' has no attribute 'validate_schema'

astropy/io/votable/xmlutil.py:125: AttributeError
_ test_schema_versions[/testbed/astropy/io/votable/tests/data/empty_table.xml-1.3-3-No matching global declaration available for the validation root] _

votable_file = '/testbed/astropy/io/votable/tests/data/empty_table.xml'
schema_version = '1.3', expected_return_code = 3
expected_msg_re = b'No matching global declaration available for the validation root'

    @pytest.mark.skipif(sys.platform.startswith("win"), reason="Cannot test on Windows")
    @pytest.mark.parametrize(
        "votable_file,schema_version,expected_return_code,expected_msg_re", test_cases
    )
    def test_schema_versions(
        votable_file, schema_version, expected_return_code, expected_msg_re
    ):
        """Test that xmllint gives expected results for the given file and schema version."""
        try:
>           rc, stdout, stderr = validate_schema(votable_file, schema_version)
                                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_schema_versions.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

filename = '/testbed/astropy/io/votable/tests/data/empty_table.xml'
version = '1.3'

    def validate_schema(filename, version="1.1"):
        """
        Validates the given file against the appropriate VOTable schema.
    
        Parameters
        ----------
        filename : str
            The path to the XML file to validate
    
        version : str, optional
            The VOTABLE version to check, which must be a string \"1.0\",
            \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
            version \"1.1\" is assumed.
    
            For version \"1.0\", it is checked against a DTD, since that
            version did not have an XML Schema.
    
        Returns
        -------
        returncode, stdout, stderr : int, str, str
            Returns the returncode from xmllint and the stdout and stderr
            as strings
        """
        supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]
    
        if version == "1.0":
            schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
        else:
            if version not in supported_schemas:
                log.info(f"{filename} has version {version}, using schema 1.1")
                version = "1.1"
            schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")
    
>       return validate.validate_schema(filename, schema_path)
               ^^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.validate' has no attribute 'validate_schema'

astropy/io/votable/xmlutil.py:125: AttributeError
_ test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.3-0-None] _

votable_file = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
schema_version = '1.3', expected_return_code = 0, expected_msg_re = None

    @pytest.mark.skipif(sys.platform.startswith("win"), reason="Cannot test on Windows")
    @pytest.mark.parametrize(
        "votable_file,schema_version,expected_return_code,expected_msg_re", test_cases
    )
    def test_schema_versions(
        votable_file, schema_version, expected_return_code, expected_msg_re
    ):
        """Test that xmllint gives expected results for the given file and schema version."""
        try:
>           rc, stdout, stderr = validate_schema(votable_file, schema_version)
                                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_schema_versions.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

filename = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
version = '1.3'

    def validate_schema(filename, version="1.1"):
        """
        Validates the given file against the appropriate VOTable schema.
    
        Parameters
        ----------
        filename : str
            The path to the XML file to validate
    
        version : str, optional
            The VOTABLE version to check, which must be a string \"1.0\",
            \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
            version \"1.1\" is assumed.
    
            For version \"1.0\", it is checked against a DTD, since that
            version did not have an XML Schema.
    
        Returns
        -------
        returncode, stdout, stderr : int, str, str
            Returns the returncode from xmllint and the stdout and stderr
            as strings
        """
        supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]
    
        if version == "1.0":
            schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
        else:
            if version not in supported_schemas:
                log.info(f"{filename} has version {version}, using schema 1.1")
                version = "1.1"
            schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")
    
>       return validate.validate_schema(filename, schema_path)
               ^^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.validate' has no attribute 'validate_schema'

astropy/io/votable/xmlutil.py:125: AttributeError
_ test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.4-0-None] _

votable_file = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
schema_version = '1.4', expected_return_code = 0, expected_msg_re = None

    @pytest.mark.skipif(sys.platform.startswith("win"), reason="Cannot test on Windows")
    @pytest.mark.parametrize(
        "votable_file,schema_version,expected_return_code,expected_msg_re", test_cases
    )
    def test_schema_versions(
        votable_file, schema_version, expected_return_code, expected_msg_re
    ):
        """Test that xmllint gives expected results for the given file and schema version."""
        try:
>           rc, stdout, stderr = validate_schema(votable_file, schema_version)
                                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_schema_versions.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

filename = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
version = '1.4'

    def validate_schema(filename, version="1.1"):
        """
        Validates the given file against the appropriate VOTable schema.
    
        Parameters
        ----------
        filename : str
            The path to the XML file to validate
    
        version : str, optional
            The VOTABLE version to check, which must be a string \"1.0\",
            \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
            version \"1.1\" is assumed.
    
            For version \"1.0\", it is checked against a DTD, since that
            version did not have an XML Schema.
    
        Returns
        -------
        returncode, stdout, stderr : int, str, str
            Returns the returncode from xmllint and the stdout and stderr
            as strings
        """
        supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]
    
        if version == "1.0":
            schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
        else:
            if version not in supported_schemas:
                log.info(f"{filename} has version {version}, using schema 1.1")
                version = "1.1"
            schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")
    
>       return validate.validate_schema(filename, schema_path)
               ^^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.validate' has no attribute 'validate_schema'

astropy/io/votable/xmlutil.py:125: AttributeError
_ test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.5-0-None] _

votable_file = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
schema_version = '1.5', expected_return_code = 0, expected_msg_re = None

    @pytest.mark.skipif(sys.platform.startswith("win"), reason="Cannot test on Windows")
    @pytest.mark.parametrize(
        "votable_file,schema_version,expected_return_code,expected_msg_re", test_cases
    )
    def test_schema_versions(
        votable_file, schema_version, expected_return_code, expected_msg_re
    ):
        """Test that xmllint gives expected results for the given file and schema version."""
        try:
>           rc, stdout, stderr = validate_schema(votable_file, schema_version)
                                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_schema_versions.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

filename = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
version = '1.5'

    def validate_schema(filename, version="1.1"):
        """
        Validates the given file against the appropriate VOTable schema.
    
        Parameters
        ----------
        filename : str
            The path to the XML file to validate
    
        version : str, optional
            The VOTABLE version to check, which must be a string \"1.0\",
            \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
            version \"1.1\" is assumed.
    
            For version \"1.0\", it is checked against a DTD, since that
            version did not have an XML Schema.
    
        Returns
        -------
        returncode, stdout, stderr : int, str, str
            Returns the returncode from xmllint and the stdout and stderr
            as strings
        """
        supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]
    
        if version == "1.0":
            schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
        else:
            if version not in supported_schemas:
                log.info(f"{filename} has version {version}, using schema 1.1")
                version = "1.1"
            schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")
    
>       return validate.validate_schema(filename, schema_path)
               ^^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.validate' has no attribute 'validate_schema'

astropy/io/votable/xmlutil.py:125: AttributeError
_ test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.6-3-No matching global declaration available for the validation root] _

votable_file = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
schema_version = '1.6', expected_return_code = 3
expected_msg_re = b'No matching global declaration available for the validation root'

    @pytest.mark.skipif(sys.platform.startswith("win"), reason="Cannot test on Windows")
    @pytest.mark.parametrize(
        "votable_file,schema_version,expected_return_code,expected_msg_re", test_cases
    )
    def test_schema_versions(
        votable_file, schema_version, expected_return_code, expected_msg_re
    ):
        """Test that xmllint gives expected results for the given file and schema version."""
        try:
>           rc, stdout, stderr = validate_schema(votable_file, schema_version)
                                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_schema_versions.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

filename = '/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml'
version = '1.1'

    def validate_schema(filename, version="1.1"):
        """
        Validates the given file against the appropriate VOTable schema.
    
        Parameters
        ----------
        filename : str
            The path to the XML file to validate
    
        version : str, optional
            The VOTABLE version to check, which must be a string \"1.0\",
            \"1.1\", \"1.2\" or \"1.3\".  If it is not one of these,
            version \"1.1\" is assumed.
    
            For version \"1.0\", it is checked against a DTD, since that
            version did not have an XML Schema.
    
        Returns
        -------
        returncode, stdout, stderr : int, str, str
            Returns the returncode from xmllint and the stdout and stderr
            as strings
        """
        supported_schemas = ["1.1", "1.2", "1.3", "1.4", "1.5"]
    
        if version == "1.0":
            schema_path = data.get_pkg_data_filename("data/VOTable.dtd")
        else:
            if version not in supported_schemas:
                log.info(f"{filename} has version {version}, using schema 1.1")
                version = "1.1"
            schema_path = data.get_pkg_data_filename(f"data/VOTable.v{version}.xsd")
    
>       return validate.validate_schema(filename, schema_path)
               ^^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: module 'astropy.utils.xml.validate' has no attribute 'validate_schema'

astropy/io/votable/xmlutil.py:125: AttributeError
----------------------------- Captured stdout call -----------------------------
INFO: /testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml has version 1.6, using schema 1.1 [astropy.io.votable.xmlutil]
------------------------------ Captured log call -------------------------------
INFO     astropy:xmlutil.py:121 /testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml has version 1.6, using schema 1.1
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_coosys.py::test_accept_refposition - Typ...
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_system - TypeErro...
FAILED astropy/io/votable/tests/test_coosys.py::test_coosys_roundtrip - TypeE...
FAILED astropy/io/votable/tests/test_resource.py::test_roundtrip - TypeError:...
FAILED astropy/io/votable/tests/test_schema_versions.py::test_schema_versions[/testbed/astropy/io/votable/tests/data/empty_table.xml-1.2-0-None]
FAILED astropy/io/votable/tests/test_schema_versions.py::test_schema_versions[/testbed/astropy/io/votable/tests/data/empty_table.xml-1.3-3-No matching global declaration available for the validation root]
FAILED astropy/io/votable/tests/test_schema_versions.py::test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.3-0-None]
FAILED astropy/io/votable/tests/test_schema_versions.py::test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.4-0-None]
FAILED astropy/io/votable/tests/test_schema_versions.py::test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.5-0-None]
FAILED astropy/io/votable/tests/test_schema_versions.py::test_schema_versions[/testbed/astropy/io/votable/tests/data/binary2_masked_strings.xml-1.6-3-No matching global declaration available for the validation root]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 10 failures !!!!!!!!!!!!!!!!!!!!!!!!!!
10 failed, 45 passed in 0.23s
```

## 原始行 146 · file_change

```
{
  "id": "item_96",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/iterparser.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 149 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_table.py -q --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
..F........ssssF.......FValidation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W50: Invalid unit string 'km/h'
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W50: Invalid unit string 'deg'
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W50: Invalid unit string 'deg'
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W50: Invalid unit string 'deg'
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.F...F........Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

7: W50: Invalid unit string 'm'
      <PARAM name="Telescope" datatype="float" ucd="phys.size;instr...
      ^

9: W50: Invalid unit string 'deg'
      <FIELD name="RA"   ID="col1" ucd="pos.eq.ra;meta.main"
      ^

11: W50: Invalid unit string 'deg'
      <FIELD name="Dec"  ID="col2" ucd="pos.eq.dec;meta.main"
      ^

15: W50: Invalid unit string 'km/s'
      <FIELD name="RVel" ID="col4" ucd="spect.dopplerVeloc" datatyp...
      ^

17: W50: Invalid unit string 'km/s'
      <FIELD name="e_RVel" ID="col5" ucd="stat.error;spect.dopplerV...
      ^

19: W50: Invalid unit string 'Mpc'
      <FIELD name="R" ID="col6" ucd="pos.distance;pos.heliocentric"
      ^

....F..F.                          [100%]
=================================== FAILURES ===================================
______________________ test_read_through_table_interface _______________________

self = <astropy.io.votable.converters.Bit object at 0x791f2bc653d0>
value = '101101'
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (79, 10)

    def parse(self, value, config=None, pos=None):
        if config is None:
            config = {}
        mapping = {"1": True, "0": False}
        if value is False or value.strip() == "":
            if not config["version_1_3_or_later"]:
                warn_or_raise(W49, W49, (), config, pos)
            return False, True
        else:
            try:
>               return mapping[value], False
                       ^^^^^^^^^^^^^^
E               KeyError: '101101'

astropy/io/votable/converters.py:1180: KeyError

During handling of the above exception, another exception occurred:

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_read_through_table_interf0')

    def test_read_through_table_interface(tmp_path):
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
                t = Table.read(fd, format="votable", table_id="main_table")
    
        assert len(t) == 5
    
        # Issue 8354
        assert t["float"].format is None
    
        fn = tmp_path / "table_interface.xml"
    
        # W39: Bit values can not be masked
        with pytest.warns(W39):
            t.write(fn, table_id="FOO", format="votable")
    
        with open(fn, "rb") as fd:
>           t2 = Table.read(fd, format="votable", table_id="FOO")
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:147: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:62: in __call__
    out = self.registry.read(cls, *args, **kwargs)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/registry/core.py:221: in read
    data = reader(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:88: in read_table_votable
    input = parse(input, table_id=table_id, verify=verify, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4509: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4373: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4141: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4083: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:3001: in parse
    self.array = self._parse_tabledata(iterator, colnumbers, config)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:3128: in _parse_tabledata
    vo_reraise(e, config, pos)
astropy/io/votable/exceptions.py:176: in vo_reraise
    raise exc
astropy/io/votable/tree.py:3117: in _parse_tabledata
    vo_reraise(
astropy/io/votable/exceptions.py:176: in vo_reraise
    raise exc
astropy/io/votable/tree.py:3113: in _parse_tabledata
    value, mask_value = parsers[i](
astropy/io/votable/converters.py:662: in parse
    return self.parse_parts(parts, config, pos)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:669: in parse_parts
    value, mask = base_parse(x, config, pos)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:1182: in parse
    vo_raise(E04, (value,), config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E04'>
args = ('101101',)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (79, 10)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E04: 79:10: E04: Invalid bit value '101101'

astropy/io/votable/exceptions.py:158: E04
____________________________ test_write_jybeam_unit ____________________________

cls = <class 'astropy.units.core.Unit'>, s = 'Crab', represents = None
format = 'ogip', namespace = None, doc = None, parse_strict = 'raise'

    def __call__(
        cls,
        s="",
        represents=None,
        format=None,
        namespace=None,
        doc=None,
        parse_strict="raise",
    ):
        # Short-circuit if we're already a unit
        if hasattr(s, "_physical_type_id"):
            return s
    
        if represents is not None:
            # This has the effect of calling the real __new__ and
            # __init__ on the Unit class.
            return super().__call__(
                s, represents, format=format, namespace=namespace, doc=doc
            )
    
        if isinstance(s, (str, bytes)):
            if len(s.strip()) == 0:
                # Return the NULL unit
                return dimensionless_unscaled
    
            from .format import Generic, get_format
    
            try:
                f = get_format(format)
            except (TypeError, ValueError) as err:
                from .format import known_parsers
    
                err.add_note(known_parsers())
                raise err
            if isinstance(s, bytes):
                s = s.decode("ascii")
    
            try:
                return f._validate_unit(s)  # Try a shortcut
            except (AttributeError, KeyError):
                # No `f._validate_unit()` (AttributeError)
                # or `s` was a composite unit (KeyError).
                pass
    
            try:
                with (
                    _WARNING_LOCK,
                    warnings.catch_warnings(
                        action=_WARNING_ACTIONS[parse_strict],
                        category=UnitParserWarning,
                    ),
                ):
>                   return f.parse(s)
                           ^^^^^^^^^^

astropy/units/core.py:2070: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/units/format/ogip.py:308: in parse
    return cls._do_parse(s.strip(), debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/base.py:225: in _do_parse
    return cls._parser.parse(s, lexer=cls._lexer, debug=debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/utils/parsing.py:109: in parse
    return self.parser.parse(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:333: in parse
    return self.parseopt_notrack(input, lexer, debug, tracking, tokenfunc)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:1063: in parseopt_notrack
    lookahead = get_token()     # Get the next token
                ^^^^^^^^^^^
astropy/extern/ply/lex.py:350: in token
    newtok = func(tok)
             ^^^^^^^^^
astropy/units/format/ogip.py:132: in t_UNIT
    t.value = cls._get_unit(t)
              ^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.ogip.OGIP'>, t = LexToken(UNIT,'Crab',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
>           return cls._validate_unit(t.value)
                   ^^^^^^^^^^^^^^^^^^
E           AttributeError: type object 'OGIP' has no attribute '_validate_unit'

astropy/units/format/base.py:235: AttributeError

During handling of the above exception, another exception occurred:

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_write_jybeam_unit0')
recwarn = WarningsRecorder(record=True)

    def test_write_jybeam_unit(tmp_path, recwarn):
        t = Table(
            {
                "flux": [5 * (u.Jy / u.beam)],
>               "foo": [0 * u.Unit("Crab", format="ogip")],
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
                "bar": [1 * u.def_unit("my_unit")],
            }
        )

astropy/io/votable/tests/test_table.py:359: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.core.Unit'>, s = 'Crab', represents = None
format = 'ogip', namespace = None, doc = None, parse_strict = 'raise'

    def __call__(
        cls,
        s="",
        represents=None,
        format=None,
        namespace=None,
        doc=None,
        parse_strict="raise",
    ):
        # Short-circuit if we're already a unit
        if hasattr(s, "_physical_type_id"):
            return s
    
        if represents is not None:
            # This has the effect of calling the real __new__ and
            # __init__ on the Unit class.
            return super().__call__(
                s, represents, format=format, namespace=namespace, doc=doc
            )
    
        if isinstance(s, (str, bytes)):
            if len(s.strip()) == 0:
                # Return the NULL unit
                return dimensionless_unscaled
    
            from .format import Generic, get_format
    
            try:
                f = get_format(format)
            except (TypeError, ValueError) as err:
                from .format import known_parsers
    
                err.add_note(known_parsers())
                raise err
            if isinstance(s, bytes):
                s = s.decode("ascii")
    
            try:
                return f._validate_unit(s)  # Try a shortcut
            except (AttributeError, KeyError):
                # No `f._validate_unit()` (AttributeError)
                # or `s` was a composite unit (KeyError).
                pass
    
            try:
                with (
                    _WARNING_LOCK,
                    warnings.catch_warnings(
                        action=_WARNING_ACTIONS[parse_strict],
                        category=UnitParserWarning,
                    ),
                ):
                    return f.parse(s)
            except NotImplementedError:
                raise
            except UnitParserWarning as err:
                new_err = ValueError(err)
                new_err.add_note(
                    "If you cannot change the unit string then try specifying the "
                    "'parse_strict' argument."
                )
                raise new_err from err
            except KeyError as err:
                if parse_strict in _WARNING_ACTIONS:
                    raise
                raise ValueError(
                    "'parse_strict' must be 'warn', 'raise' or 'silent'"
                ) from None
            except Exception as e:
                if parse_strict != "silent":
                    # Deliberately not issubclass here. Subclasses
                    # should use their name.
                    format_clause = "" if f is Generic else f.name + " "
                    msg = (
                        f"'{s}' did not parse as {format_clause}unit: {str(e)} "
                        "If this is meant to be a custom unit, "
                        "define it with 'u.def_unit'. To have it "
                        "recognized inside a file reader or other code, "
                        "enable it with 'u.add_enabled_units'. "
                        "For details, see "
                        "https://docs.astropy.org/en/latest/units/combining_and_defining.html"
                    )
                    if parse_strict == "raise":
>                       raise ValueError(msg)
E                       ValueError: 'Crab' did not parse as ogip unit: type object 'OGIP' has no attribute '_validate_unit' If this is meant to be a custom unit, define it with 'u.def_unit'. To have it recognized inside a file reader or other code, enable it with 'u.add_enabled_units'. For details, see https://docs.astropy.org/en/latest/units/combining_and_defining.html

astropy/units/core.py:2101: ValueError
_________________________ test_binary2_masked_strings __________________________

    def test_binary2_masked_strings():
        """
        Issue #8995.
        """
        # Read a VOTable which sets the null mask bit for each empty string value.
        votable = parse(get_pkg_data_filename("data/binary2_masked_strings.xml"))
        table = votable.get_first_table()
        astropy_table = table.to_table()
    
        # Ensure string columns have no masked values and can be written out
        assert not np.any(table.array.mask["epoch_photometry_url"])
        output = io.BytesIO()
>       astropy_table.write(output, format="votable")

astropy/io/votable/tests/test_table.py:478: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:130: in __call__
    self.registry.write(instance, *args, **kwargs)
astropy/io/registry/core.py:386: in write
    return writer(data, *args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:173: in write_table_votable
    table_file = from_table(input, table_id=table_id)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/table.py:372: in from_table
    return tree.VOTableFile.from_table(table, table_id=table_id)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4836: in from_table
    votable = TableElement.from_table(votable_file, table)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:3664: in from_table
    new_table.add_field(Field.from_table_column(votable, column))
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1799: in from_table_column
    field = cls(votable, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1453: in __init__
    self.unit = unit
    ^^^^^^^^^
astropy/io/votable/tree.py:1618: in unit
    warn_or_raise(W50, W50, (unit,), self._config, self._pos)
astropy/io/votable/exceptions.py:149: in warn_or_raise
    vo_warn(warning_class, args, config, pos, stacklevel=stacklevel + 1)
astropy/io/votable/exceptions.py:190: in vo_warn
    _suppressed_warning(warning, config, stacklevel=stacklevel + 1)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

warning = W50("?:?: W50: Invalid unit string 'deg'")
config = {'_warning_counts': {<class 'astropy.io.votable.exceptions.W50'>: 1}, 'version': '1.4', 'version_1_1_or_later': True, 'version_1_2_or_later': True, ...}
stacklevel = 3

    def _suppressed_warning(warning, config=None, stacklevel=1):
        """Emit repeated warnings up to the configured per-type limit."""
        if config is None:
            config = {}
        counts = config.setdefault("_warning_counts", {})
        warning_type = type(warning)
        count = counts.get(warning_type, 0) + 1
        counts[warning_type] = count
    
        if count > conf.max_warnings:
            return
        if count == conf.max_warnings:
            warning.formatted_message += (
                " (suppressing further warnings of this type...)"
            )
            warning.args = (warning.formatted_message,)
>       warn(warning, stacklevel=stacklevel + 1)
E       astropy.io.votable.exceptions.W50: ?:?: W50: Invalid unit string 'deg'

astropy/io/votable/exceptions.py:107: W50
__________________________ test_validate_output_valid __________________________

    def test_validate_output_valid():
        """
        Issue #12603. Test that we get the correct output from votable.validate with a valid
        votable.
        """
        # A valid votable. (Example from the votable standard:
        # https://www.ivoa.net/documents/VOTable/20191021/REC-VOTable-1.4-20191021.html )
        valid_votable_filepath = get_pkg_data_filename("data/valid_votable.xml")
    
        # When output is None, check that validate returns validation output as a string
        validate_out = validate(valid_votable_filepath, output=None)
        assert isinstance(validate_out, str)
        # Check for known good output string
>       assert "astropy.io.votable found no violations" in validate_out
E       assert 'astropy.io.votable found no violations' in 'Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml\n\n7: W50: Invalid unit string \'m\'\n...19: W50: Invalid unit string \'Mpc\'\n      <FIELD name="R" ID="col6" ucd="pos.distance;pos.heliocentric"\n      ^\n\n'

astropy/io/votable/tests/test_table.py:515: AssertionError
_____________________ test_binary2_char_fields_vizier_data _____________________

    def test_binary2_char_fields_vizier_data():
        """
        Test parsing a VOTable from a Vizier query which includes bounded
        variable-length char arrays (e.g., arraysize="7*").
    
        Related astropy issue:
        https://github.com/astropy/astropy/issues/8737
        """
        sample_file = get_pkg_data_filename("data/vizier_b2_votable.xml")
    
        votable = parse(sample_file)
        table = votable.get_first_table()
    
        assert table.fields[7].ID == "CS"
        assert table.fields[7].arraysize == "7*"
        assert table.fields[8].ID == "Morph"
        assert table.fields[8].arraysize == "7*"
    
        assert table.array[0]["CS"] == ""
    
        bio = io.BytesIO()
        table.format = "binary2"
        votable.version = "1.3"
        table._config["version_1_3_or_later"] = True
>       votable.to_xml(bio)

astropy/io/votable/tests/test_table.py:679: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/tree.py:4604: in to_xml
    element.to_xml(w, **kwargs)
astropy/io/votable/tree.py:4183: in to_xml
    elm.to_xml(w, **kwargs)
astropy/io/votable/tree.py:3445: in to_xml
    element.to_xml(w, **kwargs)
astropy/io/votable/tree.py:1733: in to_xml
    attrib["unit"] = self.unit.to_string(format)
                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/core.py:206: in to_string
    return formatter.to_string(self, deprecations=deprecations, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/vounit.py:205: in to_string
    unit = cls._decompose_to_known_units(unit, deprecations)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.vounit.VOUnit'>, unit = Unit(dimensionless)
deprecations = 'warn'

    @classmethod
    def _decompose_to_known_units(
        cls,
        unit: CompositeUnit | NamedUnit,
        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
    ) -> UnitBase:
        # The da- and d- prefixes are discouraged.  This has the
        # effect of adding a scale to value in the result.
        if isinstance(unit, PrefixUnit) and unit._represents.scale in (0.1, 10.0):
            return cls._decompose_to_known_units(unit._represents)
        if (
            isinstance(unit, NamedUnit)
            and unit._get_format_name(cls.name) in cls._custom_units
        ):
            return unit
>       return super()._decompose_to_known_units(unit, deprecations)
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: 'super' object has no attribute '_decompose_to_known_units'

astropy/units/format/vounit.py:143: AttributeError
______________________ TestVerifyOptions.test_verify_warn ______________________

self = <astropy.io.votable.tests.test_table.TestVerifyOptions object at 0x791f2bd60e10>

    def test_verify_warn(self):
        with pytest.warns(VOWarning) as w:
            parse(get_pkg_data_filename("data/gemini.xml"), verify="warn")
>       assert len(w) == 24
E       assert 34 == 24
E        +  where 34 = len(WarningsChecker(record=True))

astropy/io/votable/tests/test_table.py:975: AssertionError
___________________ TestVerifyOptions.test_conf_verify_warn ____________________

self = <astropy.io.votable.tests.test_table.TestVerifyOptions object at 0x791f2bd62110>

    def test_conf_verify_warn(self):
        with conf.set_temp("verify", "warn"):
            with pytest.warns(VOWarning) as w:
                parse(get_pkg_data_filename("data/gemini.xml"))
>           assert len(w) == 24
E           assert 34 == 24
E            +  where 34 = len(WarningsChecker(record=True))

astropy/io/votable/tests/test_table.py:991: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_read_through_table_interface
FAILED astropy/io/votable/tests/test_table.py::test_write_jybeam_unit - Value...
FAILED astropy/io/votable/tests/test_table.py::test_binary2_masked_strings - ...
FAILED astropy/io/votable/tests/test_table.py::test_validate_output_valid - a...
FAILED astropy/io/votable/tests/test_table.py::test_binary2_char_fields_vizier_data
FAILED astropy/io/votable/tests/test_table.py::TestVerifyOptions::test_verify_warn
FAILED astropy/io/votable/tests/test_table.py::TestVerifyOptions::test_conf_verify_warn
7 failed, 36 passed, 4 skipped in 0.62s
```

## 原始行 152 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import io
import numpy as np
from astropy.io.votable.table import parse
from astropy.utils.data import get_pkg_data_filename
from astropy.table import Table
v=parse(get_pkg_data_filename('astropy/io/votable/tests/data/regression.xml'))
t=v.get_first_table().to_table()
for name in ('bit','bitarray','bitvararray','bitvararray2'):
 c=t[name]
 print(name, c.dtype, c.shape, c[0], c.info.meta)
out=io.BytesIO()
t.write(out, format='votable', table_id='FOO')
s=out.getvalue().decode()
for line in s.splitlines():
 if 'ID=\"bit' in line:
  print(line)
PY"
```

退出码：`0`

输出：
```
WARNING: W39: ?:?: W39: Bit values can not be masked [astropy.io.votable.converters]
bit bool (5,) True {}
bitarray bool (5, 3, 2) [[True False]
 [True True]
 [False True]] {}
bitvararray object (5,) [True True True] {}
bitvararray2 object (5,) [] {}
   <FIELD ID="bit" datatype="bit" name="bit"/>
   <FIELD ID="bitarray" arraysize="3x2" datatype="bit" name="bitarray"/>
   <FIELD ID="bitvararray" arraysize="*" datatype="bit" name="bitvararray"/>
   <FIELD ID="bitvararray2" arraysize="3x2*" datatype="bit" name="bitvararray2"/>
   <FIELD ID="bitarray2" arraysize="16" datatype="bit" name="bitarray2"/>
```

## 原始行 155 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.votable.table import parse
from astropy.io.votable.tree import ParamRef, Field, Param, Resource, TableElement, Group, VOTableFile
from astropy.utils.data import get_pkg_data_filename
v=parse(get_pkg_data_filename('astropy/io/votable/tests/data/regression.xml'))
refs=[]
for resource in v.resources:
 for group in resource.groups:
  refs += [x for x in group.entries if isinstance(x, ParamRef)]
for table in v.iter_tables():
 for group in table.groups:
  refs += [x for x in group.entries if isinstance(x, ParamRef)]
print('refs', [(x.ref, x.get_ref().ID, x.get_ref().name) for x in refs])
print('repr', repr(v))
print('tables', len(list(v.iter_tables())), v.get_first_table().ID)
vals=list(v.iter_values())
print('values',len(vals), 'fieldsparams',len(list(v.iter_fields_and_params())), 'ids', [x.ID for x in vals if x.ID][:5])
# same-ID Field before Param still returns Param and forward refs resolve
v2=VOTableFile(); r=Resource(); v2.resources.append(r); t=TableElement(v2); r.tables.append(t)
f=Field(v2, ID='same', name='f', datatype='int'); p=Param(v2, ID='same', name='p', datatype='int', value='1')
t.add_field(f); t.params.append(p)
pr=ParamRef(t, 'same')
print('param identity', pr.get_ref() is p)
PY"
```

退出码：`0`

输出：
```
refs [('awesome', 'awesome', 'INPUT'), ('awesome', 'awesome', 'INPUT'), ('awesome', 'awesome', 'INPUT')]
repr <VOTABLE>... 3 tables ...</VOTABLE>
tables 3 main_table
values 100 fieldsparams 100 ids ['int_nulls', 'int_nulls', 'int_nulls']
param identity True
```

## 原始行 158 · command_execution

命令：
```
/bin/bash -lc "sed -n '300,345p' astropy/io/votable/tests/test_converter.py
sed -n '520,560p' astropy/io/votable/tests/test_table.py
grep -RIn \"from_table(.*to_table\\|from_table\" astropy/io/votable/tests/test_*.py | head -100"
```

退出码：`0`

输出：
```
    resource = tree.Resource()
    votable.resources.append(resource)
    table = tree.TableElement(votable)
    resource.tables.append(table)

    tabarr = []
    heads = ["headA", "headB", "headC"]
    types = ["char", "double", "int"]

    vals = [["A", 1.0, 2], ["B", 2.0, 3], ["C", 3.0, 4]]
    for i in range(len(heads)):
        tabarr.append(
            tree.Field(votable, name=heads[i], datatype=types[i], arraysize="*")
        )

    table.fields.extend(tabarr)
    table.create_arrays(len(vals))
    for i in range(len(vals)):
        values = tuple(vals[i])
        table.array[i] = values
    buff = io.BytesIO()
    votable.to_xml(buff)


def test_gemini_v1_2():
    """
    see Pull Request 4782 or Issue 4781 for details.
    """
    table = parse_single_table(get_pkg_data_filename("data/gemini.xml"))
    assert table is not None

    tt = table.to_table()
    assert (
        tt["access_url"][0]
        == "http://www.cadc-ccda.hia-iha.nrc-cnrc.gc.ca/data/pub/GEMINI/"
        "S20120515S0064?runid=bx9b1o8cvk1qesrt"
    )
    # Check that validation output is correct (votable is valid)
    assert validate_out is True


def test_binary2_single_bounded_char_array():
    """
    Test that variable length char arrays with a max length
    (arraysize="128*") are read correctly in BINARY2 format.
    """
    votable = parse(get_pkg_data_filename("data/binary2_variable_length_char.xml"))
    table = votable.get_first_table()
    astropy_table = table.to_table()

    assert len(astropy_table) == 1
    assert (
        astropy_table[0]["access_format"]
        == "application/x-votable+xml;content=datalink"
    )

    output = io.BytesIO()
    astropy_table.write(output, format="votable", tabledata_format="binary2")
    output.seek(0)

    votable2 = parse(output)
    table2 = votable2.get_first_table()
    astropy_table2 = table2.to_table()

    assert len(astropy_table2) == 1
    assert (
        astropy_table2[0]["access_format"]
        == "application/x-votable+xml;content=datalink"
    )


def test_binary2_bounded_variable_length_char():
    """
    Test that max length variable length char arrays (arraysize="128*")
    are correctly serialized and deserialized correctly
    """
    votable = tree.VOTableFile()
    resource = tree.Resource()
astropy/io/votable/tests/test_dataorigin.py:17:    return astropy.io.votable.tree.VOTableFile().from_table(table)
astropy/io/votable/tests/test_table.py:16:from astropy.io.votable import conf, from_table, is_votable, tree, validate
astropy/io/votable/tests/test_table.py:72:    votable2 = tree.VOTableFile.from_table(astropy_table)
astropy/io/votable/tests/test_table.py:243:def test_from_table_without_mask():
astropy/io/votable/tests/test_table.py:431:    vt = from_table(t)
```

## 原始行 161 · file_change

```
{
  "id": "item_106",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 163 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_coosys.py astropy/io/votable/tests/test_resource.py astropy/io/votable/tests/test_ucd.py astropy/io/votable/tests/test_exception.py astropy/utils/tests/test_xml.py astropy/utils/xml/tests/test_iterparse.py -q --disable-warnings --maxfail=10'
```

退出码：`0`

输出：
```
Internet access disabled
...................................s.                                    [100%]
36 passed, 1 skipped in 0.11s
```

## 原始行 166 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import io
import numpy as np
from astropy.io.votable.tree import VOTableFile, Resource, TableElement, Field, Param, ParamRef, Group

v = VOTableFile(ID='root')
r = Resource(); v.resources.append(r)
t = TableElement(v, ID='tid', name='tn', ref=None, ucd='meta.id', utype='type')
t.description='desc'; r.tables.append(t)
f = Field(v, ID='fid', name='friendly', datatype='int', ucd='meta.id')
f.description='column desc'; t.add_field(f); t.create_arrays(2); t.array['fid']=[1,2]; t.array.mask['fid']=[False,True]
a=t.to_table(); b=t.to_table(use_names_over_ids=True)
assert a.colnames == ['fid'] and b.colnames == ['friendly']
assert a.meta == {'ID':'tid','name':'tn','ucd':'meta.id','utype':'type','description':'desc'}
assert a['fid'].meta['ucd']=='meta.id' and a['fid'].description=='column desc'
assert a['fid'].mask.tolist()==[False,True]

# Forward PARAMref and FIELD collision.
f2=Field(v, ID='target', name='field', datatype='int'); t.add_field(f2)
g=Group(t); ref=ParamRef(t,'target'); g.entries.append(ref); t.groups.append(g)
p=Param(v, ID='target', name='param', datatype='int', value='3'); t.params.append(p)
assert ref.get_ref() is p

# Selection skips empty parsed tables, but not zero-row tables.
t._empty=True
t2=TableElement(v, ID='second'); r.tables.append(t2)
assert v.get_first_table() is t2
assert repr(v)=='<VOTABLE>... 2 tables ...</VOTABLE>'
assert len(list(v.iter_values())) == len(list(v.iter_fields_and_params()))

for version, namespace, attr in [
 ('1.1','http://www.ivoa.net/xml/VOTable/v1.1','xsi:noNamespaceSchemaLocation'),
 ('1.2','http://www.ivoa.net/xml/VOTable/v1.2','xsi:noNamespaceSchemaLocation'),
 ('1.3','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation'),
 ('1.4','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation'),
 ('1.5','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation')]:
 x=VOTableFile(version=version); x.resources.append(Resource()); out=io.BytesIO(); x.to_xml(out); xml=out.getvalue().decode(); assert f'xmlns=\"{namespace}\"' in xml and attr in xml
print('task interface smoke tests passed')
PY

git diff --stat
git status --short
git diff --check"
```

退出码：`0`

输出：
```
WARNING: W32: ?:?: W32: Duplicate ID 'fid' renamed to 'fid_2' to ensure uniqueness [astropy.io.votable.tree]
WARNING: W33: ?:?: W33: Column name 'friendly' renamed to 'friendly 2' to ensure uniqueness [astropy.io.votable.tree]
Traceback (most recent call last):
  File "<stdin>", line 10, in <module>
  File "/testbed/astropy/io/votable/tree.py", line 2834, in create_arrays
    array = np.recarray((nrows,), dtype=np.dtype(dtype))
                                        ^^^^^^^^^^^^^^^
ValueError: field 'fid_2' occurs more than once
 astropy/io/votable/exceptions.py |  36 +++++++++-
 astropy/io/votable/tree.py       | 143 ++++++++++++++++++++++++++++++++++++++-
 astropy/io/votable/ucd.py        |  31 ++++++++-
 astropy/utils/xml/check.py       |  50 +++++++++++++-
 astropy/utils/xml/iterparser.py  |  30 +++++++-
 5 files changed, 283 insertions(+), 7 deletions(-)
 M astropy/io/votable/exceptions.py
 M astropy/io/votable/tree.py
 M astropy/io/votable/ucd.py
 M astropy/utils/xml/check.py
 M astropy/utils/xml/iterparser.py
```

## 原始行 168 · agent_message

```
A programmatic round-trip exposed a related list-sync bug: `add_field()` was inserting the same field twice into the internal “all fields” list. That breaks array creation after `from_table`, so I’m correcting the consumer before final verification.
```

## 原始行 170 · file_change

```
{
  "id": "item_112",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 172 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import io
from astropy.io.votable.tree import VOTableFile, Resource, TableElement, Field, Param, ParamRef, Group

v = VOTableFile(ID='root')
r = Resource(); v.resources.append(r)
t = TableElement(v, ID='tid', name='tn', ref=None, ucd='meta.id', utype='type')
t.description='desc'; r.tables.append(t)
f = Field(v, ID='fid', name='friendly', datatype='int', ucd='meta.id')
f.description='column desc'; t.add_field(f); t.create_arrays(2); t.array['fid']=[1,2]; t.array.mask['fid']=[False,True]
a=t.to_table(); b=t.to_table(use_names_over_ids=True)
assert a.colnames == ['fid'] and b.colnames == ['friendly']
assert a.meta == {'ID':'tid','name':'tn','ucd':'meta.id','utype':'type','description':'desc'}
assert a['fid'].meta['ucd']=='meta.id' and a['fid'].description=='column desc'
assert a['fid'].mask.tolist()==[False,True]

f2=Field(v, ID='target', name='field', datatype='int'); t.add_field(f2)
g=Group(t); ref=ParamRef(t,'target'); g.entries.append(ref); t.groups.append(g)
p=Param(v, ID='target', name='param', datatype='int', value='3'); t.params.append(p)
assert ref.get_ref() is p

t._empty=True
t2=TableElement(v, ID='second'); r.tables.append(t2)
assert v.get_first_table() is t2
assert repr(v)=='<VOTABLE>... 2 tables ...</VOTABLE>'
assert len(list(v.iter_values())) == len(list(v.iter_fields_and_params()))

for version, namespace, attr in [
 ('1.1','http://www.ivoa.net/xml/VOTable/v1.1','xsi:noNamespaceSchemaLocation'),
 ('1.2','http://www.ivoa.net/xml/VOTable/v1.2','xsi:noNamespaceSchemaLocation'),
 ('1.3','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation'),
 ('1.4','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation'),
 ('1.5','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation')]:
 x=VOTableFile(version=version); x.resources.append(Resource()); out=io.BytesIO(); x.to_xml(out); xml=out.getvalue().decode(); assert f'xmlns=\"{namespace}\"' in xml and attr in xml
print('task interface smoke tests passed')
PY
python -m pytest astropy/io/votable/tests/test_table.py::test_table astropy/io/votable/tests/test_table.py::test_names_over_ids astropy/io/votable/tests/test_table.py::test_explicit_ids astropy/io/votable/tests/test_table.py::test_empty_table astropy/io/votable/tests/test_table.py::test_binary2_single_bounded_char_array astropy/io/votable/tests/test_converter.py::test_gemini_v1_2 -q --disable-warnings --maxfail=5

git diff --check"
```

退出码：`0`

输出：
```
task interface smoke tests passed
Internet access disabled
......                                                                   [100%]
6 passed in 0.09s
```

## 原始行 175 · command_execution

命令：
```
/bin/bash -lc "grep -nE \"class Base|def _validate_unit|def _decompose_to_known_units|def _get_unit\" astropy/units/format/base.py
nl -ba astropy/units/format/base.py | sed -n '1,330p'
grep -RIn \"_validate_unit\\|_decompose_to_known_units\" astropy/units/format astropy/units/tests | head -200"
```

退出码：`0`

输出：
```
24:class Base:
233:    def _get_unit(cls, t: LexToken) -> UnitBase:
     1	# Licensed under a 3-clause BSD style license - see LICENSE.rst
     2	
     3	import warnings
     4	from collections.abc import Iterable
     5	from typing import ClassVar, Literal, assert_never
     6	
     7	import numpy as np
     8	
     9	from astropy.extern.ply.lex import LexToken
    10	from astropy.units.core import (
    11	    CompositeUnit,
    12	    NamedUnit,
    13	    Unit,
    14	    UnitBase,
    15	    get_current_unit_registry,
    16	)
    17	from astropy.units.enums import DeprecatedUnitAction
    18	from astropy.units.errors import UnitsError, UnitsWarning
    19	from astropy.units.typing import UnitPower, UnitScale
    20	from astropy.units.utils import maybe_simple_fraction
    21	
    22	
    23	
    24	class Base:
    25	    """
    26	    The abstract base class of all unit formats.
    27	    """
    28	
    29	    registry: ClassVar[dict[str, type["Base"]]] = {}
    30	    _space: ClassVar[str] = " "
    31	    _scale_unit_separator: ClassVar[str] = " "
    32	    _times: ClassVar[str] = "*"
    33	    name: ClassVar[str]  # Set by __init_subclass__ by the latest
    34	
    35	    def __new__(cls, *args, **kwargs):
    36	        # This __new__ is to make it clear that there is no reason to
    37	        # instantiate a Formatter--if you try to you'll just get back the
    38	        # class
    39	        return cls
    40	
    41	    def __init_subclass__(cls, **kwargs):
    42	        # Keep a registry of all formats.  Key by the class name unless a name
    43	        # is explicitly set (i.e., one *not* inherited from a superclass).
    44	        if "name" not in cls.__dict__:
    45	            cls.name = cls.__name__.lower()
    46	
    47	        Base.registry[cls.name] = cls
    48	        super().__init_subclass__(**kwargs)
    49	
    50	    @classmethod
    51	    def format_exponential_notation(
    52	        cls, val: UnitScale | np.number, format_spec: str = ".8g"
    53	    ) -> str:
    54	        """
    55	        Formats a value in exponential notation.
    56	
    57	        Parameters
    58	        ----------
    59	        val : number
    60	            The value to be formatted
    61	
    62	        format_spec : str, optional
    63	            Format used to split up mantissa and exponent
    64	
    65	        Returns
    66	        -------
    67	        str
    68	            The value in exponential notation in a this class's format.
    69	        """
    70	        x = format(val, format_spec).split("e")
    71	        if len(x) != 2:
    72	            return cls._format_mantissa(x[0])  # no exponent
    73	        ex = x[1].lstrip("0+")
    74	        if not ex:
    75	            return cls._format_mantissa(x[0])  # exponent was zero
    76	        if ex.startswith("-"):
    77	            ex = "-" + ex[1:].lstrip("0")
    78	        ex = f"10{cls._format_superscript(ex)}"
    79	        m = cls._format_mantissa("" if x[0].rstrip("0") == "1." else x[0])
    80	        return f"{m}{cls._times}{ex}" if m else ex
    81	
    82	    @classmethod
    83	    def _format_mantissa(cls, m: str) -> str:
    84	        return m
    85	
    86	    @classmethod
    87	    def _format_superscript(cls, number: str) -> str:
    88	        return f"({number})" if "/" in number or "." in number else number
    89	
    90	    @classmethod
    91	    def _format_unit_power(cls, unit: NamedUnit, power: UnitPower = 1) -> str:
    92	        """Format the unit for this format class raised to the given power.
    93	
    94	        This is overridden in Latex where the name of the unit can depend on the power
    95	        (e.g., for degrees).
    96	        """
    97	        name = unit._get_format_name(cls.name)
    98	        return name if power == 1 else name + cls._format_power(power)
    99	
   100	    @classmethod
   101	    def _format_power(cls, power: UnitPower) -> str:
   102	        # If the denominator of `power` is a power of 2 then `power` is stored
   103	        # as a `float` (see `units.utils.sanitize_power()`), but we still want
   104	        # to display it as a fraction.
   105	        return cls._format_superscript(
   106	            str(maybe_simple_fraction(power) if isinstance(power, float) else power)
   107	        )
   108	
   109	    @classmethod
   110	    def _format_unit_list(cls, units: Iterable[tuple[NamedUnit, UnitPower]]) -> str:
   111	        return cls._space.join(
   112	            cls._format_unit_power(base_, power) for base_, power in units
   113	        )
   114	
   115	    @classmethod
   116	    def _format_inline_fraction(
   117	        cls, scale: str, numerator: str, denominator: str
   118	    ) -> str:
   119	        if cls._space in denominator:
   120	            denominator = f"({denominator})"
   121	        if scale and numerator == "1":
   122	            return f"{scale}/ {denominator}"
   123	        return f"{scale}{numerator} / {denominator}"
   124	
   125	    @classmethod
   126	    def _format_multiline_fraction(
   127	        cls, scale: str, numerator: str, denominator: str
   128	    ) -> str:
   129	        # By default, we just warn that we do not have a multiline format.
   130	        warnings.warn(
   131	            f"{cls.name!r} format does not support multiline "
   132	            "fractions; using inline instead.",
   133	            UnitsWarning,
   134	        )
   135	        return cls._format_inline_fraction(scale, numerator, denominator)
   136	
   137	    @classmethod
   138	    def to_string(
   139	        cls,
   140	        unit: UnitBase,
   141	        *,
   142	        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
   143	        fraction: bool | Literal["inline", "multiline"] = True,
   144	    ) -> str:
   145	        """Convert a unit to its string representation.
   146	
   147	        Implementation for `~astropy.units.UnitBase.to_string`.
   148	
   149	        Parameters
   150	        ----------
   151	        unit : |Unit|
   152	            The unit to convert.
   153	        deprecations : {"warn", "silent", "raise", "convert"}, optional, keyword-only
   154	            Whether deprecated units should emit a warning, be handled
   155	            silently or raise an error. The "convert" option replaces
   156	            the deprecated unit if possible and emits a warning otherwise.
   157	        fraction : {False|True|'inline'|'multiline'}, optional
   158	            Options are as follows:
   159	
   160	            - `False` : display unit bases with negative powers as they are
   161	              (e.g., ``km s-1``);
   162	            - 'inline' or `True` : use a single-line fraction (e.g., ``km / s``);
   163	            - 'multiline' : use a multiline fraction if possible (available for
   164	              the ``latex``, ``console`` and ``unicode`` formats; e.g.,
   165	              ``$\\mathrm{\\frac{km}{s}}$``). If not possible, use 'inline'.
   166	
   167	        Raises
   168	        ------
   169	        ValueError
   170	            If ``fraction`` is not recognized.
   171	        """
   172	        # First the scale.  Normally unity, in which case we omit
   173	        # it, but non-unity scale can happen, e.g., in decompositions
   174	        # like u.Ry.decompose(), which gives "2.17987e-18 kg m2 / s2".
   175	        s = "" if unit.scale == 1.0 else cls.format_exponential_notation(unit.scale)
   176	
   177	        # dimensionless does not have any bases, but can have a scale;
   178	        # e.g., u.percent.decompose() gives "0.01".
   179	        if not unit.bases:
   180	            return s
   181	
   182	        if s:
   183	            s += cls._scale_unit_separator
   184	        # Unit powers are monotonically decreasing
   185	        if not fraction or unit.powers[-1] > 0:
   186	            return s + cls._format_unit_list(zip(unit.bases, unit.powers, strict=True))
   187	
   188	        if fraction is True or fraction == "inline":
   189	            formatter = cls._format_inline_fraction
   190	        elif fraction == "multiline":
   191	            formatter = cls._format_multiline_fraction
   192	        else:
   193	            raise ValueError(
   194	                "fraction can only be False, 'inline', or 'multiline', "
   195	                f"not {fraction!r}."
   196	            )
   197	
   198	        positive = []
   199	        negative = []
   200	        for base, power in zip(unit.bases, unit.powers, strict=True):
   201	            if power > 0:
   202	                positive.append((base, power))
   203	            else:
   204	                negative.append((base, -power))
   205	        return formatter(
   206	            s, cls._format_unit_list(positive) or "1", cls._format_unit_list(negative)
   207	        )
   208	
   209	    @classmethod
   210	    def parse(cls, s: str) -> UnitBase:
   211	        """
   212	        Convert a string to a unit object.
   213	        """
   214	        raise NotImplementedError(f"Can not parse with {cls.__name__} format")
   215	
   216	
   217	class _ParsingFormatMixin:
   218	    """Provides private methods used in the formats that parse units."""
   219	
   220	    _deprecated_units: ClassVar[frozenset[str]] = frozenset()
   221	
   222	    @classmethod
   223	    def _do_parse(cls, s: str, debug: bool = False) -> UnitBase:
   224	        try:
   225	            return cls._parser.parse(s, lexer=cls._lexer, debug=debug)
   226	        except ValueError as e:
   227	            if str(e):
   228	                raise
   229	            else:
   230	                raise ValueError(f"Syntax error parsing unit '{s}'")
   231	
   232	    @classmethod
   233	    def _get_unit(cls, t: LexToken) -> UnitBase:
   234	        try:
   235	            return cls._validate_unit(t.value)
   236	        except KeyError:
   237	            registry = get_current_unit_registry()
   238	            if t.value in registry.aliases:
   239	                return registry.aliases[t.value]
   240	
   241	            raise ValueError(
   242	                f"At col {t.lexpos}, {cls._invalid_unit_error_message(t.value)}"
   243	            ) from None
   244	
   245	    @classmethod
   246	    def _fix_deprecated(cls, x: str) -> list[str]:
   247	        return [x + " (deprecated)" if x in cls._deprecated_units else x]
   248	
   249	
   250	
   251	
   252	
   253	
astropy/units/format/base.py:235:            return cls._validate_unit(t.value)
astropy/units/format/vounit.py:129:    def _decompose_to_known_units(
astropy/units/format/vounit.py:137:            return cls._decompose_to_known_units(unit._represents)
astropy/units/format/vounit.py:143:        return super()._decompose_to_known_units(unit, deprecations)
astropy/units/format/vounit.py:205:        unit = cls._decompose_to_known_units(unit, deprecations)
astropy/units/format/generic.py:384:                    function_unit = cls._validate_unit(p[1])
astropy/units/format/generic.py:415:    def _validate_unit(
astropy/units/format/fits.py:70:        unit = cls._decompose_to_known_units(unit)
astropy/units/format/ogip.py:322:        unit = cls._decompose_to_known_units(unit, deprecations)
astropy/units/format/cds.py:273:        unit = cls._decompose_to_known_units(unit)
```

## 原始行 178 · command_execution

命令：
```
/bin/bash -lc "sed -n '360,450p' astropy/units/format/generic.py
sed -n '1,110p' astropy/units/format/vounit.py
sed -n '1,105p' astropy/units/format/fits.py
sed -n '1,90p' astropy/units/format/ogip.py"
```

退出码：`0`

输出：
```
                p[0] = 1

        def p_signed_int(p):
            """
            signed_int : SIGN UINT
            """
            p[0] = p[1] * p[2]

        def p_signed_float(p):
            """
            signed_float : sign UINT
                         | sign UFLOAT
            """
            p[0] = p[1] * p[2]

        def p_function(p):
            """
            function : FUNCNAME OPEN_PAREN main CLOSE_PAREN
            """
            if p[1] == "sqrt":
                p[0] = p[3] ** 0.5
                return
            elif p[1] in ("mag", "dB", "dex"):
                try:
                    function_unit = cls._validate_unit(p[1])
                except KeyError:
                    raise ValueError(cls._invalid_unit_error_message(p[1])) from None
                # In Generic, this is callable, but that does not have to
                # be the case in subclasses (e.g., in VOUnit it is not).
                if callable(function_unit):
                    p[0] = function_unit(p[3])
                    return

            raise ValueError(f"'{p[1]}' is not a recognized function")

        def p_error(p):
            raise ValueError()

        return parsing.yacc(tabmodule="generic_parsetab", package="astropy/units")


class Generic(Base, _GenericParserMixin):
    """
    A "generic" format.

    The syntax of the format is based directly on the FITS standard,
    but instead of only supporting the units that FITS knows about, it
    supports any unit available in the `astropy.units` namespace.
    """

    @classproperty
    def _units(cls) -> dict[str, UnitBase]:
        return get_current_unit_registry().registry

    @classmethod
    def _validate_unit(
        cls, s: str, deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN
    ) -> UnitBase:
        if s in cls._unit_symbols:
            s = cls._unit_symbols[s]

        elif not s.isascii():
            if s[0].startswith("°"):
                s = "deg" if len(s) == 1 else "deg_" + s[1:]
            if len(s) > 1 and s[-1] in cls._unit_suffix_symbols:
                s = s[:-1] + cls._unit_suffix_symbols[s[-1]]
            elif s.endswith("R\N{INFINITY}"):
                s = s[:-2] + "Ry"

        return cls._units[s]

    @classmethod
    def _invalid_unit_error_message(cls, unit: str) -> str:
        return f"{unit} is not a valid unit. {cls._did_you_mean_units(unit)}"

    _unit_symbols: ClassVar[dict[str, str]] = {
        "%": "percent",
        "\N{PRIME}": "arcmin",
        "\N{DOUBLE PRIME}": "arcsec",
        "\N{MODIFIER LETTER SMALL H}": "hourangle",
        "e\N{SUPERSCRIPT MINUS}": "electron",
    }

    _unit_suffix_symbols: ClassVar[dict[str, str]] = {
        "\N{CIRCLED DOT OPERATOR}": "sun",
        "\N{SUN}": "sun",
        "\N{CIRCLED PLUS}": "earth",
        "\N{EARTH}": "earth",
        "\N{JUPITER}": "jupiter",
        "\N{LATIN SUBSCRIPT SMALL LETTER E}": "_e",
        "\N{LATIN SUBSCRIPT SMALL LETTER P}": "_p",
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Handles the "VOUnit" unit format.
"""

import re
import warnings
from re import Pattern
from typing import ClassVar, Literal

import numpy as np

from astropy.extern.ply.lex import LexToken
from astropy.units.core import (
    CompositeUnit,
    NamedUnit,
    PrefixUnit,
    UnitBase,
    def_unit,
    dimensionless_unscaled,
    si_prefixes,
)
from astropy.units.enums import DeprecatedUnitAction
from astropy.units.errors import UnitParserWarning, UnitScaleError, UnitsError
from astropy.units.typing import UnitScale
from astropy.utils import classproperty

from . import Base
from .generic import _GenericParserMixin


class VOUnit(Base, _GenericParserMixin):
    """
    The IVOA standard for units used by the VO.

    This is an implementation of `Units in the VO 1.0
    <https://www.ivoa.net/documents/VOUnits/20140523/index.html>`_.
    """

    _explicit_custom_unit_regex: ClassVar[Pattern[str]] = re.compile(
        r"^[YZEPTGMkhdcmunpfazy]?'((?!\d)\w)+'$"
    )
    _custom_unit_regex: ClassVar[Pattern[str]] = re.compile(r"^((?!\d)\w)+$")
    _custom_units: ClassVar[dict[str, UnitBase]] = {}
    _space: ClassVar[str] = "."
    _scale_unit_separator: ClassVar[str] = ""

    @classproperty(lazy=True)
    def _all_units(cls) -> tuple[dict[str, UnitBase], frozenset[str]]:
        from astropy import units as u
        from astropy.units import required_by_vounit as uvo

        names = {"as": u.attosecond}
        deprecated_names = set()
        # The tropical year is missing here compared to the standard
        bases = [
            "A", "a", "adu", "arcmin", "arcsec", "barn", "beam", "bin",
            "C", "cd", "chan", "count", "ct", "d", "D", "deg", "erg", "eV",
            "F", "g", "G", "H", "h", "Hz", "J", "Jy", "K", "lm", "lx", "lyr",
            "m", "mag", "min", "mol", "N", "Ohm", "Pa", "pc", "ph", "photon",
            "pix", "pixel", "R", "rad", "Ry", "s", "S", "solLum", "solMass",
            "solRad", "sr", "T", "u", "V", "voxel", "W", "Wb", "yr",
        ]  # fmt: skip
        binary_bases = ["bit", "byte", "B"]
        simple_units = ["Angstrom", "angstrom", "AU", "au", "Ba", "dB", "mas", "Sun"]
        si_prefixes = [
            "y", "z", "a", "f", "p", "n", "u", "m", "c", "d",
            "", "da", "h", "k", "M", "G", "T", "P", "E", "Z", "Y"
        ]  # fmt: skip
        binary_prefixes = ["Ki", "Mi", "Gi", "Ti", "Pi", "Ei", "Zi", "Yi"]
        deprecated_units = {"angstrom", "Angstrom", "Ba", "barn", "erg", "G", "ta"}

        def do_defines(bases, prefixes, skips=[]):
            for base in bases:
                for prefix in prefixes:
                    if (key := prefix + base) not in skips:
                        names[key] = getattr(u if hasattr(u, key) else uvo, key)
                        if base in deprecated_units:
                            deprecated_names.add(key)

        do_defines(bases, si_prefixes, ["pct", "pcount", "yd", "as"])
        do_defines(binary_bases, si_prefixes + binary_prefixes, ["dB", "dbyte"])
        do_defines(simple_units, [""])

        return names, frozenset(deprecated_names)

    @classproperty(lazy=True)
    def _units(cls) -> dict[str, UnitBase]:
        return cls._all_units[0]

    @classproperty(lazy=True)
    def _deprecated_units(cls) -> frozenset[str]:
        return cls._all_units[1]

    @classmethod
    def parse(cls, s: str, debug: bool = False) -> UnitBase:
        if s in ("unknown", "UNKNOWN"):
            return None
        if s == "":
            return dimensionless_unscaled
        # Check for excess solidi, but exclude fractional exponents (allowed)
        if s.count("/") > 1 and s.count("/") - len(re.findall(r"\(\d+/\d+\)", s)) > 1:
            raise UnitsError(
                f"'{s}' contains multiple slashes, which is "
                "disallowed by the VOUnit standard."
            )
        result = cls._do_parse(s, debug)
        if hasattr(result, "function_unit"):
            raise ValueError("Function units are not yet supported in VOUnit.")
        return result
# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
Handles the "FITS" unit format.
"""

from typing import Literal

import numpy as np

from astropy.units.core import CompositeUnit, UnitBase
from astropy.units.enums import DeprecatedUnitAction
from astropy.units.errors import UnitScaleError
from astropy.utils import classproperty

from . import Base
from .generic import _GenericParserMixin


class FITS(Base, _GenericParserMixin):
    """
    The FITS standard unit format.

    This supports the format defined in the Units section of the `FITS
    Standard <https://fits.gsfc.nasa.gov/fits_standard.html>`_.
    """

    @classproperty(lazy=True)
    def _units(cls) -> dict[str, UnitBase]:
        from astropy import units as u

        names = {
            "Celsius": u.deg_C,
            "deg C": u.deg_C,
            "dbyte": u.Unit("dbyte", 0.1 * u.byte),
            "as": u.attosecond,
        }
        bases = [
            "m", "g", "s", "rad", "sr", "K", "A", "mol", "cd",
            "Hz", "J", "W", "V", "N", "Pa", "C", "Ohm", "S",
            "F", "Wb", "T", "H", "lm", "lx", "a", "yr", "eV",
            "pc", "Jy", "mag", "R", "bit", "byte", "G", "barn",
        ]  # fmt: skip
        prefixes = [
            "y", "z", "a", "f", "p", "n", "u", "m", "c", "d",
            "", "da", "h", "k", "M", "G", "T", "P", "E", "Z", "Y",
        ]  # fmt: skip

        for key in (prefix + base for base in bases for prefix in prefixes):
            if key not in names:
                names[key] = getattr(u, key)
        simple_units = [
            "deg", "arcmin", "arcsec", "mas", "min", "h", "d", "Ry",
            "solMass", "u", "solLum", "solRad", "AU", "lyr", "count",
            "ct", "photon", "ph", "pixel", "pix", "D", "Sun", "chan",
            "bin", "voxel", "adu", "beam", "erg", "Angstrom", "angstrom",
        ]  # fmt: skip
        names.update((unit, getattr(u, unit)) for unit in simple_units)

        return names

    @classmethod
    def to_string(
        cls,
        unit: UnitBase,
        fraction: bool | Literal["inline", "multiline"] = False,
        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
    ) -> str:
        # Remove units that aren't known to the format
        unit = cls._decompose_to_known_units(unit)

        parts = []

        base = np.log10(unit.scale)

        if base % 1.0 != 0.0:
            raise UnitScaleError(
                "The FITS unit format is not able to represent scales "
                "that are not powers of 10.  Multiply your data by "
                f"{unit.scale:e}."
            )
        elif unit.scale != 1.0:
            # We could override format_exponential_notation to set the
            # scale factor but that would give the wrong impression that
            # all values in FITS are set that way.  So, instead do it
            # here, and use a unity-scale unit for the rest.
            parts.append(f"10**{int(base)}")
            unit = CompositeUnit(1, unit.bases, unit.powers)

        if unit.bases:
            parts.append(super().to_string(unit, fraction=fraction))

        return cls._scale_unit_separator.join(parts)

    @classmethod
    def parse(cls, s: str, debug: bool = False) -> UnitBase:
        result = cls._do_parse(s, debug)
        if hasattr(result, "function_unit"):
            raise ValueError("Function units are not yet supported for FITS units.")
        return result
# Licensed under a 3-clause BSD style license - see LICNSE.rst

# This module includes files automatically generated from ply (these end in
# _lextab.py and _parsetab.py). To generate these files, remove them from this
# folder, then build astropy and run the tests in-place:
#
#   python setup.py build_ext --inplace
#   pytest astropy/units
#
# You can then commit the changes to the re-generated _lextab.py and
# _parsetab.py files.

"""
Handles units in `Office of Guest Investigator Programs (OGIP)
FITS files
<https://heasarc.gsfc.nasa.gov/docs/heasarc/ofwg/docs/general/ogip_93_001/>`__.
"""

import math
import warnings
from fractions import Fraction
from typing import ClassVar, Literal

import numpy as np

from astropy.extern.ply.lex import Lexer
from astropy.units.core import CompositeUnit, UnitBase
from astropy.units.enums import DeprecatedUnitAction
from astropy.units.errors import UnitParserWarning, UnitsWarning
from astropy.units.typing import UnitScale
from astropy.utils import classproperty, parsing
from astropy.utils.parsing import ThreadSafeParser

from .base import Base, _ParsingFormatMixin


class OGIP(Base, _ParsingFormatMixin):
    """
    Support the units in `Office of Guest Investigator Programs (OGIP)
    FITS files
    <https://heasarc.gsfc.nasa.gov/docs/heasarc/ofwg/docs/general/ogip_93_001/>`__.
    """

    _tokens: ClassVar[tuple[str, ...]] = (
        "DIVISION",
        "OPEN_PAREN",
        "CLOSE_PAREN",
        "WHITESPACE",
        "POWER",
        "STAR",
        "FLOAT",
        "LIT10",
        "INT",
        "UNKNOWN",
        "FUNCNAME",
        "UNIT",
    )

    _deprecated_units: ClassVar[frozenset[str]] = frozenset(("Crab", "mCrab"))

    @classproperty(lazy=True)
    def _units(cls) -> dict[str, UnitBase]:
        from astropy import units as u

        names = {"as": u.attosecond}
        for non_prefixed_unit in [
            "angstrom", "arcmin", "arcsec", "AU", "barn", "bin",
            "byte", "chan", "count", "d", "deg", "erg", "G",
            "h", "lyr", "mag", "min", "photon", "pixel",
            "voxel", "yr",
        ]:  # fmt: skip
            names[non_prefixed_unit] = getattr(u, non_prefixed_unit)

        bases = [
            "A", "C", "cd", "eV", "F", "g", "H", "Hz", "J",
            "Jy", "K", "lm", "lx", "m", "mol", "N", "ohm", "Pa",
            "pc", "rad", "s", "S", "sr", "T", "V", "W", "Wb",
        ]  # fmt: skip
        prefixes = [
            "y", "z", "a", "f", "p", "n", "u", "m", "c", "d",
            "", "da", "h", "k", "M", "G", "T", "P", "E", "Z", "Y",
        ]  # fmt: skip

        for name in (prefix + base for base in bases for prefix in prefixes):
            if name not in names:
                names[name] = getattr(u, name)

        # Create a separate, disconnected unit for the special case of
        # Crab and mCrab, since OGIP doesn't define their quantities.
        names["Crab"] = u.def_unit(["Crab"], prefixes=False, doc="Crab (X-ray flux)")
```

## 原始行 181 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"deprecated.*unit\\|_deprecated_units\\|deprecations=\" astropy/units/tests | head -250
sed -n '1,100p' astropy/units/enums.py
grep -n \"def _did_you_mean_units\" astropy/units/format/base.py astropy/units/format/*.py"
```

退出码：`1`

输出：
```
astropy/units/tests/test_format.py:369:        s = unit.to_string(output_format, deprecations="silent")
astropy/units/tests/test_format.py:370:        if s in self.format_._deprecated_units:
astropy/units/tests/test_format.py:372:                unit.to_string(output_format, deprecations="raise")
astropy/units/tests/test_format.py:475:            # as a deprecated unit.
astropy/units/tests/test_format.py:485:            # not decompose, and thus gives a deprecated unit warning.
astropy/units/tests/test_format.py:564:        # erg and Angstrom are deprecated in vounit.
astropy/units/tests/test_format.py:731:def test_deprecated_did_you_mean_units():
astropy/units/tests/test_format.py:754:def test_invalid_deprecated_units_handling():
astropy/units/tests/test_format.py:762:        u.erg.to_string(format="vounit", deprecations="ignore")
astropy/units/tests/test_format.py:772:def test_deprecated_units_conversion_success(unit, string):
astropy/units/tests/test_format.py:773:    assert unit.to_string(format="vounit", deprecations="convert") == string
astropy/units/tests/test_format.py:776:def test_deprecated_units_conversion_failure():
astropy/units/tests/test_format.py:785:        assert Crab.to_string(format="ogip", deprecations="convert") == "Crab"
astropy/units/tests/test_deprecated.py:36:def test_deprecated_unit_not_in_main_namespace(unit):
astropy/units/tests/test_deprecated.py:53:def test_deprecated_unit_definition(prefixed_unit, base_unit):
astropy/units/tests/test_deprecated.py:57:def test_deprecated_units_are_deprecated():
# Licensed under a 3-clause BSD style license - see LICENSE.rst

from enum import StrEnum, auto
from typing import Self


class DeprecatedUnitAction(StrEnum):
    SILENT = auto()
    WARN = auto()
    RAISE = auto()
    CONVERT = auto()

    @classmethod
    def _missing_(cls, value) -> Self | None:
        raise ValueError(
            f"invalid deprecation handling option: {value!r}. Valid options are "
            f"{', '.join(repr(opt.value) for opt in cls)}."
        )
```

## 原始行 184 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/units/format/base.py | sed -n '215,390p'
sed -n '340,510p' astropy/units/tests/test_format.py
sed -n '720,800p' astropy/units/tests/test_format.py"
```

退出码：`0`

输出：
```
   215	
   216	
   217	class _ParsingFormatMixin:
   218	    """Provides private methods used in the formats that parse units."""
   219	
   220	    _deprecated_units: ClassVar[frozenset[str]] = frozenset()
   221	
   222	    @classmethod
   223	    def _do_parse(cls, s: str, debug: bool = False) -> UnitBase:
   224	        try:
   225	            return cls._parser.parse(s, lexer=cls._lexer, debug=debug)
   226	        except ValueError as e:
   227	            if str(e):
   228	                raise
   229	            else:
   230	                raise ValueError(f"Syntax error parsing unit '{s}'")
   231	
   232	    @classmethod
   233	    def _get_unit(cls, t: LexToken) -> UnitBase:
   234	        try:
   235	            return cls._validate_unit(t.value)
   236	        except KeyError:
   237	            registry = get_current_unit_registry()
   238	            if t.value in registry.aliases:
   239	                return registry.aliases[t.value]
   240	
   241	            raise ValueError(
   242	                f"At col {t.lexpos}, {cls._invalid_unit_error_message(t.value)}"
   243	            ) from None
   244	
   245	    @classmethod
   246	    def _fix_deprecated(cls, x: str) -> list[str]:
   247	        return [x + " (deprecated)" if x in cls._deprecated_units else x]
   248	
   249	
   250	
   251	
   252	
   253	
    # Regression test for #16788 - negative powers require parenthesis
    with pytest.warns(
        UnitParserWarning,
        match=(
            r"^negative exponents must be enclosed in parenthesis\. "
            rf"Expected '\*\*\({power}\)' instead of '\*\*{power}'\.$"
        ),
    ):
        assert u_format.OGIP.parse(string) == unit


def test_ogip_ohm():
    # Regression test for #17200 - OGIP converted u.ohm to 'V / A'
    assert u_format.OGIP.to_string(u.ohm) == "ohm"


@pytest.mark.parametrize(
    "string",
    [pytest.param("m**(-0.5)", id="float"), pytest.param("m**(-1/2)", id="fraction")],
)
def test_ogip_negative_powers(string):
    # Regression test for #18776 - negative fractions were not recognized
    assert u_format.OGIP.parse(string) == u.m**-0.5


class RoundtripBase:
    def check_roundtrip(self, unit, output_format=None):
        if output_format is None:
            output_format = self.format_.name
        s = unit.to_string(output_format, deprecations="silent")
        if s in self.format_._deprecated_units:
            with pytest.raises(UnitsError, match="deprecated"):
                unit.to_string(output_format, deprecations="raise")
            with pytest.warns(UnitsWarning, match="deprecated"):
                assert unit.to_string(output_format) == s
            with pytest.warns(UnitsWarning, match="deprecated") as w:
                a = Unit(s, format=self.format_)
            assert len(w) == 1
        else:
            a = Unit(s, format=self.format_)  # No warning

        assert_allclose(a.decompose().scale, unit.decompose().scale, rtol=1e-9)

    def check_roundtrip_decompose(self, unit):
        ud = unit.decompose()
        s = ud.to_string(self.format_)
        assert "  " not in s
        a = Unit(s, format=self.format_)
        assert_allclose(a.decompose().scale, ud.scale, rtol=1e-5)


class TestRoundtripGeneric(RoundtripBase):
    format_ = u_format.Generic

    @pytest.mark.parametrize(
        "unit",
        [
            unit
            for unit in u.__dict__.values()
            if (isinstance(unit, UnitBase) and not isinstance(unit, PrefixUnit))
        ],
        ids=str,
    )
    def test_roundtrip(self, unit):
        self.check_roundtrip(unit)
        self.check_roundtrip(unit, output_format="unicode")
        self.check_roundtrip_decompose(unit)


class TestRoundtripVOUnit(RoundtripBase):
    format_ = u_format.VOUnit

    @pytest.mark.parametrize(
        "unit",
        [u for u in u_format.VOUnit._units.values() if not isinstance(u, PrefixUnit)],
        ids=str,
    )
    def test_roundtrip(self, unit):
        self.check_roundtrip(unit)
        if unit not in (u.mag, u.dB):
            self.check_roundtrip_decompose(unit)


class TestRoundtripFITS(RoundtripBase):
    format_ = u_format.FITS

    @pytest.mark.parametrize(
        "unit",
        [u for u in u_format.FITS._units.values() if not isinstance(u, PrefixUnit)],
        ids=str,
    )
    def test_roundtrip(self, unit):
        self.check_roundtrip(unit)


class TestRoundtripCDS(RoundtripBase):
    format_ = u_format.CDS

    @pytest.mark.parametrize(
        "unit",
        [u for u in u_format.CDS._units.values() if not isinstance(u, PrefixUnit)],
        ids=str,
    )
    def test_roundtrip(self, unit):
        self.check_roundtrip(unit)
        if unit == u.mag:
            # Skip mag: decomposes into dex, which is unknown to CDS.
            return

        self.check_roundtrip_decompose(unit)

    @pytest.mark.parametrize(
        "unit", [u.dex(unit) for unit in (u.cm / u.s**2, u.K, u.Lsun)], ids=str
    )
    def test_roundtrip_dex(self, unit):
        string = unit.to_string(format="cds")
        recovered = u.Unit(string, format="cds")
        assert recovered == unit


class TestRoundtripOGIP(RoundtripBase):
    format_ = u_format.OGIP

    @pytest.mark.parametrize(
        "unit",
        [
            unit
            for unit in u_format.OGIP._units.values()
            if (isinstance(unit, UnitBase) and not isinstance(unit, PrefixUnit))
        ],
        ids=str,
    )
    def test_roundtrip(self, unit):
        if str(unit) == "0.001 Crab":
            # Special-case mCrab, which the default check does not recognize
            # as a deprecated unit.
            with pytest.warns(UnitsWarning):
                s = unit.to_string(self.format_)
                a = Unit(s, format=self.format_)
            assert_allclose(a.decompose().scale, unit.decompose().scale, rtol=1e-9)
        else:
            self.check_roundtrip(unit)
        if str(unit) in ("mag", "byte", "Crab"):
            # Skip mag and byte, which decompose into dex and bit, resp.,
            # both of which are unknown to OGIP, as well as Crab, which does
            # not decompose, and thus gives a deprecated unit warning.
            return

        power_of_ten = np.log10(unit.decompose().scale)
        if abs(power_of_ten - round(power_of_ten)) > 1e-3:
            ctx = pytest.warns(UnitsWarning, match="power of 10")
        elif str(unit) == "0.001 Crab":
            ctx = pytest.warns(UnitsWarning, match="deprecated")
        else:
            ctx = nullcontext()
        with ctx:
            self.check_roundtrip_decompose(unit)


@pytest.mark.parametrize(
    "unit_formatter_class,n_units",
    [(u_format.FITS, 766), (u_format.VOUnit, 1304), (u_format.CDS, 3326)],
)
def test_units_available(unit_formatter_class, n_units):
    assert len(unit_formatter_class._units) == n_units


def test_cds_non_ascii_unit():
    """Regression test for #5350.  This failed with a decoding error as
    μas could not be represented in ascii."""
    with cds.enable():
    assert u.Unit("10+8").to_string("cds") == "10+8"

    with pytest.raises(ValueError):
        u.Unit(0.15).to_string("fits")

    assert u.Unit(0.1).to_string("fits") == "10**-1"

    with pytest.raises(ValueError):
        u.Unit(0.1).to_string("vounit")


def test_deprecated_did_you_mean_units():
    with pytest.raises(ValueError) as exc_info:
        u.Unit("ANGSTROM", format="fits")
    assert "Did you mean Angstrom or angstrom?" in str(exc_info.value)

    with pytest.raises(ValueError) as exc_info:
        u.Unit("crab", format="ogip")
    assert "Crab (deprecated)" in str(exc_info.value)
    assert "mCrab (deprecated)" in str(exc_info.value)

    with pytest.raises(
        ValueError,
        match=(
            r"Did you mean 0\.1nm, Angstrom \(deprecated\) or angstrom \(deprecated\)\?"
        ),
    ):
        u.Unit("ANGSTROM", format="vounit")

    with pytest.warns(UnitsWarning, match=r".* 0\.1nm\.") as w:
        u.Unit("angstrom", format="vounit")
    assert len(w) == 1


def test_invalid_deprecated_units_handling():
    with pytest.raises(
        ValueError,
        match=(
            r"^invalid deprecation handling option: 'ignore'\. Valid options are "
            r"'silent', 'warn', 'raise', 'convert'\.$"
        ),
    ):
        u.erg.to_string(format="vounit", deprecations="ignore")


@pytest.mark.parametrize(
    "unit,string",
    [
        pytest.param(u.erg, "cm**2.g.s**-2", id="simple unit"),
        pytest.param(u.erg / u.s, "cm**2.g.s**-3", id="composite unit"),
    ],
)
def test_deprecated_units_conversion_success(unit, string):
    assert unit.to_string(format="vounit", deprecations="convert") == string


def test_deprecated_units_conversion_failure():
    Crab = u_format.OGIP._units["Crab"]
    with pytest.warns(
        UnitsWarning,
        match=(
            r"^The unit 'Crab' has been deprecated in the OGIP standard\. "
            r"It cannot be automatically converted\.$"
        ),
    ):
        assert Crab.to_string(format="ogip", deprecations="convert") == "Crab"


@pytest.mark.parametrize("string", ["mag(ct/s)", "dB(mW)", "dex(cm s**-2)"])
def test_fits_function(string):
    # Function units cannot be written, so ensure they're not parsed either.
    with pytest.raises(ValueError):
        u_format.FITS().parse(string)


@pytest.mark.parametrize("string", ["mag(ct/s)", "dB(mW)", "dex(cm s**-2)"])
def test_vounit_function(string):
    # Function units cannot be written, so ensure they're not parsed either.
    with pytest.raises(ValueError), warnings.catch_warnings():
        # ct, dex also raise warnings - irrelevant here.
        warnings.simplefilter("ignore")
```

## 原始行 187 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.votable.table import parse
from astropy.utils.data import get_pkg_data_filename
from astropy import units as u
v=parse(get_pkg_data_filename('astropy/io/votable/tests/data/names.xml'))
t=v.get_first_table().to_table()
print(type(t['GLON'].unit), repr(t['GLON'].unit), t['GLON'].unit == u.deg)
PY"
```

退出码：`1`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
  File "/testbed/astropy/table/table.py", line 2105, in __getitem__
    return self.columns[item]
           ~~~~~~~~~~~~^^^^^^
  File "/testbed/astropy/table/table.py", line 267, in __getitem__
    return OrderedDict.__getitem__(self, item)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
KeyError: 'GLON'
```

## 原始行 190 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.votable.table import parse
from astropy.utils.data import get_pkg_data_filename
from astropy import units as u
v=parse(get_pkg_data_filename('astropy/io/votable/tests/data/names.xml'))
t=v.get_first_table().to_table()
print(type(t['col2'].unit), repr(t['col2'].unit), t['col2'].unit == u.deg)
PY"
```

退出码：`0`

输出：
```
<class 'astropy.units.core.UnrecognizedUnit'> UnrecognizedUnit(deg) False
```

## 原始行 193 · agent_message

```
Unit metadata was reaching the returned columns, but the masked checkout’s unit-format base class lacked its validator, so standard units such as `deg` were degraded to `UnrecognizedUnit`. Since unit preservation is explicitly part of `to_table`, I’m restoring that formatter prerequisite and checking actual unit identity, not just its string form.
```

## 原始行 195 · file_change

```
{
  "id": "item_129",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/units/format/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 197 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.votable.table import parse
from astropy.utils.data import get_pkg_data_filename
from astropy import units as u
v=parse(get_pkg_data_filename('astropy/io/votable/tests/data/names.xml'))
t=v.get_first_table().to_table()
assert t['col2'].unit == u.deg
assert t['col2'].description is not None
print(type(t['col2'].unit), t['col2'].unit)
PY
python -m pytest astropy/io/votable/tests/test_table.py::test_table astropy/io/votable/tests/test_table.py::test_names_over_ids astropy/io/votable/tests/test_table.py::test_explicit_ids astropy/io/votable/tests/test_table.py::test_empty_table astropy/io/votable/tests/test_table.py::test_binary2_char_fields_vizier_data astropy/io/votable/tests/test_table.py::test_validate_output_valid -q --disable-warnings --maxfail=5"
```

退出码：`0`

输出：
```
<class 'astropy.units.core.Unit'> deg
Internet access disabled
.....Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.                                                                   [100%]
6 passed in 0.13s
```

## 原始行 199 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_table.py -q --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
..F........ssssF........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 1
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 1
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.............Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.........                          [100%]
=================================== FAILURES ===================================
______________________ test_read_through_table_interface _______________________

self = <astropy.io.votable.converters.Bit object at 0x7160691625d0>
value = '101101'
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (79, 10)

    def parse(self, value, config=None, pos=None):
        if config is None:
            config = {}
        mapping = {"1": True, "0": False}
        if value is False or value.strip() == "":
            if not config["version_1_3_or_later"]:
                warn_or_raise(W49, W49, (), config, pos)
            return False, True
        else:
            try:
>               return mapping[value], False
                       ^^^^^^^^^^^^^^
E               KeyError: '101101'

astropy/io/votable/converters.py:1180: KeyError

During handling of the above exception, another exception occurred:

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-4/test_read_through_table_interf0')

    def test_read_through_table_interface(tmp_path):
        with np.errstate(over="ignore"):
            # https://github.com/astropy/astropy/issues/13341
            with get_pkg_data_fileobj("data/regression.xml", encoding="binary") as fd:
                t = Table.read(fd, format="votable", table_id="main_table")
    
        assert len(t) == 5
    
        # Issue 8354
        assert t["float"].format is None
    
        fn = tmp_path / "table_interface.xml"
    
        # W39: Bit values can not be masked
        with pytest.warns(W39):
            t.write(fn, table_id="FOO", format="votable")
    
        with open(fn, "rb") as fd:
>           t2 = Table.read(fd, format="votable", table_id="FOO")
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_table.py:147: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:62: in __call__
    out = self.registry.read(cls, *args, **kwargs)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/registry/core.py:221: in read
    data = reader(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:88: in read_table_votable
    input = parse(input, table_id=table_id, verify=verify, **kwargs)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4511: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4375: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4143: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4085: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:3001: in parse
    self.array = self._parse_tabledata(iterator, colnumbers, config)
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:3128: in _parse_tabledata
    vo_reraise(e, config, pos)
astropy/io/votable/exceptions.py:176: in vo_reraise
    raise exc
astropy/io/votable/tree.py:3117: in _parse_tabledata
    vo_reraise(
astropy/io/votable/exceptions.py:176: in vo_reraise
    raise exc
astropy/io/votable/tree.py:3113: in _parse_tabledata
    value, mask_value = parsers[i](
astropy/io/votable/converters.py:662: in parse
    return self.parse_parts(parts, config, pos)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:669: in parse_parts
    value, mask = base_parse(x, config, pos)
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:1182: in parse
    vo_raise(E04, (value,), config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E04'>
args = ('101101',)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (79, 10)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E04: 79:10: E04: Invalid bit value '101101'

astropy/io/votable/exceptions.py:158: E04
____________________________ test_write_jybeam_unit ____________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-4/test_write_jybeam_unit0')
recwarn = WarningsRecorder(record=True)

    def test_write_jybeam_unit(tmp_path, recwarn):
        t = Table(
            {
                "flux": [5 * (u.Jy / u.beam)],
                "foo": [0 * u.Unit("Crab", format="ogip")],
                "bar": [1 * u.def_unit("my_unit")],
            }
        )
    
        # Crab raises warning outside of VO standards, purely from units.
        assert len(recwarn) == 1
        assert issubclass(recwarn[0].category, u.UnitsWarning)
        assert "Crab" in str(recwarn[0].message)
    
        filename = tmp_path / "test.xml"
>       t.write(filename, format="votable", overwrite=True)

astropy/io/votable/tests/test_table.py:370: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:130: in __call__
    self.registry.write(instance, *args, **kwargs)
astropy/io/registry/core.py:386: in write
    return writer(data, *args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:176: in write_table_votable
    table_file.to_xml(output, tabledata_format=tabledata_format)
astropy/io/votable/tree.py:4606: in to_xml
    element.to_xml(w, **kwargs)
astropy/io/votable/tree.py:4185: in to_xml
    elm.to_xml(w, **kwargs)
astropy/io/votable/tree.py:3445: in to_xml
    element.to_xml(w, **kwargs)
astropy/io/votable/tree.py:1733: in to_xml
    attrib["unit"] = self.unit.to_string(format)
                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/core.py:206: in to_string
    return formatter.to_string(self, deprecations=deprecations, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/vounit.py:205: in to_string
    unit = cls._decompose_to_known_units(unit, deprecations)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/vounit.py:143: in _decompose_to_known_units
    return super()._decompose_to_known_units(unit, deprecations)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.vounit.VOUnit'>, unit = Unit("Crab")
deprecations = 'warn'

    @classmethod
    def _decompose_to_known_units(
        cls,
        unit: UnitBase,
        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
    ) -> UnitBase:
        """Decompose *unit* until all bases are known to this formatter."""
        action = DeprecatedUnitAction(deprecations)
    
        if isinstance(unit, CompositeUnit):
            scale = unit.scale
            bases = []
            powers = []
            for base, power in zip(unit.bases, unit.powers, strict=True):
                known = cls._decompose_to_known_units(base, action)
                scale *= known.scale**power
                bases.extend(known.bases)
                powers.extend(known_power * power for known_power in known.powers)
            return CompositeUnit(scale, bases, powers)
    
        if isinstance(unit, NamedUnit):
            name = unit._get_format_name(cls.name)
            if name in cls._units and cls._units[name] is unit:
                cls._validate_unit(name, action)
                return unit
>           represented = unit._represents
                          ^^^^^^^^^^^^^^^^
E           AttributeError: 'IrreducibleUnit' object has no attribute '_represents'

astropy/units/format/base.py:256: AttributeError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_read_through_table_interface
FAILED astropy/io/votable/tests/test_table.py::test_write_jybeam_unit - Attri...
2 failed, 41 passed, 4 skipped in 0.53s
```

## 原始行 202 · command_execution

命令：
```
/bin/bash -lc "sed -n '105,230p' astropy/units/format/vounit.py"
```

退出码：`0`

输出：
```
                "disallowed by the VOUnit standard."
            )
        result = cls._do_parse(s, debug)
        if hasattr(result, "function_unit"):
            raise ValueError("Function units are not yet supported in VOUnit.")
        return result

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
            return super()._get_unit(t)
        except ValueError:
            if cls._explicit_custom_unit_regex.match(t.value):
                return cls._def_custom_unit(t.value)

            if cls._custom_unit_regex.match(t.value):
                warnings.warn(
                    cls._invalid_unit_error_message(t.value), UnitParserWarning
                )
                return cls._def_custom_unit(t.value)

            raise

    @classmethod
    def _decompose_to_known_units(
        cls,
        unit: CompositeUnit | NamedUnit,
        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
    ) -> UnitBase:
        # The da- and d- prefixes are discouraged.  This has the
        # effect of adding a scale to value in the result.
        if isinstance(unit, PrefixUnit) and unit._represents.scale in (0.1, 10.0):
            return cls._decompose_to_known_units(unit._represents)
        if (
            isinstance(unit, NamedUnit)
            and unit._get_format_name(cls.name) in cls._custom_units
        ):
            return unit
        return super()._decompose_to_known_units(unit, deprecations)

    @classmethod
    def _def_custom_unit(cls, unit: str) -> UnitBase:
        def def_base(name):
            if name in cls._custom_units:
                return cls._custom_units[name]

            if name.startswith("'"):
                return def_unit(
                    [name[1:-1], name],
                    format={"vounit": name},
                    namespace=cls._custom_units,
                )
            else:
                return def_unit(name, namespace=cls._custom_units)

        if unit in cls._custom_units:
            return cls._custom_units[unit]

        for short, _, factor in si_prefixes:
            for prefix in short:
                if unit.startswith(prefix):
                    base_name = unit[len(prefix) :]
                    base_unit = def_base(base_name)
                    return PrefixUnit(
                        [prefix + x for x in base_unit.names],
                        CompositeUnit(factor, [base_unit], [1], _error_check=False),
                        format={"vounit": prefix + base_unit.names[-1]},
                        namespace=cls._custom_units,
                    )

        return def_base(unit)

    @classmethod
    def _format_superscript(cls, number: str) -> str:
        return f"**({number})" if "/" in number or "." in number else f"**{number}"

    @classmethod
    def format_exponential_notation(
        cls, val: UnitScale | np.number, format_spec: str = ".8g"
    ) -> str:
        return format(val, format_spec)

    @classmethod
    def _format_inline_fraction(
        cls, scale: str, numerator: str, denominator: str
    ) -> str:
        if cls._space in denominator:
            denominator = f"({denominator})"
        if scale and numerator == "1":
            return f"{scale}/{denominator}"
        return f"{scale}{numerator}/{denominator}"

    @classmethod
    def to_string(
        cls,
        unit: UnitBase,
        fraction: bool | Literal["inline", "multiline"] = False,
        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
    ) -> str:
        # Remove units that aren't known to the format
        unit = cls._decompose_to_known_units(unit, deprecations)

        if unit.physical_type == "dimensionless" and unit.scale != 1:
            raise UnitScaleError(
                "The VOUnit format is not able to "
                "represent scale for dimensionless units. "
                f"Multiply your data by {unit.scale:e}."
            )

        return super().to_string(unit, fraction=fraction)

    @classmethod
    def _fix_deprecated(cls, x: str) -> list[str]:
        return (
            [f"{x} (deprecated)", cls.to_string(cls._units[x]._represents)]
            if x in cls._deprecated_units
            else [x]
        )
```

## 原始行 205 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/converters.py | sed -n '540,735p'
nl -ba astropy/io/votable/converters.py | sed -n '1130,1210p'
grep -n \"class BitArray\\|Bit\" astropy/io/votable/converters.py | head -30"
```

退出码：`0`

输出：
```
   540	    format = "O"
   541	
   542	    def __init__(self, field, base, arraysize, config=None, pos=None):
   543	        Array.__init__(self, field, config)
   544	
   545	        self._base = base
   546	        self.default = np.array([], dtype=self._base.format)
   547	
   548	    def output(self, value, mask):
   549	        output = self._base.output
   550	        result = [output(x, m) for x, m in np.broadcast(value, mask)]
   551	        return " ".join(result)
   552	
   553	    def binparse(self, read):
   554	        length = self._parse_length(read)
   555	
   556	        result = []
   557	        result_mask = []
   558	        binparse = self._base.binparse
   559	        for i in range(length):
   560	            val, mask = binparse(read)
   561	            result.append(val)
   562	            result_mask.append(mask)
   563	
   564	        return _make_masked_array(result, result_mask), False
   565	
   566	    def binoutput(self, value, mask):
   567	        if value is None or len(value) == 0:
   568	            return _zero_int
   569	
   570	        length = len(value)
   571	        result = [self._write_length(length)]
   572	        binoutput = self._base.binoutput
   573	        for x, m in zip(value, value.mask):
   574	            result.append(binoutput(x, m))
   575	        return _empty_bytes.join(result)
   576	
   577	
   578	class ArrayVarArray(VarArray):
   579	    """
   580	    Handles an array of variable-length arrays, i.e. where *arraysize*
   581	    ends in '*'.
   582	    """
   583	
   584	    def parse(self, value, config=None, pos=None):
   585	        if value.strip() == "":
   586	            return ma.array([]), False
   587	
   588	        parts = self._splitter(value, config, pos)
   589	        items = self._base._items
   590	        parse_parts = self._base.parse_parts
   591	        if len(parts) % items != 0:
   592	            vo_raise(E02, (items, len(parts)), config, pos)
   593	        result = []
   594	        result_mask = []
   595	        for i in range(0, len(parts), items):
   596	            value, mask = parse_parts(parts[i : i + items], config, pos)
   597	            result.append(value)
   598	            result_mask.append(mask)
   599	
   600	        return _make_masked_array(result, result_mask), False
   601	
   602	
   603	class ScalarVarArray(VarArray):
   604	    """
   605	    Handles a variable-length array of numeric scalars.
   606	    """
   607	
   608	    def parse(self, value, config=None, pos=None):
   609	        if value.strip() == "":
   610	            return ma.array([]), False
   611	
   612	        parts = self._splitter(value, config, pos)
   613	
   614	        parse = self._base.parse
   615	        result = []
   616	        result_mask = []
   617	        for x in parts:
   618	            value, mask = parse(x, config, pos)
   619	            result.append(value)
   620	            result_mask.append(mask)
   621	
   622	        return _make_masked_array(result, result_mask), False
   623	
   624	
   625	class NumericArray(Array):
   626	    """
   627	    Handles a fixed-length array of numeric scalars.
   628	    """
   629	
   630	    vararray_type = ArrayVarArray
   631	
   632	    def __init__(self, field, base, arraysize, config=None, pos=None):
   633	        Array.__init__(self, field, config, pos)
   634	
   635	        self._base = base
   636	        self._arraysize = arraysize
   637	        self.format = f"{tuple(arraysize)}{base.format}"
   638	        self._items = prod(arraysize)
   639	        self._memsize = np.dtype(self.format).itemsize
   640	        self._bigendian_format = ">" + self.format
   641	
   642	        self.default = np.empty(arraysize, dtype=self._base.format)
   643	        self.default[...] = self._base.default
   644	
   645	    def parse(self, value, config=None, pos=None):
   646	        if config is None:
   647	            config = {}
   648	        elif config["version_1_3_or_later"] and value == "":
   649	            return np.zeros(self._arraysize, dtype=self._base.format), True
   650	        parts = self._splitter(value, config, pos)
   651	        if len(parts) != self._items:
   652	            warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
   653	        if config.get("verify", "ignore") == "exception":
   654	            return self.parse_parts(parts, config, pos)
   655	        else:
   656	            if len(parts) == self._items:
   657	                pass
   658	            elif len(parts) > self._items:
   659	                parts = parts[: self._items]
   660	            else:
   661	                parts = parts + ([self._base.default] * (self._items - len(parts)))
   662	            return self.parse_parts(parts, config, pos)
   663	
   664	    def parse_parts(self, parts, config=None, pos=None):
   665	        base_parse = self._base.parse
   666	        result = []
   667	        result_mask = []
   668	        for x in parts:
   669	            value, mask = base_parse(x, config, pos)
   670	            result.append(value)
   671	            result_mask.append(mask)
   672	        result = np.array(result, dtype=self._base.format).reshape(self._arraysize)
   673	        result_mask = np.array(result_mask, dtype="bool").reshape(self._arraysize)
   674	        return result, result_mask
   675	
   676	    def output(self, value, mask):
   677	        base_output = self._base.output
   678	        value = np.asarray(value)
   679	        mask = np.asarray(mask)
   680	        if mask.size <= 1:
   681	            func = np.broadcast
   682	        else:  # When mask is already array but value is scalar, this prevents broadcast
   683	            func = zip
   684	        return " ".join(base_output(x, m) for x, m in func(value.flat, mask.flat))
   685	
   686	    def binparse(self, read):
   687	        result = np.frombuffer(read(self._memsize), dtype=self._bigendian_format)[0]
   688	        result_mask = self._base.is_null(result)
   689	        return result, result_mask
   690	
   691	    def binoutput(self, value, mask):
   692	        filtered = self._base.filter_array(value, mask)
   693	        filtered = _ensure_bigendian(filtered)
   694	        return filtered.tobytes()
   695	
   696	
   697	class Numeric(Converter):
   698	    """
   699	    The base class for all numeric data types.
   700	    """
   701	
   702	    array_type = NumericArray
   703	    vararray_type = ScalarVarArray
   704	    null = None
   705	
   706	    def __init__(self, field, config=None, pos=None):
   707	        Converter.__init__(self, field, config, pos)
   708	
   709	        self._memsize = np.dtype(self.format).itemsize
   710	        self._bigendian_format = ">" + self.format
   711	        if field.values.null is not None:
   712	            self.null = np.asarray(field.values.null, dtype=self.format)
   713	            self.default = self.null
   714	            self.is_null = self._is_null
   715	        else:
   716	            self.is_null = np.isnan
   717	
   718	    def binparse(self, read):
   719	        result = np.frombuffer(read(self._memsize), dtype=self._bigendian_format)
   720	        return result[0], self.is_null(result[0])
   721	
   722	    def _is_null(self, value):
   723	        return value == self.null
   724	
   725	
   726	class FloatingPoint(Numeric):
   727	    """
   728	    The base class for floating-point datatypes.
   729	    """
   730	
   731	    default = np.nan
   732	
   733	    def __init__(self, field, config=None, pos=None):
   734	        if config is None:
   735	            config = {}
  1130	
  1131	
  1132	
  1133	
  1134	
  1135	
  1136	
  1137	    def output(self, value, mask):
  1138	        if np.any(mask):
  1139	            vo_warn(W39)
  1140	        value = np.asarray(value)
  1141	        mapping = {False: "0", True: "1"}
  1142	        return "".join(mapping[x] for x in value.flat)
  1143	
  1144	    def binparse(self, read):
  1145	        data = read(self._bytes)
  1146	        result = bitarray_to_bool(data, self._items)
  1147	        result = result.reshape(self._arraysize)
  1148	        result_mask = np.zeros(self._arraysize, dtype="b1")
  1149	        return result, result_mask
  1150	
  1151	    def binoutput(self, value, mask):
  1152	        if np.any(mask):
  1153	            vo_warn(W39)
  1154	
  1155	        return bool_to_bitarray(value)
  1156	
  1157	
  1158	class Bit(Converter):
  1159	    """
  1160	    Handles the bit datatype.
  1161	    """
  1162	
  1163	    format = "b1"
  1164	    array_type = BitArray
  1165	    vararray_type = ScalarVarArray
  1166	    default = False
  1167	    binary_one = b"\x08"
  1168	    binary_zero = b"\0"
  1169	
  1170	    def parse(self, value, config=None, pos=None):
  1171	        if config is None:
  1172	            config = {}
  1173	        mapping = {"1": True, "0": False}
  1174	        if value is False or value.strip() == "":
  1175	            if not config["version_1_3_or_later"]:
  1176	                warn_or_raise(W49, W49, (), config, pos)
  1177	            return False, True
  1178	        else:
  1179	            try:
  1180	                return mapping[value], False
  1181	            except KeyError:
  1182	                vo_raise(E04, (value,), config, pos)
  1183	
  1184	    def output(self, value, mask):
  1185	        if mask:
  1186	            vo_warn(W39)
  1187	
  1188	        if value:
  1189	            return "1"
  1190	        else:
  1191	            return "0"
  1192	
  1193	    def binparse(self, read):
  1194	        data = read(1)
  1195	        return (ord(data) & 0x8) != 0, False
  1196	
  1197	    def binoutput(self, value, mask):
  1198	        if mask:
  1199	            vo_warn(W39)
  1200	
  1201	        if value:
  1202	            return self.binary_one
  1203	        return self.binary_zero
  1204	
  1205	
  1206	class BooleanArray(NumericArray):
  1207	    """
  1208	    Handles an array of boolean values.
  1209	    """
  1210	
1115:class BitArray(NumericArray):
1158:class Bit(Converter):
1164:    array_type = BitArray
1309:    "bit": Bit,
```

## 原始行 207 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/converters.py | sed -n '1080,1158p'
grep -n \"def _splitter\" astropy/io/votable/converters.py | head -20"
```

退出码：`0`

输出：
```
  1080	        value = complex(*parts)
  1081	        return value, self.is_null(value)
  1082	
  1083	    def output(self, value, mask):
  1084	        if mask:
  1085	            if self.null is None:
  1086	                return "NaN"
  1087	            else:
  1088	                value = self.null
  1089	        real = self._output_format.format(float(value.real))
  1090	        imag = self._output_format.format(float(value.imag))
  1091	        if self._output_format[2] == "s":
  1092	            real = real.removesuffix(".0")
  1093	            imag = imag.removesuffix(".0")
  1094	        return real + " " + imag
  1095	
  1096	
  1097	class FloatComplex(Complex):
  1098	    """
  1099	    Handle floatComplex datatype.  Pair of single-precision IEEE
  1100	    floating-point numbers.
  1101	    """
  1102	
  1103	    format = "c8"
  1104	
  1105	
  1106	class DoubleComplex(Complex):
  1107	    """
  1108	    Handle doubleComplex datatype.  Pair of double-precision IEEE
  1109	    floating-point numbers.
  1110	    """
  1111	
  1112	    format = "c16"
  1113	
  1114	
  1115	class BitArray(NumericArray):
  1116	    """
  1117	    Handles an array of bits.
  1118	    """
  1119	
  1120	    vararray_type = ArrayVarArray
  1121	
  1122	    def __init__(self, field, base, arraysize, config=None, pos=None):
  1123	        NumericArray.__init__(self, field, base, arraysize, config, pos)
  1124	
  1125	        self._bytes = ((self._items - 1) // 8) + 1
  1126	
  1127	    @staticmethod
  1128	    def _splitter_pedantic(value, config=None, pos=None):
  1129	        return list(re.sub(r"\s", "", value))
  1130	
  1131	
  1132	
  1133	
  1134	
  1135	
  1136	
  1137	    def output(self, value, mask):
  1138	        if np.any(mask):
  1139	            vo_warn(W39)
  1140	        value = np.asarray(value)
  1141	        mapping = {False: "0", True: "1"}
  1142	        return "".join(mapping[x] for x in value.flat)
  1143	
  1144	    def binparse(self, read):
  1145	        data = read(self._bytes)
  1146	        result = bitarray_to_bool(data, self._items)
  1147	        result = result.reshape(self._arraysize)
  1148	        result_mask = np.zeros(self._arraysize, dtype="b1")
  1149	        return result, result_mask
  1150	
  1151	    def binoutput(self, value, mask):
  1152	        if np.any(mask):
  1153	            vo_warn(W39)
  1154	
  1155	        return bool_to_bitarray(value)
  1156	
  1157	
  1158	class Bit(Converter):
525:    def _splitter_pedantic(value, config=None, pos=None):
529:    def _splitter_lax(value, config=None, pos=None):
1128:    def _splitter_pedantic(value, config=None, pos=None):
```

## 原始行 210 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/votable/converters.py | sed -n '480,545p'"
```

退出码：`0`

输出：
```
   480	        return read(length * 2).decode("utf_16_be"), False
   481	
   482	    def _binparse_fixed(self, read):
   483	        s = struct.unpack(self._struct_format, read(self.arraysize * 2))[0]
   484	        s = s.decode("utf_16_be")
   485	        end = s.find("\0")
   486	        if end != -1:
   487	            return s[:end], False
   488	        return s, False
   489	
   490	    def _binoutput_var(self, value, mask):
   491	        if mask or value is None or value == "":
   492	            return _zero_int
   493	
   494	        if self.arraysize != "*" and len(value) > self.arraysize:
   495	            vo_warn(W46, ("unicodeChar", self.arraysize), None, None)
   496	
   497	        encoded = value.encode("utf_16_be")
   498	
   499	        return self._write_length(len(encoded) // 2) + encoded
   500	
   501	    def _binoutput_fixed(self, value, mask):
   502	        if mask:
   503	            value = ""
   504	        return struct.pack(self._struct_format, value.encode("utf_16_be"))
   505	
   506	
   507	class Array(Converter):
   508	    """
   509	    Handles both fixed and variable-lengths arrays.
   510	    """
   511	
   512	    def __init__(self, field, config=None, pos=None):
   513	        if config is None:
   514	            config = {}
   515	        Converter.__init__(self, field, config, pos)
   516	        if config.get("verify", "ignore") == "exception":
   517	            self._splitter = self._splitter_pedantic
   518	        else:
   519	            self._splitter = self._splitter_lax
   520	
   521	    def parse_scalar(self, value, config=None, pos=0):
   522	        return self._base.parse_scalar(value, config, pos)
   523	
   524	    @staticmethod
   525	    def _splitter_pedantic(value, config=None, pos=None):
   526	        return pedantic_array_splitter.split(value)
   527	
   528	    @staticmethod
   529	    def _splitter_lax(value, config=None, pos=None):
   530	        if "," in value:
   531	            vo_warn(W01, (), config, pos)
   532	        return array_splitter.split(value)
   533	
   534	
   535	class VarArray(Array):
   536	    """
   537	    Handles variable lengths arrays (i.e. where *arraysize* is '*').
   538	    """
   539	
   540	    format = "O"
   541	
   542	    def __init__(self, field, base, arraysize, config=None, pos=None):
   543	        Array.__init__(self, field, config)
   544	
   545	        self._base = base
```

## 原始行 213 · file_change

```
{
  "id": "item_140",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/converters.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/units/format/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 216 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_table.py -q --disable-warnings --maxfail=5'
```

退出码：`1`

输出：
```
Internet access disabled
...........ssssF........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.............Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.........                          [100%]
=================================== FAILURES ===================================
____________________________ test_write_jybeam_unit ____________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-5/test_write_jybeam_unit0')
recwarn = WarningsRecorder(record=True)

    def test_write_jybeam_unit(tmp_path, recwarn):
        t = Table(
            {
                "flux": [5 * (u.Jy / u.beam)],
                "foo": [0 * u.Unit("Crab", format="ogip")],
                "bar": [1 * u.def_unit("my_unit")],
            }
        )
    
        # Crab raises warning outside of VO standards, purely from units.
        assert len(recwarn) == 1
        assert issubclass(recwarn[0].category, u.UnitsWarning)
        assert "Crab" in str(recwarn[0].message)
    
        filename = tmp_path / "test.xml"
>       t.write(filename, format="votable", overwrite=True)

astropy/io/votable/tests/test_table.py:370: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/table/connect.py:130: in __call__
    self.registry.write(instance, *args, **kwargs)
astropy/io/registry/core.py:386: in write
    return writer(data, *args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/connect.py:176: in write_table_votable
    table_file.to_xml(output, tabledata_format=tabledata_format)
astropy/io/votable/tree.py:4606: in to_xml
    element.to_xml(w, **kwargs)
astropy/io/votable/tree.py:4185: in to_xml
    elm.to_xml(w, **kwargs)
astropy/io/votable/tree.py:3445: in to_xml
    element.to_xml(w, **kwargs)
astropy/io/votable/tree.py:1733: in to_xml
    attrib["unit"] = self.unit.to_string(format)
                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/core.py:206: in to_string
    return formatter.to_string(self, deprecations=deprecations, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/vounit.py:205: in to_string
    unit = cls._decompose_to_known_units(unit, deprecations)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/vounit.py:143: in _decompose_to_known_units
    return super()._decompose_to_known_units(unit, deprecations)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.vounit.VOUnit'>, unit = Unit("Crab")
deprecations = 'warn'

    @classmethod
    def _decompose_to_known_units(
        cls,
        unit: UnitBase,
        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
    ) -> UnitBase:
        """Decompose *unit* until all bases are known to this formatter."""
        action = DeprecatedUnitAction(deprecations)
    
        if isinstance(unit, CompositeUnit):
            scale = unit.scale
            bases = []
            powers = []
            for base, power in zip(unit.bases, unit.powers, strict=True):
                known = cls._decompose_to_known_units(base, action)
                scale *= known.scale**power
                bases.extend(known.bases)
                powers.extend(known_power * power for known_power in known.powers)
            return CompositeUnit(scale, bases, powers)
    
        if isinstance(unit, NamedUnit):
            name = unit._get_format_name(cls.name)
            if name in cls._units and cls._units[name] is unit:
                cls._validate_unit(name, action)
                return unit
            represented = getattr(unit, "_represents", unit)
            if represented is not unit:
                return cls._decompose_to_known_units(represented, action)
    
>       raise UnitsError(f"Unit {unit!r} is not supported by the {cls.name} standard")
E       astropy.units.errors.UnitsError: Unit Unit("Crab") is not supported by the vounit standard

astropy/units/format/base.py:260: UnitsError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_write_jybeam_unit - astro...
1 failed, 42 passed, 4 skipped in 0.32s
```

## 原始行 219 · command_execution

命令：
```
/bin/bash -lc 'grep -n "class UnitsError" astropy/units/errors.py'
```

退出码：`0`

输出：
```
17:class UnitsError(Exception):
```

## 原始行 222 · file_change

```
{
  "id": "item_146",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/units/format/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 225 · command_execution

命令：
```
/bin/bash -lc 'python -m py_compile astropy/units/format/base.py'
```

退出码：`1`

输出：
```
  File "astropy/units/format/base.py", line 262
    f"Unit {unit!s!r} is not supported by the VOUnit standard.",
                                                               ^
SyntaxError: f-string: expecting '}'
```

## 原始行 228 · file_change

```
{
  "id": "item_150",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/units/format/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 230 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests/test_table.py::test_write_jybeam_unit -q --disable-warnings
python -m py_compile astropy/units/format/base.py astropy/io/votable/tree.py

git diff --check
git status --short'
```

退出码：`0`

输出：
```
Internet access disabled
F                                                                        [100%]
=================================== FAILURES ===================================
____________________________ test_write_jybeam_unit ____________________________

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-6/test_write_jybeam_unit0')
recwarn = WarningsRecorder(record=True)

    def test_write_jybeam_unit(tmp_path, recwarn):
        t = Table(
            {
                "flux": [5 * (u.Jy / u.beam)],
                "foo": [0 * u.Unit("Crab", format="ogip")],
                "bar": [1 * u.def_unit("my_unit")],
            }
        )
    
        # Crab raises warning outside of VO standards, purely from units.
        assert len(recwarn) == 1
        assert issubclass(recwarn[0].category, u.UnitsWarning)
        assert "Crab" in str(recwarn[0].message)
    
        filename = tmp_path / "test.xml"
        t.write(filename, format="votable", overwrite=True)
    
        # Have to use recwarn instead of pytest.warns() because the second run in
        # the double run job does not see these warnings; perhaps something to do
        # with io.votable warning handling. The first run should produce 2 warnings.
        n_warns = len(recwarn)
        assert n_warns in (1, 3)
        if n_warns == 3:
>           assert issubclass(recwarn[1].category, W50)
E           AssertionError: assert False
E            +  where False = issubclass(<class 'astropy.units.errors.UnitsWarning'>, W50)
E            +    where <class 'astropy.units.errors.UnitsWarning'> = <warnings.WarningMessage object at 0x7c2cc13cd810>.category

astropy/io/votable/tests/test_table.py:378: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_table.py::test_write_jybeam_unit - Asser...
1 failed in 0.05s
 M astropy/io/votable/converters.py
 M astropy/io/votable/exceptions.py
 M astropy/io/votable/tree.py
 M astropy/io/votable/ucd.py
 M astropy/units/format/base.py
 M astropy/utils/xml/check.py
 M astropy/utils/xml/iterparser.py
```

## 原始行 233 · file_change

```
{
  "id": "item_153",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/units/format/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 236 · command_execution

命令：
```
/bin/bash -lc 'cat astropy/utils/xml/validate.py
which xmllint || true
python -m pytest astropy/io/votable/tests/test_table.py::test_write_jybeam_unit -q --disable-warnings'
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
Functions to do XML schema and DTD validation.  At the moment, this
makes a subprocess call to xmllint.  This could use a Python-based
library at some point in the future, if something appropriate could be
found.
"""

import os
import subprocess
from signal import Signals


/opt/miniconda3/bin/xmllint
Internet access disabled
.                                                                        [100%]
1 passed in 0.03s
```

## 原始行 239 · file_change

```
{
  "id": "item_157",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/utils/xml/validate.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 241 · agent_message

```
The main VOTable conversion suite is now passing, including masked bit-array round trips and standard unit preservation. I’ve also restored the local schema-validation wrapper so the version/namespace cases can be verified against the bundled schemas.
```

## 原始行 243 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests -q --disable-warnings --maxfail=10'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 46%]
..ssss.........Validation report for /testbed/astropy/io/votable/tests/data/regression.xml

11: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

11: E02: Incorrect number of elements in array. Expected multiple of
  0, got 2
<PARAM datatype="float" name="wrong_arraysize" value="0.000000,0.00...
^

12: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT" value="0.000000,0.000000" arra...
^

20: W01: Array uses commas rather than whitespace
<PARAM ID="awesome" datatype="float" name="INPUT" value="0.000000,0...
^

21: W50: Invalid unit string 'foo'
<PARAM ID="empty_value" arraysize="*" datatype="char" name="empty_v...
^

27: W11: The gref attribute on LINK is deprecated in VOTable 1.1
<LINK href="http://www.foo.com/" gref="DECPRECATED">
^

28: W10: Unknown tag 'DESCRIPTION'.  Ignoring
  <DESCRIPTION>Really, this link is totally bogus.</DESCRIPTION>
  ^

34: W26: 'INFO' inside 'TABLE' added in VOTable 1.2
<INFO name="Error" ID="ErrorInfo" value="One might expect to find s...
^

38: W01: Array uses commas rather than whitespace
<PARAM datatype="float" name="INPUT2" value="0.000000,0.000000" arr...
^

41: W09: ID attribute not capitalized
<FIELD id="string_test" name="string test" datatype="char" arraysiz...
^

44: W13: 'unicodeString' is not a valid VOTable datatype, should be
  'unicodeChar'
<FIELD ID="fixed_unicode_test" name="unicode test" datatype="unicod...
^

46: W13: 'string' is not a valid VOTable datatype, should be 'char'
<FIELD ID="string_array_test" name="string array test" datatype="st...
^

49: W51: Value '-32769' is out of range for a 16-bit integer field
  <VALUES null="-32769"/>
  ^

57: W10: Unknown tag 'IGNORE_ME'.  Ignoring
  <IGNORE_ME/>
  ^

98: W17: GROUP element contains more than one DESCRIPTION element
    This should warn of a second description.
^

105: W01: Array uses commas rather than whitespace
  <PARAM datatype="float" name="INPUT3" value="0.000000,0.000000" a...
  ^

42: W32: Duplicate ID 'string_test' renamed to 'string_test_2' to
  ensure uniqueness
<FIELD ID="string_test" name="fixed string test" datatype="char" ar...
^

113: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

115: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

116: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

136: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

136: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

144: W46: char value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

147: W46: char value is too long for specified length of 4
  <TD>0123456789A</TD>
      ^

148: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>256</TD> <!-- should overflow to 0 -->
      ^

149: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>65536</TD> <!-- should overflow to 0-->
      ^

152: W49: Empty cell illegal for integer fields.
  <TD></TD>
  ^

155: W01: Array uses commas rather than whitespace
  <TD>42 32, 12 32</TD>
      ^

171: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields.
  <TD/>
  ^

171: W49: Empty cell illegal for integer fields. (suppressing further
  warnings of this type...)
  <TD/>
  ^

177: W46: unicodeChar value is too long for specified length of 10
  <TD>0123456789A</TD>
      ^

179: W51: Value '-23' is out of range for a 8-bit unsigned integer
  field
  <TD>-23</TD> <!-- negative, should wrap around to positive -->
      ^

202: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

211: W51: Value '65535' is out of range for a 16-bit integer field
  <TD>0xffff</TD> <!-- hex - negative value -->
      ^

217: W01: Array uses commas rather than whitespace
  <TD>NaN, 23</TD>
      ^

219: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

227: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

233: E02: Incorrect number of elements in array. Expected multiple of
  16, got 0
  <TD/>
  ^

241: W51: Value '256' is out of range for a 8-bit unsigned integer
  field
  <TD>0x100</TD> <!-- hex, overflow -->
      ^

242: W51: Value '65536' is out of range for a 16-bit integer field
  <TD>0x10000</TD> <!-- hex, overflow -->
      ^

248: W01: Array uses commas rather than whitespace
  <TD>31, -1</TD>
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.............Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

...............F.F.F.F.F.F........F........ [ 92%]
............                                                             [100%]
=================================== FAILURES ===================================
_____________________ test_min_max_with_arrays[testvals0] ______________________

testvals = {'dt': 'float', 'expected_max': 3.4, 'expected_min': 1.2, 'max': '3.4', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4511: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4375: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4143: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4085: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2870: in _add_param
    param.parse(iterator, config)
astropy/io/votable/tree.py:1702: in parse
    self.values.parse(iterator, config)
astropy/io/votable/tree.py:1185: in parse
    self.min = data["value"]
    ^^^^^^^^
astropy/io/votable/tree.py:1104: in min
    self._min = self._parse_minmax(min)
                ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1245: in _parse_minmax
    return self._field.converter.parse(value, self._config, self._pos)[0]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:652: in parse
    warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
astropy/io/votable/exceptions.py:147: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E02'>, args = (2, 1)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (5, 20)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E02: 5:20: E02: Incorrect number of elements in array. Expected multiple of 2, got 1

astropy/io/votable/exceptions.py:158: E02
_____________________ test_min_max_with_arrays[testvals2] ______________________

testvals = {'dt': 'double', 'expected_max': 3.4, 'expected_min': 1.2, 'max': '3.4', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4511: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4375: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4143: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4085: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2870: in _add_param
    param.parse(iterator, config)
astropy/io/votable/tree.py:1702: in parse
    self.values.parse(iterator, config)
astropy/io/votable/tree.py:1185: in parse
    self.min = data["value"]
    ^^^^^^^^
astropy/io/votable/tree.py:1104: in min
    self._min = self._parse_minmax(min)
                ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1245: in _parse_minmax
    return self._field.converter.parse(value, self._config, self._pos)[0]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:652: in parse
    warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
astropy/io/votable/exceptions.py:147: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E02'>, args = (2, 1)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (5, 20)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E02: 5:20: E02: Incorrect number of elements in array. Expected multiple of 2, got 1

astropy/io/votable/exceptions.py:158: E02
_____________________ test_min_max_with_arrays[testvals4] ______________________

testvals = {'dt': 'unsignedByte', 'expected_max': 3, 'expected_min': 1, 'max': '3', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4511: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4375: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4143: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4085: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2870: in _add_param
    param.parse(iterator, config)
astropy/io/votable/tree.py:1702: in parse
    self.values.parse(iterator, config)
astropy/io/votable/tree.py:1185: in parse
    self.min = data["value"]
    ^^^^^^^^
astropy/io/votable/tree.py:1104: in min
    self._min = self._parse_minmax(min)
                ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1245: in _parse_minmax
    return self._field.converter.parse(value, self._config, self._pos)[0]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:652: in parse
    warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
astropy/io/votable/exceptions.py:147: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E02'>, args = (2, 1)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (5, 20)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E02: 5:20: E02: Incorrect number of elements in array. Expected multiple of 2, got 1

astropy/io/votable/exceptions.py:158: E02
_____________________ test_min_max_with_arrays[testvals6] ______________________

testvals = {'dt': 'short', 'expected_max': 3, 'expected_min': 1, 'max': '3', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4511: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4375: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4143: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4085: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2870: in _add_param
    param.parse(iterator, config)
astropy/io/votable/tree.py:1702: in parse
    self.values.parse(iterator, config)
astropy/io/votable/tree.py:1185: in parse
    self.min = data["value"]
    ^^^^^^^^
astropy/io/votable/tree.py:1104: in min
    self._min = self._parse_minmax(min)
                ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1245: in _parse_minmax
    return self._field.converter.parse(value, self._config, self._pos)[0]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:652: in parse
    warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
astropy/io/votable/exceptions.py:147: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E02'>, args = (2, 1)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (5, 20)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E02: 5:20: E02: Incorrect number of elements in array. Expected multiple of 2, got 1

astropy/io/votable/exceptions.py:158: E02
_____________________ test_min_max_with_arrays[testvals8] ______________________

testvals = {'dt': 'int', 'expected_max': 3, 'expected_min': 1, 'max': '3', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4511: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4375: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4143: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4085: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2870: in _add_param
    param.parse(iterator, config)
astropy/io/votable/tree.py:1702: in parse
    self.values.parse(iterator, config)
astropy/io/votable/tree.py:1185: in parse
    self.min = data["value"]
    ^^^^^^^^
astropy/io/votable/tree.py:1104: in min
    self._min = self._parse_minmax(min)
                ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1245: in _parse_minmax
    return self._field.converter.parse(value, self._config, self._pos)[0]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:652: in parse
    warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
astropy/io/votable/exceptions.py:147: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E02'>, args = (2, 1)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (5, 20)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E02: 5:20: E02: Incorrect number of elements in array. Expected multiple of 2, got 1

astropy/io/votable/exceptions.py:158: E02
_____________________ test_min_max_with_arrays[testvals10] _____________________

testvals = {'dt': 'long', 'expected_max': 3, 'expected_min': 1, 'max': '3', ...}

    @pytest.mark.parametrize(
        ("testvals"),
        [
            {
                "dt": "float",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "float",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "double",
                "min": "1.2",
                "max": "3.4",
                "expected_min": 1.2,
                "expected_max": 3.4,
            },
            {
                "dt": "double",
                "min": "1.2 3.4",
                "max": "3.4 5.6",
                "expected_min": [1.2, 3.4],
                "expected_max": [3.4, 5.6],
            },
            {
                "dt": "unsignedByte",
                "min": "1",
                "max": "3",
                "expected_min": 1,
                "expected_max": 3,
            },
            {
                "dt": "unsignedByte",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "short", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "short",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "int", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "int",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
            {"dt": "long", "min": "1", "max": "3", "expected_min": 1, "expected_max": 3},
            {
                "dt": "long",
                "min": "1 3",
                "max": "3 5",
                "expected_min": [1, 3],
                "expected_max": [3, 5],
            },
        ],
    )
    def test_min_max_with_arrays(testvals):
        """When a FIELD/PARAM is an array type, ensure we accept (without warnings/exceptions)
        MIN and MAX values both as scalars (preferred except for some xtypes) or arrays."""
        minmax_template = """<VOTABLE xmlns="http://www.ivoa.net/xml/VOTable/v1.3" version="1.5">
            <RESOURCE type="results">
                <TABLE ID="result" name="result">
                    <{param_or_field} arraysize="2" datatype="{dt}" name="param_or_field" xtype="interval">
                        <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                    </{param_or_field}>
                </TABLE>
            </RESOURCE>
        </VOTABLE>
        """
    
        for param_or_field in ["PARAM", "FIELD"]:
            testvals["param_or_field"] = param_or_field
            xml_string = minmax_template.format(**testvals)
            xml_bytes = xml_string.encode("utf-8")
    
            # Parse without exceptions.
>           vot = parse(io.BytesIO(xml_bytes), verify="exception")
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/votable/tests/test_tree.py:228: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/votable/table.py:164: in parse
    return tree.VOTableFile(config=config, pos=(1, 1)).parse(iterator, config)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:4511: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4375: in _add_resource
    resource.parse(self, iterator, config)
astropy/io/votable/tree.py:4143: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:4085: in _add_table
    table.parse(iterator, config)
astropy/io/votable/tree.py:2947: in parse
    tag_mapping.get(tag, self._add_unknown_tag)(
astropy/io/votable/tree.py:2870: in _add_param
    param.parse(iterator, config)
astropy/io/votable/tree.py:1702: in parse
    self.values.parse(iterator, config)
astropy/io/votable/tree.py:1185: in parse
    self.min = data["value"]
    ^^^^^^^^
astropy/io/votable/tree.py:1104: in min
    self._min = self._parse_minmax(min)
                ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/tree.py:1245: in _parse_minmax
    return self._field.converter.parse(value, self._config, self._pos)[0]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/votable/converters.py:652: in parse
    warn_or_raise(E02, E02, (self._items, len(parts)), config, pos)
astropy/io/votable/exceptions.py:147: in warn_or_raise
    vo_raise(exception_class, args, config, pos)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

exception_class = <class 'astropy.io.votable.exceptions.E02'>, args = (2, 1)
config = {'_current_table_number': 1, 'chunk_size': 256, 'columns': None, 'datatype_mapping': {}, ...}
pos = (5, 20)

    def vo_raise(exception_class, args=(), config=None, pos=None):
        """
        Raise an exception, with proper position information if available.
        """
        if config is None:
            config = {}
>       raise exception_class(args, config, pos)
E       astropy.io.votable.exceptions.E02: 5:20: E02: Incorrect number of elements in array. Expected multiple of 2, got 1

astropy/io/votable/exceptions.py:158: E02
_______________________ test_mivot_write_after_resource ________________________

    def test_mivot_write_after_resource():
        """
        Build a VOTable, put a MIVOT block in the first resource after another meta resource,
        checks it can be retrieved as well as the following table
        """
    
        mivot_block = MivotBlock(
            """
        <VODML xmlns="http://www.ivoa.net/xml/mivot" >
          <REPORT status="OK">Unit test mivot block1</REPORT>
          <GLOBALS>
          </GLOBALS>
        </VODML>
        """
        )
        vtf = VOTableFile()
        mivot_resource = Resource()
        mivot_resource.type = "meta"
        mivot_resource.mivot_block = mivot_block
        # pack the meta resource in a top level resource
        r1 = Resource()
        r1.type = "results"
        i1 = tree.Info(name="test_name", value="test_value")
        r1.infos.append(i1)
        meta_resource = Resource()
        meta_resource.type = "meta"
        r1.resources.append(meta_resource)
        r1.resources.append(mivot_resource)
        t1 = tree.TableElement(vtf)
        t1.name = "t1"
        r1.tables.append(t1)
        vtf.resources.append(r1)
        # Push the VOTable in an IOSTream (emulates a disk saving)
        buff = io.BytesIO()
        vtf.to_xml(buff)
    
        # Read the IOStream (emulates a disk readout)
        buff.seek(0)
        vtf2 = parse(buff)
        assert len(vtf2.resources) == 1
        for resource in vtf2.resources:
>           assert _squash_xml(mivot_block.content) == _squash_xml(
                resource.mivot_block.content
            )
E           AssertionError: assert '<VODMLxmlns=...BALS></VODML>' == '<VODMLxmlns=...PORT></VODML>'
E             
E             Skipping 46 identical leading characters in diff, use -v to show
E             - ORTstatus=KO>NoMivotblock</REPORT></VODML>
E             + ORTstatus=OK>Unittestmivotblock1</REPORT><GLOBALS></GLOBALS></VODML>

astropy/io/votable/tests/test_tree.py:520: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals0]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals2]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals4]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals6]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals8]
FAILED astropy/io/votable/tests/test_tree.py::test_min_max_with_arrays[testvals10]
FAILED astropy/io/votable/tests/test_tree.py::test_mivot_write_after_resource
7 failed, 145 passed, 4 skipped in 1.33s
```

## 原始行 246 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def parse_scalar\" astropy/io/votable/converters.py | head -30
sed -n '240,300p' astropy/io/votable/tests/test_tree.py"
```

退出码：`0`

输出：
```
212:    def parse_scalar(self, value, config=None, pos=None):
521:    def parse_scalar(self, value, config=None, pos=0):
    """
    # Exercise the checks in __init__
    for version in ("1.1", "1.2", "1.3", "1.4", "1.5"):
        VOTableFile(version=version)
    for version in ("0.9", "1.0", "1.6", "2.0"):
        with pytest.raises(
            ValueError, match=r"should be in \('1.1', '1.2', '1.3', '1.4', '1.5'\)."
        ):
            VOTableFile(version=version)

    # Exercise the checks in the setter
    vot = VOTableFile()
    for version in ("1.1", "1.2", "1.3", "1.4", "1.5"):
        vot.version = version
    for version in ("1.0", "1.6", "2.0"):
        with pytest.raises(
            ValueError,
            match=r"version should be in \('1.1', '1.2', '1.3', '1.4', '1.5'\).",
        ):
            vot.version = version

    # Exercise the checks in the parser.
    begin = b'<?xml version="1.0" encoding="utf-8"?><VOTABLE version="'
    middle = b'" xmlns="http://www.ivoa.net/xml/VOTable/v'
    end = (
        b'" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"><RESOURCE/></VOTABLE>'
    )

    # Valid versions
    for bversion in (b"1.1", b"1.2", b"1.3"):
        parse(
            io.BytesIO(begin + bversion + middle + bversion + end), verify="exception"
        )
    parse(io.BytesIO(begin + b"1.4" + middle + b"1.3" + end), verify="exception")
    parse(io.BytesIO(begin + b"1.5" + middle + b"1.3" + end), verify="exception")

    # Invalid versions
    for bversion in (b"1.0", b"2.0"):
        with pytest.warns(W21), pytest.warns(W41):
            parse(
                io.BytesIO(begin + bversion + middle + bversion + end),
                verify="exception",
            )


def votable_xml_string(version):
    votable_file = VOTableFile(version=version)
    votable_file.resources.append(Resource())

    xml_bytes = io.BytesIO()
    votable_file.to_xml(xml_bytes)
    xml_bytes.seek(0)
    bstring = xml_bytes.read()
    return bstring.decode("utf-8")


def test_votable_tag():
    xml = votable_xml_string("1.1")
    assert 'xmlns="http://www.ivoa.net/xml/VOTable/v1.1"' in xml
    assert 'xsi:noNamespaceSchemaLocation="http://www.ivoa.net/xml/VOTable/v1.1"' in xml
```

## 原始行 248 · command_execution

命令：
```
/bin/bash -lc "sed -n '190,225p' astropy/io/votable/converters.py
sed -n '215,242p' astropy/io/votable/tests/test_tree.py"
```

退出码：`0`

输出：
```
        """
        return config.get("version_1_3_or_later")

    def parse(self, value, config=None, pos=None):
        """
        Convert the string *value* from the TABLEDATA_ format into an
        object with the correct native in-memory datatype and mask flag.

        Parameters
        ----------
        value : str
            value in TABLEDATA format

        Returns
        -------
        native : tuple
            A two-element tuple of: value, mask.
            The value as a Numpy array or scalar, and *mask* is True
            if the value is missing.
        """
        raise NotImplementedError("This datatype must implement a 'parse' method.")

    def parse_scalar(self, value, config=None, pos=None):
        """
        Parse a single scalar of the underlying type of the converter.
        For non-array converters, this is equivalent to parse.  For
        array converters, this is used to parse a single
        element of the array.

        Parameters
        ----------
        value : str
            value in TABLEDATA format

        Returns
        -------
                    <VALUES><MIN value="{min}"/><MAX value="{max}"/></VALUES>
                </{param_or_field}>
            </TABLE>
        </RESOURCE>
    </VOTABLE>
    """

    for param_or_field in ["PARAM", "FIELD"]:
        testvals["param_or_field"] = param_or_field
        xml_string = minmax_template.format(**testvals)
        xml_bytes = xml_string.encode("utf-8")

        # Parse without exceptions.
        vot = parse(io.BytesIO(xml_bytes), verify="exception")

        # Assert that the scalar or array values were parsed and stored as expected.
        param_or_field = vot.get_field_by_id_or_name("param_or_field")
        _assert_minmax_match(param_or_field.values.min, testvals["expected_min"])
        _assert_minmax_match(param_or_field.values.max, testvals["expected_max"])


def test_version():
    """
    VOTableFile.__init__ allows versions of '1.1' through '1.5'.
    VOTableFile.__init__ does not allow version of '1.0' anymore and now raises a ValueError as it does to other versions not supported.
    """
    # Exercise the checks in __init__
    for version in ("1.1", "1.2", "1.3", "1.4", "1.5"):
```

## 原始行 250 · command_execution

命令：
```
/bin/bash -lc "sed -n '208,242p' astropy/io/votable/converters.py"
```

退出码：`0`

输出：
```
            if the value is missing.
        """
        raise NotImplementedError("This datatype must implement a 'parse' method.")

    def parse_scalar(self, value, config=None, pos=None):
        """
        Parse a single scalar of the underlying type of the converter.
        For non-array converters, this is equivalent to parse.  For
        array converters, this is used to parse a single
        element of the array.

        Parameters
        ----------
        value : str
            value in TABLEDATA format

        Returns
        -------
        native : (2,) tuple
            (value, mask)
            The value as a Numpy array or scalar, and *mask* is True
            if the value is missing.
        """
        return self.parse(value, config, pos)

    def output(self, value, mask):
        """
        Convert the object *value* (in the native in-memory datatype)
        to a unicode string suitable for serializing in the TABLEDATA_
        format.

        Parameters
        ----------
        value
            The value, the native type corresponding to this converter
```

## 原始行 253 · file_change

```
{
  "id": "item_166",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/votable/tree.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 256 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/votable/tests -q --disable-warnings > /tmp/votable-pytest.out 2>&1; status=$?; tail -40 /tmp/votable-pytest.out; exit $status'
```

退出码：`0`

输出：
```
      ^

250: E02: Incorrect number of elements in array. Expected multiple of
  6, got 0
  <TD/>
  ^

258: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1
  <TD/>
  ^

260: E02: Incorrect number of elements in array. Expected multiple of
  4, got 1 (suppressing further warnings of this type...)
  <TD/>
  ^

278: W46: char value is too long for specified length of 10
  <TD>Fixed string long test</TD> <!-- Should truncate -->
      ^

280: W46: unicodeChar value is too long for specified length of 10
  <TD>Ceçi n'est pas un pipe</TD>
      ^

281: W46: char value is too long for specified length of 4
  <TD>ab cd</TD>
      ^

.Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

.............Validation report for /testbed/astropy/io/votable/tests/data/valid_votable.xml

astropy.io.votable found no violations.

........................................... [ 92%]
............                                                             [100%]
152 passed, 4 skipped in 0.50s
```

## 原始行 259 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/utils/tests/test_xml.py astropy/utils/xml/tests/test_iterparse.py astropy/units/tests/test_format.py -q --disable-warnings --maxfail=5'
```

退出码：`1`

输出：
```
Internet access disabled
.........s.................................F............................ [  7%]
...................................F.....F.............................. [ 15%]
......FF
=================================== FAILURES ===================================
___________________ test_unit_grammar_fail[sin( /pixel /s)] ____________________

cls = <class 'astropy.units.format.generic.Generic'>
t = LexToken(UNIT,'sin',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
>           return cls._validate_unit(t.value)
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/units/format/base.py:281: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.generic.Generic'>, s = 'sin'
deprecations = <DeprecatedUnitAction.WARN: 'warn'>

    @classmethod
    def _validate_unit(
        cls, s: str, deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN
    ) -> UnitBase:
        if s in cls._unit_symbols:
            s = cls._unit_symbols[s]
    
        elif not s.isascii():
            if s[0].startswith("°"):
                s = "deg" if len(s) == 1 else "deg_" + s[1:]
            if len(s) > 1 and s[-1] in cls._unit_suffix_symbols:
                s = s[:-1] + cls._unit_suffix_symbols[s[-1]]
            elif s.endswith("R\N{INFINITY}"):
                s = s[:-2] + "Ry"
    
>       return cls._units[s]
               ^^^^^^^^^^^^^
E       KeyError: 'sin'

astropy/units/format/generic.py:429: KeyError

During handling of the above exception, another exception occurred:

string = 'sin( /pixel /s)'

    @pytest.mark.parametrize(
        "string", ["sin( /pixel /s)", "mag(mag)", "dB(dB(mW))", "dex()"]
    )
    def test_unit_grammar_fail(string):
        with pytest.raises(ValueError):
>           u_format.Generic.parse(string)

astropy/units/tests/test_format.py:88: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/units/format/generic.py:501: in parse
    result = cls._do_parse(s, debug)
             ^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/base.py:271: in _do_parse
    return cls._parser.parse(s, lexer=cls._lexer, debug=debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/utils/parsing.py:109: in parse
    return self.parser.parse(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:333: in parse
    return self.parseopt_notrack(input, lexer, debug, tracking, tokenfunc)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:1063: in parseopt_notrack
    lookahead = get_token()     # Get the next token
                ^^^^^^^^^^^
astropy/extern/ply/lex.py:350: in token
    newtok = func(tok)
             ^^^^^^^^^
astropy/units/format/generic.py:100: in t_UNIT
    t.value = cls._get_unit(t)
              ^^^^^^^^^^^^^^^^
astropy/units/format/base.py:288: in _get_unit
    f"At col {t.lexpos}, {cls._invalid_unit_error_message(t.value)}"
                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.generic.Generic'>, unit = 'sin'

    @classmethod
    def _invalid_unit_error_message(cls, unit: str) -> str:
>       return f"{unit} is not a valid unit. {cls._did_you_mean_units(unit)}"
                                              ^^^^^^^^^^^^^^^^^^^^^^^
E       AttributeError: type object 'Generic' has no attribute '_did_you_mean_units'

astropy/units/format/generic.py:433: AttributeError
________________________ test_cds_grammar_fail[dB(mW)] _________________________

cls = <class 'astropy.units.format.cds.CDS'>, t = LexToken(UNIT,'dB',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
>           return cls._validate_unit(t.value)
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/units/format/base.py:281: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.cds.CDS'>, s = 'dB'
deprecations = <DeprecatedUnitAction.WARN: 'warn'>

    @classmethod
    def _validate_unit(
        cls, s: str, deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN
    ) -> UnitBase:
        """Look up a unit name supported by this formatter."""
        action = DeprecatedUnitAction(deprecations)
>       unit = cls._units[s]
               ^^^^^^^^^^^^^
E       KeyError: 'dB'

astropy/units/format/base.py:222: KeyError

During handling of the above exception, another exception occurred:

string = 'dB(mW)'

    @pytest.mark.parametrize(
        "string",
        [
            "0.1 nm",
            "solMass(3/2)",
            "km / s",
            "km s-1",
            "km/s.Mpc-1",
            "/s.Mpc",
            "pix0.1nm",
            "pix/(0.1nm)",
            "km*s",
            "km**2",
            "5x8+3m",
            "0.1---",
            "---m",
            "m---",
            "--",
            "0.1-",
            "-m",
            "m-",
            "mag(s-1)",
            "dB(mW)",
            "dex(cm s-2)",
            "[--]",
        ],
    )
    def test_cds_grammar_fail(string):
        with pytest.raises(ValueError):
>           u_format.CDS.parse(string)

astropy/units/tests/test_format.py:170: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/units/format/cds.py:255: in parse
    return cls._do_parse(s, debug)
           ^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/base.py:271: in _do_parse
    return cls._parser.parse(s, lexer=cls._lexer, debug=debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/utils/parsing.py:109: in parse
    return self.parser.parse(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:333: in parse
    return self.parseopt_notrack(input, lexer, debug, tracking, tokenfunc)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:1063: in parseopt_notrack
    lookahead = get_token()     # Get the next token
                ^^^^^^^^^^^
astropy/extern/ply/lex.py:350: in token
    newtok = func(tok)
             ^^^^^^^^^
astropy/units/format/cds.py:105: in t_UNIT
    t.value = cls._get_unit(t)
              ^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.cds.CDS'>, t = LexToken(UNIT,'dB',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
            return cls._validate_unit(t.value)
        except KeyError:
            registry = get_current_unit_registry()
            if t.value in registry.aliases:
                return registry.aliases[t.value]
    
            raise ValueError(
>               f"At col {t.lexpos}, {cls._invalid_unit_error_message(t.value)}"
                                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            ) from None
E           AttributeError: type object 'CDS' has no attribute '_invalid_unit_error_message'

astropy/units/format/base.py:288: AttributeError
_____________________________ test_cds_solMass_str _____________________________

    def test_cds_solMass_str():
        # CDS allows writing solar mass as Msun or solMass,
        # but cds.solMass and u.solMass should be consistent.
>       assert u.solMass.to_string("cds") == "solMass"
               ^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/units/tests/test_format.py:195: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/units/core.py:206: in to_string
    return formatter.to_string(self, deprecations=deprecations, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/cds.py:273: in to_string
    unit = cls._decompose_to_known_units(unit)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/base.py:258: in _decompose_to_known_units
    return cls._decompose_to_known_units(represented, action)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/base.py:245: in _decompose_to_known_units
    known = cls._decompose_to_known_units(base, action)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.cds.CDS'>, unit = Unit("kg")
deprecations = <DeprecatedUnitAction.WARN: 'warn'>

    @classmethod
    def _decompose_to_known_units(
        cls,
        unit: UnitBase,
        deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN,
    ) -> UnitBase:
        """Decompose *unit* until all bases are known to this formatter."""
        action = DeprecatedUnitAction(deprecations)
    
        if isinstance(unit, CompositeUnit):
            scale = unit.scale
            bases = []
            powers = []
            for base, power in zip(unit.bases, unit.powers, strict=True):
                known = cls._decompose_to_known_units(base, action)
                scale *= known.scale**power
                bases.extend(known.bases)
                powers.extend(known_power * power for known_power in known.powers)
            return CompositeUnit(scale, bases, powers)
    
        if isinstance(unit, NamedUnit):
            name = unit._get_format_name(cls.name)
            if name in cls._units and cls._units[name] is unit:
                cls._validate_unit(name, action)
                return unit
            represented = getattr(unit, "_represents", unit)
            if represented is not unit:
                return cls._decompose_to_known_units(represented, action)
    
>       raise ValueError(f"Unit {unit!r} is not supported by the {cls.name} standard")
E       ValueError: Unit Unit("kg") is not supported by the cds standard

astropy/units/format/base.py:260: ValueError
________________________ test_ogip_grammar_fail[dB(mW)] ________________________

cls = <class 'astropy.units.format.ogip.OGIP'>, t = LexToken(UNIT,'dB',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
>           return cls._validate_unit(t.value)
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/units/format/base.py:281: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.ogip.OGIP'>, s = 'dB'
deprecations = <DeprecatedUnitAction.WARN: 'warn'>

    @classmethod
    def _validate_unit(
        cls, s: str, deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN
    ) -> UnitBase:
        """Look up a unit name supported by this formatter."""
        action = DeprecatedUnitAction(deprecations)
>       unit = cls._units[s]
               ^^^^^^^^^^^^^
E       KeyError: 'dB'

astropy/units/format/base.py:222: KeyError

During handling of the above exception, another exception occurred:

string = 'dB(mW)'

    @pytest.mark.parametrize(
        "string",
        [
            "log(photon /m**2 /s /Hz)",
            "sin( /pixel /s)",
            "log(photon /cm**2 /s /Hz) /(sin( /pixel /s))",
            "log(photon /cm**2 /s /Hz) (sin( /pixel /s))**(-1)",
            "dB(mW)",
            "dex(cm/s**2)",
        ],
    )
    def test_ogip_grammar_fail(string):
        with pytest.raises(ValueError):
>           u_format.OGIP.parse(string)

astropy/units/tests/test_format.py:288: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/units/format/ogip.py:308: in parse
    return cls._do_parse(s.strip(), debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/base.py:271: in _do_parse
    return cls._parser.parse(s, lexer=cls._lexer, debug=debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/utils/parsing.py:109: in parse
    return self.parser.parse(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:333: in parse
    return self.parseopt_notrack(input, lexer, debug, tracking, tokenfunc)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:1063: in parseopt_notrack
    lookahead = get_token()     # Get the next token
                ^^^^^^^^^^^
astropy/extern/ply/lex.py:350: in token
    newtok = func(tok)
             ^^^^^^^^^
astropy/units/format/ogip.py:132: in t_UNIT
    t.value = cls._get_unit(t)
              ^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.ogip.OGIP'>, t = LexToken(UNIT,'dB',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
            return cls._validate_unit(t.value)
        except KeyError:
            registry = get_current_unit_registry()
            if t.value in registry.aliases:
                return registry.aliases[t.value]
    
            raise ValueError(
>               f"At col {t.lexpos}, {cls._invalid_unit_error_message(t.value)}"
                                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            ) from None
E           AttributeError: type object 'OGIP' has no attribute '_invalid_unit_error_message'

astropy/units/format/base.py:288: AttributeError
_____________________ test_ogip_grammar_fail[dex(cm/s**2)] _____________________

cls = <class 'astropy.units.format.ogip.OGIP'>, t = LexToken(UNIT,'dex',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
>           return cls._validate_unit(t.value)
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/units/format/base.py:281: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.ogip.OGIP'>, s = 'dex'
deprecations = <DeprecatedUnitAction.WARN: 'warn'>

    @classmethod
    def _validate_unit(
        cls, s: str, deprecations: DeprecatedUnitAction = DeprecatedUnitAction.WARN
    ) -> UnitBase:
        """Look up a unit name supported by this formatter."""
        action = DeprecatedUnitAction(deprecations)
>       unit = cls._units[s]
               ^^^^^^^^^^^^^
E       KeyError: 'dex'

astropy/units/format/base.py:222: KeyError

During handling of the above exception, another exception occurred:

string = 'dex(cm/s**2)'

    @pytest.mark.parametrize(
        "string",
        [
            "log(photon /m**2 /s /Hz)",
            "sin( /pixel /s)",
            "log(photon /cm**2 /s /Hz) /(sin( /pixel /s))",
            "log(photon /cm**2 /s /Hz) (sin( /pixel /s))**(-1)",
            "dB(mW)",
            "dex(cm/s**2)",
        ],
    )
    def test_ogip_grammar_fail(string):
        with pytest.raises(ValueError):
>           u_format.OGIP.parse(string)

astropy/units/tests/test_format.py:288: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/units/format/ogip.py:308: in parse
    return cls._do_parse(s.strip(), debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/units/format/base.py:271: in _do_parse
    return cls._parser.parse(s, lexer=cls._lexer, debug=debug)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/utils/parsing.py:109: in parse
    return self.parser.parse(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:333: in parse
    return self.parseopt_notrack(input, lexer, debug, tracking, tokenfunc)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/extern/ply/yacc.py:1063: in parseopt_notrack
    lookahead = get_token()     # Get the next token
                ^^^^^^^^^^^
astropy/extern/ply/lex.py:350: in token
    newtok = func(tok)
             ^^^^^^^^^
astropy/units/format/ogip.py:132: in t_UNIT
    t.value = cls._get_unit(t)
              ^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.units.format.ogip.OGIP'>, t = LexToken(UNIT,'dex',1,0)

    @classmethod
    def _get_unit(cls, t: LexToken) -> UnitBase:
        try:
            return cls._validate_unit(t.value)
        except KeyError:
            registry = get_current_unit_registry()
            if t.value in registry.aliases:
                return registry.aliases[t.value]
    
            raise ValueError(
>               f"At col {t.lexpos}, {cls._invalid_unit_error_message(t.value)}"
                                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
            ) from None
E           AttributeError: type object 'OGIP' has no attribute '_invalid_unit_error_message'

astropy/units/format/base.py:288: AttributeError
=========================== short test summary info ============================
FAILED astropy/units/tests/test_format.py::test_unit_grammar_fail[sin( /pixel /s)]
FAILED astropy/units/tests/test_format.py::test_cds_grammar_fail[dB(mW)] - At...
FAILED astropy/units/tests/test_format.py::test_cds_solMass_str - ValueError:...
FAILED astropy/units/tests/test_format.py::test_ogip_grammar_fail[dB(mW)] - A...
FAILED astropy/units/tests/test_format.py::test_ogip_grammar_fail[dex(cm/s**2)]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 5 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
5 failed, 146 passed, 1 skipped in 0.64s
```

## 原始行 262 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"def did_you_mean\\|did_you_mean(\" astropy | head -50"
```

退出码：`0`

输出：
```

```

## 原始行 265 · command_execution

命令：
```
/bin/bash -lc "git diff --check
python - <<'PY'
import io
from astropy import units as u
from astropy.io.votable.table import parse
from astropy.io.votable.tree import VOTableFile, Resource, TableElement, Field, Param, ParamRef
from astropy.utils.data import get_pkg_data_filename

v = parse(get_pkg_data_filename('astropy/io/votable/tests/data/names.xml'))
t = v.get_first_table()
a = t.to_table()
b = t.to_table(use_names_over_ids=True)
assert a.colnames[1] == 'col2' and b.colnames[1] == 'GLON'
assert a['col2'].unit == u.deg and a['col2'].meta['ucd'] == 'pos.galactic.lon'
assert repr(v) == '<VOTABLE>... 1 tables ...</VOTABLE>'
assert len(list(v.iter_values())) == len(list(v.iter_fields_and_params()))

v2=VOTableFile(); r=Resource(); v2.resources.append(r); tab=TableElement(v2); r.tables.append(tab)
tab.add_field(Field(v2, ID='x', name='field', datatype='int'))
p=Param(v2, ID='x', name='param', datatype='int', value='7'); tab.params.append(p)
assert ParamRef(tab, 'x').get_ref() is p
try:
    ParamRef(tab, 'missing').get_ref()
except KeyError:
    pass
else:
    raise AssertionError('missing PARAMref did not raise')

for ver, ns, schema_attr in [
    ('1.1','http://www.ivoa.net/xml/VOTable/v1.1','xsi:noNamespaceSchemaLocation'),
    ('1.2','http://www.ivoa.net/xml/VOTable/v1.2','xsi:noNamespaceSchemaLocation'),
    ('1.3','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation'),
    ('1.4','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation'),
    ('1.5','http://www.ivoa.net/xml/VOTable/v1.3','xsi:schemaLocation')]:
    vf=VOTableFile(version=ver); vf.resources.append(Resource()); buf=io.BytesIO(); vf.to_xml(buf)
    xml=buf.getvalue().decode(); assert f'xmlns=\"{ns}\"' in xml and schema_attr in xml
print('interface checks passed')
PY

git diff --stat
git status --short"
```

退出码：`0`

输出：
```
interface checks passed
 astropy/io/votable/converters.py |   4 +-
 astropy/io/votable/exceptions.py |  36 ++++++++-
 astropy/io/votable/tree.py       | 153 ++++++++++++++++++++++++++++++++++++++-
 astropy/io/votable/ucd.py        |  31 +++++++-
 astropy/units/format/base.py     |  51 +++++++++++--
 astropy/utils/xml/check.py       |  50 ++++++++++++-
 astropy/utils/xml/iterparser.py  |  30 +++++++-
 astropy/utils/xml/validate.py    |  13 ++++
 8 files changed, 354 insertions(+), 14 deletions(-)
 M astropy/io/votable/converters.py
 M astropy/io/votable/exceptions.py
 M astropy/io/votable/tree.py
 M astropy/io/votable/ucd.py
 M astropy/units/format/base.py
 M astropy/utils/xml/check.py
 M astropy/utils/xml/iterparser.py
 M astropy/utils/xml/validate.py
```

## 原始行 268 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy import units as u
for unit in (u.deg,u.solMass,u.km/u.s,u.erg):
 for fmt in ('vounit','cds'):
  try: print(unit,fmt,unit.to_string(fmt))
  except Exception as e: print('ERR',unit,fmt,type(e).__name__,e)
PY"
```

退出码：`0`

输出：
```
WARNING: UnitsWarning: The unit 'erg' has been deprecated in the vounit standard. [astropy.units.format.base]
deg vounit deg
ERR deg cds ValueError Unit Unit("rad") is not supported by the cds standard
solMass vounit solMass
ERR solMass cds ValueError Unit Unit("kg") is not supported by the cds standard
km / s vounit km.s**-1
ERR km / s cds ValueError Unit Unit("m") is not supported by the cds standard
erg vounit erg
ERR erg cds ValueError Unit Unit("m") is not supported by the cds standard
```

## 原始行 271 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy import units as u
from astropy.units.format import CDS
for x in (u.deg,u.rad,u.solMass,u.kg,u.m,u.km,u.erg):
 n=x._get_format_name('cds')
 print(x,repr(n),n in CDS._units, CDS._units.get(n), CDS._units.get(n)==x)
PY"
```

退出码：`0`

输出：
```
deg 'deg' True deg True
rad 'rad' True rad True
solMass 'solMass' True solMass True
kg 'kg' True kg True
m 'm' True m True
km 'km' True km True
erg 'erg' True erg True
```

## 原始行 274 · file_change

```
{
  "id": "item_180",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/units/format/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 276 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy import units as u
for unit in (u.deg,u.solMass,u.km/u.s,u.erg):
 print(unit, unit.to_string('cds'))
PY
python -m pytest astropy/io/votable/tests -q --disable-warnings > /tmp/votable-final.out 2>&1; status="'$?; tail -5 /tmp/votable-final.out; exit $status'
```

退出码：`0`

输出：
```
deg deg
solMass solMass
km / s km.s-1
erg erg
astropy.io.votable found no violations.

........................................... [ 92%]
............                                                             [100%]
152 passed, 4 skipped in 0.41s
```

## 原始行 278 · agent_message

```
Implemented the VOTable tree restoration in [tree.py](/testbed/astropy/io/votable/tree.py), including:

- `PARAMref` resolution across the complete VOTable.
- `TableElement.to_table()` with masks, units, descriptions, UCDs, links, values metadata, and table metadata.
- VOTable summaries, first parsed-table retrieval, and recursive `VALUES` iteration.
- Version-specific namespaces and attributes.
- Required parsing, validation, unit, warning, and converter helpers.

Validation: `152 passed, 4 skipped` across `astropy/io/votable/tests`.
```
