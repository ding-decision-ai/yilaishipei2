# Codex baseline: astropy__astropy.b0db0daa.test_tilde_path.383d7c0c.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll trace the FITS path flow from the public read/write/dump/load APIs into `_File`, inspect the existing Header and formatter implementations, then make the smallest compatible change and run focused tests.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "pwd && rg -n \"class _File|class HeaderFormatter|def _countblanks|def _updateindices|def append\\(|def count\\(\" astropy/io/fits/{file.py,header.py,scripts/fitsheader.py} && rg -n \"expanduser|dump\\(|load\\(|writeto\\(|fromfile\\(\" astropy/io/fits | head -200"
```

退出码：`127`

输出：
```
/testbed
/bin/bash: line 1: rg: command not found
```

## 原始行 7 · agent_message

```
`rg` isn’t available in this environment, so I’m switching to targeted `grep`/`find` inspection. I’ll keep the search limited to this repository as required.
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc "grep -nE \"class _File|class HeaderFormatter|def _countblanks|def _updateindices|def append\\(|def count\\(\" astropy/io/fits/file.py astropy/io/fits/header.py astropy/io/fits/scripts/fitsheader.py; grep -RInE \"expanduser|def (dump|load|writeto|fromfile)\\(\" astropy/io/fits --include='*.py' | head -250"
```

退出码：`0`

输出：
```
astropy/io/fits/file.py:145:class _File:
astropy/io/fits/scripts/fitsheader.py:89:class HeaderFormatter:
astropy/io/fits/diff.py:162:            fileobj = os.path.expanduser(fileobj)
astropy/io/fits/header.py:469:    def fromfile(cls, fileobj, sep="", endcard=True, padding=True):
astropy/io/fits/header.py:511:            fileobj = os.path.expanduser(fileobj)
astropy/io/fits/header.py:2039:    def fromfile(cls, fileobj):
astropy/io/fits/convenience.py:413:def writeto(
astropy/io/fits/convenience.py:715:        filename = os.path.expanduser(filename)
astropy/io/fits/hdu/base.py:367:    def writeto(self, name, output_verify="exception", overwrite=False, checksum=False):
astropy/io/fits/hdu/base.py:1531:    def writeto(self, name, output_verify="exception", overwrite=False, checksum=False):
astropy/io/fits/hdu/nonstandard.py:42:    def fromfile(cls, filename, compress=False):
astropy/io/fits/hdu/hdulist.py:466:    def fromfile(
astropy/io/fits/hdu/hdulist.py:990:    def writeto(
astropy/io/fits/hdu/streaming.py:72:        filename = os.path.expanduser(filename)
astropy/io/fits/hdu/table.py:1028:    def dump(self, datafile=None, cdfile=None, hfile=None, overwrite=False):
astropy/io/fits/hdu/table.py:1062:            datafile = os.path.expanduser(datafile)
astropy/io/fits/hdu/table.py:1064:            cdfile = os.path.expanduser(cdfile)
astropy/io/fits/hdu/table.py:1066:            hfile = os.path.expanduser(hfile)
astropy/io/fits/hdu/table.py:1100:    def load(cls, datafile, cdfile=None, hfile=None, replace=False, header=None):
astropy/io/fits/hdu/table.py:1290:            fileobj = os.path.expanduser(fileobj)
astropy/io/fits/hdu/table.py:1435:            fileobj = os.path.expanduser(fileobj)
astropy/io/fits/tests/test_core.py:1097:        with open(os.path.expanduser(self.temp("test.fits.gz")), "rb") as f:
astropy/io/fits/tests/test_fitsdiff.py:346:        with open(os.path.expanduser(self.temp("diff_report.txt"))) as f:
astropy/io/fits/tests/conftest.py:107:            os.path.expanduser(self.data(filename)),
astropy/io/fits/tests/conftest.py:108:            os.path.expanduser(p),
astropy/io/fits/tests/conftest.py:110:        os.chmod(os.path.expanduser(p), stat.S_IREAD | stat.S_IWRITE)
astropy/io/fits/tests/test_hdulist.py:386:        assert name == os.path.expanduser(self.data("tb.fits"))
astropy/io/fits/tests/test_hdulist.py:840:        assert os.path.exists(os.path.expanduser(self.temp("scale.fits.bak")))
astropy/io/fits/tests/test_hdulist.py:853:        assert os.path.exists(os.path.expanduser(self.temp("scale.fits.bak")))
astropy/io/fits/tests/test_hdulist.py:854:        assert os.path.exists(os.path.expanduser(self.temp("scale.fits.bak.1")))
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' astropy/io/fits/file.py; sed -n '1,180p' astropy/io/fits/scripts/fitsheader.py; grep -n \"countblanks\\|updateindices\\|def append\\|def count\" astropy/io/fits/header.py; sed -n '450,535p' astropy/io/fits/header.py; sed -n '680,735p' astropy/io/fits/convenience.py; sed -n '1020,1135p' astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import errno
import gzip
import http.client
import io
import mmap
import operator
import os
import re
import sys
import tempfile
import warnings
import zipfile
from functools import reduce

import numpy as np

# NOTE: Python can be built without bz2.
from astropy.utils.compat.optional_deps import HAS_BZ2, HAS_LZMA, HAS_UNCOMPRESSPY
from astropy.utils.data import _is_url, download_file, get_readable_fileobj





from astropy.utils.decorators import classproperty
from astropy.utils.exceptions import AstropyUserWarning
from astropy.utils.misc import NOT_OVERWRITING_MSG

from .util import _array_from_file, _array_to_file, fileobj_mode, isfile, isreadable, iswritable, path_like












if HAS_BZ2:
    import bz2

if HAS_LZMA:
    import lzma

if HAS_UNCOMPRESSPY:
    import uncompresspy


# Maps astropy.io.fits-specific file mode names to the appropriate file
# modes to use for the underlying raw files.
IO_FITS_MODES = {
    "readonly": "rb",
    "copyonwrite": "rb",
    "update": "rb+",
    "append": "ab+",
    "ostream": "wb",
    "denywrite": "rb",
}

# Maps OS-level file modes to the appropriate astropy.io.fits specific mode
# to use when given file objects but no mode specified; obviously in
# IO_FITS_MODES there are overlaps; for example 'readonly' and 'denywrite'
# both require the file to be opened in 'rb' mode.  But 'readonly' is the
# default behavior for such files if not otherwise specified.
# Note: 'ab' is only supported for 'ostream' which is output-only.
FILE_MODES = {
    "rb": "readonly",
    "rb+": "update",
    "wb": "ostream",
    "wb+": "update",
    "ab": "ostream",
    "ab+": "append",
}

# A match indicates the file was opened in text mode, which is not allowed
TEXT_RE = re.compile(r"^[rwa]((t?\+?)|(\+?t?))$")


# readonly actually uses copyonwrite for mmap so that readonly without mmap and
# with mmap still have to same behavior with regard to updating the array.  To
# get a truly readonly mmap use denywrite
# the name 'denywrite' comes from a deprecated flag to mmap() on Linux--it
# should be clarified that 'denywrite' mode is not directly analogous to the
# use of that flag; it was just taken, for lack of anything better, as a name
# that means something like "read only" but isn't readonly.
MEMMAP_MODES = {
    "readonly": mmap.ACCESS_COPY,
    "copyonwrite": mmap.ACCESS_COPY,
    "update": mmap.ACCESS_WRITE,
    "append": mmap.ACCESS_COPY,
    "denywrite": mmap.ACCESS_READ,
}

# TODO: Eventually raise a warning, and maybe even later disable the use of
# 'copyonwrite' and 'denywrite' modes unless memmap=True.  For now, however,
# that would generate too many warnings for too many users.  If nothing else,
# wait until the new logging system is in place.

GZIP_MAGIC = b"\x1f\x8b\x08"
PKZIP_MAGIC = b"\x50\x4b\x03\x04"
BZIP2_MAGIC = b"\x42\x5a"
LZMA_MAGIC = b"\xfd7zXZ\x00"
LZW_MAGIC = b"\x1f\x9d"























def _normalize_fits_mode(mode):
    if mode is not None and mode not in IO_FITS_MODES:
        if TEXT_RE.match(mode):
            raise ValueError(
                f"Text mode '{mode}' not supported: files must be opened in binary mode"
            )
        new_mode = FILE_MODES.get(mode)
        if new_mode not in IO_FITS_MODES:
            raise ValueError(f"Mode '{mode}' not recognized")
        mode = new_mode
    return mode


class _File:
    """
    Represents a FITS file on disk (or in some other file-like object).
    """




































































































































# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
``fitsheader`` is a command line script based on astropy.io.fits for printing
the header(s) of one or more FITS file(s) to the standard output in a human-
readable format.

Example uses of fitsheader:

1. Print the header of all the HDUs of a .fits file::

    $ fitsheader filename.fits

2. Print the header of the third and fifth HDU extension::

    $ fitsheader --extension 3 --extension 5 filename.fits

3. Print the header of a named extension, e.g. select the HDU containing
   keywords EXTNAME='SCI' and EXTVER='2'::

    $ fitsheader --extension "SCI,2" filename.fits

4. Print only specific keywords::

    $ fitsheader --keyword BITPIX --keyword NAXIS filename.fits

5. Print keywords NAXIS, NAXIS1, NAXIS2, etc using a wildcard::

    $ fitsheader --keyword NAXIS* filename.fits

6. Dump the header keywords of all the files in the current directory into a
   machine-readable csv file::

    $ fitsheader --table ascii.csv *.fits > keywords.csv

7. Specify hierarchical keywords with the dotted or spaced notation::

    $ fitsheader --keyword ESO.INS.ID filename.fits
    $ fitsheader --keyword "ESO INS ID" filename.fits

8. Compare the headers of different fits files, following ESO's ``fitsort``
   format::

    $ fitsheader --fitsort --extension 0 --keyword ESO.INS.ID *.fits

9. Same as above, sorting the output along a specified keyword::

    $ fitsheader -f -s DATE-OBS -e 0 -k DATE-OBS -k ESO.INS.ID *.fits

10. Sort first by OBJECT, then DATE-OBS::

    $ fitsheader -f -s OBJECT -s DATE-OBS *.fits

Note that compressed images (HDUs of type
:class:`~astropy.io.fits.CompImageHDU`) really have two headers: a real
BINTABLE header to describe the compressed data, and a fake IMAGE header
representing the image that was compressed. Astropy returns the latter by
default. You must supply the ``--compressed`` option if you require the real
header that describes the compression.

With Astropy installed, please run ``fitsheader --help`` to see the full usage
documentation.
"""

import argparse
import sys

import numpy as np

from astropy import __version__, log
from astropy.io import fits
from astropy.io.fits import CompImageHDU

DESCRIPTION = """
Print the header(s) of a FITS file. Optional arguments allow the desired
extension(s), keyword(s), and output format to be specified.
Note that in the case of a compressed image, the decompressed header is
shown by default.

This script is part of the Astropy package. See
https://docs.astropy.org/en/latest/io/fits/usage/scripts.html#module-astropy.io.fits.scripts.fitsheader
for further documentation.
""".strip()


class ExtensionNotFoundException(Exception):
    """Raised if an HDU extension requested by the user does not exist."""


class HeaderFormatter:
    """Class to format the header(s) of a FITS file for display by the
    `fitsheader` tool; essentially a wrapper around a `HDUList` object.

    Example usage:
    fmt = HeaderFormatter('/path/to/file.fits')
    print(fmt.parse(extensions=[0, 3], keywords=['NAXIS', 'BITPIX']))

    Parameters
    ----------
    filename : str
        Path to a single FITS file.
    verbose : bool
        Verbose flag, to show more information about missing extensions,
        keywords, etc.

    Raises
    ------
    OSError
        If `filename` does not exist or cannot be read.
    """






    def parse(self, extensions=None, keywords=None, compressed=False):
        """Returns the FITS file header(s) in a readable format.

        Parameters
        ----------
        extensions : list of int or str, optional
            Format only specific HDU(s), identified by number or name.
            The name can be composed of the "EXTNAME" or "EXTNAME,EXTVER"
            keywords.

        keywords : list of str, optional
            Keywords for which the value(s) should be returned.
            If not specified, then the entire header is returned.

        compressed : bool, optional
            If True, shows the header describing the compression, rather than
            the header obtained after decompression. (Affects FITS files
            containing `CompImageHDU` extensions only.)

        Returns
        -------
        formatted_header : str or astropy.table.Table
            Traditional 80-char wide format in the case of `HeaderFormatter`;
            an Astropy Table object in the case of `TableHeaderFormatter`.
        """
        # `hdukeys` will hold the keys of the HDUList items to display
        if extensions is None:
            hdukeys = range(len(self._hdulist))  # Display all by default
        else:
            hdukeys = []
            for ext in extensions:
                try:
                    # HDU may be specified by number
                    hdukeys.append(int(ext))
                except ValueError:
                    # The user can specify "EXTNAME" or "EXTNAME,EXTVER"
                    parts = ext.split(",")
                    if len(parts) > 1:
                        extname = ",".join(parts[0:-1])
                        extver = int(parts[-1])
                        hdukeys.append((extname, extver))
                    else:
                        hdukeys.append(ext)

        # Having established which HDUs the user wants, we now format these:
        return self._parse_internal(hdukeys, keywords, compressed)

    def _parse_internal(self, hdukeys, keywords, compressed):
        """The meat of the formatting; in a separate method to allow overriding."""
        result = []
        for idx, hdu in enumerate(hdukeys):
            try:
                cards = self._get_cards(hdu, keywords, compressed)
            except ExtensionNotFoundException:
                continue

            if idx > 0:  # Separate HDUs by a blank line
                result.append("\n")
            result.append(f"# HDU {hdu} in {self.filename}:\n")
            for c in cards:
                result.append(f"{c}\n")
        return "".join(result)

    def _get_cards(self, hdukey, keywords, compressed):
        """Returns a list of `astropy.io.fits.card.Card` objects.
279:        self._updateindices(idx, increment=False)

            if require_full_cardlength:
                if next_image == end_card:
                    image = []
                    break
            else:
                if next_image.split(sep)[0].rstrip() == END:
                    image = []
                    break

            image = [next_image]

        # Add the last image that was found before the end, if any
        if image:
            cards.append(Card.fromstring(empty.join(image)))

        return cls._fromcards(cards)

    @classmethod
    def fromfile(cls, fileobj, sep="", endcard=True, padding=True):
        """
        Similar to :meth:`Header.fromstring`, but reads the header string from
        a given file-like object or filename.

        Parameters
        ----------
        fileobj : str, file-like
            A filename or an open file-like object from which a FITS header is
            to be read.  For open file handles the file pointer must be at the
            beginning of the header.

        sep : str, optional
            The string separating cards from each other, such as a newline.  By
            default there is no card separator (as is the case in a raw FITS
            file).

        endcard : bool, optional
            If True (the default) the header must end with an END card in order
            to be considered valid.  If an END card is not found an
            `OSError` is raised.

        padding : bool, optional
            If True (the default) the header will be required to be padded out
            to a multiple of 2880, the FITS header block size.  Otherwise any
            padding, or lack thereof, is ignored.

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        close_file = False

        if isinstance(fileobj, path_like):
            # If sep is non-empty we are trying to read a header printed to a
            # text file, so open in text mode by default to support newline
            # handling; if a binary-mode file object is passed in, the user is
            # then on their own w.r.t. newline handling.
            #
            # Otherwise assume we are reading from an actual FITS file and open
            # in binary mode.
            fileobj = os.path.expanduser(fileobj)
            if sep:
                fileobj = open(fileobj, encoding="latin1")
            else:
                fileobj = open(fileobj, "rb")

            close_file = True

        try:
            is_binary = fileobj_is_binary(fileobj)

            def block_iter(nbytes):
                while True:
                    data = fileobj.read(nbytes)

                    if data:
                        yield data
                    else:
                        break

            return cls._from_blocks(block_iter, is_binary, sep, endcard, padding)[1]
        finally:
            if close_file:
                fileobj.close()

    Parameters
    ----------
    filename : path-like or file-like
        File to write to.  If opened, must be opened for update (rb+) unless it
        is a new file, then it must be opened for append (ab+).  A file or
        `~gzip.GzipFile` object opened for update will be closed after return.

    data : array, :class:`~astropy.table.Table`, or `~astropy.io.fits.Group`
        The new data used for appending.

    header : `Header` object, optional
        The header associated with ``data``.  If `None`, an appropriate header
        will be created for the data object supplied.

    checksum : bool, optional
        When `True` adds both ``DATASUM`` and ``CHECKSUM`` cards to the header
        of the HDU when written to the file.

    verify : bool, optional
        When `True`, the existing FITS file will be read in to verify it for
        correctness before appending.  When `False`, content is simply appended
        to the end of the file.  Setting ``verify`` to `False` can be much
        faster.

    **kwargs
        Additional arguments are passed to:

        - `~astropy.io.fits.writeto` if the file does not exist or is empty.
          In this case ``output_verify`` is the only possible argument.
        - `~astropy.io.fits.open` if ``verify`` is True or if ``filename``
          is a file object.
        - Otherwise no additional arguments can be used.

    """
    if isinstance(filename, path_like):
        filename = os.path.expanduser(filename)
    name, closed, noexist_or_empty = _stat_filename_or_fileobj(filename)

    if noexist_or_empty:
        #
        # The input file or file like object either doesn't exits or is
        # empty.  Use the writeto convenience function to write the
        # output to the empty object.
        #
        writeto(filename, data, header, checksum=checksum, **kwargs)
    else:
        hdu = _makehdu(data, header)

        if isinstance(hdu, PrimaryHDU):
            hdu = ImageHDU(data, header)

        if verify or not closed:
            f = fitsopen(filename, mode="append", **kwargs)
            try:
                f.append(hdu)

          used to represent the case where no value is provided.

        - **hfile:** Each line of the header parameters file provides the
          definition of a single HDU header card as represented by the card
          image.
      """
    )

    def dump(self, datafile=None, cdfile=None, hfile=None, overwrite=False):
        """
        Dump the table HDU to a file in ASCII format.  The table may be dumped
        in three separate files, one containing column definitions, one
        containing header parameters, and one for table data.

        Parameters
        ----------
        datafile : path-like or file-like, optional
            Output data file.  The default is the root name of the
            fits file associated with this HDU appended with the
            extension ``.txt``.

        cdfile : path-like or file-like, optional
            Output column definitions file.  The default is `None`, no
            column definitions output is produced.

        hfile : path-like or file-like, optional
            Output header parameters file.  The default is `None`,
            no header parameters output is produced.

        overwrite : bool, optional
            If ``True``, overwrite the output file if it exists. Raises an
            ``OSError`` if ``False`` and the output file exists. Default is
            ``False``.

        Notes
        -----
        The primary use for the `dump` method is to allow viewing and editing
        the table data and parameters in a standard text editor.
        The `load` method can be used to create a new table from the three
        plain text (ASCII) files.
        """
        if isinstance(datafile, path_like):
            datafile = os.path.expanduser(datafile)
        if isinstance(cdfile, path_like):
            cdfile = os.path.expanduser(cdfile)
        if isinstance(hfile, path_like):
            hfile = os.path.expanduser(hfile)
        # check if the output files already exist
        exist = []
        files = [datafile, cdfile, hfile]

        for f in files:
            if isinstance(f, path_like):
                if os.path.exists(f) and os.path.getsize(f) != 0:
                    if overwrite:
                        os.remove(f)
                    else:
                        exist.append(f)

        if exist:
            raise OSError(
                "  ".join([f"File '{f}' already exists." for f in exist])
                + "  If you mean to replace the file(s) then use the argument "
                "'overwrite=True'."
            )

        # Process the data
        self._dump_data(datafile)

        # Process the column definitions
        if cdfile:
            self._dump_coldefs(cdfile)

        # Process the header parameters
        if hfile:
            self._header.tofile(hfile, sep="\n", endcard=False, padding=False)

    if isinstance(dump.__doc__, str):
        dump.__doc__ += _tdump_file_format.replace("\n", "\n        ")

    def load(cls, datafile, cdfile=None, hfile=None, replace=False, header=None):
        """
        Create a table from the input ASCII files.  The input is from up to
        three separate files, one containing column definitions, one containing
        header parameters, and one containing column data.

        The column definition and header parameters files are not required.
        When absent the column definitions and/or header parameters are taken
        from the header object given in the header argument; otherwise sensible
        defaults are inferred (though this mode is not recommended).

        Parameters
        ----------
        datafile : path-like or file-like
            Input data file containing the table data in ASCII format.

        cdfile : path-like or file-like, optional
            Input column definition file containing the names,
            formats, display formats, physical units, multidimensional
            array dimensions, undefined values, scale factors, and
            offsets associated with the columns in the table.  If
            `None`, the column definitions are taken from the current
            values in this object.

        hfile : path-like or file-like, optional
            Input parameter definition file containing the header
            parameter definitions to be associated with the table.  If
            `None`, the header parameter definitions are taken from
            the current values in this objects header.

        replace : bool, optional
            When `True`, indicates that the entire header should be
            replaced with the contents of the ASCII file instead of
            just updating the current header.

        header : `~astropy.io.fits.Header`, optional
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,380p' astropy/io/fits/header.py; sed -n '380,900p' astropy/io/fits/header.py; sed -n '1135,1320p' astropy/io/fits/hdu/table.py; sed -n '180,520p' astropy/io/fits/file.py; sed -n '180,520p' astropy/io/fits/scripts/fitsheader.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import collections
import copy
import itertools
import numbers
import os
import re
import warnings

import numpy as np

from astropy.utils.exceptions import AstropyUserWarning

from ._utils import parse_header
from .card import KEYWORD_LENGTH, UNDEFINED, Card, _pad
from .file import _File
from .util import decode_ascii, encode_ascii, fileobj_is_binary, path_like







BLOCK_SIZE = 2880  # the FITS block size

# This regular expression can match a *valid* END card which just consists of
# the string 'END' followed by all spaces, or an *invalid* end card which
# consists of END, followed by any character that is *not* a valid character
# for a valid FITS keyword (that is, this is not a keyword like 'ENDER' which
# starts with 'END' but is not 'END'), followed by any arbitrary bytes.  An
# invalid end card may also consist of just 'END' with no trailing bytes.
HEADER_END_RE = re.compile(
    encode_ascii(r"(?:(?P<valid>END {77}) *)|(?P<invalid>END$|END {0,76}[^A-Z0-9_-])")
)


# According to the FITS standard the only characters that may appear in a
# header record are the restricted ASCII chars from 0x20 through 0x7E.
VALID_HEADER_CHARS = set(map(chr, range(0x20, 0x7F)))
END_CARD = "END" + " " * 77

_commentary_keywords = Card._commentary_keywords

__doctest_skip__ = [
    "Header",
    "Header.comments",
    "Header.fromtextfile",
    "Header.totextfile",
    "Header.update",
]


class Header:
    """
    FITS header class.  This class exposes both a dict-like interface and a
    list-like interface to FITS headers.

    The header may be indexed by keyword and, like a dict, the associated value
    will be returned.  When the header contains cards with duplicate keywords,
    only the value of the first card with the given keyword will be returned.
    It is also possible to use a 2-tuple as the index in the form (keyword,
    n)--this returns the n-th value with that keyword, in the case where there
    are duplicate keywords.

    For example::

        >>> header['NAXIS']
        0
        >>> header[('FOO', 1)]  # Return the value of the second FOO keyword
        'foo'

    The header may also be indexed by card number::

        >>> header[0]  # Return the value of the first card in the header
        'T'

    Commentary keywords such as HISTORY and COMMENT are special cases: When
    indexing the Header object with either 'HISTORY' or 'COMMENT' a list of all
    the HISTORY/COMMENT values is returned::

        >>> header['HISTORY']
        This is the first history entry in this header.
        This is the second history entry in this header.
        ...

    See the Astropy documentation for more details on working with headers.

    Notes
    -----
    Although FITS keywords must be exclusively upper case, retrieving an item
    in a `Header` object is case insensitive.
    """

    def __init__(self, cards=[], copy=False):
        """
        Construct a `Header` from an iterable and/or text file.

        Parameters
        ----------
        cards : list of `Card`, optional
            The cards to initialize the header with. Also allowed are other
            `Header` (or `dict`-like) objects.

            .. versionchanged:: 1.2
                Allowed ``cards`` to be a `dict`-like object.

        copy : bool, optional

            If ``True`` copies the ``cards`` if they were another `Header`
            instance.
            Default is ``False``.

            .. versionadded:: 1.3
        """
        self.clear()

        if isinstance(cards, Header):
            if copy:
                cards = cards.copy()
            cards = cards.cards
        elif isinstance(cards, dict):
            cards = cards.items()

        for card in cards:
            self.append(card, end=True)

        self._modified = False

    def __len__(self):
        return len(self._cards)

    def __iter__(self):
        for card in self._cards:
            yield card.keyword

    def __contains__(self, keyword):
        if keyword in self._keyword_indices or keyword in self._rvkc_indices:
            # For the most common case (single, standard form keyword lookup)
            # this will work and is an O(1) check.  If it fails that doesn't
            # guarantee absence, just that we have to perform the full set of
            # checks in self._cardindex
            return True
        try:
            self._cardindex(keyword)
        except (KeyError, IndexError):
            return False
        return True

    def __getitem__(self, key):
        if isinstance(key, slice):
            return self.__class__([copy.copy(c) for c in self._cards[key]])
        elif self._haswildcard(key):
            return self.__class__(
                [copy.copy(self._cards[idx]) for idx in self._wildcardmatch(key)]
            )
        elif isinstance(key, str):
            key = key.strip()
            if key.upper() in _commentary_keywords:
                key = key.upper()
                # Special case for commentary cards
                return _HeaderCommentaryCards(self, key)

        if isinstance(key, tuple):
            keyword = key[0]
        else:
            keyword = key

        card = self._cards[self._cardindex(key)]

        if card.field_specifier is not None and keyword == card.rawkeyword:
            # This is RVKC; if only the top-level keyword was specified return
            # the raw value, not the parsed out float value
            return card.rawvalue

        value = card.value
        if value == UNDEFINED:
            return None
        return value

    def __setitem__(self, key, value):
        if self._set_slice(key, value, self):
            return

        if isinstance(value, tuple):
            if len(value) > 2:
                raise ValueError(
                    "A Header item may be set with either a scalar value, "
                    "a 1-tuple containing a scalar value, or a 2-tuple "
                    "containing a scalar value and comment string."
                )
            if len(value) == 1:
                value, comment = value[0], None
                if value is None:
                    value = UNDEFINED
            elif len(value) == 2:
                value, comment = value
                if value is None:
                    value = UNDEFINED
                if comment is None:
                    comment = ""
        else:
            comment = None

        card = None
        if isinstance(key, numbers.Integral):
            card = self._cards[key]
        elif isinstance(key, tuple):
            card = self._cards[self._cardindex(key)]
        if value is None:
            value = UNDEFINED
        if card:
            card.value = value
            if comment is not None:
                card.comment = comment
            if card._modified:
                self._modified = True
        else:
            # If we get an IndexError that should be raised; we don't allow
            # assignment to non-existing indices
            self._update((key, value, comment))

    def __delitem__(self, key):
        if isinstance(key, slice) or self._haswildcard(key):
            # This is very inefficient but it's not a commonly used feature.
            # If someone out there complains that they make heavy use of slice
            # deletions and it's too slow, well, we can worry about it then
            # [the solution is not too complicated--it would be wait 'til all
            # the cards are deleted before updating _keyword_indices rather
            # than updating it once for each card that gets deleted]
            if isinstance(key, slice):
                indices = range(*key.indices(len(self)))
                # If the slice step is backwards we want to reverse it, because
                # it will be reversed in a few lines...
                if key.step and key.step < 0:
                    indices = reversed(indices)
            else:
                indices = self._wildcardmatch(key)
            for idx in reversed(indices):
                del self[idx]
            return
        elif isinstance(key, str):
            # delete ALL cards with the same keyword name
            key = Card.normalize_keyword(key)
            indices = self._keyword_indices
            if key not in self._keyword_indices:
                indices = self._rvkc_indices

            if key not in indices:
                # if keyword is not present raise KeyError.
                # To delete keyword without caring if they were present,
                # Header.remove(Keyword) can be used with optional argument ignore_missing as True
                raise KeyError(f"Keyword '{key}' not found.")

            for idx in reversed(indices[key]):
                # Have to copy the indices list since it will be modified below
                del self[idx]
            return

        idx = self._cardindex(key)
        card = self._cards[idx]
        keyword = card.keyword
        del self._cards[idx]
        keyword = Card.normalize_keyword(keyword)
        indices = self._keyword_indices[keyword]
        indices.remove(idx)
        if not indices:
            del self._keyword_indices[keyword]

        # Also update RVKC indices if necessary :/
        if card.field_specifier is not None:
            indices = self._rvkc_indices[card.rawkeyword]
            indices.remove(idx)
            if not indices:
                del self._rvkc_indices[card.rawkeyword]

        # We also need to update all other indices
        self._updateindices(idx, increment=False)
        self._modified = True

    def __repr__(self):
        return self.tostring(sep="\n", endcard=False, padding=False)

    def __str__(self):
        return self.tostring()

    def __eq__(self, other):
        """
        Two Headers are equal only if they have the exact same string
        representation.
        """
        return str(self) == str(other)

    def __add__(self, other):
        temp = self.copy(strip=False)
        temp.extend(other)
        return temp

    def __iadd__(self, other):
        self.extend(other)
        return self

    def _ipython_key_completions_(self):
        return self.__iter__()

    @property
    def cards(self):
        """
        The underlying physical cards that make up this Header; it can be
        looked at, but it should not be modified directly.
        """
        return _CardAccessor(self)


















    @property
    def _modified(self):
        """
        Whether or not the header has been modified; this is a property so that
        it can also check each card for modifications--cards may have been
        modified directly without the header containing it otherwise knowing.
        """
        modified_cards = any(c._modified for c in self._cards)
        if modified_cards:
            # If any cards were modified then by definition the header was
            # modified
            self.__dict__["_modified"] = True

        return self.__dict__["_modified"]

    @_modified.setter
    def _modified(self, val):
        self.__dict__["_modified"] = val

    @classmethod
    def fromstring(cls, data, sep=""):
        """
        Creates an HDU header from a byte string containing the entire header
        data.

        Parameters
        ----------
        data : str or bytes
           String or bytes containing the entire header.  In the case of bytes
           they will be decoded using latin-1 (only plain ASCII characters are
           allowed in FITS headers but latin-1 allows us to retain any invalid
           bytes that might appear in malformatted FITS files).

        sep : str, optional
            The string separating cards from each other, such as a newline.  By
            default there is no card separator (as is the case in a raw FITS
            file).  In general this is only used in cases where a header was
            printed as text (e.g. with newlines after each card) and you want
            to create a new `Header` from it by copy/pasting.

        Examples
        --------
        >>> from astropy.io.fits import Header
        >>> hdr = Header({'SIMPLE': True})
        >>> Header.fromstring(hdr.tostring()) == hdr
        True

        If you want to create a `Header` from printed text it's not necessary
        to have the exact binary structure as it would appear in a FITS file,
        to have the exact binary structure as it would appear in a FITS file,
        with the full 80 byte card length.  Rather, each "card" can end in a
        newline and does not have to be padded out to a full card length as
        long as it "looks like" a FITS header:

        >>> hdr = Header.fromstring(\"\"\"\\
        ... SIMPLE  =                    T / conforms to FITS standard
        ... BITPIX  =                    8 / array data type
        ... NAXIS   =                    0 / number of array dimensions
        ... EXTEND  =                    T
        ... \"\"\", sep='\\n')
        >>> hdr['SIMPLE']
        True
        >>> hdr['BITPIX']
        8
        >>> len(hdr)
        4

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        cards = []

        # If the card separator contains characters that may validly appear in
        # a card, the only way to unambiguously distinguish between cards is to
        # require that they be Card.length long.  However, if the separator
        # contains non-valid characters (namely \n) the cards may be split
        # immediately at the separator
        require_full_cardlength = set(sep).issubset(VALID_HEADER_CHARS)

        if isinstance(data, bytes):
            # FITS supports only ASCII, but decode as latin1 and just take all
            # bytes for now; if it results in mojibake due to e.g. UTF-8
            # encoded data in a FITS header that's OK because it shouldn't be
            # there in the first place--accepting it here still gives us the
            # opportunity to display warnings later during validation
            CONTINUE = b"CONTINUE"
            END = b"END"
            end_card = END_CARD.encode("ascii")
            sep = sep.encode("latin1")
            empty = b""
        else:
            CONTINUE = "CONTINUE"
            END = "END"
            end_card = END_CARD
            empty = ""

        # Split the header into individual cards
        idx = 0
        image = []

        while idx < len(data):
            if require_full_cardlength:
                end_idx = idx + Card.length
            else:
                try:
                    end_idx = data.index(sep, idx)
                except ValueError:
                    end_idx = len(data)

            next_image = data[idx:end_idx]
            idx = end_idx + len(sep)

            if image:
                if next_image[:8] == CONTINUE:
                    image.append(next_image)
                    continue
                cards.append(Card.fromstring(empty.join(image)))

            if require_full_cardlength:
                if next_image == end_card:
                    image = []
                    break
            else:
                if next_image.split(sep)[0].rstrip() == END:
                    image = []
                    break

            image = [next_image]

        # Add the last image that was found before the end, if any
        if image:
            cards.append(Card.fromstring(empty.join(image)))

        return cls._fromcards(cards)

    @classmethod
    def fromfile(cls, fileobj, sep="", endcard=True, padding=True):
        """
        Similar to :meth:`Header.fromstring`, but reads the header string from
        a given file-like object or filename.

        Parameters
        ----------
        fileobj : str, file-like
            A filename or an open file-like object from which a FITS header is
            to be read.  For open file handles the file pointer must be at the
            beginning of the header.

        sep : str, optional
            The string separating cards from each other, such as a newline.  By
            default there is no card separator (as is the case in a raw FITS
            file).

        endcard : bool, optional
            If True (the default) the header must end with an END card in order
            to be considered valid.  If an END card is not found an
            `OSError` is raised.

        padding : bool, optional
            If True (the default) the header will be required to be padded out
            to a multiple of 2880, the FITS header block size.  Otherwise any
            padding, or lack thereof, is ignored.

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        close_file = False

        if isinstance(fileobj, path_like):
            # If sep is non-empty we are trying to read a header printed to a
            # text file, so open in text mode by default to support newline
            # handling; if a binary-mode file object is passed in, the user is
            # then on their own w.r.t. newline handling.
            #
            # Otherwise assume we are reading from an actual FITS file and open
            # in binary mode.
            fileobj = os.path.expanduser(fileobj)
            if sep:
                fileobj = open(fileobj, encoding="latin1")
            else:
                fileobj = open(fileobj, "rb")

            close_file = True

        try:
            is_binary = fileobj_is_binary(fileobj)

            def block_iter(nbytes):
                while True:
                    data = fileobj.read(nbytes)

                    if data:
                        yield data
                    else:
                        break

            return cls._from_blocks(block_iter, is_binary, sep, endcard, padding)[1]
        finally:
            if close_file:
                fileobj.close()

    @classmethod
    def _fromcards(cls, cards):
        header = cls()
        for idx, card in enumerate(cards):
            header._cards.append(card)
            keyword = Card.normalize_keyword(card.keyword)
            header._keyword_indices[keyword].append(idx)
            if card.field_specifier is not None:
                header._rvkc_indices[card.rawkeyword].append(idx)

        header._modified = False
        return header

    @classmethod
    def _from_blocks(cls, block_iter, is_binary, sep, endcard, padding):
        """
        The meat of `Header.fromfile`; in a separate method so that
        `Header.fromfile` itself is just responsible for wrapping file
        handling.  Also used by `_BaseHDU.fromstring`.

        ``block_iter`` should be a callable which, given a block size n
        (typically 2880 bytes as used by the FITS standard) returns an iterator
        of byte strings of that block size.

        ``is_binary`` specifies whether the returned blocks are bytes or text

        Returns both the entire header *string*, and the `Header` object
        returned by Header.fromstring on that string.
        """
        actual_block_size = _block_size(sep)
        clen = Card.length + len(sep)

        blocks = block_iter(actual_block_size)

        # Read the first header block.
        try:
            block = next(blocks)
        except StopIteration:
            raise EOFError()

        if not is_binary:
            # TODO: There needs to be error handling at *this* level for
            # non-ASCII characters; maybe at this stage decoding latin-1 might
            # be safer
            block = encode_ascii(block)

        read_blocks = []
        is_eof = False
        end_found = False

        # continue reading header blocks until END card or EOF is reached
        while True:
            # find the END card
            end_found, block = cls._find_end_card(block, clen)

            read_blocks.append(decode_ascii(block))

            if end_found:
                break

            try:
                block = next(blocks)
            except StopIteration:
                is_eof = True
                break

            if not block:
                is_eof = True
                break

            if not is_binary:
                block = encode_ascii(block)

        header_str = "".join(read_blocks)
        _check_padding(header_str, actual_block_size, is_eof, check_block_size=padding)

        if not end_found and is_eof and endcard:
            # TODO: Pass this error to validation framework as an ERROR,
            # rather than raising an exception
            raise OSError("Header missing END card.")

        return header_str, cls.fromstring(header_str, sep=sep)

    @classmethod
    def _find_end_card(cls, block, card_len):
        """
        Utility method to search a header block for the END card and handle
        invalid END cards.

        This method can also returned a modified copy of the input header block
        in case an invalid end card needs to be sanitized.
        """
        for mo in HEADER_END_RE.finditer(block):
            # Ensure the END card was found, and it started on the
            # boundary of a new card (see ticket #142)
            if mo.start() % card_len != 0:
                continue

            # This must be the last header block, otherwise the
            # file is malformatted
            if mo.group("invalid"):
                offset = mo.start()
                trailing = block[offset + 3 : offset + card_len - 3].rstrip()
                if trailing:
                    trailing = repr(trailing).lstrip("ub")
                    # TODO: Pass this warning up to the validation framework
                    warnings.warn(
                        f"Unexpected bytes trailing END keyword: {trailing}; these "
                        "bytes will be replaced with spaces on write.",
                        AstropyUserWarning,
                    )
                else:
                    # TODO: Pass this warning up to the validation framework
                    warnings.warn(
                        "Missing padding to end of the FITS block after the "
                        "END keyword; additional spaces will be appended to "
                        f"the file upon writing to pad out to {BLOCK_SIZE} bytes.",
                        AstropyUserWarning,
                    )

                # Sanitize out invalid END card now that the appropriate
                # warnings have been issued
                block = (
                    block[:offset]
                    + encode_ascii(END_CARD)
                    + block[offset + len(END_CARD) :]
                )

            return True, block

        return False, block

    def tostring(self, sep="", endcard=True, padding=True):
        r"""
        Returns a string representation of the header.

        By default this uses no separator between cards, adds the END card, and
        pads the string with spaces to the next multiple of 2880 bytes.  That
        is, it returns the header exactly as it would appear in a FITS file.

        Parameters
        ----------
        sep : str, optional
            The character or string with which to separate cards.  By default
            there is no separator, but one could use ``'\\n'``, for example, to
            separate each card with a new line

        endcard : bool, optional
            If True (default) adds the END card to the end of the header
            string

        padding : bool, optional
            If True (default) pads the string with spaces out to the next
            multiple of 2880 characters

        Returns
        -------
        str
            A string representing a FITS header.
        """
        lines = []
        for card in self._cards:
            s = str(card)
            # Cards with CONTINUE cards may be longer than 80 chars; so break
            # them into multiple lines
            while s:
                lines.append(s[: Card.length])
                s = s[Card.length :]

        s = sep.join(lines)
        if endcard:
            s += sep + _pad("END")
        if padding:
            s += " " * _pad_length(len(s))
        return s






































































    def totextfile(self, fileobj, endcard=False, overwrite=False):
        """
        Write the header as text to a file or a file-like object.

        Equivalent to::

            >>> Header.tofile(fileobj, sep='\\n', endcard=False,
            ...               padding=False, overwrite=overwrite)

        See Also
        --------
        tofile
        """
        self.tofile(
            fileobj, sep="\n", endcard=endcard, padding=False, overwrite=overwrite
        )

    def clear(self):
        """
        Remove all cards from the header.
        """
        self._cards = []
        self._keyword_indices = collections.defaultdict(list)
        self._rvkc_indices = collections.defaultdict(list)

    def copy(self, strip=False):
        """
        Make a copy of the :class:`Header`.

        .. versionchanged:: 1.3
            `copy.copy` and `copy.deepcopy` on a `Header` will call this
            method.

        Parameters
        ----------
        strip : bool, optional
            If `True`, strip any headers that are specific to one of the
            standard HDU types, so that this header can be used in a different
            HDU.

        Returns
        -------
        `Header`
            A new :class:`Header` instance.
        """
        tmp = self.__class__(copy.copy(card) for card in self._cards)
        if strip:
            tmp.strip()
        return tmp

    def __copy__(self):
        return self.copy()

    def __deepcopy__(self, *args, **kwargs):
        return self.copy()

    @classmethod
    def fromkeys(cls, iterable, value=None):
        """
        Similar to :meth:`dict.fromkeys`--creates a new `Header` from an
        iterable of keywords and an optional default value.

        This method is not likely to be particularly useful for creating real
        world FITS headers, but it is useful for testing.

        Parameters
        ----------
        iterable
            Any iterable that returns strings representing FITS keywords.

        value : optional
            A default value to assign to each keyword; must be a valid type for
            FITS keywords.

        Returns
        -------
        `Header`
            A new `Header` instance.
        """
        d = cls()
        if not isinstance(value, tuple):
            value = (value,)
        for key in iterable:
            d.append((key,) + value)
        return d

    def get(self, key, default=None):
        """
        Similar to :meth:`dict.get`--returns the value associated with keyword
        in the header, or a default value if the keyword is not found.

        Parameters
        ----------
        key : str
            A keyword that may or may not be in the header.

        default : optional
            A default value to return if the keyword is not found in the
            header.

        Returns
        -------
        value: str, number, complex, bool, or ``astropy.io.fits.card.Undefined``
            The value associated with the given keyword, or the default value
            if the keyword is not in the header.
        """
        try:
            return self[key]
        except (KeyError, IndexError):
            return default

    def set(self, keyword, value=None, comment=None, before=None, after=None):
        """
        Set the value and/or comment and/or position of a specified keyword.

        If the keyword does not already exist in the header, a new keyword is
        created in the specified position, or appended to the end of the header
        if no position is specified.

        This method is similar to :meth:`Header.update` prior to Astropy v0.1.
        header : `~astropy.io.fits.Header`, optional
            When the cdfile and hfile are missing, use this Header object in
            the creation of the new table and HDU.  Otherwise this Header
            supersedes the keywords from hfile, which is only used to update
            values not present in this Header, unless ``replace=True`` in which
            this Header's values are completely replaced with the values from
            hfile.

        Notes
        -----
        The primary use for the `load` method is to allow the input of ASCII
        data that was edited in a standard text editor of the table data and
        parameters.  The `dump` method can be used to create the initial ASCII
        files.
        """
        # Process the parameter file
        if header is None:
            header = Header()

        if hfile:
            if replace:
                header = Header.fromtextfile(hfile)
            else:
                header.extend(
                    Header.fromtextfile(hfile), update=True, update_first=True
                )

        coldefs = None
        # Process the column definitions file
        if cdfile:
            coldefs = cls._load_coldefs(cdfile)

        # Process the data file
        data = cls._load_data(datafile, coldefs)
        if coldefs is None:
            coldefs = ColDefs(data)

        # Create a new HDU using the supplied header and data
        hdu = cls(data=data, header=header)
        hdu.columns = coldefs
        return hdu

    if isinstance(load.__doc__, str):
        load.__doc__ += _tdump_file_format.replace("\n", "\n        ")

    load = classmethod(load)
    # Have to create a classmethod from this here instead of as a decorator;
    # otherwise we can't update __doc__

    def _dump_data(self, fileobj):
        """
        Write the table data in the ASCII format read by BinTableHDU.load()
        to fileobj.
        """
        if not fileobj and self._file:
            root = os.path.splitext(self._file.name)[0]
            fileobj = root + ".txt"

        close_file = False

        if isinstance(fileobj, str):
            fileobj = open(fileobj, "w")
            close_file = True

        linewriter = csv.writer(fileobj, dialect=FITSTableDumpDialect)

        # Process each row of the table and output one row at a time
        def format_value(val, format):
            if format[0] == "S":
                itemsize = int(format[1:])
                return "{:{size}}".format(val, size=itemsize)
            elif format in np.typecodes["AllInteger"]:
                # output integer
                return f"{val:21d}"
            elif format in np.typecodes["Complex"]:
                return f"{val.real:21.15g}+{val.imag:.15g}j"
            elif format in np.typecodes["Float"]:
                # output floating point
                return f"{val:#21.15g}"

        for row in self.data:
            line = []  # the line for this row of the table

            # Process each column of the row.
            for column in self.columns:
                # format of data in a variable length array
                # where None means it is not a VLA:
                vla_format = None
                format = _convert_format(column.format)

                if isinstance(format, _FormatP):
                    # P format means this is a variable length array so output
                    # the length of the array for this row and set the format
                    # for the VLA data
                    line.append("VLA_Length=")
                    line.append(f"{len(row[column.name]):21d}")
                    _, dtype, option = _parse_tformat(column.format)
                    vla_format = FITS2NUMPY[option[0]][0]

                if vla_format:
                    # Output the data for each element in the array
                    for val in row[column.name].flat:
                        line.append(format_value(val, vla_format))
                else:
                    # The column data is a single element
                    dtype = self.data.dtype.fields[column.name][0]
                    array_format = dtype.char
                    if array_format == "V":
                        array_format = dtype.base.char
                    if array_format == "S":
                        array_format += str(dtype.itemsize)

                    if dtype.char == "V":
                        for value in row[column.name].flat:
                            line.append(format_value(value, array_format))
                    else:
                        line.append(format_value(row[column.name], array_format))
            linewriter.writerow(line)
        if close_file:
            fileobj.close()

    def _dump_coldefs(self, fileobj):
        """
        Write the column definition parameters in the ASCII format read by
        BinTableHDU.load() to fileobj.
        """
        close_file = False

        if isinstance(fileobj, str):
            fileobj = open(fileobj, "w")
            close_file = True

        # Process each column of the table and output the result to the
        # file one at a time
        for column in self.columns:
            line = [column.name, column.format]
            attrs = ["disp", "unit", "dim", "null", "bscale", "bzero"]
            line += [
                "{!s:16s}".format(value if value else '""')
                for value in (getattr(column, attr) for attr in attrs)
            ]
            fileobj.write(" ".join(line))
            fileobj.write("\n")

        if close_file:
            fileobj.close()

    @classmethod
    def _load_data(cls, fileobj, coldefs=None):
        """
        Read the table data from the ASCII file output by BinTableHDU.dump().
        """
        close_file = False

        if isinstance(fileobj, path_like):
            fileobj = os.path.expanduser(fileobj)
            fileobj = open(fileobj)
            close_file = True

        initialpos = fileobj.tell()  # We'll be returning here later
        linereader = csv.reader(fileobj, dialect=FITSTableDumpDialect)

        # First we need to do some preprocessing on the file to find out how
        # much memory we'll need to reserve for the table.  This is necessary
        # even if we already have the coldefs in order to determine how many
        # rows to reserve memory for
        vla_lengths = []
        recformats = []
        names = []
        nrows = 0
        if coldefs is not None:
            recformats = coldefs._recformats
            names = coldefs.names

        def update_recformats(value, idx):
            fitsformat = _scalar_to_format(value)
            recformat = _convert_format(fitsformat)
            if idx >= len(recformats):
                recformats.append(recformat)
            else:
                if _cmp_recformats(recformats[idx], recformat) < 0:
                    recformats[idx] = recformat

        # TODO: The handling of VLAs could probably be simplified a bit
        for row in linereader:
            nrows += 1























































































































    def __repr__(self):
        return f"<{self.__module__}.{self.__class__.__name__} {self._file}>"

    # Support the 'with' statement
    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        self.close()

    def readable(self):
        if self.writeonly:
            return False
        return isreadable(self._file)





































































































































    def writable(self):
        if self.readonly:
            return False
        return iswritable(self._file)







    def writearray(self, array):
        """
        Similar to file.write(), but writes a numpy array instead of a string.

        Also like file.write(), a flush() or close() may be needed before
        the file on disk reflects the data written.
        """
        if self.simulateonly:
            return
        if hasattr(self._file, "write"):
            _array_to_file(array, self._file)


























    def truncate(self, size=None):
        if hasattr(self._file, "truncate"):
            self._file.truncate(size)
























        """Returns a list of `astropy.io.fits.card.Card` objects.

        This function will return the desired header cards, taking into
        account the user's preference to see the compressed or uncompressed
        version.

        Parameters
        ----------
        hdukey : int or str
            Key of a single HDU in the HDUList.

        keywords : list of str, optional
            Keywords for which the cards should be returned.

        compressed : bool, optional
            If True, shows the header describing the compression.

        Raises
        ------
        ExtensionNotFoundException
            If the hdukey does not correspond to an extension.
        """
        # First we obtain the desired header
        try:
            if compressed and isinstance(self._hdulist[hdukey], CompImageHDU):
                # In the case of a compressed image, return the header before
                # decompression (not the default behavior)
                header = self._hdulist[hdukey]._bintable.header
            else:
                header = self._hdulist[hdukey].header
        except (IndexError, KeyError):
            message = f"{self.filename}: Extension {hdukey} not found."
            if self.verbose:
                log.warning(message)
            raise ExtensionNotFoundException(message)

        if not keywords:  # return all cards
            cards = header.cards
        else:  # specific keywords are requested
            cards = []
            for kw in keywords:
                try:
                    crd = header.cards[kw]
                    if isinstance(crd, fits.card.Card):  # Single card
                        cards.append(crd)
                    else:  # Allow for wildcard access
                        cards.extend(crd)
                except KeyError:  # Keyword does not exist
                    if self.verbose:
                        log.warning(
                            f"{self.filename} (HDU {hdukey}): Keyword {kw} not found."
                        )
        return cards





class TableHeaderFormatter(HeaderFormatter):
    """Class to convert the header(s) of a FITS file into a Table object.
    The table returned by the `parse` method will contain four columns:
    filename, hdu, keyword, and value.

    Subclassed from HeaderFormatter, which contains the meat of the formatting.
    """

    def _parse_internal(self, hdukeys, keywords, compressed):
        """Method called by the parse method in the parent class."""
        tablerows = []
        for hdu in hdukeys:
            try:
                for card in self._get_cards(hdu, keywords, compressed):
                    tablerows.append(
                        {
                            "filename": self.filename,
                            "hdu": hdu,
                            "keyword": card.keyword,
                            "value": str(card.value),
                        }
                    )
            except ExtensionNotFoundException:
                pass

        if tablerows:
            from astropy import table

            return table.Table(tablerows)
        return None


def print_headers_traditional(args):
    """Prints FITS header(s) using the traditional 80-char format.

    Parameters
    ----------
    args : argparse.Namespace
        Arguments passed from the command-line as defined below.
    """
    for idx, filename in enumerate(args.filename):  # support wildcards
        if idx > 0 and not args.keyword:
            print()  # print a newline between different files

        formatter = None
        try:
            formatter = HeaderFormatter(filename)
            print(
                formatter.parse(args.extensions, args.keyword, args.compressed), end=""
            )
        except OSError as e:
            log.error(str(e))
        finally:
            if formatter:
                formatter.close()


def print_headers_as_table(args):
    """Prints FITS header(s) in a machine-readable table format.

    Parameters
    ----------
    args : argparse.Namespace
        Arguments passed from the command-line as defined below.
    """
    tables = []
    # Create a Table object for each file
    for filename in args.filename:  # Support wildcards
        formatter = None
        try:
            formatter = TableHeaderFormatter(filename)
            tbl = formatter.parse(args.extensions, args.keyword, args.compressed)
            if tbl:
                tables.append(tbl)
        except OSError as e:
            log.error(str(e))  # file not found or unreadable
        finally:
            if formatter:
                formatter.close()

    # Concatenate the tables
    if len(tables) == 0:
        return False
    elif len(tables) == 1:
        resulting_table = tables[0]
    else:
        from astropy import table

        resulting_table = table.vstack(tables)
    # Print the string representation of the concatenated table
    resulting_table.write(sys.stdout, format=args.table)


def print_headers_as_comparison(args):
    """Prints FITS header(s) with keywords as columns.

    This follows the dfits+fitsort format.

    Parameters
    ----------
    args : argparse.Namespace
        Arguments passed from the command-line as defined below.
    """
    from astropy import table

    tables = []
    # Create a Table object for each file
    for filename in args.filename:  # Support wildcards
        formatter = None
        try:
            formatter = TableHeaderFormatter(filename, verbose=False)
            tbl = formatter.parse(args.extensions, args.keyword, args.compressed)
            if tbl:
                # Remove empty keywords
                tbl = tbl[np.where(tbl["keyword"] != "")]
            else:
                tbl = table.Table([[filename]], names=("filename",))
            tables.append(tbl)
        except OSError as e:
            log.error(str(e))  # file not found or unreadable
        finally:
            if formatter:
                formatter.close()

    # Concatenate the tables
    if len(tables) == 0:
        return False
    elif len(tables) == 1:
        resulting_table = tables[0]
    else:
        resulting_table = table.vstack(tables)

    # If we obtained more than one hdu, merge hdu and keywords columns
    hdus = resulting_table["hdu"]
    if np.ma.isMaskedArray(hdus):
        hdus = hdus.compressed()
    if len(np.unique(hdus)) > 1:
        for tab in tables:
            new_column = table.Column([f"{row['hdu']}:{row['keyword']}" for row in tab])
            tab.add_column(new_column, name="hdu+keyword")
        keyword_column_name = "hdu+keyword"
    else:
        keyword_column_name = "keyword"

    # Check how many hdus we are processing
    final_tables = []
    for tab in tables:
        final_table = [table.Column([tab["filename"][0]], name="filename")]
        if "value" in tab.colnames:
            for row in tab:
                if row["keyword"] in ("COMMENT", "HISTORY"):
                    continue
                final_table.append(
                    table.Column([row["value"]], name=row[keyword_column_name])
                )
        final_tables.append(table.Table(final_table))
    final_table = table.vstack(final_tables)
    # Sort if requested
    if args.sort:
        final_table.sort(args.sort)
    # Reorganise to keyword by columns
    final_table.pprint(max_lines=-1, max_width=-1)


def main(args=None):
    """This is the main function called by the `fitsheader` script."""
    parser = argparse.ArgumentParser(
        description=DESCRIPTION, formatter_class=argparse.RawDescriptionHelpFormatter
    )
    # TODO: pass suggest_on_error as kwarg when PYTHON_LT_14 is dropped
    parser.suggest_on_error = True

    parser.add_argument(
        "--version", action="version", version=f"%(prog)s {__version__}"
    )

    parser.add_argument(
        "-e",
        "--extension",
        metavar="HDU",
        action="append",
        dest="extensions",
        help=(
            "specify the extension by name or number; this argument can "
            "be repeated to select multiple extensions"
        ),
    )
    parser.add_argument(
        "-k",
        "--keyword",
        metavar="KEYWORD",
        action="append",
        type=str,
        help=(
            "specify a keyword; this argument can be repeated to select "
            "multiple keywords; also supports wildcards"
        ),
    )
    mode_group = parser.add_mutually_exclusive_group()
    mode_group.add_argument(
        "-t",
        "--table",
        nargs="?",
        default=False,
        metavar="FORMAT",
        help=(
            "print the header(s) in machine-readable table format; the "
            'default format is "ascii.fixed_width" (can be "ascii.csv", '
            '"ascii.html", "ascii.latex", "fits", etc)'
        ),
    )
    mode_group.add_argument(
        "-f",
        "--fitsort",
        action="store_true",
        help=(
            "print the headers as a table with each unique "
            "keyword in a given column (fitsort format) "
        ),
    )
    parser.add_argument(
        "-s",
        "--sort",
        metavar="SORT_KEYWORD",
        action="append",
        type=str,
        help=(
            "sort output by the specified header keywords, can be repeated to "
            "sort by multiple keywords; Only supported with -f/--fitsort"
        ),
    )
    parser.add_argument(
        "-c",
        "--compressed",
        action="store_true",
        help=(
            "for compressed image data, show the true header which describes "
            "the compression rather than the data"
        ),
    )
    parser.add_argument(
        "filename",
        nargs="+",
        help="path to one or more files; wildcards are supported",
    )
    args = parser.parse_args(args)

    # If `--table` was used but no format specified,
    # then use ascii.fixed_width by default
    if args.table is None:
        args.table = "ascii.fixed_width"

    if args.sort:
        args.sort = [key.replace(".", " ") for key in args.sort]
        if not args.fitsort:
            log.error(
                "Sorting with -s/--sort is only supported in conjunction with"
                " -f/--fitsort"
            )
            # 2: Unix error convention for command line syntax
            sys.exit(2)

    if args.keyword:
        args.keyword = [key.replace(".", " ") for key in args.keyword]

    # Now print the desired headers
    try:
        if args.table:
            print_headers_as_table(args)
        elif args.fitsort:
            print_headers_as_comparison(args)
        else:
            print_headers_traditional(args)
    except OSError:
        # A 'Broken pipe' OSError may occur when stdout is closed prematurely,
        # eg. when calling `fitsheader file.fits | head`. We let this pass.
        pass
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import ast
for fn in ['astropy/io/fits/file.py','astropy/io/fits/header.py','astropy/io/fits/scripts/fitsheader.py']:
 print('\\n',fn)
 m=ast.parse(open(fn).read())
 for n in ast.walk(m):
  if isinstance(n,(ast.ClassDef,ast.FunctionDef,ast.AsyncFunctionDef)) and (not isinstance(getattr(n,'parent',None),ast.FunctionDef)):
   if isinstance(n,ast.ClassDef): print('CLASS',n.name,n.lineno,n.end_lineno)
   elif n.col_offset<=4: print(' ',n.name,n.lineno,n.end_lineno)
PY
nl -ba astropy/io/fits/file.py | sed -n '130,520p'
nl -ba astropy/io/fits/header.py | sed -n '230,380p'
nl -ba astropy/io/fits/header.py | sed -n '900,1250p'"
```

退出码：`0`

输出：
```

 astropy/io/fits/file.py
  _normalize_fits_mode 132 142
CLASS _File 145 778
  __repr__ 299 300
  __enter__ 303 304
  __exit__ 306 307
  readable 309 312
  writable 446 449
  writearray 457 467
  truncate 494 496
  _overwrite_existing 530 548
  _try_read_compressed 550 609
  _open_fileobj 611 642
  _open_filelike 644 684
  _open_zipfile 752 778

 astropy/io/fits/header.py
CLASS Header 55 1913
CLASS _DelayedHeader 1920 1945
CLASS _BasicHeaderCards 1948 1973
CLASS _BasicHeader 1976 2054
CLASS _CardAccessor 2057 2117
CLASS _HeaderComments 2120 2169
CLASS _HeaderCommentaryCards 2172 2218
  _block_size 2221 2226
  _pad_length 2229 2231
  _check_padding 2234 2262
  _hdr_data_size 2265 2277
  __init__ 96 129
  __len__ 131 132
  __iter__ 134 136
  __contains__ 138 149
  __getitem__ 151 180
  __setitem__ 182 222
  __delitem__ 224 280
  __repr__ 282 283
  __str__ 285 286
  __eq__ 288 293
  __add__ 295 298
  __iadd__ 300 302
  _ipython_key_completions_ 304 305
  cards 308 313
  _modified 333 345
  _modified 348 349
  fromstring 352 466
  fromfile 469 534
  _fromcards 537 547
  _from_blocks 550 617
  _find_end_card 620 666
  tostring 668 710
  totextfile 781 796
  clear 798 804
  copy 806 829
  __copy__ 831 832
  __deepcopy__ 834 835
  fromkeys 838 865
  get 867 890
  set 892 961
  items 963 966
  keys 968 974
  values 976 979
  pop 981 1002
  popitem 1004 1011
  setdefault 1013 1019
  update 1021 1089
  extend 1180 1287
  index 1309 1343
  remove 1452 1478
  rename_keyword 1480 1514
  add_history 1516 1531
  add_comment 1533 1548
  add_blank 1550 1565
  strip 1567 1616
  data_size 1619 1623
  data_size_padded 1626 1632
  _cardindex 1673 1726
  _keyword_from_index 1728 1744
  _haswildcard 1836 1840
  _wildcardmatch 1842 1854
  _splitcommentary 1876 1900
  _add_commentary 1902 1913
  __get__ 1926 1939
  __set__ 1941 1942
  __delete__ 1944 1945
  __init__ 1958 1959
  __getitem__ 1961 1973
  __init__ 1989 1999
  __getitem__ 2001 2011
  __len__ 2013 2014
  __iter__ 2016 2017
  index 2019 2020
  data_size 2023 2027
  data_size_padded 2030 2036
  fromfile 2039 2054
  __init__ 2069 2070
  __repr__ 2072 2073
  __len__ 2075 2076
  __iter__ 2078 2079
  __eq__ 2081 2090
  __ne__ 2092 2093
  __getitem__ 2095 2100
  _setslice 2102 2117
  __iter__ 2131 2133
  __repr__ 2135 2143
  __getitem__ 2145 2154
  __setitem__ 2156 2169
  __init__ 2178 2182
  __len__ 2186 2187
  __iter__ 2189 2191
  __repr__ 2193 2194
  __getitem__ 2196 2205
  __setitem__ 2207 2218

 astropy/io/fits/scripts/fitsheader.py
CLASS ExtensionNotFoundException 85 86
CLASS HeaderFormatter 89 232
CLASS TableHeaderFormatter 238 267
  print_headers_traditional 270 292
  print_headers_as_table 295 328
  print_headers_as_comparison 331 399
  main 402 514
  parse 116 161
  _parse_internal 163 177
  _get_cards 179 232
  _parse_internal 246 267
   130	
   131	
   132	def _normalize_fits_mode(mode):
   133	    if mode is not None and mode not in IO_FITS_MODES:
   134	        if TEXT_RE.match(mode):
   135	            raise ValueError(
   136	                f"Text mode '{mode}' not supported: files must be opened in binary mode"
   137	            )
   138	        new_mode = FILE_MODES.get(mode)
   139	        if new_mode not in IO_FITS_MODES:
   140	            raise ValueError(f"Mode '{mode}' not recognized")
   141	        mode = new_mode
   142	    return mode
   143	
   144	
   145	class _File:
   146	    """
   147	    Represents a FITS file on disk (or in some other file-like object).
   148	    """
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	
   210	
   211	
   212	
   213	
   214	
   215	
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	    def __repr__(self):
   300	        return f"<{self.__module__}.{self.__class__.__name__} {self._file}>"
   301	
   302	    # Support the 'with' statement
   303	    def __enter__(self):
   304	        return self
   305	
   306	    def __exit__(self, type, value, traceback):
   307	        self.close()
   308	
   309	    def readable(self):
   310	        if self.writeonly:
   311	            return False
   312	        return isreadable(self._file)
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	
   414	
   415	
   416	
   417	
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	
   426	
   427	
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	
   437	
   438	
   439	
   440	
   441	
   442	
   443	
   444	
   445	
   446	    def writable(self):
   447	        if self.readonly:
   448	            return False
   449	        return iswritable(self._file)
   450	
   451	
   452	
   453	
   454	
   455	
   456	
   457	    def writearray(self, array):
   458	        """
   459	        Similar to file.write(), but writes a numpy array instead of a string.
   460	
   461	        Also like file.write(), a flush() or close() may be needed before
   462	        the file on disk reflects the data written.
   463	        """
   464	        if self.simulateonly:
   465	            return
   466	        if hasattr(self._file, "write"):
   467	            _array_to_file(array, self._file)
   468	
   469	
   470	
   471	
   472	
   473	
   474	
   475	
   476	
   477	
   478	
   479	
   480	
   481	
   482	
   483	
   484	
   485	
   486	
   487	
   488	
   489	
   490	
   491	
   492	
   493	
   494	    def truncate(self, size=None):
   495	        if hasattr(self._file, "truncate"):
   496	            self._file.truncate(size)
   497	
   498	
   499	
   500	
   501	
   502	
   503	
   504	
   505	
   506	
   507	
   508	
   509	
   510	
   511	
   512	
   513	
   514	
   515	
   516	
   517	
   518	
   519	
   520	
   230	            # the cards are deleted before updating _keyword_indices rather
   231	            # than updating it once for each card that gets deleted]
   232	            if isinstance(key, slice):
   233	                indices = range(*key.indices(len(self)))
   234	                # If the slice step is backwards we want to reverse it, because
   235	                # it will be reversed in a few lines...
   236	                if key.step and key.step < 0:
   237	                    indices = reversed(indices)
   238	            else:
   239	                indices = self._wildcardmatch(key)
   240	            for idx in reversed(indices):
   241	                del self[idx]
   242	            return
   243	        elif isinstance(key, str):
   244	            # delete ALL cards with the same keyword name
   245	            key = Card.normalize_keyword(key)
   246	            indices = self._keyword_indices
   247	            if key not in self._keyword_indices:
   248	                indices = self._rvkc_indices
   249	
   250	            if key not in indices:
   251	                # if keyword is not present raise KeyError.
   252	                # To delete keyword without caring if they were present,
   253	                # Header.remove(Keyword) can be used with optional argument ignore_missing as True
   254	                raise KeyError(f"Keyword '{key}' not found.")
   255	
   256	            for idx in reversed(indices[key]):
   257	                # Have to copy the indices list since it will be modified below
   258	                del self[idx]
   259	            return
   260	
   261	        idx = self._cardindex(key)
   262	        card = self._cards[idx]
   263	        keyword = card.keyword
   264	        del self._cards[idx]
   265	        keyword = Card.normalize_keyword(keyword)
   266	        indices = self._keyword_indices[keyword]
   267	        indices.remove(idx)
   268	        if not indices:
   269	            del self._keyword_indices[keyword]
   270	
   271	        # Also update RVKC indices if necessary :/
   272	        if card.field_specifier is not None:
   273	            indices = self._rvkc_indices[card.rawkeyword]
   274	            indices.remove(idx)
   275	            if not indices:
   276	                del self._rvkc_indices[card.rawkeyword]
   277	
   278	        # We also need to update all other indices
   279	        self._updateindices(idx, increment=False)
   280	        self._modified = True
   281	
   282	    def __repr__(self):
   283	        return self.tostring(sep="\n", endcard=False, padding=False)
   284	
   285	    def __str__(self):
   286	        return self.tostring()
   287	
   288	    def __eq__(self, other):
   289	        """
   290	        Two Headers are equal only if they have the exact same string
   291	        representation.
   292	        """
   293	        return str(self) == str(other)
   294	
   295	    def __add__(self, other):
   296	        temp = self.copy(strip=False)
   297	        temp.extend(other)
   298	        return temp
   299	
   300	    def __iadd__(self, other):
   301	        self.extend(other)
   302	        return self
   303	
   304	    def _ipython_key_completions_(self):
   305	        return self.__iter__()
   306	
   307	    @property
   308	    def cards(self):
   309	        """
   310	        The underlying physical cards that make up this Header; it can be
   311	        looked at, but it should not be modified directly.
   312	        """
   313	        return _CardAccessor(self)
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	    @property
   333	    def _modified(self):
   334	        """
   335	        Whether or not the header has been modified; this is a property so that
   336	        it can also check each card for modifications--cards may have been
   337	        modified directly without the header containing it otherwise knowing.
   338	        """
   339	        modified_cards = any(c._modified for c in self._cards)
   340	        if modified_cards:
   341	            # If any cards were modified then by definition the header was
   342	            # modified
   343	            self.__dict__["_modified"] = True
   344	
   345	        return self.__dict__["_modified"]
   346	
   347	    @_modified.setter
   348	    def _modified(self, val):
   349	        self.__dict__["_modified"] = val
   350	
   351	    @classmethod
   352	    def fromstring(cls, data, sep=""):
   353	        """
   354	        Creates an HDU header from a byte string containing the entire header
   355	        data.
   356	
   357	        Parameters
   358	        ----------
   359	        data : str or bytes
   360	           String or bytes containing the entire header.  In the case of bytes
   361	           they will be decoded using latin-1 (only plain ASCII characters are
   362	           allowed in FITS headers but latin-1 allows us to retain any invalid
   363	           bytes that might appear in malformatted FITS files).
   364	
   365	        sep : str, optional
   366	            The string separating cards from each other, such as a newline.  By
   367	            default there is no card separator (as is the case in a raw FITS
   368	            file).  In general this is only used in cases where a header was
   369	            printed as text (e.g. with newlines after each card) and you want
   370	            to create a new `Header` from it by copy/pasting.
   371	
   372	        Examples
   373	        --------
   374	        >>> from astropy.io.fits import Header
   375	        >>> hdr = Header({'SIMPLE': True})
   376	        >>> Header.fromstring(hdr.tostring()) == hdr
   377	        True
   378	
   379	        If you want to create a `Header` from printed text it's not necessary
   380	        to have the exact binary structure as it would appear in a FITS file,
   900	        This method is similar to :meth:`Header.update` prior to Astropy v0.1.
   901	
   902	        .. note::
   903	            It should be noted that ``header.set(keyword, value)`` and
   904	            ``header.set(keyword, value, comment)`` are equivalent to
   905	            ``header[keyword] = value`` and
   906	            ``header[keyword] = (value, comment)`` respectively.
   907	
   908	        Parameters
   909	        ----------
   910	        keyword : str
   911	            A header keyword
   912	
   913	        value : str, optional
   914	            The value to set for the given keyword; if None the existing value
   915	            is kept, but '' may be used to set a blank value
   916	
   917	        comment : str, optional
   918	            The comment to set for the given keyword; if None the existing
   919	            comment is kept, but ``''`` may be used to set a blank comment
   920	
   921	        before : str, int, optional
   922	            Name of the keyword, or index of the `Card` before which this card
   923	            should be located in the header.  The argument ``before`` takes
   924	            precedence over ``after`` if both specified.
   925	
   926	        after : str, int, optional
   927	            Name of the keyword, or index of the `Card` after which this card
   928	            should be located in the header.
   929	
   930	        """
   931	        # Create a temporary card that looks like the one being set; if the
   932	        # temporary card turns out to be a RVKC this will make it easier to
   933	        # deal with the idiosyncrasies thereof
   934	        # Don't try to make a temporary card though if they keyword looks like
   935	        # it might be a HIERARCH card or is otherwise invalid--this step is
   936	        # only for validating RVKCs.
   937	        if (
   938	            len(keyword) <= KEYWORD_LENGTH
   939	            and Card._keywd_FSC_RE.match(keyword)
   940	            and keyword not in self._keyword_indices
   941	        ):
   942	            new_card = Card(keyword, value, comment)
   943	            new_keyword = new_card.keyword
   944	        else:
   945	            new_keyword = keyword
   946	
   947	        if new_keyword not in _commentary_keywords and new_keyword in self:
   948	            if comment is None:
   949	                comment = self.comments[keyword]
   950	            if value is None:
   951	                value = self[keyword]
   952	
   953	            self[keyword] = (value, comment)
   954	
   955	            if before is not None or after is not None:
   956	                card = self._cards[self._cardindex(keyword)]
   957	                self._relativeinsert(card, before=before, after=after, replace=True)
   958	        elif before is not None or after is not None:
   959	            self._relativeinsert((keyword, value, comment), before=before, after=after)
   960	        else:
   961	            self[keyword] = (value, comment)
   962	
   963	    def items(self):
   964	        """Like :meth:`dict.items`."""
   965	        for card in self._cards:
   966	            yield card.keyword, None if card.value == UNDEFINED else card.value
   967	
   968	    def keys(self):
   969	        """
   970	        Like :meth:`dict.keys`--iterating directly over the `Header`
   971	        instance has the same behavior.
   972	        """
   973	        for card in self._cards:
   974	            yield card.keyword
   975	
   976	    def values(self):
   977	        """Like :meth:`dict.values`."""
   978	        for card in self._cards:
   979	            yield None if card.value == UNDEFINED else card.value
   980	
   981	    def pop(self, *args):
   982	        """
   983	        Works like :meth:`list.pop` if no arguments or an index argument are
   984	        supplied; otherwise works like :meth:`dict.pop`.
   985	        """
   986	        if len(args) > 2:
   987	            raise TypeError(f"Header.pop expected at most 2 arguments, got {len(args)}")
   988	
   989	        if len(args) == 0:
   990	            key = -1
   991	        else:
   992	            key = args[0]
   993	
   994	        try:
   995	            value = self[key]
   996	        except (KeyError, IndexError):
   997	            if len(args) == 2:
   998	                return args[1]
   999	            raise
  1000	
  1001	        del self[key]
  1002	        return value
  1003	
  1004	    def popitem(self):
  1005	        """Similar to :meth:`dict.popitem`."""
  1006	        try:
  1007	            k, v = next(self.items())
  1008	        except StopIteration:
  1009	            raise KeyError("Header is empty")
  1010	        del self[k]
  1011	        return k, v
  1012	
  1013	    def setdefault(self, key, default=None):
  1014	        """Similar to :meth:`dict.setdefault`."""
  1015	        try:
  1016	            return self[key]
  1017	        except (KeyError, IndexError):
  1018	            self[key] = default
  1019	        return default
  1020	
  1021	    def update(self, *args, **kwargs):
  1022	        """
  1023	        Update the Header with new keyword values, updating the values of
  1024	        existing keywords and appending new keywords otherwise; similar to
  1025	        `dict.update`.
  1026	
  1027	        `update` accepts either a dict-like object or an iterable.  In the
  1028	        former case the keys must be header keywords and the values may be
  1029	        either scalar values or (value, comment) tuples.  In the case of an
  1030	        iterable the items must be (keyword, value) tuples or (keyword, value,
  1031	        comment) tuples.
  1032	
  1033	        Arbitrary arguments are also accepted, in which case the update() is
  1034	        called again with the kwargs dict as its only argument.  That is,
  1035	
  1036	        ::
  1037	
  1038	            >>> header.update(NAXIS1=100, NAXIS2=100)
  1039	
  1040	        is equivalent to::
  1041	
  1042	            header.update({'NAXIS1': 100, 'NAXIS2': 100})
  1043	
  1044	        """
  1045	        if args:
  1046	            other = args[0]
  1047	        else:
  1048	            other = None
  1049	
  1050	        def update_from_dict(k, v):
  1051	            if not isinstance(v, tuple):
  1052	                card = Card(k, v)
  1053	            elif 0 < len(v) <= 2:
  1054	                card = Card(*((k,) + v))
  1055	            else:
  1056	                raise ValueError(
  1057	                    f"Header update value for key {k!r} is invalid; the "
  1058	                    "value must be either a scalar, a 1-tuple "
  1059	                    "containing the scalar value, or a 2-tuple "
  1060	                    "containing the value and a comment string."
  1061	                )
  1062	            self._update(card)
  1063	
  1064	        if other is None:
  1065	            pass
  1066	        elif isinstance(other, Header):
  1067	            for card in other.cards:
  1068	                self._update(card)
  1069	        elif hasattr(other, "items"):
  1070	            for k, v in other.items():
  1071	                update_from_dict(k, v)
  1072	        elif hasattr(other, "keys"):
  1073	            for k in other.keys():
  1074	                update_from_dict(k, other[k])
  1075	        else:
  1076	            for idx, card in enumerate(other):
  1077	                if isinstance(card, Card):
  1078	                    self._update(card)
  1079	                elif isinstance(card, tuple) and (1 < len(card) <= 3):
  1080	                    self._update(Card(*card))
  1081	                else:
  1082	                    raise ValueError(
  1083	                        f"Header update sequence item #{idx} is invalid; "
  1084	                        "the item must either be a 2-tuple containing "
  1085	                        "a keyword and value, or a 3-tuple containing "
  1086	                        "a keyword, value, and comment string."
  1087	                    )
  1088	        if kwargs:
  1089	            self.update(kwargs)
  1090	
  1091	
  1092	
  1093	
  1094	
  1095	
  1096	
  1097	
  1098	
  1099	
  1100	
  1101	
  1102	
  1103	
  1104	
  1105	
  1106	
  1107	
  1108	
  1109	
  1110	
  1111	
  1112	
  1113	
  1114	
  1115	
  1116	
  1117	
  1118	
  1119	
  1120	
  1121	
  1122	
  1123	
  1124	
  1125	
  1126	
  1127	
  1128	
  1129	
  1130	
  1131	
  1132	
  1133	
  1134	
  1135	
  1136	
  1137	
  1138	
  1139	
  1140	
  1141	
  1142	
  1143	
  1144	
  1145	
  1146	
  1147	
  1148	
  1149	
  1150	
  1151	
  1152	
  1153	
  1154	
  1155	
  1156	
  1157	
  1158	
  1159	
  1160	
  1161	
  1162	
  1163	
  1164	
  1165	
  1166	
  1167	
  1168	
  1169	
  1170	
  1171	
  1172	
  1173	
  1174	
  1175	
  1176	
  1177	
  1178	
  1179	
  1180	    def extend(
  1181	        self,
  1182	        cards,
  1183	        strip=True,
  1184	        unique=False,
  1185	        update=False,
  1186	        update_first=False,
  1187	        useblanks=True,
  1188	        bottom=False,
  1189	        end=False,
  1190	    ):
  1191	        """
  1192	        Appends multiple keyword+value cards to the end of the header, similar
  1193	        to `list.extend`.
  1194	
  1195	        Parameters
  1196	        ----------
  1197	        cards : iterable
  1198	            An iterable of (keyword, value, [comment]) tuples; see
  1199	            `Header.append`.
  1200	
  1201	        strip : bool, optional
  1202	            Remove any keywords that have meaning only to specific types of
  1203	            HDUs, so that only more general keywords are added from extension
  1204	            Header or Card list (default: `True`).
  1205	
  1206	        unique : bool, optional
  1207	            If `True`, ensures that no duplicate keywords are appended;
  1208	            keywords already in this header are simply discarded.  The
  1209	            exception is commentary keywords (COMMENT, HISTORY, etc.): they are
  1210	            only treated as duplicates if their values match.
  1211	
  1212	        update : bool, optional
  1213	            If `True`, update the current header with the values and comments
  1214	            from duplicate keywords in the input header.  This supersedes the
  1215	            ``unique`` argument.  Commentary keywords are treated the same as
  1216	            if ``unique=True``.
  1217	
  1218	        update_first : bool, optional
  1219	            If the first keyword in the header is 'SIMPLE', and the first
  1220	            keyword in the input header is 'XTENSION', the 'SIMPLE' keyword is
  1221	            replaced by the 'XTENSION' keyword.  Likewise if the first keyword
  1222	            in the header is 'XTENSION' and the first keyword in the input
  1223	            header is 'SIMPLE', the 'XTENSION' keyword is replaced by the
  1224	            'SIMPLE' keyword.  This behavior is otherwise dumb as to whether or
  1225	            not the resulting header is a valid primary or extension header.
  1226	            This is mostly provided to support backwards compatibility with the
  1227	            old ``Header.fromTxtFile`` method, and only applies if
  1228	            ``update=True``.
  1229	
  1230	        useblanks, bottom, end : bool, optional
  1231	            These arguments are passed to :meth:`Header.append` while appending
  1232	            new cards to the header.
  1233	        """
  1234	        temp = self.__class__(cards)
  1235	        if strip:
  1236	            temp.strip()
  1237	
  1238	        if len(self):
  1239	            first = self._cards[0].keyword
  1240	        else:
  1241	            first = None
  1242	
  1243	        # We don't immediately modify the header, because first we need to sift
  1244	        # out any duplicates in the new header prior to adding them to the
  1245	        # existing header, but while *allowing* duplicates from the header
  1246	        # being extended from (see ticket #156)
  1247	        extend_cards = []
  1248	
  1249	        for idx, card in enumerate(temp.cards):
  1250	            keyword = card.keyword
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/header.py | sed -n '650,890p'; nl -ba astropy/io/fits/header.py | sed -n '1070,1485p'; nl -ba astropy/io/fits/header.py | sed -n '1600,1885p'; nl -ba astropy/io/fits/file.py | sed -n '500,800p'"
```

退出码：`0`

输出：
```
   650	                        "Missing padding to end of the FITS block after the "
   651	                        "END keyword; additional spaces will be appended to "
   652	                        f"the file upon writing to pad out to {BLOCK_SIZE} bytes.",
   653	                        AstropyUserWarning,
   654	                    )
   655	
   656	                # Sanitize out invalid END card now that the appropriate
   657	                # warnings have been issued
   658	                block = (
   659	                    block[:offset]
   660	                    + encode_ascii(END_CARD)
   661	                    + block[offset + len(END_CARD) :]
   662	                )
   663	
   664	            return True, block
   665	
   666	        return False, block
   667	
   668	    def tostring(self, sep="", endcard=True, padding=True):
   669	        r"""
   670	        Returns a string representation of the header.
   671	
   672	        By default this uses no separator between cards, adds the END card, and
   673	        pads the string with spaces to the next multiple of 2880 bytes.  That
   674	        is, it returns the header exactly as it would appear in a FITS file.
   675	
   676	        Parameters
   677	        ----------
   678	        sep : str, optional
   679	            The character or string with which to separate cards.  By default
   680	            there is no separator, but one could use ``'\\n'``, for example, to
   681	            separate each card with a new line
   682	
   683	        endcard : bool, optional
   684	            If True (default) adds the END card to the end of the header
   685	            string
   686	
   687	        padding : bool, optional
   688	            If True (default) pads the string with spaces out to the next
   689	            multiple of 2880 characters
   690	
   691	        Returns
   692	        -------
   693	        str
   694	            A string representing a FITS header.
   695	        """
   696	        lines = []
   697	        for card in self._cards:
   698	            s = str(card)
   699	            # Cards with CONTINUE cards may be longer than 80 chars; so break
   700	            # them into multiple lines
   701	            while s:
   702	                lines.append(s[: Card.length])
   703	                s = s[Card.length :]
   704	
   705	        s = sep.join(lines)
   706	        if endcard:
   707	            s += sep + _pad("END")
   708	        if padding:
   709	            s += " " * _pad_length(len(s))
   710	        return s
   711	
   712	
   713	
   714	
   715	
   716	
   717	
   718	
   719	
   720	
   721	
   722	
   723	
   724	
   725	
   726	
   727	
   728	
   729	
   730	
   731	
   732	
   733	
   734	
   735	
   736	
   737	
   738	
   739	
   740	
   741	
   742	
   743	
   744	
   745	
   746	
   747	
   748	
   749	
   750	
   751	
   752	
   753	
   754	
   755	
   756	
   757	
   758	
   759	
   760	
   761	
   762	
   763	
   764	
   765	
   766	
   767	
   768	
   769	
   770	
   771	
   772	
   773	
   774	
   775	
   776	
   777	
   778	
   779	
   780	
   781	    def totextfile(self, fileobj, endcard=False, overwrite=False):
   782	        """
   783	        Write the header as text to a file or a file-like object.
   784	
   785	        Equivalent to::
   786	
   787	            >>> Header.tofile(fileobj, sep='\\n', endcard=False,
   788	            ...               padding=False, overwrite=overwrite)
   789	
   790	        See Also
   791	        --------
   792	        tofile
   793	        """
   794	        self.tofile(
   795	            fileobj, sep="\n", endcard=endcard, padding=False, overwrite=overwrite
   796	        )
   797	
   798	    def clear(self):
   799	        """
   800	        Remove all cards from the header.
   801	        """
   802	        self._cards = []
   803	        self._keyword_indices = collections.defaultdict(list)
   804	        self._rvkc_indices = collections.defaultdict(list)
   805	
   806	    def copy(self, strip=False):
   807	        """
   808	        Make a copy of the :class:`Header`.
   809	
   810	        .. versionchanged:: 1.3
   811	            `copy.copy` and `copy.deepcopy` on a `Header` will call this
   812	            method.
   813	
   814	        Parameters
   815	        ----------
   816	        strip : bool, optional
   817	            If `True`, strip any headers that are specific to one of the
   818	            standard HDU types, so that this header can be used in a different
   819	            HDU.
   820	
   821	        Returns
   822	        -------
   823	        `Header`
   824	            A new :class:`Header` instance.
   825	        """
   826	        tmp = self.__class__(copy.copy(card) for card in self._cards)
   827	        if strip:
   828	            tmp.strip()
   829	        return tmp
   830	
   831	    def __copy__(self):
   832	        return self.copy()
   833	
   834	    def __deepcopy__(self, *args, **kwargs):
   835	        return self.copy()
   836	
   837	    @classmethod
   838	    def fromkeys(cls, iterable, value=None):
   839	        """
   840	        Similar to :meth:`dict.fromkeys`--creates a new `Header` from an
   841	        iterable of keywords and an optional default value.
   842	
   843	        This method is not likely to be particularly useful for creating real
   844	        world FITS headers, but it is useful for testing.
   845	
   846	        Parameters
   847	        ----------
   848	        iterable
   849	            Any iterable that returns strings representing FITS keywords.
   850	
   851	        value : optional
   852	            A default value to assign to each keyword; must be a valid type for
   853	            FITS keywords.
   854	
   855	        Returns
   856	        -------
   857	        `Header`
   858	            A new `Header` instance.
   859	        """
   860	        d = cls()
   861	        if not isinstance(value, tuple):
   862	            value = (value,)
   863	        for key in iterable:
   864	            d.append((key,) + value)
   865	        return d
   866	
   867	    def get(self, key, default=None):
   868	        """
   869	        Similar to :meth:`dict.get`--returns the value associated with keyword
   870	        in the header, or a default value if the keyword is not found.
   871	
   872	        Parameters
   873	        ----------
   874	        key : str
   875	            A keyword that may or may not be in the header.
   876	
   877	        default : optional
   878	            A default value to return if the keyword is not found in the
   879	            header.
   880	
   881	        Returns
   882	        -------
   883	        value: str, number, complex, bool, or ``astropy.io.fits.card.Undefined``
   884	            The value associated with the given keyword, or the default value
   885	            if the keyword is not in the header.
   886	        """
   887	        try:
   888	            return self[key]
   889	        except (KeyError, IndexError):
   890	            return default
  1070	            for k, v in other.items():
  1071	                update_from_dict(k, v)
  1072	        elif hasattr(other, "keys"):
  1073	            for k in other.keys():
  1074	                update_from_dict(k, other[k])
  1075	        else:
  1076	            for idx, card in enumerate(other):
  1077	                if isinstance(card, Card):
  1078	                    self._update(card)
  1079	                elif isinstance(card, tuple) and (1 < len(card) <= 3):
  1080	                    self._update(Card(*card))
  1081	                else:
  1082	                    raise ValueError(
  1083	                        f"Header update sequence item #{idx} is invalid; "
  1084	                        "the item must either be a 2-tuple containing "
  1085	                        "a keyword and value, or a 3-tuple containing "
  1086	                        "a keyword, value, and comment string."
  1087	                    )
  1088	        if kwargs:
  1089	            self.update(kwargs)
  1090	
  1091	
  1092	
  1093	
  1094	
  1095	
  1096	
  1097	
  1098	
  1099	
  1100	
  1101	
  1102	
  1103	
  1104	
  1105	
  1106	
  1107	
  1108	
  1109	
  1110	
  1111	
  1112	
  1113	
  1114	
  1115	
  1116	
  1117	
  1118	
  1119	
  1120	
  1121	
  1122	
  1123	
  1124	
  1125	
  1126	
  1127	
  1128	
  1129	
  1130	
  1131	
  1132	
  1133	
  1134	
  1135	
  1136	
  1137	
  1138	
  1139	
  1140	
  1141	
  1142	
  1143	
  1144	
  1145	
  1146	
  1147	
  1148	
  1149	
  1150	
  1151	
  1152	
  1153	
  1154	
  1155	
  1156	
  1157	
  1158	
  1159	
  1160	
  1161	
  1162	
  1163	
  1164	
  1165	
  1166	
  1167	
  1168	
  1169	
  1170	
  1171	
  1172	
  1173	
  1174	
  1175	
  1176	
  1177	
  1178	
  1179	
  1180	    def extend(
  1181	        self,
  1182	        cards,
  1183	        strip=True,
  1184	        unique=False,
  1185	        update=False,
  1186	        update_first=False,
  1187	        useblanks=True,
  1188	        bottom=False,
  1189	        end=False,
  1190	    ):
  1191	        """
  1192	        Appends multiple keyword+value cards to the end of the header, similar
  1193	        to `list.extend`.
  1194	
  1195	        Parameters
  1196	        ----------
  1197	        cards : iterable
  1198	            An iterable of (keyword, value, [comment]) tuples; see
  1199	            `Header.append`.
  1200	
  1201	        strip : bool, optional
  1202	            Remove any keywords that have meaning only to specific types of
  1203	            HDUs, so that only more general keywords are added from extension
  1204	            Header or Card list (default: `True`).
  1205	
  1206	        unique : bool, optional
  1207	            If `True`, ensures that no duplicate keywords are appended;
  1208	            keywords already in this header are simply discarded.  The
  1209	            exception is commentary keywords (COMMENT, HISTORY, etc.): they are
  1210	            only treated as duplicates if their values match.
  1211	
  1212	        update : bool, optional
  1213	            If `True`, update the current header with the values and comments
  1214	            from duplicate keywords in the input header.  This supersedes the
  1215	            ``unique`` argument.  Commentary keywords are treated the same as
  1216	            if ``unique=True``.
  1217	
  1218	        update_first : bool, optional
  1219	            If the first keyword in the header is 'SIMPLE', and the first
  1220	            keyword in the input header is 'XTENSION', the 'SIMPLE' keyword is
  1221	            replaced by the 'XTENSION' keyword.  Likewise if the first keyword
  1222	            in the header is 'XTENSION' and the first keyword in the input
  1223	            header is 'SIMPLE', the 'XTENSION' keyword is replaced by the
  1224	            'SIMPLE' keyword.  This behavior is otherwise dumb as to whether or
  1225	            not the resulting header is a valid primary or extension header.
  1226	            This is mostly provided to support backwards compatibility with the
  1227	            old ``Header.fromTxtFile`` method, and only applies if
  1228	            ``update=True``.
  1229	
  1230	        useblanks, bottom, end : bool, optional
  1231	            These arguments are passed to :meth:`Header.append` while appending
  1232	            new cards to the header.
  1233	        """
  1234	        temp = self.__class__(cards)
  1235	        if strip:
  1236	            temp.strip()
  1237	
  1238	        if len(self):
  1239	            first = self._cards[0].keyword
  1240	        else:
  1241	            first = None
  1242	
  1243	        # We don't immediately modify the header, because first we need to sift
  1244	        # out any duplicates in the new header prior to adding them to the
  1245	        # existing header, but while *allowing* duplicates from the header
  1246	        # being extended from (see ticket #156)
  1247	        extend_cards = []
  1248	
  1249	        for idx, card in enumerate(temp.cards):
  1250	            keyword = card.keyword
  1251	            if keyword not in _commentary_keywords:
  1252	                if unique and not update and keyword in self:
  1253	                    continue
  1254	                elif update:
  1255	                    if idx == 0 and update_first:
  1256	                        # Dumbly update the first keyword to either SIMPLE or
  1257	                        # XTENSION as the case may be, as was in the case in
  1258	                        # Header.fromTxtFile
  1259	                        if (keyword == "SIMPLE" and first == "XTENSION") or (
  1260	                            keyword == "XTENSION" and first == "SIMPLE"
  1261	                        ):
  1262	                            del self[0]
  1263	                            self.insert(0, card)
  1264	                        else:
  1265	                            self[keyword] = (card.value, card.comment)
  1266	                    elif keyword in self:
  1267	                        self[keyword] = (card.value, card.comment)
  1268	                    else:
  1269	                        extend_cards.append(card)
  1270	                else:
  1271	                    extend_cards.append(card)
  1272	            else:
  1273	                if (unique or update) and keyword in self:
  1274	                    if card.is_blank:
  1275	                        extend_cards.append(card)
  1276	                        continue
  1277	
  1278	                    for value in self[keyword]:
  1279	                        if value == card.value:
  1280	                            break
  1281	                    else:
  1282	                        extend_cards.append(card)
  1283	                else:
  1284	                    extend_cards.append(card)
  1285	
  1286	        for card in extend_cards:
  1287	            self.append(card, useblanks=useblanks, bottom=bottom, end=end)
  1288	
  1289	
  1290	
  1291	
  1292	
  1293	
  1294	
  1295	
  1296	
  1297	
  1298	
  1299	
  1300	
  1301	
  1302	
  1303	
  1304	
  1305	
  1306	
  1307	
  1308	
  1309	    def index(self, keyword, start=None, stop=None):
  1310	        """
  1311	        Returns the index if the first instance of the given keyword in the
  1312	        header, similar to `list.index` if the Header object is treated as a
  1313	        list of keywords.
  1314	
  1315	        Parameters
  1316	        ----------
  1317	        keyword : str
  1318	            The keyword to look up in the list of all keywords in the header
  1319	
  1320	        start : int, optional
  1321	            The lower bound for the index
  1322	
  1323	        stop : int, optional
  1324	            The upper bound for the index
  1325	
  1326	        """
  1327	        if start is None:
  1328	            start = 0
  1329	
  1330	        if stop is None:
  1331	            stop = len(self._cards)
  1332	
  1333	        if stop < start:
  1334	            step = -1
  1335	        else:
  1336	            step = 1
  1337	
  1338	        norm_keyword = Card.normalize_keyword(keyword)
  1339	
  1340	        for idx in range(start, stop, step):
  1341	            if self._cards[idx].keyword.upper() == norm_keyword:
  1342	                return idx
  1343	        raise ValueError(f"The keyword {keyword!r} is not in the  header.")
  1344	
  1345	
  1346	
  1347	
  1348	
  1349	
  1350	
  1351	
  1352	
  1353	
  1354	
  1355	
  1356	
  1357	
  1358	
  1359	
  1360	
  1361	
  1362	
  1363	
  1364	
  1365	
  1366	
  1367	
  1368	
  1369	
  1370	
  1371	
  1372	
  1373	
  1374	
  1375	
  1376	
  1377	
  1378	
  1379	
  1380	
  1381	
  1382	
  1383	
  1384	
  1385	
  1386	
  1387	
  1388	
  1389	
  1390	
  1391	
  1392	
  1393	
  1394	
  1395	
  1396	
  1397	
  1398	
  1399	
  1400	
  1401	
  1402	
  1403	
  1404	
  1405	
  1406	
  1407	
  1408	
  1409	
  1410	
  1411	
  1412	
  1413	
  1414	
  1415	
  1416	
  1417	
  1418	
  1419	
  1420	
  1421	
  1422	
  1423	
  1424	
  1425	
  1426	
  1427	
  1428	
  1429	
  1430	
  1431	
  1432	
  1433	
  1434	
  1435	
  1436	
  1437	
  1438	
  1439	
  1440	
  1441	
  1442	
  1443	
  1444	
  1445	
  1446	
  1447	
  1448	
  1449	
  1450	
  1451	
  1452	    def remove(self, keyword, ignore_missing=False, remove_all=False):
  1453	        """
  1454	        Removes the first instance of the given keyword from the header similar
  1455	        to `list.remove` if the Header object is treated as a list of keywords.
  1456	
  1457	        Parameters
  1458	        ----------
  1459	        keyword : str
  1460	            The keyword of which to remove the first instance in the header.
  1461	
  1462	        ignore_missing : bool, optional
  1463	            When True, ignores missing keywords.  Otherwise, if the keyword
  1464	            is not present in the header a KeyError is raised.
  1465	
  1466	        remove_all : bool, optional
  1467	            When True, all instances of keyword will be removed.
  1468	            Otherwise only the first instance of the given keyword is removed.
  1469	
  1470	        """
  1471	        keyword = Card.normalize_keyword(keyword)
  1472	        if keyword in self._keyword_indices:
  1473	            del self[self._keyword_indices[keyword][0]]
  1474	            if remove_all:
  1475	                while keyword in self._keyword_indices:
  1476	                    del self[self._keyword_indices[keyword][0]]
  1477	        elif not ignore_missing:
  1478	            raise KeyError(f"Keyword '{keyword}' not found.")
  1479	
  1480	    def rename_keyword(self, oldkeyword, newkeyword, force=False):
  1481	        """
  1482	        Rename a card's keyword in the header.
  1483	
  1484	        Parameters
  1485	        ----------
  1600	            for idx in range(tfields):
  1601	                self.remove(name + str(idx + 1), ignore_missing=True)
  1602	
  1603	        for name in (
  1604	            "SIMPLE",
  1605	            "XTENSION",
  1606	            "BITPIX",
  1607	            "NAXIS",
  1608	            "EXTEND",
  1609	            "PCOUNT",
  1610	            "GCOUNT",
  1611	            "GROUPS",
  1612	            "BSCALE",
  1613	            "BZERO",
  1614	            "TFIELDS",
  1615	        ):
  1616	            self.remove(name, ignore_missing=True)
  1617	
  1618	    @property
  1619	    def data_size(self):
  1620	        """
  1621	        Return the size (in bytes) of the data portion following the `Header`.
  1622	        """
  1623	        return _hdr_data_size(self)
  1624	
  1625	    @property
  1626	    def data_size_padded(self):
  1627	        """
  1628	        Return the size (in bytes) of the data portion following the `Header`
  1629	        including padding.
  1630	        """
  1631	        size = self.data_size
  1632	        return size + _pad_length(size)
  1633	
  1634	
  1635	
  1636	
  1637	
  1638	
  1639	
  1640	
  1641	
  1642	
  1643	
  1644	
  1645	
  1646	
  1647	
  1648	
  1649	
  1650	
  1651	
  1652	
  1653	
  1654	
  1655	
  1656	
  1657	
  1658	
  1659	
  1660	
  1661	
  1662	
  1663	
  1664	
  1665	
  1666	
  1667	
  1668	
  1669	
  1670	
  1671	
  1672	
  1673	    def _cardindex(self, key):
  1674	        """Returns an index into the ._cards list given a valid lookup key."""
  1675	        # This used to just set key = (key, 0) and then go on to act as if the
  1676	        # user passed in a tuple, but it's much more common to just be given a
  1677	        # string as the key, so optimize more for that case
  1678	        if isinstance(key, str):
  1679	            keyword = key
  1680	            n = 0
  1681	        elif isinstance(key, numbers.Integral):
  1682	            # If < 0, determine the actual index
  1683	            if key < 0:
  1684	                key += len(self._cards)
  1685	            if key < 0 or key >= len(self._cards):
  1686	                raise IndexError("Header index out of range.")
  1687	            return key
  1688	        elif isinstance(key, slice):
  1689	            return key
  1690	        elif isinstance(key, tuple):
  1691	            if (
  1692	                len(key) != 2
  1693	                or not isinstance(key[0], str)
  1694	                or not isinstance(key[1], numbers.Integral)
  1695	            ):
  1696	                raise ValueError(
  1697	                    "Tuple indices must be 2-tuples consisting of a "
  1698	                    "keyword string and an integer index."
  1699	                )
  1700	            keyword, n = key
  1701	        else:
  1702	            raise ValueError(
  1703	                "Header indices must be either a string, a 2-tuple, or an integer."
  1704	            )
  1705	
  1706	        keyword = Card.normalize_keyword(keyword)
  1707	        # Returns the index into _cards for the n-th card with the given
  1708	        # keyword (where n is 0-based)
  1709	        indices = self._keyword_indices.get(keyword, None)
  1710	
  1711	        if keyword and not indices:
  1712	            if len(keyword) > KEYWORD_LENGTH or "." in keyword:
  1713	                raise KeyError(f"Keyword {keyword!r} not found.")
  1714	            else:
  1715	                # Maybe it's a RVKC?
  1716	                indices = self._rvkc_indices.get(keyword, None)
  1717	
  1718	        if not indices:
  1719	            raise KeyError(f"Keyword {keyword!r} not found.")
  1720	
  1721	        try:
  1722	            return indices[n]
  1723	        except IndexError:
  1724	            raise IndexError(
  1725	                f"There are only {len(indices)} {keyword!r} cards in the header."
  1726	            )
  1727	
  1728	    def _keyword_from_index(self, idx):
  1729	        """
  1730	        Given an integer index, return the (keyword, repeat) tuple that index
  1731	        refers to.  For most keywords the repeat will always be zero, but it
  1732	        may be greater than zero for keywords that are duplicated (especially
  1733	        commentary keywords).
  1734	
  1735	        In a sense this is the inverse of self.index, except that it also
  1736	        supports duplicates.
  1737	        """
  1738	        if idx < 0:
  1739	            idx += len(self._cards)
  1740	
  1741	        keyword = self._cards[idx].keyword
  1742	        keyword = Card.normalize_keyword(keyword)
  1743	        repeat = self._keyword_indices[keyword].index(idx)
  1744	        return keyword, repeat
  1745	
  1746	
  1747	
  1748	
  1749	
  1750	
  1751	
  1752	
  1753	
  1754	
  1755	
  1756	
  1757	
  1758	
  1759	
  1760	
  1761	
  1762	
  1763	
  1764	
  1765	
  1766	
  1767	
  1768	
  1769	
  1770	
  1771	
  1772	
  1773	
  1774	
  1775	
  1776	
  1777	
  1778	
  1779	
  1780	
  1781	
  1782	
  1783	
  1784	
  1785	
  1786	
  1787	
  1788	
  1789	
  1790	
  1791	
  1792	
  1793	
  1794	
  1795	
  1796	
  1797	
  1798	
  1799	
  1800	
  1801	
  1802	
  1803	
  1804	
  1805	
  1806	
  1807	
  1808	
  1809	
  1810	
  1811	
  1812	
  1813	
  1814	
  1815	
  1816	
  1817	
  1818	
  1819	
  1820	
  1821	
  1822	
  1823	
  1824	
  1825	
  1826	
  1827	
  1828	
  1829	
  1830	
  1831	
  1832	
  1833	
  1834	
  1835	
  1836	    def _haswildcard(self, keyword):
  1837	        """Return `True` if the input keyword contains a wildcard pattern."""
  1838	        return isinstance(keyword, str) and (
  1839	            keyword.endswith("...") or "*" in keyword or "?" in keyword
  1840	        )
  1841	
  1842	    def _wildcardmatch(self, pattern):
  1843	        """
  1844	        Returns a list of indices of the cards matching the given wildcard
  1845	        pattern.
  1846	
  1847	         * '*' matches 0 or more characters
  1848	         * '?' matches a single character
  1849	         * '...' matches 0 or more of any non-whitespace character
  1850	        """
  1851	        pattern = pattern.replace("*", r".*").replace("?", r".")
  1852	        pattern = pattern.replace("...", r"\S*") + "$"
  1853	        match_pattern = re.compile(pattern, re.IGNORECASE).match
  1854	        return [i for i, card in enumerate(self._cards) if match_pattern(card.keyword)]
  1855	
  1856	
  1857	
  1858	
  1859	
  1860	
  1861	
  1862	
  1863	
  1864	
  1865	
  1866	
  1867	
  1868	
  1869	
  1870	
  1871	
  1872	
  1873	
  1874	
  1875	
  1876	    def _splitcommentary(self, keyword, value):
  1877	        """
  1878	        Given a commentary keyword and value, returns a list of the one or more
  1879	        cards needed to represent the full value.  This is primarily used to
  1880	        create the multiple commentary cards needed to represent a long value
  1881	        that won't fit into a single commentary card.
  1882	        """
  1883	        # The maximum value in each card can be the maximum card length minus
  1884	        # the maximum key length (which can include spaces if they key length
  1885	        # less than 8
   500	
   501	
   502	
   503	
   504	
   505	
   506	
   507	
   508	
   509	
   510	
   511	
   512	
   513	
   514	
   515	
   516	
   517	
   518	
   519	
   520	
   521	
   522	
   523	
   524	
   525	
   526	
   527	
   528	
   529	
   530	    def _overwrite_existing(self, overwrite, fileobj, closed):
   531	        """Overwrite an existing file if ``overwrite`` is ``True``, otherwise
   532	        raise an OSError.  The exact behavior of this method depends on the
   533	        _File object state and is only meant for use within the ``_open_*``
   534	        internal methods.
   535	        """
   536	        # The file will be overwritten...
   537	        if (self.file_like and hasattr(fileobj, "len") and fileobj.len > 0) or (
   538	            os.path.exists(self.name) and os.path.getsize(self.name) != 0
   539	        ):
   540	            if overwrite:
   541	                if self.file_like and hasattr(fileobj, "truncate"):
   542	                    fileobj.truncate(0)
   543	                else:
   544	                    if not closed:
   545	                        fileobj.close()
   546	                    os.remove(self.name)
   547	            else:
   548	                raise OSError(NOT_OVERWRITING_MSG.format(self.name))
   549	
   550	    def _try_read_compressed(self, obj_or_name, magic, mode, ext=""):
   551	        """Attempt to determine if the given file is compressed."""
   552	        is_ostream = mode == "ostream"
   553	        if (is_ostream and ext == ".gz") or magic.startswith(GZIP_MAGIC):
   554	            if mode == "append":
   555	                raise OSError(
   556	                    "'append' mode is not supported with gzip files."
   557	                    "Use 'update' mode instead"
   558	                )
   559	            # Handle gzip files
   560	            kwargs = {"mode": IO_FITS_MODES[mode]}
   561	            if isinstance(obj_or_name, str):
   562	                kwargs["filename"] = obj_or_name
   563	            else:
   564	                kwargs["fileobj"] = obj_or_name
   565	            self._file = gzip.GzipFile(**kwargs)
   566	            self.compression = "gzip"
   567	        elif (is_ostream and ext == ".zip") or magic.startswith(PKZIP_MAGIC):
   568	            # Handle zip files
   569	            self._open_zipfile(self.name, mode)
   570	            self.compression = "zip"
   571	        elif (is_ostream and ext == ".bz2") or magic.startswith(BZIP2_MAGIC):
   572	            # Handle bzip2 files
   573	            if mode in ["update", "append"]:
   574	                raise OSError(
   575	                    "update and append modes are not supported with bzip2 files"
   576	                )
   577	            if not HAS_BZ2:
   578	                raise ModuleNotFoundError(
   579	                    "This Python installation does not provide the bz2 module."
   580	                )
   581	            # bzip2 only supports 'w' and 'r' modes
   582	            bzip2_mode = "w" if is_ostream else "r"
   583	            self._file = bz2.BZ2File(obj_or_name, mode=bzip2_mode)
   584	            self.compression = "bzip2"
   585	        elif (is_ostream and ext == ".xz") or magic.startswith(LZMA_MAGIC):
   586	            # Handle lzma files
   587	            if mode in ["update", "append"]:
   588	                raise OSError(
   589	                    "update and append modes are not supported with lzma files"
   590	                )
   591	            if not HAS_LZMA:
   592	                raise ModuleNotFoundError(
   593	                    "This Python installation does not provide the lzma module."
   594	                )
   595	            lzma_mode = "w" if is_ostream else "r"
   596	            self._file = lzma.LZMAFile(obj_or_name, mode=lzma_mode)
   597	            self.compression = "lzma"
   598	        elif (is_ostream and ext == ".Z") or magic.startswith(LZW_MAGIC):
   599	            # Handle LZW files
   600	            if mode in ["update", "append", "ostream"]:
   601	                raise OSError(f"{mode} mode not supported with LZW files")
   602	            if not HAS_UNCOMPRESSPY:
   603	                raise ModuleNotFoundError(
   604	                    "The optional package uncompresspy is necessary for reading"
   605	                    " LZW compressed files (.Z extension)."
   606	                )
   607	            self._file = uncompresspy.LZWFile(obj_or_name, mode="rb")
   608	            self.compression = "lzw"
   609	        return self.compression is not None
   610	
   611	    def _open_fileobj(self, fileobj, mode, overwrite):
   612	        """Open a FITS file from a file object (including compressed files)."""
   613	        closed = fileobj_closed(fileobj)
   614	        # FIXME: this variable was unused, check if it was useful
   615	        # fmode = fileobj_mode(fileobj) or IO_FITS_MODES[mode]
   616	
   617	        if mode == "ostream":
   618	            self._overwrite_existing(overwrite, fileobj, closed)
   619	
   620	        if not closed:
   621	            self._file = fileobj
   622	        elif isfile(fileobj):
   623	            self._file = open(self.name, IO_FITS_MODES[mode])
   624	
   625	        # Attempt to determine if the file represented by the open file object
   626	        # is compressed
   627	        try:
   628	            # We need to account for the possibility that the underlying file
   629	            # handle may have been opened with either 'ab' or 'ab+', which
   630	            # means that the current file position is at the end of the file.
   631	            if mode in ["ostream", "append"]:
   632	                self._file.seek(0)
   633	            magic = self._file.read(6)
   634	            # No matter whether the underlying file was opened with 'ab' or
   635	            # 'ab+', we need to return to the beginning of the file in order
   636	            # to properly process the FITS header (and handle the possibility
   637	            # of a compressed file).
   638	            self._file.seek(0)
   639	        except OSError:
   640	            return
   641	
   642	        self._try_read_compressed(fileobj, magic, mode)
   643	
   644	    def _open_filelike(self, fileobj, mode, overwrite):
   645	        """Open a FITS file from a file-like object, i.e. one that has
   646	        read and/or write methods.
   647	        """
   648	        self.file_like = True
   649	        self._file = fileobj
   650	
   651	        if fileobj_closed(fileobj):
   652	            raise OSError(
   653	                f"Cannot read from/write to a closed file-like object ({fileobj!r})."
   654	            )
   655	
   656	        if isinstance(fileobj, zipfile.ZipFile):
   657	            self._open_zipfile(fileobj, mode)
   658	            # We can bypass any additional checks at this point since now
   659	            # self._file points to the temp file extracted from the zip
   660	            return
   661	
   662	        # If there is not seek or tell methods then set the mode to
   663	        # output streaming.
   664	        if not hasattr(self._file, "seek") or not hasattr(self._file, "tell"):
   665	            self.mode = mode = "ostream"
   666	
   667	        if mode == "ostream":
   668	            self._overwrite_existing(overwrite, fileobj, False)
   669	
   670	        # Any "writeable" mode requires a write() method on the file object
   671	        if self.mode in ("update", "append", "ostream") and not hasattr(
   672	            self._file, "write"
   673	        ):
   674	            raise OSError(
   675	                "File-like object does not have a 'write' "
   676	                f"method, required for mode '{self.mode}'."
   677	            )
   678	
   679	        # Any mode except for 'ostream' requires readability
   680	        if self.mode != "ostream" and not hasattr(self._file, "read"):
   681	            raise OSError(
   682	                "File-like object does not have a 'read' "
   683	                f"method, required for mode {self.mode!r}."
   684	            )
   685	
   686	
   687	
   688	
   689	
   690	
   691	
   692	
   693	
   694	
   695	
   696	
   697	
   698	
   699	
   700	
   701	
   702	
   703	
   704	
   705	
   706	
   707	
   708	
   709	
   710	
   711	
   712	
   713	
   714	
   715	
   716	
   717	
   718	
   719	
   720	
   721	
   722	
   723	
   724	
   725	
   726	
   727	
   728	
   729	
   730	
   731	
   732	
   733	
   734	
   735	
   736	
   737	
   738	
   739	
   740	
   741	
   742	
   743	
   744	
   745	
   746	
   747	
   748	
   749	
   750	
   751	
   752	    def _open_zipfile(self, fileobj, mode):
   753	        """Limited support for zipfile.ZipFile objects containing a single
   754	        a file.  Allows reading only for now by extracting the file to a
   755	        tempfile.
   756	        """
   757	        if mode in ("update", "append"):
   758	            raise OSError("Writing to zipped fits files is not currently supported")
   759	
   760	        if not isinstance(fileobj, zipfile.ZipFile):
   761	            zfile = zipfile.ZipFile(fileobj)
   762	            close = True
   763	        else:
   764	            zfile = fileobj
   765	            close = False
   766	
   767	        namelist = zfile.namelist()
   768	        if len(namelist) != 1:
   769	            raise OSError("Zip files with multiple members are not supported.")
   770	        self._file = tempfile.NamedTemporaryFile(suffix=".fits")
   771	        self._file.write(zfile.read(namelist[0]))
   772	
   773	        if close:
   774	            zfile.close()
   775	        # We just wrote the contents of the first file in the archive to a new
   776	        # temp file, which now serves as our underlying file object. So it's
   777	        # necessary to reset the position back to the beginning
   778	        self._file.seek(0)
```

## 原始行 23 · agent_message

```
The masked tree contains the requested interfaces removed wholesale, plus several helper methods those interfaces depend on (for example `_File` lacks `close`, `readarray`, seeking, and local-file opening; `Header` lacks insertion helpers and `tofile`). I’m treating those as genuine task blockers and reconstructing them from the repository’s callers and tests, without using external or installed source copies.
```

## 原始行 25 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"_File(\" astropy/io/fits --include='*.py' | head -100; grep -RInE \"\\._file\\.(readarray|read|write|seek|tell|flush|close|fileobj_mode)|\\.readarray\\(|\\.fileobj_mode|\\.memmap|\\.compression|\\.readonly|\\.writeonly|\\.size\" astropy/io/fits --include='*.py' | head -300; grep -RInE \"Header\\.(tofile|fromtextfile)|\\.insert\\(|\\._relativeinsert|\\._update\\(|\\._countblanks|\\.count\\(\" astropy/io/fits/tests astropy/io/fits --include='*.py' | head -350"
```

退出码：`0`

输出：
```
astropy/io/fits/convenience.py:742:            f = _File(filename, mode="append")
astropy/io/fits/hdu/base.py:900:        f = _File()
astropy/io/fits/hdu/nonstandard.py:112:        return cls._readfrom_internal(_File(bs), header=header)
astropy/io/fits/hdu/hdulist.py:1048:        fileobj = _File(fileobj, mode=mode, overwrite=overwrite)
astropy/io/fits/hdu/hdulist.py:1186:                fileobj = _File(
astropy/io/fits/hdu/hdulist.py:1516:            ffo = _File(old_file, mode="update", memmap=old_memmap)
astropy/io/fits/hdu/streaming.py:110:        self._ffo = _File(name, "append")
astropy/io/fits/fitsrec.py:451:                    inarr_rowsize = inarr[0].size
astropy/io/fits/fitsrec.py:460:                    inarr_rowsize = inarr[0].size
astropy/io/fits/fitsrec.py:496:        if self.size > 0 or self.shape == (0,):
astropy/io/fits/fitsrec.py:1392:    if inarray.size == 0:
astropy/io/fits/fitstime.py:640:                if location.size > 1:
astropy/io/fits/file.py:310:        if self.writeonly:
astropy/io/fits/file.py:447:        if self.readonly:
astropy/io/fits/file.py:566:            self.compression = "gzip"
astropy/io/fits/file.py:570:            self.compression = "zip"
astropy/io/fits/file.py:584:            self.compression = "bzip2"
astropy/io/fits/file.py:597:            self.compression = "lzma"
astropy/io/fits/file.py:608:            self.compression = "lzw"
astropy/io/fits/file.py:609:        return self.compression is not None
astropy/io/fits/file.py:632:                self._file.seek(0)
astropy/io/fits/file.py:633:            magic = self._file.read(6)
astropy/io/fits/file.py:638:            self._file.seek(0)
astropy/io/fits/file.py:771:        self._file.write(zfile.read(namelist[0]))
astropy/io/fits/file.py:778:        self._file.seek(0)
astropy/io/fits/util.py:271:        if s.size == 0:
astropy/io/fits/util.py:410:        return f.fileobj_mode
astropy/io/fits/util.py:798:            hdulist_size = sum(hdu.size for hdu in hdulist)
astropy/io/fits/hdu/base.py:616:        return self.data.size * self.data.itemsize
astropy/io/fits/hdu/base.py:668:            self._file.seek(hdrloc)
astropy/io/fits/hdu/base.py:678:            self._file.seek(hdrloc)
astropy/io/fits/hdu/base.py:682:            fileobj.write(self._file.read(hdrsize))
astropy/io/fits/hdu/base.py:703:                    self._file.seek(self._data_offset)
astropy/io/fits/hdu/base.py:760:        return self._file.size - self._data_offset
astropy/io/fits/hdu/base.py:804:        return self._file.size - self._data_offset
astropy/io/fits/hdu/base.py:838:        return self._get_raw_data(self.size, "ubyte", self._data_offset)
astropy/io/fits/hdu/base.py:1384:            if self.size > 0:
astropy/io/fits/hdu/base.py:1599:        return self._get_raw_data(self.size, "ubyte", self._data_offset)
astropy/io/fits/hdu/nonstandard.py:29:        self._file.seek(self._data_offset)
astropy/io/fits/hdu/nonstandard.py:35:        fileobj.write(self._file.read(self.size))
astropy/io/fits/hdu/image.py:669:            size += output.size * output.itemsize
astropy/io/fits/hdu/image.py:703:        if fileobj.fileobj_mode not in ("rb+", "wb+", "ab+"):
astropy/io/fits/hdu/image.py:847:                if self._file is not None and self._file.memmap:
astropy/io/fits/hdu/hdulist.py:1088:                and not self._file.closed
astropy/io/fits/hdu/hdulist.py:1093:                self._file.close()
astropy/io/fits/hdu/hdulist.py:1214:            and hdulist._file.size > 0
astropy/io/fits/hdu/hdulist.py:1216:            pos = hdulist._file.tell()
astropy/io/fits/hdu/hdulist.py:1220:            simple = hdulist._file.read(80)
astropy/io/fits/hdu/hdulist.py:1237:                    if hdulist._file.close_on_error:
astropy/io/fits/hdu/hdulist.py:1238:                        hdulist._file.close()
astropy/io/fits/hdu/hdulist.py:1245:            hdulist._file.seek(pos)
astropy/io/fits/hdu/hdulist.py:1250:        if fileobj is not None and fileobj.writeonly:
astropy/io/fits/hdu/hdulist.py:1262:            if hdulist._file.close_on_error:
astropy/io/fits/hdu/hdulist.py:1263:                hdulist._file.close()
astropy/io/fits/hdu/hdulist.py:1332:                        if self._file.close_on_error:
astropy/io/fits/hdu/hdulist.py:1333:                            self._file.close()
astropy/io/fits/hdu/hdulist.py:1335:                        if fileobj.writeonly:
astropy/io/fits/hdu/hdulist.py:1450:            if self._resize or self._file.compression:
astropy/io/fits/hdu/hdulist.py:1470:        old_memmap = self._file.memmap
astropy/io/fits/hdu/hdulist.py:1478:            if self._file.compression == "gzip":
astropy/io/fits/hdu/hdulist.py:1495:                hdulist._file.close()
astropy/io/fits/hdu/hdulist.py:1496:                self._file.close()
astropy/io/fits/hdu/hdulist.py:1620:                nbytes = hdu.size
astropy/io/fits/hdu/compressed/compressed.py:307:            self.compression_type = self._bintable.header.get(
astropy/io/fits/hdu/compressed/compressed.py:340:            self.compression_type = compression_type
astropy/io/fits/hdu/compressed/compressed.py:343:                compression_type=self.compression_type,
astropy/io/fits/hdu/compressed/compressed.py:446:            compression_type=self.compression_type,
astropy/io/fits/hdu/compressed/compressed.py:508:                compression_type=self.compression_type,
astropy/io/fits/hdu/compressed/compressed.py:538:            self.data, self.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/_tiled_compression.py:332:    if image_data.size == 0:
astropy/io/fits/hdu/compressed/_tiled_compression.py:429:                settings["itemsize"] = tile_data.size // int(prod(actual_tile_shape))
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:26:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:36:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:47:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:57:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:67:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:77:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:88:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:98:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:108:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:118:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:128:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:139:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:152:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:162:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compression_failures.py:172:                hdu.data, hdu.compression_type, bintable.header, bintable.columns
astropy/io/fits/hdu/compressed/tests/test_compressed.py:896:        assert chdu.compression_type == "RICE_1"
astropy/io/fits/hdu/compressed/tests/test_compressed.py:903:        assert chdu.compression_type == "PLIO_1"
astropy/io/fits/hdu/compressed/tests/test_compressed.py:1312:    chdu.compression_type = "RICE_ONE"
astropy/io/fits/hdu/compressed/_quantization.py:74:                qbytes.size,
astropy/io/fits/hdu/compressed/_quantization.py:87:                qbytes.size,
astropy/io/fits/hdu/compressed/_quantization.py:121:                uarray.size,
astropy/io/fits/hdu/compressed/_quantization.py:132:                uarray.size,
astropy/io/fits/hdu/compressed/section.py:63:                self.hdu.compression_type,
astropy/io/fits/hdu/compressed/section.py:118:            self.hdu.compression_type,
astropy/io/fits/hdu/streaming.py:120:        self._size = self.size
astropy/io/fits/hdu/table.py:773:            padding = np.frombuffer(_pad_length(self.size) * b" ", dtype=np.ubyte)
astropy/io/fits/hdu/table.py:944:        size += self.data.size * self.data._raw_itemsize
astropy/io/fits/hdu/groups.py:503:            size += output.size * output.itemsize
astropy/io/fits/tests/test_core.py:728:            assert fits_handle._file.compression == "gzip"
astropy/io/fits/tests/test_core.py:732:            assert fits_handle._file.compression == "gzip"
astropy/io/fits/tests/test_core.py:736:            assert fits_handle._file.compression == "gzip"
astropy/io/fits/tests/test_core.py:742:                assert fits_handle._file.compression == "gzip"
astropy/io/fits/tests/test_core.py:747:            assert fits_handle._file.compression == "gzip"
astropy/io/fits/tests/test_core.py:796:            assert fits_handle._file.compression == "bzip2"
astropy/io/fits/tests/test_core.py:800:            assert fits_handle._file.compression == "bzip2"
astropy/io/fits/tests/test_core.py:804:            assert fits_handle._file.compression == "bzip2"
astropy/io/fits/tests/test_core.py:819:                assert fits_handle._file.compression == "bzip2"
astropy/io/fits/tests/test_core.py:826:            assert fits_handle._file.compression == "bzip2"
astropy/io/fits/tests/test_core.py:857:            assert fits_handle._file.compression == "lzma"
astropy/io/fits/tests/test_core.py:861:            assert fits_handle._file.compression == "lzma"
astropy/io/fits/tests/test_core.py:865:            assert fits_handle._file.compression == "lzma"
astropy/io/fits/tests/test_core.py:880:                assert fits_handle._file.compression == "lzma"
astropy/io/fits/tests/test_core.py:887:            assert fits_handle._file.compression == "lzma"
astropy/io/fits/tests/test_core.py:922:            assert fits_handle._file.compression == "lzw"
astropy/io/fits/tests/test_core.py:928:            assert fits_handle._file.compression == "lzw"
astropy/io/fits/tests/test_core.py:934:            assert fits_handle._file.compression == "lzw"
astropy/io/fits/tests/test_core.py:954:                assert fits_handle._file.compression == "lzw"
astropy/io/fits/tests/test_core.py:967:            assert fits_handle._file.compression == "lzw"
astropy/io/fits/tests/test_core.py:987:            assert fits_handle._file.compression == "zip"
astropy/io/fits/tests/test_core.py:991:            assert fits_handle._file.compression == "zip"
astropy/io/fits/tests/test_core.py:995:            assert fits_handle._file.compression == "zip"
astropy/io/fits/tests/test_core.py:1001:                assert fits_handle._file.compression == "zip"
astropy/io/fits/tests/test_core.py:1550:        assert isinstance(shdu.size, int)
astropy/io/fits/tests/test_core.py:1551:        assert shdu.size == 100
astropy/io/fits/tests/test_core.py:1580:            assert shdu.size == 100
astropy/io/fits/tests/test_core.py:1594:        assert shdu.size == 100
astropy/io/fits/tests/test_table.py:3893:        assert hdul["TEST"].data.size == 0
astropy/io/fits/tests/test_table.py:3900:        assert hdul["TEST"].data.size == 0
astropy/io/fits/tests/test_util.py:84:        assert util.fileobj_mode("tmp1.fits") is None
astropy/io/fits/tests/test_util.py:94:            assert util.fileobj_mode(fileobj) == "rb"
astropy/io/fits/tests/test_util.py:116:                assert util.fileobj_mode(fileobj) == res
astropy/io/fits/tests/test_util.py:131:                assert util.fileobj_mode(fileobj) == res
astropy/io/fits/tests/test_util.py:149:                assert util.fileobj_mode(fileobj) == res
astropy/io/fits/tests/test_util.py:167:                assert util.fileobj_mode(fileobj) == res
astropy/io/fits/tests/test_division.py:30:            assert type(t1[1].size) is int
astropy/io/fits/tests/test_structured.py:43:            if w.size > 0:
astropy/io/fits/tests/test_structured.py:47:                        f"\n        {w.size} elements in field {n2} differ\n"
astropy/io/fits/tests/test_core.py:1141:        hdul.insert(1, fits.ImageHDU())
astropy/io/fits/tests/test_core.py:1442:                hdul.insert(1, fits.ImageHDU())
astropy/io/fits/tests/test_diff.py:631:        assert report.count("more indices") == 1
astropy/io/fits/tests/test_header.py:90:        assert header.count(key) == 1
astropy/io/fits/tests/test_header.py:851:            header.insert(2, ("abcdefghij", 10))
astropy/io/fits/tests/test_header.py:856:            header.insert(2, ("abcdefghij", 10))
astropy/io/fits/tests/test_header.py:1508:        assert header.count("A") == 1
astropy/io/fits/tests/test_header.py:1509:        assert header.count("C") == 1
astropy/io/fits/tests/test_header.py:1510:        assert header.count("E") == 1
astropy/io/fits/tests/test_header.py:1513:        assert header.count("HISTORY") == 2
astropy/io/fits/tests/test_header.py:1574:        header.insert(1, ("E", "F"))
astropy/io/fits/tests/test_header.py:1581:        header.insert(1, ("G", "H"), useblanks=False)
astropy/io/fits/tests/test_header.py:1599:        header.insert("NAXIS1", ("NAXIS", 2, "Number of axes"))
astropy/io/fits/tests/test_header.py:1604:        header.insert("NAXIS1", ("NAXIS2", 20), after=True)
astropy/io/fits/tests/test_header.py:1609:        header.insert(("COMMENT", 1), ("COMMENT", "Comment 2"))
astropy/io/fits/tests/test_header.py:1612:        header.insert(("COMMENT", 2), ("COMMENT", "Comment 4"), after=True)
astropy/io/fits/tests/test_header.py:1615:        header.insert(-1, ("TEST1", True))
astropy/io/fits/tests/test_header.py:1618:        header.insert(-1, ("TEST2", True), after=True)
astropy/io/fits/tests/test_header.py:1697:        header.insert(0, ("A", "B", "C"))
astropy/io/fits/tests/test_header.py:1886:        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
astropy/io/fits/tests/test_header.py:1906:        new_header = fits.Header.fromtextfile(self.temp("test.hdr"))
astropy/io/fits/tests/test_header.py:2255:        assert h.count("ijk") == 1
astropy/io/fits/tests/test_header.py:2298:        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
astropy/io/fits/tests/test_header.py:2734:        header.insert(idx, ("D", 42))
astropy/io/fits/tests/test_hdulist.py:54:            hdul.insert(1, hdu)
astropy/io/fits/tests/test_hdulist.py:211:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:226:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:241:            hdul.insert(0, hdul1[1])
astropy/io/fits/tests/test_hdulist.py:259:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:274:            hdul.insert(1, hdu)
astropy/io/fits/tests/test_hdulist.py:291:            hdul.insert(1, hdul[1])
astropy/io/fits/tests/test_hdulist.py:310:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:314:            hdul.insert(1, hdu)
astropy/io/fits/tests/test_hdulist.py:321:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:337:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:339:            hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:344:            hdul.insert(0, hdul[1])
astropy/io/fits/tests/test_hdulist.py:367:            hdul.insert(0, hdu)
astropy/io/fits/verify.py:119:            messages.insert(0, "Verification reported errors:")
astropy/io/fits/header.py:49:    "Header.fromtextfile",
astropy/io/fits/header.py:222:            self._update((key, value, comment))
astropy/io/fits/header.py:787:            >>> Header.tofile(fileobj, sep='\\n', endcard=False,
astropy/io/fits/header.py:957:                self._relativeinsert(card, before=before, after=after, replace=True)
astropy/io/fits/header.py:959:            self._relativeinsert((keyword, value, comment), before=before, after=after)
astropy/io/fits/header.py:1062:            self._update(card)
astropy/io/fits/header.py:1068:                self._update(card)
astropy/io/fits/header.py:1078:                    self._update(card)
astropy/io/fits/header.py:1080:                    self._update(Card(*card))
astropy/io/fits/header.py:1263:                            self.insert(0, card)
astropy/io/fits/header.py:1514:        self.insert(idx, (new, card.value, card.comment))
astropy/io/fits/header.py:1911:            self._relativeinsert((key, value), before=before, after=after)
astropy/io/fits/header.py:2181:        self._count = self._header.count(self._keyword)
astropy/io/fits/hdu/base.py:1118:                    self._header.insert(insert_pos, card)
astropy/io/fits/hdu/base.py:1141:                        self._header.insert(insert_pos, card)
astropy/io/fits/hdu/hdulist.py:332:        for idx in itertools.count():
astropy/io/fits/hdu/hdulist.py:690:                super().insert(1, hdu1)
astropy/io/fits/hdu/hdulist.py:705:                    super().insert(0, phdu)
astropy/io/fits/hdu/hdulist.py:716:        super().insert(index, hdu)
astropy/io/fits/hdu/hdulist.py:1398:                self.insert(0, PrimaryHDU())
astropy/io/fits/hdu/compressed/compressed.py:593:            image_blanks = self.header._countblanks()
astropy/io/fits/hdu/compressed/compressed.py:594:            table_blanks = self._tmp_bintable.header._countblanks()
astropy/io/fits/hdu/compressed/header.py:231:    table_blanks = bintable_header._countblanks()
astropy/io/fits/hdu/compressed/header.py:232:    image_blanks = image_header._countblanks()
astropy/io/fits/hdu/compressed/tests/test_checksum.py:27:                assert h2[1].header._countblanks() == 78
astropy/io/fits/hdu/compressed/tests/test_checksum.py:39:                assert h2[1].header._countblanks() == 78
astropy/io/fits/hdu/compressed/tests/test_compressed.py:563:            imghdr.insert(1000, "TFIELDS")
astropy/io/fits/hdu/compressed/tests/test_compressed.py:566:            imghdr.insert("TELESCOP", ("OBSERVER", "Phil Plait"))
astropy/io/fits/hdu/compressed/tests/test_compressed.py:573:            imghdr.insert("OBSERVER", ("FOO",))
astropy/io/fits/hdu/compressed/tests/test_compressed.py:587:            assert tblhdr.count("TFIELDS") == 1
astropy/io/fits/hdu/compressed/tests/test_compressed.py:609:            assert tblhdr.count("ZBITPIX") == 1
astropy/io/fits/hdu/compressed/tests/test_compressed.py:697:            assert hdul[1]._bintable.header.count("ZTENSION") == 2
astropy/io/fits/hdu/compressed/utils.py:70:                tile_shape.insert(0, image_header["NAXIS1"])
astropy/io/fits/hdu/compressed/utils.py:76:                        tile_shape.insert(0, dim)
astropy/io/fits/hdu/compressed/utils.py:79:                    tile_shape.insert(0, 17)
astropy/io/fits/hdu/compressed/utils.py:83:                tile_shape.insert(0, 1)
astropy/io/fits/hdu/table.py:611:                    self._header.insert(
astropy/io/fits/hdu/table.py:619:                        self._header.insert(after_keyword, (keyword, new_value))
astropy/io/fits/hdu/table.py:667:                self._header.insert(keyword, new_card)
astropy/io/fits/hdu/table.py:1156:                header = Header.fromtextfile(hfile)
astropy/io/fits/hdu/table.py:1159:                    Header.fromtextfile(hfile), update=True, update_first=True
astropy/io/fits/tests/test_core.py:1141:        hdul.insert(1, fits.ImageHDU())
astropy/io/fits/tests/test_core.py:1442:                hdul.insert(1, fits.ImageHDU())
astropy/io/fits/tests/test_diff.py:631:        assert report.count("more indices") == 1
astropy/io/fits/tests/test_header.py:90:        assert header.count(key) == 1
astropy/io/fits/tests/test_header.py:851:            header.insert(2, ("abcdefghij", 10))
astropy/io/fits/tests/test_header.py:856:            header.insert(2, ("abcdefghij", 10))
astropy/io/fits/tests/test_header.py:1508:        assert header.count("A") == 1
astropy/io/fits/tests/test_header.py:1509:        assert header.count("C") == 1
astropy/io/fits/tests/test_header.py:1510:        assert header.count("E") == 1
astropy/io/fits/tests/test_header.py:1513:        assert header.count("HISTORY") == 2
astropy/io/fits/tests/test_header.py:1574:        header.insert(1, ("E", "F"))
astropy/io/fits/tests/test_header.py:1581:        header.insert(1, ("G", "H"), useblanks=False)
astropy/io/fits/tests/test_header.py:1599:        header.insert("NAXIS1", ("NAXIS", 2, "Number of axes"))
astropy/io/fits/tests/test_header.py:1604:        header.insert("NAXIS1", ("NAXIS2", 20), after=True)
astropy/io/fits/tests/test_header.py:1609:        header.insert(("COMMENT", 1), ("COMMENT", "Comment 2"))
astropy/io/fits/tests/test_header.py:1612:        header.insert(("COMMENT", 2), ("COMMENT", "Comment 4"), after=True)
astropy/io/fits/tests/test_header.py:1615:        header.insert(-1, ("TEST1", True))
astropy/io/fits/tests/test_header.py:1618:        header.insert(-1, ("TEST2", True), after=True)
astropy/io/fits/tests/test_header.py:1697:        header.insert(0, ("A", "B", "C"))
astropy/io/fits/tests/test_header.py:1886:        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
astropy/io/fits/tests/test_header.py:1906:        new_header = fits.Header.fromtextfile(self.temp("test.hdr"))
astropy/io/fits/tests/test_header.py:2255:        assert h.count("ijk") == 1
astropy/io/fits/tests/test_header.py:2298:        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
astropy/io/fits/tests/test_header.py:2734:        header.insert(idx, ("D", 42))
astropy/io/fits/tests/test_hdulist.py:54:            hdul.insert(1, hdu)
astropy/io/fits/tests/test_hdulist.py:211:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:226:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:241:            hdul.insert(0, hdul1[1])
astropy/io/fits/tests/test_hdulist.py:259:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:274:            hdul.insert(1, hdu)
astropy/io/fits/tests/test_hdulist.py:291:            hdul.insert(1, hdul[1])
astropy/io/fits/tests/test_hdulist.py:310:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:314:            hdul.insert(1, hdu)
astropy/io/fits/tests/test_hdulist.py:321:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:337:        hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:339:            hdul.insert(0, hdu)
astropy/io/fits/tests/test_hdulist.py:344:            hdul.insert(0, hdul[1])
astropy/io/fits/tests/test_hdulist.py:367:            hdul.insert(0, hdu)
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io import fits
print('Header methods', [x for x in ('append','insert','count','tofile','_updateindices','_countblanks') if hasattr(fits.Header,x)])
try:
 h=fits.Header([('A',1)]); print(h)
except Exception as e:
 import traceback; traceback.print_exc()
try:
 print(fits.PrimaryHDU())
except Exception as e:
 import traceback; traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
  File "/testbed/astropy/io/fits/header.py", line 127, in __init__
    self.append(card, end=True)
    ^^^^^^^^^^^
AttributeError: 'Header' object has no attribute 'append'
Traceback (most recent call last):
  File "<stdin>", line 8, in <module>
  File "/testbed/astropy/io/fits/hdu/image.py", line 1127, in __init__
    super().__init__(
  File "/testbed/astropy/io/fits/hdu/image.py", line 87, in __init__
    new_header = Header(cards)
                 ^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/header.py", line 127, in __init__
    self.append(card, end=True)
    ^^^^^^^^^^^
AttributeError: 'Header' object has no attribute 'append'
Header methods []
```

## 原始行 31 · command_execution

命令：
```
/bin/bash -lc 'grep -n "''^version'"\\|__version__\" pyproject.toml astropy/__init__.py; sed -n '360,455p' astropy/io/fits/util.py; sed -n '1000,1280p' astropy/io/fits/hdu/hdulist.py; sed -n '1,180p' astropy/io/fits/tests/test_file.py 2>/dev/null || true; find astropy/io/fits/tests -maxdepth 1 -type f -printf '%f\\n' | sort"
```

退出码：`0`

输出：
```
pyproject.toml:217:version_file = "astropy/_version.py"
astropy/__init__.py:16:    "__version__",
astropy/__init__.py:65:from .version import version as __version__



































def fileobj_mode(f):
    """
    Returns the 'mode' string of a file-like object if such a thing exists.
    Otherwise returns None.
    """
    # Go from most to least specific--for example gzip objects have a 'mode'
    # attribute, but it's not analogous to the file.mode attribute

    # gzip.GzipFile -like
    if hasattr(f, "fileobj") and hasattr(f.fileobj, "mode"):
        fileobj = f.fileobj

    # astropy.io.fits._File -like, doesn't need additional checks because it's
    # already validated
    elif hasattr(f, "fileobj_mode"):
        return f.fileobj_mode

    # PIL-Image -like investigate the fp (filebuffer)
    elif hasattr(f, "fp") and hasattr(f.fp, "mode"):
        fileobj = f.fp

    # FILEIO -like (normal open(...)), keep as is.
    elif hasattr(f, "mode"):
        fileobj = f

    # Doesn't look like a file-like object, for example strings, urls or paths.
    else:
        return None

    return _fileobj_normalize_mode(fileobj)


def _fileobj_normalize_mode(f):
    """Takes care of some corner cases in Python where the mode string
    is either oddly formatted or does not truly represent the file mode.
    """
    mode = f.mode

    # Special case: Gzip modes:
    if isinstance(f, gzip.GzipFile):
        # GzipFiles can be either readonly or writeonly
        if mode == gzip.READ:
            return "rb"
        elif mode == gzip.WRITE:
            return "wb"
        else:
            return None  # This shouldn't happen?

    # Sometimes Python can produce modes like 'r+b' which will be normalized
    # here to 'rb+'
    if "+" in mode:
        mode = mode.replace("+", "")
        mode += "+"

    return mode


def fileobj_is_binary(f):
    """
    Returns True if the give file or file-like object has a file open in binary
    mode.  When in doubt, returns True by default.
            writeable mode.

        output_verify : str
            Output verification option.  Must be one of ``"fix"``,
            ``"silentfix"``, ``"ignore"``, ``"warn"``, or
            ``"exception"``.  May also be any combination of ``"fix"`` or
            ``"silentfix"`` with ``"+ignore"``, ``+warn``, or ``+exception"
            (e.g. ``"fix+warn"``).  See :ref:`astropy:verify` for more info.

        overwrite : bool, optional
            If ``True``, overwrite the output file if it exists. Raises an
            ``OSError`` if ``False`` and the output file exists. Default is
            ``False``.

        checksum : bool
            When `True` adds both ``DATASUM`` and ``CHECKSUM`` cards
            to the headers of all HDU's written to the file.

        Notes
        -----
        gzip, zip, bzip2 and lzma compression algorithms are natively supported.
        Compression mode is determined from the filename extension
        ('.gz', '.zip', '.bz2' or '.xz' respectively).  It is also possible to
        pass a compressed file object, e.g. `gzip.GzipFile`.
        """
        if len(self) == 0:
            warnings.warn("There is nothing to write.", AstropyUserWarning)
            return

        self.verify(option=output_verify)

        # make sure the EXTEND keyword is there if there is extension
        self.update_extend()

        if fileobj is sys.stdout:
            # special case stdout for debugging convenience
            # see https://github.com/astropy/astropy/issues/3427
            fileobj = fileobj.buffer

        # make note of whether the input file object is already open, in which
        # case we should not close it after writing (that should be the job
        # of the caller)
        closed = isinstance(fileobj, str) or fileobj_closed(fileobj)

        mode = FILE_MODES[fileobj_mode(fileobj)] if isfile(fileobj) else "ostream"

        # This can accept an open file object that's open to write only, or in
        # append/update modes but only if the file doesn't exist.
        fileobj = _File(fileobj, mode=mode, overwrite=overwrite)
        hdulist = self.fromfile(fileobj)
        try:
            dirname = os.path.dirname(hdulist._file.name)
        except (AttributeError, TypeError):
            dirname = None

        try:
            with _free_space_check(self, dirname=dirname):
                for hdu in self:
                    hdu._output_checksum = checksum
                    hdu._prewriteto()
                    hdu._writeto(hdulist._file)
                    hdu._postwriteto()
        finally:
            hdulist.close(output_verify=output_verify, closed=closed)

    def close(self, output_verify="exception", verbose=False, closed=True):
        """
        Close the associated FITS file and memmap object, if any.

        Parameters
        ----------
        output_verify : str
            Output verification option.  Must be one of ``"fix"``,
            ``"silentfix"``, ``"ignore"``, ``"warn"``, or
            ``"exception"``.  May also be any combination of ``"fix"`` or
            ``"silentfix"`` with ``"+ignore"``, ``+warn``, or ``+exception"
            (e.g. ``"fix+warn"``).  See :ref:`astropy:verify` for more info.

        verbose : bool
            When `True`, print out verbose messages.

        closed : bool
            When `True`, close the underlying file object.
        """
        try:
            if (
                self._file
                and self._file.mode in ("append", "update")
                and not self._file.closed
            ):
                self.flush(output_verify=output_verify, verbose=verbose)
        finally:
            if self._file and closed and hasattr(self._file, "close"):
                self._file.close()

            # Give individual HDUs an opportunity to do on-close cleanup
            for hdu in self:
                hdu._close(closed=closed)

    def info(self, output=None):
        """
        Summarize the info of the HDUs in this `HDUList`.

        Note that this function prints its results to the console---it
        does not return a value.

        Parameters
        ----------
        output : file-like or bool, optional
            A file-like object to write the output to.  If `False`, does not
            output to a file and instead returns a list of tuples representing
            the HDU info.  Writes to ``sys.stdout`` by default.
        """
        if output is None:
            output = sys.stdout

        if self._file is None:
            name = "(No file associated with this HDUList)"
        else:
            name = self._file.name

        results = [
            f"Filename: {name}",
            "No.    Name      Ver    Type      Cards   Dimensions   Format",
        ]

        format = "{:3d}  {:10}  {:3} {:11}  {:5d}   {}   {}   {}"
        default = ("", "", "", 0, (), "", "")
        for idx, hdu in enumerate(self):
            summary = hdu._summary()
            if len(summary) < len(default):
                summary += default[len(summary) :]
            summary = (idx,) + summary
            if output:
                results.append(format.format(*summary))
            else:
                results.append(summary)

        if output:
            output.write("\n".join(results))
            output.write("\n")
            output.flush()
        else:
            return results[2:]

    def filename(self):
        """
        Return the file name associated with the HDUList object if one exists.
        Otherwise returns None.

        Returns
        -------
        filename : str
            A string containing the file name associated with the HDUList
            object if an association exists.  Otherwise returns None.

        """
        if self._file is not None:
            if hasattr(self._file, "name"):
                return self._file.name
        return None

    @classmethod
    def _readfrom(
        cls,
        fileobj=None,
        data=None,
        mode=None,
        memmap=None,
        cache=True,
        lazy_load_hdus=True,
        ignore_missing_simple=False,
        *,
        use_fsspec=None,
        fsspec_kwargs=None,
        decompress_in_memory=False,
        **kwargs,
    ):
        """
        Provides the implementations from HDUList.fromfile and
        HDUList.fromstring, both of which wrap this method, as their
        implementations are largely the same.
        """
        if fileobj is not None:
            if not isinstance(fileobj, _File):
                # instantiate a FITS file object (ffo)
                fileobj = _File(
                    fileobj,
                    mode=mode,
                    memmap=memmap,
                    cache=cache,
                    use_fsspec=use_fsspec,
                    fsspec_kwargs=fsspec_kwargs,
                    decompress_in_memory=decompress_in_memory,
                )
            # The Astropy mode is determined by the _File initializer if the
            # supplied mode was None
            mode = fileobj.mode
            hdulist = cls(file=fileobj)
        else:
            if mode is None:
                # The default mode
                mode = "readonly"

            hdulist = cls(file=data)
            # This method is currently only called from HDUList.fromstring and
            # HDUList.fromfile.  If fileobj is None then this must be the
            # fromstring case; the data type of ``data`` will be checked in the
            # _BaseHDU.fromstring call.

        if (
            not ignore_missing_simple
            and hdulist._file
            and hdulist._file.mode != "ostream"
            and hdulist._file.size > 0
        ):
            pos = hdulist._file.tell()
            # FITS signature is supposed to be in the first 30 bytes, but to
            # allow reading various invalid files we will check in the first
            # card (80 bytes).
            simple = hdulist._file.read(80)
            match_sig = simple[:29] == FITS_SIGNATURE[:-1] and simple[29:30] in (
                b"T",
                b"F",
            )

            if not match_sig:
                # Check the SIMPLE card is there but not written correctly
                match_sig_relaxed = re.match(rb"SIMPLE\s*=\s*[T|F]", simple)

                if match_sig_relaxed:
                    warnings.warn(
                        "Found a SIMPLE card but its format doesn't"
                        " respect the FITS Standard",
                        VerifyWarning,
                    )
                else:
                    if hdulist._file.close_on_error:
                        hdulist._file.close()
                    raise OSError(
                        "No SIMPLE card found, this file does not appear to "
                        "be a valid FITS file. If this is really a FITS file, "
                        "try with ignore_missing_simple=True"
                    )

            hdulist._file.seek(pos)

        # Store additional keyword args that were passed to fits.open
        hdulist._open_kwargs = kwargs

        if fileobj is not None and fileobj.writeonly:
            # Output stream--not interested in reading/parsing
            # the HDUs--just writing to the output file
            return hdulist

        # Make sure at least the PRIMARY HDU can be read
        read_one = hdulist._read_next_hdu()

        # If we're trying to read only and no header units were found,
        # raise an exception
        if not read_one and mode in ("readonly", "denywrite"):
            # Close the file if necessary (issue #6168)
            if hdulist._file.close_on_error:
                hdulist._file.close()

            raise OSError("Empty or corrupt FITS file")

        if not lazy_load_hdus or kwargs.get("checksum") is True:
            # Go ahead and load all HDUs
            while hdulist._read_next_hdu():
                pass

        # initialize/reset attributes to be used in "update/append" mode
        hdulist._resize = False
        hdulist._truncate = False

        return hdulist

    def _try_while_unread_hdus(self, func, *args, **kwargs):
        """
        Attempt an operation that accesses an HDU by index/name
__init__.py
cfitsio_verify.c
conftest.py
test_checksum.py
test_connect.py
test_convenience.py
test_core.py
test_diff.py
test_division.py
test_fitscheck.py
test_fitsdiff.py
test_fitsheader.py
test_fitsinfo.py
test_fitstime.py
test_fsspec.py
test_groups.py
test_hdulist.py
test_header.py
test_image.py
test_image_dask.py
test_nonstandard.py
test_structured.py
test_table.py
test_uint.py
test_util.py
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "git status --short; grep -n \"def fileobj_closed\\|def path_like\\|path_like =\\|class path_like\" astropy/io/fits/util.py; grep -n \"fsspec\\|use_fsspec\" astropy/io/fits/file.py astropy/io/fits/tests/test_fsspec.py; sed -n '1,280p' astropy/io/fits/tests/test_fsspec.py; sed -n '1,260p' astropy/io/fits/tests/test_fitsheader.py"
```

退出码：`0`

输出：
```
26:path_like = (str, bytes, os.PathLike)
astropy/io/fits/tests/test_fsspec.py:2:"""Can `astropy.io.fits.open` access (remote) data using the fsspec package?"""
astropy/io/fits/tests/test_fsspec.py:15:    import fsspec
astropy/io/fits/tests/test_fsspec.py:18:@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
astropy/io/fits/tests/test_fsspec.py:19:def test_fsspec_local():
astropy/io/fits/tests/test_fsspec.py:20:    """Can we use fsspec to read a local file?"""
astropy/io/fits/tests/test_fsspec.py:23:        with fits.open(fn, use_fsspec=True) as hdulist_fsspec:
astropy/io/fits/tests/test_fsspec.py:24:            assert_array_equal(hdulist_classic[2].data, hdulist_fsspec[2].data)
astropy/io/fits/tests/test_fsspec.py:26:                hdulist_classic[2].section[3:5], hdulist_fsspec[2].section[3:5]
astropy/io/fits/tests/test_fsspec.py:30:@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
astropy/io/fits/tests/test_fsspec.py:31:def test_fsspec_local_write(tmp_path):
astropy/io/fits/tests/test_fsspec.py:32:    """Can we write to a local file that was opened using fsspec?"""
astropy/io/fits/tests/test_fsspec.py:35:    with fits.open(fn, use_fsspec=True) as hdul:
astropy/io/fits/tests/test_fsspec.py:49:@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
astropy/io/fits/tests/test_fsspec.py:50:def test_fsspec_cutout2d():
astropy/io/fits/tests/test_fsspec.py:51:    """Does Cutout2D work with data loaded lazily using fsspec and .section?"""
astropy/io/fits/tests/test_fsspec.py:53:    with fits.open(fn, use_fsspec=True) as hdul:
astropy/io/fits/tests/test_fsspec.py:61:@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
astropy/io/fits/tests/test_fsspec.py:62:def test_fsspec_compressed():
astropy/io/fits/tests/test_fsspec.py:63:    """Does fsspec support compressed data correctly?"""
astropy/io/fits/tests/test_fsspec.py:66:    with fits.open(fn, use_fsspec=True) as hdul:
astropy/io/fits/tests/test_fsspec.py:92:    @pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
astropy/io/fits/tests/test_fsspec.py:93:    def test_fsspec_http(self):
astropy/io/fits/tests/test_fsspec.py:94:        """Can we use fsspec to open a remote FITS file via http?"""
astropy/io/fits/tests/test_fsspec.py:95:        with fits.open(self.http_url, use_fsspec=True) as hdul:
astropy/io/fits/tests/test_fsspec.py:103:        # Can the user also pass an fsspec file object directly to fits open?
astropy/io/fits/tests/test_fsspec.py:104:        with fsspec.open(self.http_url) as fileobj:
astropy/io/fits/tests/test_fsspec.py:111:    def test_fsspec_s3(self):
astropy/io/fits/tests/test_fsspec.py:112:        """Can we use fsspec to open a FITS file in a public Amazon S3 bucket?"""
astropy/io/fits/tests/test_fsspec.py:114:            self.s3_uri, fsspec_kwargs={"anon": True}
astropy/io/fits/tests/test_fsspec.py:115:        ) as hdul:  # s3:// paths should default to use_fsspec=True
astropy/io/fits/tests/test_fsspec.py:123:        # Can the user also pass an fsspec file object directly to fits open?
astropy/io/fits/tests/test_fsspec.py:124:        with fsspec.open(self.s3_uri, anon=True) as fileobj:
astropy/io/fits/tests/test_fsspec.py:131:    def test_fsspec_s3_table(self):
astropy/io/fits/tests/test_fsspec.py:132:        """Can we use fsspec to open a FITS table in a public Amazon S3 bucket?"""
astropy/io/fits/tests/test_fsspec.py:134:        # s3:// paths should default to use_fsspec=True
astropy/io/fits/tests/test_fsspec.py:135:        with fits.open(self.s3_uri_table, fsspec_kwargs={"anon": True}) as hdul:
astropy/io/fits/tests/test_fsspec.py:142:            self.s3_uri_table, fsspec_kwargs={"anon": True}, format="fits", hdu=1
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""Can `astropy.io.fits.open` access (remote) data using the fsspec package?"""

import numpy as np
import pytest
from numpy.testing import assert_allclose, assert_array_equal

from astropy.io import fits
from astropy.nddata import Cutout2D
from astropy.table import Table
from astropy.utils.compat.optional_deps import HAS_FSSPEC, HAS_S3FS
from astropy.utils.data import get_pkg_data_filename

if HAS_FSSPEC:
    import fsspec


@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
def test_fsspec_local():
    """Can we use fsspec to read a local file?"""
    fn = get_pkg_data_filename("data/test0.fits")
    with fits.open(fn) as hdulist_classic:
        with fits.open(fn, use_fsspec=True) as hdulist_fsspec:
            assert_array_equal(hdulist_classic[2].data, hdulist_fsspec[2].data)
            assert_array_equal(
                hdulist_classic[2].section[3:5], hdulist_fsspec[2].section[3:5]
            )


@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
def test_fsspec_local_write(tmp_path):
    """Can we write to a local file that was opened using fsspec?"""
    fn = get_pkg_data_filename("data/test0.fits")
    fn_tmp = tmp_path / "tmp.fits"
    with fits.open(fn, use_fsspec=True) as hdul:
        # writing to a section is never allowed
        with pytest.raises(TypeError):
            hdul[1].section[0, 0] = -999
        # however writing to .data should work
        hdul[1].data[2, 3] = -999
        assert hdul[1].data[2, 3] == -999
        hdul.writeto(fn_tmp)

    # Is the new value present when we re-open the file?
    with fits.open(fn_tmp) as hdul:
        assert hdul[1].data[2, 3] == -999


@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
def test_fsspec_cutout2d():
    """Does Cutout2D work with data loaded lazily using fsspec and .section?"""
    fn = get_pkg_data_filename("data/test0.fits")
    with fits.open(fn, use_fsspec=True) as hdul:
        position = (10, 20)
        size = (2, 3)
        cutout1 = Cutout2D(hdul[1].data, position, size)
        cutout2 = Cutout2D(hdul[1].section, position, size)
        assert_allclose(cutout1.data, cutout2.data)


@pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
def test_fsspec_compressed():
    """Does fsspec support compressed data correctly?"""
    # comp.fits[1] is a compressed image with shape (440, 300)
    fn = get_pkg_data_filename("data/comp.fits")
    with fits.open(fn, use_fsspec=True) as hdul:
        # The .data attribute should work as normal
        assert hdul[1].data[0, 0] == 7
        # And the .section attribute should work too
        assert hdul[1].section[0, 0] == 7


@pytest.mark.remote_data
class TestFsspecRemote:
    """Test obtaining cutouts from FITS files via HTTP (from MAST) and S3 (from Amazon)."""

    def setup_class(self):
        # The test file (ibxl50020_jif.fits) is a Hubble jitter FITS file (*.jif)
        # rather than a real image, because jitter files are less likely to
        # change due to reprocessing.
        self.http_url = "https://mast.stsci.edu/api/v0.1/Download/file/?uri=mast:HST/product/ibxl50020_jif.fits"
        self.s3_uri = "s3://stpubdata/hst/public/ibxl/ibxl50020/ibxl50020_jif.fits"
        self.s3_uri_table = "s3://stpubdata/jwst/public/jw02565/jw02565001001/jw02565001001_03101_00002_nrs2_x1d.fits"
        # Random slice was selected for testing:
        self.slice = (slice(31, 33), slice(27, 30))
        # The expected cutout array below was obtained by downloading the URIs
        # listed above to a local path and and executing:
        # with fits.open(local_path) as hdul:
        #     expected_cutout = hdul[1].data[31:33, 27:30]
        self.expected_cutout = np.array([[24, 88, 228], [35, 132, 305]], dtype=np.int32)

    @pytest.mark.skipif(not HAS_FSSPEC, reason="requires fsspec")
    def test_fsspec_http(self):
        """Can we use fsspec to open a remote FITS file via http?"""
        with fits.open(self.http_url, use_fsspec=True) as hdul:
            # Do we retrieve the expected array?
            assert_array_equal(hdul[1].section[self.slice], self.expected_cutout)
            # The file has multiple extensions which are not yet downloaded;
            # the repr and string representation should reflect this.
            assert "partially read" in repr(hdul)
            assert "partially read" in str(hdul)

        # Can the user also pass an fsspec file object directly to fits open?
        with fsspec.open(self.http_url) as fileobj:
            with fits.open(fileobj) as hdul2:
                assert_array_equal(hdul2[1].section[self.slice], self.expected_cutout)
                assert "partially read" in repr(hdul)
                assert "partially read" in str(hdul)

    @pytest.mark.skipif(not HAS_S3FS, reason="requires s3fs")
    def test_fsspec_s3(self):
        """Can we use fsspec to open a FITS file in a public Amazon S3 bucket?"""
        with fits.open(
            self.s3_uri, fsspec_kwargs={"anon": True}
        ) as hdul:  # s3:// paths should default to use_fsspec=True
            # Do we retrieve the expected array?
            assert_array_equal(hdul[1].section[self.slice], self.expected_cutout)
            # The file has multiple extensions which are not yet downloaded;
            # the repr and string representation should reflect this.
            assert "partially read" in repr(hdul)
            assert "partially read" in str(hdul)

        # Can the user also pass an fsspec file object directly to fits open?
        with fsspec.open(self.s3_uri, anon=True) as fileobj:
            with fits.open(fileobj) as hdul2:
                assert_array_equal(hdul2[1].section[self.slice], self.expected_cutout)
                assert "partially read" in repr(hdul)
                assert "partially read" in str(hdul)

    @pytest.mark.skipif(not HAS_S3FS, reason="requires s3fs")
    def test_fsspec_s3_table(self):
        """Can we use fsspec to open a FITS table in a public Amazon S3 bucket?"""

        # s3:// paths should default to use_fsspec=True
        with fits.open(self.s3_uri_table, fsspec_kwargs={"anon": True}) as hdul:
            t1 = Table(hdul[1].data)

        assert len(t1) == 424
        assert len(t1.colnames) == 18

        t2 = Table.read(
            self.s3_uri_table, fsspec_kwargs={"anon": True}, format="fits", hdu=1
        )

        assert len(t2) == 424
        assert t1.colnames == t2.colnames
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import pytest

from astropy import __version__ as version
from astropy.io.fits.scripts import fitsheader

from .conftest import FitsTestCase


class TestFITSheader_script(FitsTestCase):
    def test_help(self):
        with pytest.raises(SystemExit) as e:
            fitsheader.main(["-h"])
        assert e.value.code == 0

    def test_version(self, capsys):
        with pytest.raises(SystemExit) as e:
            fitsheader.main(["--version"])
            out = capsys.readouterr()[0]
            assert out == f"fitsheader {version}"
        assert e.value.code == 0

    def test_file_exists(self, capsys):
        fitsheader.main([self.data("arange.fits")])
        out, err = capsys.readouterr()
        assert out.splitlines()[1].startswith(
            "SIMPLE  =                    T / conforms to FITS standard"
        )
        assert err == ""

    def test_by_keyword(self, capsys):
        fitsheader.main(["-k", "NAXIS", self.data("arange.fits")])
        out, err = capsys.readouterr()
        assert out.splitlines()[1].startswith(
            "NAXIS   =                    3 / number of array dimensions"
        )

        fitsheader.main(["-k", "NAXIS*", self.data("arange.fits")])
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 5
        assert out[1].startswith("NAXIS")
        assert out[2].startswith("NAXIS1")
        assert out[3].startswith("NAXIS2")
        assert out[4].startswith("NAXIS3")

        fitsheader.main(["-k", "RANDOMKEY", self.data("arange.fits")])
        out, err = capsys.readouterr()
        assert err.startswith("WARNING") and "RANDOMKEY" in err
        assert not err.startswith("ERROR")

    def test_by_extension(self, capsys):
        fitsheader.main(["-e", "1", self.data("test0.fits")])
        out, err = capsys.readouterr()
        assert len(out.splitlines()) == 62

        fitsheader.main(["-e", "3", "-k", "BACKGRND", self.data("test0.fits")])
        out, err = capsys.readouterr()
        assert out.splitlines()[1].startswith("BACKGRND=                 312.")

        fitsheader.main(["-e", "0", "-k", "BACKGRND", self.data("test0.fits")])
        out, err = capsys.readouterr()
        assert err.startswith("WARNING")

        fitsheader.main(["-e", "3", "-k", "FOO", self.data("test0.fits")])
        out, err = capsys.readouterr()
        assert err.startswith("WARNING")

    def test_table(self, capsys):
        fitsheader.main(["-t", "-k", "BACKGRND", self.data("test0.fits")])
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 5
        assert out[1].endswith("|   1 | BACKGRND | 316.0 |")
        assert out[2].endswith("|   2 | BACKGRND | 351.0 |")
        assert out[3].endswith("|   3 | BACKGRND | 312.0 |")
        assert out[4].endswith("|   4 | BACKGRND | 323.0 |")

        fitsheader.main(
            [
                "-t",
                "-e",
                "0",
                "-k",
                "NAXIS",
                self.data("arange.fits"),
                self.data("ascii.fits"),
                self.data("blank.fits"),
            ]
        )
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 4
        assert out[1].endswith("|   0 |   NAXIS |     3 |")
        assert out[2].endswith("|   0 |   NAXIS |     0 |")
        assert out[3].endswith("|   0 |   NAXIS |     2 |")

    def test_fitsort(self, capsys):
        fitsheader.main(
            [
                "-e",
                "0",
                "-f",
                "-k",
                "EXPSTART",
                "-k",
                "EXPTIME",
                self.data("test0.fits"),
                self.data("test1.fits"),
            ]
        )
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 4
        assert out[2].endswith("test0.fits 49491.65366175    0.23")
        assert out[3].endswith("test1.fits 49492.65366175    0.22")

        fitsheader.main(
            [
                "-e",
                "0",
                "-f",
                "-k",
                "EXPSTART",
                "-k",
                "EXPTIME",
                self.data("test0.fits"),
            ]
        )
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 3
        assert out[2].endswith("test0.fits 49491.65366175    0.23")

        fitsheader.main(
            ["-f", "-k", "NAXIS", self.data("tdim.fits"), self.data("test1.fits")]
        )
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 4
        assert out[0].endswith("0:NAXIS 1:NAXIS 2:NAXIS 3:NAXIS 4:NAXIS")
        assert out[2].endswith("tdim.fits       0       2      --      --      --")
        assert out[3].endswith("test1.fits       0       2       2       2       2")

        # check that files without required keyword are present
        fitsheader.main(
            ["-f", "-k", "DATE-OBS", self.data("table.fits"), self.data("test0.fits")]
        )
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 4
        assert out[2].endswith("table.fits       --")
        assert out[3].endswith("test0.fits 19/05/94")

        # check that COMMENT and HISTORY are excluded
        fitsheader.main(["-e", "0", "-f", self.data("tb.fits")])
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 3
        assert out[2].endswith(
            "tb.fits   True     16     0   True STScI-STSDAS/TABLES  tb.fits       1"
        )

    def test_fitsort_sorting_keyword_fitsort(self, capsys):
        """check that sorting by keyword works"""
        fitsheader.main(
            [
                "-f",
                "-k",
                "NAXIS",
                "-e",
                "0",
                self.data("group.fits"),
                self.data("test0.fits"),
            ]
        )
        out_unsorted, err_unsorted = capsys.readouterr()
        out_unsorted = out_unsorted.splitlines()

        fitsheader.main(
            [
                "-f",
                "-s",
                "NAXIS",
                "-k",
                "NAXIS",
                "-e",
                "0",
                self.data("group.fits"),
                self.data("test0.fits"),
            ]
        )
        out_sorted, err_sorted = capsys.readouterr()
        out_sorted = out_sorted.splitlines()

        assert len(out_unsorted) == 4
        assert out_unsorted[2].endswith("group.fits     5")
        assert out_unsorted[3].endswith("test0.fits     0")

        assert len(out_sorted) == 4
        assert out_sorted[2].endswith("test0.fits     0")
        assert out_sorted[3].endswith("group.fits     5")

    def test_fitsort_sorting_keyword_complains(self, capsys):
        with pytest.raises(SystemExit):
            fitsheader.main(
                ["-t", "-s", "DUMMY", self.data("group.fits"), self.data("test0.fits")]
            )
        out_table, err_table = capsys.readouterr()
        assert "only supported in conjunction with -f/--fitsort" in err_table
        with pytest.raises(SystemExit):
            fitsheader.main(
                ["-s", "DUMMY", self.data("group.fits"), self.data("test0.fits")]
            )
        out_default, err_default = capsys.readouterr()
        assert "only supported in conjunction with -f/--fitsort" in err_default

    def test_dotkeyword(self, capsys):
        fitsheader.main(["-e", "0", "-k", "ESO DET ID", self.data("fixed-1890.fits")])
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 2
        assert (
            out[1].strip().endswith("HIERARCH ESO DET ID = 'DV13' / Detector system Id")
        )

        fitsheader.main(["-e", "0", "-k", "ESO.DET.ID", self.data("fixed-1890.fits")])
        out, err = capsys.readouterr()
        out = out.splitlines()
        assert len(out) == 2
        assert (
            out[1].strip().endswith("HIERARCH ESO DET ID = 'DV13' / Detector system Id")
        )
```

## 原始行 37 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,125p' astropy/io/fits/tests/test_header.py; sed -n '1450,1725p' astropy/io/fits/tests/test_header.py; sed -n '1850,1925p' astropy/io/fits/tests/test_header.py; sed -n '2220,2320p' astropy/io/fits/tests/test_header.py; sed -n '2680,2770p' astropy/io/fits/tests/test_header.py; sed -n '1,180p' astropy/io/fits/util.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import collections
import copy
import warnings
from io import BytesIO, StringIO

import numpy as np
import pytest

from astropy.io import fits
from astropy.io.fits.card import _pad
from astropy.io.fits.header import _pad_length
from astropy.io.fits.scripts import fitsheader
from astropy.io.fits.util import encode_ascii
from astropy.io.fits.verify import VerifyError, VerifyWarning
from astropy.utils.exceptions import AstropyUserWarning
from astropy.utils.misc import _NOT_OVERWRITING_MSG_MATCH

from .conftest import FitsTestCase


def test_shallow_copy():
    """Make sure that operations on a shallow copy do not alter the original.
    #4990."""
    original_header = fits.Header([("a", 1), ("b", 1)])
    copied_header = copy.copy(original_header)

    # Modifying the original dict should not alter the copy
    original_header["c"] = 100
    assert "c" not in copied_header

    # and changing the copy should not change the original.
    copied_header["a"] = 0
    assert original_header["a"] == 1


def test_init_with_header():
    """Make sure that creating a Header from another Header makes a copy if
    copy is True."""

    original_header = fits.Header([("a", 10)])
    new_header = fits.Header(original_header, copy=True)
    original_header["a"] = 20
    assert new_header["a"] == 10

    new_header["a"] = 0
    assert original_header["a"] == 20


def test_init_with_dict():
    dict1 = {"a": 11, "b": 12, "c": 13, "d": 14, "e": 15}
    h1 = fits.Header(dict1)
    for i, expected in dict1.items():
        assert h1[i] == expected


def test_init_with_ordereddict():
    # Create a list of tuples. Each tuple consisting of a letter and the number
    list1 = [(i, j) for j, i in enumerate("abcdefghijklmnopqrstuvwxyz")]
    # Create an ordered dictionary and a header from this dictionary
    dict1 = collections.OrderedDict(list1)
    h1 = fits.Header(dict1)
    # Check that the order is preserved of the initial list
    assert all(h1[val] == list1[i][1] for i, val in enumerate(h1))


class TestHeaderFunctions(FitsTestCase):
    """Test Header and Card objects."""

    def test_rename_keyword(self):
        """Test renaming keyword with rename_keyword."""
        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])
        header.rename_keyword("A", "B")
        assert "A" not in header
        assert "B" in header
        assert header[0] == "B"
        assert header["B"] == "B"
        assert header.comments["B"] == "C"

    @pytest.mark.parametrize("key", ["A", "a"])
    def test_indexing_case(self, key):
        """Check that indexing is case insensitive"""
        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])
        assert key in header
        assert header[key] == "B"
        assert header.get(key) == "B"
        assert header.index(key) == 0
        assert header.comments[key] == "C"
        assert header.count(key) == 1
        header.remove(key, ignore_missing=False)

    def test_card_constructor_default_args(self):
        """Test Card constructor with default argument values."""

        c = fits.Card()
        assert c.keyword == ""

    def test_card_from_bytes(self):
        """
        Test loading a Card from a `bytes` object (assuming latin-1 encoding).
        """

        c = fits.Card.fromstring(b"ABC     = 'abc'")
        assert c.keyword == "ABC"
        assert c.value == "abc"

    def test_string_value_card(self):
        """Test Card constructor with string value"""

        c = fits.Card("abc", "<8 ch")
        assert str(c) == _pad("ABC     = '<8 ch   '")
        c = fits.Card("nullstr", "")
        assert str(c) == _pad("NULLSTR = ''")

    def test_boolean_value_card(self):
        """Test Card constructor with boolean value"""

        c = fits.Card("abc", True)
        assert str(c) == _pad("ABC     =                    T")

        c = fits.Card.fromstring("ABC     = F")
        assert c.value is False

    def test_long_integer_value_card(self):
        hdu2 = fits.ImageHDU()
        hdu.header["MYKEY"] = ("some val", "some comment")
        hdu.header["HISTORY"] = "history 1"
        hdu2.header["MYKEY"] = ("some other val", "some other comment")
        hdu2.header["HISTORY"] = "history 1"
        hdu2.header["HISTORY"] = "history 2"
        hdu.header.extend(hdu2.header)
        assert len(hdu.header) == 9
        assert ("MYKEY", 0) in hdu.header
        assert ("MYKEY", 1) in hdu.header
        assert hdu.header[("MYKEY", 1)] == "some other val"
        assert len(hdu.header["HISTORY"]) == 3
        assert hdu.header[-1] == "history 2"

        hdu = fits.PrimaryHDU()
        hdu.header["MYKEY"] = ("some val", "some comment")
        hdu.header["HISTORY"] = "history 1"
        hdu.header.extend(hdu2.header, update=True)
        assert len(hdu.header) == 7
        assert ("MYKEY", 0) in hdu.header
        assert ("MYKEY", 1) not in hdu.header
        assert hdu.header["MYKEY"] == "some other val"
        assert len(hdu.header["HISTORY"]) == 2
        assert hdu.header[-1] == "history 2"

    def test_header_extend_update_commentary(self):
        """
        Test extending header with and without unique=True and commentary
        cards in the header being added.

        Though not quite the same as astropy/astropy#3967, update=True hits
        the same if statement as that issue.
        """
        for commentary_card in ["", "COMMENT", "HISTORY"]:
            for is_update in [True, False]:
                hdu = fits.PrimaryHDU()
                # Make sure we are testing the case we want.
                assert commentary_card not in hdu.header
                hdu2 = fits.ImageHDU()
                hdu2.header[commentary_card] = "My text"
                hdu.header.extend(hdu2.header, update=is_update)
                assert len(hdu.header) == 5
                assert hdu.header[commentary_card][0] == "My text"

    def test_header_extend_exact(self):
        """
        Test that extending an empty header with the contents of an existing
        header can exactly duplicate that header, given strip=False and
        end=True.
        """

        header = fits.getheader(self.data("test0.fits"))
        header2 = fits.Header()
        header2.extend(header, strip=False, end=True)
        assert header == header2

    def test_header_count(self):
        header = fits.Header([("A", "B"), ("C", "D"), ("E", "F")])
        assert header.count("A") == 1
        assert header.count("C") == 1
        assert header.count("E") == 1
        header["HISTORY"] = "a"
        header["HISTORY"] = "b"
        assert header.count("HISTORY") == 2
        pytest.raises(KeyError, header.count, "G")

    def test_header_append_use_blanks(self):
        """
        Tests that blank cards can be appended, and that future appends will
        use blank cards when available (unless useblanks=False)
        """

        header = fits.Header([("A", "B"), ("C", "D")])

        # Append a couple blanks
        header.append()
        header.append()
        assert len(header) == 4
        assert header[-1] == ""
        assert header[-2] == ""

        # New card should fill the first blank by default
        header.append(("E", "F"))
        assert len(header) == 4
        assert header[-2] == "F"
        assert header[-1] == ""

        # This card should not use up a blank spot
        header.append(("G", "H"), useblanks=False)
        assert len(header) == 5
        assert header[-1] == ""
        assert header[-2] == "H"

    def test_header_append_keyword_only(self):
        """
        Test appending a new card with just the keyword, and no value or
        comment given.
        """

        header = fits.Header([("A", "B"), ("C", "D")])
        header.append("E")
        assert len(header) == 3
        assert list(header)[-1] == "E"
        assert header[-1] is None
        assert header.comments["E"] == ""

        # Try appending a blank--normally this can be accomplished with just
        # header.append(), but header.append('') should also work (and is maybe
        # a little more clear)
        header.append("")
        assert len(header) == 4

        assert list(header)[-1] == ""
        assert header[""] == ""
        assert header.comments[""] == ""

    def test_header_insert_use_blanks(self):
        header = fits.Header([("A", "B"), ("C", "D")])

        # Append a couple blanks
        header.append()
        header.append()

        # Insert a new card; should use up one of the blanks
        header.insert(1, ("E", "F"))
        assert len(header) == 4
        assert header[1] == "F"
        assert header[-1] == ""
        assert header[-2] == "D"

        # Insert a new card without using blanks
        header.insert(1, ("G", "H"), useblanks=False)
        assert len(header) == 5
        assert header[1] == "H"
        assert header[-1] == ""

    def test_header_insert_before_keyword(self):
        """
        Test that a keyword name or tuple can be used to insert new keywords.

        Also tests the ``after`` keyword argument.

        Regression test for https://github.com/spacetelescope/PyFITS/issues/12
        """

        header = fits.Header(
            [("NAXIS1", 10), ("COMMENT", "Comment 1"), ("COMMENT", "Comment 3")]
        )

        header.insert("NAXIS1", ("NAXIS", 2, "Number of axes"))
        assert list(header.keys())[0] == "NAXIS"
        assert header[0] == 2
        assert header.comments[0] == "Number of axes"

        header.insert("NAXIS1", ("NAXIS2", 20), after=True)
        assert list(header.keys())[1] == "NAXIS1"
        assert list(header.keys())[2] == "NAXIS2"
        assert header[2] == 20

        header.insert(("COMMENT", 1), ("COMMENT", "Comment 2"))
        assert header["COMMENT"] == ["Comment 1", "Comment 2", "Comment 3"]

        header.insert(("COMMENT", 2), ("COMMENT", "Comment 4"), after=True)
        assert header["COMMENT"] == ["Comment 1", "Comment 2", "Comment 3", "Comment 4"]

        header.insert(-1, ("TEST1", True))
        assert list(header.keys())[-2] == "TEST1"

        header.insert(-1, ("TEST2", True), after=True)
        assert list(header.keys())[-1] == "TEST2"
        assert list(header.keys())[-3] == "TEST1"

    def test_remove(self):
        header = fits.Header([("A", "B"), ("C", "D")])

        # When keyword is present in the header it should be removed.
        header.remove("C")
        assert len(header) == 1
        assert list(header) == ["A"]
        assert "C" not in header

        # When keyword is not present in the header and ignore_missing is
        # False, KeyError should be raised
        with pytest.raises(KeyError):
            header.remove("F")

        # When keyword is not present and ignore_missing is True, KeyError
        # will be ignored
        header.remove("F", ignore_missing=True)
        assert len(header) == 1

        # Test for removing all instances of a keyword
        header = fits.Header([("A", "B"), ("C", "D"), ("A", "F")])
        header.remove("A", remove_all=True)
        assert "A" not in header
        assert len(header) == 1
        assert list(header) == ["C"]
        assert header[0] == "D"

    def test_header_comments(self):
        header = fits.Header([("A", "B", "C"), ("DEF", "G", "H")])
        assert repr(header.comments) == "       A  C\n     DEF  H"

    def test_comment_slices_and_filters(self):
        header = fits.Header([("AB", "C", "D"), ("EF", "G", "H"), ("AI", "J", "K")])
        s = header.comments[1:]
        assert list(s) == ["H", "K"]
        s = header.comments[::-1]
        assert list(s) == ["K", "H", "D"]
        s = header.comments["A*"]
        assert list(s) == ["D", "K"]

    def test_comment_slice_filter_assign(self):
        header = fits.Header([("AB", "C", "D"), ("EF", "G", "H"), ("AI", "J", "K")])
        header.comments[1:] = "L"
        assert list(header.comments) == ["D", "L", "L"]
        assert header.cards[header.index("AB")].comment == "D"
        assert header.cards[header.index("EF")].comment == "L"
        assert header.cards[header.index("AI")].comment == "L"

        header.comments[::-1] = header.comments[:]
        assert list(header.comments) == ["L", "L", "D"]

        header.comments["A*"] = ["M", "N"]
        assert list(header.comments) == ["M", "L", "N"]

    def test_commentary_slicing(self):
        header = fits.Header()

        indices = list(range(5))

        for idx in indices:
            header["HISTORY"] = idx

        # Just a few sample slice types; this won't get all corner cases but if
        # these all work we should be in good shape
        assert header["HISTORY"][1:] == indices[1:]
        assert header["HISTORY"][:3] == indices[:3]
        assert header["HISTORY"][:6] == indices[:6]
        assert header["HISTORY"][:-2] == indices[:-2]
        assert header["HISTORY"][::-1] == indices[::-1]
        assert header["HISTORY"][1::-1] == indices[1::-1]
        assert header["HISTORY"][1:5:2] == indices[1:5:2]

        # Same tests, but copy the values first; as it turns out this is
        # different from just directly doing an __eq__ as in the first set of
        # assertions
        header.insert(0, ("A", "B", "C"))
        header.append(("D", "E", "F"), end=True)
        assert list(header["HISTORY"][1:]) == indices[1:]
        assert list(header["HISTORY"][:3]) == indices[:3]
        assert list(header["HISTORY"][:6]) == indices[:6]
        assert list(header["HISTORY"][:-2]) == indices[:-2]
        assert list(header["HISTORY"][::-1]) == indices[::-1]
        assert list(header["HISTORY"][1::-1]) == indices[1::-1]
        assert list(header["HISTORY"][1:5:2]) == indices[1:5:2]

    def test_update_commentary(self):
        header = fits.Header()
        header["FOO"] = "BAR"
        header["HISTORY"] = "ABC"
        header["FRED"] = "BARNEY"
        header["HISTORY"] = "DEF"
        header["HISTORY"] = "GHI"

        assert header["HISTORY"] == ["ABC", "DEF", "GHI"]

        # Single value update
        header["HISTORY"][0] = "FOO"
        assert header["HISTORY"] == ["FOO", "DEF", "GHI"]

        # Single value partial slice update
        header["HISTORY"][1:] = "BAR"
        assert header["HISTORY"] == ["FOO", "BAR", "BAR"]

        # Multi-value update
            hdu.header.fromfile(header_filename),
            update=True,
            update_first=True,
            strip=False,
        )
        assert "MYKEY" in hdu.header
        assert "EXTENSION" not in hdu.header
        assert "SIMPLE" in hdu.header

        hdu.writeto(self.temp("test.fits"), output_verify="ignore", overwrite=True)

        with fits.open(self.temp("test.fits")) as hdul2:
            assert len(hdul2) == 2
            assert "MYKEY" in hdul2[1].header

    def test_fromfile(self):
        """Regression test for https://github.com/astropy/astropy/issues/8711"""
        filename = self.data("scale.fits")
        hdr = fits.Header.fromfile(filename)
        assert hdr["DATASET"] == "2MASS"

    def test_header_fromtextfile(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/122

        Manually write a text file containing some header cards ending with
        newlines and ensure that fromtextfile can read them back in.
        """

        header = fits.Header()
        header["A"] = ("B", "C")
        header["B"] = ("C", "D")
        header["C"] = ("D", "E")

        with open(self.temp("test.hdr"), "w") as f:
            f.write("\n".join(str(c).strip() for c in header.cards))

        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
        assert header == header2

    def test_header_fromtextfile_with_end_card(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/154

        Make sure that when a Header is read from a text file that the END card
        is ignored.
        """

        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])

        # We don't use header.totextfile here because it writes each card with
        # trailing spaces to pad them out to 80 characters.  But this bug only
        # presents itself when each card ends immediately with a newline, and
        # no trailing spaces
        with open(self.temp("test.hdr"), "w") as f:
            f.write("\n".join(str(c).strip() for c in header.cards))
            f.write("\nEND")

        new_header = fits.Header.fromtextfile(self.temp("test.hdr"))

        assert "END" not in new_header
        assert header == new_header

    def test_append_end_card(self):
        """
        Regression test 2 for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/154

        Manually adding an END card to a header should simply result in a
        ValueError (as was the case in PyFITS 3.0 and earlier).
        """

        header = fits.Header([("A", "B", "C"), ("D", "E", "F")])

        def setitem(k, v):
            header[k] = v

        pytest.raises(ValueError, setitem, "END", "")
        pytest.raises(ValueError, header.append, "END")
        assert h["geh"] == 3

        # Case insensitivity of wildcards
        assert len(h["g*"]) == 1

        h["aBc"] = 2
        assert h["abc"] == 2
        # ABC already existed so assigning to aBc should not have added any new
        # cards
        assert len(h) == 3

        del h["gEh"]
        assert list(h) == ["ABC", "DEF"]
        assert len(h) == 2
        assert h.get("def") == 2

        h.set("Abc", 3)
        assert h["ABC"] == 3
        h.set("gEh", 3, before="Abc")
        assert list(h) == ["GEH", "ABC", "DEF"]

        assert h.pop("abC") == 3
        assert len(h) == 2

        assert h.setdefault("def", 3) == 2
        assert len(h) == 2
        assert h.setdefault("aBc", 1) == 1
        assert len(h) == 3
        assert list(h) == ["GEH", "DEF", "ABC"]

        h.update({"GeH": 1, "iJk": 4})
        assert len(h) == 4
        assert list(h) == ["GEH", "DEF", "ABC", "IJK"]
        assert h["GEH"] == 1

        assert h.count("ijk") == 1
        assert h.index("ijk") == 3

        h.remove("Def")
        assert len(h) == 3
        assert list(h) == ["GEH", "ABC", "IJK"]

    def test_end_in_comment(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/142

        Tests a case where the comment of a card ends with END, and is followed
        by several blank cards.
        """

        data = np.arange(100).reshape(10, 10)
        hdu = fits.PrimaryHDU(data=data)
        hdu.header["TESTKW"] = ("Test val", "This is the END")
        # Add a couple blanks after the END string
        hdu.header.append()
        hdu.header.append()
        hdu.writeto(self.temp("test.fits"))

        with fits.open(self.temp("test.fits"), memmap=False) as hdul:
            # memmap = False to avoid leaving open a mmap to the file when we
            # access the data--this causes problems on Windows when we try to
            # overwrite the file later
            assert "TESTKW" in hdul[0].header
            assert hdul[0].header == hdu.header
            assert (hdul[0].data == data).all()

        # Add blanks until the header is extended to two block sizes
        while len(hdu.header) < 36:
            hdu.header.append()
        hdu.writeto(self.temp("test.fits"), overwrite=True)

        with fits.open(self.temp("test.fits")) as hdul:
            assert "TESTKW" in hdul[0].header
            assert hdul[0].header == hdu.header
            assert (hdul[0].data == data).all()

        # Test parsing the same header when it's written to a text file
        hdu.header.totextfile(self.temp("test.hdr"))
        header2 = fits.Header.fromtextfile(self.temp("test.hdr"))
        assert hdu.header == header2

    def test_assign_unicode(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/134

        Assigning a unicode literal as a header value should not fail silently.
        If the value can be converted to ASCII then it should just work.
        Otherwise it should fail with an appropriate value error.

        Also tests unicode for keywords and comments.
        """

        erikku = "\u30a8\u30ea\u30c3\u30af"

        def assign(keyword, val):
            h[keyword] = val

        h = fits.Header()
        h["FOO"] = "BAR"
        assert "FOO" in h
        assert h["FOO"] == "BAR"
        assert hdr["KEY2"] == 4
        assert hdr["KEY2 "] == 4

    def test_strip(self):
        hdr = fits.getheader(self.data("tb.fits"), ext=1)
        hdr["FOO"] = "bar"
        hdr.strip()
        assert set(hdr) == {"HISTORY", "FOO"}

        hdr = fits.getheader(self.data("tb.fits"), ext=1)
        hdr["FOO"] = "bar"
        hdr = hdr.copy(strip=True)
        assert set(hdr) == {"HISTORY", "FOO"}

    def test_update_invalid_card(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/5408

        Tests updating the value of a card that is malformatted (with an
        invalid value literal).

        This tests two ways of reproducing the problem, one working with a
        Card object directly, and one when reading/writing a header containing
        such an invalid card.
        """

        card = fits.Card.fromstring("KW      = INF  / Comment")
        card.value = "FIXED"
        assert tuple(card) == ("KW", "FIXED", "Comment")
        card.verify("fix")
        assert tuple(card) == ("KW", "FIXED", "Comment")

        card = fits.Card.fromstring("KW      = INF")
        hdu = fits.PrimaryHDU()
        # This is a loophole to write a header containing a malformatted card
        card._verified = True
        hdu.header.append(card)
        hdu.header.tofile(self.temp("bogus.fits"))

        with fits.open(self.temp("bogus.fits")) as hdul:
            hdul[0].header["KW"] = -1
            hdul.writeto(self.temp("bogus_fixed.fits"))

        with fits.open(self.temp("bogus_fixed.fits")) as hdul:
            assert hdul[0].header["KW"] == -1

    def test_index_numpy_int(self):
        header = fits.Header([("A", "FOO"), ("B", 2), ("C", "BAR")])
        idx = np.int8(2)
        assert header[idx] == "BAR"

        header[idx] = "BAZ"
        assert header[idx] == "BAZ"

        header.insert(idx, ("D", 42))
        assert header[idx] == 42

        header.add_comment("HELLO")
        header.add_comment("WORLD")
        assert header["COMMENT"][np.int64(1)] == "WORLD"

        header.append(("C", "BAZBAZ"))
        assert header[("C", np.int16(0))] == "BAZ"
        assert header[("C", np.uint32(1))] == "BAZBAZ"

    def test_header_data_size(self):
        """
        Tests data size calculation (w/o padding) given a Header.
        """
        hdu = fits.PrimaryHDU()
        header = hdu.header
        assert header.data_size == 0

        header["BITPIX"] = 32
        header["NAXIS"] = 2
        header["NAXIS1"] = 100
        header["NAXIS2"] = 100
        assert header.data_size == 40000
        assert header.data_size_padded == 40320


class TestRecordValuedKeywordCards(FitsTestCase):
    """
    Tests for handling of record-valued keyword cards as used by the
    `FITS WCS distortion paper
    <https://www.atnf.csiro.au/people/mcalabre/WCS/dcs_20040422.pdf>`__.

    These tests are derived primarily from the release notes for PyFITS 1.4 (in
    which this feature was first introduced.
    Note that extra leading spaces in the `value` fields should be parsed on input,
    but will be stripped in the cards.
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import gzip
import io
import mmap
import operator
import os
import platform
import signal
import sys
import tempfile
import textwrap
import threading
import warnings
import weakref
from contextlib import contextmanager, suppress
from functools import wraps

import numpy as np
from packaging.version import Version

from astropy.utils import data
from astropy.utils.compat.optional_deps import HAS_DASK
from astropy.utils.exceptions import AstropyUserWarning

path_like = (str, bytes, os.PathLike)

cmp = lambda a, b: (a > b) - (a < b)

all_integer_types = (int, np.integer)


class NotifierMixin:
    """
    Mixin class that provides services by which objects can register
    listeners to changes on that object.

    All methods provided by this class are underscored, since this is intended
    for internal use to communicate between classes in a generic way, and is
    not machinery that should be exposed to users of the classes involved.

    Use the ``_add_listener`` method to register a listener on an instance of
    the notifier.  This registers the listener with a weak reference, so if
    no other references to the listener exist it is automatically dropped from
    the list and does not need to be manually removed.

    Call the ``_notify`` method on the notifier to update all listeners
    upon changes.  ``_notify('change_type', *args, **kwargs)`` results
    in calling ``listener._update_change_type(*args, **kwargs)`` on all
    listeners subscribed to that notifier.

    If a particular listener does not have the appropriate update method
    it is ignored.

    Examples
    --------
    >>> class Widget(NotifierMixin):
    ...     state = 1
    ...     def __init__(self, name):
    ...         self.name = name
    ...     def update_state(self):
    ...         self.state += 1
    ...         self._notify('widget_state_changed', self)
    ...
    >>> class WidgetListener:
    ...     def _update_widget_state_changed(self, widget):
    ...         print('Widget {0} changed state to {1}'.format(
    ...             widget.name, widget.state))
    ...
    >>> widget = Widget('fred')
    >>> listener = WidgetListener()
    >>> widget._add_listener(listener)
    >>> widget.update_state()
    Widget fred changed state to 2
    """

    _listeners = None













    def _remove_listener(self, listener):
        """
        Removes the specified listener from the listeners list.  This relies
        on object identity (i.e. the ``is`` operator).
        """
        if self._listeners is None:
            return

        with suppress(KeyError):
            del self._listeners[id(listener)]

    def _notify(self, notification, *args, **kwargs):
        """
        Notify all listeners of some particular state change by calling their
        ``_update_<notification>`` method with the given ``*args`` and
        ``**kwargs``.

        The notification does not by default include the object that actually
        changed (``self``), but it certainly may if required.
        """
        if self._listeners is None:
            return

        method_name = f"_update_{notification}"
        for listener in self._listeners.valuerefs():
            # Use valuerefs instead of itervaluerefs; see
            # https://github.com/astropy/astropy/issues/4015
            listener = listener()  # dereference weakref
            if listener is None:
                continue

            if hasattr(listener, method_name):
                method = getattr(listener, method_name)
                if callable(method):
                    method(*args, **kwargs)

    def __getstate__(self):
        """
        Exclude listeners when saving the listener's state, since they may be
        ephemeral.
        """
        # TODO: This hasn't come up often, but if anyone needs to pickle HDU
        # objects it will be necessary when HDU objects' states are restored to
        # re-register themselves as listeners on their new column instances.
        try:
            state = super().__getstate__()
        except AttributeError:
            # Chances are the super object doesn't have a getstate
            state = self.__dict__.copy()

        state["_listeners"] = None
        return state


def first(iterable):
    """
    Returns the first item returned by iterating over an iterable object.

    Examples
    --------
    >>> a = [1, 2, 3]
    >>> first(a)
    1
    """
    return next(iter(iterable))


def itersubclasses(cls, _seen=None):
    """
    Generator over all subclasses of a given class, in depth first order.

    >>> class A: pass
    >>> class B(A): pass
    >>> class C(A): pass
    >>> class D(B,C): pass
    >>> class E(D): pass
    >>>
    >>> for cls in itersubclasses(A):
    ...     print(cls.__name__)
    B
    D
    E
    C
    >>> # get ALL classes currently defined
    >>> [cls.__name__ for cls in itersubclasses(object)]
    [...'tuple', ...'type', ...]

    From http://code.activestate.com/recipes/576949/
    """
    if _seen is None:
```

## 原始行 40 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"def fileobj_closed\\|fileobj_closed =\" astropy --include='*.py' || true; grep -RIn \"def _array_from_file\\|def _array_to_file\" astropy/io/fits/util.py; grep -RIn \"def _is_url\" astropy/utils/data.py; python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1"
```

退出码：`1`

输出：
```
505:def _array_from_file(infile, dtype, count):
545:def _array_to_file(arr, outfile):
603:def _array_to_file_like(arr, fileobj):
Internet access disabled

==================================== ERRORS ====================================
____________ ERROR collecting astropy/io/fits/tests/test_header.py _____________
astropy/io/fits/tests/test_header.py:68: in <module>
    class TestHeaderFunctions(FitsTestCase):
astropy/io/fits/tests/test_header.py:1201: in TestHeaderFunctions
    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
                                         ^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1242: in __init__
    super().__init__(
astropy/io/fits/hdu/image.py:87: in __init__
    new_header = Header(cards)
                 ^^^^^^^^^^^^^
astropy/io/fits/header.py:127: in __init__
    self.append(card, end=True)
    ^^^^^^^^^^^
E   AttributeError: 'Header' object has no attribute 'append'
=========================== short test summary info ============================
ERROR astropy/io/fits/tests/test_header.py - AttributeError: 'Header' object ...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 error in 0.45s
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def is_blank\\|is_blank\" astropy/io/fits/card.py | head; sed -n '140,260p' astropy/io/fits/card.py; grep -RIn \"_updateindices\\|_relativeinsert\" astropy/io/fits/tests/test_header.py; grep -n \"test_.*append\\|test_.*insert\\|test_countblanks\\|countblanks\" astropy/io/fits/tests/test_header.py"
```

退出码：`0`

输出：
```
533:    def is_blank(self):
    _rvkc_field_specifier_val_RE = re.compile(_rvkc_field_specifier_val + "$")

    # regular expression to extract the key and the field specifier from a
    # string that is being used to index into a card list that contains
    # record value keyword cards (ex. 'DP1.AXIS.1')
    _rvkc_keyword_name_RE = re.compile(
        rf"(?P<keyword>{_rvkc_identifier})\.(?P<field_specifier>{_rvkc_field_specifier_s})$"
    )

    # regular expression to extract the field specifier and value and comment
    # from the string value of a record value keyword card
    # (ex "'AXIS.1: 1' / a comment")
    _rvkc_keyword_val_comm_RE = re.compile(_rvkc_keyword_val_comm)

    _commentary_keywords = {"", "COMMENT", "HISTORY", "END"}
    _special_keywords = _commentary_keywords.union(["CONTINUE"])

    # The default value indicator; may be changed if required by a convention
    # (namely HIERARCH cards)
    _value_indicator = VALUE_INDICATOR

    def __init__(self, keyword=None, value=None, comment=None, **kwargs):
        # For backwards compatibility, support the 'key' keyword argument:
        if keyword is None and "key" in kwargs:
            keyword = kwargs["key"]

        self._keyword = None
        self._value = None
        self._comment = None
        self._valuestring = None
        self._image = None

        # This attribute is set to False when creating the card from a card
        # image to ensure that the contents of the image get verified at some
        # point
        self._verified = True

        # A flag to conveniently mark whether or not this was a valid HIERARCH
        # card
        self._hierarch = False

        # If the card could not be parsed according the FITS standard or
        # any recognized non-standard conventions, this will be True
        self._invalid = False

        self._field_specifier = None

        # These are used primarily only by RVKCs
        self._rawkeyword = None
        self._rawvalue = None

        if not (
            keyword is not None
            and value is not None
            and self._check_if_rvkc(keyword, value)
        ):
            # If _check_if_rvkc passes, it will handle setting the keyword and
            # value
            if keyword is not None:
                self.keyword = keyword
            if value is not None:
                self.value = value

        if comment is not None:
            self.comment = comment

        self._modified = False
        self._valuemodified = False

    def __repr__(self):
        return repr((self.keyword, self.value, self.comment))

    def __str__(self):
        return self.image

    def __len__(self):
        return 3

    def __getitem__(self, index):
        return (self.keyword, self.value, self.comment)[index]

    @property
    def keyword(self):
        """Returns the keyword name parsed from the card image."""
        if self._keyword is not None:
            return self._keyword
        elif self._image:
            self._keyword = self._parse_keyword()
            return self._keyword
        else:
            self.keyword = ""
            return ""

    @keyword.setter
    def keyword(self, keyword):
        """Set the key attribute; once set it cannot be modified."""
        if self._keyword is not None:
            raise AttributeError("Once set, the Card keyword may not be modified")
        elif isinstance(keyword, str):
            # Be nice and remove trailing whitespace--some FITS code always
            # pads keywords out with spaces; leading whitespace, however,
            # should be strictly disallowed.
            keyword = keyword.rstrip()
            keyword_upper = keyword.upper()
            if len(keyword) <= KEYWORD_LENGTH and self._keywd_FSC_RE.match(
                keyword_upper
            ):
                # For keywords with length > 8 they will be HIERARCH cards,
                # and can have arbitrary case keywords
                if keyword_upper == "END":
                    raise ValueError("Keyword 'END' not allowed.")
                keyword = keyword_upper
            elif self._keywd_hierarch_RE.match(keyword):
                # In prior versions of PyFITS (*) HIERARCH cards would only be
                # created if the user-supplied keyword explicitly started with
                # 'HIERARCH '.  Now we will create them automatically for long
                # keywords, but we still want to support the old behavior too;
                # the old behavior makes it possible to create HIERARCH cards
                # that would otherwise be recognized as RVKCs
                # (*) This has never affected Astropy, because it was changed
                # before PyFITS was merged into Astropy!
840:    def test_hierarch_card_insert_delete(self):
1516:    def test_header_append_use_blanks(self):
1543:    def test_header_append_keyword_only(self):
1566:    def test_header_insert_use_blanks(self):
1586:    def test_header_insert_before_keyword(self):
1911:    def test_append_end_card(self):
2633:    def test_long_commentary_card_appended_to_header(self):
2957:    def test_rvkc_insert_after(self):
```

## 原始行 45 · command_execution

命令：
```
/bin/bash -lc "sed -n '510,550p' astropy/io/fits/card.py; sed -n '810,870p' astropy/io/fits/tests/test_header.py; sed -n '2590,2675p' astropy/io/fits/tests/test_header.py; sed -n '2935,2980p' astropy/io/fits/tests/test_header.py; grep -RIn \"_File\" astropy/io/fits/tests | head -100; grep -n \"def test_.*file\\|class TestFile\\|fileobj\" astropy/io/fits/tests/test_core.py | head -100"
```

退出码：`0`

输出：
```
            self._keyword = f"{keyword}.{field_specifier}"
            self._modified = True

    @field_specifier.deleter
    def field_specifier(self):
        raise AttributeError(
            "The field_specifier attribute may not be "
            "deleted from record-valued keyword cards."
        )

    @property
    def image(self):
        """
        The card "image", that is, the 80 byte character string that represents
        this card in an actual FITS header.
        """
        if self._image and not self._verified:
            self.verify("fix+warn")
        if self._image is None or self._modified:
            self._image = self._format_image()
        return self._image

    @property
    def is_blank(self):
        """
        `True` if the card is completely blank--that is, it has no keyword,
        value, or comment.  It appears in the header as 80 spaces.

        Returns `False` otherwise.
        """
        if not self._verified:
            # The card image has not been parsed yet; compare directly with the
            # string representation of a blank card
            return self._image == BLANK_CARD

        # If the keyword, value, and comment are all empty (for self.value
        # explicitly check that it is a string value, since a blank value is
        # returned as '')
        return (
            not self.keyword
            and (isinstance(self.value, str) and not self.value)
            assert str(header.cards[header.index("key.META_0")]) == str(
                header2.cards[header2.index("key.META_0")]
            )

    def test_missing_keyword(self):
        """Test that accessing a non-existent keyword raises a KeyError."""

        header = fits.Header()
        # De-referencing header through the inline function should behave
        # identically to accessing it in the pytest.raises context below.
        pytest.raises(KeyError, lambda k: header[k], "NAXIS")
        # Test exception with message
        with pytest.raises(KeyError, match=r"Keyword 'NAXIS' not found."):
            header["NAXIS"]

    def test_hierarch_card_lookup(self):
        header = fits.Header()
        header["hierarch abcdefghi"] = 10
        assert "abcdefghi" in header
        assert header["abcdefghi"] == 10
        # This used to be assert_false, but per ticket
        # https://aeon.stsci.edu/ssb/trac/pyfits/ticket/155 hierarch keywords
        # should be treated case-insensitively when performing lookups
        assert "ABCDEFGHI" in header

    def test_hierarch_card_delete(self):
        header = fits.Header()
        header["hierarch abcdefghi"] = 10
        del header["hierarch abcdefghi"]

    def test_hierarch_card_insert_delete(self):
        header = fits.Header()
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header["abcdefghi"] = 10
        header["abcdefgh"] = 10
        header["abcdefg"] = 10
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header.insert(2, ("abcdefghij", 10))
        del header["abcdefghij"]
        with pytest.warns(
            fits.verify.VerifyWarning, match=r"greater than 8 characters"
        ):
            header.insert(2, ("abcdefghij", 10))
        del header[2]
        assert list(header.keys())[2] == "abcdefg".upper()

    def test_hierarch_create_and_update(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/158

        Tests several additional use cases for working with HIERARCH cards.
        """

        msg = "a HIERARCH card will be created"

        header = fits.Header()
        with pytest.warns(VerifyWarning) as w:
        h["TEST"] = 0
        assert isinstance(h["TEST"], int)
        assert str(h).startswith("TEST    =                    0")

    def test_newlines_in_commentary(self):
        """
        Regression test for https://github.com/spacetelescope/PyFITS/issues/51

        Test data extracted from a header in an actual FITS file found in the
        wild.  Names have been changed to protect the innocent.
        """

        # First ensure that we can't assign new keyword values with newlines in
        # them
        h = fits.Header()
        pytest.raises(ValueError, h.set, "HISTORY", "\n")
        pytest.raises(ValueError, h.set, "HISTORY", "\nabc")
        pytest.raises(ValueError, h.set, "HISTORY", "abc\n")
        pytest.raises(ValueError, h.set, "HISTORY", "abc\ndef")

        test_cards = [
            "HISTORY File modified by user 'wilma' with fv  on 2013-04-22T21:42:18           "
            "HISTORY File modified by user ' fred' with fv  on 2013-04-23T11:16:29           "
            "HISTORY File modified by user ' fred' with fv  on 2013-11-04T16:59:14           "
            "HISTORY File modified by user 'wilma' with fv  on 2013-04-22T21:42:18\nFile modif"
            "HISTORY ied by user 'wilma' with fv  on 2013-04-23T11:16:29\nFile modified by use"
            "HISTORY r ' fred' with fv  on 2013-11-04T16:59:14                               "
            "HISTORY File modified by user 'wilma' with fv  on 2013-04-22T21:42:18\nFile modif"
            "HISTORY ied by user 'wilma' with fv  on 2013-04-23T11:16:29\nFile modified by use"
            "HISTORY r ' fred' with fv  on 2013-11-04T16:59:14\nFile modified by user 'wilma' "
            "HISTORY with fv  on 2013-04-22T21:42:18\nFile modif\nied by user 'wilma' with fv  "
            "HISTORY on 2013-04-23T11:16:29\nFile modified by use\nr ' fred' with fv  on 2013-1"
            "HISTORY 1-04T16:59:14                                                           "
        ]

        for card_image in test_cards:
            c = fits.Card.fromstring(card_image)

            if "\n" in card_image:
                pytest.raises(fits.VerifyError, c.verify, "exception")
            else:
                c.verify("exception")

    def test_long_commentary_card_appended_to_header(self):
        """
        If a HISTORY or COMMENT card with a too-long value is appended to a
        header with Header.append (as opposed to assigning to hdr['HISTORY']
        it fails verification.

        Regression test for https://github.com/astropy/astropy/issues/11486
        """

        header = fits.Header()
        value = "abc" * 90
        # this is what Table does when saving its history metadata key to a
        # FITS file
        header.append(("history", value))
        assert len(header.cards) == 1

        # Test Card._split() directly since this was the main problem area
        key, val = header.cards[0]._split()
        assert key == "HISTORY" and val == value

        # Try writing adding this header to an HDU and writing it to a file
        hdu = fits.PrimaryHDU(header=header)
        hdu.writeto(self.temp("test.fits"), overwrite=True)

    def test_header_fromstring_bytes(self):
        """
        Test reading a Header from a `bytes` string.

        See https://github.com/astropy/astropy/issues/8706
        """

        with open(self.data("test0.fits"), "rb") as fobj:
            pri_hdr_from_bytes = fits.Header.fromstring(fobj.read())

        pri_hdr = fits.getheader(self.data("test0.fits"))
        assert pri_hdr["NAXIS"] == pri_hdr_from_bytes["NAXIS"]
        assert pri_hdr == pri_hdr_from_bytes
        assert pri_hdr.tostring() == pri_hdr_from_bytes.tostring()

    def test_set_keyword_with_space(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/10479
        """
    def test_update_rvkc_2(self):
        """Regression test for an issue that appeared after SVN r2412."""

        h = fits.Header()
        h["D2IM1.EXTVER"] = 1
        assert h["D2IM1.EXTVER"] == 1.0
        h["D2IM1.EXTVER"] = 2
        assert h["D2IM1.EXTVER"] == 2.0

    def test_raw_keyword_value(self):
        c = fits.Card.fromstring("DP1     = 'NAXIS: 2' / A comment")
        assert c.rawkeyword == "DP1"
        assert c.rawvalue == "NAXIS: 2"

        c = fits.Card("DP1.NAXIS", 2)
        assert c.rawkeyword == "DP1"
        assert c.rawvalue == "NAXIS: 2.0"

        c = fits.Card("DP1.NAXIS", 2.0)
        assert c.rawkeyword == "DP1"
        assert c.rawvalue == "NAXIS: 2.0"

    def test_rvkc_insert_after(self):
        """
        It should be possible to insert a new RVKC after an existing one
        specified by the full keyword/field-specifier combination."""

        self._test_header.set("DP1", "AXIS.3: 1", "a comment", after="DP1.AXIS.2")
        assert self._test_header[3] == 1
        assert self._test_header["DP1.AXIS.3"] == 1

    def test_rvkc_delete(self):
        """
        Deleting a RVKC should work as with a normal card by using the full
        keyword/field-spcifier combination.
        """

        del self._test_header["DP1.AXIS.1"]
        assert len(self._test_header) == 7
        assert list(self._test_header)[0] == "DP1.NAXIS"
        assert self._test_header[0] == 2
        assert list(self._test_header)[1] == "DP1.AXIS.2"

        # Perform a subsequent delete to make sure all the index mappings were
        # updated
        del self._test_header["DP1.AXIS.2"]
astropy/io/fits/tests/test_core.py:21:from astropy.io.fits.file import GZIP_MAGIC, _File
astropy/io/fits/tests/test_core.py:623:    astropy.io.fits.file._File class.
astropy/io/fits/tests/test_core.py:1205:        _File.__dict__["_mmap_available"]._cache.clear()
astropy/io/fits/tests/test_core.py:1222:            _File.__dict__["_mmap_available"]._cache.clear()
astropy/io/fits/tests/test_core.py:1265:        if not _File._mmap_available:
46:    def test_missing_file(self):
75:    def test_fits_file_path_object(self):
107:    def test_fits_file_bytes_object(self):
620:class TestFileFunctions(FitsTestCase):
643:    def test_open_file_handle(self):
673:    def test_fits_file_handle_mode_combo(self):
762:        fileobj = gzip.GzipFile(self.temp("test.fits.gz"), "ab+")
765:            h.writeto(fileobj)
767:            fileobj.close()
830:    def test_writeto_bzip2_fileobj(self):
832:        fileobj = bz2.BZ2File(self.temp("test.fits.bz2"), "w")
835:            h.writeto(fileobj)
837:            fileobj.close()
843:    def test_writeto_bzip2_filename(self):
891:    def test_writeto_lzma_fileobj(self):
893:        fileobj = lzma.LZMAFile(self.temp("test.fits.xz"), "w")
896:            h.writeto(fileobj)
898:            fileobj.close()
904:    def test_writeto_lzma_filename(self):
975:    def test_writeto_lzw_filename(self):
1022:    def test_read_open_astropy_gzip_file(self):
1035:    def test_open_multiple_member_zipfile(self):
1050:    def test_read_open_file(self):
1056:    def test_read_closed_file(self):
1064:    def test_read_open_gzip_file(self):
1073:    def test_open_gzip_file_for_writing(self):
1086:    def test_write_read_gzip_file(self, home_is_temp):
1116:    def test_read_file_like_object(self):
1125:    def test_updated_file_permissions(self):
1147:    def test_fileobj_mode_guessing(self):
1308:    def test_uncloseable_file(self):
1330:            fileobj = MyFileLike(f)
1332:            with fits.open(fileobj) as hdul1:
1351:        fileobj = io.BytesIO()
1352:        hdu.writeto(fileobj)
1354:        fileobj.seek(0)
1356:        with fits.open(fileobj) as h:
1371:    def test_filename_with_colon(self):
1412:            with open(filename, mode="wb") as fileobj:
1413:                hdulist.writeto(fileobj)
1426:        def _writedata(self, fileobj):
1445:    def _test_write_string_bytes_io(self, fileobj):
1451:            hdul.writeto(fileobj)
1452:            hdul2 = fits.HDUList.fromstring(fileobj.getvalue())
1562:    def test_streaming_hdu_file_wrong_mode(self):
1572:    def test_streaming_hdu_write_file(self):
1585:    def test_streaming_hdu_write_file_like(self):
1629:    def _make_streaming_hdu(self, fileobj):
1637:        return fits.StreamingHDU(fileobj, hd)
```

## 原始行 48 · command_execution

命令：
```
/bin/bash -lc "sed -n '620,1425p' astropy/io/fits/tests/test_core.py"
```

退出码：`0`

输出：
```
class TestFileFunctions(FitsTestCase):
    """
    Tests various basic I/O operations, specifically in the
    astropy.io.fits.file._File class.
    """

    def test_open_nonexistent(self):
        """Test that trying to open a non-existent file results in an
        OSError (and not some other arbitrary exception).
        """

        with pytest.raises(OSError, match=r"No such file or directory"):
            fits.open(self.temp("foobar.fits"))

        # But opening in ostream or append mode should be okay, since they
        # allow writing new files
        for mode in ("ostream", "append"):
            with fits.open(self.temp("foobar.fits"), mode=mode) as _:
                pass

            assert os.path.exists(self.temp("foobar.fits"))
            os.remove(self.temp("foobar.fits"))

    def test_open_file_handle(self):
        # Make sure we can open a FITS file from an open file handle
        with open(self.data("test0.fits"), "rb") as handle:
            with fits.open(handle) as _:
                pass

        with open(self.temp("temp.fits"), "wb") as handle:
            with fits.open(handle, mode="ostream") as _:
                pass

        # Opening without explicitly specifying binary mode should fail
        with pytest.raises(ValueError):
            with open(self.data("test0.fits")) as handle:
                with fits.open(handle) as _:
                    pass

        # All of these read modes should fail
        for mode in ["r", "rt"]:
            with pytest.raises(ValueError):
                with open(self.data("test0.fits"), mode=mode) as handle:
                    with fits.open(handle) as _:
                        pass

        # These update or write modes should fail as well
        for mode in ["w", "wt", "w+", "wt+", "r+", "rt+", "a", "at", "a+", "at+"]:
            with pytest.raises(ValueError):
                with open(self.temp("temp.fits"), mode=mode) as handle:
                    with fits.open(handle) as _:
                        pass

    def test_fits_file_handle_mode_combo(self):
        # This should work fine since no mode is given
        with open(self.data("test0.fits"), "rb") as handle:
            with fits.open(handle) as _:
                pass

        # This should work fine since the modes are compatible
        with open(self.data("test0.fits"), "rb") as handle:
            with fits.open(handle, mode="readonly") as _:
                pass

        # This should not work since the modes conflict
        with pytest.raises(ValueError):
            with open(self.data("test0.fits"), "rb") as handle:
                with fits.open(handle, mode="ostream") as _:
                    pass

    def test_open_from_url(self):
        file_url = "file:///" + self.data("test0.fits").lstrip("/")
        with urllib.request.urlopen(file_url) as urlobj:
            with fits.open(urlobj) as _:
                pass

        # It will not be possible to write to a file that is from a URL object
        for mode in ("ostream", "append", "update"):
            with pytest.raises(ValueError):
                with urllib.request.urlopen(file_url) as urlobj:
                    with fits.open(urlobj, mode=mode) as _:
                        pass

    @pytest.mark.remote_data(source="astropy")
    def test_open_from_remote_url(self):
        for dataurl in (conf.dataurl, conf.dataurl_mirror):
            remote_url = f"{dataurl}/allsky/allsky_rosat.fits"
            try:
                with urllib.request.urlopen(remote_url) as urlobj:
                    with fits.open(urlobj) as fits_handle:
                        assert len(fits_handle) == 1

                for mode in ("ostream", "append", "update"):
                    with pytest.raises(ValueError):
                        with urllib.request.urlopen(remote_url) as urlobj:
                            with fits.open(urlobj, mode=mode) as fits_handle:
                                assert len(fits_handle) == 1
            except (urllib.error.HTTPError, urllib.error.URLError):
                continue
            else:
                break
        else:
            raise Exception("Could not download file")

    def test_open_gzipped(self):
        gzip_file = self._make_gzip_file()

        with fits.open(gzip_file) as fits_handle:
            assert fits_handle._file.compression == "gzip"
            assert len(fits_handle) == 5

        with fits.open(gzip_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "gzip"
            assert len(fits_handle) == 5

        with fits.open(gzip.GzipFile(gzip_file)) as fits_handle:
            assert fits_handle._file.compression == "gzip"
            assert len(fits_handle) == 5

    def test_open_gzipped_from_handle(self):
        with open(self._make_gzip_file(), "rb") as handle:
            with fits.open(handle) as fits_handle:
                assert fits_handle._file.compression == "gzip"

    def test_detect_gzipped(self):
        """Test detection of a gzip file when the extension is not .gz."""
        with fits.open(self._make_gzip_file("test0.fz")) as fits_handle:
            assert fits_handle._file.compression == "gzip"
            assert len(fits_handle) == 5

    def test_writeto_append_mode_gzip(self):
        """Regression test for
        https://github.com/spacetelescope/PyFITS/issues/33

        Check that a new GzipFile opened in append mode can be used to write
        out a new FITS file.
        """

        # Note: when opening a GzipFile the 'b+' is superfluous, but this was
        # still how the original test case looked
        # Note: with statement not supported on GzipFile in older Python
        # versions
        fileobj = gzip.GzipFile(self.temp("test.fits.gz"), "ab+")
        h = fits.PrimaryHDU()
        try:
            h.writeto(fileobj)
        finally:
            fileobj.close()

        with fits.open(self.temp("test.fits.gz")) as hdul:
            assert hdul[0].header == h.header

    def test_fits_update_mode_gzip(self):
        """Test updating a GZipped FITS file"""

        with fits.open(self._make_gzip_file("update.gz"), mode="update") as fits_handle:
            hdu = fits.ImageHDU(data=list(range(100)))
            fits_handle.append(hdu)

        with fits.open(self.temp("update.gz")) as new_handle:
            assert len(new_handle) == 6
            assert (new_handle[-1].data == list(range(100))).all()

    def test_fits_append_mode_gzip(self):
        """Make sure that attempting to open an existing GZipped FITS file in
        'append' mode raises an error"""

        with pytest.raises(OSError):
            with fits.open(self._make_gzip_file("append.gz"), mode="append") as _:
                pass

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_open_bzipped(self):
        bzip_file = self._make_bzip2_file()

        with fits.open(bzip_file) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5

        with fits.open(bzip_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5

        with fits.open(bz2.BZ2File(bzip_file)) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5

        for mode in ("append", "update"):
            with pytest.raises(
                OSError,
                match="update and append modes are not supported with bzip2 files",
            ):
                with fits.open(bzip_file, mode=mode) as fits_handle:
                    pass

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_open_bzipped_from_handle(self):
        with open(self._make_bzip2_file(), "rb") as handle:
            with fits.open(handle) as fits_handle:
                assert fits_handle._file.compression == "bzip2"
                assert len(fits_handle) == 5

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_detect_bzipped(self):
        """Test detection of a bzip2 file when the extension is not .bz2."""
        with fits.open(self._make_bzip2_file("test0.xx")) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_writeto_bzip2_fileobj(self):
        """Test writing to a bz2.BZ2File file like object"""
        fileobj = bz2.BZ2File(self.temp("test.fits.bz2"), "w")
        h = fits.PrimaryHDU()
        try:
            h.writeto(fileobj)
        finally:
            fileobj.close()

        with fits.open(self.temp("test.fits.bz2")) as hdul:
            assert hdul[0].header == h.header

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_writeto_bzip2_filename(self):
        """Test writing to a bzip2 file by name"""
        filename = self.temp("testname.fits.bz2")
        h = fits.PrimaryHDU()
        h.writeto(filename)

        with fits.open(self.temp("testname.fits.bz2")) as hdul:
            assert hdul[0].header == h.header

    @pytest.mark.skipif(not HAS_LZMA, reason="Python built without lzma module")
    def test_open_lzma(self):
        lzma_file = self._make_lzma_file()

        with fits.open(lzma_file) as fits_handle:
            assert fits_handle._file.compression == "lzma"
            assert len(fits_handle) == 5

        with fits.open(lzma_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "lzma"
            assert len(fits_handle) == 5

        with fits.open(lzma.LZMAFile(lzma_file)) as fits_handle:
            assert fits_handle._file.compression == "lzma"
            assert len(fits_handle) == 5

        for mode in ("append", "update"):
            with pytest.raises(
                OSError,
                match="update and append modes are not supported with lzma files",
            ):
                with fits.open(lzma_file, mode=mode) as fits_handle:
                    pass

    @pytest.mark.skipif(not HAS_LZMA, reason="Python built without lzma module")
    def test_open_lzma_from_handle(self):
        with open(self._make_lzma_file(), "rb") as handle:
            with fits.open(handle) as fits_handle:
                assert fits_handle._file.compression == "lzma"
                assert len(fits_handle) == 5

    @pytest.mark.skipif(not HAS_LZMA, reason="Python built without lzma module")
    def test_detect_lzma(self):
        """Test detection of a lzma file when the extension is not .xz."""
        with fits.open(self._make_lzma_file("test0.xx")) as fits_handle:
            assert fits_handle._file.compression == "lzma"
            assert len(fits_handle) == 5

    @pytest.mark.skipif(not HAS_LZMA, reason="Python built without lzma module")
    def test_writeto_lzma_fileobj(self):
        """Test writing to a lzma.LZMAFile file like object"""
        fileobj = lzma.LZMAFile(self.temp("test.fits.xz"), "w")
        h = fits.PrimaryHDU()
        try:
            h.writeto(fileobj)
        finally:
            fileobj.close()

        with fits.open(self.temp("test.fits.xz")) as hdul:
            assert hdul[0].header == h.header

    @pytest.mark.skipif(not HAS_LZMA, reason="Python built without lzma module")
    def test_writeto_lzma_filename(self):
        """Test writing to a lzma file by name"""
        filename = self.temp("testname.fits.xz")
        h = fits.PrimaryHDU()
        h.writeto(filename)

        with fits.open(self.temp("testname.fits.xz")) as hdul:
            assert hdul[0].header == h.header

    @pytest.mark.skipif(
        not HAS_UNCOMPRESSPY, reason="Optional package uncompresspy not installed"
    )
    def test_open_lzw(self):
        lzw_file = self._make_lzw_file()

        arcfile = "ONTT.1991-12-30T08:55:46.000.fits"
        last_datapoint = 53
        with fits.open(lzw_file) as fits_handle:
            assert fits_handle._file.compression == "lzw"
            assert len(fits_handle) == 1
            assert fits_handle[0].header["ARCFILE"] == arcfile
            assert fits_handle[0].data[-1, -1] == last_datapoint

        with fits.open(lzw_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "lzw"
            assert len(fits_handle) == 1
            assert fits_handle[0].header["ARCFILE"] == arcfile
            assert fits_handle[0].data[-1, -1] == last_datapoint

        with fits.open(uncompresspy.LZWFile(lzw_file)) as fits_handle:
            assert fits_handle._file.compression == "lzw"
            assert len(fits_handle) == 1
            assert fits_handle[0].header["ARCFILE"] == arcfile
            assert fits_handle[0].data[-1, -1] == last_datapoint

        for mode in ("append", "update"):
            with pytest.raises(
                OSError, match=f"{mode} mode not supported with LZW files"
            ):
                with fits.open(lzw_file, mode=mode) as fits_handle:
                    pass

    @pytest.mark.skipif(
        not HAS_UNCOMPRESSPY, reason="Optional package uncompresspy not installed"
    )
    def test_open_lzw_from_handle(self):
        arcfile = "ONTT.1991-12-30T08:55:46.000.fits"
        last_datapoint = 53
        with open(self._make_lzw_file(), "rb") as handle:
            with fits.open(handle) as fits_handle:
                assert fits_handle._file.compression == "lzw"
                assert len(fits_handle) == 1
                assert fits_handle[0].header["ARCFILE"] == arcfile
                assert fits_handle[0].data[-1, -1] == last_datapoint

    @pytest.mark.skipif(
        not HAS_UNCOMPRESSPY, reason="Optional package uncompresspy not installed"
    )
    def test_detect_lzw(self):
        """Test detection of a lzw file when the extension is not .Z."""
        arcfile = "ONTT.1991-12-30T08:55:46.000.fits"
        last_datapoint = 53
        with fits.open(self._make_lzw_file("test0.xx")) as fits_handle:
            assert fits_handle._file.compression == "lzw"
            assert len(fits_handle) == 1
            assert fits_handle[0].header["ARCFILE"] == arcfile
            assert fits_handle[0].data[-1, -1] == last_datapoint

    @pytest.mark.skipif(
        not HAS_UNCOMPRESSPY, reason="Optional package uncompresspy not installed"
    )
    def test_writeto_lzw_filename(self):
        """Test writing to a LZW file by name. This should fail as writing LZW
        is not supported."""
        filename = self.temp("testname.fits.Z")
        h = fits.PrimaryHDU()
        with pytest.raises(OSError, match="mode not supported with LZW files"):
            h.writeto(filename)

    def test_open_zipped(self):
        zip_file = self._make_zip_file()

        with fits.open(zip_file) as fits_handle:
            assert fits_handle._file.compression == "zip"
            assert len(fits_handle) == 5

        with fits.open(zip_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "zip"
            assert len(fits_handle) == 5

        with fits.open(zipfile.ZipFile(zip_file)) as fits_handle:
            assert fits_handle._file.compression == "zip"
            assert len(fits_handle) == 5

    def test_open_zipped_from_handle(self):
        with open(self._make_zip_file(), "rb") as handle:
            with fits.open(handle) as fits_handle:
                assert fits_handle._file.compression == "zip"
                assert len(fits_handle) == 5

    def test_detect_zipped(self):
        """Test detection of a zip file when the extension is not .zip."""

        zf = self._make_zip_file(filename="test0.fz")
        with fits.open(zf) as fits_handle:
            assert len(fits_handle) == 5

    def test_open_zipped_writeable(self):
        """Opening zipped files in a writeable mode should fail."""

        zf = self._make_zip_file()
        pytest.raises(OSError, fits.open, zf, "update")
        pytest.raises(OSError, fits.open, zf, "append")

        zf = zipfile.ZipFile(zf, "a")
        pytest.raises(OSError, fits.open, zf, "update")
        pytest.raises(OSError, fits.open, zf, "append")

    def test_read_open_astropy_gzip_file(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/2774

        This tests reading from a ``GzipFile`` object from Astropy's
        compatibility copy of the ``gzip`` module.
        """
        gf = gzip.GzipFile(self._make_gzip_file())
        try:
            assert len(fits.open(gf)) == 5
        finally:
            gf.close()

    def test_open_multiple_member_zipfile(self):
        """
        Opening zip files containing more than one member files should fail
        as there's no obvious way to specify which file is the FITS file to
        read.
        """

        zfile = zipfile.ZipFile(self.temp("test0.zip"), "w")
        zfile.write(self.data("test0.fits"))
        zfile.writestr("foo", "bar")
        zfile.close()

        with pytest.raises(OSError):
            fits.open(zfile.filename)

    def test_read_open_file(self):
        """Read from an existing file object."""

        with open(self.data("test0.fits"), "rb") as f:
            assert len(fits.open(f)) == 5

    def test_read_closed_file(self):
        """Read from an existing file object that's been closed."""

        f = open(self.data("test0.fits"), "rb")
        f.close()
        with fits.open(f) as f2:
            assert len(f2) == 5

    def test_read_open_gzip_file(self):
        """Read from an open gzip file object."""

        gf = gzip.GzipFile(self._make_gzip_file())
        try:
            assert len(fits.open(gf)) == 5
        finally:
            gf.close()

    def test_open_gzip_file_for_writing(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/195."""

        gf = self._make_gzip_file()
        with fits.open(gf, mode="update") as h:
            h[0].header["EXPFLAG"] = "ABNORMAL"
            h[1].data[0, 0] = 1
        with fits.open(gf) as h:
            # Just to make sure the update worked; if updates work
            # normal writes should work too...
            assert h[0].header["EXPFLAG"] == "ABNORMAL"
            assert h[1].data[0, 0] == 1

    def test_write_read_gzip_file(self, home_is_temp):
        """
        Regression test for https://github.com/astropy/astropy/issues/2794

        Ensure files written through gzip are readable.
        """

        data = np.arange(100)
        hdu = fits.PrimaryHDU(data=data)
        hdu.writeto(self.temp("test.fits.gz"))

        with open(os.path.expanduser(self.temp("test.fits.gz")), "rb") as f:
            assert f.read(3) == GZIP_MAGIC

        with fits.open(self.temp("test.fits.gz")) as hdul:
            assert np.all(hdul[0].data == data)

    @pytest.mark.parametrize("ext", ["gz", "bz2", "zip", "xz", "Z"])
    def test_compressed_ext_but_not_compressed(self, ext):
        testfile = self.temp(f"test0.fits.{ext}")
        shutil.copy(self.data("test0.fits"), testfile)

        with fits.open(testfile) as hdul:
            assert len(hdul) == 5

        fits.append(testfile, np.arange(5))

        with fits.open(testfile) as hdul:
            assert len(hdul) == 6

    def test_read_file_like_object(self):
        """Test reading a FITS file from a file-like object."""

        filelike = io.BytesIO()
        with open(self.data("test0.fits"), "rb") as f:
            filelike.write(f.read())
        filelike.seek(0)
        assert len(fits.open(filelike)) == 5

    def test_updated_file_permissions(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/79

        Tests that when a FITS file is modified in update mode, the file
        permissions are preserved.
        """

        filename = self.temp("test.fits")
        hdul = [fits.PrimaryHDU(), fits.ImageHDU()]
        hdul = fits.HDUList(hdul)
        hdul.writeto(filename)

        old_mode = os.stat(filename).st_mode

        hdul = fits.open(filename, mode="update")
        hdul.insert(1, fits.ImageHDU())
        hdul.flush()
        hdul.close()

        assert old_mode == os.stat(filename).st_mode

    def test_fileobj_mode_guessing(self):
        """Tests whether a file opened without a specified io.fits mode
        ('readonly', etc.) is opened in a mode appropriate for the given file
        object.
        """

        testfile = self.copy_file("test0.fits")

        # Opening in text mode should outright fail
        for mode in ("r", "w", "a"):
            with open(testfile, mode) as f:
                pytest.raises(ValueError, fits.HDUList.fromfile, f)

        # Need to re-copy the file since opening it in 'w' mode blew it away
        testfile = self.copy_file("test0.fits")

        with open(testfile, "rb") as f:
            with fits.HDUList.fromfile(f) as h:
                assert h.fileinfo(0)["filemode"] == "readonly"

        for mode in ("wb", "ab"):
            with open(testfile, mode) as f:
                with fits.HDUList.fromfile(f) as h:
                    # Basically opening empty files for output streaming
                    assert len(h) == 0

        # Need to re-copy the file since opening it in 'w' mode blew it away
        with open(self.copy_file("test0.fits"), "wb+") as f:
            with fits.HDUList.fromfile(f) as h:
                # wb+ still causes an existing file to be overwritten so there
                # are no HDUs
                assert len(h) == 0

        # Need to re-copy the file since opening it in 'w' mode blew it away
        testfile = self.copy_file("test0.fits")
        with open(testfile, "rb+") as f:
            with fits.HDUList.fromfile(f) as h:
                assert h.fileinfo(0)["filemode"] == "update"

        with open(testfile, "ab+") as f:
            with fits.HDUList.fromfile(f) as h:
                assert h.fileinfo(0)["filemode"] == "append"

    def test_mmap_unwriteable(self):
        """Regression test for https://github.com/astropy/astropy/issues/968

        Temporarily patches mmap.mmap to exhibit platform-specific bad
        behavior.
        """

        class MockMmap(mmap.mmap):
            def flush(self):
                raise OSError("flush is broken on this platform")

        old_mmap = mmap.mmap
        mmap.mmap = MockMmap

        # Force the mmap test to be rerun
        _File.__dict__["_mmap_available"]._cache.clear()

        try:
            testfile = self.copy_file("test0.fits")
            with pytest.warns(
                AstropyUserWarning, match=r"mmap\.flush is unavailable"
            ) as w:
                with fits.open(testfile, mode="update", memmap=True) as h:
                    h[1].data[0, 0] = 999

            assert len(w) == 1

            # Double check that writing without mmap still worked
            with fits.open(testfile) as h:
                assert h[1].data[0, 0] == 999
        finally:
            mmap.mmap = old_mmap
            _File.__dict__["_mmap_available"]._cache.clear()

    def test_mmap_allocate_error(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/1380

        Temporarily patches mmap.mmap to raise an OSError if mode is ACCESS_COPY.
        """

        mmap_original = mmap.mmap

        # We patch mmap here to raise an error if access=mmap.ACCESS_COPY, which
        # emulates an issue that an OSError is raised if the available address
        # space is less than the size of the file even if memory mapping is used.

        def mmap_patched(*args, **kwargs):
            if kwargs.get("access") == mmap.ACCESS_COPY:
                exc = OSError()
                if sys.platform.startswith("win32"):
                    exc.errno = errno.EINVAL
                    exc.winerror = 1455
                else:
                    exc.errno = errno.ENOMEM
                raise exc
            else:
                return mmap_original(*args, **kwargs)

        with fits.open(self.data("test0.fits"), memmap=True) as hdulist:
            with patch.object(mmap, "mmap", side_effect=mmap_patched) as p:
                with pytest.warns(
                    AstropyUserWarning,
                    match=r"Could not memory map array with mode='readonly'",
                ):
                    data = hdulist[1].data
                p.reset_mock()
            assert not data.flags.writeable

    def test_mmap_closing(self):
        """
        Tests that the mmap reference is closed/removed when there aren't any
        HDU data references left.
        """

        if not _File._mmap_available:
            pytest.xfail("not expected to work on platforms without mmap support")

        with fits.open(self.data("test0.fits"), memmap=True) as hdul:
            assert hdul._file._mmap is None

            hdul[1].data
            assert hdul._file._mmap is not None

            del hdul[1].data
            # Should be no more references to data in the file so close the
            # mmap
            assert hdul._file._mmap is None

            hdul[1].data
            hdul[2].data
            del hdul[1].data
            # hdul[2].data is still references so keep the mmap open
            assert hdul._file._mmap is not None
            del hdul[2].data
            assert hdul._file._mmap is None

        assert hdul._file._mmap is None

        with fits.open(self.data("test0.fits"), memmap=True) as hdul:
            hdul[1].data

        # When the only reference to the data is on the hdu object, and the
        # hdulist it belongs to has been closed, the mmap should be closed as
        # well
        assert hdul._file._mmap is None

        with fits.open(self.data("test0.fits"), memmap=True) as hdul:
            data = hdul[1].data
            # also make a copy
            data_copy = data.copy()

        # The HDUList is closed; in fact, get rid of it completely
        del hdul

        # The data array should still work though...
        assert np.all(data == data_copy)

    def test_uncloseable_file(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/2356

        Demonstrates that FITS files can still be read from file-like objects
        that don't have an obvious "open" or "closed" state.
        """

        class MyFileLike:
            def __init__(self, foobar):
                self._foobar = foobar

            def read(self, n):
                return self._foobar.read(n)

            def seek(self, offset, whence=os.SEEK_SET):
                self._foobar.seek(offset, whence)

            def tell(self):
                return self._foobar.tell()

        with open(self.data("test0.fits"), "rb") as f:
            fileobj = MyFileLike(f)

            with fits.open(fileobj) as hdul1:
                with fits.open(self.data("test0.fits")) as hdul2:
                    assert hdul1.info(output=False) == hdul2.info(output=False)
                    for hdu1, hdu2 in zip(hdul1, hdul2):
                        assert hdu1.header == hdu2.header
                        if hdu1.data is not None and hdu2.data is not None:
                            assert np.all(hdu1.data == hdu2.data)

    def test_write_bytesio_discontiguous(self):
        """
        Regression test related to
        https://github.com/astropy/astropy/issues/2794#issuecomment-55441539

        Demonstrates that writing an HDU containing a discontiguous Numpy array
        should work properly.
        """

        data = np.arange(100)[::3]
        hdu = fits.PrimaryHDU(data=data)
        fileobj = io.BytesIO()
        hdu.writeto(fileobj)

        fileobj.seek(0)

        with fits.open(fileobj) as h:
            assert np.all(h[0].data == data)

    def test_write_bytesio(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/2463

        Test against `io.BytesIO`.  `io.StringIO` is not supported.
        """

        self._test_write_string_bytes_io(io.BytesIO())

    @pytest.mark.skipif(
        sys.platform.startswith("win32"), reason="Cannot test on Windows"
    )
    def test_filename_with_colon(self):
        """
        Test reading and writing a file with a colon in the filename.

        Regression test for https://github.com/astropy/astropy/issues/3122
        """

        # Skip on Windows since colons in filenames makes NTFS sad.

        filename = "APEXHET.2014-04-01T15:18:01.000.fits"
        hdu = fits.PrimaryHDU(data=np.arange(10))
        hdu.writeto(self.temp(filename))

        with fits.open(self.temp(filename)) as hdul:
            assert np.all(hdul[0].data == hdu.data)

    def test_writeto_full_disk(self, monkeypatch):
        """
        Test that it gives a readable error when trying to write an hdulist
        to a full disk.
        """

        def _writeto(self, array):
            raise OSError("Fake error raised when writing file.")

        def get_free_space_in_dir(path):
            return 0

        msg = (
            "Not enough space on disk: requested 8000, available 0. "
            "Fake error raised when writing file."
        )
        with pytest.raises(OSError, match=msg) as exc:
            monkeypatch.setattr(fits.hdu.base._BaseHDU, "_writeto", _writeto)
            monkeypatch.setattr(data, "get_free_space_in_dir", get_free_space_in_dir)

            n = np.arange(0, 1000, dtype="int64")
            hdu = fits.PrimaryHDU(n)
            hdulist = fits.HDUList(hdu)
            filename = self.temp("test.fits")

            with open(filename, mode="wb") as fileobj:
                hdulist.writeto(fileobj)

    def test_flush_full_disk(self, monkeypatch):
        """
        Test that it gives a readable error when trying to update an hdulist
        to a full disk.
        """
        filename = self.temp("test.fits")
        hdul = [fits.PrimaryHDU(), fits.ImageHDU()]
        hdul = fits.HDUList(hdul)
        hdul[0].data = np.arange(0, 1000, dtype="int64")
        hdul.writeto(filename)
```

## 原始行 51 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"readarray(\" astropy/io/fits --include='*.py'; grep -RInE \"_file\\.(flush|seek|tell|read|write|truncate|close)\\(\" astropy/io/fits --include='*.py' | head -250; sed -n '810,870p' astropy/io/fits/hdu/base.py; sed -n '1360,1525p' astropy/io/fits/hdu/hdulist.py; grep -n \"decompress_in_memory\" -R astropy/io/fits --include='*.py'"
```

退出码：`0`

输出：
```
astropy/io/fits/file.py:496:            self._file.truncate(size)
astropy/io/fits/file.py:632:                self._file.seek(0)
astropy/io/fits/file.py:633:            magic = self._file.read(6)
astropy/io/fits/file.py:638:            self._file.seek(0)
astropy/io/fits/file.py:771:        self._file.write(zfile.read(namelist[0]))
astropy/io/fits/file.py:778:        self._file.seek(0)
astropy/io/fits/scripts/fitsdiff.py:423:            out_file.close()
astropy/io/fits/hdu/base.py:668:            self._file.seek(hdrloc)
astropy/io/fits/hdu/base.py:678:            self._file.seek(hdrloc)
astropy/io/fits/hdu/base.py:682:            fileobj.write(self._file.read(hdrsize))
astropy/io/fits/hdu/base.py:703:                    self._file.seek(self._data_offset)
astropy/io/fits/hdu/nonstandard.py:29:        self._file.seek(self._data_offset)
astropy/io/fits/hdu/nonstandard.py:35:        fileobj.write(self._file.read(self.size))
astropy/io/fits/hdu/hdulist.py:1093:                self._file.close()
astropy/io/fits/hdu/hdulist.py:1216:            pos = hdulist._file.tell()
astropy/io/fits/hdu/hdulist.py:1220:            simple = hdulist._file.read(80)
astropy/io/fits/hdu/hdulist.py:1238:                        hdulist._file.close()
astropy/io/fits/hdu/hdulist.py:1245:            hdulist._file.seek(pos)
astropy/io/fits/hdu/hdulist.py:1263:                hdulist._file.close()
astropy/io/fits/hdu/hdulist.py:1333:                            self._file.close()
astropy/io/fits/hdu/hdulist.py:1495:                hdulist._file.close()
astropy/io/fits/hdu/hdulist.py:1496:                self._file.close()
astropy/io/fits/hdu/hdulist.py:1631:                    self._file.truncate(hdu._data_offset + hdu._data_size)
        instead of an array.
        """
        offset = 0
        size = 0

        fileobj.flush()
        try:
            offset = fileobj.tell()
        except OSError:
            offset = 0

        if self.data is not None:
            fileobj.write(self.data)
            # flush, to make sure the content is written
            fileobj.flush()
            size = len(self.data)

        # return both the location and the size of the data area
        return offset, size

    def _summary(self):
        return (self.name, self.ver, "NonstandardHDU", len(self._header))

    @lazyproperty
    def data(self):
        """
        Return the file data.
        """
        return self._get_raw_data(self.size, "ubyte", self._data_offset)

    def _verify(self, option="warn"):
        errs = _ErrList([], unit="Card")

        # verify each card
        for card in self._header.cards:
            errs.append(card._verify(option))

        return errs


class _ValidHDU(_BaseHDU, _Verify):
    """
    Base class for all HDUs which are not corrupted.
    """

    def __init__(self, data=None, header=None, name=None, ver=None, **kwargs):
        super().__init__(data=data, header=header)

        if header is not None and not isinstance(header, (Header, _BasicHeader)):
            # TODO: Instead maybe try initializing a new Header object from
            # whatever is passed in as the header--there are various types
            # of objects that could work for this...
            raise ValueError("header must be a Header object")

        # NOTE:  private data members _checksum and _datasum are used by the
        # utility script "fitscheck" to detect missing checksums.
        self._checksum = None
        self._checksum_valid = None
        self._datasum = None
        self._datasum_valid = None

                    # Check for an extension HDU and update the EXTEND
                    # keyword of the primary HDU accordingly
                    self.update_extend()

                hdu._new = False
                if "checksum" in kwargs:
                    hdu._output_checksum = kwargs["checksum"]
            # check in the case there is extra space after the last HDU or
            # corrupted HDU
            except (VerifyError, ValueError) as exc:
                warnings.warn(
                    f"Error validating header for HDU #{len(self)} (note: Astropy "
                    f"uses zero-based indexing).\n{indent(str(exc), 4 * ' ')}\n"
                    "There may be extra bytes after the last HDU or the "
                    "file is corrupted.",
                    VerifyWarning,
                )
                del exc
                self._read_all = True
                return False
        finally:
            self._in_read_next_hdu = False

        return True

    def _verify(self, option="warn"):
        errs = _ErrList([], unit="HDU")

        # the first (0th) element must be a primary HDU
        if (
            len(self) > 0
            and (not isinstance(self[0], PrimaryHDU))
            and (not isinstance(self[0], _NonstandardHDU))
        ):
            err_text = "HDUList's 0th element is not a primary HDU."
            fix_text = "Fixed by inserting one as 0th HDU."

            def fix(self=self):
                self.insert(0, PrimaryHDU())

            err = self.run_option(option, err_text=err_text, fix_text=fix_text, fix=fix)
            errs.append(err)

        if len(self) > 1 and (
            "EXTEND" not in self[0].header or self[0].header["EXTEND"] is not True
        ):
            err_text = (
                "Primary HDU does not contain an EXTEND keyword "
                "equal to T even though there are extension HDUs."
            )
            fix_text = "Fixed by inserting or updating the EXTEND keyword."

            def fix(header=self[0].header):
                naxis = header["NAXIS"]
                if naxis == 0:
                    after = "NAXIS"
                else:
                    after = "NAXIS" + str(naxis)
                header.set("EXTEND", value=True, after=after)

            errs.append(
                self.run_option(option, err_text=err_text, fix_text=fix_text, fix=fix)
            )

        # each element calls their own verify
        for idx, hdu in enumerate(self):
            if idx > 0 and (not isinstance(hdu, ExtensionHDU)):
                err_text = f"HDUList's element {idx} is not an extension HDU."

                err = self.run_option(option, err_text=err_text, fixable=False)
                errs.append(err)

            else:
                result = hdu._verify(option)
                if result:
                    errs.append(result)
        return errs

    def _flush_update(self):
        """Implements flushing changes to a file in update mode."""
        for hdu in self:
            # Need to all _prewriteto() for each HDU first to determine if
            # resizing will be necessary
            hdu._prewriteto(inplace=True)

        try:
            self._wasresized()

            # if the HDUList is resized, need to write out the entire contents of
            # the hdulist to the file.
            if self._resize or self._file.compression:
                self._flush_resize()
            else:
                # if not resized, update in place
                for hdu in self:
                    hdu._writeto(self._file, inplace=True)

            # reset the modification attributes after updating
            for hdu in self:
                hdu._header._modified = False
        finally:
            for hdu in self:
                hdu._postwriteto()

    def _flush_resize(self):
        """
        Implements flushing changes in update mode when parts of one or more HDU
        need to be resized.
        """
        old_name = self._file.name
        old_memmap = self._file.memmap
        name = _tmp_name(old_name)

        if not self._file.file_like:
            old_mode = os.stat(old_name).st_mode
            # The underlying file is an actual file object.  The HDUList is
            # resized, so we need to write it to a tmp file, delete the
            # original file, and rename the tmp file to the original file.
            if self._file.compression == "gzip":
                new_file = gzip.GzipFile(name, mode="ab+")
            else:
                new_file = name

            with self.fromfile(new_file, mode="append") as hdulist:
                for hdu in self:
                    hdu._writeto(hdulist._file, inplace=True, copy=True)
                if sys.platform.startswith("win"):
                    # Collect a list of open mmaps to the data; this well be
                    # used later.  See below.
                    mmaps = [
                        (idx, _get_array_mmap(hdu.data), hdu.data)
                        for idx, hdu in enumerate(self)
                        if hdu._has_data
                    ]

                hdulist._file.close()
                self._file.close()
            if sys.platform.startswith("win"):
                # Close all open mmaps to the data.  This is only necessary on
                # Windows, which will not allow a file to be renamed or deleted
                # until all handles to that file have been closed.
                for idx, mmap, arr in mmaps:
                    if mmap is not None:
                        mmap.close()

            os.remove(self._file.name)

            # reopen the renamed new file with "update" mode
            os.rename(name, old_name)
            os.chmod(old_name, old_mode)

            if isinstance(new_file, gzip.GzipFile):
                old_file = gzip.GzipFile(old_name, mode="rb+")
            else:
                old_file = old_name

            ffo = _File(old_file, mode="update", memmap=old_memmap)

            self._file = ffo

            for hdu in self:
                # Need to update the _file attribute and close any open mmaps
                # on each HDU
                if hdu._has_data and _get_array_mmap(hdu.data) is not None:
                    del hdu.data
                hdu._file = ffo
astropy/io/fits/hdu/hdulist.py:55:    decompress_in_memory=False,
astropy/io/fits/hdu/hdulist.py:186:    decompress_in_memory : bool, optional
astropy/io/fits/hdu/hdulist.py:189:        the whole file, but it can be slow. With decompress_in_memory=True it
astropy/io/fits/hdu/hdulist.py:230:        decompress_in_memory=decompress_in_memory,
astropy/io/fits/hdu/hdulist.py:1175:        decompress_in_memory=False,
astropy/io/fits/hdu/hdulist.py:1193:                    decompress_in_memory=decompress_in_memory,
astropy/io/fits/tests/test_core.py:731:        with fits.open(gzip_file, decompress_in_memory=True) as fits_handle:
astropy/io/fits/tests/test_core.py:799:        with fits.open(bzip_file, decompress_in_memory=True) as fits_handle:
astropy/io/fits/tests/test_core.py:860:        with fits.open(lzma_file, decompress_in_memory=True) as fits_handle:
astropy/io/fits/tests/test_core.py:927:        with fits.open(lzw_file, decompress_in_memory=True) as fits_handle:
astropy/io/fits/tests/test_core.py:990:        with fits.open(zip_file, decompress_in_memory=True) as fits_handle:
```

## 原始行 54 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"readarray\" astropy/io/fits astropy/io --include='*.py' || true; grep -n \"def _get_raw_data\" -A50 astropy/io/fits/hdu/base.py; sed -n '480,570p' astropy/io/fits/util.py; grep -n \"classproperty\" -n astropy/utils/decorators.py | head"
```

退出码：`0`

输出：
```
def fill(text, width, **kwargs):
    """
    Like :func:`textwrap.wrap` but preserves existing paragraphs which
    :func:`textwrap.wrap` does not otherwise handle well.  Also handles section
    headers.
    """
    paragraphs = text.split("\n\n")

    def maybe_fill(t):
        if all(len(line) < width for line in t.splitlines()):
            return t
        else:
            return textwrap.fill(t, width, **kwargs)

    return "\n\n".join(maybe_fill(p) for p in paragraphs)


# On MacOS X 10.8 and earlier, there is a bug that causes numpy.fromfile to
# fail when reading over 2Gb of data. If we detect these versions of MacOS X,
# we can instead read the data in chunks. To avoid performance penalties at
# import time, we defer the setting of this global variable until the first
# time it is needed.
CHUNKED_FROMFILE = None


def _array_from_file(infile, dtype, count):
    """Create a numpy array from a file or a file-like object."""
    if isfile(infile):
        global CHUNKED_FROMFILE
        if CHUNKED_FROMFILE is None:
            if sys.platform == "darwin" and Version(platform.mac_ver()[0]) < Version(
                "10.9"
            ):
                CHUNKED_FROMFILE = True
            else:
                CHUNKED_FROMFILE = False

        if CHUNKED_FROMFILE:
            chunk_size = int(1024**3 / dtype.itemsize)  # 1Gb to be safe
            if count < chunk_size:
                return np.fromfile(infile, dtype=dtype, count=count)
            else:
                array = np.empty(count, dtype=dtype)
                for beg in range(0, count, chunk_size):
                    end = min(count, beg + chunk_size)
                    array[beg:end] = np.fromfile(infile, dtype=dtype, count=end - beg)
                return array
        else:
            return np.fromfile(infile, dtype=dtype, count=count)
    else:
        # treat as file-like object with "read" method; this includes gzip file
        # objects, because numpy.fromfile just reads the compressed bytes from
        # their underlying file object, instead of the decompressed bytes
        read_size = np.dtype(dtype).itemsize * count
        s = infile.read(read_size)
        array = np.ndarray(buffer=s, dtype=dtype, shape=(count,))
        # copy is needed because np.frombuffer returns a read-only view of the
        # underlying buffer
        return array.copy()


_OSX_WRITE_LIMIT = (2**32) - 1
_WIN_WRITE_LIMIT = (2**31) - 1


def _array_to_file(arr, outfile):
    """
    Write a numpy array to a file or a file-like object.

    Parameters
    ----------
    arr : ndarray
        The Numpy array to write.
    outfile : file-like
        A file-like object such as a Python file object, an `io.BytesIO`, or
        anything else with a ``write`` method.  The file object must support
        the buffer interface in its ``write``.

    If writing directly to an on-disk file this delegates directly to
    `ndarray.tofile`.  Otherwise a slower Python implementation is used.
    """
    try:
        seekable = outfile.seekable()
    except AttributeError:
        seekable = False

    if isfile(outfile) and seekable:
        write = lambda a, f: a.tofile(f)
    else:
        write = _array_to_file_like

22:    "classproperty",
726:class classproperty(property):
737:        classproperty only works for *read-only* properties.  It does not
756:        argument can also be used when `classproperty` is used as a decorator
766:        ...     @classproperty
779:    As previously noted, a `classproperty` is limited to implementing
784:        ...     @classproperty
793:        NotImplementedError: classproperty can only be read-only; use a
799:        ...     @classproperty(lazy=True)
810:    If a subclass inherits a lazy `classproperty` the property is still
```

## 原始行 57 · command_execution

命令：
```
/bin/bash -lc "grep -n \"_get_raw_data\" astropy/io/fits/hdu/base.py; nl -ba astropy/io/fits/hdu/base.py | sed -n '680,850p'; python - <<'PY'
import ast
for fn in ['astropy/io/fits/hdu/base.py','astropy/io/fits/util.py']:
 m=ast.parse(open(fn).read()); print(fn)
 for n in ast.walk(m):
  if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.col_offset<=4: print(n.name,n.lineno,n.end_lineno)
PY"
```

退出码：`0`

输出：
```
628:        raw = self._get_raw_data(self._data_size, "ubyte", self._data_offset)
838:        return self._get_raw_data(self.size, "ubyte", self._data_offset)
1385:                raw_data = self._get_raw_data(
1599:        return self._get_raw_data(self.size, "ubyte", self._data_offset)
   680	            # which is the hdrloc for the new file
   681	            hdrloc = fileobj.tell()
   682	            fileobj.write(self._file.read(hdrsize))
   683	            # The header size is unchanged, but the data location may be
   684	            # different from before depending on if previous HDUs were resized
   685	            datloc = fileobj.tell()
   686	
   687	        if self._data_loaded:
   688	            if self.data is not None:
   689	                # Seek through the array's bases for an memmap'd array; we
   690	                # can't rely on the _File object to give us this info since
   691	                # the user may have replaced the previous mmap'd array
   692	                if copy or self._data_replaced:
   693	                    # Of course, if we're copying the data to a new file
   694	                    # we don't care about flushing the original mmap;
   695	                    # instead just read it into the new file
   696	                    array_mmap = None
   697	                else:
   698	                    array_mmap = _get_array_mmap(self.data)
   699	
   700	                if array_mmap is not None:
   701	                    array_mmap.flush()
   702	                else:
   703	                    self._file.seek(self._data_offset)
   704	                    datloc, datsize = self._writedata(fileobj)
   705	        elif copy:
   706	            datsize = self._writedata_direct_copy(fileobj)
   707	
   708	        self._header_offset = hdrloc
   709	        self._data_offset = datloc
   710	        self._data_size = datsize
   711	        self._data_replaced = False
   712	
   713	
   714	
   715	
   716	
   717	
   718	
   719	
   720	
   721	
   722	# For backwards-compatibility, though nobody should have
   723	# been using this directly:
   724	_AllHDU = _BaseHDU
   725	
   726	# For convenience...
   727	# TODO: register_hdu could be made into a class decorator which would be pretty
   728	# cool, but only once 2.6 support is dropped.
   729	register_hdu = _BaseHDU.register_hdu
   730	unregister_hdu = _BaseHDU.unregister_hdu
   731	
   732	
   733	class _CorruptedHDU(_BaseHDU):
   734	    """
   735	    A Corrupted HDU class.
   736	
   737	    This class is used when one or more mandatory `Card`s are
   738	    corrupted (unparsable), such as the ``BITPIX``, ``NAXIS``, or
   739	    ``END`` cards.  A corrupted HDU usually means that the data size
   740	    cannot be calculated or the ``END`` card is not found.  In the case
   741	    of a missing ``END`` card, the `Header` may also contain the binary
   742	    data
   743	
   744	    .. note::
   745	       In future, it may be possible to decipher where the last block
   746	       of the `Header` ends, but this task may be difficult when the
   747	       extension is a `TableHDU` containing ASCII data.
   748	    """
   749	
   750	    @property
   751	    def size(self):
   752	        """
   753	        Returns the size (in bytes) of the HDU's data part.
   754	        """
   755	        # Note: On compressed files this might report a negative size; but the
   756	        # file is corrupt anyways so I'm not too worried about it.
   757	        if self._buffer is not None:
   758	            return len(self._buffer) - self._data_offset
   759	
   760	        return self._file.size - self._data_offset
   761	
   762	    def _summary(self):
   763	        return (self.name, self.ver, "CorruptedHDU")
   764	
   765	    def verify(self):
   766	        pass
   767	
   768	
   769	class _NonstandardHDU(_BaseHDU, _Verify):
   770	    """
   771	    A Non-standard HDU class.
   772	
   773	    This class is used for a Primary HDU when the ``SIMPLE`` Card has
   774	    a value of `False`.  A non-standard HDU comes from a file that
   775	    resembles a FITS file but departs from the standards in some
   776	    significant way.  One example would be files where the numbers are
   777	    in the DEC VAX internal storage format rather than the standard
   778	    FITS most significant byte first.  The header for this HDU should
   779	    be valid.  The data for this HDU is read from the file as a byte
   780	    stream that begins at the first byte after the header ``END`` card
   781	    and continues until the end of the file.
   782	    """
   783	
   784	    _standard = False
   785	
   786	    @classmethod
   787	    def match_header(cls, header):
   788	        """
   789	        Matches any HDU that has the 'SIMPLE' keyword but is not a standard
   790	        Primary or Groups HDU.
   791	        """
   792	        # The SIMPLE keyword must be in the first card
   793	        card = header.cards[0]
   794	        return card.keyword == "SIMPLE" and card.value is False
   795	
   796	    @property
   797	    def size(self):
   798	        """
   799	        Returns the size (in bytes) of the HDU's data part.
   800	        """
   801	        if self._buffer is not None:
   802	            return len(self._buffer) - self._data_offset
   803	
   804	        return self._file.size - self._data_offset
   805	
   806	    def _writedata(self, fileobj):
   807	        """
   808	        Differs from the base class :class:`_writedata` in that it doesn't
   809	        automatically add padding, and treats the data as a string of raw bytes
   810	        instead of an array.
   811	        """
   812	        offset = 0
   813	        size = 0
   814	
   815	        fileobj.flush()
   816	        try:
   817	            offset = fileobj.tell()
   818	        except OSError:
   819	            offset = 0
   820	
   821	        if self.data is not None:
   822	            fileobj.write(self.data)
   823	            # flush, to make sure the content is written
   824	            fileobj.flush()
   825	            size = len(self.data)
   826	
   827	        # return both the location and the size of the data area
   828	        return offset, size
   829	
   830	    def _summary(self):
   831	        return (self.name, self.ver, "NonstandardHDU", len(self._header))
   832	
   833	    @lazyproperty
   834	    def data(self):
   835	        """
   836	        Return the file data.
   837	        """
   838	        return self._get_raw_data(self.size, "ubyte", self._data_offset)
   839	
   840	    def _verify(self, option="warn"):
   841	        errs = _ErrList([], unit="Card")
   842	
   843	        # verify each card
   844	        for card in self._header.cards:
   845	            errs.append(card._verify(option))
   846	
   847	        return errs
   848	
   849	
   850	class _ValidHDU(_BaseHDU, _Verify):
astropy/io/fits/hdu/base.py
_Delayed 39 40
InvalidHDUException 75 80
_hdu_class_from_header 83 128
_BaseHDU 133 711
_CorruptedHDU 733 766
_NonstandardHDU 769 847
_ValidHDU 850 1509
ExtensionHDU 1512 1555
NonstandardExtHDU 1558 1599
__init__ 150 173
__init_subclass__ 175 206
header 209 210
header 213 214
name 217 220
name 223 231
ver 234 235
ver 238 244
level 247 248
level 251 257
is_image 260 271
register_hdu 282 283
unregister_hdu 286 288
match_header 291 292
fromstring 295 329
writeto 367 405
_from_data 408 414
_writeheader 559 571
_writedata 573 605
_writedata_internal 607 616
_writedata_direct_copy 618 633
_writeto_internal 648 711
size 751 760
_summary 762 763
verify 765 766
match_header 787 794
size 797 804
_writedata 806 828
_summary 830 831
data 834 838
_verify 840 847
__init__ 855 874
match_header 877 886
size 889 893
filebytes 895 902
fileinfo 904 940
copy 942 950
_verify 952 1032
_prewriteto 1034 1036
req_cards 1040 1171
add_datasum 1173 1206
add_checksum 1208 1261
verify_datasum 1263 1283
verify_checksum 1285 1309
_verify_checksum_datasum 1311 1332
_update_checksum 1334 1365
_get_timestamp 1367 1374
_calculate_datasum 1376 1394
_calculate_checksum 1396 1415
_compute_checksum 1417 1450
_encode_byte 1459 1479
_char_encode 1481 1509
match_header 1523 1529
writeto 1531 1541
_verify 1543 1555
match_header 1573 1588
_summary 1590 1592
data 1595 1599
astropy/io/fits/util.py
NotifierMixin 33 142
first 145 155
itersubclasses 158 190
ignore_sigint 193 238
encode_ascii 241 251
decode_ascii 254 287
isreadable 290 307
iswritable 310 327
isfile 330 344
fileobj_mode 395 424
_fileobj_normalize_mode 427 449
fileobj_is_binary 452 469
translate 472 477
fill 480 494
_array_from_file 505 538
_array_to_file 545 600
_array_to_file_like 603 642
_convert_array 662 677
_pseudo_zero 680 690
_str_to_num 703 710
_words_group 713 756
_tmp_name 759 768
_free_space_check 787 808
_extract_number 811 821
get_testdata_filepath 824 841
_rstrip_inplace 844 890
_is_dask_array 893 900
_remove_listener 91 100
_notify 102 125
__getstate__ 127 142
wrapped 200 236
maybe_fill 488 492
```

## 原始行 62 · file_change

```
{
  "id": "item_40",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc "sed -n '1890,1935p' astropy/io/fits/header.py; python - <<'PY'
from astropy.io import fits
h=fits.Header([('A',1),('COMMENT','x')]); print(h, list(h),h.count('a'))
h.append(); h.append(('B',2)); print(list(h),len(h),h._countblanks())
h.insert(1,('C',3)); print(list(h),dict(h._keyword_indices))
PY"
```

退出码：`1`

输出：
```
                f"There are only {len(indices)} {keyword!r} cards in the header."
            )

    def _keyword_from_index(self, idx):
        """
        Given an integer index, return the (keyword, repeat) tuple that index
        refers to.  For most keywords the repeat will always be zero, but it
        may be greater than zero for keywords that are duplicated (especially
        commentary keywords).

        In a sense this is the inverse of self.index, except that it also
        supports duplicates.
        """
        if idx < 0:
            idx += len(self._cards)

        keyword = self._cards[idx].keyword
        keyword = Card.normalize_keyword(keyword)
        repeat = self._keyword_indices[keyword].index(idx)
        return keyword, repeat

    def _updateindices(self, idx, increment=True):
        """Shift all maintained card indices at or above ``idx``."""
        if idx > len(self._cards):
            return
        delta = 1 if increment else -1
        for mapping in (self._keyword_indices, self._rvkc_indices):
            for indices in mapping.values():
                for position, value in enumerate(indices):
                    if value >= idx:
                        indices[position] = value + delta

    def _update(self, card):
        """Update an existing card or append it if its keyword is new."""
        if not isinstance(card, Card):
            card = Card(*card)
        keyword = Card.normalize_keyword(card.keyword)

        if keyword in _commentary_keywords:
            for commentary_card in self._splitcommentary(keyword, card.value):
                self.append(commentary_card)
            return

        try:
            idx = self._cardindex(card.keyword)
        except (KeyError, IndexError):
Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
  File "/testbed/astropy/io/fits/header.py", line 286, in __str__
    return self.tostring()
           ^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/header.py", line 716, in tostring
    s = str(card)
        ^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 213, in __str__
    return self.image
           ^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 529, in image
    self._image = self._format_image()
                  ^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 997, in _format_image
    value = self._format_value()
            ^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 980, in _format_value
    value = _format_value(value)
            ^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/card.py", line 1284, in _format_value
    elif _is_int(value):
         ^^^^^^^
NameError: name '_is_int' is not defined
```

## 原始行 68 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import ast
fn='astropy/io/fits/card.py'; m=ast.parse(open(fn).read())
for n in m.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)): print(n.name,n.lineno,n.end_lineno)
PY
nl -ba astropy/io/fits/card.py | tail -160; git status --short"
```

退出码：`0`

输出：
```
Undefined 30 35
Card 41 1243
_int_or_float 1246 1262
_format_value 1265 1297
_format_float 1300 1314
_pad 1317 1332
  1173	                        "err_text": (
  1174	                            f"Unprintable string {valuecomment!r}; commentary "
  1175	                            "cards may only contain printable ASCII characters"
  1176	                        ),
  1177	                        "fixable": False,
  1178	                    }
  1179	                )
  1180	        else:
  1181	            if not self._valuemodified:
  1182	                m = self._value_FSC_RE.match(valuecomment)
  1183	                # If the value of a card was replaced before the card was ever
  1184	                # even verified, the new value can be considered valid, so we
  1185	                # don't bother verifying the old value.  See
  1186	                # https://github.com/astropy/astropy/issues/5408
  1187	                if m is None:
  1188	                    errs.append(
  1189	                        {
  1190	                            "err_text": (
  1191	                                f"Card {self.keyword!r} is not FITS standard "
  1192	                                f"(invalid value string: {valuecomment!r})."
  1193	                            ),
  1194	                            "fix_text": fix_text,
  1195	                            "fix": self._fix_value,
  1196	                        }
  1197	                    )
  1198	
  1199	        # verify the comment (string), it is never fixable
  1200	        m = self._value_NFSC_RE.match(valuecomment)
  1201	        if m is not None:
  1202	            comment = m.group("comm")
  1203	            if comment is not None:
  1204	                if not self._ascii_text_re.match(comment):
  1205	                    errs.append(
  1206	                        {
  1207	                            "err_text": (
  1208	                                f"Unprintable string {comment!r}; header comments "
  1209	                                "may only contain printable ASCII characters"
  1210	                            ),
  1211	                            "fixable": False,
  1212	                        }
  1213	                    )
  1214	
  1215	        errs = _ErrList([self.run_option(option, **err) for err in errs])
  1216	        self._verified = True
  1217	        return errs
  1218	
  1219	    def _itersubcards(self):
  1220	        """
  1221	        If the card image is greater than 80 characters, it should consist of a
  1222	        normal card followed by one or more CONTINUE card.  This method returns
  1223	        the subcards that make up this logical card.
  1224	
  1225	        This can also support the case where a HISTORY or COMMENT card has a
  1226	        long value that is stored internally as multiple concatenated card
  1227	        images.
  1228	        """
  1229	        ncards = len(self._image) // Card.length
  1230	
  1231	        for idx in range(0, Card.length * ncards, Card.length):
  1232	            card = Card.fromstring(self._image[idx : idx + Card.length])
  1233	            if idx > 0 and card.keyword.upper() not in self._special_keywords:
  1234	                raise VerifyError(
  1235	                    "Long card images must have CONTINUE cards after "
  1236	                    "the first card or have commentary keywords like "
  1237	                    "HISTORY or COMMENT."
  1238	                )
  1239	
  1240	            if not isinstance(card.value, str):
  1241	                raise VerifyError("CONTINUE cards must have string values.")
  1242	
  1243	            yield card
  1244	
  1245	
  1246	def _int_or_float(s):
  1247	    """
  1248	    Converts an a string to an int if possible, or to a float.
  1249	
  1250	    If the string is neither a string or a float a value error is raised.
  1251	    """
  1252	    if isinstance(s, float):
  1253	        # Already a float so just pass through
  1254	        return s
  1255	
  1256	    try:
  1257	        return int(s)
  1258	    except (ValueError, TypeError):
  1259	        try:
  1260	            return float(s)
  1261	        except (ValueError, TypeError) as e:
  1262	            raise ValueError(str(e))
  1263	
  1264	
  1265	def _format_value(value):
  1266	    """
  1267	    Converts a card value to its appropriate string representation as
  1268	    defined by the FITS format.
  1269	    """
  1270	    # string value should occupies at least 8 columns, unless it is
  1271	    # a null string
  1272	    if isinstance(value, str):
  1273	        if value == "":
  1274	            return "''"
  1275	        else:
  1276	            exp_val_str = value.replace("'", "''")
  1277	            val_str = f"'{exp_val_str:8}'"
  1278	            return f"{val_str:20}"
  1279	
  1280	    # must be before int checking since bool is also int
  1281	    elif isinstance(value, (bool, np.bool_)):
  1282	        return f"{repr(value)[0]:>20}"  # T or F
  1283	
  1284	    elif _is_int(value):
  1285	        return f"{value:>20d}"
  1286	
  1287	    elif isinstance(value, (float, np.floating)):
  1288	        return f"{_format_float(value):>20}"
  1289	
  1290	    elif isinstance(value, (complex, np.complexfloating)):
  1291	        val_str = f"({_format_float(value.real)}, {_format_float(value.imag)})"
  1292	        return f"{val_str:>20}"
  1293	
  1294	    elif isinstance(value, Undefined):
  1295	        return ""
  1296	    else:
  1297	        return ""
  1298	
  1299	
  1300	def _format_float(value):
  1301	    """Format a floating number to make sure it is at most 20 characters."""
  1302	    value_str = str(value).replace("e", "E")
  1303	
  1304	    # Limit the value string to at most 20 characters.
  1305	    if (str_len := len(value_str)) > 20:
  1306	        idx = value_str.find("E")
  1307	        if idx < 0:
  1308	            # No scientific notation, truncate decimal places
  1309	            value_str = value_str[:20]
  1310	        else:
  1311	            # Scientific notation, truncate significand (mantissa)
  1312	            value_str = value_str[: 20 - (str_len - idx)] + value_str[idx:]
  1313	
  1314	    return value_str
  1315	
  1316	
  1317	def _pad(input):
  1318	    """Pad blank space to the input string to be multiple of 80."""
  1319	    _len = len(input)
  1320	    if _len == Card.length:
  1321	        return input
  1322	    elif _len > Card.length:
  1323	        strlen = _len % Card.length
  1324	        if strlen == 0:
  1325	            return input
  1326	        else:
  1327	            return input + " " * (Card.length - strlen)
  1328	
  1329	    # minimum length is 80
  1330	    else:
  1331	        strlen = _len % Card.length
  1332	        return input + " " * (Card.length - strlen)
 M astropy/io/fits/header.py
```

## 原始行 71 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,55p' astropy/io/fits/card.py; grep -RIn \"def _is_int\\|_is_int\" astropy/io/fits | head; sed -n '1900,1945p' astropy/io/fits/header.py; sed -n '1980,2025p' astropy/io/fits/header.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import re
import warnings

import numpy as np

from astropy.utils.exceptions import AstropyUserWarning

from . import conf
from .util import _str_to_num, _words_group, translate
from .verify import VerifyError, VerifyWarning, _ErrList, _Verify

__all__ = ["Card", "Undefined"]


FIX_FP_TABLE = str.maketrans("de", "DE")
FIX_FP_TABLE2 = str.maketrans("dD", "eE")


CARD_LENGTH = 80
BLANK_CARD = " " * CARD_LENGTH
KEYWORD_LENGTH = 8  # The max length for FITS-standard keywords

VALUE_INDICATOR = "= "  # The standard FITS value indicator
VALUE_INDICATOR_LEN = len(VALUE_INDICATOR)
HIERARCH_VALUE_INDICATOR = "="  # HIERARCH cards may use a shortened indicator


class Undefined:
    """Undefined value."""

    def __init__(self):
        # This __init__ is required to be here for Sphinx documentation
        pass


UNDEFINED = Undefined()


class Card(_Verify):
    length = CARD_LENGTH
    """The length of a Card image; should always be 80 for valid FITS files."""

    # String for a FITS standard compliant (FSC) keyword.
    _keywd_FSC_RE = re.compile(r"^[A-Z0-9_-]{0,%d}$" % KEYWORD_LENGTH)  # noqa: UP031, RUF100
    # This will match any printable ASCII character excluding '='
    _keywd_hierarch_RE = re.compile(
        r"^(?:HIERARCH +)?(?:^[ -<>-~]+ ?)+$", re.IGNORECASE
    )

    # A number sub-string, either an integer or a float in fixed or
    # scientific notation.  One for FSC and one for non-FSC (NFSC) format:
    # NFSC allows lower case of DE for exponent, allows space between sign,
    # digits, exponent sign, and exponents
astropy/io/fits/card.py:1284:    elif _is_int(value):
astropy/io/fits/column.py:1077:                if not _is_int(null):
astropy/io/fits/column.py:1159:                if not _is_int(start) or start < 1:
astropy/io/fits/column.py:1758:        if _is_int(key):
astropy/io/fits/hdu/base.py:239:        if not _is_int(value):
astropy/io/fits/hdu/base.py:252:        if not _is_int(value):
astropy/io/fits/hdu/base.py:969:            "BITPIX", 1, lambda v: (_is_int(v) and is_valid(v)), 8, option, errs
astropy/io/fits/hdu/base.py:972:            "NAXIS", 2, lambda v: (_is_int(v) and 0 <= v <= 999), 0, option, errs
astropy/io/fits/hdu/base.py:982:                    lambda v: (_is_int(v) and v >= 0),
astropy/io/fits/hdu/base.py:1104:        if _is_int(pos):
        In a sense this is the inverse of self.index, except that it also
        supports duplicates.
        """
        if idx < 0:
            idx += len(self._cards)

        keyword = self._cards[idx].keyword
        keyword = Card.normalize_keyword(keyword)
        repeat = self._keyword_indices[keyword].index(idx)
        return keyword, repeat

    def _updateindices(self, idx, increment=True):
        """Shift all maintained card indices at or above ``idx``."""
        if idx > len(self._cards):
            return
        delta = 1 if increment else -1
        for mapping in (self._keyword_indices, self._rvkc_indices):
            for indices in mapping.values():
                for position, value in enumerate(indices):
                    if value >= idx:
                        indices[position] = value + delta

    def _update(self, card):
        """Update an existing card or append it if its keyword is new."""
        if not isinstance(card, Card):
            card = Card(*card)
        keyword = Card.normalize_keyword(card.keyword)

        if keyword in _commentary_keywords:
            for commentary_card in self._splitcommentary(keyword, card.value):
                self.append(commentary_card)
            return

        try:
            idx = self._cardindex(card.keyword)
        except (KeyError, IndexError):
            self.append(card)
            return

        old = self._cards[idx]
        # Assignment to an RVKC field must preserve its normalized lookup.
        if old.field_specifier is not None and card.field_specifier is None:
            old.value = card.value
            old.comment = card.comment
            self._modified = True
            return
```

## 原始行 74 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"_is_int[ ,)]\" astropy/io/fits/*.py | head -30; sed -n '1,50p' astropy/io/fits/hdu/base.py; sed -n '1,40p' astropy/io/fits/column.py; sed -n '2060,2100p' astropy/io/fits/header.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst


import datetime
import numbers
import os
import sys
import warnings
from contextlib import suppress
from inspect import Parameter, signature

import numpy as np

from astropy.io.fits import conf
from astropy.io.fits.file import _File
from astropy.io.fits.header import Header, _BasicHeader, _DelayedHeader, _pad_length
from astropy.io.fits.util import _extract_number, _free_space_check, decode_ascii, first, itersubclasses








from astropy.io.fits.verify import _ErrList, _Verify
from astropy.utils import lazyproperty
from astropy.utils.exceptions import AstropyUserWarning

__all__ = [
    "DELAYED",
    "ExtensionHDU",
    # classes
    "InvalidHDUException",
    "NonstandardExtHDU",
]


class _Delayed:
    pass


DELAYED = _Delayed()


BITPIX2DTYPE = {
    8: "uint8",
    16: "int16",
    32: "int32",
    64: "int64",
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import copy
import numbers
import operator
import re
import sys
import warnings
import weakref
from collections import OrderedDict
from contextlib import suppress
from functools import reduce
from itertools import pairwise
from textwrap import indent

import numpy as np
from numpy import char as chararray

from astropy.utils import lazyproperty
from astropy.utils.exceptions import AstropyUserWarning

from .card import CARD_LENGTH, Card
from .util import NotifierMixin, _convert_array, cmp, encode_ascii
from .verify import VerifyError, VerifyWarning

__all__ = ["ColDefs", "Column", "Delayed"]


# mapping from TFORM data type to numpy data type (code)
# L: Logical (Boolean)
# B: Unsigned Byte
# I: 16-bit Integer
# J: 32-bit Integer
# K: 64-bit Integer
# E: Single-precision Floating Point
# D: Double-precision Floating Point
# C: Single-precision Complex
# M: Double-precision Complex
# A: Character
FITS2NUMPY = {
        """Insert *card* relative to another card, optionally replacing it."""
        reference = before if before is not None else after
        idx = self._cardindex(reference)
        if replace:
            old_idx = self._cardindex(card.keyword if isinstance(card, Card) else card[0])
            del self[old_idx]
            if old_idx < idx:
                idx -= 1
        self.insert(idx, card, after=before is None and after is not None)





















    def _splitcommentary(self, keyword, value):
        """
        Given a commentary keyword and value, returns a list of the one or more
        cards needed to represent the full value.  This is primarily used to
        create the multiple commentary cards needed to represent a long value
        that won't fit into a single commentary card.
        """
        # The maximum value in each card can be the maximum card length minus
        # the maximum key length (which can include spaces if they key length
        # less than 8
        maxlen = Card.length - KEYWORD_LENGTH
```

## 原始行 77 · command_execution

命令：
```
/bin/bash -lc "sed -n '2100,2155p' astropy/io/fits/header.py; grep -RIn \"_is_int\" astropy/io/fits --include='*.py' | head -30"
```

退出码：`0`

输出：
```
        maxlen = Card.length - KEYWORD_LENGTH
        valuestr = str(value)

        if len(valuestr) <= maxlen:
            # The value can fit in a single card
            cards = [Card(keyword, value)]
        else:
            # The value must be split across multiple consecutive commentary
            # cards
            idx = 0
            cards = []
            while idx < len(valuestr):
                cards.append(Card(keyword, valuestr[idx : idx + maxlen]))
                idx += maxlen
        return cards

    def _add_commentary(self, key, value, before=None, after=None):
        """
        Add a commentary card.

        If ``before`` and ``after`` are `None`, add to the last occurrence
        of cards of the same name (except blank card).  If there is no
        card (or blank card), append at the end.
        """
        if before is not None or after is not None:
            self._relativeinsert((key, value), before=before, after=after)
        else:
            self[key] = value


collections.abc.MutableSequence.register(Header)
collections.abc.MutableMapping.register(Header)


class _DelayedHeader:
    """
    Descriptor used to create the Header object from the header string that
    was stored in HDU._header_str when parsing the file.
    """

    def __get__(self, obj, owner=None):
        try:
            return obj.__dict__["_header"]
        except KeyError:
            if obj._header_str is not None:
                hdr = Header.fromstring(obj._header_str)
                obj._header_str = None
            else:
                raise AttributeError(
                    f"'{type(obj).__name__}' object has no attribute '_header'"
                )

            obj.__dict__["_header"] = hdr
            return hdr

    def __set__(self, obj, val):
astropy/io/fits/card.py:1284:    elif _is_int(value):
astropy/io/fits/column.py:1077:                if not _is_int(null):
astropy/io/fits/column.py:1159:                if not _is_int(start) or start < 1:
astropy/io/fits/column.py:1758:        if _is_int(key):
astropy/io/fits/hdu/base.py:239:        if not _is_int(value):
astropy/io/fits/hdu/base.py:252:        if not _is_int(value):
astropy/io/fits/hdu/base.py:969:            "BITPIX", 1, lambda v: (_is_int(v) and is_valid(v)), 8, option, errs
astropy/io/fits/hdu/base.py:972:            "NAXIS", 2, lambda v: (_is_int(v) and 0 <= v <= 999), 0, option, errs
astropy/io/fits/hdu/base.py:982:                    lambda v: (_is_int(v) and v >= 0),
astropy/io/fits/hdu/base.py:1104:        if _is_int(pos):
astropy/io/fits/hdu/base.py:1549:            "PCOUNT", naxis + 3, lambda v: (_is_int(v) and v >= 0), 0, option, errs
astropy/io/fits/hdu/base.py:1552:            "GCOUNT", naxis + 4, lambda v: (_is_int(v) and v == 1), 1, option, errs
astropy/io/fits/hdu/image.py:594:        if not _is_int(self._blank):
astropy/io/fits/hdu/image.py:1021:            if not _is_int(key[idx]):
astropy/io/fits/hdu/image.py:1270:            "PCOUNT", naxis + 3, lambda v: (_is_int(v) and v == 0), 0, option, errs
astropy/io/fits/hdu/image.py:1277:        if _is_int(index):
astropy/io/fits/hdu/hdulist.py:422:            if _is_int(_key):
astropy/io/fits/hdu/hdulist.py:824:        if _is_int(key):
astropy/io/fits/hdu/compressed/compressed.py:609:        if not _is_int(seed):
astropy/io/fits/hdu/table.py:540:                lambda v: (_is_int(v) and v >= 0 and v <= 999),
astropy/io/fits/hdu/table.py:793:            self.req_cards("TBCOL" + str(idx + 1), None, _is_int, None, option, errs)
astropy/io/fits/hdu/groups.py:42:        if _is_int(parname):
astropy/io/fits/hdu/groups.py:62:        if _is_int(parname):
astropy/io/fits/hdu/groups.py:249:        if _is_int(parname):
astropy/io/fits/hdu/groups.py:511:            "NAXIS", 2, lambda v: (_is_int(v) and 1 <= v <= 999), 1, option, errs
astropy/io/fits/hdu/groups.py:513:        self.req_cards("NAXIS1", 3, lambda v: (_is_int(v) and v == 0), 0, option, errs)
astropy/io/fits/hdu/groups.py:518:        self.req_cards("GCOUNT", pos, _is_int, 1, option, errs)
astropy/io/fits/hdu/groups.py:519:        self.req_cards("PCOUNT", pos, _is_int, 0, option, errs)
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc 'for f in astropy/io/fits/hdu/{image.py,hdulist.py,table.py,groups.py} astropy/io/fits/hdu/compressed/compressed.py; do echo $f; grep -n "from .*util import" $f | head; done'
```

退出码：`0`

输出：
```
astropy/io/fits/hdu/image.py
10:from astropy.io.fits.util import _is_dask_array, _pseudo_zero
astropy/io/fits/hdu/hdulist.py
16:from astropy.io.fits.util import _free_space_check, _tmp_name, fileobj_mode, ignore_sigint, isfile
astropy/io/fits/hdu/table.py
38:from astropy.io.fits.util import _str_to_num, path_like
astropy/io/fits/hdu/groups.py
9:from astropy.io.fits.util import _pseudo_zero
astropy/io/fits/hdu/compressed/compressed.py
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _is_url\" -A25 astropy/utils/data.py; grep -n \"def download_file\" -A15 astropy/utils/data.py; grep -RIn \"strict_memmap\\|memmap=\" astropy/io/fits/file.py astropy/io/fits | head -100; grep -RIn \"close_on_error\" astropy/io/fits | head -50"
```

退出码：`0`

输出：
```
1398:def download_file(
1399-    remote_url,
1400-    cache=False,
1401-    show_progress=True,
1402-    timeout=None,
1403-    sources=None,
1404-    pkgname="astropy",
1405-    http_headers=None,
1406-    ssl_context=None,
1407-    allow_insecure=False,
1408-):
1409-    """Downloads a URL and optionally caches the result.
1410-
1411-    It returns the filename of a file containing the URL's contents.
1412-    If ``cache=True`` and the file is present in the cache, just
1413-    returns the filename; if the file had to be downloaded, add it
--
1665:def download_files_in_parallel(
1666-    urls,
1667-    cache="update",
1668-    show_progress=True,
1669-    timeout=None,
1670-    sources=None,
1671-    multiprocessing_start_method=None,
1672-    pkgname="astropy",
1673-):
1674-    """Download multiple files in parallel from the given URLs.
1675-
1676-    Blocks until all files have downloaded.  The result is a list of
1677-    local file paths corresponding to the given urls.
1678-
1679-    The results will be stored in the cache under the values in ``urls`` even
1680-    if they are obtained from some other location via ``sources``. See
astropy/io/fits/file.py:100:# 'copyonwrite' and 'denywrite' modes unless memmap=True.  For now, however,
astropy/io/fits/file.py:100:# 'copyonwrite' and 'denywrite' modes unless memmap=True.  For now, however,
astropy/io/fits/connect.py:124:    memmap=False,
astropy/io/fits/connect.py:184:        when using ``memmap=True`` (see above).
astropy/io/fits/connect.py:188:        using ``memmap=True`` (see above).
astropy/io/fits/connect.py:269:            memmap=memmap,
astropy/io/fits/hdu/image.py:812:            if self._file.strict_memmap:
astropy/io/fits/hdu/image.py:816:                    "Set memmap=False."
astropy/io/fits/hdu/image.py:818:        except AttributeError:  # strict_memmap not set
astropy/io/fits/hdu/hdulist.py:47:    memmap=None,
astropy/io/fits/hdu/hdulist.py:470:        memmap=None,
astropy/io/fits/hdu/hdulist.py:487:            memmap=memmap,
astropy/io/fits/hdu/hdulist.py:1168:        memmap=None,
astropy/io/fits/hdu/hdulist.py:1189:                    memmap=memmap,
astropy/io/fits/hdu/hdulist.py:1516:            ffo = _File(old_file, mode="update", memmap=old_memmap)
astropy/io/fits/tests/test_core.py:1212:                with fits.open(testfile, mode="update", memmap=True) as h:
astropy/io/fits/tests/test_core.py:1249:        with fits.open(self.data("test0.fits"), memmap=True) as hdulist:
astropy/io/fits/tests/test_core.py:1268:        with fits.open(self.data("test0.fits"), memmap=True) as hdul:
astropy/io/fits/tests/test_core.py:1289:        with fits.open(self.data("test0.fits"), memmap=True) as hdul:
astropy/io/fits/tests/test_core.py:1297:        with fits.open(self.data("test0.fits"), memmap=True) as hdul:
astropy/io/fits/tests/test_core.py:1645:        with fits.open(pth, memmap=True) as hdul:
astropy/io/fits/tests/test_core.py:1651:        with fits.open(pth, memmap=True, do_not_scale_image_data=True) as hdul:
astropy/io/fits/tests/test_table.py:2559:        with fits.open(self.temp("ascii_null.fits"), memmap=True) as f:
astropy/io/fits/tests/test_table.py:2580:        with fits.open(self.temp("ascii_null2.fits"), memmap=True) as f:
astropy/io/fits/tests/test_table.py:3002:        with fits.open(self.temp("foo.fits"), memmap=False) as hdul:
astropy/io/fits/tests/test_groups.py:67:        fits.open(testfile, mode="update", memmap=False).close()
astropy/io/fits/tests/test_header.py:2278:        with fits.open(self.temp("test.fits"), memmap=False) as hdul:
astropy/io/fits/tests/test_image.py:384:        f1 = fits.open(self.data("test0.fits"), memmap=1)
astropy/io/fits/tests/test_connect.py:313:        t2 = Table.read(filename, memmap=False)
astropy/io/fits/tests/test_connect.py:314:        t3 = Table.read(filename, memmap=True)
astropy/io/fits/tests/test_connect.py:326:        t2 = Table.read(filename, character_as_bytes=False, memmap=memmap)
astropy/io/fits/tests/test_connect.py:327:        t3 = Table.read(filename, character_as_bytes=True, memmap=memmap)
astropy/io/fits/tests/test_connect.py:347:        t = Table.read(filename, character_as_bytes=character_as_bytes, memmap=True)
astropy/io/fits/tests/test_connect.py:434:        tab = Table.read(filename, memmap=True)
astropy/io/fits/tests/test_hdulist.py:592:        hdul = fits.open(self.temp("temp.fits"), mode="update", memmap=True)
astropy/io/fits/tests/test_hdulist.py:597:        with fits.open(self.temp("temp.fits"), memmap=True) as hdul:
astropy/io/fits/tests/test_hdulist.py:874:                self.temp("test_a.fits"), mode="update", memmap=mmap_a
astropy/io/fits/tests/test_hdulist.py:876:                with fits.open(self.temp("test_b.fits"), memmap=mmap_b) as hdul_b:
astropy/io/fits/tests/test_hdulist.py:911:                self.temp("test_a.fits"), mode="update", memmap=mmap_a
astropy/io/fits/tests/test_hdulist.py:913:                with fits.open(self.temp("test_b.fits"), memmap=mmap_b) as hdul_b:
astropy/io/fits/hdu/hdulist.py:1237:                    if hdulist._file.close_on_error:
astropy/io/fits/hdu/hdulist.py:1262:            if hdulist._file.close_on_error:
astropy/io/fits/hdu/hdulist.py:1332:                        if self._file.close_on_error:
```

## 原始行 86 · command_execution

命令：
```
/bin/bash -lc "grep -n \"_is_url\" astropy/utils/data.py | head -20; sed -n '1300,1325p' astropy/utils/data.py; sed -n '780,830p' astropy/io/fits/hdu/image.py"
```

退出码：`0`

输出：
```
181:_is_url = is_url
354:            is_url = _is_url(name_or_obj)
1860:        elif _is_url(hashorurl):
1929:    if not _is_url(url):
2021:                    if not _is_url(url):
            "allow_internet"
        )

    if remote_url is None:
        remote_url = source_url
    if http_headers is None:
        http_headers = {}

    if ftp_tls is None and urllib.parse.urlparse(remote_url).scheme == "ftp":
        try:
            return _download_file_from_source(
                source_url,
                show_progress=show_progress,
                timeout=timeout,
                remote_url=remote_url,
                cache=cache,
                pkgname=pkgname,
                http_headers=http_headers,
                ftp_tls=False,
            )
        except urllib.error.URLError as e:
            # e.reason might not be a string, e.g. socket.gaierror
            # URLError changed to report original exception in Python 3.11 (bpo-43564)
            if (
                str(e.reason)
                .removeprefix("ftp error: ")
        if dtype is not None and dtype.kind == "u":
            # Convert the input raw data into an unsigned integer array and
            # then scale the data adjusting for the value of BZERO.  Note that
            # we subtract the value of BZERO instead of adding because of the
            # way numpy converts the raw signed array into an unsigned array.
            bits = dtype.itemsize * 8
            data = np.array(data, dtype=dtype)
            data -= np.uint64(1 << (bits - 1))

            return data

    def _get_scaled_image_data(self, offset, shape):
        """
        Internal function for reading image data from a file and apply scale
        factors to it.  Normally this is used for the entire image, but it
        supports alternate offset/shape for Section support.
        """
        code = BITPIX2DTYPE[self._orig_bitpix]

        raw_data = self._get_raw_data(shape, code, offset)
        raw_data = raw_data.view(raw_data.dtype.newbyteorder(">"))

        return self._scale_data(raw_data)

    def _scale_data(self, raw_data):
        if self._do_not_scale_image_data or (
            self._orig_bzero == 0 and self._orig_bscale == 1 and self._blank is None
        ):
            # No further conversion of the data is necessary
            return raw_data

        try:
            if self._file.strict_memmap:
                raise ValueError(
                    "Cannot load a memory-mapped image: "
                    "BZERO/BSCALE/BLANK header keywords present. "
                    "Set memmap=False."
                )
        except AttributeError:  # strict_memmap not set
            pass

        data = None
        if not (self._orig_bzero == 0 and self._orig_bscale == 1):
            data = self._convert_pseudo_integer(raw_data)

        if data is None:
            # In these cases, we end up with floating-point arrays and have to
            # apply bscale and bzero. We may have to handle BLANK and convert
            # to NaN in the resulting floating-point arrays.
            # The BLANK keyword should only be applied for integer data (this
            # is checked in __init__ but it can't hurt to double check here)
```

## 原始行 90 · command_execution

命令：
```
/bin/bash -lc "sed -n '285,370p' astropy/io/fits/util.py; sed -n '452,475p' astropy/io/fits/util.py; grep -n \"def is_url\" -A30 astropy/utils/data.py | head -40"
```

退出码：`0`

输出：
```
        # to be decoded
        raise TypeError("string operation on non-string array")
    return s


def isreadable(f):
    """
    Returns True if the file-like object can be read from.  This is a common-
    sense approximation of io.IOBase.readable.
    """
    if hasattr(f, "readable"):
        return f.readable()

    if hasattr(f, "closed") and f.closed:
        # This mimics the behavior of io.IOBase.readable
        raise ValueError("I/O operation on closed file")

    if not hasattr(f, "read"):
        return False

    # Not closed, has a 'read()' method, and either has no known mode or a
    # readable mode--should be good enough to assume 'readable'
    return (not hasattr(f, "mode")) or any(c in f.mode for c in "r+")


def iswritable(f):
    """
    Returns True if the file-like object can be written to.  This is a common-
    sense approximation of io.IOBase.writable.
    """
    if hasattr(f, "writable"):
        return f.writable()

    if hasattr(f, "closed") and f.closed:
        # This mimics the behavior of io.IOBase.writable
        raise ValueError("I/O operation on closed file")

    if not hasattr(f, "write"):
        return False

    # Note closed, has a 'write()' method, and either has no known mode or a
    # mode that supports writing--should be good enough to assume 'writable'
    return (not hasattr(f, "mode")) or any(c in f.mode for c in "wa+")


def isfile(f):
    """
    Returns True if the given object represents an OS-level file (that is,
    ``isinstance(f, file)``).

    This also returns True if the given object is higher level
    wrapper on top of a FileIO object, such as a TextIOWrapper.
    """
    if isinstance(f, io.FileIO):
        return True
    elif hasattr(f, "buffer"):
        return isfile(f.buffer)
    elif hasattr(f, "raw"):
        return isfile(f.raw)
    return False


























def fileobj_is_binary(f):
    """
    Returns True if the give file or file-like object has a file open in binary
    mode.  When in doubt, returns True by default.
    """
    # This is kind of a hack for this to work correctly with _File objects,
    # which, for the time being, are *always* binary
    if hasattr(f, "binary"):
        return f.binary

    if isinstance(f, io.TextIOBase):
        return False

    mode = fileobj_mode(f)
    if mode:
        return "b" in mode
    else:
        return True


def translate(s, table, deletechars):
    if deletechars:
        table = table.copy()
        for c in deletechars:
158:def is_url(string):
159-    """
160-    Test whether a string is a valid URL for :func:`download_file`.
161-
162-    Parameters
163-    ----------
164-    string : str
165-        The string to test.
166-
167-    Returns
168-    -------
169-    status : bool
170-        String is URL or not.
171-
172-    """
173-    url = urllib.parse.urlparse(string)
174-    # we can't just check that url.scheme is not an empty string, because
175-    # file paths in windows would return a non-empty scheme (e.g. e:\\
176-    # returns 'e').
177-    return url.scheme.lower() in ["http", "https", "ftp", "sftp", "ssh", "file"]
178-
179-
180-# Backward compatibility because some downstream packages allegedly uses it.
181-_is_url = is_url
182-
183-
184-
185-
186-
187-
188-
--
1615:def is_url_in_cache(url_key, pkgname="astropy"):
1616-    """Check if a download for ``url_key`` is in the cache.
1617-
1618-    The provided ``url_key`` will be the name used in the cache. The contents
1619-    may have been downloaded from this URL or from a mirror or they may have
1620-    been provided by the user. See `~download_file` for details.
1621-
1622-    Parameters
```

## 原始行 93 · file_change

```
{
  "id": "item_61",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/card.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/groups.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/hdulist.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/image.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 96 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,55p' astropy/io/fits/hdu/compressed/compressed.py; python - <<'PY'
from astropy.io import fits
h=fits.Header([('A',1),('COMMENT','x')]); print(list(h),h.count('a'), repr(h[0]))
h.append(); h.append(('B',2)); print(list(h),len(h),h._countblanks())
h.insert(1,('C',3)); print(list(h),dict(h._keyword_indices))
try: print(fits.PrimaryHDU())
except Exception as e:
 import traceback; traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import ctypes
import math
import time
import warnings

import numpy as np

from astropy.io.fits.fitsrec import FITS_rec
from astropy.io.fits.hdu.base import BITPIX2DTYPE, DELAYED
from astropy.io.fits.hdu.compressed._quantization import DITHER_METHODS
from astropy.io.fits.hdu.compressed._tiled_compression import (
    _get_compression_setting,
    compress_image_data,
)
from astropy.io.fits.hdu.compressed.utils import _tile_shape, _validate_tile_shape
from astropy.io.fits.hdu.image import ImageHDU
from astropy.io.fits.header import Header

from astropy.io.fits.verify import _ErrList
from astropy.utils.decorators import lazyproperty
from astropy.utils.exceptions import AstropyUserWarning

from .header import (
    _bintable_header_to_image_header,
    _image_header_to_empty_bintable,
)
from .section import CompImageSection
from .settings import (
    CMTYPE_ALIASES,
    COMPRESSION_TYPES,
    DEFAULT_COMPRESSION_TYPE,
    DEFAULT_DITHER_SEED,
    DEFAULT_HCOMP_SCALE,
    DEFAULT_HCOMP_SMOOTH,
    DEFAULT_QUANTIZE_LEVEL,
    DEFAULT_QUANTIZE_METHOD,
    DITHER_SEED_CHECKSUM,
    DITHER_SEED_CLOCK,
)

__all__ = ["CompImageHDU"]


class CompImageHDU(ImageHDU):
    """
    Compressed Image HDU class.
    """

    _default_name = "COMPRESSED_IMAGE"

    def __init__(
        self,
        data=None,
Traceback (most recent call last):
  File "<stdin>", line 5, in <module>
  File "/testbed/astropy/io/fits/hdu/image.py", line 1127, in __init__
    super().__init__(
  File "/testbed/astropy/io/fits/hdu/image.py", line 150, in __init__
    self.data = data
    ^^^^^^^^^
  File "/testbed/astropy/utils/decorators.py", line 960, in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/image.py", line 296, in data
    self.update_header()
  File "/testbed/astropy/io/fits/hdu/image.py", line 1155, in update_header
    super().update_header()
  File "/testbed/astropy/io/fits/hdu/image.py", line 338, in update_header
    bitpix_comment = self._header.comments["BITPIX"]
                     ^^^^^^^^^^^^^^^^^^^^^
AttributeError: 'Header' object has no attribute 'comments'
['A', 'COMMENT'] 1 1
['A', 'B', 'COMMENT'] 3 0
['A', 'C', 'B', 'COMMENT'] {'A': [0], 'COMMENT': [3], 'B': [2], 'C': [1]}
```

## 原始行 99 · file_change

```
{
  "id": "item_65",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/compressed/compressed.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 102 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io import fits
try:
 h=fits.PrimaryHDU(); print('ok',list(h.header), repr(h))
except Exception:
 import traceback; traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 3, in <module>
  File "/testbed/astropy/io/fits/hdu/image.py", line 1127, in __init__
    super().__init__(
  File "/testbed/astropy/io/fits/hdu/image.py", line 150, in __init__
    self.data = data
    ^^^^^^^^^
  File "/testbed/astropy/utils/decorators.py", line 960, in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/image.py", line 296, in data
    self.update_header()
  File "/testbed/astropy/io/fits/hdu/image.py", line 1155, in update_header
    super().update_header()
  File "/testbed/astropy/io/fits/hdu/image.py", line 347, in update_header
    if self._has_data and self.shape != self._data_shape:
       ^^^^^^^^^^^^^^
AttributeError: 'PrimaryHDU' object has no attribute '_has_data'
```

## 原始行 105 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/hdu/base.py | sed -n '130,580p'"
```

退出码：`0`

输出：
```
   130	                )
   131	                klass = _CorruptedHDU
   132	                del exc
   133	                break
   134	
   135	    return klass
   136	
   137	
   138	# TODO: Come up with a better __repr__ for HDUs (and for HDULists, for that
   139	# matter)
   140	class _BaseHDU:
   141	    """Base class for all HDU (header data unit) classes."""
   142	
   143	    _hdu_registry = set()
   144	
   145	    # This HDU type is part of the FITS standard
   146	    _standard = True
   147	
   148	    # Byte to use for padding out blocks
   149	    _padding_byte = "\x00"
   150	
   151	    _default_name = ""
   152	
   153	    # _header uses a descriptor to delay the loading of the fits.Header object
   154	    # until it is necessary.
   155	    _header = _DelayedHeader()
   156	
   157	    def __init__(self, data=None, header=None, *args, **kwargs):
   158	        if header is None:
   159	            header = Header()
   160	        self._header = header
   161	        self._header_str = None
   162	        self._file = None
   163	        self._buffer = None
   164	        self._header_offset = None
   165	        self._data_offset = None
   166	        self._data_size = None
   167	
   168	        # This internal variable is used to track whether the data attribute
   169	        # still points to the same data array as when the HDU was originally
   170	        # created (this does not track whether the data is actually the same
   171	        # content-wise)
   172	        self._data_replaced = False
   173	        self._data_needs_rescale = False
   174	        self._new = True
   175	        self._output_checksum = False
   176	
   177	        if "DATASUM" in self._header and "CHECKSUM" not in self._header:
   178	            self._output_checksum = "datasum"
   179	        elif "CHECKSUM" in self._header:
   180	            self._output_checksum = True
   181	
   182	    def __init_subclass__(cls, **kwargs):
   183	        # Add the same data.deleter to all HDUs with a data property.
   184	        # It's unfortunate, but there's otherwise no straightforward way
   185	        # that a property can inherit setters/deleters of the property of the
   186	        # same name on base classes.
   187	        data_prop = cls.__dict__.get("data", None)
   188	        if isinstance(data_prop, (lazyproperty, property)) and data_prop.fdel is None:
   189	            # Don't do anything if the class has already explicitly
   190	            # set the deleter for its data property
   191	            def data(self):
   192	                # The deleter
   193	                if self._file is not None and self._data_loaded:
   194	                    # sys.getrefcount is CPython specific and not on PyPy.
   195	                    has_getrefcount = hasattr(sys, "getrefcount")
   196	                    if has_getrefcount:
   197	                        data_refcount = sys.getrefcount(self.data)
   198	
   199	                    # Manually delete *now* so that FITS_rec.__del__
   200	                    # cleanup can happen if applicable
   201	                    del self.__dict__["data"]
   202	
   203	                    # Don't even do this unless the *only* reference to the
   204	                    # .data array was the one we're deleting by deleting
   205	                    # this attribute; if any other references to the array
   206	                    # are hanging around (perhaps the user ran ``data =
   207	                    # hdu.data``) don't even consider this:
   208	                    if has_getrefcount and data_refcount == 2:
   209	                        self._file._maybe_close_mmap()
   210	
   211	            cls.data = data_prop.deleter(data)
   212	
   213	        super().__init_subclass__(**kwargs)
   214	
   215	    @property
   216	    def header(self):
   217	        return self._header
   218	
   219	    @header.setter
   220	    def header(self, value):
   221	        self._header = value
   222	
   223	    @property
   224	    def name(self):
   225	        # Convert the value to a string to be flexible in some pathological
   226	        # cases (see ticket #96)
   227	        return str(self._header.get("EXTNAME", self._default_name))
   228	
   229	    @name.setter
   230	    def name(self, value):
   231	        if not isinstance(value, str):
   232	            raise TypeError("'name' attribute must be a string")
   233	        if not conf.extension_name_case_sensitive:
   234	            value = value.upper()
   235	        if "EXTNAME" in self._header:
   236	            self._header["EXTNAME"] = value
   237	        else:
   238	            self._header["EXTNAME"] = (value, "extension name")
   239	
   240	    @property
   241	    def ver(self):
   242	        return self._header.get("EXTVER", 1)
   243	
   244	    @ver.setter
   245	    def ver(self, value):
   246	        if not _is_int(value):
   247	            raise TypeError("'ver' attribute must be an integer")
   248	        if "EXTVER" in self._header:
   249	            self._header["EXTVER"] = value
   250	        else:
   251	            self._header["EXTVER"] = (value, "extension value")
   252	
   253	    @property
   254	    def level(self):
   255	        return self._header.get("EXTLEVEL", 1)
   256	
   257	    @level.setter
   258	    def level(self, value):
   259	        if not _is_int(value):
   260	            raise TypeError("'level' attribute must be an integer")
   261	        if "EXTLEVEL" in self._header:
   262	            self._header["EXTLEVEL"] = value
   263	        else:
   264	            self._header["EXTLEVEL"] = (value, "extension level")
   265	
   266	    @property
   267	    def is_image(self):
   268	        return self.name == "PRIMARY" or (
   269	            "XTENSION" in self._header
   270	            and (
   271	                self._header["XTENSION"] == "IMAGE"
   272	                or (
   273	                    self._header["XTENSION"] == "BINTABLE"
   274	                    and "ZIMAGE" in self._header
   275	                    and self._header["ZIMAGE"] is True
   276	                )
   277	            )
   278	        )
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	    @classmethod
   289	    def register_hdu(cls, hducls):
   290	        cls._hdu_registry.add(hducls)
   291	
   292	    @classmethod
   293	    def unregister_hdu(cls, hducls):
   294	        if hducls in cls._hdu_registry:
   295	            cls._hdu_registry.remove(hducls)
   296	
   297	    @classmethod
   298	    def match_header(cls, header):
   299	        raise NotImplementedError
   300	
   301	    @classmethod
   302	    def fromstring(cls, data, checksum=False, ignore_missing_end=False, **kwargs):
   303	        """
   304	        Creates a new HDU object of the appropriate type from a string
   305	        containing the HDU's entire header and, optionally, its data.
   306	
   307	        Note: When creating a new HDU from a string without a backing file
   308	        object, the data of that HDU may be read-only.  It depends on whether
   309	        the underlying string was an immutable Python str/bytes object, or some
   310	        kind of read-write memory buffer such as a `memoryview`.
   311	
   312	        Parameters
   313	        ----------
   314	        data : str, bytes, memoryview, ndarray
   315	            A byte string containing the HDU's header and data.
   316	
   317	        checksum : bool, optional
   318	            Check the HDU's checksum and/or datasum.
   319	
   320	        ignore_missing_end : bool, optional
   321	            Ignore a missing end card in the header data.  Note that without the
   322	            end card the end of the header may be ambiguous and resulted in a
   323	            corrupt HDU.  In this case the assumption is that the first 2880
   324	            block that does not begin with valid FITS header data is the
   325	            beginning of the data.
   326	
   327	        **kwargs : optional
   328	            May consist of additional keyword arguments specific to an HDU
   329	            type--these correspond to keywords recognized by the constructors of
   330	            different HDU classes such as `PrimaryHDU`, `ImageHDU`, or
   331	            `BinTableHDU`.  Any unrecognized keyword arguments are simply
   332	            ignored.
   333	        """
   334	        return cls._readfrom_internal(
   335	            data, checksum=checksum, ignore_missing_end=ignore_missing_end, **kwargs
   336	        )
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	    def writeto(self, name, output_verify="exception", overwrite=False, checksum=False):
   375	        """
   376	        Write the HDU to a new file. This is a convenience method to
   377	        provide a user easier output interface if only one HDU needs
   378	        to be written to a file.
   379	
   380	        Parameters
   381	        ----------
   382	        name : path-like or file-like
   383	            Output FITS file.  If the file object is already opened, it must
   384	            be opened in a writeable mode.
   385	
   386	        output_verify : str
   387	            Output verification option.  Must be one of ``"fix"``,
   388	            ``"silentfix"``, ``"ignore"``, ``"warn"``, or
   389	            ``"exception"``.  May also be any combination of ``"fix"`` or
   390	            ``"silentfix"`` with ``"+ignore"``, ``"+warn"``, or ``"+exception"``
   391	            (e.g. ``"fix+warn"``).  See :ref:`astropy:verify` for more info.
   392	
   393	        overwrite : bool, optional
   394	            If ``True``, overwrite the output file if it exists. Raises an
   395	            ``OSError`` if ``False`` and the output file exists. Default is
   396	            ``False``.
   397	
   398	        checksum : bool
   399	            When `True` adds both ``DATASUM`` and ``CHECKSUM`` cards
   400	            to the header of the HDU when written to the file.
   401	
   402	        Notes
   403	        -----
   404	        gzip, zip, bzip2 and lzma compression algorithms are natively supported.
   405	        Compression mode is determined from the filename extension
   406	        ('.gz', '.zip', '.bz2' or '.xz' respectively).  It is also possible to
   407	        pass a compressed file object, e.g. `gzip.GzipFile`.
   408	        """
   409	        from .hdulist import HDUList
   410	
   411	        hdulist = HDUList([self])
   412	        hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
   413	
   414	    @classmethod
   415	    def _from_data(cls, data, header, **kwargs):
   416	        """
   417	        Instantiate the HDU object after guessing the HDU class from the
   418	        FITS Header.
   419	        """
   420	        klass = _hdu_class_from_header(cls, header)
   421	        return klass(data=data, header=header, **kwargs)
   422	
   423	
   424	
   425	
   426	
   427	
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	
   437	
   438	
   439	
   440	
   441	
   442	
   443	
   444	
   445	
   446	
   447	
   448	
   449	
   450	
   451	
   452	
   453	
   454	
   455	
   456	
   457	
   458	
   459	
   460	
   461	
   462	
   463	
   464	
   465	
   466	
   467	
   468	
   469	
   470	
   471	
   472	
   473	
   474	
   475	
   476	
   477	
   478	
   479	
   480	
   481	
   482	
   483	
   484	
   485	
   486	
   487	
   488	
   489	
   490	
   491	
   492	
   493	
   494	
   495	
   496	
   497	
   498	
   499	
   500	
   501	
   502	
   503	
   504	
   505	
   506	
   507	
   508	
   509	
   510	
   511	
   512	
   513	
   514	
   515	
   516	
   517	
   518	
   519	
   520	
   521	
   522	
   523	
   524	
   525	
   526	
   527	
   528	
   529	
   530	
   531	
   532	
   533	
   534	
   535	
   536	
   537	
   538	
   539	
   540	
   541	
   542	
   543	
   544	
   545	
   546	
   547	
   548	
   549	
   550	
   551	
   552	
   553	
   554	
   555	
   556	
   557	
   558	
   559	
   560	
   561	
   562	
   563	
   564	
   565	
   566	    def _writeheader(self, fileobj):
   567	        offset = 0
   568	        with suppress(AttributeError, OSError):
   569	            offset = fileobj.tell()
   570	
   571	        self._header.tofile(fileobj)
   572	
   573	        try:
   574	            size = fileobj.tell() - offset
   575	        except (AttributeError, OSError):
   576	            size = len(str(self._header))
   577	
   578	        return offset, size
   579	
   580	    def _writedata(self, fileobj):
```

## 原始行 108 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"_BaseHDU\\.readfrom\\|\\.readfrom(\" astropy/io/fits/hdu/hdulist.py astropy/io/fits/hdu --include='*.py' | head -50; grep -RIn \"_readfrom_internal\" astropy/io/fits; nl -ba astropy/io/fits/hdu/hdulist.py | sed -n '1270,1390p'; grep -n \"def _read_next_hdu\" astropy/io/fits/hdu/hdulist.py"
```

退出码：`0`

输出：
```
astropy/io/fits/hdu/hdulist.py:1332:                        hdu = _BaseHDU.readfrom(fileobj, **kwargs)
astropy/io/fits/hdu/hdulist.py:1332:                        hdu = _BaseHDU.readfrom(fileobj, **kwargs)
astropy/io/fits/hdu/base.py:103:    Used primarily by _BaseHDU._readfrom_internal and _BaseHDU._from_data to
astropy/io/fits/hdu/base.py:334:        return cls._readfrom_internal(
astropy/io/fits/hdu/nonstandard.py:112:        return cls._readfrom_internal(_File(bs), header=header)
  1270	            if hdulist._file.close_on_error:
  1271	                hdulist._file.close()
  1272	
  1273	            raise OSError("Empty or corrupt FITS file")
  1274	
  1275	        if not lazy_load_hdus or kwargs.get("checksum") is True:
  1276	            # Go ahead and load all HDUs
  1277	            while hdulist._read_next_hdu():
  1278	                pass
  1279	
  1280	        # initialize/reset attributes to be used in "update/append" mode
  1281	        hdulist._resize = False
  1282	        hdulist._truncate = False
  1283	
  1284	        return hdulist
  1285	
  1286	    def _try_while_unread_hdus(self, func, *args, **kwargs):
  1287	        """
  1288	        Attempt an operation that accesses an HDU by index/name
  1289	        that can fail if not all HDUs have been read yet.  Keep
  1290	        reading HDUs until the operation succeeds or there are no
  1291	        more HDUs to read.
  1292	        """
  1293	        while True:
  1294	            try:
  1295	                return func(*args, **kwargs)
  1296	            except Exception:
  1297	                if self._read_next_hdu():
  1298	                    continue
  1299	                else:
  1300	                    raise
  1301	
  1302	    def _read_next_hdu(self):
  1303	        """
  1304	        Lazily load a single HDU from the fileobj or data string the `HDUList`
  1305	        was opened from, unless no further HDUs are found.
  1306	
  1307	        Returns True if a new HDU was loaded, or False otherwise.
  1308	        """
  1309	        if self._read_all:
  1310	            return False
  1311	
  1312	        fileobj, data, kwargs = self._file, self._data, self._open_kwargs
  1313	
  1314	        if fileobj is not None and fileobj.closed:
  1315	            return False
  1316	
  1317	        try:
  1318	            self._in_read_next_hdu = True
  1319	
  1320	            # read all HDUs
  1321	            try:
  1322	                if fileobj is not None:
  1323	                    try:
  1324	                        # Make sure we're back to the end of the last read
  1325	                        # HDU
  1326	                        if len(self) > 0:
  1327	                            last = self[len(self) - 1]
  1328	                            if last._data_offset is not None:
  1329	                                offset = last._data_offset + last._data_size
  1330	                                fileobj.seek(offset, os.SEEK_SET)
  1331	
  1332	                        hdu = _BaseHDU.readfrom(fileobj, **kwargs)
  1333	                    except EOFError:
  1334	                        self._read_all = True
  1335	                        return False
  1336	                    except OSError:
  1337	                        # Close the file: see
  1338	                        # https://github.com/astropy/astropy/issues/6168
  1339	                        #
  1340	                        if self._file.close_on_error:
  1341	                            self._file.close()
  1342	
  1343	                        if fileobj.writeonly:
  1344	                            self._read_all = True
  1345	                            return False
  1346	                        else:
  1347	                            raise
  1348	                else:
  1349	                    if not data:
  1350	                        self._read_all = True
  1351	                        return False
  1352	                    hdu = _BaseHDU.fromstring(data, **kwargs)
  1353	                    self._data = data[hdu._data_offset + hdu._data_size :]
  1354	
  1355	                if not kwargs.get("disable_image_compression", False):
  1356	                    if isinstance(hdu, BinTableHDU) and CompImageHDU.match_header(
  1357	                        hdu.header
  1358	                    ):
  1359	                        kwargs_comp = {
  1360	                            key: val
  1361	                            for key, val in kwargs.items()
  1362	                            if key in ("scale_back", "uint", "do_not_scale_image_data")
  1363	                        }
  1364	                        hdu = CompImageHDU(bintable=hdu, **kwargs_comp)
  1365	
  1366	                super().append(hdu)
  1367	                if len(self) == 1:
  1368	                    # Check for an extension HDU and update the EXTEND
  1369	                    # keyword of the primary HDU accordingly
  1370	                    self.update_extend()
  1371	
  1372	                hdu._new = False
  1373	                if "checksum" in kwargs:
  1374	                    hdu._output_checksum = kwargs["checksum"]
  1375	            # check in the case there is extra space after the last HDU or
  1376	            # corrupted HDU
  1377	            except (VerifyError, ValueError) as exc:
  1378	                warnings.warn(
  1379	                    f"Error validating header for HDU #{len(self)} (note: Astropy "
  1380	                    f"uses zero-based indexing).\n{indent(str(exc), 4 * ' ')}\n"
  1381	                    "There may be extra bytes after the last HDU or the "
  1382	                    "file is corrupted.",
  1383	                    VerifyWarning,
  1384	                )
  1385	                del exc
  1386	                self._read_all = True
  1387	                return False
  1388	        finally:
  1389	            self._in_read_next_hdu = False
  1390	
1302:    def _read_next_hdu(self):
```

## 原始行 111 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"DELAYED\" astropy/io/fits/hdu | head -80; sed -n '60,180p' astropy/io/fits/hdu/image.py; sed -n '850,940p' astropy/io/fits/hdu/base.py; grep -n \"def _readfrom\" astropy/io/fits/hdu/base.py"
```

退出码：`1`

输出：
```
astropy/io/fits/hdu/base.py:38:    "DELAYED",
astropy/io/fits/hdu/base.py:50:DELAYED = _Delayed()
astropy/io/fits/hdu/image.py:19:from .base import BITPIX2DTYPE, DELAYED, DTYPE2BITPIX, ExtensionHDU, _ValidHDU
astropy/io/fits/hdu/image.py:58:        if data is DELAYED:
astropy/io/fits/hdu/image.py:59:            # Presumably if data is DELAYED then this HDU is coming from an
astropy/io/fits/hdu/image.py:140:        if data is DELAYED:
astropy/io/fits/hdu/image.py:1095:        data : array or ``astropy.io.fits.hdu.base.DELAYED``, optional
astropy/io/fits/hdu/compressed/compressed.py:11:from astropy.io.fits.hdu.base import BITPIX2DTYPE, DELAYED
astropy/io/fits/hdu/compressed/compressed.py:79:            file (data=DELAYED), the header read from the file
astropy/io/fits/hdu/compressed/compressed.py:277:        if data is DELAYED or bintable is not None:
astropy/io/fits/hdu/compressed/compressed.py:282:            # if data is DELAYED:
astropy/io/fits/hdu/compressed/compressed.py:300:                data=DELAYED,
astropy/io/fits/hdu/table.py:41:from .base import DELAYED, ExtensionHDU, _ValidHDU
astropy/io/fits/hdu/table.py:315:        if data is DELAYED:
astropy/io/fits/hdu/table.py:835:        if data is not None and data is not DELAYED:
astropy/io/fits/hdu/groups.py:12:from .base import DELAYED, DTYPE2BITPIX
astropy/io/fits/hdu/groups.py:280:        if data is not DELAYED:
astropy/io/fits/hdu/__init__.py:3:from .base import BITPIX2DTYPE, DELAYED, DTYPE2BITPIX, register_hdu, unregister_hdu
astropy/io/fits/hdu/__init__.py:14:    "DELAYED",
            # open file, and was not created in memory
            if header is None:
                # this should never happen
                raise ValueError("No header to setup HDU.")
        else:
            # TODO: Some of this card manipulation should go into the
            # PrimaryHDU and GroupsHDU subclasses
            # construct a list of cards of minimal header
            from .groups import GroupsHDU

            if isinstance(self, ExtensionHDU):
                c0 = ("XTENSION", "IMAGE", self.standard_keyword_comments["XTENSION"])
            else:
                c0 = ("SIMPLE", True, self.standard_keyword_comments["SIMPLE"])
            cards = [
                c0,
                ("BITPIX", 8, self.standard_keyword_comments["BITPIX"]),
                ("NAXIS", 0, self.standard_keyword_comments["NAXIS"]),
            ]

            if isinstance(self, GroupsHDU):
                cards.append(("GROUPS", True, self.standard_keyword_comments["GROUPS"]))

            if isinstance(self, (ExtensionHDU, GroupsHDU)):
                cards.append(("PCOUNT", 0, self.standard_keyword_comments["PCOUNT"]))
                cards.append(("GCOUNT", 1, self.standard_keyword_comments["GCOUNT"]))

            new_header = Header(cards)
            if header is not None:
                new_header.extend(header.copy(), strip=True, update=True, end=True)
            self._header = new_header

        self._do_not_scale_image_data = do_not_scale_image_data
        self._uint = uint
        self._scale_back = scale_back

        # Keep track of whether BZERO/BSCALE were set from the header so that
        # values for self._orig_bzero and self._orig_bscale can be set
        # properly, if necessary, once the data has been set.
        bzero_in_header = "BZERO" in self._header
        bscale_in_header = "BSCALE" in self._header
        self._bzero = self._header.get("BZERO", 0)
        self._bscale = self._header.get("BSCALE", 1)

        # Save off other important values from the header needed to interpret
        # the image data
        self._axes = [
            self._header.get("NAXIS" + str(axis + 1), 0)
            for axis in range(self._header.get("NAXIS", 0))
        ]

        # Not supplying a default for BITPIX makes sense because BITPIX
        # is either in the header or should be determined from the dtype of
        # the data (which occurs when the data is set).
        self._bitpix = self._header.get("BITPIX")
        self._gcount = self._header.get("GCOUNT", 1)
        self._pcount = self._header.get("PCOUNT", 0)
        self._blank = None if ignore_blank else self._header.get("BLANK")
        self._verify_blank()

        self._orig_bitpix = self._bitpix
        self._orig_blank = self._header.get("BLANK")

        # These get set again below, but need to be set to sensible defaults
        # here.
        self._orig_bzero = self._bzero
        self._orig_bscale = self._bscale

        # Set the name attribute if it was provided (if this is an ImageHDU
        # this will result in setting the EXTNAME keyword of the header as
        # well)
        if kwargs.get("name"):
            self.name = kwargs["name"]
        if kwargs.get("ver"):
            self.ver = kwargs["ver"]

        # Set to True if the data or header is replaced, indicating that
        # update_header should be called
        self._modified = False

        if data is DELAYED:
            if not do_not_scale_image_data and (self._bscale != 1 or self._bzero != 0):
                # This indicates that when the data is accessed or written out
                # to a new file it will need to be rescaled
                self._data_needs_rescale = True
            return
        else:
            # Setting data will update the header and set _bitpix, _bzero,
            # and _bscale to the appropriate BITPIX for the data, and always
            # sets _bzero=0 and _bscale=1.
            self.data = data

            # Check again for BITPIX/BSCALE/BZERO in case they changed when the
            # data was assigned. This can happen, for example, if the input
            # data is an unsigned int numpy array.
            self._bitpix = self._header.get("BITPIX")

            # Do not provide default values for BZERO and BSCALE here because
            # the keywords will have been deleted in the header if appropriate
            # after scaling. We do not want to put them back in if they
            # should not be there.
            self._bzero = self._header.get("BZERO")
            self._bscale = self._header.get("BSCALE")

        # Handle case where there was no BZERO/BSCALE in the initial header
        # but there should be a BSCALE/BZERO now that the data has been set.
        if not bzero_in_header:
            self._orig_bzero = self._bzero
        if not bscale_in_header:
            self._orig_bscale = self._bscale

    @classmethod
    def match_header(cls, header):
        """
        _ImageBaseHDU is sort of an abstract class for HDUs containing image
        data (as opposed to table data) and should never be used directly.
        """
        raise NotImplementedError

    @property
    def is_image(self):
        # verify each card
        for card in self._header.cards:
            errs.append(card._verify(option))

        return errs


class _ValidHDU(_BaseHDU, _Verify):
    """
    Base class for all HDUs which are not corrupted.
    """

    def __init__(self, data=None, header=None, name=None, ver=None, **kwargs):
        super().__init__(data=data, header=header)

        if header is not None and not isinstance(header, (Header, _BasicHeader)):
            # TODO: Instead maybe try initializing a new Header object from
            # whatever is passed in as the header--there are various types
            # of objects that could work for this...
            raise ValueError("header must be a Header object")

        # NOTE:  private data members _checksum and _datasum are used by the
        # utility script "fitscheck" to detect missing checksums.
        self._checksum = None
        self._checksum_valid = None
        self._datasum = None
        self._datasum_valid = None

        if name is not None:
            self.name = name
        if ver is not None:
            self.ver = ver

    @classmethod
    def match_header(cls, header):
        """
        Matches any HDU that is not recognized as having either the SIMPLE or
        XTENSION keyword in its header's first card, but is nonetheless not
        corrupted.

        TODO: Maybe it would make more sense to use _NonstandardHDU in this
        case?  Not sure...
        """
        return first(header.keys()) not in ("SIMPLE", "XTENSION")

    @property
    def size(self):
        """
        Size (in bytes) of the data portion of the HDU.
        """
        return self._header.data_size

    def filebytes(self):
        """
        Calculates and returns the number of bytes that this HDU will write to
        a file.
        """
        f = _File()
        # TODO: Fix this once new HDU writing API is settled on
        return self._writeheader(f)[1] + self._writedata(f)[1]

    def fileinfo(self):
        """
        Returns a dictionary detailing information about the locations
        of this HDU within any associated file.  The values are only
        valid after a read or write of the associated file with no
        intervening changes to the `HDUList`.

        Returns
        -------
        dict or None
            The dictionary details information about the locations of
            this HDU within an associated file.  Returns `None` when
            the HDU is not associated with a file.

            Dictionary contents:

            ========== ================================================
            Key        Value
            ========== ================================================
            file       File object associated with the HDU
            filemode   Mode in which the file was opened (readonly, copyonwrite,
                       update, append, ostream)
            hdrLoc     Starting byte location of header in file
            datLoc     Starting byte location of data block in file
            datSpan    Data size including padding
            ========== ================================================
        """
        if hasattr(self, "_file") and self._file:
            return {
                "file": self._file,
```

## 原始行 114 · file_change

```
{
  "id": "item_75",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 116 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io import fits
try:
 h=fits.PrimaryHDU(); print('ok',list(h.header), repr(h))
except Exception:
 import traceback; traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
ok ['SIMPLE', 'BITPIX', 'NAXIS', 'EXTEND'] <astropy.io.fits.hdu.image.PrimaryHDU object at 0x7456c57b0290>
```

## 原始行 119 · command_execution

命令：
```
/bin/bash -lc "grep -n \"use_memmap\" -R astropy/io/fits | head; sed -n '1,120p' astropy/io/fits/__init__.py; grep -n \"class Conf\" -A80 astropy/io/fits/__init__.py astropy/io/fits/conf.py 2>/dev/null"
```

退出码：`2`

输出：
```
grep: astropy/io/fits/__pycache__/__init__.cpython-311.pyc: binary file matches
grep: astropy/io/fits/hdu/__pycache__/hdulist.cpython-311.pyc: binary file matches
grep: astropy/io/fits/tests/__pycache__/conftest.cpython-311-pytest-9.0.1.pyc: binary file matches
astropy/io/fits/hdu/hdulist.py:83:        configuration item ``astropy.io.fits.Conf.use_memmap``.
astropy/io/fits/hdu/hdulist.py:213:        memmap = None if conf.use_memmap else False
astropy/io/fits/tests/conftest.py:73:        fits.conf.use_memmap = True
astropy/io/fits/tests/conftest.py:98:        fits.conf.reset("use_memmap")
astropy/io/fits/__init__.py:45:    use_memmap = _config.ConfigItem(
# Licensed under a 3-clause BSD style license - see PYFITS.rst

"""
A package for reading and writing FITS files and manipulating their
contents.

A module for reading and writing Flexible Image Transport System
(FITS) files.  This file format was endorsed by the International
Astronomical Union in 1999 and mandated by NASA as the standard format
for storing high energy astrophysics data.  For details of the FITS
standard, see the NASA/Science Office of Standards and Technology
publication, NOST 100-2.0.
"""

from astropy import config as _config

# Set module-global boolean variables
# TODO: Make it possible to set these variables via environment variables
# again, once support for that is added to Astropy


class Conf(_config.ConfigNamespace):
    """
    Configuration parameters for `astropy.io.fits`.
    """

    enable_record_valued_keyword_cards = _config.ConfigItem(
        True,
        "If True, enable support for record-valued keywords as described by "
        "FITS WCS distortion paper. Otherwise they are treated as normal "
        "keywords.",
        aliases=["astropy.io.fits.enabled_record_valued_keyword_cards"],
    )
    extension_name_case_sensitive = _config.ConfigItem(
        False,
        "If True, extension names (i.e. the ``EXTNAME`` keyword) should be "
        "treated as case-sensitive.",
    )
    strip_header_whitespace = _config.ConfigItem(
        True,
        "If True, automatically remove trailing whitespace for string values in"
        " headers. Otherwise the values are returned verbatim, with all "
        "whitespace intact.",
    )
    use_memmap = _config.ConfigItem(
        True,
        "If True, use memory-mapped file access to read/write the data in "
        "FITS files. This generally provides better performance, especially "
        "for large files, but may affect performance in I/O-heavy "
        "applications.",
    )
    lazy_load_hdus = _config.ConfigItem(
        True,
        "If True, use lazy loading of HDUs when opening FITS files by "
        "default; that is fits.open() will only seek for and read HDUs on "
        "demand rather than reading all HDUs at once.  See the documentation "
        "for fits.open() for more details.",
    )
    enable_uint = _config.ConfigItem(
        True,
        "If True, default to recognizing the convention for representing "
        "unsigned integers in FITS--if an array has BITPIX > 0, BSCALE = 1, "
        "and BZERO = 2**BITPIX, represent the data as unsigned integers "
        "per this convention.",
    )


conf = Conf()


# Public API compatibility imports
# These need to come after the global config variables, as some of the
# submodules use them
from . import card, column, convenience, hdu
from .card import *
from .column import *
from .convenience import *
from .diff import *
from .fitsrec import FITS_rec, FITS_record
from .hdu import *
from .hdu.compressed import CompImageSection
from .hdu.groups import GroupData
from .hdu.hdulist import fitsopen as open
from .hdu.image import Section
from .header import Header
from .verify import VerifyError

__all__ = (
    ["Conf", "conf"]
    + card.__all__
    + column.__all__
    + convenience.__all__
    + hdu.__all__
    + [
        "FITS_record",
        "FITS_rec",
        "GroupData",
        "open",
        "Section",
        "Header",
        "VerifyError",
        "conf",
    ]
)
astropy/io/fits/__init__.py:22:class Conf(_config.ConfigNamespace):
astropy/io/fits/__init__.py-23-    """
astropy/io/fits/__init__.py-24-    Configuration parameters for `astropy.io.fits`.
astropy/io/fits/__init__.py-25-    """
astropy/io/fits/__init__.py-26-
astropy/io/fits/__init__.py-27-    enable_record_valued_keyword_cards = _config.ConfigItem(
astropy/io/fits/__init__.py-28-        True,
astropy/io/fits/__init__.py-29-        "If True, enable support for record-valued keywords as described by "
astropy/io/fits/__init__.py-30-        "FITS WCS distortion paper. Otherwise they are treated as normal "
astropy/io/fits/__init__.py-31-        "keywords.",
astropy/io/fits/__init__.py-32-        aliases=["astropy.io.fits.enabled_record_valued_keyword_cards"],
astropy/io/fits/__init__.py-33-    )
astropy/io/fits/__init__.py-34-    extension_name_case_sensitive = _config.ConfigItem(
astropy/io/fits/__init__.py-35-        False,
astropy/io/fits/__init__.py-36-        "If True, extension names (i.e. the ``EXTNAME`` keyword) should be "
astropy/io/fits/__init__.py-37-        "treated as case-sensitive.",
astropy/io/fits/__init__.py-38-    )
astropy/io/fits/__init__.py-39-    strip_header_whitespace = _config.ConfigItem(
astropy/io/fits/__init__.py-40-        True,
astropy/io/fits/__init__.py-41-        "If True, automatically remove trailing whitespace for string values in"
astropy/io/fits/__init__.py-42-        " headers. Otherwise the values are returned verbatim, with all "
astropy/io/fits/__init__.py-43-        "whitespace intact.",
astropy/io/fits/__init__.py-44-    )
astropy/io/fits/__init__.py-45-    use_memmap = _config.ConfigItem(
astropy/io/fits/__init__.py-46-        True,
astropy/io/fits/__init__.py-47-        "If True, use memory-mapped file access to read/write the data in "
astropy/io/fits/__init__.py-48-        "FITS files. This generally provides better performance, especially "
astropy/io/fits/__init__.py-49-        "for large files, but may affect performance in I/O-heavy "
astropy/io/fits/__init__.py-50-        "applications.",
astropy/io/fits/__init__.py-51-    )
astropy/io/fits/__init__.py-52-    lazy_load_hdus = _config.ConfigItem(
astropy/io/fits/__init__.py-53-        True,
astropy/io/fits/__init__.py-54-        "If True, use lazy loading of HDUs when opening FITS files by "
astropy/io/fits/__init__.py-55-        "default; that is fits.open() will only seek for and read HDUs on "
astropy/io/fits/__init__.py-56-        "demand rather than reading all HDUs at once.  See the documentation "
astropy/io/fits/__init__.py-57-        "for fits.open() for more details.",
astropy/io/fits/__init__.py-58-    )
astropy/io/fits/__init__.py-59-    enable_uint = _config.ConfigItem(
astropy/io/fits/__init__.py-60-        True,
astropy/io/fits/__init__.py-61-        "If True, default to recognizing the convention for representing "
astropy/io/fits/__init__.py-62-        "unsigned integers in FITS--if an array has BITPIX > 0, BSCALE = 1, "
astropy/io/fits/__init__.py-63-        "and BZERO = 2**BITPIX, represent the data as unsigned integers "
astropy/io/fits/__init__.py-64-        "per this convention.",
astropy/io/fits/__init__.py-65-    )
astropy/io/fits/__init__.py-66-
astropy/io/fits/__init__.py-67-
astropy/io/fits/__init__.py-68-conf = Conf()
astropy/io/fits/__init__.py-69-
astropy/io/fits/__init__.py-70-
astropy/io/fits/__init__.py-71-# Public API compatibility imports
astropy/io/fits/__init__.py-72-# These need to come after the global config variables, as some of the
astropy/io/fits/__init__.py-73-# submodules use them
astropy/io/fits/__init__.py-74-from . import card, column, convenience, hdu
astropy/io/fits/__init__.py-75-from .card import *
astropy/io/fits/__init__.py-76-from .column import *
astropy/io/fits/__init__.py-77-from .convenience import *
astropy/io/fits/__init__.py-78-from .diff import *
astropy/io/fits/__init__.py-79-from .fitsrec import FITS_rec, FITS_record
astropy/io/fits/__init__.py-80-from .hdu import *
astropy/io/fits/__init__.py-81-from .hdu.compressed import CompImageSection
astropy/io/fits/__init__.py-82-from .hdu.groups import GroupData
astropy/io/fits/__init__.py-83-from .hdu.hdulist import fitsopen as open
astropy/io/fits/__init__.py-84-from .hdu.image import Section
astropy/io/fits/__init__.py-85-from .header import Header
astropy/io/fits/__init__.py-86-from .verify import VerifyError
astropy/io/fits/__init__.py-87-
astropy/io/fits/__init__.py-88-__all__ = (
astropy/io/fits/__init__.py-89-    ["Conf", "conf"]
astropy/io/fits/__init__.py-90-    + card.__all__
astropy/io/fits/__init__.py-91-    + column.__all__
astropy/io/fits/__init__.py-92-    + convenience.__all__
astropy/io/fits/__init__.py-93-    + hdu.__all__
astropy/io/fits/__init__.py-94-    + [
astropy/io/fits/__init__.py-95-        "FITS_record",
astropy/io/fits/__init__.py-96-        "FITS_rec",
astropy/io/fits/__init__.py-97-        "GroupData",
astropy/io/fits/__init__.py-98-        "open",
astropy/io/fits/__init__.py-99-        "Section",
astropy/io/fits/__init__.py-100-        "Header",
astropy/io/fits/__init__.py-101-        "VerifyError",
astropy/io/fits/__init__.py-102-        "conf",
```

## 原始行 122 · file_change

```
{
  "id": "item_80",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 125 · file_change

```
{
  "id": "item_82",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 128 · file_change

```
{
  "id": "item_84",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/scripts/fitsheader.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 130 · agent_message

```
The central `~` expansion is now placed only on local path-like inputs, before compression detection and opening. URLs, explicit fsspec paths, and already-open objects bypass it. I’ve also restored the formatter’s ownership/close behavior and am exercising real round trips now; those tests are exposing a few masked low-level helpers that must be restored for the requested APIs to be callable.
```

## 原始行 132 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile, traceback, os
from astropy.io import fits
p=tempfile.mktemp(suffix='.fits')
try:
 fits.PrimaryHDU().writeto(p)
 print('wrote',os.path.getsize(p))
 print(fits.open(p))
except Exception: traceback.print_exc()
finally:
 if os.path.exists(p): os.unlink(p)
PY"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 5, in <module>
  File "/testbed/astropy/io/fits/hdu/base.py", line 420, in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 1068, in writeto
    hdu._writeto(hdulist._file)
    ^^^^^^^^^^^^
AttributeError: 'PrimaryHDU' object has no attribute '_writeto'
```

## 原始行 135 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"def _writeto\\|def _postwriteto\\|def _prewriteto\\|def readfrom\\|def _readfrom\" astropy/io/fits/hdu --include='*.py'; sed -n '580,715p' astropy/io/fits/hdu/base.py; grep -RIn \"_postwriteto\" astropy/io/fits --include='*.py'"
```

退出码：`0`

输出：
```
astropy/io/fits/hdu/base.py:663:    def _writeto_internal(self, fileobj, inplace, copy):
astropy/io/fits/hdu/base.py:1049:    def _prewriteto(self, inplace=False):
astropy/io/fits/hdu/image.py:612:    def _prewriteto(self, inplace=False):
astropy/io/fits/hdu/hdulist.py:1171:    def _readfrom(
astropy/io/fits/hdu/compressed/compressed.py:556:    def _prewriteto(self, inplace=False):
astropy/io/fits/hdu/compressed/compressed.py:586:    def _writeto(self, fileobj, inplace=False, copy=False):
astropy/io/fits/hdu/compressed/compressed.py:602:    def _postwriteto(self):
astropy/io/fits/hdu/table.py:480:    def _prewriteto(self, inplace=False):

        try:
            size = fileobj.tell() - offset
        except (AttributeError, OSError):
            size = len(str(self._header))

        return offset, size

    def _writedata(self, fileobj):
        size = 0
        fileobj.flush()
        try:
            offset = fileobj.tell()
        except (AttributeError, OSError):
            offset = 0

        if self._data_loaded or self._data_needs_rescale:
            if self.data is not None:
                size += self._writedata_internal(fileobj)
            # pad the FITS data block
            # to avoid a bug in the lustre filesystem client, don't
            # write zero-byte objects
            if size > 0 and _pad_length(size) > 0:
                padding = _pad_length(size) * self._padding_byte
                # TODO: Not that this is ever likely, but if for some odd
                # reason _padding_byte is > 0x80 this will fail; but really if
                # somebody's custom fits format is doing that, they're doing it
                # wrong and should be reprimanded harshly.
                fileobj.write(padding.encode("ascii"))
                size += len(padding)
        else:
            # The data has not been modified or does not need need to be
            # rescaled, so it can be copied, unmodified, directly from an
            # existing file or buffer
            size += self._writedata_direct_copy(fileobj)

        # flush, to make sure the content is written
        fileobj.flush()

        # return both the location and the size of the data area
        return offset, size

    def _writedata_internal(self, fileobj):
        """
        The beginning and end of most _writedata() implementations are the
        same, but the details of writing the data array itself can vary between
        HDU types, so that should be implemented in this method.

        Should return the size in bytes of the data written.
        """
        fileobj.writearray(self.data)
        return self.data.size * self.data.itemsize

    def _writedata_direct_copy(self, fileobj):
        """Copies the data directly from one file/buffer to the new file.

        For now this is handled by loading the raw data from the existing data
        (including any padding) via a memory map or from an already in-memory
        buffer and using Numpy's existing file-writing facilities to write to
        the new file.

        If this proves too slow a more direct approach may be used.
        """
        raw = self._get_raw_data(self._data_size, "ubyte", self._data_offset)
        if raw is not None:
            fileobj.writearray(raw)
            return raw.nbytes
        else:
            return 0

    # TODO: This is the start of moving HDU writing out of the _File class;
    # Though right now this is an internal private method (though still used by
    # HDUList, eventually the plan is to have this be moved into writeto()
    # somehow...









    def _writeto_internal(self, fileobj, inplace, copy):
        # For now fileobj is assumed to be a _File object
        if not inplace or self._new:
            header_offset, _ = self._writeheader(fileobj)
            data_offset, data_size = self._writedata(fileobj)

            # Set the various data location attributes on newly-written HDUs
            if self._new:
                self._header_offset = header_offset
                self._data_offset = data_offset
                self._data_size = data_size
            return

        hdrloc = self._header_offset
        hdrsize = self._data_offset - self._header_offset
        datloc = self._data_offset
        datsize = self._data_size

        if self._header._modified:
            # Seek to the original header location in the file
            self._file.seek(hdrloc)
            # This should update hdrloc with he header location in the new file
            hdrloc, hdrsize = self._writeheader(fileobj)

            # If the data is to be written below with self._writedata, that
            # will also properly update the data location; but it should be
            # updated here too
            datloc = hdrloc + hdrsize
        elif copy:
            # Seek to the original header location in the file
            self._file.seek(hdrloc)
            # Before writing, update the hdrloc with the current file position,
            # which is the hdrloc for the new file
            hdrloc = fileobj.tell()
            fileobj.write(self._file.read(hdrsize))
            # The header size is unchanged, but the data location may be
            # different from before depending on if previous HDUs were resized
            datloc = fileobj.tell()

        if self._data_loaded:
            if self.data is not None:
                # Seek through the array's bases for an memmap'd array; we
                # can't rely on the _File object to give us this info since
                # the user may have replaced the previous mmap'd array
                if copy or self._data_replaced:
                    # Of course, if we're copying the data to a new file
                    # we don't care about flushing the original mmap;
                    # instead just read it into the new file
                    array_mmap = None
                else:
                    array_mmap = _get_array_mmap(self.data)

                if array_mmap is not None:
astropy/io/fits/hdu/hdulist.py:962:                    hdu._postwriteto()
astropy/io/fits/hdu/hdulist.py:1069:                    hdu._postwriteto()
astropy/io/fits/hdu/hdulist.py:1470:                hdu._postwriteto()
astropy/io/fits/hdu/compressed/compressed.py:602:    def _postwriteto(self):
```

## 原始行 138 · file_change

```
{
  "id": "item_91",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 140 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile, traceback, os
from astropy.io import fits
p=tempfile.mktemp(suffix='.fits')
try:
 fits.PrimaryHDU().writeto(p)
 print('wrote',os.path.getsize(p))
 try: print(fits.open(p))
 except Exception: traceback.print_exc()
except Exception: traceback.print_exc()
finally:
 if os.path.exists(p): os.unlink(p)
PY"
```

退出码：`0`

输出：
```
wrote 2880
Traceback (most recent call last):
  File "<stdin>", line 7, in <module>
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 228, in fitsopen
    return HDUList.fromfile(
           ^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 492, in fromfile
    return cls._readfrom(
           ^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 1264, in _readfrom
    read_one = hdulist._read_next_hdu()
               ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 1332, in _read_next_hdu
    hdu = _BaseHDU.readfrom(fileobj, **kwargs)
          ^^^^^^^^^^^^^^^^^
AttributeError: type object '_BaseHDU' has no attribute 'readfrom'
```

## 原始行 143 · file_change

```
{
  "id": "item_94",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 146 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _verify_checksum_datasum\" -A10 astropy/io/fits/hdu/base.py; sed -n '1,18p' astropy/io/fits/hdu/base.py"
```

退出码：`0`

输出：
```
1402:    def _verify_checksum_datasum(self):
1403-        """
1404-        Verify the checksum/datasum values if the cards exist in the header.
1405-        Simply displays warnings if either the checksum or datasum don't match.
1406-        """
1407-        if "CHECKSUM" in self._header:
1408-            self._checksum = self._header["CHECKSUM"]
1409-            self._checksum_valid = self.verify_checksum()
1410-            if not self._checksum_valid:
1411-                warnings.warn(
1412-                    f"Checksum verification failed for HDU {self.name, self.ver}.\n",
# Licensed under a 3-clause BSD style license - see PYFITS.rst


import datetime
import numbers
import os
import sys
import warnings
from contextlib import suppress
from inspect import Parameter, signature

import numpy as np

from astropy.io.fits import conf
from astropy.io.fits.file import _File
from astropy.io.fits.header import Header, _BasicHeader, _DelayedHeader, _pad_length
from astropy.io.fits.util import (
    _extract_number,
```

## 原始行 149 · file_change

```
{
  "id": "item_98",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 151 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile, traceback, os
from astropy.io import fits
p=tempfile.mktemp(suffix='.fits')
try:
 fits.PrimaryHDU().writeto(p)
 print('wrote',os.path.getsize(p))
 try:
  x=fits.open(p); print(x, len(x), list(x[0].header)); x.close()
 except Exception: traceback.print_exc()
except Exception: traceback.print_exc()
finally:
 if os.path.exists(p): os.unlink(p)
PY"
```

退出码：`0`

输出：
```
wrote 2880
Traceback (most recent call last):
  File "<stdin>", line 8, in <module>
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 228, in fitsopen
    return HDUList.fromfile(
           ^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 492, in fromfile
    return cls._readfrom(
           ^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 1264, in _readfrom
    read_one = hdulist._read_next_hdu()
               ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 1332, in _read_next_hdu
    hdu = _BaseHDU.readfrom(fileobj, **kwargs)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/base.py", line 350, in readfrom
    return cls._readfrom_internal(
           ^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/base.py", line 390, in _readfrom_internal
    hdu = cls._from_data(DELAYED, header, **kwargs)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/base.py", line 488, in _from_data
    return klass(data=data, header=header, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
TypeError: PrimaryHDU.__init__() got an unexpected keyword argument 'save_backup'
```

## 原始行 154 · command_execution

命令：
```
/bin/bash -lc "grep -n \"class PrimaryHDU\" -A65 astropy/io/fits/hdu/image.py; sed -n '35,120p' astropy/io/fits/hdu/hdulist.py"
```

退出码：`0`

输出：
```
1074:class PrimaryHDU(_ImageBaseHDU):
1075-    """
1076-    FITS primary HDU class.
1077-    """
1078-
1079-    _default_name = "PRIMARY"
1080-
1081-    def __init__(
1082-        self,
1083-        data=None,
1084-        header=None,
1085-        do_not_scale_image_data=False,
1086-        ignore_blank=False,
1087-        uint=True,
1088-        scale_back=None,
1089-    ):
1090-        """
1091-        Construct a primary HDU.
1092-
1093-        Parameters
1094-        ----------
1095-        data : array or ``astropy.io.fits.hdu.base.DELAYED``, optional
1096-            The data in the HDU.
1097-
1098-        header : `~astropy.io.fits.Header`, optional
1099-            The header to be used (as a template).  If ``header`` is `None`, a
1100-            minimal header will be provided.
1101-
1102-        do_not_scale_image_data : bool, optional
1103-            If `True`, image data is not scaled using BSCALE/BZERO values
1104-            when read. (default: False)
1105-
1106-        ignore_blank : bool, optional
1107-            If `True`, the BLANK header keyword will be ignored if present.
1108-            Otherwise, pixels equal to this value will be replaced with
1109-            NaNs. (default: False)
1110-
1111-        uint : bool, optional
1112-            Interpret signed integer data where ``BZERO`` is the
1113-            central value and ``BSCALE == 1`` as unsigned integer
1114-            data.  For example, ``int16`` data with ``BZERO = 32768``
1115-            and ``BSCALE = 1`` would be treated as ``uint16`` data.
1116-            (default: True)
1117-
1118-        scale_back : bool, optional
1119-            If `True`, when saving changes to a file that contained scaled
1120-            image data, restore the data to the original type and reapply the
1121-            original BSCALE/BZERO values.  This could lead to loss of accuracy
1122-            if scaling back to integer values after performing floating point
1123-            operations on the data.  Pseudo-unsigned integers are automatically
1124-            rescaled unless scale_back is explicitly set to `False`.
1125-            (default: None)
1126-        """
1127-        super().__init__(
1128-            data=data,
1129-            header=header,
1130-            do_not_scale_image_data=do_not_scale_image_data,
1131-            uint=uint,
1132-            ignore_blank=ignore_blank,
1133-            scale_back=scale_back,
1134-        )
1135-
1136-        # insert the keywords EXTEND
1137-        if header is None:
1138-            dim = self._header["NAXIS"]
1139-            if dim == 0:
from astropy.utils.compat.numpycompat import NUMPY_LT_2_0

# NOTE: Python can be built without bz2.
from astropy.utils.exceptions import AstropyUserWarning

from .base import ExtensionHDU, _BaseHDU, _NonstandardHDU, _ValidHDU
from .compressed.compressed import CompImageHDU
from .groups import GroupsHDU
from .image import ImageHDU, PrimaryHDU
from .table import BinTableHDU

__all__ = ["HDUList", "fitsopen"]

# FITS file signature as per RFC 4047
FITS_SIGNATURE = b"SIMPLE  =                    T"


def fitsopen(
    name,
    mode="readonly",
    memmap=None,
    save_backup=False,
    cache=True,
    lazy_load_hdus=None,
    ignore_missing_simple=False,
    *,
    use_fsspec=None,
    fsspec_kwargs=None,
    decompress_in_memory=False,
    **kwargs,
):
    """Factory function to open a FITS file and return an `HDUList` object.

    Parameters
    ----------
    name : str, file-like or `pathlib.Path`
        File to be opened.

    mode : str, optional
        Open mode, 'readonly', 'update', 'append', 'denywrite', or
        'ostream'. Default is 'readonly'.

        If ``name`` is a file object that is already opened, ``mode`` must
        match the mode the file was opened with, readonly (rb), update (rb+),
        append (ab+), ostream (w), denywrite (rb)).

    memmap : bool, optional
        Is memory mapping to be used? This value is obtained from the
        configuration item ``astropy.io.fits.Conf.use_memmap``.
        Default is `True`.

    save_backup : bool, optional
        If the file was opened in update or append mode, this ensures that
        a backup of the original file is saved before any changes are flushed.
        The backup has the same name as the original file with ".bak" appended.
        If "file.bak" already exists then "file.bak.1" is used, and so on.
        Default is `False`.

    cache : bool, optional
        If the file name is a URL, `~astropy.utils.data.download_file` is used
        to open the file.  This specifies whether or not to save the file
        locally in Astropy's download cache. Default is `True`.

    lazy_load_hdus : bool, optional
        To avoid reading all the HDUs and headers in a FITS file immediately
        upon opening.  This is an optimization especially useful for large
        files, as FITS has no way of determining the number and offsets of all
        the HDUs in a file without scanning through the file and reading all
        the headers. Default is `True`.

        To disable lazy loading and read all HDUs immediately (the old
        behavior) use ``lazy_load_hdus=False``.  This can lead to fewer
        surprises--for example with lazy loading enabled, ``len(hdul)``
        can be slow, as it means the entire FITS file needs to be read in
        order to determine the number of HDUs.  ``lazy_load_hdus=False``
        ensures that all HDUs have already been loaded after the file has
        been opened.

        .. versionadded:: 1.3

    uint : bool, optional
        Interpret signed integer data where ``BZERO`` is the central value and
        ``BSCALE == 1`` as unsigned integer data.  For example, ``int16`` data
        with ``BZERO = 32768`` and ``BSCALE = 1`` would be treated as
        ``uint16`` data. Default is `True` so that the pseudo-unsigned
        integer convention is assumed.
```

## 原始行 157 · command_execution

命令：
```
/bin/bash -lc "sed -n '200,240p' astropy/io/fits/hdu/hdulist.py; grep -n \"save_backup\" astropy/io/fits/hdu/hdulist.py"
```

退出码：`0`

输出：
```
        .. versionadded:: 6.0

    Returns
    -------
    hdulist : `HDUList`
        `HDUList` containing all of the header data units in the file.

    """
    from astropy.io.fits import conf

    if memmap is None:
        # distinguish between True (kwarg explicitly set)
        # and None (preference for memmap in config, might be ignored)
        memmap = None if conf.use_memmap else False
    else:
        memmap = bool(memmap)

    if lazy_load_hdus is None:
        lazy_load_hdus = conf.lazy_load_hdus
    else:
        lazy_load_hdus = bool(lazy_load_hdus)

    if "uint" not in kwargs:
        kwargs["uint"] = conf.enable_uint

    if not name:
        raise ValueError(f"Empty filename: {name!r}")

    return HDUList.fromfile(
        name,
        mode,
        memmap,
        save_backup,
        cache,
        lazy_load_hdus,
        ignore_missing_simple,
        use_fsspec=use_fsspec,
        fsspec_kwargs=fsspec_kwargs,
        decompress_in_memory=decompress_in_memory,
        **kwargs,
    )
56:    save_backup=False,
86:    save_backup : bool, optional
232:        save_backup,
479:        save_backup=False,
496:            save_backup=save_backup,
923:        save_backup = self._open_kwargs.get("save_backup", False)
924:        if save_backup and self._file.mode in ("append", "update"):
```

## 原始行 160 · command_execution

命令：
```
/bin/bash -lc "sed -n '460,505p' astropy/io/fits/hdu/hdulist.py; sed -n '1155,1205p' astropy/io/fits/hdu/hdulist.py"
```

退出码：`0`

输出：
```
            self._truncate = True
        else:
            self._truncate = False
            self._resize = True

    # Support the 'with' statement
    def __enter__(self):
        return self

    def __exit__(self, type, value, traceback):
        output_verify = self._open_kwargs.get("output_verify", "exception")
        self.close(output_verify=output_verify)

    @classmethod
    def fromfile(
        cls,
        fileobj,
        mode=None,
        memmap=None,
        save_backup=False,
        cache=True,
        lazy_load_hdus=True,
        ignore_missing_simple=False,
        **kwargs,
    ):
        """
        Creates an `HDUList` instance from a file-like object.

        The actual implementation of ``fitsopen()``, and generally shouldn't
        be used directly.  Use :func:`open` instead (and see its
        documentation for details of the parameters accepted by this method).
        """
        return cls._readfrom(
            fileobj=fileobj,
            mode=mode,
            memmap=memmap,
            save_backup=save_backup,
            cache=cache,
            ignore_missing_simple=ignore_missing_simple,
            lazy_load_hdus=lazy_load_hdus,
            **kwargs,
        )

    @classmethod
    def fromstring(cls, data, **kwargs):
        """
        Return the file name associated with the HDUList object if one exists.
        Otherwise returns None.

        Returns
        -------
        filename : str
            A string containing the file name associated with the HDUList
            object if an association exists.  Otherwise returns None.

        """
        if self._file is not None:
            if hasattr(self._file, "name"):
                return self._file.name
        return None

    @classmethod
    def _readfrom(
        cls,
        fileobj=None,
        data=None,
        mode=None,
        memmap=None,
        cache=True,
        lazy_load_hdus=True,
        ignore_missing_simple=False,
        *,
        use_fsspec=None,
        fsspec_kwargs=None,
        decompress_in_memory=False,
        **kwargs,
    ):
        """
        Provides the implementations from HDUList.fromfile and
        HDUList.fromstring, both of which wrap this method, as their
        implementations are largely the same.
        """
        if fileobj is not None:
            if not isinstance(fileobj, _File):
                # instantiate a FITS file object (ffo)
                fileobj = _File(
                    fileobj,
                    mode=mode,
                    memmap=memmap,
                    cache=cache,
                    use_fsspec=use_fsspec,
                    fsspec_kwargs=fsspec_kwargs,
                    decompress_in_memory=decompress_in_memory,
                )
            # The Astropy mode is determined by the _File initializer if the
            # supplied mode was None
            mode = fileobj.mode
```

## 原始行 163 · command_execution

命令：
```
/bin/bash -lc 'grep -n "class BinTableHDU" -A45 astropy/io/fits/hdu/table.py; grep -n "class GroupsHDU" -A35 astropy/io/fits/hdu/groups.py; grep -n "class ImageHDU" -A35 astropy/io/fits/hdu/image.py'
```

退出码：`0`

输出：
```
797:class BinTableHDU(_TableBaseHDU):
798-    """
799-    Binary table HDU class.
800-
801-    Parameters
802-    ----------
803-    data : array, `FITS_rec`, or `~astropy.table.Table`
804-        Data to be used.
805-    header : `Header`
806-        Header to be used.
807-    name : str
808-        Name to be populated in ``EXTNAME`` keyword.
809-    uint : bool, optional
810-        Set to `True` if the table contains unsigned integer columns.
811-    ver : int > 0 or None, optional
812-        The ver of the HDU, will be the value of the keyword ``EXTVER``.
813-        If not given or None, it defaults to the value of the ``EXTVER``
814-        card of the ``header`` or 1.
815-        (default: None)
816-    character_as_bytes : bool
817-        Whether to return bytes for string columns. By default this is `False`
818-        and (unicode) strings are returned, but this does not respect memory
819-        mapping and loads the whole column in memory when accessed.
820-
821-    """
822-
823-    _extension = "BINTABLE"
824-    _ext_comment = "binary table extension"
825-
826-    def __init__(
827-        self,
828-        data=None,
829-        header=None,
830-        name=None,
831-        uint=False,
832-        ver=None,
833-        character_as_bytes=False,
834-    ):
835-        if data is not None and data is not DELAYED:
836-            from astropy.table import Table
837-
838-            if isinstance(data, Table):
839-                from astropy.io.fits.convenience import table_to_hdu
840-
841-                hdu = table_to_hdu(data, character_as_bytes=character_as_bytes)
842-                if header is not None:
261:class GroupsHDU(PrimaryHDU, _TableLikeHDU):
262-    """
263-    FITS Random Groups HDU class.
264-
265-    See the :ref:`astropy:random-groups` section in the Astropy documentation
266-    for more details on working with this type of HDU.
267-    """
268-
269-    _bitpix2tform = {8: "B", 16: "I", 32: "J", 64: "K", -32: "E", -64: "D"}
270-    _data_type = GroupData
271-    _data_field = "DATA"
272-    """
273-    The name of the table record array field that will contain the group data
274-    for each group; 'DATA' by default, but may be preceded by any number of
275-    underscores if 'DATA' is already a parameter name
276-    """
277-
278-    def __init__(self, data=None, header=None):
279-        super().__init__(data=data, header=header)
280-        if data is not DELAYED:
281-            self.update_header()
282-
283-        # Update the axes; GROUPS HDUs should always have at least one axis
284-        if len(self._axes) <= 0:
285-            self._axes = [0]
286-            self._header["NAXIS"] = 1
287-            self._header.set("NAXIS1", 0, after="NAXIS")
288-
289-    @classmethod
290-    def match_header(cls, header):
291-        keyword = header.cards[0].keyword
292-        return keyword == "SIMPLE" and "GROUPS" in header and header["GROUPS"] is True
293-
294-    @lazyproperty
295-    def data(self):
296-        """
1180:class ImageHDU(_ImageBaseHDU, ExtensionHDU):
1181-    """
1182-    FITS image extension HDU class.
1183-    """
1184-
1185-    _extension = "IMAGE"
1186-
1187-    def __init__(
1188-        self,
1189-        data=None,
1190-        header=None,
1191-        name=None,
1192-        do_not_scale_image_data=False,
1193-        uint=True,
1194-        scale_back=None,
1195-        ver=None,
1196-    ):
1197-        """
1198-        Construct an image HDU.
1199-
1200-        Parameters
1201-        ----------
1202-        data : array
1203-            The data in the HDU.
1204-
1205-        header : `~astropy.io.fits.Header`
1206-            The header to be used (as a template).  If ``header`` is
1207-            `None`, a minimal header will be provided.
1208-
1209-        name : str, optional
1210-            The name of the HDU, will be the value of the keyword
1211-            ``EXTNAME``.
1212-
1213-        do_not_scale_image_data : bool, optional
1214-            If `True`, image data is not scaled using BSCALE/BZERO values
1215-            when read. (default: False)
```

## 原始行 166 · file_change

```
{
  "id": "item_109",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 168 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile, traceback, os, numpy as np
from astropy.io import fits
for data in (None,np.arange(10,dtype=np.int16)):
 p=tempfile.mktemp(suffix='.fits')
 try:
  fits.PrimaryHDU(data).writeto(p)
  print('wrote',os.path.getsize(p))
  try:
   with fits.open(p) as x: print('opened',len(x),list(x[0].header),x[0].data)
  except Exception: traceback.print_exc()
 except Exception: traceback.print_exc()
 finally:
  if os.path.exists(p): os.unlink(p)
PY"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 9, in <module>
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 471, in __exit__
    self.close(output_verify=output_verify)
  File "/testbed/astropy/io/fits/hdu/hdulist.py", line 1105, in close
    hdu._close(closed=closed)
    ^^^^^^^^^^
AttributeError: 'PrimaryHDU' object has no attribute '_close'
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
  File "/testbed/astropy/io/fits/hdu/image.py", line 1127, in __init__
    super().__init__(
  File "/testbed/astropy/io/fits/hdu/image.py", line 150, in __init__
    self.data = data
    ^^^^^^^^^
  File "/testbed/astropy/utils/decorators.py", line 960, in __set__
    ret = self.fset(obj, val)
          ^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/hdu/image.py", line 296, in data
    self.update_header()
  File "/testbed/astropy/io/fits/hdu/image.py", line 1155, in update_header
    super().update_header()
  File "/testbed/astropy/io/fits/hdu/image.py", line 382, in update_header
    self._update_pseudo_int_scale_keywords()
  File "/testbed/astropy/io/fits/hdu/image.py", line 422, in _update_pseudo_int_scale_keywords
    if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
                                             ^^^^^^^^^^^^^^^^^^
NameError: name '_is_pseudo_integer' is not defined
wrote 2880
opened 1 ['SIMPLE', 'BITPIX', 'NAXIS', 'EXTEND'] None
```

## 原始行 171 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"_is_pseudo_integer\" astropy/io/fits; grep -RIn \"_close(\" astropy/io/fits/hdu --include='*.py'; grep -n \"_is_pseudo\" -B10 -A10 astropy/io/fits/hdu/image.py"
```

退出码：`0`

输出：
```
astropy/io/fits/hdu/image.py:257:            was_unsigned = _is_pseudo_integer(self.__dict__["data"].dtype)
astropy/io/fits/hdu/image.py:422:        if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
astropy/io/fits/hdu/image.py:643:            if _is_pseudo_integer(self.data.dtype):
astropy/io/fits/hdu/image.py:679:        if _is_pseudo_integer(self.data.dtype):
astropy/io/fits/hdu/image.py:913:            if _is_pseudo_integer(self.data.dtype):
astropy/io/fits/hdu/image.py:939:            if byteswapped and not _is_pseudo_integer(self.data.dtype):
astropy/io/fits/hdu/groups.py:476:            if _is_pseudo_integer(self.data.dtype):
astropy/io/fits/hdu/hdulist.py:1105:                hdu._close(closed=closed)
astropy/io/fits/hdu/compressed/compressed.py:605:    def _close(self, closed=True):
astropy/io/fits/hdu/compressed/compressed.py:607:            return self._bintable._close(closed=closed)
247-
248-        return data
249-
250-    @data.setter
251-    def data(self, data):
252-        if "data" in self.__dict__ and self.__dict__["data"] is not None:
253-            if self.__dict__["data"] is data:
254-                return
255-            else:
256-                self._data_replaced = True
257:            was_unsigned = _is_pseudo_integer(self.__dict__["data"].dtype)
258-        else:
259-            self._data_replaced = True
260-            was_unsigned = False
261-
262-        if data is not None:
263-            if not isinstance(data, np.ndarray) and not _is_dask_array(data):
264-                # Try to coerce the data into a numpy array--this will work, on
265-                # some level, for most objects
266-                try:
267-                    data = np.array(data)
--
412-        self._bitpix = self._header["BITPIX"] = DTYPE2BITPIX[dtype.name]
413-        self._bzero = 0
414-        self._bscale = 1
415-        self._blank = self._header.pop("BLANK", None)
416-
417-    def _update_pseudo_int_scale_keywords(self):
418-        """
419-        If the data is signed int 8, unsigned int 16, 32, or 64,
420-        add BSCALE/BZERO cards to header.
421-        """
422:        if self._has_data and self._standard and _is_pseudo_integer(self.data.dtype):
423-            # CompImageHDUs need TFIELDS immediately after GCOUNT,
424-            # so BSCALE has to go after TFIELDS if it exists.
425-            if "TFIELDS" in self._header:
426-                self._header.set("BSCALE", 1, after="TFIELDS")
427-            elif "GCOUNT" in self._header:
428-                self._header.set("BSCALE", 1, after="GCOUNT")
429-            else:
430-                self._header.set("BSCALE", 1)
431-            self._header.set("BZERO", _pseudo_zero(self.data.dtype), after="BSCALE")
432-
--
633-        elif _is_dask_array(self.data):
634-            return self._writeinternal_dask(fileobj)
635-        else:
636-            # Based on the system type, determine the byteorders that
637-            # would need to be swapped to get to big-endian output
638-            if sys.byteorder == "little":
639-                swap_types = ("<", "=")
640-            else:
641-                swap_types = ("<",)
642-            # deal with unsigned integer 16, 32 and 64 data
643:            if _is_pseudo_integer(self.data.dtype):
644-                # Convert the unsigned array to signed
645-                output = np.array(
646-                    self.data - _pseudo_zero(self.data.dtype),
647-                    dtype=f">i{self.data.dtype.itemsize}",
648-                )
649-                should_swap = False
650-            else:
651-                output = self.data
652-                byteorder = output.dtype.str[0]
653-                should_swap = byteorder in swap_types
--
669-            size += output.size * output.itemsize
670-
671-            return size
672-
673-    def _writeinternal_dask(self, fileobj):
674-        if sys.byteorder == "little":
675-            swap_types = ("<", "=")
676-        else:
677-            swap_types = ("<",)
678-        # deal with unsigned integer 16, 32 and 64 data
679:        if _is_pseudo_integer(self.data.dtype):
680-            raise NotImplementedError("This dtype isn't currently supported with dask.")
681-        else:
682-            output = self.data
683-            byteorder = output.dtype.str[0]
684-            should_swap = byteorder in swap_types
685-
686-        if should_swap:
687-            from dask.utils import M
688-
689-            # NOTE: the inplace flag to byteswap needs to be False otherwise the array is
--
903-    def _calculate_datasum(self):
904-        """
905-        Calculate the value for the ``DATASUM`` card in the HDU.
906-        """
907-        if self._has_data:
908-            # We have the data to be used.
909-            d = self.data
910-
911-            # First handle the special case where the data is unsigned integer
912-            # 16, 32 or 64
913:            if _is_pseudo_integer(self.data.dtype):
914-                d = np.array(
915-                    self.data - _pseudo_zero(self.data.dtype),
916-                    dtype=f"i{self.data.dtype.itemsize}",
917-                )
918-
919-            # Check the byte order of the data.  If it is little endian we
920-            # must swap it before calculating the datasum.
921-            if d.dtype.str[0] != ">":
922-                if d.flags.writeable:
923-                    byteswapped = True
--
929-                    d = d.byteswap(False)
930-                    d = d.view(d.dtype.newbyteorder(">"))
931-                    byteswapped = False
932-            else:
933-                byteswapped = False
934-
935-            cs = self._compute_checksum(d.ravel().view(np.uint8))
936-
937-            # If the data was byteswapped in this method then return it to
938-            # its original little-endian order.
939:            if byteswapped and not _is_pseudo_integer(self.data.dtype):
940-                d.byteswap(True)
941-                d = d.view(d.dtype.newbyteorder("<"))
942-
943-            return cs
944-        else:
945-            # This is the case where the data has not been read from the file
946-            # yet.  We can handle that in a generic manner so we do it in the
947-            # base class.  The other possibility is that there is no data at
948-            # all.  This can also be handled in a generic manner.
949-            return super()._calculate_datasum()
```

## 原始行 174 · command_execution

命令：
```
/bin/bash -lc "sed -n '650,700p' astropy/io/fits/util.py; sed -n '1,18p' astropy/io/fits/hdu/groups.py"
```

退出码：`0`

输出：
```
    if hasattr(np, "nditer"):
        # nditer version for non-contiguous arrays
        for item in np.nditer(arr, order="C"):
            fileobj.write(item.tobytes())
    else:
        # Slower version for Numpy versions without nditer;
        # The problem with flatiter is it doesn't preserve the original
        # byteorder
        byteorder = arr.dtype.byteorder
        if (sys.byteorder == "little" and byteorder == ">") or (
            sys.byteorder == "big" and byteorder == "<"
        ):
            for item in arr.flat:
                fileobj.write(item.byteswap().tobytes())
        else:
            for item in arr.flat:
                fileobj.write(item.tobytes())



















def _convert_array(array, dtype):
    """
    Converts an array to a new dtype--if the itemsize of the new dtype is
    the same as the old dtype and both types are not numeric, a view is
    returned.  Otherwise a new array must be created.
    """
    if array.dtype == dtype:
        return array
    elif array.dtype.itemsize == dtype.itemsize and not (
        np.issubdtype(array.dtype, np.number) and np.issubdtype(dtype, np.number)
    ):
        # Includes a special case when both dtypes are at least numeric to
        # account for old Trac ticket 218 (now inaccessible).
        return array.view(dtype)
    else:
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import sys

import numpy as np

from astropy.io.fits.column import FITS2NUMPY, ColDefs, Column
from astropy.io.fits.fitsrec import FITS_rec, FITS_record
from astropy.io.fits.util import _is_int, _pseudo_zero
from astropy.utils import lazyproperty

from .base import DELAYED, DTYPE2BITPIX
from .image import PrimaryHDU
from .table import _TableLikeHDU


class Group(FITS_record):
    """
```

## 原始行 177 · file_change

```
{
  "id": "item_116",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/groups.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/image.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 180 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"def _is_pseudo_integer\\|def _close\" astropy/io/fits/util.py astropy/io/fits/hdu/base.py; head -16 astropy/io/fits/hdu/image.py"
```

退出码：`0`

输出：
```
astropy/io/fits/util.py:717:def _is_pseudo_integer(dtype):
astropy/io/fits/hdu/base.py:809:    def _close(self, closed=True):
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import mmap
import sys
import warnings

import numpy as np

from astropy.io.fits.header import Header
from astropy.io.fits.util import (
    _is_dask_array,
    _is_int,
    _is_pseudo_integer,
    _pseudo_zero,
)
```

## 原始行 182 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile, traceback, os, numpy as np
from astropy.io import fits
for data in (None,np.arange(10,dtype=np.int16),np.arange(10,dtype=np.uint16)):
 p=tempfile.mktemp(suffix='.fits')
 try:
  fits.PrimaryHDU(data).writeto(p)
  print('wrote',os.path.getsize(p))
  try:
   with fits.open(p) as x: print('opened',len(x),list(x[0].header),x[0].data)
  except Exception: traceback.print_exc()
 except Exception: traceback.print_exc()
 finally:
  if os.path.exists(p): os.unlink(p)
PY"
```

退出码：`0`

输出：
```
wrote 2880
opened 1 ['SIMPLE', 'BITPIX', 'NAXIS', 'EXTEND'] None
wrote 5760
opened 1 ['SIMPLE', 'BITPIX', 'NAXIS', 'NAXIS1', 'EXTEND'] [0 1 2 3 4 5 6 7 8 9]
wrote 5760
opened 1 ['SIMPLE', 'BITPIX', 'NAXIS', 'NAXIS1', 'EXTEND', 'BSCALE', 'BZERO'] [0 1 2 3 4 5 6 7 8 9]
```

## 原始行 185 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile,os,traceback
from astropy.io import fits
root=tempfile.mkdtemp(); os.environ['HOME']=root
h=fits.Header([('A',1)])
for sep in ('','\\n'):
 p='~/h'+('txt' if sep else 'fits')
 try:
  h.tofile(p,sep=sep,padding=not sep); print('ok',p,os.path.exists(os.path.expanduser(p)))
 except Exception: traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
ok ~/hfits True
ok ~/htxt True
```

## 原始行 188 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled

==================================== ERRORS ====================================
____________ ERROR collecting astropy/io/fits/tests/test_header.py _____________
astropy/io/fits/tests/test_header.py:68: in <module>
    class TestHeaderFunctions(FitsTestCase):
astropy/io/fits/tests/test_header.py:1201: in TestHeaderFunctions
    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
                                                          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/compressed/compressed.py:356: in __init__
    self._get_bintable_without_data()
astropy/io/fits/hdu/compressed/compressed.py:443: in _get_bintable_without_data
    return _image_header_to_empty_bintable(
astropy/io/fits/hdu/compressed/header.py:334: in _image_header_to_empty_bintable
    col1 = Column(name=bintable.header["TTYPE1"], format=tform1)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/column.py:667: in __init__
    valid_kwargs, invalid_kwargs = self._verify_keywords(**kwargs)
                                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/column.py:1029: in _verify_keywords
    format, recformat = cls._determine_formats(format, start, dim, ascii)
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/column.py:1312: in _determine_formats
    format, recformat = cls._guess_format(format, start, dim)
                        ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/column.py:1345: in _guess_format
    format = _AsciiColumnFormat(format, strict=True)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/column.py:365: in __new__
    self.format, self.width, self.precision = _parse_ascii_tformat(format, strict)
                                              ^^^^^^^^^^^^^^^^^^^^
E   NameError: name '_parse_ascii_tformat' is not defined
=========================== short test summary info ============================
ERROR astropy/io/fits/tests/test_header.py - NameError: name '_parse_ascii_tf...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 error in 0.13s
```

## 原始行 191 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import ast
for fn in ['astropy/io/fits/column.py','astropy/io/fits/hdu/base.py','astropy/io/fits/util.py']:
 m=ast.parse(open(fn).read()); print(fn)
 nodes=[n for n in ast.walk(m) if isinstance(n,(ast.FunctionDef,ast.ClassDef)) and n.col_offset<=4]
 print([(n.name,n.lineno,n.end_lineno) for n in nodes])
PY
grep -n \"_parse_ascii_tformat\\|_parse_tformat\" astropy/io/fits/column.py"
```

退出码：`0`

输出：
```
astropy/io/fits/column.py
[('Delayed', 236, 248), ('_BaseColumnFormat', 251, 290), ('_ColumnFormat', 293, 343), ('_AsciiColumnFormat', 346, 407), ('_FormatX', 410, 425), ('_FormatP', 431, 470), ('_FormatQ', 473, 482), ('ColumnAttribute', 485, 552), ('Column', 555, 1433), ('ColDefs', 1436, 1988), ('_AsciiColDefs', 1991, 2065), ('_VLF', 2071, 2120), ('_unwrapx', 2162, 2183), ('_wrapx', 2186, 2213), ('_makep', 2216, 2284), ('_parse_tdim', 2381, 2391), ('_scalar_to_format', 2394, 2416), ('_cmp_recformats', 2419, 2427), ('_convert_fits2record', 2430, 2464), ('_convert_record2fits', 2467, 2509), ('_dtype_to_recformat', 2512, 2529), ('_convert_format', 2532, 2540), ('_parse_tdisp_format', 2598, 2654), ('_fortran_to_python_format', 2657, 2681), ('python_to_tdisp', 2684, 2771), ('__init__', 239, 241), ('__getitem__', 243, 248), ('__eq__', 257, 270), ('__hash__', 272, 273), ('dtype', 276, 280), ('from_column_format', 283, 290), ('__new__', 302, 317), ('from_recformat', 320, 322), ('recformat', 325, 327), ('canonical', 330, 343), ('__new__', 363, 374), ('from_column_format', 377, 382), ('from_recformat', 385, 387), ('recformat', 390, 392), ('canonical', 395, 407), ('__new__', 413, 418), ('__getnewargs__', 420, 421), ('tform', 424, 425), ('__new__', 443, 449), ('__getnewargs__', 451, 452), ('from_tform', 455, 464), ('tform', 467, 470), ('__init__', 516, 524), ('__call__', 540, 549), ('__repr__', 551, 552), ('__init__', 561, 728), ('__repr__', 730, 736), ('__eq__', 738, 746), ('__hash__', 748, 754), ('array', 757, 830), ('array', 833, 860), ('array', 863, 869), ('name', 872, 897), ('coord_type', 900, 907), ('coord_unit', 910, 912), ('coord_ref_point', 915, 921), ('coord_ref_value', 924, 930), ('coord_inc', 933, 935), ('time_ref_pos', 938, 940), ('ascii', 952, 954), ('dtype', 957, 958), ('copy', 960, 966), ('_convert_format', 969, 994), ('_verify_keywords', 997, 1286), ('_determine_formats', 1289, 1321), ('_guess_format', 1324, 1364), ('_convert_to_valid_data_type', 1366, 1433), ('__new__', 1449, 1462), ('__getnewargs__', 1464, 1465), ('__init__', 1467, 1510), ('_init_from_coldefs', 1512, 1516), ('_init_from_sequence', 1518, 1523), ('_init_from_array', 1525, 1579), ('_init_from_table', 1581, 1630), ('__copy__', 1632, 1633), ('__deepcopy__', 1635, 1636), ('_copy_column', 1638, 1681), ('__getattr__', 1683, 1697), ('dtype', 1700, 1730), ('names', 1733, 1734), ('formats', 1737, 1738), ('_arrays', 1741, 1742), ('_recformats', 1745, 1746), ('_dims', 1749, 1751), ('__getitem__', 1753, 1761), ('__contains__', 1763, 1769), ('__len__', 1771, 1772), ('__repr__', 1774, 1783), ('__add__', 1785, 1796), ('__radd__', 1798, 1799), ('__sub__', 1801, 1805), ('_update_column_attribute_changed', 1807, 1829), ('add_col', 1831, 1857), ('del_col', 1859, 1889), ('change_attrib', 1891, 1906), ('change_name', 1908, 1923), ('change_unit', 1925, 1937), ('info', 1939, 1988), ('__init__', 1997, 2008), ('dtype', 2011, 2018), ('spans', 2021, 2023), ('_recformats', 2026, 2036), ('add_col', 2038, 2040), ('del_col', 2042, 2044), ('_update_field_metrics', 2046, 2065), ('__new__', 2074, 2093), ('__array_finalize__', 2095, 2099), ('__setitem__', 2101, 2117), ('tolist', 2119, 2120)]
astropy/io/fits/hdu/base.py
[('_Delayed', 47, 48), ('InvalidHDUException', 83, 88), ('_hdu_class_from_header', 91, 136), ('_BaseHDU', 141, 815), ('_CorruptedHDU', 837, 870), ('_NonstandardHDU', 873, 951), ('_ValidHDU', 954, 1613), ('ExtensionHDU', 1616, 1659), ('NonstandardExtHDU', 1662, 1703), ('__init__', 158, 181), ('__init_subclass__', 183, 214), ('header', 217, 218), ('header', 221, 222), ('name', 225, 228), ('name', 231, 239), ('ver', 242, 243), ('ver', 246, 252), ('level', 255, 256), ('level', 259, 265), ('is_image', 268, 279), ('_data_loaded', 282, 283), ('_has_data', 286, 287), ('register_hdu', 298, 299), ('unregister_hdu', 302, 304), ('match_header', 307, 308), ('fromstring', 311, 345), ('readfrom', 348, 355), ('_readfrom_internal', 358, 403), ('writeto', 441, 479), ('_from_data', 482, 492), ('_writeheader', 637, 649), ('_writedata', 651, 683), ('_writedata_internal', 685, 694), ('_writedata_direct_copy', 696, 711), ('_writeto', 718, 719), ('_postwriteto', 721, 723), ('_writeto_internal', 733, 796), ('_get_raw_data', 798, 807), ('_close', 809, 815), ('size', 855, 864), ('_summary', 866, 867), ('verify', 869, 870), ('match_header', 891, 898), ('size', 901, 908), ('_writedata', 910, 932), ('_summary', 934, 935), ('data', 938, 942), ('_verify', 944, 951), ('__init__', 959, 978), ('match_header', 981, 990), ('size', 993, 997), ('filebytes', 999, 1006), ('fileinfo', 1008, 1044), ('copy', 1046, 1054), ('_verify', 1056, 1136), ('_prewriteto', 1138, 1140), ('req_cards', 1144, 1275), ('add_datasum', 1277, 1310), ('add_checksum', 1312, 1365), ('verify_datasum', 1367, 1387), ('verify_checksum', 1389, 1413), ('_verify_checksum_datasum', 1415, 1436), ('_update_checksum', 1438, 1469), ('_get_timestamp', 1471, 1478), ('_calculate_datasum', 1480, 1498), ('_calculate_checksum', 1500, 1519), ('_compute_checksum', 1521, 1554), ('_encode_byte', 1563, 1583), ('_char_encode', 1585, 1613), ('match_header', 1627, 1633), ('writeto', 1635, 1645), ('_verify', 1647, 1659), ('match_header', 1677, 1692), ('_summary', 1694, 1696), ('data', 1699, 1703)]
astropy/io/fits/util.py
[('_is_int', 33, 37), ('NotifierMixin', 40, 149), ('first', 152, 162), ('itersubclasses', 165, 197), ('ignore_sigint', 200, 245), ('encode_ascii', 248, 258), ('decode_ascii', 261, 294), ('isreadable', 297, 314), ('iswritable', 317, 334), ('isfile', 337, 351), ('fileobj_closed', 354, 368), ('fileobj_mode', 419, 448), ('_fileobj_normalize_mode', 451, 473), ('fileobj_is_binary', 476, 493), ('translate', 496, 501), ('fill', 504, 518), ('_array_from_file', 529, 562), ('_array_to_file', 569, 624), ('_array_to_file_like', 627, 666), ('_convert_array', 686, 701), ('_pseudo_zero', 704, 714), ('_is_pseudo_integer', 717, 720), ('_str_to_num', 733, 740), ('_words_group', 743, 786), ('_tmp_name', 789, 798), ('_free_space_check', 817, 838), ('_extract_number', 841, 851), ('get_testdata_filepath', 854, 871), ('_rstrip_inplace', 874, 920), ('_is_dask_array', 923, 930), ('_remove_listener', 98, 107), ('_notify', 109, 132), ('__getstate__', 134, 149), ('wrapped', 207, 243), ('maybe_fill', 512, 516)]
304:        self.repeat, self.format, self.option = _parse_tformat(format)
365:        self.format, self.width, self.precision = _parse_ascii_tformat(format, strict)
2434:    repeat, dtype, option = _parse_tformat(format)
```

## 原始行 194 · command_execution

命令：
```
/bin/bash -lc "sed -n '40,235p' astropy/io/fits/column.py; nl -ba astropy/io/fits/column.py | sed -n '2110,2605p'"
```

退出码：`0`

输出：
```
FITS2NUMPY = {
    "L": "i1",
    "B": "u1",
    "I": "i2",
    "J": "i4",
    "K": "i8",
    "E": "f4",
    "D": "f8",
    "C": "c8",
    "M": "c16",
    "A": "S",
}

# the inverse dictionary of the above
NUMPY2FITS = {val: key for key, val in FITS2NUMPY.items()}
# Normally booleans are represented as ints in Astropy, but if passed in a numpy
# boolean array, that should be supported
NUMPY2FITS["b1"] = "L"
# Add unsigned types, which will be stored as signed ints with a TZERO card.
NUMPY2FITS["u2"] = "I"
NUMPY2FITS["u4"] = "J"
NUMPY2FITS["u8"] = "K"
# Add half precision floating point numbers which will be up-converted to
# single precision.
NUMPY2FITS["f2"] = "E"

# This is the order in which values are converted to FITS types
# Note that only double precision floating point/complex are supported
FORMATORDER = ["L", "B", "I", "J", "K", "D", "M", "A"]

# Convert single precision floating point/complex to double precision.
FITSUPCONVERTERS = {"E": "D", "C": "M"}

# mapping from ASCII table TFORM data type to numpy data type
# A: Character
# I: Integer (32-bit)
# J: Integer (64-bit; non-standard)
# F: Float (64-bit; fixed decimal notation)
# E: Float (64-bit; exponential notation)
# D: Float (64-bit; exponential notation, always 64-bit by convention)
ASCII2NUMPY = {"A": "S", "I": "i4", "J": "i8", "F": "f8", "E": "f8", "D": "f8"}

# Maps FITS ASCII column format codes to the appropriate Python string
# formatting codes for that type.
ASCII2STR = {"A": "", "I": "d", "J": "d", "F": "f", "E": "E", "D": "E"}

# For each ASCII table format code, provides a default width (and decimal
# precision) for when one isn't given explicitly in the column format
ASCII_DEFAULT_WIDTHS = {
    "A": (1, 0),
    "I": (10, 0),
    "J": (15, 0),
    "E": (15, 7),
    "F": (16, 7),
    "D": (25, 17),
}

# TDISPn for both ASCII and Binary tables
TDISP_RE_DICT = {}
TDISP_RE_DICT["F"] = re.compile(
    r"(?:(?P<formatc>[F])(?:(?P<width>[0-9]+)\.{1}(?P<precision>[0-9]+))+)|"
)
TDISP_RE_DICT["A"] = TDISP_RE_DICT["L"] = re.compile(
    r"(?:(?P<formatc>[AL])(?P<width>[0-9]+)+)|"
)
TDISP_RE_DICT["I"] = TDISP_RE_DICT["B"] = TDISP_RE_DICT["O"] = TDISP_RE_DICT["Z"] = (
    re.compile(
        r"(?:(?P<formatc>[IBOZ])(?:(?P<width>[0-9]+)"
        r"(?:\.{0,1}(?P<precision>[0-9]+))?))|"
    )
)
TDISP_RE_DICT["E"] = TDISP_RE_DICT["G"] = TDISP_RE_DICT["D"] = re.compile(
    r"(?:(?P<formatc>[EGD])(?:(?P<width>[0-9]+)\."
    r"(?P<precision>[0-9]+))+)"
    r"(?:E{0,1}(?P<exponential>[0-9]+)?)|"
)
TDISP_RE_DICT["EN"] = TDISP_RE_DICT["ES"] = re.compile(
    r"(?:(?P<formatc>E[NS])(?:(?P<width>[0-9]+)\.{1}(?P<precision>[0-9]+))+)"
)

# mapping from TDISP format to python format
# A: Character
# L: Logical (Boolean)
# I: 16-bit Integer
#    Can't predefine zero padding and space padding before hand without
#    knowing the value being formatted, so grabbing precision and using that
#    to zero pad, ignoring width. Same with B, O, and Z
# B: Binary Integer
# O: Octal Integer
# Z: Hexadecimal Integer
# F: Float (64-bit; fixed decimal notation)
# EN: Float (engineering fortran format, exponential multiple of thee
# ES: Float (scientific, same as EN but non-zero leading digit
# E: Float, exponential notation
#    Can't get exponential restriction to work without knowing value
#    before hand, so just using width and precision, same with D, G, EN, and
#    ES formats
# D: Double-precision Floating Point with exponential
#    (E but for double precision)
# G: Double-precision Floating Point, may or may not show exponent
TDISP_FMT_DICT = {
    "I": "{{:{width}d}}",
    "B": "{{:{width}b}}",
    "O": "{{:{width}o}}",
    "Z": "{{:{width}x}}",
    "F": "{{:{width}.{precision}f}}",
    "G": "{{:{width}.{precision}g}}",
}
TDISP_FMT_DICT["A"] = TDISP_FMT_DICT["L"] = "{{:>{width}}}"
TDISP_FMT_DICT["E"] = TDISP_FMT_DICT["D"] = TDISP_FMT_DICT["EN"] = TDISP_FMT_DICT[
    "ES"
] = "{{:{width}.{precision}e}}"

# tuple of column/field definition common names and keyword names, make
# sure to preserve the one-to-one correspondence when updating the list(s).
# Use lists, instead of dictionaries so the names can be displayed in a
# preferred order.
KEYWORD_NAMES = (
    "TTYPE",
    "TFORM",
    "TUNIT",
    "TNULL",
    "TSCAL",
    "TZERO",
    "TDISP",
    "TBCOL",
    "TDIM",
    "TCTYP",
    "TCUNI",
    "TCRPX",
    "TCRVL",
    "TCDLT",
    "TRPOS",
)
KEYWORD_ATTRIBUTES = (
    "name",
    "format",
    "unit",
    "null",
    "bscale",
    "bzero",
    "disp",
    "start",
    "dim",
    "coord_type",
    "coord_unit",
    "coord_ref_point",
    "coord_ref_value",
    "coord_inc",
    "time_ref_pos",
)
"""This is a list of the attributes that can be set on `Column` objects."""


KEYWORD_TO_ATTRIBUTE = OrderedDict(zip(KEYWORD_NAMES, KEYWORD_ATTRIBUTES))

ATTRIBUTE_TO_KEYWORD = OrderedDict(zip(KEYWORD_ATTRIBUTES, KEYWORD_NAMES))


# TODO: Define a list of default comments to associate with each table keyword

# TFORMn regular expression
TFORMAT_RE = re.compile(
    r"(?P<repeat>^[0-9]*)(?P<format>[LXBIJKAEDCMPQ])(?P<option>[!-~]*)", re.IGNORECASE
)

# TFORMn for ASCII tables; two different versions depending on whether
# the format is floating-point or not; allows empty values for width
# in which case defaults are used
TFORMAT_ASCII_RE = re.compile(
    r"(?:(?P<format>[AIJ])(?P<width>[0-9]+)?)|"
    r"(?:(?P<formatf>[FED])"
    r"(?:(?P<widthf>[0-9]+)(?:\."
    r"(?P<precision>[0-9]+))?)?)"
)

TTYPE_RE = re.compile(r"[0-9a-zA-Z_]+")
"""
Regular expression for valid table column names.  See FITS Standard v3.0 section 7.2.2.
"""

# table definition keyword regular expression
TDEF_RE = re.compile(r"(?P<label>^T[A-Z]*)(?P<num>[1-9][0-9 ]*$)")

# table dimension keyword regular expression (fairly flexible with whitespace)
TDIM_RE = re.compile(r"\(\s*(?P<dims>(?:\d+\s*)(?:,\s*\d+\s*)*\s*)\)\s*")

# value for ASCII table cell with value = TNULL
# this can be reset by user.
ASCIITNULL = 0

# The default placeholder to use for NULL values in ASCII tables when
# converting from binary to ASCII tables
DEFAULT_ASCII_TNULL = "---"


  2110	        elif self.element_dtype == "S":
  2111	            value = chararray.array(value, itemsize=1)
  2112	        else:
  2113	            value = np.array(value, dtype=self.element_dtype)
  2114	        np.ndarray.__setitem__(self, key, value)
  2115	        nelem = value.shape
  2116	        len_value = np.prod(nelem)
  2117	        self.max = max(self.max, len_value)
  2118	
  2119	    def tolist(self):
  2120	        return [list(item) for item in super().tolist()]
  2121	
  2122	
  2123	
  2124	
  2125	
  2126	
  2127	
  2128	
  2129	
  2130	
  2131	
  2132	
  2133	
  2134	
  2135	
  2136	
  2137	
  2138	
  2139	
  2140	
  2141	
  2142	
  2143	
  2144	
  2145	
  2146	
  2147	
  2148	
  2149	
  2150	
  2151	
  2152	
  2153	
  2154	
  2155	
  2156	
  2157	
  2158	
  2159	
  2160	
  2161	
  2162	def _unwrapx(input, output, repeat):
  2163	    """
  2164	    Unwrap the X format column into a Boolean array.
  2165	
  2166	    Parameters
  2167	    ----------
  2168	    input
  2169	        input ``Uint8`` array of shape (`s`, `nbytes`)
  2170	
  2171	    output
  2172	        output Boolean array of shape (`s`, `repeat`)
  2173	
  2174	    repeat
  2175	        number of bits
  2176	    """
  2177	    pow2 = np.array([128, 64, 32, 16, 8, 4, 2, 1], dtype="uint8")
  2178	    nbytes = ((repeat - 1) // 8) + 1
  2179	    for i in range(nbytes):
  2180	        _min = i * 8
  2181	        _max = min((i + 1) * 8, repeat)
  2182	        for j in range(_min, _max):
  2183	            output[..., j] = np.bitwise_and(input[..., i], pow2[j - i * 8])
  2184	
  2185	
  2186	def _wrapx(input, output, repeat):
  2187	    """
  2188	    Wrap the X format column Boolean array into an ``UInt8`` array.
  2189	
  2190	    Parameters
  2191	    ----------
  2192	    input
  2193	        input Boolean array of shape (`s`, `repeat`)
  2194	
  2195	    output
  2196	        output ``Uint8`` array of shape (`s`, `nbytes`)
  2197	
  2198	    repeat
  2199	        number of bits
  2200	    """
  2201	    output[...] = 0  # reset the output
  2202	    nbytes = ((repeat - 1) // 8) + 1
  2203	    unused = nbytes * 8 - repeat
  2204	    for i in range(nbytes):
  2205	        _min = i * 8
  2206	        _max = min((i + 1) * 8, repeat)
  2207	        for j in range(_min, _max):
  2208	            if j != _min:
  2209	                np.left_shift(output[..., i], 1, output[..., i])
  2210	            np.add(output[..., i], input[..., j], output[..., i])
  2211	
  2212	    # shift the unused bits
  2213	    np.left_shift(output[..., i], unused, output[..., i])
  2214	
  2215	
  2216	def _makep(array, descr_output, format, nrows=None):
  2217	    """
  2218	    Construct the P (or Q) format column array, both the data descriptors and
  2219	    the data.  It returns the output "data" array of data type `dtype`.
  2220	
  2221	    The descriptor location will have a zero offset for all columns
  2222	    after this call.  The final offset will be calculated when the file
  2223	    is written.
  2224	
  2225	    Parameters
  2226	    ----------
  2227	    array
  2228	        input object array
  2229	
  2230	    descr_output
  2231	        output "descriptor" array of data type int32 (for P format arrays) or
  2232	        int64 (for Q format arrays)--must be nrows long in its first dimension
  2233	
  2234	    format
  2235	        the _FormatP object representing the format of the variable array
  2236	
  2237	    nrows : int, optional
  2238	        number of rows to create in the column; defaults to the number of rows
  2239	        in the input array
  2240	    """
  2241	    # TODO: A great deal of this is redundant with FITS_rec._convert_p; see if
  2242	    # we can merge the two somehow.
  2243	
  2244	    _offset = 0
  2245	
  2246	    if not nrows:
  2247	        nrows = len(array)
  2248	
  2249	    data_output = _VLF([None] * nrows, dtype=format.dtype)
  2250	
  2251	    if format.dtype == "S":
  2252	        _nbytes = 1
  2253	    else:
  2254	        _nbytes = np.array([], dtype=format.dtype).itemsize
  2255	
  2256	    for idx in range(nrows):
  2257	        if idx < len(array):
  2258	            rowval = array[idx]
  2259	        else:
  2260	            if format.dtype == "S":
  2261	                rowval = " " * data_output.max
  2262	            else:
  2263	                rowval = [0] * data_output.max
  2264	        if format.dtype == "S":
  2265	            data_output[idx] = chararray.array(encode_ascii(rowval), itemsize=1)
  2266	        else:
  2267	            data_output[idx] = np.array(rowval, dtype=format.dtype)
  2268	
  2269	        nelem = data_output[idx].shape
  2270	        descr_output[idx, 0] = np.prod(nelem)
  2271	        descr_output[idx, 1] = _offset
  2272	
  2273	        # detect overflow when using P format
  2274	        if (
  2275	            descr_output.dtype == np.int32
  2276	            and int(descr_output[idx, 0]) * _nbytes >= 2**31
  2277	        ):
  2278	            raise ValueError(
  2279	                "The heapsize limit for 'P' format has been reached. "
  2280	                "Please consider using the 'Q' format for your file."
  2281	            )
  2282	        _offset += descr_output[idx, 0] * _nbytes
  2283	
  2284	    return data_output
  2285	
  2286	
  2287	
  2288	
  2289	
  2290	
  2291	
  2292	
  2293	
  2294	
  2295	
  2296	
  2297	
  2298	
  2299	
  2300	
  2301	
  2302	
  2303	
  2304	
  2305	
  2306	
  2307	
  2308	
  2309	
  2310	
  2311	
  2312	
  2313	
  2314	
  2315	
  2316	
  2317	
  2318	
  2319	
  2320	
  2321	
  2322	
  2323	
  2324	
  2325	
  2326	
  2327	
  2328	
  2329	
  2330	
  2331	
  2332	
  2333	
  2334	
  2335	
  2336	
  2337	
  2338	
  2339	
  2340	
  2341	
  2342	
  2343	
  2344	
  2345	
  2346	
  2347	
  2348	
  2349	
  2350	
  2351	
  2352	
  2353	
  2354	
  2355	
  2356	
  2357	
  2358	
  2359	
  2360	
  2361	
  2362	
  2363	
  2364	
  2365	
  2366	
  2367	
  2368	
  2369	
  2370	
  2371	
  2372	
  2373	
  2374	
  2375	
  2376	
  2377	
  2378	
  2379	
  2380	
  2381	def _parse_tdim(tdim):
  2382	    """Parse the ``TDIM`` value into a tuple (may return an empty tuple if
  2383	    the value ``TDIM`` value is empty or invalid).
  2384	    """
  2385	    m = tdim and TDIM_RE.match(tdim)
  2386	    if m:
  2387	        dims = m.group("dims")
  2388	        return tuple(int(d.strip()) for d in dims.split(","))[::-1]
  2389	
  2390	    # Ignore any dim values that don't specify a multidimensional column
  2391	    return ()
  2392	
  2393	
  2394	def _scalar_to_format(value):
  2395	    """
  2396	    Given a scalar value or string, returns the minimum FITS column format
  2397	    that can represent that value.  'minimum' is defined by the order given in
  2398	    FORMATORDER.
  2399	    """
  2400	    # First, if value is a string, try to convert to the appropriate scalar
  2401	    # value
  2402	    for type_ in (int, float, complex):
  2403	        try:
  2404	            value = type_(value)
  2405	            break
  2406	        except ValueError:
  2407	            continue
  2408	
  2409	    numpy_dtype_str = np.min_scalar_type(value).str
  2410	    numpy_dtype_str = numpy_dtype_str[1:]  # Strip endianness
  2411	
  2412	    try:
  2413	        fits_format = NUMPY2FITS[numpy_dtype_str]
  2414	        return FITSUPCONVERTERS.get(fits_format, fits_format)
  2415	    except KeyError:
  2416	        return "A" + str(len(value))
  2417	
  2418	
  2419	def _cmp_recformats(f1, f2):
  2420	    """
  2421	    Compares two numpy recformats using the ordering given by FORMATORDER.
  2422	    """
  2423	    if f1[0] == "S" and f2[0] == "S":
  2424	        return cmp(int(f1[1:]), int(f2[1:]))
  2425	    else:
  2426	        f1, f2 = NUMPY2FITS[f1], NUMPY2FITS[f2]
  2427	        return cmp(FORMATORDER.index(f1), FORMATORDER.index(f2))
  2428	
  2429	
  2430	def _convert_fits2record(format):
  2431	    """
  2432	    Convert FITS format spec to record format spec.
  2433	    """
  2434	    repeat, dtype, option = _parse_tformat(format)
  2435	
  2436	    if dtype in FITS2NUMPY:
  2437	        if dtype == "A":
  2438	            output_format = FITS2NUMPY[dtype] + str(repeat)
  2439	            # to accommodate both the ASCII table and binary table column
  2440	            # format spec, i.e. A7 in ASCII table is the same as 7A in
  2441	            # binary table, so both will produce 'S7'.
  2442	            # Technically the FITS standard does not allow this but it's a very
  2443	            # common mistake
  2444	            if format.lstrip()[0] == "A" and option != "":
  2445	                # make sure option is integer
  2446	                output_format = FITS2NUMPY[dtype] + str(int(option))
  2447	        else:
  2448	            repeat_str = ""
  2449	            if repeat != 1:
  2450	                repeat_str = str(repeat)
  2451	            output_format = repeat_str + FITS2NUMPY[dtype]
  2452	
  2453	    elif dtype == "X":
  2454	        output_format = _FormatX(repeat)
  2455	    elif dtype == "P":
  2456	        output_format = _FormatP.from_tform(format)
  2457	    elif dtype == "Q":
  2458	        output_format = _FormatQ.from_tform(format)
  2459	    elif dtype == "F":
  2460	        output_format = "f8"
  2461	    else:
  2462	        raise ValueError(f"Illegal format `{format}`.")
  2463	
  2464	    return output_format
  2465	
  2466	
  2467	def _convert_record2fits(format):
  2468	    """
  2469	    Convert record format spec to FITS format spec.
  2470	    """
  2471	    recformat, kind, dtype = _dtype_to_recformat(format)
  2472	    shape = dtype.shape
  2473	    itemsize = dtype.base.itemsize
  2474	    if dtype.char == "U" or (
  2475	        dtype.subdtype is not None and dtype.subdtype[0].char == "U"
  2476	    ):
  2477	        # Unicode dtype--itemsize is 4 times actual ASCII character length,
  2478	        # which what matters for FITS column formats
  2479	        # Use dtype.base and dtype.subdtype --dtype for multi-dimensional items
  2480	        itemsize = itemsize // 4
  2481	
  2482	    option = str(itemsize)
  2483	
  2484	    ndims = len(shape)
  2485	    repeat = 1
  2486	    if ndims > 0:
  2487	        nel = np.array(shape, dtype="i8").prod()
  2488	        if nel > 1:
  2489	            repeat = nel
  2490	
  2491	    if kind == "S":
  2492	        # This is a kludge that will place string arrays into a
  2493	        # single field, so at least we won't lose data.  Need to
  2494	        # use a TDIM keyword to fix this, declaring as (slength,
  2495	        # dim1, dim2, ...)  as mwrfits does
  2496	
  2497	        ntot = int(repeat) * int(option)
  2498	
  2499	        output_format = str(ntot) + "A"
  2500	    elif recformat in NUMPY2FITS:  # record format
  2501	        if repeat != 1:
  2502	            repeat = str(repeat)
  2503	        else:
  2504	            repeat = ""
  2505	        output_format = repeat + NUMPY2FITS[recformat]
  2506	    else:
  2507	        raise ValueError(f"Illegal format `{format}`.")
  2508	
  2509	    return output_format
  2510	
  2511	
  2512	def _dtype_to_recformat(dtype):
  2513	    """
  2514	    Utility function for converting a dtype object or string that instantiates
  2515	    a dtype (e.g. 'float32') into one of the two character Numpy format codes
  2516	    that have been traditionally used by Astropy.
  2517	    """
  2518	    if not isinstance(dtype, np.dtype):
  2519	        dtype = np.dtype(dtype)
  2520	
  2521	    kind = dtype.base.kind
  2522	
  2523	    if kind in ("U", "S"):
  2524	        recformat = kind = "S"
  2525	    else:
  2526	        itemsize = dtype.base.itemsize
  2527	        recformat = kind + str(itemsize)
  2528	
  2529	    return recformat, kind, dtype
  2530	
  2531	
  2532	def _convert_format(format, reverse=False):
  2533	    """
  2534	    Convert FITS format spec to record format spec.  Do the opposite if
  2535	    reverse=True.
  2536	    """
  2537	    if reverse:
  2538	        return _convert_record2fits(format)
  2539	    else:
  2540	        return _convert_fits2record(format)
  2541	
  2542	
  2543	
  2544	
  2545	
  2546	
  2547	
  2548	
  2549	
  2550	
  2551	
  2552	
  2553	
  2554	
  2555	
  2556	
  2557	
  2558	
  2559	
  2560	
  2561	
  2562	
  2563	
  2564	
  2565	
  2566	
  2567	
  2568	
  2569	
  2570	
  2571	
  2572	
  2573	
  2574	
  2575	
  2576	
  2577	
  2578	
  2579	
  2580	
  2581	
  2582	
  2583	
  2584	
  2585	
  2586	
  2587	
  2588	
  2589	
  2590	
  2591	
  2592	
  2593	
  2594	
  2595	
  2596	
  2597	
  2598	def _parse_tdisp_format(tdisp):
  2599	    """
  2600	    Parse the ``TDISPn`` keywords for ASCII and binary tables into a
  2601	    ``(format, width, precision, exponential)`` tuple (the TDISP values
  2602	    for ASCII and binary are identical except for 'Lw',
  2603	    which is only present in BINTABLE extensions.
  2604	
  2605	    Parameters
```

## 原始行 197 · command_execution

命令：
```
/bin/bash -lc "sed -n '290,410p' astropy/io/fits/column.py; grep -RIn \"_get_index\\|_convert_ascii_format\" astropy/io/fits --include='*.py'"
```

退出码：`0`

输出：
```
        return cls.from_recformat(format.recformat)


class _ColumnFormat(_BaseColumnFormat):
    """
    Represents a FITS binary table column format.

    This is an enhancement over using a normal string for the format, since the
    repeat count, format code, and option are available as separate attributes,
    and smart comparison is used.  For example 1J == J.
    """

    def __new__(cls, format):
        self = super().__new__(cls, format)
        self.repeat, self.format, self.option = _parse_tformat(format)
        self.format = self.format.upper()
        if self.format in ("P", "Q"):
            # TODO: There should be a generic factory that returns either
            # _FormatP or _FormatQ as appropriate for a given TFORMn
            if self.format == "P":
                recformat = _FormatP.from_tform(format)
            else:
                recformat = _FormatQ.from_tform(format)
            # Format of variable length arrays
            self.p_format = recformat.format
        else:
            self.p_format = None
        return self

    @classmethod
    def from_recformat(cls, recformat):
        """Creates a column format from a Numpy record dtype format."""
        return cls(_convert_format(recformat, reverse=True))

    @lazyproperty
    def recformat(self):
        """Returns the equivalent Numpy record format string."""
        return _convert_format(self)

    @lazyproperty
    def canonical(self):
        """
        Returns a 'canonical' string representation of this format.

        This is in the proper form of rTa where T is the single character data
        type code, a is the optional part, and r is the repeat.  If repeat == 1
        (the default) it is left out of this representation.
        """
        if self.repeat == 1:
            repeat = ""
        else:
            repeat = str(self.repeat)

        return f"{repeat}{self.format}{self.option}"


class _AsciiColumnFormat(_BaseColumnFormat):
    """Similar to _ColumnFormat but specifically for columns in ASCII tables.

    The formats of ASCII table columns and binary table columns are inherently
    incompatible in FITS.  They don't support the same ranges and types of
    values, and even reuse format codes in subtly different ways.  For example
    the format code 'Iw' in ASCII columns refers to any integer whose string
    representation is at most w characters wide, so 'I' can represent
    effectively any integer that will fit in a FITS columns.  Whereas for
    binary tables 'I' very explicitly refers to a 16-bit signed integer.

    Conversions between the two column formats can be performed using the
    ``to/from_binary`` methods on this class, or the ``to/from_ascii``
    methods on the `_ColumnFormat` class.  But again, not all conversions are
    possible and may result in a `ValueError`.
    """

    def __new__(cls, format, strict=False):
        self = super().__new__(cls, format)
        self.format, self.width, self.precision = _parse_ascii_tformat(format, strict)

        # If no width has been specified, set the dtype here to default as well
        if format == self.format:
            self.recformat = ASCII2NUMPY[format]

        # This is to support handling logical (boolean) data from binary tables
        # in an ASCII table
        self._pseudo_logical = False
        return self

    @classmethod
    def from_column_format(cls, format):
        inst = cls.from_recformat(format.recformat)
        # Hack
        if format.format == "L":
            inst._pseudo_logical = True
        return inst

    @classmethod
    def from_recformat(cls, recformat):
        """Creates a column format from a Numpy record dtype format."""
        return cls(_convert_ascii_format(recformat, reverse=True))

    @lazyproperty
    def recformat(self):
        """Returns the equivalent Numpy record format string."""
        return _convert_ascii_format(self)

    @lazyproperty
    def canonical(self):
        """
        Returns a 'canonical' string representation of this format.

        This is in the proper form of Tw.d where T is the single character data
        type code, w is the width in characters for this field, and d is the
        number of digits after the decimal place (for format codes 'E', 'F',
        and 'D' only).
        """
        if self.format in ("E", "F", "D"):
            return f"{self.format}{self.width}.{self.precision}"

        return f"{self.format}{self.width}"


class _FormatX(str):
astropy/io/fits/fitsrec.py:74:            index = _get_index(self.array.names, key)
astropy/io/fits/fitsrec.py:81:            index = self._get_index(key)
astropy/io/fits/fitsrec.py:90:            index = _get_index(self.array.names, key)
astropy/io/fits/fitsrec.py:97:                self.array.field(self._get_index(i))[self.row] = val
astropy/io/fits/fitsrec.py:100:            index = self._get_index(key)
astropy/io/fits/column.py:387:        return cls(_convert_ascii_format(recformat, reverse=True))
astropy/io/fits/column.py:392:        return _convert_ascii_format(self)
astropy/io/fits/column.py:1755:            key = _get_index(self.names, key)
astropy/io/fits/column.py:1804:        _other = [_get_index(self.names, key) for key in other]
astropy/io/fits/column.py:1869:        index = _get_index(self.names, col_name)
```

## 原始行 200 · command_execution

命令：
```
/bin/bash -lc 'head -45 astropy/io/fits/fitsrec.py'
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import copy
import operator
import warnings
import weakref
from contextlib import suppress
from functools import reduce

import numpy as np
from numpy import char as chararray

from astropy.utils import lazyproperty

from .column import _VLF, ASCII2NUMPY, ASCII2STR, ASCIITNULL, FITS2NUMPY, ColDefs, Delayed, _AsciiColDefs, _FormatP, _FormatX, _makep, _unwrapx, _wrapx















from .util import _rstrip_inplace, decode_ascii, encode_ascii


class FITS_record:
    """
    FITS record class.

    `FITS_record` is used to access records of the `FITS_rec` object.
    This will allow us to deal with scaled columns.  It also handles
    conversion/scaling of columns in ASCII tables.  The `FITS_record`
    class expects a `FITS_rec` object as input.
    """

    def __init__(
        self, input, row=0, start=None, end=None, step=None, base=None, **kwargs
```

## 原始行 203 · file_change

```
{
  "id": "item_133",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/fitsrec.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 206 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled

==================================== ERRORS ====================================
____________ ERROR collecting astropy/io/fits/tests/test_header.py _____________
astropy/io/fits/tests/test_header.py:68: in <module>
    class TestHeaderFunctions(FitsTestCase):
astropy/io/fits/tests/test_header.py:1201: in TestHeaderFunctions
    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
                                                          ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/compressed/compressed.py:356: in __init__
    self._get_bintable_without_data()
astropy/io/fits/hdu/compressed/compressed.py:443: in _get_bintable_without_data
    return _image_header_to_empty_bintable(
astropy/io/fits/hdu/compressed/header.py:392: in _image_header_to_empty_bintable
    cols = ColDefs([col1])
           ^^^^^^^^^^^^^^^
astropy/io/fits/column.py:1510: in __init__
    col._add_listener(self)
    ^^^^^^^^^^^^^^^^^
E   AttributeError: 'Column' object has no attribute '_add_listener'
=========================== short test summary info ============================
ERROR astropy/io/fits/tests/test_header.py - AttributeError: 'Column' object ...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 error in 0.15s
```

## 原始行 209 · file_change

```
{
  "id": "item_137",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 211 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
....................F
=================================== FAILURES ===================================
______________________ TestHeaderFunctions.test_add_blank ______________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7d8f83374450>

    def test_add_blank(self):
        header = fits.Header(
            [("A", "B", "C"), ("", 1), ("", 2), ("", 3), ("", "", ""), ("", "", "")]
        )
        header.add_blank(4)
        # This time a new blank should be added, and the existing blanks don't
        # get used... (though this is really kinda sketchy--there's a
        # distinction between truly blank cards, and cards with blank keywords
        # that isn't currently made int he code)
>       assert len(header) == 7
E       AssertionError: assert 6 == 7
E        +  where 6 = len(A       = 'B       '           / C                                              \n        1                            ...                                      \n                                                                                )

astropy/io/fits/tests/test_header.py:251: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_add_blank
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 20 passed in 0.13s
```

## 原始行 214 · file_change

```
{
  "id": "item_140",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 216 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
...................F
=================================== FAILURES ===================================
_____________________ TestHeaderFunctions.test_add_history _____________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7a06f882cd50>

    def test_add_history(self):
        header = fits.Header(
            [
                ("A", "B", "C"),
                ("HISTORY", 1),
                ("HISTORY", 2),
                ("HISTORY", 3),
                ("", "", ""),
                ("", "", ""),
            ]
        )
        header.add_history(4)
        # One of the blanks should get used, so the length shouldn't change
>       assert len(header) == 6
E       AssertionError: assert 7 == 6
E        +  where 7 = len(A       = 'B       '           / C                                              \nHISTORY 1                            ...                                      \n                                                                                )

astropy/io/fits/tests/test_header.py:232: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_add_history
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 19 passed in 0.11s
```

## 原始行 219 · file_change

```
{
  "id": "item_143",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 221 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
....................F
=================================== FAILURES ===================================
______________________ TestHeaderFunctions.test_add_blank ______________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x75e2a99f8950>

    def test_add_blank(self):
        header = fits.Header(
            [("A", "B", "C"), ("", 1), ("", 2), ("", 3), ("", "", ""), ("", "", "")]
        )
        header.add_blank(4)
        # This time a new blank should be added, and the existing blanks don't
        # get used... (though this is really kinda sketchy--there's a
        # distinction between truly blank cards, and cards with blank keywords
        # that isn't currently made int he code)
        assert len(header) == 7
>       assert header.cards[6].value == 4
E       AssertionError: assert '' == 4
E        +  where '' = ('', '', '').value

astropy/io/fits/tests/test_header.py:252: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_add_blank
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 20 passed in 0.12s
```

## 原始行 224 · file_change

```
{
  "id": "item_146",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 226 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
....................F
=================================== FAILURES ===================================
______________________ TestHeaderFunctions.test_add_blank ______________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x757c5bf882d0>

    def test_add_blank(self):
        header = fits.Header(
            [("A", "B", "C"), ("", 1), ("", 2), ("", 3), ("", "", ""), ("", "", "")]
        )
        header.add_blank(4)
        # This time a new blank should be added, and the existing blanks don't
        # get used... (though this is really kinda sketchy--there's a
        # distinction between truly blank cards, and cards with blank keywords
        # that isn't currently made int he code)
        assert len(header) == 7
        assert header.cards[6].value == 4
        assert header[""] == [1, 2, 3, "", "", 4]
        assert repr(header[""]) == "1\n2\n3\n\n\n4"
    
        header.add_blank(0, after="A")
>       assert len(header) == 8
E       AssertionError: assert 7 == 8
E        +  where 7 = len(A       = 'B       '           / C                                              \n        0                            ...                                      \n        4                                                                       )

astropy/io/fits/tests/test_header.py:257: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_add_blank
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 20 passed in 0.14s
```

## 原始行 229 · file_change

```
{
  "id": "item_149",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 231 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
......................F
=================================== FAILURES ===================================
___________________ TestHeaderFunctions.test_update_comment ____________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7a903e6b5550>

    def test_update_comment(self):
        hdul = fits.open(self.data("arange.fits"))
        hdul[0].header.update({"FOO": ("BAR", "BAZ")})
        assert hdul[0].header["FOO"] == "BAR"
        assert hdul[0].header.comments["FOO"] == "BAZ"
    
        with pytest.raises(ValueError):
            hdul[0].header.update({"FOO2": ("BAR", "BAZ", "EXTRA")})
    
        hdul.writeto(self.temp("test.fits"))
        hdul.close()
    
        hdul = fits.open(self.temp("test.fits"), mode="update")
        hdul[0].header.comments["FOO"] = "QUX"
>       hdul.close()

astropy/io/fits/tests/test_header.py:306: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:1098: in close
    self.flush(output_verify=output_verify, verbose=verbose)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

args = ([<astropy.io.fits.hdu.image.PrimaryHDU object at 0x7a903e725a90>],)
kwargs = {'output_verify': 'exception', 'verbose': False}
curr_thread = <_MainThread(MainThread, started 134760704001088)>
single_thread = True

    @wraps(func)
    def wrapped(*args, **kwargs):
        # Get the name of the current thread and determine if this is a single
        # threaded application
        curr_thread = threading.current_thread()
        single_thread = (
            threading.active_count() == 1 and curr_thread.name == "MainThread"
        )
    
    
    
    
    
    
    
    
    
    
    
    
>       sigint_handler = SigintHandler()
                         ^^^^^^^^^^^^^
E       NameError: name 'SigintHandler' is not defined

astropy/io/fits/util.py:232: NameError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_update_comment
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 22 passed in 0.13s
```

## 原始行 234 · command_execution

命令：
```
/bin/bash -lc "sed -n '190,250p' astropy/io/fits/util.py"
```

退出码：`0`

输出：
```

    From http://code.activestate.com/recipes/576949/
    """
    if _seen is None:
        _seen = set()
    try:
        subs = cls.__subclasses__()
    except TypeError:  # fails only when cls is type
        subs = cls.__subclasses__(cls)
    for sub in sorted(subs, key=operator.attrgetter("__name__")):
        if sub not in _seen:
            _seen.add(sub)
            yield sub
            yield from itersubclasses(sub, _seen)


def ignore_sigint(func):
    """
    This decorator registers a custom SIGINT handler to catch and ignore SIGINT
    until the wrapped function is completed.
    """

    @wraps(func)
    def wrapped(*args, **kwargs):
        # Get the name of the current thread and determine if this is a single
        # threaded application
        curr_thread = threading.current_thread()
        single_thread = (
            threading.active_count() == 1 and curr_thread.name == "MainThread"
        )












        sigint_handler = SigintHandler()

        # Define new signal interput handler
        if single_thread:
            # Install new handler
            old_handler = signal.signal(signal.SIGINT, sigint_handler)

        try:
            func(*args, **kwargs)
        finally:
            if single_thread:
                if old_handler is not None:
                    signal.signal(signal.SIGINT, old_handler)
                else:
                    signal.signal(signal.SIGINT, signal.SIG_DFL)

                if sigint_handler.sigint_received:
                    raise KeyboardInterrupt
```

## 原始行 237 · file_change

```
{
  "id": "item_154",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 239 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 40%]
.......F
=================================== FAILURES ===================================
____________ TestHeaderFunctions.test_header_clear_write[fitsext0] _____________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7168546cf9d0>
fitsext = <astropy.io.fits.hdu.image.ImageHDU object at 0x716854839f10>

    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
    def test_header_clear_write(self, fitsext):
        hdulist = fits.HDUList([fits.PrimaryHDU(), fitsext])
        hdulist[1].header["FOO"] = "BAR"
        hdulist[1].header.clear()
        with pytest.raises(VerifyError) as err:
>           hdulist.writeto(self.temp("temp.fits"), overwrite=True)

astropy/io/fits/tests/test_header.py:1207: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:1037: in writeto
    self.verify(option=output_verify)
astropy/io/fits/verify.py:82: in verify
    errs = self._verify(opt)
           ^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:1441: in _verify
    result = hdu._verify(option)
             ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1269: in _verify
    errs = super()._verify(option=option)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:584: in _verify
    self.update_header()
astropy/io/fits/hdu/image.py:347: in update_header
    self._header.set("BITPIX", self._bitpix, bitpix_comment, after=0)
astropy/io/fits/header.py:1006: in set
    self._relativeinsert((keyword, value, comment), before=before, after=after)
astropy/io/fits/header.py:2073: in _relativeinsert
    idx = self._cardindex(reference)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = , key = 0

    def _cardindex(self, key):
        """Returns an index into the ._cards list given a valid lookup key."""
        # This used to just set key = (key, 0) and then go on to act as if the
        # user passed in a tuple, but it's much more common to just be given a
        # string as the key, so optimize more for that case
        if isinstance(key, str):
            keyword = key
            n = 0
        elif isinstance(key, numbers.Integral):
            # If < 0, determine the actual index
            if key < 0:
                key += len(self._cards)
            if key < 0 or key >= len(self._cards):
>               raise IndexError("Header index out of range.")
E               IndexError: Header index out of range.

astropy/io/fits/header.py:1857: IndexError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_clear_write[fitsext0]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 79 passed in 0.24s
```

## 原始行 242 · file_change

```
{
  "id": "item_157",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 245 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 40%]
.......F
=================================== FAILURES ===================================
____________ TestHeaderFunctions.test_header_clear_write[fitsext0] _____________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x70c69815bc10>
fitsext = <astropy.io.fits.hdu.image.ImageHDU object at 0x70c6982be350>

    @pytest.mark.parametrize("fitsext", [fits.ImageHDU(), fits.CompImageHDU()])
    def test_header_clear_write(self, fitsext):
        hdulist = fits.HDUList([fits.PrimaryHDU(), fitsext])
        hdulist[1].header["FOO"] = "BAR"
        hdulist[1].header.clear()
        with pytest.raises(VerifyError) as err:
>           hdulist.writeto(self.temp("temp.fits"), overwrite=True)

astropy/io/fits/tests/test_header.py:1207: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:1037: in writeto
    self.verify(option=output_verify)
astropy/io/fits/verify.py:82: in verify
    errs = self._verify(opt)
           ^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:1441: in _verify
    result = hdu._verify(option)
             ^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:1269: in _verify
    errs = super()._verify(option=option)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:587: in _verify
    return super()._verify(option)
           ^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:1648: in _verify
    errs = super()._verify(option=option)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:1075: in _verify
    self.req_cards(
astropy/io/fits/hdu/base.py:1255: in req_cards
    val = self._header[keyword]
          ^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = BITPIX  =                    8 / array data type                                
NAXIS   =                    0 / number of array dimensions                     
key = 'NAXIS'

    def __getitem__(self, key):
        if isinstance(key, slice):
            return self.__class__([copy.copy(c) for c in self._cards[key]])
        elif self._haswildcard(key):
            return self.__class__(
                [copy.copy(self._cards[idx]) for idx in self._wildcardmatch(key)]
            )
        elif isinstance(key, str):
            key = key.strip()
            if key.upper() in _commentary_keywords:
                key = key.upper()
                # Special case for commentary cards
                return _HeaderCommentaryCards(self, key)
    
        if isinstance(key, tuple):
            keyword = key[0]
        else:
            keyword = key
    
>       card = self._cards[self._cardindex(key)]
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
E       IndexError: list index out of range

astropy/io/fits/header.py:170: IndexError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_clear_write[fitsext0]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 79 passed in 0.25s
```

## 原始行 248 · file_change

```
{
  "id": "item_161",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 251 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os,tempfile,traceback,numpy as np,gzip
from pathlib import Path
from astropy.io import fits
from astropy.io.fits.scripts.fitsheader import HeaderFormatter
root=tempfile.mkdtemp(); os.environ['HOME']=root
try:
 p='~/image.fits'; fits.writeto(p,np.arange(6),overwrite=True)
 print('write exists',Path(root,'image.fits').exists())
 with fits.open(p) as hdul: print('read',hdul[0].data.tolist(),hdul._file.name)
 fmt=HeaderFormatter(p); print('fmt', 'NAXIS' in fmt.parse()); fmt.close()
 pg='~/image.fits.gz'; fits.writeto(pg,np.arange(3),overwrite=True)
 with fits.open(pg) as hdul: print('gzip',hdul._file.compression,hdul[0].data.tolist())
 h=fits.Header([('FOO',1)]); h.tofile('~/head.bin'); print('head',fits.Header.fromfile('~/head.bin')['FOO'])
 col=fits.Column(name='a',format='J',array=np.array([1,2]))
 tab=fits.BinTableHDU.from_columns([col]); tab.dump('~/data.txt','~/cols.txt','~/hdr.txt',overwrite=True)
 tab2=fits.BinTableHDU.load('~/data.txt','~/cols.txt','~/hdr.txt'); print('table',tab2.data['a'].tolist())
except Exception:
 traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 15, in <module>
  File "/testbed/astropy/io/fits/hdu/table.py", line 146, in from_columns
    data = FITS_rec.from_columns(
           ^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/astropy/io/fits/fitsrec.py", line 398, in from_columns
    field = _get_recarray_field(data, idx)
            ^^^^^^^^^^^^^^^^^^^
NameError: name '_get_recarray_field' is not defined
write exists True
read [0, 1, 2, 3, 4, 5] /tmp/tmpeapoaequ/image.fits
fmt True
gzip gzip [0, 1, 2]
head 1
```

## 原始行 254 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import ast
fn='astropy/io/fits/fitsrec.py'; m=ast.parse(open(fn).read())
for n in m.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)): print(n.name,n.lineno,n.end_lineno)
PY
nl -ba astropy/io/fits/fitsrec.py | tail -260; grep -RIn \"_get_recarray_field\\|_has_unicode_fields\\|_get_heap_data\" astropy/io/fits/fitsrec.py"
```

退出码：`0`

输出：
```
FITS_record 49 143
FITS_rec 165 1366
_UnicodeArrayEncodeError 1384 1387
_ascii_encode 1390 1423
  1165	            # add the location offset of the heap area for each
  1166	            # variable length column
  1167	            if isinstance(recformat, _FormatP):
  1168	                # Irritatingly, this can return a different dtype than just
  1169	                # doing np.dtype(recformat.dtype); but this returns the results
  1170	                # that we want.  For example if recformat.dtype is 'S' we want
  1171	                # an array of characters.
  1172	                dtype = np.array([], dtype=recformat.dtype).dtype
  1173	
  1174	                if update_heap_pointers and name in self._converted:
  1175	                    # The VLA has potentially been updated, so we need to
  1176	                    # update the array descriptors
  1177	                    raw_field[:] = 0  # reset
  1178	                    npts = [np.prod(arr.shape) for arr in self._converted[name]]
  1179	
  1180	                    raw_field[: len(npts), 0] = npts
  1181	                    raw_field[1:, 1] = (
  1182	                        np.add.accumulate(raw_field[:-1, 0]) * dtype.itemsize
  1183	                    )
  1184	                    raw_field[:, 1][:] += heapsize
  1185	
  1186	                heapsize += raw_field[:, 0].sum() * dtype.itemsize
  1187	                # Even if this VLA has not been read or updated, we need to
  1188	                # include the size of its constituent arrays in the heap size
  1189	                # total
  1190	
  1191	            if isinstance(recformat, _FormatX) and name in self._converted:
  1192	                _wrapx(self._converted[name], raw_field, recformat.repeat)
  1193	                continue
  1194	
  1195	            scale_factors = self._get_scale_factors(column)
  1196	            _str, _bool, _number, _scale, _zero, bscale, bzero, _ = scale_factors
  1197	
  1198	            field = self._converted.get(name, raw_field)
  1199	
  1200	            # conversion for both ASCII and binary tables
  1201	            if _number or _str:
  1202	                if _number and (_scale or _zero) and column._physical_values:
  1203	                    dummy = field.copy()
  1204	                    if _zero:
  1205	                        # Cast before subtracting to avoid overflow problems.
  1206	                        dummy -= np.array(bzero).astype(dummy.dtype, casting="unsafe")
  1207	                    if _scale:
  1208	                        dummy /= bscale
  1209	                    # This will set the raw values in the recarray back to
  1210	                    # their non-physical storage values, so the column should
  1211	                    # be mark is not scaled
  1212	                    column._physical_values = False
  1213	                elif _str or isinstance(self._coldefs, _AsciiColDefs):
  1214	                    dummy = field
  1215	                else:
  1216	                    continue
  1217	
  1218	                # ASCII table, convert numbers to strings
  1219	                if isinstance(self._coldefs, _AsciiColDefs):
  1220	                    self._scale_back_ascii(index, dummy, raw_field)
  1221	                # binary table string column
  1222	                elif isinstance(raw_field, chararray.chararray):
  1223	                    self._scale_back_strings(index, dummy, raw_field)
  1224	                # all other binary table columns
  1225	                else:
  1226	                    if len(raw_field) and isinstance(raw_field[0], np.integer):
  1227	                        dummy = np.around(dummy)
  1228	
  1229	                    if raw_field.shape == dummy.shape:
  1230	                        raw_field[:] = dummy
  1231	                    else:
  1232	                        # Reshaping the data is necessary in cases where the
  1233	                        # TDIMn keyword was used to shape a column's entries
  1234	                        # into arrays
  1235	                        raw_field[:] = dummy.ravel().view(raw_field.dtype)
  1236	
  1237	                del dummy
  1238	
  1239	            # ASCII table does not have Boolean type
  1240	            elif _bool and name in self._converted:
  1241	                choices = (
  1242	                    np.array([ord("F")], dtype=np.int8)[0],
  1243	                    np.array([ord("T")], dtype=np.int8)[0],
  1244	                )
  1245	                raw_field[:] = np.choose(field, choices)
  1246	
  1247	        # Store the updated heapsize
  1248	        self._heapsize = heapsize
  1249	
  1250	    def _scale_back_strings(self, col_idx, input_field, output_field):
  1251	        # There are a few possibilities this has to be able to handle properly
  1252	        # The input_field, which comes from the _converted column is of dtype
  1253	        # 'Un' so that elements read out of the array are normal str
  1254	        # objects (i.e. unicode strings)
  1255	        #
  1256	        # At the other end the *output_field* may also be of type 'S' or of
  1257	        # type 'U'.  It will *usually* be of type 'S' because when reading
  1258	        # an existing FITS table the raw data is just ASCII strings, and
  1259	        # represented in Numpy as an S array.  However, when a user creates
  1260	        # a new table from scratch, they *might* pass in a column containing
  1261	        # unicode strings (dtype 'U').  Therefore the output_field of the
  1262	        # raw array is actually a unicode array.  But we still want to make
  1263	        # sure the data is encodable as ASCII.  Later when we write out the
  1264	        # array we use, in the dtype 'U' case, a different write routine
  1265	        # that writes row by row and encodes any 'U' columns to ASCII.
  1266	
  1267	        # If the output_field is non-ASCII we will worry about ASCII encoding
  1268	        # later when writing; otherwise we can do it right here
  1269	        if input_field.dtype.kind == "U" and output_field.dtype.kind == "S":
  1270	            try:
  1271	                _ascii_encode(input_field, out=output_field)
  1272	            except _UnicodeArrayEncodeError as exc:
  1273	                raise ValueError(
  1274	                    f"Could not save column '{self._coldefs[col_idx].name}': "
  1275	                    "Contains characters that cannot be encoded as ASCII as required "
  1276	                    "by FITS, starting at the index "
  1277	                    f"{exc.index[0] if len(exc.index) == 1 else exc.index!r} of the "
  1278	                    f"column, and the index {exc.start} of the string at that location."
  1279	                )
  1280	        else:
  1281	            # Otherwise go ahead and do a direct copy into--if both are type
  1282	            # 'U' we'll handle encoding later
  1283	            input_field = input_field.flatten().view(output_field.dtype)
  1284	            output_field.flat[:] = input_field
  1285	
  1286	        # Ensure that blanks at the end of each string are
  1287	        # converted to nulls instead of spaces, see Trac #15
  1288	        # and #111
  1289	        _rstrip_inplace(output_field)
  1290	
  1291	    def _scale_back_ascii(self, col_idx, input_field, output_field):
  1292	        """
  1293	        Convert internal array values back to ASCII table representation.
  1294	
  1295	        The ``input_field`` is the internal representation of the values, and
  1296	        the ``output_field`` is the character array representing the ASCII
  1297	        output that will be written.
  1298	        """
  1299	        starts = self._coldefs.starts[:]
  1300	        spans = self._coldefs.spans
  1301	        format = self._coldefs[col_idx].format
  1302	
  1303	        # The index of the "end" column of the record, beyond
  1304	        # which we can't write
  1305	        end = super().field(-1).itemsize
  1306	        starts.append(end + starts[-1])
  1307	
  1308	        if col_idx > 0:
  1309	            lead = starts[col_idx] - starts[col_idx - 1] - spans[col_idx - 1]
  1310	        else:
  1311	            lead = 0
  1312	
  1313	        if lead < 0:
  1314	            warnings.warn(
  1315	                f"Column {col_idx + 1} starting point overlaps the previous column."
  1316	            )
  1317	
  1318	        trail = starts[col_idx + 1] - starts[col_idx] - spans[col_idx]
  1319	
  1320	        if trail < 0:
  1321	            warnings.warn(
  1322	                f"Column {col_idx + 1} ending point overlaps the next column."
  1323	            )
  1324	
  1325	        # TODO: It would be nice if these string column formatting
  1326	        # details were left to a specialized class, as is the case
  1327	        # with FormatX and FormatP
  1328	        if "A" in format:
  1329	            _pc = "{:"
  1330	        else:
  1331	            _pc = "{:>"
  1332	
  1333	        fmt = "".join([_pc, format[1:], ASCII2STR[format[0]], "}", (" " * trail)])
  1334	
  1335	        # Even if the format precision is 0, we should output a decimal point
  1336	        # as long as there is space to do so--not including a decimal point in
  1337	        # a float value is discouraged by the FITS Standard
  1338	        trailing_decimal = format.precision == 0 and format.format in ("F", "E", "D")
  1339	
  1340	        # not using numarray.strings's num2char because the
  1341	        # result is not allowed to expand (as C/Python does).
  1342	        for jdx, value in enumerate(input_field):
  1343	            value = fmt.format(value)
  1344	            if len(value) > starts[col_idx + 1] - starts[col_idx]:
  1345	                raise ValueError(
  1346	                    f"Value {value!r} does not fit into the output's itemsize of "
  1347	                    f"{spans[col_idx]}."
  1348	                )
  1349	
  1350	            if trailing_decimal and value[0] == " ":
  1351	                # We have some extra space in the field for the trailing
  1352	                # decimal point
  1353	                value = value[1:] + "."
  1354	
  1355	            output_field[jdx] = value
  1356	
  1357	        # Replace exponent separator in floating point numbers
  1358	        if "D" in format:
  1359	            output_field[:] = output_field.replace(b"E", b"D")
  1360	
  1361	    def tolist(self):
  1362	        # Override .tolist to take care of special case of VLF
  1363	
  1364	        column_lists = [self[name].tolist() for name in self.columns.names]
  1365	
  1366	        return [list(row) for row in zip(*column_lists)]
  1367	
  1368	
  1369	
  1370	
  1371	
  1372	
  1373	
  1374	
  1375	
  1376	
  1377	
  1378	
  1379	
  1380	
  1381	
  1382	
  1383	
  1384	class _UnicodeArrayEncodeError(UnicodeEncodeError):
  1385	    def __init__(self, encoding, object_, start, end, reason, index):
  1386	        super().__init__(encoding, object_, start, end, reason)
  1387	        self.index = index
  1388	
  1389	
  1390	def _ascii_encode(inarray, out=None):
  1391	    """
  1392	    Takes a unicode array and fills the output string array with the ASCII
  1393	    encodings (if possible) of the elements of the input array.  The two arrays
  1394	    must be the same size (though not necessarily the same shape).
  1395	
  1396	    This is like an inplace version of `np.char.encode` though simpler since
  1397	    it's only limited to ASCII, and hence the size of each character is
  1398	    guaranteed to be 1 byte.
  1399	
  1400	    If any strings are non-ASCII an UnicodeArrayEncodeError is raised--this is
  1401	    just a `UnicodeEncodeError` with an additional attribute for the index of
  1402	    the item that couldn't be encoded.
  1403	    """
  1404	    out_dtype = np.dtype((f"S{inarray.dtype.itemsize // 4}", inarray.dtype.shape))
  1405	    if out is not None:
  1406	        out = out.view(out_dtype)
  1407	    if inarray.size == 0:
  1408	        return out
  1409	
  1410	    op_dtypes = [inarray.dtype, out_dtype]
  1411	    op_flags = [["readonly"], ["writeonly", "allocate"]]
  1412	    it = np.nditer(
  1413	        [inarray, out], op_dtypes=op_dtypes, op_flags=op_flags, flags=["zerosize_ok"]
  1414	    )
  1415	
  1416	    try:
  1417	        for initem, outitem in it:
  1418	            outitem[...] = initem.item().encode("ascii")
  1419	    except UnicodeEncodeError as exc:
  1420	        index = np.unravel_index(it.iterindex, inarray.shape)
  1421	        raise _UnicodeArrayEncodeError(*(exc.args + (index,)))
  1422	
  1423	    return it.operands[1]
  1424	
342:                    column.array = _get_recarray_field(arr.hdu.data, arr.field)
398:            field = _get_recarray_field(data, idx)
715:        if _has_unicode_fields(self):
746:        field = _get_recarray_field(base, name)
1050:    def _get_heap_data(self, try_from_disk=True):
1163:            raw_field = _get_recarray_field(self, index)
```

## 原始行 257 · file_change

```
{
  "id": "item_167",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/fitsrec.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 259 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os,tempfile,traceback,numpy as np
from astropy.io import fits
root=tempfile.mkdtemp(); os.environ['HOME']=root
try:
 col=fits.Column(name='a',format='J',array=np.array([1,2]))
 tab=fits.BinTableHDU.from_columns([col]); print(tab.data)
 tab.dump('~/data.txt','~/cols.txt','~/hdr.txt',overwrite=True)
 print(os.listdir(root))
 tab2=fits.BinTableHDU.load('~/data.txt','~/cols.txt','~/hdr.txt'); print('table',tab2.data['a'].tolist())
except Exception: traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 1721, in _array_str_implementation
    return array2string(a, max_line_width, precision, suppress_small, ' ', "")
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 798, in array2string
    return _array2string(a, options, separator, prefix)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 571, in wrapper
    return f(self, *args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 604, in _array2string
    lst = _formatArray(a, format_function, options['linewidth'],
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 957, in _formatArray
    return recurser(index=(),
           ^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 910, in recurser
    word = recurser(index + (-i,), next_hanging_indent, next_width)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 861, in recurser
    return format_function(a[index])
           ^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 1478, in __call__
    str_fields = [
                 ^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/numpy/_core/arrayprint.py", line 1478, in <listcomp>
    str_fields = [
                 ^
  File "/testbed/astropy/io/fits/fitsrec.py", line 96, in __getitem__
    index = self._get_index(key)
            ^^^^^^^^^^^^^^^
AttributeError: 'FITS_record' object has no attribute '_get_index'
```

## 原始行 262 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/io/fits/fitsrec.py | sed -n '45,175p'"
```

退出码：`0`

输出：
```
    45	
    46	from .util import _rstrip_inplace, decode_ascii, encode_ascii
    47	
    48	
    49	class FITS_record:
    50	    """
    51	    FITS record class.
    52	
    53	    `FITS_record` is used to access records of the `FITS_rec` object.
    54	    This will allow us to deal with scaled columns.  It also handles
    55	    conversion/scaling of columns in ASCII tables.  The `FITS_record`
    56	    class expects a `FITS_rec` object as input.
    57	    """
    58	
    59	    def __init__(
    60	        self, input, row=0, start=None, end=None, step=None, base=None, **kwargs
    61	    ):
    62	        """
    63	        Parameters
    64	        ----------
    65	        input : array
    66	            The array to wrap.
    67	        row : int, optional
    68	            The starting logical row of the array.
    69	        start : int, optional
    70	            The starting column in the row associated with this object.
    71	            Used for subsetting the columns of the `FITS_rec` object.
    72	        end : int, optional
    73	            The ending column in the row associated with this object.
    74	            Used for subsetting the columns of the `FITS_rec` object.
    75	        """
    76	        self.array = input
    77	        self.row = row
    78	        if base:
    79	            width = len(base)
    80	        else:
    81	            width = self.array._nfields
    82	
    83	        s = slice(start, end, step).indices(width)
    84	        self.start, self.end, self.step = s
    85	        self.base = base
    86	
    87	    def __getitem__(self, key):
    88	        if isinstance(key, str):
    89	            index = _get_index(self.array.names, key)
    90	
    91	            if index < self.start or index > self.end - 1:
    92	                raise KeyError(f"Key '{key}' does not exist.")
    93	        elif isinstance(key, slice):
    94	            return type(self)(self.array, self.row, key.start, key.stop, key.step, self)
    95	        else:
    96	            index = self._get_index(key)
    97	
    98	            if index > self.array._nfields - 1:
    99	                raise IndexError("Index out of bounds")
   100	
   101	        return self.array.field(index)[self.row]
   102	
   103	    def __setitem__(self, key, value):
   104	        if isinstance(key, str):
   105	            index = _get_index(self.array.names, key)
   106	
   107	            if index < self.start or index > self.end - 1:
   108	                raise KeyError(f"Key '{key}' does not exist.")
   109	        elif isinstance(key, slice):
   110	            start, stop, step = key.indices(self.array._nfields)
   111	            for i, val in zip(range(start, stop, step), value, strict=True):
   112	                self.array.field(self._get_index(i))[self.row] = val
   113	            return
   114	        else:
   115	            index = self._get_index(key)
   116	            if index > self.array._nfields - 1:
   117	                raise IndexError("Index out of bounds")
   118	
   119	        self.array.field(index)[self.row] = value
   120	
   121	    def __len__(self):
   122	        return len(range(self.start, self.end, self.step))
   123	
   124	    def __repr__(self):
   125	        """
   126	        Display a single row.
   127	        """
   128	        outlist = []
   129	        for idx in range(len(self)):
   130	            outlist.append(repr(self[idx]))
   131	        return f"({', '.join(outlist)})"
   132	
   133	    def field(self, field):
   134	        """
   135	        Get the field data of the record.
   136	        """
   137	        return self.__getitem__(field)
   138	
   139	    def setfield(self, field, value):
   140	        """
   141	        Set the field data of the record.
   142	        """
   143	        self.__setitem__(field, value)
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	class FITS_rec(np.recarray):
   166	    """
   167	    FITS record array class.
   168	
   169	    `FITS_rec` is the data part of a table HDU's data part.  This is a layer
   170	    over the `~numpy.recarray`, so we can deal with scaled columns.
   171	
   172	    It inherits all of the standard methods from `numpy.ndarray`.
   173	    """
   174	
   175	    _record_type = FITS_record
```

## 原始行 265 · file_change

```
{
  "id": "item_172",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/fitsrec.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 267 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os,tempfile,traceback,numpy as np
from astropy.io import fits
root=tempfile.mkdtemp(); os.environ['HOME']=root
try:
 col=fits.Column(name='a',format='J',array=np.array([1,2]))
 tab=fits.BinTableHDU.from_columns([col])
 tab.dump('~/data.txt','~/cols.txt','~/hdr.txt',overwrite=True)
 print(os.listdir(root))
 tab2=fits.BinTableHDU.load('~/data.txt','~/cols.txt','~/hdr.txt'); print('table',tab2.data['a'].tolist())
except Exception: traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
['cols.txt', 'hdr.txt', 'data.txt']
table [1, 2]
```

## 原始行 270 · file_change

```
{
  "id": "item_175",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 273 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled

==================================== ERRORS ====================================
_____________ ERROR collecting astropy/io/fits/tests/test_core.py ______________
astropy/io/fits/tests/test_core.py:19: in <module>
    from astropy.io.fits.convenience import _getext
E   ImportError: cannot import name '_getext' from 'astropy.io.fits.convenience' (/testbed/astropy/io/fits/convenience.py)
=========================== short test summary info ============================
ERROR astropy/io/fits/tests/test_core.py - ImportError: cannot import name '_...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 error in 0.18s
```

## 原始行 276 · command_execution

命令：
```
/bin/bash -lc "sed -n '45,120p' astropy/io/fits/tests/conftest.py; grep -RIn \"home_is_temp\\|startswith.*~\\|~/\" astropy/io/fits/tests --include='*.py'"
```

退出码：`0`

输出：
```
    be tracked so that, after the test case, we can verify no files were written
    to a literal tilde path.
    """
    # This checks the value specified in the fixture annotation
    if request.param:
        # `request.instance` refers to the test case that's using this fixture.
        request.instance.monkeypatch = monkeypatch
        request.instance.set_home_as_temp()

        request.instance.set_paths_via_pathlib(request.param == "pathlib")


class FitsTestCase:
    def setup_method(self):
        self.data_dir = os.path.join(os.path.dirname(__file__), "data")
        self.temp_dir = tempfile.mkdtemp(prefix="fits-test-")

        self.home_is_data = False
        self.home_is_temp = False
        self.temp_files_used = set()
        self.use_pathlib = False

        # Restore global settings to defaults
        # TODO: Replace this when there's a better way to in the config API to
        # force config values to their defaults
        fits.conf.enable_record_valued_keyword_cards = True
        fits.conf.extension_name_case_sensitive = False
        fits.conf.strip_header_whitespace = True
        fits.conf.use_memmap = True

    def teardown_method(self):
        if self.home_is_temp:
            # Verify that no files were written to a literal tilde path
            for temp_file, temp_file_no_tilde in self.temp_files_used:
                assert not os.path.exists(temp_file)
                assert os.path.exists(temp_file_no_tilde)

        if hasattr(self, "temp_dir") and os.path.exists(self.temp_dir):
            tries = 3
            while tries:
                try:
                    shutil.rmtree(self.temp_dir)
                    break
                except OSError:
                    # Probably couldn't delete the file because for whatever
                    # reason a handle to it is still open/hasn't been
                    # garbage-collected
                    time.sleep(0.5)
                    tries -= 1

        fits.conf.reset("enable_record_valued_keyword_cards")
        fits.conf.reset("extension_name_case_sensitive")
        fits.conf.reset("strip_header_whitespace")
        fits.conf.reset("use_memmap")

    def copy_file(self, filename, new_filename=None):
        """Copies a backup of a test data file to the temp dir and sets its
        mode to writeable. Can optionally change the file's name.
        """
        new_filename = filename if new_filename is None else new_filename
        p = self.temp(new_filename)
        shutil.copy(
            os.path.expanduser(self.data(filename)),
            os.path.expanduser(p),
        )
        os.chmod(os.path.expanduser(p), stat.S_IREAD | stat.S_IWRITE)
        return p

    def data(self, filename):
        """Returns the path to a test data file."""
        if self.home_is_data:
            prefix = "~"
        else:
            prefix = self.data_dir

        if self.use_pathlib:
astropy/io/fits/tests/test_core.py:565:    def test_writeto(self, home_is_temp):
astropy/io/fits/tests/test_core.py:597:    def test_writeto_overwrite(self, home_is_temp):
astropy/io/fits/tests/test_core.py:1086:    def test_write_read_gzip_file(self, home_is_temp):
astropy/io/fits/tests/test_core.py:1464:    def test_write_overwrite(self, home_is_temp):
astropy/io/fits/tests/test_core.py:1548:    def test_streaming_hdu(self, home_is_temp):
astropy/io/fits/tests/test_convenience.py:263:    def test_image_extension_update_header(self, home_is_temp):
astropy/io/fits/tests/test_convenience.py:383:    def test_append_filename(self, home_is_temp):
astropy/io/fits/tests/test_groups.py:148:    def test_create_groupdata(self, home_is_temp):
astropy/io/fits/tests/test_header.py:1782:    def test_totxtfile(self, home_is_temp):
astropy/io/fits/tests/test_header.py:1822:    def test_tofile(self, home_is_temp):
astropy/io/fits/tests/test_fitsdiff.py:335:    def test_FITSDiff_report(self, home_is_temp):
astropy/io/fits/tests/conftest.py:23:    produce '~/filename.fits', and environment variables will be temporarily
astropy/io/fits/tests/conftest.py:38:def home_is_temp(request, monkeypatch):
astropy/io/fits/tests/conftest.py:43:    produce '~/filename.fits', and environment variables will be temporarily
astropy/io/fits/tests/conftest.py:63:        self.home_is_temp = False
astropy/io/fits/tests/conftest.py:76:        if self.home_is_temp:
astropy/io/fits/tests/conftest.py:127:        if self.home_is_temp:
astropy/io/fits/tests/conftest.py:130:            # in `home_is_temp`
astropy/io/fits/tests/conftest.py:142:        with '~/' expand to the data directory. Used by the `home_is_data`
astropy/io/fits/tests/conftest.py:154:        with '~/' expand to the temp directory. In conjunction with
astropy/io/fits/tests/conftest.py:157:        in the filesystem. Used by the `home_is_temp` fixture.
astropy/io/fits/tests/conftest.py:159:        self.home_is_temp = True
astropy/io/fits/tests/test_hdulist.py:587:    def test_replace_memmaped_array(self, home_is_temp):
astropy/io/fits/tests/test_hdulist.py:687:    def test_update_resized_header(self, home_is_temp):
astropy/io/fits/tests/test_hdulist.py:736:    def test_update_resized_header2(self, home_is_temp):
astropy/io/fits/tests/test_hdulist.py:824:    def test_save_backup(self, home_is_temp):
astropy/io/fits/tests/test_hdulist.py:949:    def test_overwrite(self, home_is_temp):
```

## 原始行 279 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import ast
fn='astropy/io/fits/convenience.py'; m=ast.parse(open(fn).read())
for n in m.body:
 if isinstance(n,(ast.FunctionDef,ast.ClassDef)): print(n.name,n.lineno,n.end_lineno)
PY
nl -ba astropy/io/fits/convenience.py | tail -260; grep -RIn \"_getext(\" astropy/io/fits/convenience.py astropy/io/fits/tests | head -100"
```

退出码：`0`

输出：
```
getheader 99 128
getdata 131 264
getval 267 298
setval 301 375
delval 378 410
writeto 413 466
table_to_hdu 469 671
append 674 747
update 750 805
info 808 842
printdiff 845 951
tabledump 954 1011
tableload 1018 1049
_makehdu 1131 1146
_stat_filename_or_fileobj 1149 1164
   909	    has_extensions = args or extension
   910	
   911	    if isinstance(inputa, str) and has_extensions:
   912	        # Use handy _getext to interpret any ext keywords, but
   913	        # will need to close a if  fails
   914	        modea, closeda = _get_file_mode(inputa)
   915	        modeb, closedb = _get_file_mode(inputb)
   916	
   917	        hdulista, extidxa = _getext(inputa, modea, *args, **extension)
   918	        # Have to close a if b doesn't make it
   919	        try:
   920	            hdulistb, extidxb = _getext(inputb, modeb, *args, **extension)
   921	        except Exception:
   922	            hdulista.close(closed=closeda)
   923	            raise
   924	
   925	        try:
   926	            hdua = hdulista[extidxa]
   927	            hdub = hdulistb[extidxb]
   928	            # See below print for note
   929	            print(HDUDiff(hdua, hdub, **kwargs).report())
   930	
   931	        finally:
   932	            hdulista.close(closed=closeda)
   933	            hdulistb.close(closed=closedb)
   934	
   935	    # If input is not a string, can feed HDU objects or HDUList directly,
   936	    # but can't currently handle extensions
   937	    elif isinstance(inputa, _ValidHDU) and has_extensions:
   938	        raise ValueError("Cannot use extension keywords when providing an HDU object.")
   939	
   940	    elif isinstance(inputa, _ValidHDU) and not has_extensions:
   941	        print(HDUDiff(inputa, inputb, **kwargs).report())
   942	
   943	    elif isinstance(inputa, HDUList) and has_extensions:
   944	        raise NotImplementedError(
   945	            "Extension specification with HDUList objects not implemented."
   946	        )
   947	
   948	    # This function is EXCLUSIVELY for printing the diff report to screen
   949	    # in a one-liner call, hence the use of print instead of logging
   950	    else:
   951	        print(FITSDiff(inputa, inputb, **kwargs).report())
   952	
   953	
   954	def tabledump(filename, datafile=None, cdfile=None, hfile=None, ext=1, overwrite=False):
   955	    """
   956	    Dump a table HDU to a file in ASCII format.  The table may be
   957	    dumped in three separate files, one containing column definitions,
   958	    one containing header parameters, and one for table data.
   959	
   960	    Parameters
   961	    ----------
   962	    filename : path-like or file-like
   963	        Input fits file.
   964	
   965	    datafile : path-like or file-like, optional
   966	        Output data file.  The default is the root name of the input
   967	        fits file appended with an underscore, followed by the
   968	        extension number (ext), followed by the extension ``.txt``.
   969	
   970	    cdfile : path-like or file-like, optional
   971	        Output column definitions file.  The default is `None`,
   972	        no column definitions output is produced.
   973	
   974	    hfile : path-like or file-like, optional
   975	        Output header parameters file.  The default is `None`,
   976	        no header parameters output is produced.
   977	
   978	    ext : int
   979	        The number of the extension containing the table HDU to be
   980	        dumped.
   981	
   982	    overwrite : bool, optional
   983	        If ``True``, overwrite the output file if it exists. Raises an
   984	        ``OSError`` if ``False`` and the output file exists. Default is
   985	        ``False``.
   986	
   987	    Notes
   988	    -----
   989	    The primary use for the `tabledump` function is to allow editing in a
   990	    standard text editor of the table data and parameters.  The
   991	    `tableload` function can be used to reassemble the table from the
   992	    three ASCII files.
   993	    """
   994	    # allow file object to already be opened in any of the valid modes
   995	    # and leave the file in the same state (opened or closed) as when
   996	    # the function was called
   997	
   998	    mode, closed = _get_file_mode(filename, default="readonly")
   999	    f = fitsopen(filename, mode=mode)
  1000	
  1001	    # Create the default data file name if one was not provided
  1002	    try:
  1003	        if not datafile:
  1004	            root, tail = os.path.splitext(f._file.name)
  1005	            datafile = root + "_" + repr(ext) + ".txt"
  1006	
  1007	        # Dump the data from the HDU to the files
  1008	        f[ext].dump(datafile, cdfile, hfile, overwrite)
  1009	    finally:
  1010	        if closed:
  1011	            f.close()
  1012	
  1013	
  1014	if isinstance(tabledump.__doc__, str):
  1015	    tabledump.__doc__ += BinTableHDU._tdump_file_format.replace("\n", "\n    ")
  1016	
  1017	
  1018	def tableload(datafile, cdfile, hfile=None):
  1019	    """
  1020	    Create a table from the input ASCII files.  The input is from up
  1021	    to three separate files, one containing column definitions, one
  1022	    containing header parameters, and one containing column data.  The
  1023	    header parameters file is not required.  When the header
  1024	    parameters file is absent a minimal header is constructed.
  1025	
  1026	    Parameters
  1027	    ----------
  1028	    datafile : path-like or file-like
  1029	        Input data file containing the table data in ASCII format.
  1030	
  1031	    cdfile : path-like or file-like
  1032	        Input column definition file containing the names, formats,
  1033	        display formats, physical units, multidimensional array
  1034	        dimensions, undefined values, scale factors, and offsets
  1035	        associated with the columns in the table.
  1036	
  1037	    hfile : path-like or file-like, optional
  1038	        Input parameter definition file containing the header
  1039	        parameter definitions to be associated with the table.
  1040	        If `None`, a minimal header is constructed.
  1041	
  1042	    Notes
  1043	    -----
  1044	    The primary use for the `tableload` function is to allow the input of
  1045	    ASCII data that was edited in a standard text editor of the table
  1046	    data and parameters.  The tabledump function can be used to create the
  1047	    initial ASCII files.
  1048	    """
  1049	    return BinTableHDU.load(datafile, cdfile, hfile, replace=True)
  1050	
  1051	
  1052	if isinstance(tableload.__doc__, str):
  1053	    tableload.__doc__ += BinTableHDU._tdump_file_format.replace("\n", "\n    ")
  1054	
  1055	
  1056	
  1057	
  1058	
  1059	
  1060	
  1061	
  1062	
  1063	
  1064	
  1065	
  1066	
  1067	
  1068	
  1069	
  1070	
  1071	
  1072	
  1073	
  1074	
  1075	
  1076	
  1077	
  1078	
  1079	
  1080	
  1081	
  1082	
  1083	
  1084	
  1085	
  1086	
  1087	
  1088	
  1089	
  1090	
  1091	
  1092	
  1093	
  1094	
  1095	
  1096	
  1097	
  1098	
  1099	
  1100	
  1101	
  1102	
  1103	
  1104	
  1105	
  1106	
  1107	
  1108	
  1109	
  1110	
  1111	
  1112	
  1113	
  1114	
  1115	
  1116	
  1117	
  1118	
  1119	
  1120	
  1121	
  1122	
  1123	
  1124	
  1125	
  1126	
  1127	
  1128	
  1129	
  1130	
  1131	def _makehdu(data, header):
  1132	    if header is None:
  1133	        header = Header()
  1134	    hdu = _BaseHDU._from_data(data, header)
  1135	    if hdu.__class__ in (_BaseHDU, _ValidHDU):
  1136	        # The HDU type was unrecognized, possibly due to a
  1137	        # nonexistent/incomplete header
  1138	        if (
  1139	            isinstance(data, np.ndarray) and data.dtype.fields is not None
  1140	        ) or isinstance(data, np.recarray):
  1141	            hdu = BinTableHDU(data, header=header)
  1142	        elif isinstance(data, np.ndarray) or _is_dask_array(data):
  1143	            hdu = ImageHDU(data, header=header)
  1144	        else:
  1145	            raise KeyError("Data must be a numpy array.")
  1146	    return hdu
  1147	
  1148	
  1149	def _stat_filename_or_fileobj(filename):
  1150	    if isinstance(filename, os.PathLike):
  1151	        filename = os.fspath(filename)
  1152	    closed = fileobj_closed(filename)
  1153	    name = fileobj_name(filename) or ""
  1154	
  1155	    try:
  1156	        loc = filename.tell()
  1157	    except AttributeError:
  1158	        loc = 0
  1159	
  1160	    noexist_or_empty = (
  1161	        name and (not os.path.exists(name) or (os.path.getsize(name) == 0))
  1162	    ) or (not name and loc == 0)
  1163	
  1164	    return name, closed, noexist_or_empty
  1165	
  1166	
  1167	
  1168	
astropy/io/fits/convenience.py:121:    hdulist, extidx = _getext(filename, mode, *args, **kwargs)
astropy/io/fits/convenience.py:220:    hdulist, extidx = _getext(filename, mode, *args, **kwargs)
astropy/io/fits/convenience.py:369:    hdulist, extidx = _getext(filename, "update", *args, **kwargs)
astropy/io/fits/convenience.py:406:    hdulist, extidx = _getext(filename, "update", *args, **kwargs)
astropy/io/fits/convenience.py:801:    hdulist, _ext = _getext(filename, "update", *args, **kwargs)
astropy/io/fits/convenience.py:917:        hdulista, extidxa = _getext(inputa, modea, *args, **extension)
astropy/io/fits/convenience.py:920:            hdulistb, extidxb = _getext(inputb, modeb, *args, **extension)
astropy/io/fits/tests/test_core.py:325:    def test_getext(self):
astropy/io/fits/tests/test_core.py:332:        hl, ext = _getext(filename, "readonly", 1)
astropy/io/fits/tests/test_core.py:341:        hl, ext = _getext(filename, "readonly", ext=1)
astropy/io/fits/tests/test_core.py:345:        hl, ext = _getext(filename, "readonly", ext=("sci", 2))
astropy/io/fits/tests/test_core.py:356:        hl, ext = _getext(filename, "readonly", "sci")
astropy/io/fits/tests/test_core.py:360:        hl, ext = _getext(filename, "readonly", "sci", 1)
astropy/io/fits/tests/test_core.py:364:        hl, ext = _getext(filename, "readonly", ("sci", 1))
astropy/io/fits/tests/test_core.py:368:        hl, ext = _getext(
astropy/io/fits/tests/test_core.py:377:        hl, ext = _getext(filename, "readonly", extname="sci")
astropy/io/fits/tests/test_core.py:381:        hl, ext = _getext(filename, "readonly", extname="sci", extver=1)
```

## 原始行 282 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,60p' astropy/io/fits/convenience.py; sed -n '300,415p' astropy/io/fits/tests/test_core.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

"""Convenience functions for working with FITS files.

Convenience functions
=====================

The functions in this module provide shortcuts for some of the most basic
operations on FITS files, such as reading and updating the header.  They are
included directly in the 'astropy.io.fits' namespace so that they can be used
like::

    astropy.io.fits.getheader(...)

These functions are primarily for convenience when working with FITS files in
the command-line interpreter.  If performing several operations on the same
file, such as in a script, it is better to *not* use these functions, as each
one must open and re-parse the file.  In such cases it is better to use
:func:`astropy.io.fits.open` and work directly with the
:class:`astropy.io.fits.HDUList` object and underlying HDU objects.

Several of the convenience functions, such as `getheader` and `getdata` support
special arguments for selecting which HDU to use when working with a
multi-extension FITS file.  There are a few supported argument formats for
selecting the HDU.  See the documentation for `getdata` for an
explanation of all the different formats.

.. warning::
    All arguments to convenience functions other than the filename that are
    *not* for selecting the HDU should be passed in as keyword
    arguments.  This is to avoid ambiguity and conflicts with the
    HDU arguments.  For example, to set NAXIS=1 on the Primary HDU:

    Wrong::

        astropy.io.fits.setval('myimage.fits', 'NAXIS', 1)

    The above example will try to set the NAXIS value on the first extension
    HDU to blank.  That is, the argument '1' is assumed to specify an
    HDU.

    Right::

        astropy.io.fits.setval('myimage.fits', 'NAXIS', value=1)

    This will set the NAXIS keyword to 1 on the primary HDU (the default).  To
    specify the first extension HDU use::

        astropy.io.fits.setval('myimage.fits', 'NAXIS', value=1, ext=1)

    This complexity arises out of the attempt to simultaneously support
    multiple argument formats that were used in past versions of PyFITS.
    Unfortunately, it is not possible to support all formats without
    introducing some ambiguity.  A future Astropy release may standardize
    around a single format and officially deprecate the other formats.
"""

import operator
import os
import warnings
            hdu.verify("silentfix+exception")
        assert "not upper case" not in str(excinfo.value)

        # fix+ignore is not too useful, but it should warn about the fixed
        # problems while saying nothing about the unfixable problems
        hdu = make_invalid_hdu()
        with pytest.warns(fits.verify.VerifyWarning) as w:
            hdu.verify("fix+ignore")
        assert len(w) == 4
        assert "not upper case" not in str(w.list[0].message)

        # fix+warn
        hdu = make_invalid_hdu()
        with pytest.warns(AstropyUserWarning) as w:
            hdu.verify("fix+warn")
        assert len(w) == 6
        assert "not upper case" in str(w[2].message)
        assert "Illegal keyword name" in str(w[4].message)

        # fix+exception
        hdu = make_invalid_hdu()
        with pytest.raises(fits.VerifyError, match=r"Illegal keyword name") as excinfo:
            hdu.verify("fix+exception")
        assert "not upper case" in str(excinfo.value)

    def test_getext(self):
        """
        Test the various different ways of specifying an extension header in
        the convenience functions.
        """
        filename = self.data("test0.fits")

        hl, ext = _getext(filename, "readonly", 1)
        assert ext == 1
        hl.close()

        pytest.raises(ValueError, _getext, filename, "readonly", 1, 2)
        pytest.raises(ValueError, _getext, filename, "readonly", (1, 2))
        pytest.raises(ValueError, _getext, filename, "readonly", "sci", "sci")
        pytest.raises(TypeError, _getext, filename, "readonly", 1, 2, 3)

        hl, ext = _getext(filename, "readonly", ext=1)
        assert ext == 1
        hl.close()

        hl, ext = _getext(filename, "readonly", ext=("sci", 2))
        assert ext == ("sci", 2)
        hl.close()

        pytest.raises(
            TypeError, _getext, filename, "readonly", 1, ext=("sci", 2), extver=3
        )
        pytest.raises(
            TypeError, _getext, filename, "readonly", ext=("sci", 2), extver=3
        )

        hl, ext = _getext(filename, "readonly", "sci")
        assert ext == ("sci", 1)
        hl.close()

        hl, ext = _getext(filename, "readonly", "sci", 1)
        assert ext == ("sci", 1)
        hl.close()

        hl, ext = _getext(filename, "readonly", ("sci", 1))
        assert ext == ("sci", 1)
        hl.close()

        hl, ext = _getext(
            filename, "readonly", "sci", extver=1, do_not_scale_image_data=True
        )
        assert ext == ("sci", 1)
        hl.close()

        pytest.raises(TypeError, _getext, filename, "readonly", "sci", ext=1)
        pytest.raises(TypeError, _getext, filename, "readonly", "sci", 1, extver=2)

        hl, ext = _getext(filename, "readonly", extname="sci")
        assert ext == ("sci", 1)
        hl.close()

        hl, ext = _getext(filename, "readonly", extname="sci", extver=1)
        assert ext == ("sci", 1)
        hl.close()

        pytest.raises(TypeError, _getext, filename, "readonly", extver=1)

    def test_extension_name_case_sensitive(self):
        """
        Tests that setting fits.conf.extension_name_case_sensitive at
        runtime works.
        """

        hdu = fits.ImageHDU()
        hdu.name = "sCi"
        assert hdu.name == "SCI"
        assert hdu.header["EXTNAME"] == "SCI"

        with fits.conf.set_temp("extension_name_case_sensitive", True):
            hdu = fits.ImageHDU()
            hdu.name = "sCi"
            assert hdu.name == "sCi"
            assert hdu.header["EXTNAME"] == "sCi"

        hdu.name = "sCi"
        assert hdu.name == "SCI"
        assert hdu.header["EXTNAME"] == "SCI"

    def test_hdu_fromstring(self):
        """
        Tests creating a fully-formed HDU object from a string containing the
        bytes of the HDU.
        """
        infile = self.data("test0.fits")
        outfile = self.temp("test.fits")
```

## 原始行 284 · command_execution

命令：
```
/bin/bash -lc "sed -n '60,98p' astropy/io/fits/convenience.py"
```

退出码：`0`

输出：
```
import warnings

import numpy as np

from astropy.utils.exceptions import AstropyUserWarning

from .diff import FITSDiff, HDUDiff
from .file import FILE_MODES, _File
from .hdu.base import _BaseHDU, _ValidHDU
from .hdu.hdulist import HDUList, fitsopen
from .hdu.image import ImageHDU, PrimaryHDU
from .hdu.table import BinTableHDU
from .header import Header
from .util import _is_dask_array, fileobj_mode, path_like








__all__ = [
    "append",
    "delval",
    "getdata",
    "getheader",
    "getval",
    "info",
    "printdiff",
    "setval",
    "table_to_hdu",
    "tabledump",
    "tableload",
    "update",
    "writeto",
]
```

## 原始行 287 · file_change

```
{
  "id": "item_186",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/convenience.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 290 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,48p' astropy/io/fits/tests/conftest.py; python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_write_read_gzip_file astropy/io/fits/tests/test_core.py::TestHDU::test_writeto -q --disable-warnings --maxfail=1"
```

退出码：`4`

输出：
```
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import os
import pathlib
import shutil
import stat
import tempfile
import time

import pytest

from astropy.io import fits


@pytest.fixture(
    params=[False, "str", "pathlib"], ids=["", "home_is_data", "home_is_data, pathlib"]
)
def home_is_data(request, monkeypatch):
    """
    Pytest fixture to run a test case both with and without tilde paths.

    In the tilde-path case, calls like self.data('filename.fits') will
    produce '~/filename.fits', and environment variables will be temporarily
    modified so that '~' resolves to the data directory.
    """
    # This checks the value specified in the fixture annotation
    if request.param:
        # `request.instance` refers to the test case that's using this fixture.
        request.instance.monkeypatch = monkeypatch
        request.instance.set_home_as_data()

        request.instance.set_paths_via_pathlib(request.param == "pathlib")


@pytest.fixture(
    params=[False, "str", "pathlib"], ids=["", "home_is_data", "home_is_data, pathlib"]
)
def home_is_temp(request, monkeypatch):
    """
    Pytest fixture to run a test case both with and without tilde paths.

    In the tilde-path case, calls like self.temp('filename.fits') will
    produce '~/filename.fits', and environment variables will be temporarily
    modified so that '~' resolves to the temp directory. These files will also
    be tracked so that, after the test case, we can verify no files were written
    to a literal tilde path.
    """
    # This checks the value specified in the fixture annotation
ERROR: not found: /testbed/astropy/io/fits/tests/test_core.py::TestHDU::test_writeto
(no match in any of [<DocTestModulePlus test_core.py>, <Module test_core.py>])

Internet access disabled

no tests ran in 0.04s
```

## 原始行 293 · command_execution

命令：
```
/bin/bash -lc "sed -n '520,620p' astropy/io/fits/tests/test_core.py | grep -B10 -A5 '"'^class'"\\|def test_writeto'; grep -n \"class .*\" astropy/io/fits/tests/test_core.py | head -20"
```

退出码：`0`

输出：
```
                    for hdul in (hdul1, hdul3):
                        for idx, hdus in enumerate(zip(hdul2, hdul)):
                            hdu2, hdu = hdus
                            if idx != 1:
                                assert hdu.header == hdu2.header
                            else:
                                assert hdu2.header == hdu.header[: len(hdu2.header)]
                            assert np.all(hdu.data == hdu2.data)


class TestConvenienceFunctions(FitsTestCase):
    def test_writeto(self, home_is_temp):
        """
        Simple test for writing a trivial header and some data to a file
        with the `writeto()` convenience function.
        """
        filename = self.temp("array.fits")
        data = np.zeros((100, 100))
        header = fits.Header()
        fits.writeto(filename, data, header=header, overwrite=True)
        with fits.open(filename) as hdul:
            assert len(hdul) == 1
            assert (data == hdul[0].data).all()

    def test_writeto_2(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/107

        Test of `writeto()` with a trivial header containing a single keyword.
        """
--
        header.set("CRPIX1", 1.0)
        fits.writeto(
            filename, data, header=header, overwrite=True, output_verify="silentfix"
        )
        with fits.open(filename) as hdul:
            assert len(hdul) == 1
            assert (data == hdul[0].data).all()
            assert "CRPIX1" in hdul[0].header
            assert hdul[0].header["CRPIX1"] == 1.0

    def test_writeto_overwrite(self, home_is_temp):
        """
        Ensure the `overwrite` keyword works as it should
        """
        filename = self.temp("array.fits")
        data = np.zeros((100, 100))
--

        with pytest.raises(OSError, match=_NOT_OVERWRITING_MSG_MATCH):
            fits.writeto(filename, data, header=header, overwrite=False)

        fits.writeto(filename, data, header=header, overwrite=True)

        with fits.open(filename) as hdul:
            assert len(hdul) == 1
            assert (data == hdul[0].data).all()

    def test_writeto_stdout(self):
        # see https://github.com/astropy/astropy/issues/3427
        fits.writeto(sys.stdout, data=np.array([1, 2]))


class TestFileFunctions(FitsTestCase):
45:class TestCore(FitsTestCase):
92:        class TPath(os.PathLike):
221:        class TestHDU(fits.hdu.base.NonstandardExtHDU):
229:                # Since creating this HDU class adds it to the registry we
564:class TestConvenienceFunctions(FitsTestCase):
620:class TestFileFunctions(FitsTestCase):
1197:        class MockMmap(mmap.mmap):
1316:        class MyFileLike:
1545:class TestStreamingFunctions(FitsTestCase):
```

## 原始行 296 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto_overwrite astropy/io/fits/tests/test_core.py::TestFileFunctions::test_write_read_gzip_file -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
..F
=================================== FAILURES ===================================
_________ TestConvenienceFunctions.test_writeto[home_is_data, pathlib] _________

self = <astropy.io.fits.hdu.image.PrimaryHDU object at 0x7b2253abc810>
name = PosixPath('~/array.fits'), output_verify = 'exception', overwrite = True
checksum = False

    def writeto(self, name, output_verify="exception", overwrite=False, checksum=False):
        """
        Write the HDU to a new file. This is a convenience method to
        provide a user easier output interface if only one HDU needs
        to be written to a file.
    
        Parameters
        ----------
        name : path-like or file-like
            Output FITS file.  If the file object is already opened, it must
            be opened in a writeable mode.
    
        output_verify : str
            Output verification option.  Must be one of ``"fix"``,
            ``"silentfix"``, ``"ignore"``, ``"warn"``, or
            ``"exception"``.  May also be any combination of ``"fix"`` or
            ``"silentfix"`` with ``"+ignore"``, ``"+warn"``, or ``"+exception"``
            (e.g. ``"fix+warn"``).  See :ref:`astropy:verify` for more info.
    
        overwrite : bool, optional
            If ``True``, overwrite the output file if it exists. Raises an
            ``OSError`` if ``False`` and the output file exists. Default is
            ``False``.
    
        checksum : bool
            When `True` adds both ``DATASUM`` and ``CHECKSUM`` cards
            to the header of the HDU when written to the file.
    
        Notes
        -----
        gzip, zip, bzip2 and lzma compression algorithms are natively supported.
        Compression mode is determined from the filename extension
        ('.gz', '.zip', '.bz2' or '.xz' respectively).  It is also possible to
        pass a compressed file object, e.g. `gzip.GzipFile`.
        """
        from .hdulist import HDUList
    
        hdulist = HDUList([self])
>       hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
E       ResourceWarning: unclosed file <_io.BufferedWriter name='/tmp/fits-test-gxhzq45k/array.fits'>

astropy/io/fits/hdu/base.py:479: ResourceWarning

The above exception was the direct cause of the following exception:

cls = <class '_pytest.runner.CallInfo'>
func = <function call_and_report.<locals>.<lambda> at 0x7b2253a936a0>
when = 'call'
reraise = (<class '_pytest.outcomes.Exit'>, <class 'KeyboardInterrupt'>)

    @classmethod
    def from_call(
        cls,
        func: Callable[[], TResult],
        when: Literal["collect", "setup", "call", "teardown"],
        reraise: type[BaseException] | tuple[type[BaseException], ...] | None = None,
    ) -> CallInfo[TResult]:
        """Call func, wrapping the result in a CallInfo.
    
        :param func:
            The function to call. Called without arguments.
        :type func: Callable[[], _pytest.runner.TResult]
        :param when:
            The phase in which the function is called.
        :param reraise:
            Exception or exceptions that shall propagate if raised by the
            function, instead of being wrapped in the CallInfo.
        """
        excinfo = None
        instant = timing.Instant()
        try:
>           result: TResult | None = func()
                                     ^^^^^^

/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py:353: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py:245: in <lambda>
    lambda: runtest_hook(item=item, **kwds),
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_hooks.py:512: in __call__
    return self._hookexec(self.name, self._hookimpls.copy(), kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_manager.py:120: in _hookexec
    return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/logging.py:850: in pytest_runtest_call
    yield
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py:53: in run_old_style_hookwrapper
    return result.get_result()
           ^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py:38: in run_old_style_hookwrapper
    res = yield
          ^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/capture.py:900: in pytest_runtest_call
    return (yield)
            ^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py:53: in run_old_style_hookwrapper
    return result.get_result()
           ^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py:38: in run_old_style_hookwrapper
    res = yield
          ^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py:53: in run_old_style_hookwrapper
    return result.get_result()
           ^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py:38: in run_old_style_hookwrapper
    res = yield
          ^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/skipping.py:268: in pytest_runtest_call
    return (yield)
            ^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py:158: in pytest_runtest_call
    collect_unraisable(item.config)
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py:79: in collect_unraisable
    raise errors[0]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

config = <_pytest.config.Config object at 0x7b22800eef10>

    def collect_unraisable(config: Config) -> None:
        pop_unraisable = config.stash[unraisable_exceptions].pop
        errors: list[pytest.PytestUnraisableExceptionWarning | RuntimeError] = []
        meta = None
        hook_error = None
        try:
            while True:
                try:
                    meta = pop_unraisable()
                except IndexError:
                    break
    
                if isinstance(meta, BaseException):
                    hook_error = RuntimeError("Failed to process unraisable exception")
                    hook_error.__cause__ = meta
                    errors.append(hook_error)
                    continue
    
                msg = meta.msg
                try:
>                   warnings.warn(pytest.PytestUnraisableExceptionWarning(msg))
E                   pytest.PytestUnraisableExceptionWarning: Exception ignored in: <_io.FileIO name='/tmp/fits-test-gxhzq45k/array.fits' mode='wb' closefd=True>
E                   Enable tracemalloc to get traceback where the object was allocated.
E                   See https://docs.pytest.org/en/stable/how-to/capture-warnings.html#resource-warnings for more info.

/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py:67: PytestUnraisableExceptionWarning
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto[home_is_data, pathlib]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 2 passed in 0.12s
```

## 原始行 299 · file_change

```
{
  "id": "item_194",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/hdulist.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 301 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto_overwrite astropy/io/fits/tests/test_core.py::TestFileFunctions::test_write_read_gzip_file -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
.........                                                                [100%]
9 passed in 0.07s
```

## 原始行 304 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_totxtfile astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_tofile astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_append_use_blanks astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_insert_use_blanks astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_count -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
_____________________ TestHeaderFunctions.test_totxtfile[] _____________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7544576b6f10>
home_is_temp = None

    def test_totxtfile(self, home_is_temp):
        header_filename = self.temp("header.txt")
        with fits.open(self.data("test0.fits")) as hdul:
            hdul[0].header.totextfile(header_filename)
            # Check the `overwrite` flag
            with pytest.raises(OSError, match=_NOT_OVERWRITING_MSG_MATCH):
>               hdul[0].header.totextfile(header_filename, overwrite=False)

astropy/io/fits/tests/test_header.py:1788: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/header.py:841: in totextfile
    self.tofile(
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = SIMPLE  =                    T / file does conform to FITS standard             
BITPIX  =                   16 / numb...interruption indicator                
FILENAME= 'vtest3.fits'        / File name                                      
fileobj = '/tmp/fits-test-o57073y6/header.txt', sep = '\n', endcard = False
padding = False, overwrite = False

    def tofile(self, fileobj, sep="", endcard=True, padding=True, overwrite=False):
        """Write the header to a filename or an open file object."""
        close_file = False
        if isinstance(fileobj, path_like):
            fileobj = os.path.expanduser(fileobj)
            if os.path.exists(fileobj) and os.path.getsize(fileobj) and not overwrite:
>               raise OSError(f"File {fileobj!r} already exists.")
E               OSError: File '/tmp/fits-test-o57073y6/header.txt' already exists.

astropy/io/fits/header.py:741: OSError

During handling of the above exception, another exception occurred:

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7544576b6f10>
home_is_temp = None

    def test_totxtfile(self, home_is_temp):
        header_filename = self.temp("header.txt")
        with fits.open(self.data("test0.fits")) as hdul:
            hdul[0].header.totextfile(header_filename)
            # Check the `overwrite` flag
>           with pytest.raises(OSError, match=_NOT_OVERWRITING_MSG_MATCH):
E           AssertionError: Regex pattern did not match.
E             Expected regex: 'File .* already exists\\. If you mean to replace it then use the argument "overwrite=True"\\.'
E             Actual message: "File '/tmp/fits-test-o57073y6/header.txt' already exists."

astropy/io/fits/tests/test_header.py:1787: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_totxtfile[]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.14s
```

## 原始行 307 · file_change

```
{
  "id": "item_199",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 309 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_totxtfile astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_tofile astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_append_use_blanks astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_insert_use_blanks astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_header_count -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
.........                                                                [100%]
9 passed in 0.13s
```

## 原始行 312 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_fitsheader.py -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
..........                                                               [100%]
10 passed in 0.12s
```

## 原始行 315 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def test_.*dump\\|def test_.*load\" astropy/io/fits/tests/test_table.py astropy/io/fits/tests/test_convenience.py | head -50"
```

退出码：`0`

输出：
```
astropy/io/fits/tests/test_table.py:2346:    def test_dump_load_round_trip(self, tablename):
astropy/io/fits/tests/test_table.py:2366:    def test_dump_load_array_colums(self):
astropy/io/fits/tests/test_table.py:2387:    def test_load_guess_format(self):
astropy/io/fits/tests/test_table.py:2611:    def test_unncessary_table_load(self):
astropy/io/fits/tests/test_table.py:2898:    def test_dump_overwrite(self):
astropy/io/fits/tests/test_convenience.py:323:    def test_tabledump(self):
astropy/io/fits/tests/test_convenience.py:364:    def test_dump_load_round_trip(self, tablename):
```

## 原始行 318 · command_execution

命令：
```
/bin/bash -lc "sed -n '2300,2420p' astropy/io/fits/tests/test_table.py; python -m pytest astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite -q --disable-warnings --maxfail=1"
```

退出码：`1`

输出：
```
        s2 = data[np.where(data["target"] == "NGC1001")]
        s3 = data[[0]]
        s4 = data[:1]
        for s in [s1, s2, s3, s4]:
            assert isinstance(s, fits.FITS_rec)

        assert comparerecords(s1, s2)
        assert comparerecords(s2, s3)
        assert comparerecords(s3, s4)

    def test_array_broadcasting(self):
        """
        Regression test for https://github.com/spacetelescope/PyFITS/pull/48
        """

        with fits.open(self.data("table.fits")) as hdu:
            data = hdu[1].data
            data["V_mag"] = 0
            assert np.all(data["V_mag"] == 0)

            data["V_mag"] = 1
            assert np.all(data["V_mag"] == 1)

            for container in (list, tuple, np.array):
                data["V_mag"] = container([1, 2, 3])
                assert np.array_equal(data["V_mag"], np.array([1, 2, 3]))

    def test_array_slicing_readonly(self):
        """
        Like test_array_slicing but with the file opened in 'readonly' mode.
        Regression test for a crash when slicing readonly memmap'd tables.
        """

        with fits.open(self.data("table.fits"), mode="readonly") as f:
            data = f[1].data
        s1 = data[data["target"] == "NGC1001"]
        s2 = data[np.where(data["target"] == "NGC1001")]
        s3 = data[[0]]
        s4 = data[:1]
        for s in [s1, s2, s3, s4]:
            assert isinstance(s, fits.FITS_rec)
        assert comparerecords(s1, s2)
        assert comparerecords(s2, s3)
        assert comparerecords(s3, s4)

    @pytest.mark.parametrize("tablename", ["table.fits", "tb.fits"])
    def test_dump_load_round_trip(self, tablename):
        """
        A simple test of the dump/load methods; dump the data, column, and
        header files and try to reload the table from them.
        """

        with fits.open(self.data(tablename)) as hdul:
            tbhdu = hdul[1]
            datafile = self.temp("data.txt")
            cdfile = self.temp("coldefs.txt")
            hfile = self.temp("header.txt")

            tbhdu.dump(datafile, cdfile, hfile)

            new_tbhdu = fits.BinTableHDU.load(datafile, cdfile, hfile)

            assert comparerecords(tbhdu.data, new_tbhdu.data)

            _assert_attr_col(new_tbhdu, hdul[1])

    def test_dump_load_array_colums(self):
        """
        Regression test for https://github.com/spacetelescope/PyFITS/issues/22

        Ensures that a table containing a multi-value array column can be
        dumped and loaded successfully.
        """

        data = np.rec.array(
            [("a", [1, 2, 3, 4], 0.1), ("b", [5, 6, 7, 8], 0.2)], formats="S1,4i4,f8"
        )
        tbhdu = fits.BinTableHDU.from_columns(data)
        datafile = self.temp("data.txt")
        cdfile = self.temp("coldefs.txt")
        hfile = self.temp("header.txt")

        tbhdu.dump(datafile, cdfile, hfile)
        new_tbhdu = fits.BinTableHDU.load(datafile, cdfile, hfile)
        assert comparerecords(tbhdu.data, new_tbhdu.data)
        assert str(tbhdu.header) == str(new_tbhdu.header)

    def test_load_guess_format(self):
        """
        Tests loading a table dump with no supplied coldefs or header, so that
        the table format has to be guessed at.  There is of course no exact
        science to this; the table that's produced simply uses sensible guesses
        for that format.  Ideally this should never have to be used.
        """

        # Create a table containing a variety of data types.
        a0 = np.array([False, True, False], dtype=bool)
        c0 = fits.Column(name="c0", format="L", array=a0)

        # Format X currently not supported by the format
        # a1 = np.array([[0], [1], [0]], dtype=np.uint8)
        # c1 = fits.Column(name='c1', format='X', array=a1)

        a2 = np.array([1, 128, 255], dtype=np.uint8)
        c2 = fits.Column(name="c2", format="B", array=a2)
        a3 = np.array([-30000, 1, 256], dtype=np.int16)
        c3 = fits.Column(name="c3", format="I", array=a3)
        a4 = np.array([-123123123, 1234, 123123123], dtype=np.int32)
        c4 = fits.Column(name="c4", format="J", array=a4)
        a5 = np.array(["a", "abc", "ab"])
        c5 = fits.Column(name="c5", format="A3", array=a5)
        a6 = np.array([1.1, 2.2, 3.3], dtype=np.float64)
        c6 = fits.Column(name="c6", format="D", array=a6)
        a7 = np.array([1.1 + 2.2j, 3.3 + 4.4j, 5.5 + 6.6j], dtype=np.complex128)
        c7 = fits.Column(name="c7", format="M", array=a7)
        a8 = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9]], dtype=np.int32)
        c8 = fits.Column(name="c8", format="PJ()", array=a8)

        tbhdu = fits.BinTableHDU.from_columns([c0, c2, c3, c4, c5, c6, c7, c8])

        datafile = self.temp("data.txt")
Internet access disabled
F
=================================== FAILURES ===================================
____________________ TestTableFunctions.test_dump_overwrite ____________________

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x72c0a01d5d90>

    def test_dump_overwrite(self):
        with fits.open(self.data("table.fits")) as hdul:
            tbhdu = hdul[1]
            datafile = self.temp("data.txt")
            cdfile = self.temp("coldefs.txt")
            hfile = self.temp("header.txt")
            tbhdu.dump(datafile, cdfile, hfile)
            msg = (
                r"File .* already exists\.  File .* already exists\.  File "
                r".* already exists\.  If you mean to replace the "
                r"file\(s\) then use the argument 'overwrite=True'\."
            )
            with pytest.raises(OSError, match=msg):
>               tbhdu.dump(datafile, cdfile, hfile)

astropy/io/fits/tests/test_table.py:2911: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.table.BinTableHDU object at 0x72c0a01bc8d0>
datafile = '/tmp/fits-test-epz2wcg3/data.txt'
cdfile = '/tmp/fits-test-epz2wcg3/coldefs.txt'
hfile = '/tmp/fits-test-epz2wcg3/header.txt', overwrite = False

    def dump(self, datafile=None, cdfile=None, hfile=None, overwrite=False):
        """
        Dump the table HDU to a file in ASCII format.  The table may be dumped
        in three separate files, one containing column definitions, one
        containing header parameters, and one for table data.
    
        Parameters
        ----------
        datafile : path-like or file-like, optional
            Output data file.  The default is the root name of the
            fits file associated with this HDU appended with the
            extension ``.txt``.
    
        cdfile : path-like or file-like, optional
            Output column definitions file.  The default is `None`, no
            column definitions output is produced.
    
        hfile : path-like or file-like, optional
            Output header parameters file.  The default is `None`,
            no header parameters output is produced.
    
        overwrite : bool, optional
            If ``True``, overwrite the output file if it exists. Raises an
            ``OSError`` if ``False`` and the output file exists. Default is
            ``False``.
    
        Notes
        -----
        The primary use for the `dump` method is to allow viewing and editing
        the table data and parameters in a standard text editor.
        The `load` method can be used to create a new table from the three
        plain text (ASCII) files.
        """
        if isinstance(datafile, path_like):
            datafile = os.path.expanduser(datafile)
        if isinstance(cdfile, path_like):
            cdfile = os.path.expanduser(cdfile)
        if isinstance(hfile, path_like):
            hfile = os.path.expanduser(hfile)
        # check if the output files already exist
        exist = []
        files = [datafile, cdfile, hfile]
    
        for f in files:
            if isinstance(f, path_like):
                if os.path.exists(f) and os.path.getsize(f) != 0:
                    if overwrite:
                        os.remove(f)
                    else:
                        exist.append(f)
    
        if exist:
>           raise OSError(
                "  ".join([f"File '{f}' already exists." for f in exist])
                + "  If you mean to replace the file(s) then use the argument "
                "'overwrite=True'."
            )
E           OSError: File '/tmp/fits-test-epz2wcg3/coldefs.txt' already exists.  File '/tmp/fits-test-epz2wcg3/header.txt' already exists.  If you mean to replace the file(s) then use the argument 'overwrite=True'.

astropy/io/fits/hdu/table.py:1080: OSError

During handling of the above exception, another exception occurred:

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x72c0a01d5d90>

    def test_dump_overwrite(self):
        with fits.open(self.data("table.fits")) as hdul:
            tbhdu = hdul[1]
            datafile = self.temp("data.txt")
            cdfile = self.temp("coldefs.txt")
            hfile = self.temp("header.txt")
            tbhdu.dump(datafile, cdfile, hfile)
            msg = (
                r"File .* already exists\.  File .* already exists\.  File "
                r".* already exists\.  If you mean to replace the "
                r"file\(s\) then use the argument 'overwrite=True'\."
            )
>           with pytest.raises(OSError, match=msg):
E           AssertionError: Regex pattern did not match.
E             Expected regex: "File .* already exists\\.  File .* already exists\\.  File .* already exists\\.  If you mean to replace the file\\(s\\) then use the argument 'overwrite=True'\\."
E             Actual message: "File '/tmp/fits-test-epz2wcg3/coldefs.txt' already exists.  File '/tmp/fits-test-epz2wcg3/header.txt' already exists.  If you mean to replace the file(s) then use the argument 'overwrite=True'."

astropy/io/fits/tests/test_table.py:2910: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.77s
```

## 原始行 321 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile,os
from astropy.io import fits
p='astropy/io/fits/tests/data/table.fits'
with fits.open(p) as x:
 print(len(x), x[1].size, x[1]._data_size, x[1].data.shape, len(x[1].data))
 root=tempfile.mkdtemp(); paths=[root+'/'+n for n in ['d','c','h']]; x[1].dump(*paths); print([os.path.getsize(q) for q in paths])
PY"
```

退出码：`0`

输出：
```
2 72 2880 (0,) 0
[0, 223, 971]
```

## 原始行 324 · command_execution

命令：
```
/bin/bash -lc "sed -n '280,365p' astropy/io/fits/hdu/table.py; grep -n \"NAXIS2\\|_nrows\" astropy/io/fits/hdu/table.py | head -30; python - <<'PY'
from astropy.io import fits
with fits.open('astropy/io/fits/tests/data/table.fits') as x:
 print(x[1].header['NAXIS1'],x[1].header['NAXIS2'],x[1]._nrows if hasattr(x[1],'_nrows') else 'none')
PY"
```

退出码：`0`

输出：
```
    ver : int > 0 or None, optional
        The ver of the HDU, will be the value of the keyword ``EXTVER``.
        If not given or None, it defaults to the value of the ``EXTVER``
        card of the ``header`` or 1.
        (default: None)
    character_as_bytes : bool
        Whether to return bytes for string columns. By default this is `False`
        and (unicode) strings are returned, but this does not respect memory
        mapping and loads the whole column in memory when accessed.
    """

    _manages_own_heap = False
    """
    This flag implies that when writing VLA tables (P/Q format) the heap
    pointers that go into P/Q table columns should not be reordered or
    rearranged in any way by the default heap management code.

    This is included primarily as an optimization for compressed image HDUs
    which perform their own heap maintenance.
    """

    def __init__(
        self,
        data=None,
        header=None,
        name=None,
        uint=False,
        ver=None,
        character_as_bytes=False,
    ):
        super().__init__(data=data, header=header, name=name, ver=ver)

        self._uint = uint
        self._character_as_bytes = character_as_bytes

        if data is DELAYED:
            # this should never happen
            if header is None:
                raise ValueError("No header to setup HDU.")

            # if the file is read the first time, no need to copy, and keep it
            # unchanged
            else:
                self._header = header
        else:
            # construct a list of cards of minimal header
            cards = [
                ("XTENSION", self._extension, self._ext_comment),
                ("BITPIX", 8, "array data type"),
                ("NAXIS", 2, "number of array dimensions"),
                ("NAXIS1", 0, "length of dimension 1"),
                ("NAXIS2", 0, "length of dimension 2"),
                ("PCOUNT", 0, "number of group parameters"),
                ("GCOUNT", 1, "number of groups"),
                ("TFIELDS", 0, "number of table fields"),
            ]

            if header is not None:
                # Make a "copy" (not just a view) of the input header, since it
                # may get modified.  the data is still a "view" (for now)
                hcopy = header.copy(strip=True)
                cards.extend(hcopy.cards)

            self._header = Header(cards)

            if isinstance(data, np.ndarray) and data.dtype.fields is not None:
                # self._data_type is FITS_rec.
                if isinstance(data, self._data_type):
                    self.data = data
                else:
                    self.data = self._data_type.from_columns(data)
            elif data is None:
                pass
            else:
                raise TypeError("Table data has incorrect type.")

        # Ensure that the correct EXTNAME is set on the new header if one was
        # created, or that it overrides the existing EXTNAME if different
        if name:
            self.name = name
        if ver is not None:
            self.ver = ver

    @classmethod
    def match_header(cls, header):
        """
165:    def _nrows(self):
189:            tbsize = self._header["NAXIS1"] * self._header["NAXIS2"]
192:            raw_data = self._get_raw_data(self._nrows, columns.dtype, self._data_offset)
218:        data._tbsize = self._header["NAXIS1"] * self._header["NAXIS2"]
243:            nrows=self._nrows,
256:            nrows=self._nrows,
331:                ("NAXIS2", 0, "length of dimension 2"),
450:    def _nrows(self):
452:            return self._header.get("NAXIS2", 0)
458:        size = self._header["NAXIS1"] * self._header["NAXIS2"]
466:        self._header.set("NAXIS2", self.data.shape[0], after="NAXIS1")
483:            # check TFIELDS and NAXIS2
485:            self._header["NAXIS2"] = self.data.shape[0]
488:            tbsize = self._header["NAXIS1"] * self._header["NAXIS2"]
568:            nrows = self._header["NAXIS2"]
759:        raw_data = self._get_raw_data(self._nrows, dtype, self._data_offset)
24 3 3
```

## 原始行 326 · command_execution

命令：
```
/bin/bash -lc "sed -n '130,230p' astropy/io/fits/hdu/table.py; sed -n '430,460p' astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```
        fill : bool
            If `True`, will fill all cells with zeros or blanks.  If `False`,
            copy the data from input, undefined cells will still be filled with
            zeros/blanks.

        character_as_bytes : bool
            Whether to return bytes for string columns when accessed from the
            HDU. By default this is `False` and (unicode) strings are returned,
            but for large tables this may use up a lot of memory.

        Notes
        -----
        Any additional keyword arguments accepted by the HDU class's
        ``__init__`` may also be passed in as keyword arguments.
        """
        coldefs = cls._columns_type(columns)
        data = FITS_rec.from_columns(
            coldefs, nrows=nrows, fill=fill, character_as_bytes=character_as_bytes
        )
        hdu = cls(
            data=data, header=header, character_as_bytes=character_as_bytes, **kwargs
        )
        coldefs._add_listener(hdu)
        return hdu

    @lazyproperty
    def columns(self):
        """
        The :class:`ColDefs` objects describing the columns in this table.
        """
        # The base class doesn't make any assumptions about where the column
        # definitions come from, so just return an empty ColDefs
        return ColDefs([])

    @property
    def _nrows(self):
        """
        table-like HDUs must provide an attribute that specifies the number of
        rows in the HDU's table.

        For now this is an internal-only attribute.
        """
        raise NotImplementedError

    def _get_tbdata(self):
        """Get the table data from an input HDU object."""
        columns = self.columns

        # TODO: Details related to variable length arrays need to be dealt with
        # specifically in the BinTableHDU class, since they're a detail
        # specific to FITS binary tables
        if (
            self._load_variable_length_data
            and any(type(r) in (_FormatP, _FormatQ) for r in columns._recformats)
            and self._data_size is not None
            and self._data_size > self._theap
        ):
            # We have a heap; include it in the raw_data
            raw_data = self._get_raw_data(self._data_size, np.uint8, self._data_offset)
            tbsize = self._header["NAXIS1"] * self._header["NAXIS2"]
            data = raw_data[:tbsize].view(dtype=columns.dtype, type=np.rec.recarray)
        else:
            raw_data = self._get_raw_data(self._nrows, columns.dtype, self._data_offset)
            if raw_data is None:
                # This can happen when a brand new table HDU is being created
                # and no data has been assigned to the columns, which case just
                # return an empty array
                raw_data = np.array([], dtype=columns.dtype)

            data = raw_data.view(np.rec.recarray)

        self._init_tbdata(data)
        data = data.view(self._data_type)
        data._load_variable_length_data = self._load_variable_length_data
        columns._add_listener(data)
        return data

    def _init_tbdata(self, data):
        columns = self.columns

        data.dtype = data.dtype.newbyteorder(">")

        # hack to enable pseudo-uint support
        data._uint = self._uint

        # pass datLoc, for P format
        data._heapoffset = self._theap
        data._heapsize = self._header["PCOUNT"]
        data._tbsize = self._header["NAXIS1"] * self._header["NAXIS2"]
        data._gap = self._theap - data._tbsize

        # pass the attributes
        for idx, col in enumerate(columns):
            # get the data for each column object from the rec.recarray
            col.array = data.field(idx)

        # delete the _arrays attribute so that it is recreated to point to the
        # new data placed in the column object above
        del columns._arrays

    def _update_load_data(self):
            with suppress(TypeError, AttributeError):
                # Make the ndarrays in the Column objects of the ColDefs
                # object of the HDU reference the same ndarray as the HDU's
                # FITS_rec object.
                for idx, col in enumerate(self.columns):
                    col.array = self.data.field(idx)

                # Delete the _arrays attribute so that it is recreated to
                # point to the new data placed in the column objects above
                del self.columns._arrays
        elif data is None:
            pass
        else:
            raise TypeError("Table data has incorrect type.")

        # returning the data signals to lazyproperty that we've already handled
        # setting self.__dict__['data']
        return data

    @property
    def _nrows(self):
        if not self._data_loaded:
            return self._header.get("NAXIS2", 0)
        else:
            return len(self.data)

    @property
    def _theap(self):
        size = self._header["NAXIS1"] * self._header["NAXIS2"]
        return self._header.get("THEAP", size)
```

## 原始行 329 · file_change

```
{
  "id": "item_213",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 331 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io import fits
with fits.open('astropy/io/fits/tests/data/table.fits') as x: print(x[1].data.shape, x[1].data['target'])
PY
python -m pytest astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip -q --disable-warnings --maxfail=1"
```

退出码：`1`

输出：
```
(3,) ['NGC1001' 'NGC1002' 'NGC1003']
Internet access disabled
.F
=================================== FAILURES ===================================
___________ TestTableFunctions.test_dump_load_round_trip[table.fits] ___________

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x7a4e7bc53f10>
tablename = 'table.fits'

    @pytest.mark.parametrize("tablename", ["table.fits", "tb.fits"])
    def test_dump_load_round_trip(self, tablename):
        """
        A simple test of the dump/load methods; dump the data, column, and
        header files and try to reload the table from them.
        """
    
        with fits.open(self.data(tablename)) as hdul:
            tbhdu = hdul[1]
            datafile = self.temp("data.txt")
            cdfile = self.temp("coldefs.txt")
            hfile = self.temp("header.txt")
    
            tbhdu.dump(datafile, cdfile, hfile)
    
            new_tbhdu = fits.BinTableHDU.load(datafile, cdfile, hfile)
    
>           assert comparerecords(tbhdu.data, new_tbhdu.data)
E           AssertionError: assert False
E            +  where False = comparerecords(FITS_rec([('NGC1001', 11.1), ('NGC1002', 12.3), ('NGC1003', 15.2)],\n         dtype=(numpy.record, [('target', 'S20'), ('V_mag', '>f4')])), FITS_rec([('NGC1001             ', 11.10000038),\n          ('NGC1002             ', 12.30000019),\n          ('NGC1003             ', 15.19999981)],\n         dtype=(numpy.record, [('target', 'S20'), ('V_mag', '<f8')])))
E            +    where FITS_rec([('NGC1001', 11.1), ('NGC1002', 12.3), ('NGC1003', 15.2)],\n         dtype=(numpy.record, [('target', 'S20'), ('V_mag', '>f4')])) = <astropy.io.fits.hdu.table.BinTableHDU object at 0x7a4e7bc695d0>.data
E            +    and   FITS_rec([('NGC1001             ', 11.10000038),\n          ('NGC1002             ', 12.30000019),\n          ('NGC1003             ', 15.19999981)],\n         dtype=(numpy.record, [('target', 'S20'), ('V_mag', '<f8')])) = <astropy.io.fits.hdu.table.BinTableHDU object at 0x7a4e7bc43e50>.data

astropy/io/fits/tests/test_table.py:2362: AssertionError
----------------------------- Captured stdout call -----------------------------
fielda:  ['NGC1001' 'NGC1002' 'NGC1003']
fieldb:  ['NGC1001             ' 'NGC1002             ' 'NGC1003             ']
field 0 differs
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip[table.fits]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 1 passed in 0.17s
```

## 原始行 334 · command_execution

命令：
```
/bin/bash -lc "sed -n '1280,1465p' astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```

        if close_file:
            fileobj.close()

    @classmethod
    def _load_data(cls, fileobj, coldefs=None):
        """
        Read the table data from the ASCII file output by BinTableHDU.dump().
        """
        close_file = False

        if isinstance(fileobj, path_like):
            fileobj = os.path.expanduser(fileobj)
            fileobj = open(fileobj)
            close_file = True

        initialpos = fileobj.tell()  # We'll be returning here later
        linereader = csv.reader(fileobj, dialect=FITSTableDumpDialect)

        # First we need to do some preprocessing on the file to find out how
        # much memory we'll need to reserve for the table.  This is necessary
        # even if we already have the coldefs in order to determine how many
        # rows to reserve memory for
        vla_lengths = []
        recformats = []
        names = []
        nrows = 0
        if coldefs is not None:
            recformats = coldefs._recformats
            names = coldefs.names

        def update_recformats(value, idx):
            fitsformat = _scalar_to_format(value)
            recformat = _convert_format(fitsformat)
            if idx >= len(recformats):
                recformats.append(recformat)
            else:
                if _cmp_recformats(recformats[idx], recformat) < 0:
                    recformats[idx] = recformat

        # TODO: The handling of VLAs could probably be simplified a bit
        for row in linereader:
            nrows += 1
            if coldefs is not None:
                continue
            col = 0
            idx = 0
            while idx < len(row):
                if row[idx] == "VLA_Length=":
                    if col < len(vla_lengths):
                        vla_length = vla_lengths[col]
                    else:
                        vla_length = int(row[idx + 1])
                        vla_lengths.append(vla_length)
                    idx += 2
                    while vla_length:
                        update_recformats(row[idx], col)
                        vla_length -= 1
                        idx += 1
                    col += 1
                else:
                    if col >= len(vla_lengths):
                        vla_lengths.append(None)
                    update_recformats(row[idx], col)
                    col += 1
                    idx += 1

        # Update the recformats for any VLAs
        for idx, length in enumerate(vla_lengths):
            if length is not None:
                recformats[idx] = str(length) + recformats[idx]

        dtype = np.rec.format_parser(recformats, names, None).dtype

        # TODO: In the future maybe enable loading a bit at a time so that we
        # can convert from this format to an actual FITS file on disk without
        # needing enough physical memory to hold the entire thing at once
        hdu = BinTableHDU.from_columns(
            np.recarray(shape=1, dtype=dtype), nrows=nrows, fill=True
        )

        # TODO: It seems to me a lot of this could/should be handled from
        # within the FITS_rec class rather than here.
        data = hdu.data
        for idx, length in enumerate(vla_lengths):
            if length is not None:
                arr = data.columns._arrays[idx]
                dt = recformats[idx][len(str(length)) :]

                # NOTE: FormatQ not supported here; it's hard to determine
                # whether or not it will be necessary to use a wider descriptor
                # type. The function documentation will have to serve as a
                # warning that this is not supported.
                recformats[idx] = _FormatP(dt, max=length)
                data.columns._recformats[idx] = recformats[idx]
                name = data.columns.names[idx]
                data._cache_field(name, _makep(arr, arr, recformats[idx]))

        def format_value(col, val):
            # Special formatting for a couple particular data types
            if recformats[col] == FITS2NUMPY["L"]:
                return bool(int(val))
            elif recformats[col] == FITS2NUMPY["M"]:
                # For some reason, in arrays/fields where numpy expects a
                # complex it's not happy to take a string representation
                # (though it's happy to do that in other contexts), so we have
                # to convert the string representation for it:
                return complex(val)
            else:
                return val

        # Jump back to the start of the data and create a new line reader
        fileobj.seek(initialpos)
        linereader = csv.reader(fileobj, dialect=FITSTableDumpDialect)
        for row, line in enumerate(linereader):
            col = 0
            idx = 0
            while idx < len(line):
                if line[idx] == "VLA_Length=":
                    vla_len = vla_lengths[col]
                    idx += 2
                    slice_ = slice(idx, idx + vla_len)
                    data[row][col][:] = line[idx : idx + vla_len]
                    idx += vla_len
                elif dtype[col].shape:
                    # This is an array column
                    array_size = int(np.multiply.reduce(dtype[col].shape))
                    slice_ = slice(idx, idx + array_size)
                    idx += array_size
                else:
                    slice_ = None

                if slice_ is None:
                    # This is a scalar row element
                    data[row][col] = format_value(col, line[idx])
                    idx += 1
                else:
                    data[row][col].flat[:] = [
                        format_value(col, val) for val in line[slice_]
                    ]

                col += 1

        if close_file:
            fileobj.close()

        return data

    @classmethod
    def _load_coldefs(cls, fileobj):
        """
        Read the table column definitions from the ASCII file output by
        BinTableHDU.dump().
        """
        close_file = False

        if isinstance(fileobj, path_like):
            fileobj = os.path.expanduser(fileobj)
            fileobj = open(fileobj)
            close_file = True

        columns = []

        for line in fileobj:
            words = line[:-1].split()
            kwargs = {}
            for key in ["name", "format", "disp", "unit", "dim"]:
                kwargs[key] = words.pop(0).replace('""', "")

            for key in ["null", "bscale", "bzero"]:
                word = words.pop(0).replace('""', "")
                if word:
                    word = _str_to_num(word)
                kwargs[key] = word
            columns.append(Column(**kwargs))

        if close_file:
            fileobj.close()

        return ColDefs(columns)


@contextlib.contextmanager
def _binary_table_byte_swap(data):
    """
    Ensures that all the data of a binary FITS table (represented as a FITS_rec
```

## 原始行 337 · file_change

```
{
  "id": "item_218",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 339 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
.F
=================================== FAILURES ===================================
___________ TestTableFunctions.test_dump_load_round_trip[table.fits] ___________

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x71b090267990>
tablename = 'table.fits'

    @pytest.mark.parametrize("tablename", ["table.fits", "tb.fits"])
    def test_dump_load_round_trip(self, tablename):
        """
        A simple test of the dump/load methods; dump the data, column, and
        header files and try to reload the table from them.
        """
    
        with fits.open(self.data(tablename)) as hdul:
            tbhdu = hdul[1]
            datafile = self.temp("data.txt")
            cdfile = self.temp("coldefs.txt")
            hfile = self.temp("header.txt")
    
            tbhdu.dump(datafile, cdfile, hfile)
    
            new_tbhdu = fits.BinTableHDU.load(datafile, cdfile, hfile)
    
            assert comparerecords(tbhdu.data, new_tbhdu.data)
    
>           _assert_attr_col(new_tbhdu, hdul[1])

astropy/io/fits/tests/test_table.py:2364: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

new_tbhdu = <astropy.io.fits.hdu.table.BinTableHDU object at 0x71b0901defd0>
tbhdu = <astropy.io.fits.hdu.table.BinTableHDU object at 0x71b090278510>

    def _assert_attr_col(new_tbhdu, tbhdu):
        """
        Helper function to compare column attributes
        """
        # Double check that the headers are equivalent
        assert tbhdu.columns.names == new_tbhdu.columns.names
        attrs = [
            k for k, v in fits.Column.__dict__.items() if isinstance(v, ColumnAttribute)
        ]
        for name in tbhdu.columns.names:
            col = tbhdu.columns[name]
            new_col = new_tbhdu.columns[name]
            for attr in attrs:
                if getattr(col, attr) and getattr(new_col, attr):
>                   assert getattr(col, attr) == getattr(new_col, attr)
E                   AssertionError: assert 'E' == 'D'
E                     
E                     - D
E                     + E

astropy/io/fits/tests/test_table.py:127: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip[table.fits]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 1 passed in 0.17s
```

## 原始行 342 · command_execution

命令：
```
/bin/bash -lc "grep -n \"@columns.setter\\|def columns\" astropy/io/fits/hdu/table.py | head -20; sed -n '390,450p' astropy/io/fits/hdu/table.py; sed -n '1160,1190p' astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```
156:    def columns(self):
373:    def columns(self):
    @data.setter
    def data(self, data):
        if "data" in self.__dict__:
            if self.__dict__["data"] is data:
                return
            else:
                self._data_replaced = True
        else:
            self._data_replaced = True

        self._modified = True

        if data is None and self.columns:
            # Create a new table with the same columns, but empty rows
            formats = ",".join(self.columns._recformats)
            data = np.rec.array(
                None, formats=formats, names=self.columns.names, shape=0
            )

        if isinstance(data, np.ndarray) and data.dtype.fields is not None:
            # Go ahead and always make a view, even if the data is already the
            # correct class (self._data_type) so we can update things like the
            # column defs, if necessary
            data = data.view(self._data_type)

            if not isinstance(data.columns, self._columns_type):
                # This would be the place, if the input data was for an ASCII
                # table and this is binary table, or vice versa, to convert the
                # data to the appropriate format for the table type
                new_columns = self._columns_type(data.columns)
                data = FITS_rec.from_columns(new_columns)

            if "data" in self.__dict__:
                self.columns._remove_listener(self.__dict__["data"])
            self.__dict__["data"] = data

            self.columns = self.data.columns
            self.columns._add_listener(self.data)
            self.update_header()

            with suppress(TypeError, AttributeError):
                # Make the ndarrays in the Column objects of the ColDefs
                # object of the HDU reference the same ndarray as the HDU's
                # FITS_rec object.
                for idx, col in enumerate(self.columns):
                    col.array = self.data.field(idx)

                # Delete the _arrays attribute so that it is recreated to
                # point to the new data placed in the column objects above
                del self.columns._arrays
        elif data is None:
            pass
        else:
            raise TypeError("Table data has incorrect type.")

        # returning the data signals to lazyproperty that we've already handled
        # setting self.__dict__['data']
        return data

    @property
    def _nrows(self):
                )

        coldefs = None
        # Process the column definitions file
        if cdfile:
            coldefs = cls._load_coldefs(cdfile)

        # Process the data file
        data = cls._load_data(datafile, coldefs)
        if coldefs is None:
            coldefs = ColDefs(data)

        # Create a new HDU using the supplied header and data
        hdu = cls(data=data, header=header)
        hdu.columns = coldefs
        return hdu

    if isinstance(load.__doc__, str):
        load.__doc__ += _tdump_file_format.replace("\n", "\n        ")

    load = classmethod(load)
    # Have to create a classmethod from this here instead of as a decorator;
    # otherwise we can't update __doc__

    def _dump_data(self, fileobj):
        """
        Write the table data in the ASCII format read by BinTableHDU.load()
        to fileobj.
        """
        if not fileobj and self._file:
            root = os.path.splitext(self._file.name)[0]
```

## 原始行 345 · command_execution

命令：
```
/bin/bash -lc "sed -n '360,390p' astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```
        if ver is not None:
            self.ver = ver

    @classmethod
    def match_header(cls, header):
        """
        This is an abstract type that implements the shared functionality of
        the ASCII and Binary Table HDU types, which should be used instead of
        this.
        """
        raise NotImplementedError

    @lazyproperty
    def columns(self):
        """
        The :class:`ColDefs` objects describing the columns in this table.
        """
        if self._has_data and hasattr(self.data, "_coldefs"):
            return self.data._coldefs
        return self._columns_type(self)

    @lazyproperty
    def data(self):
        data = self._get_tbdata()
        data._coldefs = self.columns
        data._character_as_bytes = self._character_as_bytes
        # Columns should now just return a reference to the data._coldefs
        del self.columns
        return data

    @data.setter
```

## 原始行 348 · file_change

```
{
  "id": "item_225",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 350 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
.F
=================================== FAILURES ===================================
___________ TestTableFunctions.test_dump_load_round_trip[table.fits] ___________

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x7a9629a7c1d0>
tablename = 'table.fits'

    @pytest.mark.parametrize("tablename", ["table.fits", "tb.fits"])
    def test_dump_load_round_trip(self, tablename):
        """
        A simple test of the dump/load methods; dump the data, column, and
        header files and try to reload the table from them.
        """
    
        with fits.open(self.data(tablename)) as hdul:
            tbhdu = hdul[1]
            datafile = self.temp("data.txt")
            cdfile = self.temp("coldefs.txt")
            hfile = self.temp("header.txt")
    
            tbhdu.dump(datafile, cdfile, hfile)
    
            new_tbhdu = fits.BinTableHDU.load(datafile, cdfile, hfile)
    
            assert comparerecords(tbhdu.data, new_tbhdu.data)
    
>           _assert_attr_col(new_tbhdu, hdul[1])

astropy/io/fits/tests/test_table.py:2364: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

new_tbhdu = <astropy.io.fits.hdu.table.BinTableHDU object at 0x7a9629a85690>
tbhdu = <astropy.io.fits.hdu.table.BinTableHDU object at 0x7a9629a88d50>

    def _assert_attr_col(new_tbhdu, tbhdu):
        """
        Helper function to compare column attributes
        """
        # Double check that the headers are equivalent
        assert tbhdu.columns.names == new_tbhdu.columns.names
        attrs = [
            k for k, v in fits.Column.__dict__.items() if isinstance(v, ColumnAttribute)
        ]
        for name in tbhdu.columns.names:
            col = tbhdu.columns[name]
            new_col = new_tbhdu.columns[name]
            for attr in attrs:
                if getattr(col, attr) and getattr(new_col, attr):
>                   assert getattr(col, attr) == getattr(new_col, attr)
E                   AssertionError: assert 'E' == 'D'
E                     
E                     - D
E                     + E

astropy/io/fits/tests/test_table.py:127: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip[table.fits]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 1 passed in 0.18s
```

## 原始行 353 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile,os
from astropy.io import fits
root=tempfile.mkdtemp(); ps=[root+'/'+x for x in 'dch']
with fits.open('astropy/io/fits/tests/data/table.fits') as x:
 x[1].dump(*ps)
 print(open(ps[1]).read())
 c=fits.BinTableHDU._load_coldefs(ps[1]); print([str(z.format) for z in c])
 y=fits.BinTableHDU.load(*ps); print([str(z.format) for z in y.columns],y.header['TFORM2'])
PY"
```

退出码：`0`

输出：
```
target 20A ""               ""               ""               ""               ""               ""              
V_mag E ""               ""               ""               ""               ""               ""              

['20A', 'D']
['20A', 'D'] D
```

## 原始行 356 · command_execution

命令：
```
/bin/bash -lc "sed -n '1320,1368p' astropy/io/fits/column.py"
```

退出码：`0`

输出：
```

        return format, recformat

    @classmethod
    def _guess_format(cls, format, start, dim):
        if start and dim:
            # This is impossible; this can't be a valid FITS column
            raise ValueError(
                "Columns cannot have both a start (TCOLn) and dim "
                "(TDIMn) option, since the former is only applies to "
                "ASCII tables, and the latter is only valid for binary tables."
            )
        elif start:
            # Only ASCII table columns can have a 'start' option
            guess_format = _AsciiColumnFormat
        elif dim:
            # Only binary tables can have a dim option
            guess_format = _ColumnFormat
        else:
            # If the format is *technically* a valid binary column format
            # (i.e. it has a valid format code followed by arbitrary
            # "optional" codes), but it is also strictly a valid ASCII
            # table format, then assume an ASCII table column was being
            # requested (the more likely case, after all).
            with suppress(VerifyError):
                format = _AsciiColumnFormat(format, strict=True)

            # A safe guess which reflects the existing behavior of previous
            # Astropy versions
            guess_format = _ColumnFormat

        try:
            format, recformat = cls._convert_format(format, guess_format)
        except VerifyError:
            # For whatever reason our guess was wrong (for example if we got
            # just 'F' that's not a valid binary format, but it an ASCII format
            # code albeit with the width/precision omitted
            guess_format = (
                _AsciiColumnFormat if guess_format is _ColumnFormat else _ColumnFormat
            )
            # If this fails too we're out of options--it is truly an invalid
            # format, or at least not supported
            format, recformat = cls._convert_format(format, guess_format)

        return format, recformat

    def _convert_to_valid_data_type(self, array):
        # Convert the format to a type we understand
        if isinstance(array, Delayed):
```

## 原始行 359 · file_change

```
{
  "id": "item_232",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 361 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
..F
=================================== FAILURES ===================================
____________ TestTableFunctions.test_dump_load_round_trip[tb.fits] _____________

self = <astropy.io.fits.tests.test_table.TestTableFunctions object at 0x79026e1b7cd0>
tablename = 'tb.fits'

    @pytest.mark.parametrize("tablename", ["table.fits", "tb.fits"])
    def test_dump_load_round_trip(self, tablename):
        """
        A simple test of the dump/load methods; dump the data, column, and
        header files and try to reload the table from them.
        """
    
        with fits.open(self.data(tablename)) as hdul:
            tbhdu = hdul[1]
            datafile = self.temp("data.txt")
            cdfile = self.temp("coldefs.txt")
            hfile = self.temp("header.txt")
    
            tbhdu.dump(datafile, cdfile, hfile)
    
            new_tbhdu = fits.BinTableHDU.load(datafile, cdfile, hfile)
    
>           assert comparerecords(tbhdu.data, new_tbhdu.data)
E           AssertionError: assert False
E            +  where False = comparerecords(FITS_rec([(1, 'abc', 3.70000007, False), (2, 'xy ', 6.69999971, True)],\n         dtype=(numpy.record, [('c1', '>i4'), ('c2', 'S3'), ('c3', '>f4'), ('c4', 'i1')])), FITS_rec([(1, 'abc', 3.70000007, False), (2, 'xy', 6.69999971, True)],\n         dtype=(numpy.record, [('c1', '<i4'), ('c2', 'S3'), ('c3', '<f4'), ('c4', 'i1')])))
E            +    where FITS_rec([(1, 'abc', 3.70000007, False), (2, 'xy ', 6.69999971, True)],\n         dtype=(numpy.record, [('c1', '>i4'), ('c2', 'S3'), ('c3', '>f4'), ('c4', 'i1')])) = <astropy.io.fits.hdu.table.BinTableHDU object at 0x79026e1a9f50>.data
E            +    and   FITS_rec([(1, 'abc', 3.70000007, False), (2, 'xy', 6.69999971, True)],\n         dtype=(numpy.record, [('c1', '<i4'), ('c2', 'S3'), ('c3', '<f4'), ('c4', 'i1')])) = <astropy.io.fits.hdu.table.BinTableHDU object at 0x79026e1cad50>.data

astropy/io/fits/tests/test_table.py:2362: AssertionError
----------------------------- Captured stdout call -----------------------------
fielda:  ['abc' 'xy ']
fieldb:  ['abc' 'xy']
field 1 differs
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_load_round_trip[tb.fits]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 2 passed in 0.17s
```

## 原始行 365 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_fsspec.py::test_fsspec_local astropy/io/fits/tests/test_fsspec.py::test_fsspec_local_write astropy/io/fits/tests/test_fsspec.py::test_fsspec_compressed -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
...                                                                      [100%]
3 passed in 0.19s
```

## 原始行 368 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_nonexistent astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_file_handle astropy/io/fits/tests/test_core.py::TestFileFunctions::test_fits_file_handle_mode_combo astropy/io/fits/tests/test_core.py::TestFileFunctions::test_read_file_like_object astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzipped astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_lzma astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_zipped -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
.....F
=================================== FAILURES ===================================
_____________________ TestFileFunctions.test_open_bzipped ______________________

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x742f95364090>

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_open_bzipped(self):
        bzip_file = self._make_bzip2_file()
    
        with fits.open(bzip_file) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        with fits.open(bzip_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        with fits.open(bz2.BZ2File(bzip_file)) as fits_handle:
>           assert fits_handle._file.compression == "bzip2"
E           AssertionError: assert None == 'bzip2'
E            +  where None = <astropy.io.fits.file._File <bz2.BZ2File object at 0x742f952e6920>>.compression
E            +    where <astropy.io.fits.file._File <bz2.BZ2File object at 0x742f952e6920>> = [<astropy.io.fits.hdu.image.PrimaryHDU object at 0x742f952f22d0>, <astropy.io.fits.hdu.image.ImageHDU object at 0x742f...py.io.fits.hdu.image.ImageHDU object at 0x742f95377590>, <astropy.io.fits.hdu.image.ImageHDU object at 0x742f952f5850>]._file

astropy/io/fits/tests/test_core.py:804: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 5 passed in 0.12s
```

## 原始行 371 · file_change

```
{
  "id": "item_240",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 374 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_lzma astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_zipped -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
_____________________ TestFileFunctions.test_open_bzipped ______________________

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x7aa91889f3d0>

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_open_bzipped(self):
        bzip_file = self._make_bzip2_file()
    
        with fits.open(bzip_file) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        with fits.open(bzip_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        with fits.open(bz2.BZ2File(bzip_file)) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        for mode in ("append", "update"):
            with pytest.raises(
                OSError,
                match="update and append modes are not supported with bzip2 files",
            ):
>               with fits.open(bzip_file, mode=mode) as fits_handle:
                     ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_core.py:812: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:229: in fitsopen
    return HDUList.fromfile(
astropy/io/fits/hdu/hdulist.py:493: in fromfile
    return cls._readfrom(
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'astropy.io.fits.hdu.hdulist.HDUList'>
fileobj = <astropy.io.fits.file._File <_io.BufferedRandom name='/tmp/fits-test-gxiu17oi/test0.fits.bz2'>>
data = None, mode = 'append', memmap = None, cache = True, lazy_load_hdus = True
ignore_missing_simple = False, use_fsspec = None, fsspec_kwargs = None
decompress_in_memory = False, kwargs = {'save_backup': False, 'uint': True}
hdulist = [], pos = 0
simple = b'BZh91AY&SYii\xff\xe4\x00-\xdc\xff\xd7\xff\xff\xff\xfe\xfc\xff\xff\xff\xff\xff\xff\xff\xff\xff\xff\xe1\n\x08\x00\x02\...00\x10\x08\x00\x00\x08`(\x7fx\x00\x00\x00\x00\x00\x00\x03\x8a\x00\x00\x00\x08\x00\x00(\x0c:H]\xb4!*\x80QP\xd6\xa9@\x00'
match_sig = False

    @classmethod
    def _readfrom(
        cls,
        fileobj=None,
        data=None,
        mode=None,
        memmap=None,
        cache=True,
        lazy_load_hdus=True,
        ignore_missing_simple=False,
        *,
        use_fsspec=None,
        fsspec_kwargs=None,
        decompress_in_memory=False,
        **kwargs,
    ):
        """
        Provides the implementations from HDUList.fromfile and
        HDUList.fromstring, both of which wrap this method, as their
        implementations are largely the same.
        """
        if fileobj is not None:
            if not isinstance(fileobj, _File):
                # instantiate a FITS file object (ffo)
                fileobj = _File(
                    fileobj,
                    mode=mode,
                    memmap=memmap,
                    cache=cache,
                    use_fsspec=use_fsspec,
                    fsspec_kwargs=fsspec_kwargs,
                    decompress_in_memory=decompress_in_memory,
                )
            # The Astropy mode is determined by the _File initializer if the
            # supplied mode was None
            mode = fileobj.mode
            hdulist = cls(file=fileobj)
        else:
            if mode is None:
                # The default mode
                mode = "readonly"
    
            hdulist = cls(file=data)
            # This method is currently only called from HDUList.fromstring and
            # HDUList.fromfile.  If fileobj is None then this must be the
            # fromstring case; the data type of ``data`` will be checked in the
            # _BaseHDU.fromstring call.
    
        if (
            not ignore_missing_simple
            and hdulist._file
            and hdulist._file.mode != "ostream"
            and hdulist._file.size > 0
        ):
            pos = hdulist._file.tell()
            # FITS signature is supposed to be in the first 30 bytes, but to
            # allow reading various invalid files we will check in the first
            # card (80 bytes).
            simple = hdulist._file.read(80)
            match_sig = simple[:29] == FITS_SIGNATURE[:-1] and simple[29:30] in (
                b"T",
                b"F",
            )
    
            if not match_sig:
                # Check the SIMPLE card is there but not written correctly
                match_sig_relaxed = re.match(rb"SIMPLE\s*=\s*[T|F]", simple)
    
                if match_sig_relaxed:
                    warnings.warn(
                        "Found a SIMPLE card but its format doesn't"
                        " respect the FITS Standard",
                        VerifyWarning,
                    )
                else:
                    if hdulist._file.close_on_error:
                        hdulist._file.close()
>                   raise OSError(
                        "No SIMPLE card found, this file does not appear to "
                        "be a valid FITS file. If this is really a FITS file, "
                        "try with ignore_missing_simple=True"
                    )
E                   OSError: No SIMPLE card found, this file does not appear to be a valid FITS file. If this is really a FITS file, try with ignore_missing_simple=True

astropy/io/fits/hdu/hdulist.py:1248: OSError

During handling of the above exception, another exception occurred:

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x7aa91889f3d0>

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_open_bzipped(self):
        bzip_file = self._make_bzip2_file()
    
        with fits.open(bzip_file) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        with fits.open(bzip_file, decompress_in_memory=True) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        with fits.open(bz2.BZ2File(bzip_file)) as fits_handle:
            assert fits_handle._file.compression == "bzip2"
            assert len(fits_handle) == 5
    
        for mode in ("append", "update"):
>           with pytest.raises(
                OSError,
                match="update and append modes are not supported with bzip2 files",
            ):
E           AssertionError: Regex pattern did not match.
E             Expected regex: 'update and append modes are not supported with bzip2 files'
E             Actual message: 'No SIMPLE card found, this file does not appear to be a valid FITS file. If this is really a FITS file, try with ignore_missing_simple=True'

astropy/io/fits/tests/test_core.py:808: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.11s
```

## 原始行 377 · file_change

```
{
  "id": "item_244",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 379 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_lzma astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_zipped -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
_____________________ TestFileFunctions.test_open_bzipped ______________________
  + Exception Group Traceback (most recent call last):
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py", line 353, in from_call
  |     result: TResult | None = func()
  |                              ^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py", line 245, in <lambda>
  |     lambda: runtest_hook(item=item, **kwds),
  |             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_hooks.py", line 512, in __call__
  |     return self._hookexec(self.name, self._hookimpls.copy(), kwargs, firstresult)
  |            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_manager.py", line 120, in _hookexec
  |     return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
  |            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 167, in _multicall
  |     raise exception
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/logging.py", line 850, in pytest_runtest_call
  |     yield
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 53, in run_old_style_hookwrapper
  |     return result.get_result()
  |            ^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_result.py", line 103, in get_result
  |     raise exc.with_traceback(tb)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 38, in run_old_style_hookwrapper
  |     res = yield
  |           ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/capture.py", line 900, in pytest_runtest_call
  |     return (yield)
  |             ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 53, in run_old_style_hookwrapper
  |     return result.get_result()
  |            ^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_result.py", line 103, in get_result
  |     raise exc.with_traceback(tb)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 38, in run_old_style_hookwrapper
  |     res = yield
  |           ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 53, in run_old_style_hookwrapper
  |     return result.get_result()
  |            ^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_result.py", line 103, in get_result
  |     raise exc.with_traceback(tb)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 38, in run_old_style_hookwrapper
  |     res = yield
  |           ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/skipping.py", line 268, in pytest_runtest_call
  |     return (yield)
  |             ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 121, in _multicall
  |     res = hook_impl.function(*args)
  |           ^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 158, in pytest_runtest_call
  |     collect_unraisable(item.config)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 81, in collect_unraisable
  |     raise ExceptionGroup("multiple unraisable exception warnings", errors)
  | ExceptionGroup: multiple unraisable exception warnings (2 sub-exceptions)
  +-+---------------- 1 ----------------
    | Traceback (most recent call last):
    |   File "/testbed/astropy/io/fits/tests/test_core.py", line 808, in test_open_bzipped
    |     with pytest.raises(
    | ResourceWarning: unclosed file <_io.BufferedRandom name='/tmp/fits-test-xaz69029/test0.fits.bz2'>
    | 
    | The above exception was the direct cause of the following exception:
    | 
    | Traceback (most recent call last):
    |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 67, in collect_unraisable
    |     warnings.warn(pytest.PytestUnraisableExceptionWarning(msg))
    | pytest.PytestUnraisableExceptionWarning: Exception ignored in: <_io.FileIO name='/tmp/fits-test-xaz69029/test0.fits.bz2' mode='rb+' closefd=True>
    | Enable tracemalloc to get traceback where the object was allocated.
    | See https://docs.pytest.org/en/stable/how-to/capture-warnings.html#resource-warnings for more info.
    +---------------- 2 ----------------
    | Traceback (most recent call last):
    |   File "/testbed/astropy/io/fits/tests/test_core.py", line 808, in test_open_bzipped
    |     with pytest.raises(
    | ResourceWarning: unclosed file <_io.BufferedRandom name='/tmp/fits-test-xaz69029/test0.fits.bz2'>
    | 
    | The above exception was the direct cause of the following exception:
    | 
    | Traceback (most recent call last):
    |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 67, in collect_unraisable
    |     warnings.warn(pytest.PytestUnraisableExceptionWarning(msg))
    | pytest.PytestUnraisableExceptionWarning: Exception ignored in: <_io.FileIO name='/tmp/fits-test-xaz69029/test0.fits.bz2' mode='ab+' closefd=True>
    | Enable tracemalloc to get traceback where the object was allocated.
    | See https://docs.pytest.org/en/stable/how-to/capture-warnings.html#resource-warnings for more info.
    +------------------------------------
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.07s
```

## 原始行 382 · file_change

```
{
  "id": "item_247",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 384 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_lzma astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_zipped -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
...                                                                      [100%]
3 passed in 0.10s
```

## 原始行 387 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_from_url astropy/io/fits/tests/test_core.py::TestFileFunctions::test_read_open_file astropy/io/fits/tests/test_core.py::TestFileFunctions::test_read_closed_file astropy/io/fits/tests/test_core.py::TestFileFunctions::test_read_open_gzip_file astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzip_file_for_writing -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
....F
=================================== FAILURES ===================================
______________ TestFileFunctions.test_open_gzip_file_for_writing _______________

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x71f9afb9d690>

    def test_open_gzip_file_for_writing(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/195."""
    
        gf = self._make_gzip_file()
>       with fits.open(gf, mode="update") as h:

astropy/io/fits/tests/test_core.py:1077: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:472: in __exit__
    self.close(output_verify=output_verify)
astropy/io/fits/hdu/hdulist.py:1099: in close
    self.flush(output_verify=output_verify, verbose=verbose)
astropy/io/fits/util.py:247: in wrapped
    return func(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:966: in flush
    self._flush_update()
astropy/io/fits/hdu/hdulist.py:1460: in _flush_update
    self._flush_resize()
astropy/io/fits/hdu/hdulist.py:1492: in _flush_resize
    with self.fromfile(new_file, mode="append") as hdulist:
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:493: in fromfile
    return cls._readfrom(
astropy/io/fits/hdu/hdulist.py:1223: in _readfrom
    and hdulist._file.size > 0
        ^^^^^^^^^^^^^^^^^^
astropy/io/fits/file.py:337: in size
    self.seek(0, os.SEEK_END)
astropy/io/fits/file.py:532: in seek
    return self._file.seek(offset, whence)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <gzip _io.BufferedRandom name='/tmp/fits-test-jl3_eggz/tmpo5tygbfw' 0x71f9afac7340>
offset = 0, whence = 2

    def seek(self, offset, whence=io.SEEK_SET):
        if self.mode == WRITE:
            if whence != io.SEEK_SET:
                if whence == io.SEEK_CUR:
                    offset = self.offset + offset
                else:
>                   raise ValueError('Seek from end not supported')
E                   ValueError: Seek from end not supported

/opt/miniconda3/envs/testbed/lib/python3.11/gzip.py:383: ValueError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzip_file_for_writing
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 4 passed in 0.15s
```

## 原始行 390 · file_change

```
{
  "id": "item_252",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 392 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzip_file_for_writing -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
______________ TestFileFunctions.test_open_gzip_file_for_writing _______________

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x79a29e0750d0>

    def test_open_gzip_file_for_writing(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/195."""
    
        gf = self._make_gzip_file()
>       with fits.open(gf, mode="update") as h:

astropy/io/fits/tests/test_core.py:1077: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:472: in __exit__
    self.close(output_verify=output_verify)
astropy/io/fits/hdu/hdulist.py:1099: in close
    self.flush(output_verify=output_verify, verbose=verbose)
astropy/io/fits/util.py:247: in wrapped
    return func(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:966: in flush
    self._flush_update()
astropy/io/fits/hdu/hdulist.py:1460: in _flush_update
    self._flush_resize()
astropy/io/fits/hdu/hdulist.py:1492: in _flush_resize
    with self.fromfile(new_file, mode="append") as hdulist:
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:493: in fromfile
    return cls._readfrom(
astropy/io/fits/hdu/hdulist.py:1265: in _readfrom
    read_one = hdulist._read_next_hdu()
               ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:1333: in _read_next_hdu
    hdu = _BaseHDU.readfrom(fileobj, **kwargs)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:350: in readfrom
    return cls._readfrom_internal(
astropy/io/fits/hdu/base.py:371: in _readfrom_internal
    header = Header.fromfile(
astropy/io/fits/header.py:555: in fromfile
    return cls._from_blocks(block_iter, is_binary, sep, endcard, padding)[1]
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/header.py:596: in _from_blocks
    block = next(blocks)
            ^^^^^^^^^^^^
astropy/io/fits/header.py:548: in block_iter
    data = fileobj.read(nbytes)
           ^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/file.py:545: in read
    return self._file.read() if size is None else self._file.read(size)
                                                  ^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <gzip _io.BufferedRandom name='/tmp/fits-test-ocqwib7u/tmpnt_ded6h' 0x79a2ca927010>
size = 2880

    def read(self, size=-1):
        self._check_not_closed()
        if self.mode != READ:
            import errno
>           raise OSError(errno.EBADF, "read() on write-only GzipFile object")
E           OSError: [Errno 9] read() on write-only GzipFile object

/opt/miniconda3/envs/testbed/lib/python3.11/gzip.py:300: OSError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzip_file_for_writing
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.14s
```

## 原始行 395 · file_change

```
{
  "id": "item_255",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 397 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzip_file_for_writing astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_append_mode_gzip astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_bzip2_fileobj astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_lzma_fileobj -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
______________ TestFileFunctions.test_open_gzip_file_for_writing _______________

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x736364091f50>

    def test_open_gzip_file_for_writing(self):
        """Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/195."""
    
        gf = self._make_gzip_file()
>       with fits.open(gf, mode="update") as h:

astropy/io/fits/tests/test_core.py:1077: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:472: in __exit__
    self.close(output_verify=output_verify)
astropy/io/fits/hdu/hdulist.py:1099: in close
    self.flush(output_verify=output_verify, verbose=verbose)
astropy/io/fits/util.py:247: in wrapped
    return func(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/hdulist.py:966: in flush
    self._flush_update()
astropy/io/fits/hdu/hdulist.py:1460: in _flush_update
    self._flush_resize()
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = [<astropy.io.fits.hdu.image.PrimaryHDU object at 0x7363640a10d0>, <astropy.io.fits.hdu.image.ImageHDU object at 0x7363...py.io.fits.hdu.image.ImageHDU object at 0x736364271190>, <astropy.io.fits.hdu.image.ImageHDU object at 0x73636424dc50>]

    def _flush_resize(self):
        """
        Implements flushing changes in update mode when parts of one or more HDU
        need to be resized.
        """
        old_name = self._file.name
        old_memmap = self._file.memmap
        name = _tmp_name(old_name)
    
        if not self._file.file_like:
            old_mode = os.stat(old_name).st_mode
            # The underlying file is an actual file object.  The HDUList is
            # resized, so we need to write it to a tmp file, delete the
            # original file, and rename the tmp file to the original file.
            if self._file.compression == "gzip":
                new_file = gzip.GzipFile(name, mode="ab+")
            else:
                new_file = name
    
            with self.fromfile(new_file, mode="append") as hdulist:
                for hdu in self:
                    hdu._writeto(hdulist._file, inplace=True, copy=True)
                if sys.platform.startswith("win"):
                    # Collect a list of open mmaps to the data; this well be
                    # used later.  See below.
                    mmaps = [
                        (idx, _get_array_mmap(hdu.data), hdu.data)
                        for idx, hdu in enumerate(self)
                        if hdu._has_data
                    ]
    
                hdulist._file.close()
                self._file.close()
            if sys.platform.startswith("win"):
                # Close all open mmaps to the data.  This is only necessary on
                # Windows, which will not allow a file to be renamed or deleted
                # until all handles to that file have been closed.
                for idx, mmap, arr in mmaps:
                    if mmap is not None:
                        mmap.close()
    
            os.remove(self._file.name)
    
            # reopen the renamed new file with "update" mode
            os.rename(name, old_name)
            os.chmod(old_name, old_mode)
    
            if isinstance(new_file, gzip.GzipFile):
                old_file = gzip.GzipFile(old_name, mode="rb+")
            else:
                old_file = old_name
    
            ffo = _File(old_file, mode="update", memmap=old_memmap)
    
            self._file = ffo
    
            for hdu in self:
                # Need to update the _file attribute and close any open mmaps
                # on each HDU
>               if hdu._has_data and _get_array_mmap(hdu.data) is not None:
                                     ^^^^^^^^^^^^^^^
E               NameError: name '_get_array_mmap' is not defined

astropy/io/fits/hdu/hdulist.py:1532: NameError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzip_file_for_writing
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.16s
```

## 原始行 400 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"def _get_array_mmap\\|_get_array_mmap\" astropy/io/fits | head; head -35 astropy/io/fits/hdu/hdulist.py"
```

退出码：`0`

输出：
```
astropy/io/fits/hdu/base.py:783:                    array_mmap = _get_array_mmap(self.data)
astropy/io/fits/hdu/hdulist.py:1499:                        (idx, _get_array_mmap(hdu.data), hdu.data)
astropy/io/fits/hdu/hdulist.py:1532:                if hdu._has_data and _get_array_mmap(hdu.data) is not None:
# Licensed under a 3-clause BSD style license - see PYFITS.rst

import gzip
import itertools
import os
import re
import shutil
import sys
import warnings
from textwrap import indent

import numpy as np

from astropy.io.fits.file import FILE_MODES, _File
from astropy.io.fits.header import _pad_length
from astropy.io.fits.util import (
    _free_space_check,
    _is_int,
    _tmp_name,
    fileobj_closed,
    fileobj_mode,
    ignore_sigint,
    isfile,
    path_like,
)









from astropy.io.fits.verify import VerifyError, VerifyWarning, _ErrList, _Verify
```

## 原始行 403 · file_change

```
{
  "id": "item_260",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/hdu/hdulist.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 405 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_gzip_file_for_writing astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_append_mode_gzip astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_bzip2_fileobj astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_lzma_fileobj -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
..F
=================================== FAILURES ===================================
_________________ TestFileFunctions.test_writeto_bzip2_fileobj _________________

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x76c7b8500450>

    @pytest.mark.skipif(not HAS_BZ2, reason="Python built without bz2 module")
    def test_writeto_bzip2_fileobj(self):
        """Test writing to a bz2.BZ2File file like object"""
        fileobj = bz2.BZ2File(self.temp("test.fits.bz2"), "w")
        h = fits.PrimaryHDU()
        try:
>           h.writeto(fileobj)

astropy/io/fits/tests/test_core.py:835: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/base.py:480: in writeto
    hdulist.writeto(name, output_verify, overwrite=overwrite, checksum=checksum)
astropy/io/fits/hdu/hdulist.py:1058: in writeto
    fileobj = _File(fileobj, mode=mode, overwrite=overwrite)
              ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/file.py:268: in __init__
    self._open_fileobj(fileobj, mode, overwrite)
astropy/io/fits/file.py:900: in _open_fileobj
    self._overwrite_existing(overwrite, fileobj, closed)
astropy/io/fits/file.py:820: in _overwrite_existing
    os.path.exists(self.name) and os.path.getsize(self.name) != 0
    ^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

path = None

>   ???
E   TypeError: stat: path should be string, bytes, os.PathLike or integer, not NoneType

<frozen genericpath>:19: TypeError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_bzip2_fileobj
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 2 passed in 0.10s
```

## 原始行 408 · file_change

```
{
  "id": "item_263",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 410 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_bzip2_fileobj astropy/io/fits/tests/test_core.py::TestFileFunctions::test_writeto_lzma_fileobj -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
..                                                                       [100%]
2 passed in 0.04s
```

## 原始行 412 · agent_message

```
The focused round trips now pass for string and `pathlib` tilde paths, gzip tilde paths, formatter use, Header text/binary files, fsspec local access, and open file objects. I also verified the table dump/load path expansion directly. I’m doing a final compatibility pass over overwrite behavior, compressed handles, and the modified-file diff before handing it back.
```

## 原始行 414 · command_execution

命令：
```
/bin/bash -lc 'git diff --check; git status --short; git diff --stat; python -m compileall -q astropy/io/fits'
```

退出码：`0`

输出：
```
 M astropy/io/fits/card.py
 M astropy/io/fits/column.py
 M astropy/io/fits/convenience.py
 M astropy/io/fits/file.py
 M astropy/io/fits/fitsrec.py
 M astropy/io/fits/hdu/base.py
 M astropy/io/fits/hdu/compressed/compressed.py
 M astropy/io/fits/hdu/groups.py
 M astropy/io/fits/hdu/hdulist.py
 M astropy/io/fits/hdu/image.py
 M astropy/io/fits/hdu/table.py
 M astropy/io/fits/header.py
 M astropy/io/fits/scripts/fitsheader.py
 M astropy/io/fits/util.py
 astropy/io/fits/card.py                      |   2 +-
 astropy/io/fits/column.py                    |  67 +++++-
 astropy/io/fits/convenience.py               |  60 ++++-
 astropy/io/fits/file.py                      | 328 ++++++++++++++++++++++++++-
 astropy/io/fits/fitsrec.py                   |  42 +++-
 astropy/io/fits/hdu/base.py                  | 111 ++++++++-
 astropy/io/fits/hdu/compressed/compressed.py |   1 +
 astropy/io/fits/hdu/groups.py                |   2 +-
 astropy/io/fits/hdu/hdulist.py               |  14 +-
 astropy/io/fits/hdu/image.py                 |   9 +-
 astropy/io/fits/hdu/table.py                 |  26 ++-
 astropy/io/fits/header.py                    | 232 ++++++++++++++++++-
 astropy/io/fits/scripts/fitsheader.py        |  12 +-
 astropy/io/fits/util.py                      |  66 +++++-
 14 files changed, 939 insertions(+), 33 deletions(-)
```

## 原始行 417 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_hdulist.py::TestHDUListFunctions::test_update_resized_header astropy/io/fits/tests/test_hdulist.py::TestHDUListFunctions::test_overwrite astropy/io/fits/tests/test_convenience.py::TestConvenienceFunctions::test_append_filename -q --disable-warnings --maxfail=1'
```

退出码：`4`

输出：
```
Internet access disabled

no tests ran in 0.15s
ERROR: not found: /testbed/astropy/io/fits/tests/test_convenience.py::TestConvenienceFunctions::test_append_filename
(no match in any of [<DocTestModulePlus test_convenience.py>, <Module test_convenience.py>])
```

## 原始行 420 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^class '"' astropy/io/fits/tests/test_hdulist.py astropy/io/fits/tests/test_convenience.py | head -30; grep -n 'def test_update_resized_header\\|def test_overwrite\\|def test_append_filename' astropy/io/fits/tests/test_hdulist.py astropy/io/fits/tests/test_convenience.py"
```

退出码：`0`

输出：
```
astropy/io/fits/tests/test_hdulist.py:24:class TestHDUListFunctions(FitsTestCase):
astropy/io/fits/tests/test_convenience.py:23:class TestConvenience(FitsTestCase):
astropy/io/fits/tests/test_hdulist.py:687:    def test_update_resized_header(self, home_is_temp):
astropy/io/fits/tests/test_hdulist.py:736:    def test_update_resized_header2(self, home_is_temp):
astropy/io/fits/tests/test_hdulist.py:949:    def test_overwrite(self, home_is_temp):
astropy/io/fits/tests/test_convenience.py:383:    def test_append_filename(self, home_is_temp):
```

## 原始行 423 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_hdulist.py::TestHDUListFunctions::test_update_resized_header astropy/io/fits/tests/test_hdulist.py::TestHDUListFunctions::test_overwrite astropy/io/fits/tests/test_convenience.py::TestConvenience::test_append_filename -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
......F
=================================== FAILURES ===================================
____________________ TestConvenience.test_append_filename[] ____________________
  + Exception Group Traceback (most recent call last):
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py", line 353, in from_call
  |     result: TResult | None = func()
  |                              ^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py", line 245, in <lambda>
  |     lambda: runtest_hook(item=item, **kwds),
  |             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_hooks.py", line 512, in __call__
  |     return self._hookexec(self.name, self._hookimpls.copy(), kwargs, firstresult)
  |            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_manager.py", line 120, in _hookexec
  |     return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
  |            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 167, in _multicall
  |     raise exception
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/logging.py", line 850, in pytest_runtest_call
  |     yield
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 53, in run_old_style_hookwrapper
  |     return result.get_result()
  |            ^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_result.py", line 103, in get_result
  |     raise exc.with_traceback(tb)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 38, in run_old_style_hookwrapper
  |     res = yield
  |           ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/capture.py", line 900, in pytest_runtest_call
  |     return (yield)
  |             ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 53, in run_old_style_hookwrapper
  |     return result.get_result()
  |            ^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_result.py", line 103, in get_result
  |     raise exc.with_traceback(tb)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 38, in run_old_style_hookwrapper
  |     res = yield
  |           ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 53, in run_old_style_hookwrapper
  |     return result.get_result()
  |            ^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_result.py", line 103, in get_result
  |     raise exc.with_traceback(tb)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 38, in run_old_style_hookwrapper
  |     res = yield
  |           ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 139, in _multicall
  |     teardown.throw(exception)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/skipping.py", line 268, in pytest_runtest_call
  |     return (yield)
  |             ^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_callers.py", line 121, in _multicall
  |     res = hook_impl.function(*args)
  |           ^^^^^^^^^^^^^^^^^^^^^^^^^
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 158, in pytest_runtest_call
  |     collect_unraisable(item.config)
  |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 81, in collect_unraisable
  |     raise ExceptionGroup("multiple unraisable exception warnings", errors)
  | ExceptionGroup: multiple unraisable exception warnings (2 sub-exceptions)
  +-+---------------- 1 ----------------
    | Traceback (most recent call last):
    |   File "/testbed/astropy/io/fits/tests/test_convenience.py", line 398, in test_append_filename
    |     fits.append(testfile, data=data * 3, checksum=True, verify=False)
    | ResourceWarning: unclosed file <_io.BufferedRandom name='/tmp/fits-test-6ci8if4_/test_append_1.fits'>
    | 
    | The above exception was the direct cause of the following exception:
    | 
    | Traceback (most recent call last):
    |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 67, in collect_unraisable
    |     warnings.warn(pytest.PytestUnraisableExceptionWarning(msg))
    | pytest.PytestUnraisableExceptionWarning: Exception ignored in: <_io.FileIO name='/tmp/fits-test-6ci8if4_/test_append_1.fits' mode='ab+' closefd=True>
    | Enable tracemalloc to get traceback where the object was allocated.
    | See https://docs.pytest.org/en/stable/how-to/capture-warnings.html#resource-warnings for more info.
    +---------------- 2 ----------------
    | Traceback (most recent call last):
    |   File "/testbed/astropy/io/fits/tests/test_convenience.py", line 395, in test_append_filename
    |     fits.append(testfile, data=data * 2, checksum=True, ignore_blank=True)
    | ResourceWarning: unclosed file <_io.BufferedRandom name='/tmp/fits-test-6ci8if4_/test_append_1.fits'>
    | 
    | The above exception was the direct cause of the following exception:
    | 
    | Traceback (most recent call last):
    |   File "/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py", line 67, in collect_unraisable
    |     warnings.warn(pytest.PytestUnraisableExceptionWarning(msg))
    | pytest.PytestUnraisableExceptionWarning: Exception ignored in: <_io.FileIO name='/tmp/fits-test-6ci8if4_/test_append_1.fits' mode='ab+' closefd=True>
    | Enable tracemalloc to get traceback where the object was allocated.
    | See https://docs.pytest.org/en/stable/how-to/capture-warnings.html#resource-warnings for more info.
    +------------------------------------
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_convenience.py::TestConvenience::test_append_filename[]
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 6 passed in 0.14s
```

## 原始行 426 · command_execution

命令：
```
/bin/bash -lc "sed -n '700,755p' astropy/io/fits/convenience.py"
```

退出码：`0`

输出：
```
    checksum : bool, optional
        When `True` adds both ``DATASUM`` and ``CHECKSUM`` cards to the header
        of the HDU when written to the file.

    verify : bool, optional
        When `True`, the existing FITS file will be read in to verify it for
        correctness before appending.  When `False`, content is simply appended
        to the end of the file.  Setting ``verify`` to `False` can be much
        faster.

    **kwargs
        Additional arguments are passed to:

        - `~astropy.io.fits.writeto` if the file does not exist or is empty.
          In this case ``output_verify`` is the only possible argument.
        - `~astropy.io.fits.open` if ``verify`` is True or if ``filename``
          is a file object.
        - Otherwise no additional arguments can be used.

    """
    if isinstance(filename, path_like):
        filename = os.path.expanduser(filename)
    name, closed, noexist_or_empty = _stat_filename_or_fileobj(filename)

    if noexist_or_empty:
        #
        # The input file or file like object either doesn't exits or is
        # empty.  Use the writeto convenience function to write the
        # output to the empty object.
        #
        writeto(filename, data, header, checksum=checksum, **kwargs)
    else:
        hdu = _makehdu(data, header)

        if isinstance(hdu, PrimaryHDU):
            hdu = ImageHDU(data, header)

        if verify or not closed:
            f = fitsopen(filename, mode="append", **kwargs)
            try:
                f.append(hdu)

                # Set a flag in the HDU so that only this HDU gets a checksum
                # when writing the file.
                hdu._output_checksum = checksum
            finally:
                f.close(closed=closed)
        else:
            f = _File(filename, mode="append")
            try:
                hdu._output_checksum = checksum
                hdu._writeto(f)
            finally:
                f.close()
```

## 原始行 429 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile,os
from astropy.io.fits.file import _File
p=tempfile.mktemp(); open(p,'wb').write(b'x')
f=_File(p,mode='append'); raw=f._file; print(f._close_file,raw.closed); f.close();print(raw.closed)
os.unlink(p)
PY"
```

退出码：`0`

输出：
```
True False
True
```

## 原始行 432 · file_change

```
{
  "id": "item_279",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/util.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 434 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_convenience.py::TestConvenience::test_append_filename -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
...                                                                      [100%]
3 passed in 0.10s
```

## 原始行 437 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 40%]
.......................................F
=================================== FAILURES ===================================
__________________ TestHeaderFunctions.test_update_commentary __________________

self = FOO     = 'BAR     '                                                            
FRED    = 'BARNEY  '                 ...                                      
HISTORY BAR                                                                     
key = ('HISTORY', 3)

    def _cardindex(self, key):
        """Returns an index into the ._cards list given a valid lookup key."""
        # This used to just set key = (key, 0) and then go on to act as if the
        # user passed in a tuple, but it's much more common to just be given a
        # string as the key, so optimize more for that case
        if isinstance(key, str):
            keyword = key
            n = 0
        elif isinstance(key, numbers.Integral):
            # If < 0, determine the actual index
            if key < 0:
                key += len(self._cards)
            if key < 0 or key >= len(self._cards):
                raise IndexError("Header index out of range.")
            return key
        elif isinstance(key, slice):
            return key
        elif isinstance(key, tuple):
            if (
                len(key) != 2
                or not isinstance(key[0], str)
                or not isinstance(key[1], numbers.Integral)
            ):
                raise ValueError(
                    "Tuple indices must be 2-tuples consisting of a "
                    "keyword string and an integer index."
                )
            keyword, n = key
        else:
            raise ValueError(
                "Header indices must be either a string, a 2-tuple, or an integer."
            )
    
        keyword = Card.normalize_keyword(keyword)
        # Returns the index into _cards for the n-th card with the given
        # keyword (where n is 0-based)
        indices = self._keyword_indices.get(keyword, None)
    
        if keyword and not indices:
            if len(keyword) > KEYWORD_LENGTH or "." in keyword:
                raise KeyError(f"Keyword {keyword!r} not found.")
            else:
                # Maybe it's a RVKC?
                indices = self._rvkc_indices.get(keyword, None)
    
        if not indices:
            raise KeyError(f"Keyword {keyword!r} not found.")
    
        try:
>           return indices[n]
                   ^^^^^^^^^^
E           IndexError: list index out of range

astropy/io/fits/header.py:1895: IndexError

During handling of the above exception, another exception occurred:

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x79bd1a210490>

    def test_update_commentary(self):
        header = fits.Header()
        header["FOO"] = "BAR"
        header["HISTORY"] = "ABC"
        header["FRED"] = "BARNEY"
        header["HISTORY"] = "DEF"
        header["HISTORY"] = "GHI"
    
        assert header["HISTORY"] == ["ABC", "DEF", "GHI"]
    
        # Single value update
        header["HISTORY"][0] = "FOO"
        assert header["HISTORY"] == ["FOO", "DEF", "GHI"]
    
        # Single value partial slice update
>       header["HISTORY"][1:] = "BAR"
        ^^^^^^^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_header.py:1722: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/header.py:2443: in __setitem__
    if self._header._set_slice(item, value, self):
       ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/header.py:1804: in _set_slice
    target[idx] = item
    ^^^^^^^^^^^
astropy/io/fits/header.py:2448: in __setitem__
    self._header[(self._keyword, item)] = value
    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/header.py:211: in __setitem__
    card = self._cards[self._cardindex(key)]
                       ^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = FOO     = 'BAR     '                                                            
FRED    = 'BARNEY  '                 ...                                      
HISTORY BAR                                                                     
key = ('HISTORY', 3)

    def _cardindex(self, key):
        """Returns an index into the ._cards list given a valid lookup key."""
        # This used to just set key = (key, 0) and then go on to act as if the
        # user passed in a tuple, but it's much more common to just be given a
        # string as the key, so optimize more for that case
        if isinstance(key, str):
            keyword = key
            n = 0
        elif isinstance(key, numbers.Integral):
            # If < 0, determine the actual index
            if key < 0:
                key += len(self._cards)
            if key < 0 or key >= len(self._cards):
                raise IndexError("Header index out of range.")
            return key
        elif isinstance(key, slice):
            return key
        elif isinstance(key, tuple):
            if (
                len(key) != 2
                or not isinstance(key[0], str)
                or not isinstance(key[1], numbers.Integral)
            ):
                raise ValueError(
                    "Tuple indices must be 2-tuples consisting of a "
                    "keyword string and an integer index."
                )
            keyword, n = key
        else:
            raise ValueError(
                "Header indices must be either a string, a 2-tuple, or an integer."
            )
    
        keyword = Card.normalize_keyword(keyword)
        # Returns the index into _cards for the n-th card with the given
        # keyword (where n is 0-based)
        indices = self._keyword_indices.get(keyword, None)
    
        if keyword and not indices:
            if len(keyword) > KEYWORD_LENGTH or "." in keyword:
                raise KeyError(f"Keyword {keyword!r} not found.")
            else:
                # Maybe it's a RVKC?
                indices = self._rvkc_indices.get(keyword, None)
    
        if not indices:
            raise KeyError(f"Keyword {keyword!r} not found.")
    
        try:
            return indices[n]
        except IndexError:
>           raise IndexError(
                f"There are only {len(indices)} {keyword!r} cards in the header."
            )
E           IndexError: There are only 3 'HISTORY' cards in the header.

astropy/io/fits/header.py:1897: IndexError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_update_commentary
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 111 passed in 0.22s
```

## 原始行 440 · file_change

```
{
  "id": "item_284",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 442 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 40%]
.........................................F
=================================== FAILURES ===================================
________________ TestHeaderFunctions.test_long_commentary_card _________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7722c5d30fd0>

    def test_long_commentary_card(self):
        header = fits.Header()
        header["FOO"] = "BAR"
        header["BAZ"] = "QUX"
        longval = "ABC" * 30
        header["HISTORY"] = longval
        header["FRED"] = "BARNEY"
        header["HISTORY"] = longval
    
        assert len(header) == 7
        assert list(header)[2] == "FRED"
        assert str(header.cards[3]) == "HISTORY " + longval[:72]
        assert str(header.cards[4]).rstrip() == "HISTORY " + longval[72:]
    
        header.set("HISTORY", longval, after="FOO")
>       assert len(header) == 9
E       AssertionError: assert 8 == 9
E        +  where 8 = len(FOO     = 'BAR     '                                                            \nHISTORY ABCABCABCABCABCABCABCABCABCAB...BCABCABCABCABCABCABCABCABCABCABCABCABC\nHISTORY ABCABCABCABCABCABC                                                      )

astropy/io/fits/tests/test_header.py:1760: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_long_commentary_card
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 113 passed in 0.19s
```

## 原始行 445 · file_change

```
{
  "id": "item_287",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 447 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 40%]
......................................................F
=================================== FAILURES ===================================
__________________ TestHeaderFunctions.test_unnecessary_move ___________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7f4797878350>

    def test_unnecessary_move(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/125
    
        Ensures that a header is not modified when setting the position of a
        keyword that's already in its correct position.
        """
    
        header = fits.Header([("A", "B"), ("B", "C"), ("C", "D")])
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
>       assert not header._modified
E       AssertionError: assert not True
E        +  where True = A       = 'B       '                                                            \nB       = 'C       '                 ...                                      \nC       = 'D       '                                                            ._modified

astropy/io/fits/tests/test_header.py:2044: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 126 passed in 0.27s
```

## 原始行 450 · file_change

```
{
  "id": "item_290",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 453 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
__________________ TestHeaderFunctions.test_unnecessary_move ___________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x784b7713cbd0>

    def test_unnecessary_move(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/125
    
        Ensures that a header is not modified when setting the position of a
        keyword that's already in its correct position.
        """
    
        header = fits.Header([("A", "B"), ("B", "C"), ("C", "D")])
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
>       assert not header._modified
E       AssertionError: assert not True
E        +  where True = A       = 'B       '                                                            \nB       = 'C       '                 ...                                      \nC       = 'D       '                                                            ._modified

astropy/io/fits/tests/test_header.py:2044: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.08s
```

## 原始行 456 · file_change

```
{
  "id": "item_294",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 459 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
__________________ TestHeaderFunctions.test_unnecessary_move ___________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x72ed98050650>

    def test_unnecessary_move(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/125
    
        Ensures that a header is not modified when setting the position of a
        keyword that's already in its correct position.
        """
    
        header = fits.Header([("A", "B"), ("B", "C"), ("C", "D")])
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", after=0)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", before="C")
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", after="A")
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        # 123 is well past the end, and C is already at the end, so it's in the
        # right place already
>       header.set("C", before=123)

astropy/io/fits/tests/test_header.py:2064: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/header.py:1005: in set
    self._relativeinsert(card, before=before, after=after, replace=True)
astropy/io/fits/header.py:2082: in _relativeinsert
    idx = self._cardindex(reference)
          ^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = A       = 'B       '                                                            
B       = 'C       '                 ...                                      
C       = 'D       '                                                            
key = 123

    def _cardindex(self, key):
        """Returns an index into the ._cards list given a valid lookup key."""
        # This used to just set key = (key, 0) and then go on to act as if the
        # user passed in a tuple, but it's much more common to just be given a
        # string as the key, so optimize more for that case
        if isinstance(key, str):
            keyword = key
            n = 0
        elif isinstance(key, numbers.Integral):
            # If < 0, determine the actual index
            if key < 0:
                key += len(self._cards)
            if key < 0 or key >= len(self._cards):
>               raise IndexError("Header index out of range.")
E               IndexError: Header index out of range.

astropy/io/fits/header.py:1860: IndexError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.10s
```

## 原始行 462 · file_change

```
{
  "id": "item_298",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 465 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os,tempfile,numpy as np
from astropy.io import fits
root=tempfile.mkdtemp(); os.environb[b'HOME']=os.fsencode(root)
p=b'~/bytes.fits'; fits.writeto(p,np.arange(3)); print(os.path.exists(os.path.expanduser(p)),fits.getdata(p).tolist())
PY"
```

退出码：`0`

输出：
```
True [0, 1, 2]
```

## 原始行 468 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_mmap_closing astropy/io/fits/tests/test_core.py::TestFileFunctions::test_mmap_allocate_error -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
.F
=================================== FAILURES ===================================
__________________ TestFileFunctions.test_mmap_allocate_error __________________

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x782640d82150>

    def test_mmap_allocate_error(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/1380
    
        Temporarily patches mmap.mmap to raise an OSError if mode is ACCESS_COPY.
        """
    
        mmap_original = mmap.mmap
    
        # We patch mmap here to raise an error if access=mmap.ACCESS_COPY, which
        # emulates an issue that an OSError is raised if the available address
        # space is less than the size of the file even if memory mapping is used.
    
        def mmap_patched(*args, **kwargs):
            if kwargs.get("access") == mmap.ACCESS_COPY:
                exc = OSError()
                if sys.platform.startswith("win32"):
                    exc.errno = errno.EINVAL
                    exc.winerror = 1455
                else:
                    exc.errno = errno.ENOMEM
                raise exc
            else:
                return mmap_original(*args, **kwargs)
    
        with fits.open(self.data("test0.fits"), memmap=True) as hdulist:
            with patch.object(mmap, "mmap", side_effect=mmap_patched) as p:
                with pytest.warns(
                    AstropyUserWarning,
                    match=r"Could not memory map array with mode='readonly'",
                ):
>                   data = hdulist[1].data
                           ^^^^^^^^^^^^^^^

astropy/io/fits/tests/test_core.py:1255: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/utils/decorators.py:949: in __get__
    val = self.fget(obj)
          ^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:250: in data
    data = self._get_scaled_image_data(self._data_offset, self.shape)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/image.py:804: in _get_scaled_image_data
    raw_data = self._get_raw_data(shape, code, offset)
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:807: in _get_raw_data
    return self._file.readarray(offset=offset, dtype=dtype, shape=shape)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/file.py:559: in readarray
    self._mmap = mmap.mmap(
/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py:1124: in __call__
    return self._mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py:1128: in _mock_call
    return self._execute_mock_call(*args, **kwargs)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/unittest/mock.py:1189: in _execute_mock_call
    result = effect(*args, **kwargs)
             ^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

args = (11, 0), kwargs = {'access': 3}, exc = OSError()

    def mmap_patched(*args, **kwargs):
        if kwargs.get("access") == mmap.ACCESS_COPY:
            exc = OSError()
            if sys.platform.startswith("win32"):
                exc.errno = errno.EINVAL
                exc.winerror = 1455
            else:
                exc.errno = errno.ENOMEM
>           raise exc
E           OSError

astropy/io/fits/tests/test_core.py:1245: OSError

During handling of the above exception, another exception occurred:

self = <astropy.io.fits.tests.test_core.TestFileFunctions object at 0x782640d82150>

    def test_mmap_allocate_error(self):
        """
        Regression test for https://github.com/astropy/astropy/issues/1380
    
        Temporarily patches mmap.mmap to raise an OSError if mode is ACCESS_COPY.
        """
    
        mmap_original = mmap.mmap
    
        # We patch mmap here to raise an error if access=mmap.ACCESS_COPY, which
        # emulates an issue that an OSError is raised if the available address
        # space is less than the size of the file even if memory mapping is used.
    
        def mmap_patched(*args, **kwargs):
            if kwargs.get("access") == mmap.ACCESS_COPY:
                exc = OSError()
                if sys.platform.startswith("win32"):
                    exc.errno = errno.EINVAL
                    exc.winerror = 1455
                else:
                    exc.errno = errno.ENOMEM
                raise exc
            else:
                return mmap_original(*args, **kwargs)
    
        with fits.open(self.data("test0.fits"), memmap=True) as hdulist:
            with patch.object(mmap, "mmap", side_effect=mmap_patched) as p:
>               with pytest.warns(
                    AstropyUserWarning,
                    match=r"Could not memory map array with mode='readonly'",
                ):
E               Failed: DID NOT WARN. No warnings of type (<class 'astropy.utils.exceptions.AstropyUserWarning'>,) were emitted.
E                Emitted warnings: [].

astropy/io/fits/tests/test_core.py:1251: Failed
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestFileFunctions::test_mmap_allocate_error
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 1 passed in 0.15s
```

## 原始行 471 · file_change

```
{
  "id": "item_304",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 474 · file_change

```
{
  "id": "item_306",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 476 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_mmap_closing astropy/io/fits/tests/test_core.py::TestFileFunctions::test_mmap_allocate_error -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
..                                                                       [100%]
2 passed in 0.05s
```

## 原始行 479 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestFileFunctions::test_mmap_unwriteable -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
.                                                                        [100%]
1 passed in 0.05s
```

## 原始行 482 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 40%]
......................................................F
=================================== FAILURES ===================================
__________________ TestHeaderFunctions.test_unnecessary_move ___________________

self = <astropy.io.fits.tests.test_header.TestHeaderFunctions object at 0x7ba030078fd0>

    def test_unnecessary_move(self):
        """
        Regression test for https://aeon.stsci.edu/ssb/trac/pyfits/ticket/125
    
        Ensures that a header is not modified when setting the position of a
        keyword that's already in its correct position.
        """
    
        header = fits.Header([("A", "B"), ("B", "C"), ("C", "D")])
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", after=0)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", before="C")
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", after="A")
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("B", before=2)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        # 123 is well past the end, and C is already at the end, so it's in the
        # right place already
        header.set("C", before=123)
        assert list(header) == ["A", "B", "C"]
        assert not header._modified
    
        header.set("C", after=123)
        assert list(header) == ["A", "B", "C"]
>       assert not header._modified
E       AssertionError: assert not True
E        +  where True = A       = 'B       '                                                            \nB       = 'C       '                 ...                                      \nC       = 'D       '                                                            ._modified

astropy/io/fits/tests/test_header.py:2070: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 126 passed in 0.27s
```

## 原始行 485 · file_change

```
{
  "id": "item_313",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/header.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 488 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_unnecessary_move astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_hierarch_card_insert_delete astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_rvkc_insert_after astropy/io/fits/tests/test_header.py::TestRecordValuedKeywordCards::test_rvkc_delete -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
....                                                                     [100%]
4 passed in 0.06s
```

## 原始行 491 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from astropy.io.fits.header import Header
from astropy.io.fits.file import _File
from astropy.io.fits.scripts.fitsheader import HeaderFormatter
for x in [Header._countblanks,Header._updateindices,Header.append,Header.count,HeaderFormatter.__init__,HeaderFormatter.close,_File.__init__]: print(x.__qualname__,inspect.signature(x))
PY"
```

退出码：`0`

输出：
```
Header._countblanks (self)
Header._updateindices (self, idx, increment=True)
Header.append (self, card=None, useblanks=True, bottom=False, end=False)
Header.count (self, keyword)
HeaderFormatter.__init__ (self, filename, verbose=True)
HeaderFormatter.close (self)
_File.__init__ (self, fileobj=None, mode=None, memmap=None, overwrite=False, cache=True, *, use_fsspec=None, fsspec_kwargs=None, decompress_in_memory=False)
```

## 原始行 494 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto_overwrite astropy/io/fits/tests/test_core.py::TestFileFunctions::test_write_read_gzip_file astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_totxtfile astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_tofile astropy/io/fits/tests/test_fitsheader.py astropy/io/fits/tests/test_fsspec.py::test_fsspec_local astropy/io/fits/tests/test_fsspec.py::test_fsspec_local_write astropy/io/fits/tests/test_fsspec.py::test_fsspec_compressed astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
.............................                                            [100%]
29 passed in 0.33s
```

## 原始行 497 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os
import tempfile
from pathlib import Path
import numpy as np
from astropy.io import fits
from astropy.io.fits.scripts.fitsheader import HeaderFormatter

home = tempfile.mkdtemp()
os.environ['HOME'] = home
path = Path('~/roundtrip.fits')
fits.writeto(path, np.arange(4), overwrite=True)
assert fits.getdata(path).tolist() == [0, 1, 2, 3]
formatter = HeaderFormatter(path)
try:
    assert 'NAXIS' in formatter.parse()
finally:
    formatter.close()
table = fits.BinTableHDU.from_columns([fits.Column(name='x', format='J', array=[1, 2])])
table.dump(Path('~/data.txt'), Path('~/columns.txt'), Path('~/header.txt'))
loaded = fits.BinTableHDU.load(Path('~/data.txt'), Path('~/columns.txt'), Path('~/header.txt'))
assert loaded.data['x'].tolist() == [1, 2]
print('tilde round trips passed')
PY
git diff --check"
```

退出码：`0`

输出：
```
tilde round trips passed
```

## 原始行 500 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestCore::test_fits_file_path_object astropy/io/fits/tests/test_core.py::TestCore::test_fits_file_bytes_object -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
F
=================================== FAILURES ===================================
_____________________ TestCore.test_fits_file_path_object ______________________

self = <astropy.io.fits.tests.test_core.TestCore object at 0x7b3919fd0e10>

    def test_fits_file_path_object(self):
        """
        Testing when fits file is passed as pathlib.Path object #4412.
        """
        fpath = pathlib.Path(self.data("tdim.fits"))
        with fits.open(fpath) as hdulist:
>           assert hdulist[0].filebytes() == 2880
E           assert 0 == 2880
E            +  where 0 = filebytes()
E            +    where filebytes = <astropy.io.fits.hdu.image.PrimaryHDU object at 0x7b3919fa8d50>.filebytes

astropy/io/fits/tests/test_core.py:81: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestCore::test_fits_file_path_object
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed in 0.07s
```

## 原始行 503 · command_execution

命令：
```
/bin/bash -lc "sed -n '990,1010p' astropy/io/fits/hdu/base.py; grep -RIn \"def filebytes\" astropy/io/fits/hdu"
```

退出码：`0`

输出：
```
        """
        return first(header.keys()) not in ("SIMPLE", "XTENSION")

    @property
    def size(self):
        """
        Size (in bytes) of the data portion of the HDU.
        """
        return self._header.data_size

    def filebytes(self):
        """
        Calculates and returns the number of bytes that this HDU will write to
        a file.
        """
        f = _File()
        # TODO: Fix this once new HDU writing API is settled on
        return self._writeheader(f)[1] + self._writedata(f)[1]

    def fileinfo(self):
        """
astropy/io/fits/hdu/base.py:1000:    def filebytes(self):
```

## 原始行 506 · file_change

```
{
  "id": "item_327",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 509 · file_change

```
{
  "id": "item_329",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/file.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 511 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestCore::test_fits_file_path_object astropy/io/fits/tests/test_core.py::TestCore::test_fits_file_bytes_object -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
..                                                                       [100%]
2 passed in 0.04s
```

## 原始行 514 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
..F
=================================== FAILURES ===================================
____________________________ TestCore.test_byteswap ____________________________

self = <astropy.io.fits.tests.test_core.TestCore object at 0x79df40934990>

    def test_byteswap(self):
        p = fits.PrimaryHDU()
        lst = fits.HDUList()
    
        n = np.array([1, 60000, 0], dtype="u2").astype("i2")
    
        c = fits.Column(name="foo", format="i2", bscale=1, bzero=32768, array=n)
        t = fits.BinTableHDU.from_columns([c])
    
        lst.append(p)
        lst.append(t)
    
>       lst.writeto(self.temp("test.fits"), overwrite=True)

astropy/io/fits/tests/test_core.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:1070: in writeto
    hdu._writeto(hdulist._file)
astropy/io/fits/hdu/base.py:720: in _writeto
    self._writeto_internal(fileobj, inplace, copy)
astropy/io/fits/hdu/base.py:738: in _writeto_internal
    data_offset, data_size = self._writedata(fileobj)
                             ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:662: in _writedata
    size += self._writedata_internal(fileobj)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/table.py:916: in _writedata_internal
    with _binary_table_byte_swap(self.data) as data:
/opt/miniconda3/envs/testbed/lib/python3.11/contextlib.py:137: in __enter__
    return next(self.gen)
           ^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data = FITS_rec([(1.0,), (-5536.0,), (0.0,)],
         dtype=(numpy.record, [('foo', '<i4')]))

    @contextlib.contextmanager
    def _binary_table_byte_swap(data):
        """
        Ensures that all the data of a binary FITS table (represented as a FITS_rec
        object) is in a big-endian byte order.  Columns are swapped in-place one
        at a time, and then returned to their previous byte order when this context
        manager exits.
    
        Because a new dtype is needed to represent the byte-swapped columns, the
        new dtype is temporarily applied as well.
        """
        orig_dtype = data.dtype
    
        names = []
        formats = []
        offsets = []
    
        to_swap = []
    
        if sys.byteorder == "little":
            swap_types = ("<", "=")
        else:
            swap_types = ("<",)
    
        for idx, name in enumerate(orig_dtype.names):
>           field = _get_recarray_field(data, idx)
                    ^^^^^^^^^^^^^^^^^^^
E           NameError: name '_get_recarray_field' is not defined

astropy/io/fits/hdu/table.py:1493: NameError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestCore::test_byteswap - NameErro...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 2 passed in 0.12s
```

## 原始行 517 · command_execution

命令：
```
/bin/bash -lc "sed -n '20,48p' astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```
















from astropy.io.fits.fitsrec import FITS_rec
from astropy.io.fits.header import Header, _pad_length
from astropy.io.fits.util import _is_int, _str_to_num, path_like
from astropy.utils import lazyproperty

from .base import DELAYED, ExtensionHDU, _ValidHDU


class FITSTableDumpDialect(csv.excel):
    """
    A CSV dialect for the Astropy format of ASCII dumps of FITS tables.
    """
```

## 原始行 520 · file_change

```
{
  "id": "item_336",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 522 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
..F
=================================== FAILURES ===================================
____________________________ TestCore.test_byteswap ____________________________

self = <astropy.io.fits.tests.test_core.TestCore object at 0x79c80f3c0810>

    def test_byteswap(self):
        p = fits.PrimaryHDU()
        lst = fits.HDUList()
    
        n = np.array([1, 60000, 0], dtype="u2").astype("i2")
    
        c = fits.Column(name="foo", format="i2", bscale=1, bzero=32768, array=n)
        t = fits.BinTableHDU.from_columns([c])
    
        lst.append(p)
        lst.append(t)
    
>       lst.writeto(self.temp("test.fits"), overwrite=True)

astropy/io/fits/tests/test_core.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/io/fits/hdu/hdulist.py:1070: in writeto
    hdu._writeto(hdulist._file)
astropy/io/fits/hdu/base.py:720: in _writeto
    self._writeto_internal(fileobj, inplace, copy)
astropy/io/fits/hdu/base.py:738: in _writeto_internal
    data_offset, data_size = self._writedata(fileobj)
                             ^^^^^^^^^^^^^^^^^^^^^^^^
astropy/io/fits/hdu/base.py:662: in _writedata
    size += self._writedata_internal(fileobj)
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.io.fits.hdu.table.BinTableHDU object at 0x79c81005b2d0>
fileobj = <astropy.io.fits.file._File <_io.BufferedWriter name='/tmp/fits-test-_iuyx1ws/test.fits'>>

    def _writedata_internal(self, fileobj):
        size = 0
    
        if self.data is None:
            return size
    
        with _binary_table_byte_swap(self.data) as data:
>           if _has_unicode_fields(data):
               ^^^^^^^^^^^^^^^^^^^
E           NameError: name '_has_unicode_fields' is not defined

astropy/io/fits/hdu/table.py:917: NameError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestCore::test_byteswap - NameErro...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 2 passed in 0.11s
```

## 原始行 525 · command_execution

命令：
```
/bin/bash -lc "grep -n \"_has_unicode_fields\\|_ascii_encode\" astropy/io/fits/hdu/table.py"
```

退出码：`0`

输出：
```
917:            if _has_unicode_fields(data):
```

## 原始行 527 · file_change

```
{
  "id": "item_340",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/hdu/table.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 529 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
..F
=================================== FAILURES ===================================
____________________________ TestCore.test_byteswap ____________________________

self = <astropy.io.fits.tests.test_core.TestCore object at 0x757206c4c690>

    def test_byteswap(self):
        p = fits.PrimaryHDU()
        lst = fits.HDUList()
    
        n = np.array([1, 60000, 0], dtype="u2").astype("i2")
    
        c = fits.Column(name="foo", format="i2", bscale=1, bzero=32768, array=n)
        t = fits.BinTableHDU.from_columns([c])
    
        lst.append(p)
        lst.append(t)
    
        lst.writeto(self.temp("test.fits"), overwrite=True)
    
        with fits.open(self.temp("test.fits")) as p:
>           assert p[1].data[1]["foo"] == 60000.0
E           assert np.float64(-5536.0) == 60000.0

astropy/io/fits/tests/test_core.py:73: AssertionError
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestCore::test_byteswap - assert n...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 1 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 2 passed in 0.09s
```

## 原始行 532 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto astropy/io/fits/tests/test_core.py::TestConvenienceFunctions::test_writeto_overwrite astropy/io/fits/tests/test_core.py::TestFileFunctions::test_write_read_gzip_file astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_totxtfile astropy/io/fits/tests/test_header.py::TestHeaderFunctions::test_tofile astropy/io/fits/tests/test_fitsheader.py astropy/io/fits/tests/test_fsspec.py::test_fsspec_local astropy/io/fits/tests/test_fsspec.py::test_fsspec_local_write astropy/io/fits/tests/test_fsspec.py::test_fsspec_compressed astropy/io/fits/tests/test_table.py::TestTableFunctions::test_dump_overwrite -q --disable-warnings --maxfail=1
git diff --check'
```

退出码：`0`

输出：
```
Internet access disabled
.............................                                            [100%]
29 passed in 0.36s
```

## 原始行 535 · command_execution

命令：
```
/bin/bash -lc "sed -n '960,1035p' astropy/io/fits/column.py; sed -n '1280,1325p' astropy/io/fits/column.py; sed -n '555,700p' astropy/io/fits/column.py"
```

退出码：`0`

输出：
```
    def copy(self):
        """
        Return a copy of this `Column`.
        """
        tmp = Column(format="I")  # just use a throw-away format
        tmp.__dict__ = self.__dict__.copy()
        return tmp

    @staticmethod
    def _convert_format(format, cls):
        """The format argument to this class's initializer may come in many
        forms.  This uses the given column format class ``cls`` to convert
        to a format of that type.

        TODO: There should be an abc base class for column format classes
        """
        # Short circuit in case we're already a _BaseColumnFormat--there is at
        # least one case in which this can happen
        if isinstance(format, _BaseColumnFormat):
            return format, format.recformat

        if format in NUMPY2FITS:
            with suppress(VerifyError):
                # legit recarray format?
                recformat = format
                format = cls.from_recformat(format)

        try:
            # legit FITS format?
            format = cls(format)
            recformat = format.recformat
        except VerifyError:
            raise VerifyError(f"Illegal format `{format}`.")

        return format, recformat

    @classmethod
    def _verify_keywords(
        cls,
        name=None,
        format=None,
        unit=None,
        null=None,
        bscale=None,
        bzero=None,
        disp=None,
        start=None,
        dim=None,
        ascii=None,
        coord_type=None,
        coord_unit=None,
        coord_ref_point=None,
        coord_ref_value=None,
        coord_inc=None,
        time_ref_pos=None,
    ):
        """
        Given the keyword arguments used to initialize a Column, specifically
        those that typically read from a FITS header (so excluding array),
        verify that each keyword has a valid value.

        Returns a 2-tuple of dicts.  The first maps valid keywords to their
        values.  The second maps invalid keywords to a 2-tuple of their value,
        and a message explaining why they were found invalid.
        """
        valid = {}
        invalid = {}

        try:
            format, recformat = cls._determine_formats(format, start, dim, ascii)
            valid.update(format=format, recformat=recformat)
        except (ValueError, VerifyError) as err:
            msg = (
                f"Column format option (TFORMn) failed verification: {err!s} "
                "The invalid value will be ignored for the purpose of "
                "formatting the data in this column."

            if msg is None:
                valid["time_ref_pos"] = time_ref_pos
            else:
                invalid["time_ref_pos"] = (time_ref_pos, msg)

        return valid, invalid

    @classmethod
    def _determine_formats(cls, format, start, dim, ascii):
        """
        Given a format string and whether or not the Column is for an
        ASCII table (ascii=None means unspecified, but lean toward binary table
        where ambiguous) create an appropriate _BaseColumnFormat instance for
        the column's format, and determine the appropriate recarray format.

        The values of the start and dim keyword arguments are also useful, as
        the former is only valid for ASCII tables and the latter only for
        BINARY tables.
        """
        # If the given format string is unambiguously a Numpy dtype or one of
        # the Numpy record format type specifiers supported by Astropy then that
        # should take priority--otherwise assume it is a FITS format
        if isinstance(format, np.dtype):
            format, _, _ = _dtype_to_recformat(format)

        # check format
        if ascii is None and not isinstance(format, _BaseColumnFormat):
            # We're just give a string which could be either a Numpy format
            # code, or a format for a binary column array *or* a format for an
            # ASCII column array--there may be many ambiguities here.  Try our
            # best to guess what the user intended.
            format, recformat = cls._guess_format(format, start, dim)
        elif not ascii and not isinstance(format, _BaseColumnFormat):
            format, recformat = cls._convert_format(format, _ColumnFormat)
        elif ascii and not isinstance(format, _AsciiColumnFormat):
            format, recformat = cls._convert_format(format, _AsciiColumnFormat)
        else:
            # The format is already acceptable and unambiguous
            recformat = format.recformat

        return format, recformat

    @classmethod
    def _guess_format(cls, format, start, dim):
        if start and dim:
class Column(NotifierMixin):
    """
    Class which contains the definition of one column, e.g.  ``ttype``,
    ``tform``, etc. and the array containing values for the column.
    """

    def __init__(
        self,
        name=None,
        format=None,
        unit=None,
        null=None,
        bscale=None,
        bzero=None,
        disp=None,
        start=None,
        dim=None,
        array=None,
        ascii=None,
        coord_type=None,
        coord_unit=None,
        coord_ref_point=None,
        coord_ref_value=None,
        coord_inc=None,
        time_ref_pos=None,
    ):
        """
        Construct a `Column` by specifying attributes.  All attributes
        except ``format`` can be optional; see :ref:`astropy:column_creation`
        and :ref:`astropy:creating_ascii_table` for more information regarding
        ``TFORM`` keyword.

        Parameters
        ----------
        name : str, optional
            column name, corresponding to ``TTYPE`` keyword

        format : str
            column format, corresponding to ``TFORM`` keyword

        unit : str, optional
            column unit, corresponding to ``TUNIT`` keyword

        null : str, optional
            null value, corresponding to ``TNULL`` keyword

        bscale : int-like, optional
            bscale value, corresponding to ``TSCAL`` keyword

        bzero : int-like, optional
            bzero value, corresponding to ``TZERO`` keyword

        disp : str, optional
            display format, corresponding to ``TDISP`` keyword

        start : int, optional
            column starting position (ASCII table only), corresponding
            to ``TBCOL`` keyword

        dim : str, optional
            column dimension corresponding to ``TDIM`` keyword

        array : iterable, optional
            a `list`, `numpy.ndarray` (or other iterable that can be used to
            initialize an ndarray) providing initial data for this column.
            The array will be automatically converted, if possible, to the data
            format of the column.  In the case were non-trivial ``bscale``
            and/or ``bzero`` arguments are given, the values in the array must
            be the *physical* values--that is, the values of column as if the
            scaling has already been applied (the array stored on the column
            object will then be converted back to its storage values).

        ascii : bool, optional
            set `True` if this describes a column for an ASCII table; this
            may be required to disambiguate the column format

        coord_type : str, optional
            coordinate/axis type corresponding to ``TCTYP`` keyword

        coord_unit : str, optional
            coordinate/axis unit corresponding to ``TCUNI`` keyword

        coord_ref_point : int-like, optional
            pixel coordinate of the reference point corresponding to ``TCRPX``
            keyword

        coord_ref_value : int-like, optional
            coordinate value at reference point corresponding to ``TCRVL``
            keyword

        coord_inc : int-like, optional
            coordinate increment at reference point corresponding to ``TCDLT``
            keyword

        time_ref_pos : str, optional
            reference position for a time coordinate column corresponding to
            ``TRPOS`` keyword
        """
        if format is None:
            raise ValueError("Must specify format to construct Column.")

        # any of the input argument (except array) can be a Card or just
        # a number/string
        kwargs = {"ascii": ascii}
        for attr in KEYWORD_ATTRIBUTES:
            value = locals()[attr]  # get the argument's value

            if isinstance(value, Card):
                value = value.value

            kwargs[attr] = value

        valid_kwargs, invalid_kwargs = self._verify_keywords(**kwargs)

        if invalid_kwargs:
            msg = ["The following keyword arguments to Column were invalid:"]

            for val in invalid_kwargs.values():
                msg.append(indent(val[1], 4 * " "))

            raise VerifyError("\n".join(msg))

        for attr in KEYWORD_ATTRIBUTES:
            setattr(self, attr, valid_kwargs.get(attr))

        # TODO: Try to eliminate the following two special cases
        # for recformat and dim:
        # This is not actually stored as an attribute on columns for some
        # reason
        recformat = valid_kwargs["recformat"]

        # The 'dim' keyword's original value is stored in self.dim, while
        # *only* the tuple form is stored in self._dims.
        self._dims = self.dim
        self.dim = dim

        # Awful hack to use for now to keep track of whether the column holds
        # pseudo-unsigned int data
        self._pseudo_unsigned_ints = False

        # if the column data is not ndarray, make it to be one, i.e.
        # input arrays can be just list or tuple, not required to be ndarray
        # does not include Object array because there is no guarantee
        # the elements in the object array are consistent.
        if not isinstance(array, (np.ndarray, chararray.chararray, Delayed)):
            try:  # try to convert to a ndarray first
```

## 原始行 538 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
from astropy.io import fits
c=fits.Column(name='foo',format='i2',bscale=1,bzero=32768,array=np.array([1,60000,0],dtype='u2').astype('i2'))
print(c.format,c._recformat,c.array.dtype,c.array)
t=fits.BinTableHDU.from_columns([c]); print(t.columns[0].format,t.data.dtype,t.data['foo'],t.header)
PY"
```

退出码：`1`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
AttributeError: 'Column' object has no attribute '_recformat'
```

## 原始行 541 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
from astropy.io import fits
c=fits.Column(name='foo',format='i2',bscale=1,bzero=32768,array=np.array([1,60000,0],dtype='u2').astype('i2'))
print(c.format,repr(c.format),c.format.recformat,c.array.dtype,c.array)
t=fits.BinTableHDU.from_columns([c]); print(t.columns[0].format,t.columns[0].format.recformat,t.data.dtype,t.data['foo'],t.header['TFORM1'])
PY"
```

退出码：`0`

输出：
```
i2 'i2' i4 int32 [    1 -5536     0]
J i4 (numpy.record, [('foo', '<i4')]) [    1 -5536     0] J
```

## 原始行 544 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from astropy.io.fits.column import *
import astropy.io.fits.column as c
print(c.NUMPY2FITS.get('i2'))
print(c._convert_record2fits('i2'))
x=c._ColumnFormat.from_recformat('i2'); print(x,repr(x),x.recformat)
print(c.Column._convert_format('i2',c._ColumnFormat))
PY"
```

退出码：`0`

输出：
```
I
I
I 'I' i2
('I', 'i2')
```

## 原始行 547 · file_change

```
{
  "id": "item_353",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/column.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 550 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestCore::test_byteswap -q --disable-warnings --maxfail=1'
```

退出码：`0`

输出：
```
Internet access disabled
.                                                                        [100%]
1 passed in 0.04s
```

## 原始行 552 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py -q --disable-warnings --maxfail=1'
```

退出码：`1`

输出：
```
Internet access disabled
...................FE
==================================== ERRORS ====================================
__________________ ERROR at teardown of TestCore.test_getext ___________________

E   ResourceWarning: unclosed file <_io.BufferedReader name='/testbed/astropy/io/fits/tests/data/test0.fits'>
All traceback entries are hidden. Pass `--full-trace` to see hidden and internal frames.

The above exception was the direct cause of the following exception:

cls = <class '_pytest.runner.CallInfo'>
func = <function call_and_report.<locals>.<lambda> at 0x7f0cab5edee0>
when = 'teardown'
reraise = (<class '_pytest.outcomes.Exit'>, <class 'KeyboardInterrupt'>)

    @classmethod
    def from_call(
        cls,
        func: Callable[[], TResult],
        when: Literal["collect", "setup", "call", "teardown"],
        reraise: type[BaseException] | tuple[type[BaseException], ...] | None = None,
    ) -> CallInfo[TResult]:
        """Call func, wrapping the result in a CallInfo.
    
        :param func:
            The function to call. Called without arguments.
        :type func: Callable[[], _pytest.runner.TResult]
        :param when:
            The phase in which the function is called.
        :param reraise:
            Exception or exceptions that shall propagate if raised by the
            function, instead of being wrapped in the CallInfo.
        """
        excinfo = None
        instant = timing.Instant()
        try:
>           result: TResult | None = func()
                                     ^^^^^^

/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py:353: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/runner.py:245: in <lambda>
    lambda: runtest_hook(item=item, **kwds),
            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_hooks.py:512: in __call__
    return self._hookexec(self.name, self._hookimpls.copy(), kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pluggy/_manager.py:120: in _hookexec
    return self._inner_hookexec(hook_name, methods, kwargs, firstresult)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/logging.py:858: in pytest_runtest_teardown
    yield
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/capture.py:905: in pytest_runtest_teardown
    return (yield)
            ^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py:163: in pytest_runtest_teardown
    collect_unraisable(item.config)
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py:79: in collect_unraisable
    raise errors[0]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

config = <_pytest.config.Config object at 0x7f0cd7df2e10>

    def collect_unraisable(config: Config) -> None:
        pop_unraisable = config.stash[unraisable_exceptions].pop
        errors: list[pytest.PytestUnraisableExceptionWarning | RuntimeError] = []
        meta = None
        hook_error = None
        try:
            while True:
                try:
                    meta = pop_unraisable()
                except IndexError:
                    break
    
                if isinstance(meta, BaseException):
                    hook_error = RuntimeError("Failed to process unraisable exception")
                    hook_error.__cause__ = meta
                    errors.append(hook_error)
                    continue
    
                msg = meta.msg
                try:
>                   warnings.warn(pytest.PytestUnraisableExceptionWarning(msg))
E                   pytest.PytestUnraisableExceptionWarning: Exception ignored in: <_io.FileIO name='/testbed/astropy/io/fits/tests/data/test0.fits' mode='rb' closefd=True>
E                   Enable tracemalloc to get traceback where the object was allocated.
E                   See https://docs.pytest.org/en/stable/how-to/capture-warnings.html#resource-warnings for more info.

/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/unraisableexception.py:67: PytestUnraisableExceptionWarning
=================================== FAILURES ===================================
_____________________________ TestCore.test_getext _____________________________

self = <astropy.io.fits.tests.test_core.TestCore object at 0x7f0cab7cd990>

    def test_getext(self):
        """
        Test the various different ways of specifying an extension header in
        the convenience functions.
        """
        filename = self.data("test0.fits")
    
        hl, ext = _getext(filename, "readonly", 1)
        assert ext == 1
        hl.close()
    
        pytest.raises(ValueError, _getext, filename, "readonly", 1, 2)
        pytest.raises(ValueError, _getext, filename, "readonly", (1, 2))
        pytest.raises(ValueError, _getext, filename, "readonly", "sci", "sci")
        pytest.raises(TypeError, _getext, filename, "readonly", 1, 2, 3)
    
        hl, ext = _getext(filename, "readonly", ext=1)
        assert ext == 1
        hl.close()
    
        hl, ext = _getext(filename, "readonly", ext=("sci", 2))
        assert ext == ("sci", 2)
        hl.close()
    
        pytest.raises(
            TypeError, _getext, filename, "readonly", 1, ext=("sci", 2), extver=3
        )
        pytest.raises(
            TypeError, _getext, filename, "readonly", ext=("sci", 2), extver=3
        )
    
        hl, ext = _getext(filename, "readonly", "sci")
        assert ext == ("sci", 1)
        hl.close()
    
        hl, ext = _getext(filename, "readonly", "sci", 1)
        assert ext == ("sci", 1)
        hl.close()
    
        hl, ext = _getext(filename, "readonly", ("sci", 1))
        assert ext == ("sci", 1)
        hl.close()
    
        hl, ext = _getext(
            filename, "readonly", "sci", extver=1, do_not_scale_image_data=True
        )
        assert ext == ("sci", 1)
        hl.close()
    
        pytest.raises(TypeError, _getext, filename, "readonly", "sci", ext=1)
>       pytest.raises(TypeError, _getext, filename, "readonly", "sci", 1, extver=2)
E       Failed: DID NOT RAISE <class 'TypeError'>

astropy/io/fits/tests/test_core.py:375: Failed
=========================== short test summary info ============================
FAILED astropy/io/fits/tests/test_core.py::TestCore::test_getext - Failed: DI...
ERROR astropy/io/fits/tests/test_core.py::TestCore::test_getext - pytest.Pyte...
!!!!!!!!!!!!!!!!!!!!!!!!!! stopping after 2 failures !!!!!!!!!!!!!!!!!!!!!!!!!!!
1 failed, 19 passed, 1 error in 0.15s
```

## 原始行 555 · file_change

```
{
  "id": "item_358",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/io/fits/convenience.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 557 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/io/fits/tests/test_core.py::TestCore::test_getext astropy/io/fits/tests/test_core.py::TestFileFunctions::test_mmap_closing astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_bzipped astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_lzma astropy/io/fits/tests/test_core.py::TestFileFunctions::test_open_zipped -q --disable-warnings --maxfail=1; git diff --check; git status --short'
```

退出码：`0`

输出：
```
Internet access disabled
.....                                                                    [100%]
5 passed in 0.10s
 M astropy/io/fits/card.py
 M astropy/io/fits/column.py
 M astropy/io/fits/convenience.py
 M astropy/io/fits/file.py
 M astropy/io/fits/fitsrec.py
 M astropy/io/fits/hdu/base.py
 M astropy/io/fits/hdu/compressed/compressed.py
 M astropy/io/fits/hdu/groups.py
 M astropy/io/fits/hdu/hdulist.py
 M astropy/io/fits/hdu/image.py
 M astropy/io/fits/hdu/table.py
 M astropy/io/fits/header.py
 M astropy/io/fits/scripts/fitsheader.py
 M astropy/io/fits/util.py
```

## 原始行 559 · agent_message

```
Implemented home-directory path support across FITS I/O.

Key updates:

- Local `str`, `bytes`, and `os.PathLike` paths now expand `~`.
- URLs, fsspec inputs, and open file objects remain unmodified.
- Read/write, compressed files, Header file operations, table dump/load, and `HeaderFormatter` support tilde paths.
- Restored masked Header and low-level FITS I/O helpers while preserving modes, overwrite handling, memory mapping, and resource ownership.

Validation:

- 29 focused FITS path/formatter/fsspec/table tests passed.
- Additional compressed-file, mmap, Header, and path-like tests passed.
- Direct string, bytes, and `pathlib.Path` tilde round trips passed.
- `git diff --check` and compilation passed.
```
