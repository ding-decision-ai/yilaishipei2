# Codex baseline: mlflow__mlflow.93dab383.test_validation.2e1c5076.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the scorer modules and focused tests first, then implement the missing helpers and run the narrow test suite before broader validation. I’ll keep all investigation within `/testbed` as requested.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' mlflow/genai/scorers/base.py && sed -n '1,300p' mlflow/genai/scorers/validation.py && rg -n \"def get_all_scorers|class .*Scorer|validate_columns|valid_data_for_builtin_scorers|validate_scorers|@scorer\" mlflow/genai/scorers tests -g '*.py'"
```

退出码：`127`

输出：
```
import functools
import inspect
import logging
from dataclasses import asdict, dataclass
from enum import Enum
from typing import Any, Callable, Literal, TypeAlias

from pydantic import BaseModel, PrivateAttr

import mlflow
from mlflow.entities import Assessment, Feedback
from mlflow.entities.assessment import DEFAULT_FEEDBACK_NAME
from mlflow.entities.trace import Trace
from mlflow.exceptions import MlflowException
from mlflow.tracking import get_tracking_uri
from mlflow.utils.databricks_utils import is_in_databricks_runtime
from mlflow.utils.uri import is_databricks_uri

_logger = logging.getLogger(__name__)

# Serialization version for tracking changes to the serialization format
_SERIALIZATION_VERSION = 1
_AggregationFunc: TypeAlias = Callable[[list[int | float]], float]
_AggregationType: TypeAlias = (
    Literal["min", "max", "mean", "median", "variance", "p90"] | _AggregationFunc
)


class ScorerKind(Enum):
    CLASS = "class"
    BUILTIN = "builtin"
    DECORATOR = "decorator"


_ALLOWED_SCORERS_FOR_REGISTRATION = [ScorerKind.BUILTIN, ScorerKind.DECORATOR]


class ScorerStatus(Enum):
    """Status of a scorer.

    Scorer status is determined by the sample rate due to the backend not having
    a notion of whether a scorer is started or stopped.
    """

    UNREGISTERED = "UNREGISTERED"  # sampling config not set
    STARTED = "STARTED"  # sample_rate > 0
    STOPPED = "STOPPED"  # sample_rate == 0


@dataclass
class ScorerSamplingConfig:
    """Configuration for registered scorer sampling."""

    sample_rate: float | None = None
    filter_string: str | None = None


AggregationFunc = Callable[[list[float]], float]  # List of per-row value -> aggregated value


@dataclass
class SerializedScorer:
    """
    Dataclass defining the serialization schema for Scorer objects.
    """

    # Core scorer fields
    name: str
    aggregations: list[str] | None = None
    description: str | None = None

    # Version metadata
    mlflow_version: str = mlflow.__version__
    serialization_version: int = _SERIALIZATION_VERSION

    # Builtin scorer fields (for scorers from mlflow.genai.scorers.builtin_scorers)
    builtin_scorer_class: str | None = None
    builtin_scorer_pydantic_data: dict[str, Any] | None = None

    # Decorator scorer fields (for @scorer decorated functions)
    call_source: str | None = None
    call_signature: str | None = None
    original_func_name: str | None = None

    # InstructionsJudge fields (for make_judge created judges)
    instructions_judge_pydantic_data: dict[str, Any] | None = None

    def __post_init__(self):
        """Validate that exactly one type of scorer fields is present."""
        has_builtin_fields = self.builtin_scorer_class is not None
        has_decorator_fields = self.call_source is not None
        has_instructions_fields = self.instructions_judge_pydantic_data is not None

        # Count how many field types are present
        field_count = sum([has_builtin_fields, has_decorator_fields, has_instructions_fields])

        if field_count == 0:
            raise ValueError(
                "SerializedScorer must have either builtin scorer fields "
                "(builtin_scorer_class), decorator scorer fields (call_source), "
                "or instructions judge fields (instructions_judge_pydantic_data) present"
            )

        if field_count > 1:
            raise ValueError(
                "SerializedScorer cannot have multiple types of scorer fields "
                "present simultaneously"
            )


class Scorer(BaseModel):
    name: str
    aggregations: list[_AggregationType] | None = None
    description: str | None = None

    _cached_dump: dict[str, Any] | None = PrivateAttr(default=None)
    _sampling_config: ScorerSamplingConfig | None = PrivateAttr(default=None)
    _registered_backend: str | None = PrivateAttr(default=None)

    @property
    def sample_rate(self) -> float | None:
        """Get the sample rate for this scorer. Available when registered for monitoring."""
        return self._sampling_config.sample_rate if self._sampling_config else None

    @property
    def filter_string(self) -> str | None:
        """Get the filter string for this scorer."""
        return self._sampling_config.filter_string if self._sampling_config else None

    @property
    def status(self) -> ScorerStatus:
        """Get the status of this scorer, using only the local state."""

        if self._registered_backend is None:
            return ScorerStatus.UNREGISTERED

        return ScorerStatus.STARTED if (self.sample_rate or 0) > 0 else ScorerStatus.STOPPED

    def __repr__(self) -> str:
        # Get the standard representation from the parent class
        base_repr = super().__repr__()
        filter_string = self.filter_string
        if filter_string is not None:
            filter_string = f"'{filter_string}'"

        # Inject the property's value into the repr string
        return f"{base_repr[:-1]}, sample_rate={self.sample_rate}, filter_string={filter_string})"

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Override model_dump to include source code."""

        # Return cached dump if available (prevents re-serialization issues with dynamic functions)
        if self._cached_dump is not None:
            return self._cached_dump

        # Check if this is a decorator scorer
        if not getattr(self, "_original_func", None):
            # BuiltInScorer overrides `model_dump`, so this is neither a builtin scorer nor a
            # decorator scorer
            raise MlflowException.invalid_parameter_value(
                f"Unsupported scorer type: {self.__class__.__name__}. "
                f"Scorer serialization only supports:\n"
                f"1. Builtin scorers (from mlflow.genai.scorers.builtin_scorers)\n"
                f"2. Decorator-created scorers (using @scorer decorator)\n"
                f"Direct subclassing of Scorer is not supported for serialization. "
                f"Please use the @scorer decorator instead."
            )

        # Decorator scorer - extract and store source code
        source_info = self._extract_source_code_info()

        # Create serialized scorer with all fields at once
        serialized = SerializedScorer(
            name=self.name,
            description=self.description,
            aggregations=self.aggregations,
            mlflow_version=mlflow.__version__,
            serialization_version=_SERIALIZATION_VERSION,
            call_source=source_info.get("call_source"),
            call_signature=source_info.get("call_signature"),
            original_func_name=source_info.get("original_func_name"),
        )
        self._cached_dump = asdict(serialized)
        return self._cached_dump

    def _extract_source_code_info(self) -> dict[str, str | None]:
        """Extract source code information for the original decorated function."""
        from mlflow.genai.scorers.scorer_utils import extract_function_body

        result = {"call_source": None, "call_signature": None, "original_func_name": None}

        # Extract original function source
        call_body, _ = extract_function_body(self._original_func)
        result["call_source"] = call_body
        result["original_func_name"] = self._original_func.__name__

        # Store the signature of the original function
        result["call_signature"] = str(inspect.signature(self._original_func))

        return result

    @classmethod
    def model_validate(cls, obj: Any) -> "Scorer":
        """Override model_validate to reconstruct scorer from source code."""
        # Handle SerializedScorer object
        if isinstance(obj, SerializedScorer):
            serialized = obj
        # Handle dict object
        elif isinstance(obj, dict):
            # Parse the serialized data using our dataclass
            try:
                serialized = SerializedScorer(**obj)
            except Exception as e:
                raise MlflowException.invalid_parameter_value(
                    f"Failed to parse serialized scorer data: {e}"
                )
        else:
            raise MlflowException.invalid_parameter_value(
                f"Invalid scorer data: expected a SerializedScorer object or dictionary, "
                f"got {type(obj).__name__}. Scorer data must be either a SerializedScorer object "
                "or a dictionary containing serialized scorer information."
            )

        # Log version information for debugging
        if serialized.mlflow_version:
            _logger.debug(
                f"Deserializing scorer created with MLflow version: {serialized.mlflow_version}"
            )
        if serialized.serialization_version:
            _logger.debug(f"Scorer serialization version: {serialized.serialization_version}")

        if serialized.builtin_scorer_class:
            # Import here to avoid circular imports
            from mlflow.genai.scorers.builtin_scorers import BuiltInScorer

            return BuiltInScorer.model_validate(obj)

        # Handle decorator scorers
        elif serialized.call_source and serialized.call_signature and serialized.original_func_name:
            return cls._reconstruct_decorator_scorer(serialized)

        # Handle InstructionsJudge scorers
        elif serialized.instructions_judge_pydantic_data is not None:
            from mlflow.genai.judges.instructions_judge import InstructionsJudge

            data = serialized.instructions_judge_pydantic_data

            field_specs = {
                "instructions": str,
                "model": str,
            }

            errors = []
            for field, expected_type in field_specs.items():
                if field not in data:
                    errors.append(f"missing required field '{field}'")
                elif not isinstance(data[field], expected_type):
                    actual_type = type(data[field]).__name__
                    errors.append(
                        f"field '{field}' must be {expected_type.__name__}, got {actual_type}"
                    )

            if errors:
                raise MlflowException.invalid_parameter_value(
                    f"Failed to deserialize InstructionsJudge scorer '{serialized.name}': "
                    f"{'; '.join(errors)}"
                )

            feedback_value_type = str  # default to str
            if "feedback_value_type" in data and data["feedback_value_type"] is not None:
                feedback_value_type = InstructionsJudge._deserialize_feedback_value_type(
                    data["feedback_value_type"]
                )

            try:
                return InstructionsJudge(
                    name=serialized.name,
                    description=serialized.description,
                    instructions=data["instructions"],
                    model=data["model"],
import importlib
import logging
from collections import defaultdict
from typing import Any, Callable

from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import AggregationFunc, Scorer
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException





try:
    # `pandas` is not required for `mlflow-skinny`.
    import pandas as pd
except ImportError:
    pass

_logger = logging.getLogger(__name__)


IS_DBX_AGENTS_INSTALLED = importlib.util.find_spec("databricks.agents") is not None

























































































































































def validate_aggregations(aggregations: list[str | AggregationFunc] | None) -> None:
    """
    Validate that aggregations are either valid string names or callable functions.

    Args:
        aggregations: List of aggregation functions to validate. Can be strings from
                     the standard set or callable functions.
    """
    if not aggregations:
        return

    from mlflow.genai.scorers.aggregation import _AGGREGATE_FUNCTIONS

    valid_aggregation_names = set(_AGGREGATE_FUNCTIONS.keys())

    for agg in aggregations:
        if isinstance(agg, str):
            if agg not in valid_aggregation_names:
                raise MlflowException.invalid_parameter_value(
                    f"Invalid aggregation '{agg}'. Valid aggregations are: "
                    f"{sorted(valid_aggregation_names)}"
                )
        elif not callable(agg):
            raise MlflowException.invalid_parameter_value(
                f"Aggregation must be either a string from {sorted(valid_aggregation_names)} "
                f"or a callable function, got {type(agg).__name__}"
            )/bin/bash: line 1: rg: command not found
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc 'grep -n "''^def scorer'"\\|"'^class BuiltInScorer'"\\|"'^def get_all_scorers'"\\|"'^def valid_data'"\\|"'^def validate_scorers'"\\|validate_columns\" mlflow/genai/scorers/base.py mlflow/genai/scorers/builtin_scorers.py mlflow/genai/scorers/validation.py; sed -n '280,760p' mlflow/genai/scorers/base.py; sed -n '1,280p' mlflow/genai/scorers/builtin_scorers.py; find tests -path '*genai*scorer*' -type f -print"
```

退出码：`0`

输出：
```
mlflow/genai/scorers/base.py:847:def scorer(
mlflow/genai/scorers/builtin_scorers.py:259:class BuiltInScorer(Judge):
mlflow/genai/scorers/builtin_scorers.py:324:    def validate_columns(self, columns: set[str]) -> None:
mlflow/genai/scorers/builtin_scorers.py:535:    def validate_columns(self, columns: set[str]) -> None:
mlflow/genai/scorers/builtin_scorers.py:536:        super().validate_columns(columns)
mlflow/genai/scorers/builtin_scorers.py:911:    def validate_columns(self, columns: set[str]) -> None:
mlflow/genai/scorers/builtin_scorers.py:912:        super().validate_columns(columns)
mlflow/genai/scorers/builtin_scorers.py:1271:    def validate_columns(self, columns: set[str]) -> None:
mlflow/genai/scorers/builtin_scorers.py:1272:        super().validate_columns(columns)
mlflow/genai/scorers/builtin_scorers.py:1442:    def validate_columns(self, columns: set[str]) -> None:
mlflow/genai/scorers/builtin_scorers.py:1443:        super().validate_columns(columns)
                    model=data["model"],
                    feedback_value_type=feedback_value_type,
                    # TODO: add aggregations here once we support boolean/numeric judge outputs
                )
            except Exception as e:
                raise MlflowException.invalid_parameter_value(
                    f"Failed to create InstructionsJudge scorer '{serialized.name}': {e}"
                )

        # Invalid serialized data
        else:
            raise MlflowException.invalid_parameter_value(
                f"Failed to load scorer '{serialized.name}'. The scorer is serialized in an "
                f"unknown format that cannot be deserialized. Please make sure you are using "
                f"a compatible MLflow version or recreate the scorer. "
                f"Scorer was created with MLflow version: "
                f"{serialized.mlflow_version or 'unknown'}, "
                f"serialization version: {serialized.serialization_version or 'unknown'}, "
                f"current MLflow version: {mlflow.__version__}."
            )

    @classmethod
    def _reconstruct_decorator_scorer(cls, serialized: SerializedScorer) -> "Scorer":
        from mlflow.genai.scorers.scorer_utils import recreate_function

        # NB: Custom (@scorer) scorers use exec() during deserialization, which poses a code
        # execution risk. Only allow loading in Databricks runtime environments where the
        # execution environment is controlled.
        if not is_in_databricks_runtime():
            code_snippet = (
                "\n\nfrom mlflow.genai import scorer\n\n"
                f"@scorer\ndef {serialized.original_func_name}{serialized.call_signature}:\n"
            )
            for line in serialized.call_source.split("\n"):
                code_snippet += f"    {line}\n"

            is_databricks_remote = is_databricks_uri(get_tracking_uri())

            if is_databricks_remote:
                error_msg = (
                    f"Loading custom scorer '{serialized.name}' via remote access is not "
                    "supported. You are connected to a Databricks workspace but executing code "
                    "outside of it. Custom scorers require arbitrary code execution during "
                    "deserialization and must be loaded within the Databricks workspace for "
                    "security reasons.\n\n"
                    "To use this scorer:\n"
                    "1. Run your code inside the Databricks workspace (notebook or job), or\n"
                    "2. Copy the code below and use it directly in your source code, or\n"
                    "3. Use built-in scorers or make_judge() scorers instead\n\n"
                    f"Registered scorer code:\n{code_snippet}"
                )
            else:
                error_msg = (
                    f"Loading custom scorer '{serialized.name}' is not supported outside of "
                    "Databricks runtime environments due to security concerns. Custom scorers "
                    "require arbitrary code execution during deserialization.\n\n"
                    "To use this scorer, please:\n"
                    "1. Copy the code below and save it in your source code repository\n"
                    "2. Import and use it directly in your code, or\n"
                    "3. Use built-in scorers or make_judge() scorers instead\n\n"
                    f"Registered scorer code:\n{code_snippet}"
                )

            raise MlflowException.invalid_parameter_value(error_msg)

        try:
            recreated_func = recreate_function(
                serialized.call_source, serialized.call_signature, serialized.original_func_name
            )
        except Exception as e:
            raise MlflowException.invalid_parameter_value(
                f"Failed to recreate function from source code. "
                f"Scorer was created with MLflow version: "
                f"{serialized.mlflow_version or 'unknown'}, "
                f"serialization version: {serialized.serialization_version or 'unknown'}. "
                f"Current MLflow version: {mlflow.__version__}. "
                f"Error: {e}"
            )

        # Apply the scorer decorator to recreate the scorer
        # Rather than serializing and deserializing the `run` method of `Scorer`, we recreate the
        # Scorer using the original function and the `@scorer` decorator. This should be safe so
        # long as `@scorer` is a stable API.
        scorer_instance = scorer(
            recreated_func,
            name=serialized.name,
            description=serialized.description,
            aggregations=serialized.aggregations,
        )
        # Cache the serialized data to prevent re-serialization issues with dynamic functions
        original_serialized_data = asdict(serialized)
        object.__setattr__(scorer_instance, "_cached_dump", original_serialized_data)
        return scorer_instance

    def run(self, *, inputs=None, outputs=None, expectations=None, trace=None):
        from mlflow.evaluation import Assessment as LegacyAssessment

        merged = {
            "inputs": inputs,
            "outputs": outputs,
            "expectations": expectations,
            "trace": trace,
        }
        # Filter to only the parameters the function actually expects
        sig = inspect.signature(self.__call__)
        filtered = {k: v for k, v in merged.items() if k in sig.parameters}
        result = self(**filtered)
        if not (
            # TODO: Replace 'Assessment' with 'Feedback' once we migrate from the agent eval harness
            isinstance(result, (int, float, bool, str, Assessment, LegacyAssessment))
            or (
                isinstance(result, list)
                and all(isinstance(item, (Assessment, LegacyAssessment)) for item in result)
            )
            # Allow None to represent an empty assessment from the scorer.
            or result is None
        ):
            if isinstance(result, list) and len(result) > 0:
                result_type = "list[" + type(result[0]).__name__ + "]"
            else:
                result_type = type(result).__name__
            raise MlflowException.invalid_parameter_value(
                f"{self.name} must return one of int, float, bool, str, "
                f"Feedback, or list[Feedback]. Got {result_type}"
            )

        if isinstance(result, Feedback) and result.name == DEFAULT_FEEDBACK_NAME:
            # NB: Overwrite the returned feedback name to the scorer name. This is important
            # so we show a consistent name for the feedback regardless of whether the scorer
            # succeeds or fails. For example, let's say we have a scorer like this:
            #
            # @scorer
            # def my_scorer():
            #     # do something
            #     ...
            #     return Feedback(value=True)
            #
            # If the scorer succeeds, the returned feedback name will be default "feedback".
            # However, if the scorer fails, it doesn't return a Feedback object, and we
            # only know the scorer name. To unify this behavior, we overwrite the feedback
            # name to the scorer name in the happy path.
            # This will not apply when the scorer returns a list of Feedback objects.
            # or users explicitly specify the feedback name via Feedback constructor.
            result.name = self.name

        return result

    def __call__(
        self,
        *,
        inputs: Any = None,
        outputs: Any = None,
        expectations: dict[str, Any] | None = None,
        trace: Trace | None = None,
    ) -> int | float | bool | str | Feedback | list[Feedback]:
        """
        Implement the custom scorer's logic here.


        The scorer will be called for each row in the input evaluation dataset.

        Your scorer doesn't need to have all the parameters defined in the base
        signature. You can define a custom scorer with only the parameters you need.
        See the parameter details below for what values are passed for each parameter.

        .. list-table::
            :widths: 20 20 20
            :header-rows: 1

            * - Parameter
              - Description
              - Source

            * - ``inputs``
              - A single input to the target model/app.
              - Derived from either dataset or trace.

                * When the dataset contains ``inputs`` column, the value will be
                  passed as is.
                * When traces are provided as evaluation dataset, this will be derived
                  from the ``inputs`` field of the trace (i.e. inputs captured as the
                  root span of the trace).

            * - ``outputs``
              - A single output from the target model/app.
              - Derived from either dataset, trace, or output of ``predict_fn``.

                * When the dataset contains ``outputs`` column, the value will be
                  passed as is.
                * When ``predict_fn`` is provided, MLflow will make a prediction using the
                  ``inputs`` and the ``predict_fn``, and pass the result as the ``outputs``.
                * When traces are provided as evaluation dataset, this will be derived
                  from the ``response`` field of the trace (i.e. outputs captured as the
                  root span of the trace).

            * - ``expectations``
              - Ground truth or any expectation for each prediction, e.g. expected retrieved docs.
              - Derived from either dataset or trace.

                * When the dataset contains ``expectations`` column, the value will be
                  passed as is.
                * When traces are provided as evaluation dataset, this will be a dictionary
                  that contains a set of assessments in the format of
                  [assessment name]: [assessment value].

            * - ``trace``
              - A trace object corresponding to the prediction for the row.
              - Specified as a ``trace`` column in the dataset, or generated during the prediction.

        Example:

            .. code-block:: python

                class NotEmpty(BaseScorer):
                    name = "not_empty"

                    def __call__(self, *, outputs) -> bool:
                        return outputs != ""


                class ExactMatch(BaseScorer):
                    name = "exact_match"

                    def __call__(self, *, outputs, expectations) -> bool:
                        return outputs == expectations["expected_response"]


                class NumToolCalls(BaseScorer):
                    name = "num_tool_calls"

                    def __call__(self, *, trace) -> int:
                        spans = trace.search_spans(name="tool_call")
                        return len(spans)


                # Use the scorer in an evaluation
                mlflow.genai.evaluate(
                    data=data,
                    scorers=[NotEmpty(), ExactMatch(), NumToolCalls()],
                )
        """
        raise NotImplementedError("Implementation of __call__ is required for Scorer class")

    @property
    def kind(self) -> ScorerKind:
        return ScorerKind.CLASS

    def register(self, *, name: str | None = None, experiment_id: str | None = None) -> "Scorer":
        """
        Register this scorer with the MLflow server.

        This method registers the scorer for use with automatic trace evaluation in the
        specified experiment. Once registered, the scorer can be started to begin
        evaluating traces automatically.

        Args:
            name: Optional registered name for the scorer. If not provided, the current `name`
                property value will be used as a registered name.
            experiment_id: The ID of the MLflow experiment to register the scorer for.
                If None, uses the currently active experiment.

        Returns:
            A new Scorer instance with server registration information.

        Example:

            .. code-block:: python

                import mlflow
                from mlflow.genai.scorers import RelevanceToQuery

                # Register a built-in scorer
                mlflow.set_experiment("my_genai_app")
                registered_scorer = RelevanceToQuery().register(name="relevance_scorer")
                print(f"Registered scorer: {registered_scorer.name}")

                # Register a custom scorer
                from mlflow.genai.scorers import scorer


                @scorer
                def custom_length_check(outputs) -> bool:
                    return len(outputs) > 100


                registered_custom = custom_length_check.register(
                    name="output_length_checker", experiment_id="12345"
                )
        """
        # Get the current tracking store
        from mlflow.genai.scorers.registry import DatabricksStore, _get_scorer_store

        self._check_can_be_registered()
        store = _get_scorer_store()
        # Create a new scorer instance
        new_scorer = self._create_copy()

        # If name is provided, update the copy's name
        if name:
            new_scorer.name = name
            # Update cached dump to reflect the new name
            if new_scorer._cached_dump is not None:
                new_scorer._cached_dump["name"] = name

        store.register_scorer(experiment_id, new_scorer)

        if isinstance(store, DatabricksStore):
            new_scorer._registered_backend = "databricks"
        else:
            new_scorer._registered_backend = "tracking"
        return new_scorer

    def start(
        self,
        *,
        name: str | None = None,
        experiment_id: str | None = None,
        sampling_config: ScorerSamplingConfig,
    ) -> "Scorer":
        """
        Start registered scoring with the specified sampling configuration.

        This method activates automatic trace evaluation for the scorer. The scorer will
        evaluate traces based on the provided sampling configuration, including the
        sample rate and optional filter criteria.

        Args:
            name: Optional scorer name. If not provided, uses the scorer's registered
                name or default name.
            experiment_id: The ID of the MLflow experiment containing the scorer.
                If None, uses the currently active experiment.
            sampling_config: Configuration object containing:
                - sample_rate: Fraction of traces to evaluate (0.0 to 1.0). Required.
                - filter_string: Optional MLflow search_traces compatible filter string.

        Returns:
            A new Scorer instance with updated sampling configuration.

        Example:
            .. code-block:: python

                import mlflow
                from mlflow.genai.scorers import RelevanceToQuery, ScorerSamplingConfig

                # Start scorer with 50% sampling rate
                mlflow.set_experiment("my_genai_app")
                scorer = RelevanceToQuery().register()
                active_scorer = scorer.start(sampling_config=ScorerSamplingConfig(sample_rate=0.5))
                print(f"Scorer is evaluating {active_scorer.sample_rate * 100}% of traces")

                # Start scorer with filter to only evaluate specific traces
                filtered_scorer = scorer.start(
                    sampling_config=ScorerSamplingConfig(
                        sample_rate=1.0, filter_string="YOUR_FILTER_STRING"
                    )
                )
        """
        from mlflow.genai.scorers.registry import DatabricksStore
        from mlflow.tracking._tracking_service.utils import get_tracking_uri
        from mlflow.utils.uri import is_databricks_uri

        if not is_databricks_uri(get_tracking_uri()):
            raise MlflowException(
                "Scheduling scorers is only supported by Databricks tracking URI."
            )

        self._check_can_be_registered()

        if sampling_config.sample_rate is not None and sampling_config.sample_rate <= 0:
            raise MlflowException.invalid_parameter_value(
                "When starting a scorer, provided sample rate must be greater than 0"
            )

        scorer_name = name or self.name

        # Update the scorer on the server
        return DatabricksStore.update_registered_scorer(
            name=scorer_name,
            scorer=self,
            sample_rate=sampling_config.sample_rate,
            filter_string=sampling_config.filter_string,
            experiment_id=experiment_id,
        )

    def update(
        self,
        *,
        name: str | None = None,
        experiment_id: str | None = None,
        sampling_config: ScorerSamplingConfig,
    ) -> "Scorer":
        """
        Update the sampling configuration for this scorer.

        This method modifies the sampling rate and/or filter criteria for an already
        registered scorer. It can be used to dynamically adjust how many traces are
        evaluated or change the filtering criteria without stopping and restarting
        the scorer.

        Args:
            name: Optional scorer name. If not provided, uses the scorer's registered name
                or default name.
            experiment_id: The ID of the MLflow experiment containing the scorer.
                If None, uses the currently active experiment.
            sampling_config: Configuration object containing:
                - sample_rate: New fraction of traces to evaluate (0.0 to 1.0). Optional.
                - filter_string: New MLflow search_traces compatible filter string. Optional.

        Returns:
            A new Scorer instance with updated configuration.

        Example:

            .. code-block:: python

                import mlflow
                from mlflow.genai.scorers import RelevanceToQuery, ScorerSamplingConfig

                # Start scorer with initial configuration
                mlflow.set_experiment("my_genai_app")
                scorer = RelevanceToQuery().register()
                active_scorer = scorer.start(sampling_config=ScorerSamplingConfig(sample_rate=0.1))

                # Update to increase sampling rate during high traffic
                updated_scorer = active_scorer.update(
                    sampling_config=ScorerSamplingConfig(sample_rate=0.5)
                )
                print(f"Updated sample rate: {updated_scorer.sample_rate}")

                # Update to add filtering criteria
                filtered_scorer = updated_scorer.update(
                    sampling_config=ScorerSamplingConfig(filter_string="YOUR_FILTER_STRING")
                )
                print(f"Added filter: {filtered_scorer.filter_string}")
        """
        from mlflow.genai.scorers.registry import DatabricksStore
        from mlflow.tracking._tracking_service.utils import get_tracking_uri
        from mlflow.utils.uri import is_databricks_uri

        if not is_databricks_uri(get_tracking_uri()):
            raise MlflowException(
                "Updating scheduled scorers is only supported by Databricks tracking URI."
            )

        self._check_can_be_registered()

        scorer_name = name or self.name

        # Update the scorer on the server
        return DatabricksStore.update_registered_scorer(
            name=scorer_name,
            scorer=self,
            sample_rate=sampling_config.sample_rate,
            filter_string=sampling_config.filter_string,
            experiment_id=experiment_id,
        )

    def stop(self, *, name: str | None = None, experiment_id: str | None = None) -> "Scorer":
        """
        Stop registered scoring by setting sample rate to 0.

        This method deactivates automatic trace evaluation for the scorer while keeping
        the scorer registered. The scorer can be restarted later using the start() method.

        Args:
            name: Optional scorer name. If not provided, uses the scorer's registered name
                or default name.
            experiment_id: The ID of the MLflow experiment containing the scorer.
                If None, uses the currently active experiment.

        Returns:
            A new Scorer instance with sample rate set to 0.

        Example:

            .. code-block:: python

                import mlflow
                from mlflow.genai.scorers import RelevanceToQuery, ScorerSamplingConfig

                # Start and then stop a scorer
import logging
import math
from abc import abstractmethod
from dataclasses import asdict, dataclass
from typing import TYPE_CHECKING, Any

import pydantic

from mlflow.genai.judges.prompts.equivalence import EQUIVALENCE_PROMPT_INSTRUCTIONS

if TYPE_CHECKING:
    from mlflow.types.llm import ChatMessage

_logger = logging.getLogger(__name__)

import mlflow
from mlflow.entities.assessment import Feedback
from mlflow.entities.trace import Trace
from mlflow.exceptions import MlflowException
from mlflow.genai import judges
from mlflow.genai.judges.base import Judge, JudgeField
from mlflow.genai.judges.builtin import _MODEL_API_DOC
from mlflow.genai.judges.constants import _AFFIRMATIVE_VALUES, _NEGATIVE_VALUES
from mlflow.genai.judges.prompts.context_sufficiency import (
    CONTEXT_SUFFICIENCY_PROMPT_INSTRUCTIONS,
)
from mlflow.genai.judges.prompts.correctness import CORRECTNESS_PROMPT_INSTRUCTIONS
from mlflow.genai.judges.prompts.groundedness import GROUNDEDNESS_PROMPT_INSTRUCTIONS
from mlflow.genai.judges.prompts.guidelines import GUIDELINES_PROMPT_INSTRUCTIONS
from mlflow.genai.judges.prompts.relevance_to_query import (
    RELEVANCE_TO_QUERY_PROMPT_INSTRUCTIONS,
)
from mlflow.genai.judges.utils import (
    CategoricalRating,
    get_chat_completions_with_structured_output,
    get_default_model,
    invoke_judge_model,
)
from mlflow.genai.scorers.base import (
    _SERIALIZATION_VERSION,
    ScorerKind,
    SerializedScorer,
)
from mlflow.genai.utils.trace_utils import (
    extract_request_from_trace,
    extract_response_from_trace,
    extract_retrieval_context_from_trace,
    parse_inputs_to_str,
    parse_outputs_to_str,
    resolve_expectations_from_trace,
    resolve_inputs_from_trace,
    resolve_outputs_from_trace,
)
from mlflow.utils.docstring_utils import format_docstring
from mlflow.utils.uri import is_databricks_uri

GENAI_CONFIG_NAME = "databricks-agent"


@dataclass
class FieldExtractionConfig:
    messages: list["ChatMessage"]
    schema: type[pydantic.BaseModel]


@dataclass
class ExtractedFields:
    inputs: Any | None = None
    outputs: Any | None = None
    expectations: dict[str, Any] | None = None


def _construct_field_extraction_config(
    needs_inputs: bool,
    needs_outputs: bool,
) -> FieldExtractionConfig:
    """
    Construct field extraction configuration with messages and schema.

    Args:
        needs_inputs: Whether inputs field needs extraction.
        needs_outputs: Whether outputs field needs extraction.

    Returns:
        FieldExtractionConfig containing messages and schema for extraction.
    """
    from mlflow.types.llm import ChatMessage

    extraction_tasks = []
    schema_fields = {}

    if needs_inputs:
        extraction_tasks.append('- "inputs": The initial user request/question')
        schema_fields["inputs"] = (
            str,
            pydantic.Field(
                description='The user\'s original request (field name must be exactly "inputs")'
            ),
        )

    if needs_outputs:
        extraction_tasks.append('- "outputs": The final system response')
        schema_fields["outputs"] = (
            str,
            pydantic.Field(
                description='The system\'s final response (field name must be exactly "outputs")'
            ),
        )

    schema = pydantic.create_model("ExtractionSchema", **schema_fields)

    # Build example field names for the IMPORTANT message
    example_fields = []
    if needs_inputs:
        example_fields.append('"inputs"')
    if needs_outputs:
        example_fields.append('"outputs"')
    example_text = ", ".join(example_fields)

    messages = [
        ChatMessage(
            role="system",
            content=(
                "Extract the following fields from the trace.\n"
                "Use the provided tools to examine the trace's spans to find:\n"
                + "\n".join(extraction_tasks)
                + "\n\nIMPORTANT: Return the result as JSON with the EXACT field names shown "
                + f"in quotes above (e.g., {example_text}). Do not use singular forms or "
                + "variations of these field names."
            ),
        ),
        ChatMessage(
            role="user",
            content=(
                "Use the tools to find the required fields, then return them as JSON "
                "with the exact field names specified."
            ),
        ),
    ]

    return FieldExtractionConfig(messages=messages, schema=schema)


def _validate_required_fields(
    fields: ExtractedFields,
    judge: Judge,
    scorer_name: str,
) -> None:
    """
    Validate that all required fields for a scorer are present.

    Args:
        fields: Extracted fields containing inputs, outputs, and expectations.
        judge: Judge instance to determine which fields are required.
        scorer_name: Name of the scorer for error messages.

    Raises:
        MlflowException: If any required fields are missing.
    """
    required_fields = {field.name for field in judge.get_input_fields()}
    missing_fields = []

    if "inputs" in required_fields and fields.inputs is None:
        missing_fields.append("inputs")
    if "outputs" in required_fields and fields.outputs is None:
        missing_fields.append("outputs")
    if "expectations" in required_fields and fields.expectations is None:
        missing_fields.append("expectations")

    if missing_fields:
        fields_str = ", ".join(missing_fields)
        raise MlflowException(
            f"{scorer_name} requires the following fields: {fields_str}. "
            "Provide them directly or pass a trace containing them."
        )


def resolve_scorer_fields(
    trace: Trace | None,
    judge: Judge,
    inputs: Any | None = None,
    outputs: Any | None = None,
    expectations: dict[str, Any] | None = None,
    model: str | None = None,
    extract_expectations: bool = False,
) -> ExtractedFields:
    """
    Resolve scorer fields from provided values or extract from trace if needed.

    Args:
        trace: MLflow trace object containing the execution to evaluate.
        judge: Judge instance to determine which fields need extraction.
        inputs: Input data to evaluate. If None, will be extracted from trace.
        outputs: Output data to evaluate. If None, will be extracted from trace.
        expectations: Dictionary of expected outcomes. If None, will be extracted from trace.
        model: Model URI to use for LLM-based extraction if needed.
        extract_expectations: If True, extract expectations from trace.

    Returns:
        ExtractedFields dataclass containing inputs, outputs, and expectations
    """
    if not trace:
        return ExtractedFields(inputs=inputs, outputs=outputs, expectations=expectations)

    inputs = resolve_inputs_from_trace(inputs, trace)
    outputs = resolve_outputs_from_trace(outputs, trace)
    if extract_expectations:
        expectations = resolve_expectations_from_trace(expectations, trace)

    input_field_names = {field.name for field in judge.get_input_fields()}
    needs_inputs = inputs is None and "inputs" in input_field_names
    needs_outputs = outputs is None and "outputs" in input_field_names

    if needs_inputs or needs_outputs:
        extraction_config = _construct_field_extraction_config(
            needs_inputs=needs_inputs,
            needs_outputs=needs_outputs,
        )

        try:
            extracted = get_chat_completions_with_structured_output(
                model_uri=model or get_default_model(),
                messages=extraction_config.messages,
                output_schema=extraction_config.schema,
                trace=trace,
            )
            if needs_inputs:
                inputs = inputs or extracted.inputs
            if needs_outputs:
                outputs = outputs or extracted.outputs
        except Exception as e:
            _logger.warning(
                "Failed to extract required fields from trace using LLM: %s",
                e,
            )

    return ExtractedFields(inputs=inputs, outputs=outputs, expectations=expectations)


def _sanitize_scorer_feedback(feedback: Feedback) -> Feedback:
    """Sanitize feedback values from LLM judges to ensure YES/NO consistency."""
    if feedback.value:
        if isinstance(feedback.value, CategoricalRating):
            return feedback

        if isinstance(feedback.value, str):
            value_str = feedback.value.strip().lower()

            if value_str in _AFFIRMATIVE_VALUES:
                feedback.value = CategoricalRating.YES
            elif value_str in _NEGATIVE_VALUES:
                feedback.value = CategoricalRating.NO
            else:
                feedback.value = CategoricalRating(value_str)

    return feedback


class BuiltInScorer(Judge):
    """
    Abstract base class for built-in scorers that share a common implementation.
    All built-in scorers should inherit from this class.
    """

    name: str
    required_columns: set[str] = set()

    @property
    @abstractmethod
    def instructions(self) -> str:
        """
        Get the instructions of what this scorer evaluates.
        """

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Override model_dump to handle builtin scorer serialization."""
        pydantic_model_data = pydantic.BaseModel.model_dump(self, mode="json", **kwargs)
        pydantic_model_data["instructions"] = self.instructions

        serialized = SerializedScorer(
tests/genai/test_scheduled_scorers.py
tests/genai/scorers/test_scorer_description.py
tests/genai/scorers/test_scorer_CRUD.py
tests/genai/scorers/test_scorer_utils.py
tests/genai/scorers/test_registered_scorers_scheduling.py
tests/genai/scorers/test_aggregation.py
tests/genai/scorers/test_serialization.py
tests/genai/scorers/test_scorer.py
tests/genai/scorers/test_builtin_scorers.py
tests/genai/scorers/__init__.py
tests/genai/scorers/test_builtin_scorers_registration.py
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "sed -n '800,1020p' mlflow/genai/scorers/base.py; sed -n '250,580p' mlflow/genai/scorers/builtin_scorers.py; sed -n '1450,1700p' mlflow/genai/scorers/builtin_scorers.py; sed -n '1,360p' tests/genai/scorers/test_scorer.py; sed -n '1,420p' tests/genai/scorers/test_builtin_scorers.py; grep -R -n \"valid_data_for_builtin_scorers\\|validate_scorers\\|get_all_scorers\\|Invalid scorer\\|expectations.*dict\" tests mlflow | head -250"
```

退出码：`0`

输出：
```
        copy = self.model_copy(deep=True)
        # Duplicate the cached dump so modifications to the copy don't affect the original
        if self._cached_dump is not None:
            object.__setattr__(copy, "_cached_dump", dict(self._cached_dump))
        return copy

    def _check_can_be_registered(self, error_message: str | None = None) -> None:
        from mlflow.genai.scorers.registry import DatabricksStore, _get_scorer_store

        if self.kind not in _ALLOWED_SCORERS_FOR_REGISTRATION:
            if error_message is None:
                error_message = (
                    "Scorer must be a builtin or decorator scorer to be registered. "
                    f"Got {self.kind}."
                )
            raise MlflowException.invalid_parameter_value(error_message)

        # NB: Custom (@scorer) scorers use exec() during deserialization, which poses a code
        # execution risk. Only allow registration when using Databricks tracking URI.
        # Registration itself is safe (just stores code), but we restrict it to Databricks
        # to ensure loaded scorers can only be executed in controlled environments.
        if self.kind == ScorerKind.DECORATOR and not is_databricks_uri(get_tracking_uri()):
            raise MlflowException.invalid_parameter_value(
                "Custom scorer registration (using @scorer decorator) is not supported "
                "outside of Databricks tracking environments due to security concerns. "
                "Custom scorers require arbitrary code execution during deserialization.\n\n"
                "To use custom scorers:\n"
                "1. Configure MLflow to use a Databricks tracking URI, or\n"
                "2. Manage your custom scorer code in a source code repository "
                "(e.g., GitHub) and import it directly, or\n"
                "3. Use built-in scorers or make_judge() scorers instead"
            )

        store = _get_scorer_store()
        if (
            isinstance(store, DatabricksStore)
            and (model := getattr(self, "model", None))
            and not model.startswith("databricks")
        ):
            raise MlflowException.invalid_parameter_value(
                "The scorer's judge model must use Databricks as a model provider "
                "in order to be registered or updated. Please use the default judge model or "
                "specify a model value starting with `databricks:/`. "
                f"Got {model}."
            )


def scorer(
    func=None,
    *,
    name: str | None = None,
    description: str | None = None,
    aggregations: list[_AggregationType] | None = None,
):
    """
    A decorator to define a custom scorer that can be used in ``mlflow.genai.evaluate()``.

    The scorer function should take in a **subset** of the following parameters:

    .. list-table::
        :widths: 20 20 20
        :header-rows: 1

        * - Parameter
          - Description
          - Source

        * - ``inputs``
          - A single input to the target model/app.
          - Derived from either dataset or trace.

            * When the dataset contains ``inputs`` column, the value will be passed as is.
            * When traces are provided as evaluation dataset, this will be derived
              from the ``inputs`` field of the trace (i.e. inputs captured as the
              root span of the trace).

        * - ``outputs``
          - A single output from the target model/app.
          - Derived from either dataset, trace, or output of ``predict_fn``.

            * When the dataset contains ``outputs`` column, the value will be passed as is.
            * When ``predict_fn`` is provided, MLflow will make a prediction using the
              ``inputs`` and the ``predict_fn`` and pass the result as the ``outputs``.
            * When traces are provided as evaluation dataset, this will be derived
              from the ``response`` field of the trace (i.e. outputs captured as the
              root span of the trace).

        * - ``expectations``
          - Ground truth or any expectation for each prediction e.g., expected retrieved docs.
          - Derived from either dataset or trace.

            * When the dataset contains ``expectations`` column, the value will be passed as is.
            * When traces are provided as evaluation dataset, this will be a dictionary
              that contains a set of assessments in the format of
              [assessment name]: [assessment value].

        * - ``trace``
          - A trace object corresponding to the prediction for the row.
          - Specified as a ``trace`` column in the dataset, or generated during the prediction.

    The scorer function should return one of the following:

    * A boolean value
    * An integer value
    * A float value
    * A string value
    * A single :class:`~mlflow.entities.Feedback` object
    * A list of :class:`~mlflow.entities.Feedback` objects

    .. note::

        The metric name will be determined by the scorer function's name or a custom name
        specified in the `name` parameter for the scorer.

    Args:
        func: The scorer function to be decorated.
        name: The name of the scorer.
        description: A description of what the scorer evaluates.
        aggregations: A list of aggregation functions to apply to the scorer's output.
            The aggregation functions can be either a string or a callable.

            * If a string, it must be one of `["min", "max", "mean", "median", "variance", "p90"]`.
            * If a callable, it must take a list of values and return a single value.

            By default, "mean" is used as the aggregation function.

    Example:

        .. code-block:: python

            import json
            from mlflow.genai.scorers import scorer
            from mlflow.entities import AssessmentSource, Feedback


            # Basic scorers that returns primitive values
            @scorer
            def not_empty(outputs) -> bool:
                return outputs != ""


            @scorer
            def exact_match(outputs, expectations) -> bool:
                return outputs == expectations["expected_response"]


            @scorer
            def num_tool_calls(trace) -> int:
                spans = trace.search_spans(name="tool_call")
                return len(spans)


            # Use `Feedback` object to return additional information about the scorer's
            # result, such as a rationale for the score.
            @scorer
            def harmfulness(outputs) -> Feedback:
                import openai

                prompt = f'''
                    Judge if the following text is harmful or not.

                    Text:
                    {outputs}

                    Return the answer in a JSON object with the following format:
                    {{
                        "harmful": true
                        "reason": "The text contains harmful content"
                    }}

                    Do not output any other characters than the json object.
                '''
                response = openai.OpenAI().chat.completions.create(
                    model="o4-mini",
                    messages=[{"role": "user", "content": prompt}],
                )
                payload = json.loads(response.choices[0].message.content)
                return Feedback(
                    value=payload["harmful"],
                    rationale=payload["reason"],
                    source=AssessmentSource(
                        source_type="LLM_JUDGE",
                        source_id="openai:/o4-mini",
                    ),
                )


            # Use the scorer in an evaluation
            mlflow.genai.evaluate(
                data=data,
                scorers=[not_empty, exact_match, num_tool_calls, harmfulness],
            )
    """

    if func is None:
        return functools.partial(
            scorer, name=name, description=description, aggregations=aggregations
        )




















    # Update the __call__ method's signature to match the original function
    # but add 'self' as the first parameter. This is required for MLflow to
    # pass the correct set of parameters to the scorer.
                feedback.value = CategoricalRating.YES
            elif value_str in _NEGATIVE_VALUES:
                feedback.value = CategoricalRating.NO
            else:
                feedback.value = CategoricalRating(value_str)

    return feedback


class BuiltInScorer(Judge):
    """
    Abstract base class for built-in scorers that share a common implementation.
    All built-in scorers should inherit from this class.
    """

    name: str
    required_columns: set[str] = set()

    @property
    @abstractmethod
    def instructions(self) -> str:
        """
        Get the instructions of what this scorer evaluates.
        """

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Override model_dump to handle builtin scorer serialization."""
        pydantic_model_data = pydantic.BaseModel.model_dump(self, mode="json", **kwargs)
        pydantic_model_data["instructions"] = self.instructions

        serialized = SerializedScorer(
            name=self.name,
            description=self.description,
            aggregations=self.aggregations,
            mlflow_version=mlflow.__version__,
            serialization_version=_SERIALIZATION_VERSION,
            builtin_scorer_class=self.__class__.__name__,
            builtin_scorer_pydantic_data=pydantic_model_data,
        )

        return asdict(serialized)

    @classmethod
    def model_validate(cls, obj: SerializedScorer | dict[str, Any]) -> "BuiltInScorer":
        """Override model_validate to handle builtin scorer deserialization."""
        from mlflow.genai.scorers import builtin_scorers

        if isinstance(obj, SerializedScorer):
            serialized = obj
        else:
            if not isinstance(obj, dict) or "builtin_scorer_class" not in obj:
                raise MlflowException.invalid_parameter_value(
                    f"Invalid builtin scorer data: expected a dictionary with "
                    f"'builtin_scorer_class' field, got {type(obj).__name__}."
                )

            try:
                serialized = SerializedScorer(**obj)
            except Exception as e:
                raise MlflowException.invalid_parameter_value(
                    f"Failed to parse serialized scorer data: {e}"
                )

        try:
            scorer_class = getattr(builtin_scorers, serialized.builtin_scorer_class)
        except AttributeError:
            raise MlflowException.invalid_parameter_value(
                f"Unknown builtin scorer class: {serialized.builtin_scorer_class}"
            )

        constructor_args = serialized.builtin_scorer_pydantic_data or {}

        return scorer_class(**constructor_args)

    def validate_columns(self, columns: set[str]) -> None:
        missing_columns = self.required_columns - columns
        if missing_columns:
            raise MissingColumnsException(self.name, missing_columns)

    @property
    def kind(self) -> ScorerKind:
        return ScorerKind.BUILTIN


@format_docstring(_MODEL_API_DOC)
class RetrievalRelevance(BuiltInScorer):
    """
    Retrieval relevance measures whether each chunk is relevant to the input request.

    You can invoke the scorer directly with a single input for testing, or pass it to
    `mlflow.genai.evaluate` for running full evaluation on a dataset.

    Args:
        name: The name of the scorer. Defaults to "retrieval_relevance".
        model: {{ model }}

    Example (direct usage):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import RetrievalRelevance

        trace = mlflow.get_trace("<your-trace-id>")
        feedbacks = RetrievalRelevance(name="my_retrieval_relevance")(trace=trace)
        print(feedbacks)

    Example (with evaluate):

    .. code-block:: python

        import mlflow

        data = mlflow.search_traces(...)
        result = mlflow.genai.evaluate(data=data, scorers=[RetrievalRelevance()])
    """

    name: str = "retrieval_relevance"
    model: str | None = None
    required_columns: set[str] = {"inputs", "trace"}
    description: str = (
        "Evaluate whether each retrieved context chunk is relevant to the input request."
    )

    def __init__(self, /, **kwargs):
        super().__init__(**kwargs)

    @property
    def instructions(self) -> str:
        """Get the instructions of what this scorer evaluates."""
        return "Evaluates whether each retrieved context chunk is relevant to the input request."

    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for the RetrievalRelevance judge.

        Returns:
            List of JudgeField objects defining the input fields based on the __call__ method.
        """
        return [
            JudgeField(
                name="trace",
                description=(
                    "The trace of the model's execution. Must contains at least one span with "
                    "type `RETRIEVER`. MLflow will extract the retrieved context from that span. "
                    "If multiple spans are found, MLflow will use the **last** one."
                ),
            ),
        ]

    def __call__(self, *, trace: Trace) -> Feedback:
        """
        Evaluate chunk relevance for each context chunk.

        Args:
            trace: The trace of the model's execution. Must contains at least one span with
                type `RETRIEVER`. MLflow will extract the retrieved context from that span.
                If multiple spans are found, MLflow will use the **last** one.

        Returns:
            A list of assessments evaluating the relevance of each context chunk.
            If the number of retrievers is N and each retriever has M chunks, the list will
            contain N * (M + 1) assessments. Each retriever span will emit M assessments
            for the relevance of its chunks and 1 assessment for the average relevance of all
            chunks.
        """
        request = extract_request_from_trace(trace)
        span_id_to_context = extract_retrieval_context_from_trace(trace)

        feedbacks = []
        for span_id, context in span_id_to_context.items():
            feedbacks.extend(self._compute_span_relevance(span_id, request, context))
        return feedbacks

    def _compute_span_relevance(
        self, span_id: str, request: str, chunks: list[dict[str, str]]
    ) -> list[Feedback]:
        """Compute the relevance of retrieved context for one retriever span."""
        from mlflow.genai.judges.prompts.retrieval_relevance import get_prompt

        model = self.model or get_default_model()

        chunk_feedbacks = []
        if model == "databricks":
            from databricks.agents.evals.judges import chunk_relevance

            chunk_feedbacks = chunk_relevance(
                request=request, retrieved_context=chunks, assessment_name=self.name
            )
        else:
            for chunk in chunks:
                prompt = get_prompt(request=request, context=chunk["content"])
                feedback = invoke_judge_model(model, prompt, assessment_name=self.name)
                sanitized_feedback = _sanitize_scorer_feedback(feedback)
                chunk_feedbacks.append(sanitized_feedback)

        for feedback in chunk_feedbacks:
            feedback.span_id = span_id

        if len(chunk_feedbacks) == 0:
            return []

        average = sum(f.value == "yes" for f in chunk_feedbacks) / len(chunk_feedbacks)

        span_level_feedback = Feedback(
            name=self.name + "/precision",
            value=average,
            source=chunk_feedbacks[0].source,
            span_id=span_id,
        )
        return [span_level_feedback] + chunk_feedbacks


@format_docstring(_MODEL_API_DOC)
class RetrievalSufficiency(BuiltInScorer):
    """
    Retrieval sufficiency evaluates whether the retrieved documents provide all necessary
    information to generate the expected response.

    You can invoke the scorer directly with a single input for testing, or pass it to
    `mlflow.genai.evaluate` for running full evaluation on a dataset.

    Args:
        name: The name of the scorer. Defaults to "retrieval_sufficiency".
        model: {{ model }}

    Example (direct usage):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import RetrievalSufficiency

        trace = mlflow.get_trace("<your-trace-id>")
        feedback = RetrievalSufficiency(name="my_retrieval_sufficiency")(trace=trace)
        print(feedback)

    Example (with evaluate):

    .. code-block:: python

        import mlflow

        data = mlflow.search_traces(...)
        result = mlflow.genai.evaluate(data=data, scorers=[RetrievalSufficiency()])
    """

    name: str = "retrieval_sufficiency"
    model: str | None = None
    required_columns: set[str] = {"inputs", "trace"}
    description: str = (
        "Evaluate whether the information in the last retrieval is sufficient to generate "
        "the facts in expected_response or expected_facts."
    )

    @property
    def instructions(self) -> str:
        """Get the instructions of what this scorer evaluates."""
        return CONTEXT_SUFFICIENCY_PROMPT_INSTRUCTIONS

    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for the RetrievalSufficiency judge.

        Returns:
            List of JudgeField objects defining the input fields based on the __call__ method.
        """
        return [
            JudgeField(
                name="trace",
                description=(
                    "The trace of the model's execution. Must contain at least one span with "
                    "type `RETRIEVER`. MLflow will extract the retrieved context from that span. "
                    "If multiple spans are found, MLflow will use the **last** one."
                ),
            ),
            JudgeField(
                name="expectations",
                description=(
                    "A dictionary of expectations for the response. This must contain either "
                    "`expected_response` or `expected_facts` key (optional)."
                ),
            ),
        ]

    def validate_columns(self, columns: set[str]) -> None:
        super().validate_columns(columns)
        if (
            "expectations/expected_response" not in columns
            and "expectations/expected_facts" not in columns
        ):
            raise MissingColumnsException(
                self.name,
                ["expectations/expected_response or expectations/expected_facts"],
            )

    def __call__(
        self, *, trace: Trace, expectations: dict[str, Any] | None = None
    ) -> list[Feedback]:
        """
        Evaluate context sufficiency based on retrieved documents.

        Args:
            trace: The trace of the model's execution. Must contains at least one span with
                type `RETRIEVER`. MLflow will extract the retrieved context from that span.
                If multiple spans are found, MLflow will use the **last** one.
            expectations: A dictionary of expectations for the response. Either `expected_facts` or
                `expected_response` key is required. Alternatively, you can pass a trace annotated
                with `expected_facts` or `expected_response` label(s) and omit this argument.
        """
        request = extract_request_from_trace(trace)
        span_id_to_context = extract_retrieval_context_from_trace(trace)

        expectations = expectations or {}
        expected_facts = expectations.get("expected_facts")
        expected_response = expectations.get("expected_response")
        if expected_facts is None or expected_response is None:
            for assessment in trace.info.assessments:
                if assessment.name == "expected_facts" and expected_facts is None:
                    expected_facts = assessment.value
                if assessment.name == "expected_response" and expected_response is None:
                    expected_response = assessment.value

        feedbacks = []
        for span_id, context in span_id_to_context.items():
            feedback = judges.is_context_sufficient(
                request=request,
                context=context,
                expected_response=expected_response,
                expected_facts=expected_facts,
                name=self.name,

        Returns:
            List of JudgeField objects defining the input fields.
        """
        return [
            JudgeField(
                name="outputs",
                description="The actual output from the program to compare.",
            ),
            JudgeField(
                name="expectations",
                description=(
                    "A dictionary containing the expected output. Must contain an "
                    "'expected_response' key with the expected value, e.g. "
                    "{'expected_response': 'Paris'}."
                ),
            ),
        ]

    def __call__(
        self,
        *,
        inputs: dict[str, Any] | None = None,
        outputs: Any | None = None,
        expectations: dict[str, Any] | None = None,
        trace: Trace | None = None,
    ) -> Feedback:
        """
        Evaluate output equivalence.

        This scorer can be used in two ways:
        1. Pass an MLflow trace object to automatically extract
           outputs and expectations from the trace and its assessments.
        2. Directly provide outputs and expectations to evaluate.

        Args:
            inputs: A dictionary of input data (optional, not used in evaluation).
            outputs: The actual output to compare. Optional when trace is provided.
            expectations: A dictionary containing the expected output. Must contain an
                'expected_response' key. Optional when trace is provided.
            trace: MLflow trace object containing the execution to evaluate. When provided,
                outputs and expectations will be automatically extracted from the trace.

        Returns:
            Feedback object with 'yes'/'no' value and rationale
        """
        from mlflow.genai.judges.builtin import _sanitize_feedback
        from mlflow.genai.judges.prompts.equivalence import (
            EQUIVALENCE_FEEDBACK_NAME,
            get_prompt,
        )

        # Use resolve_scorer_fields to extract fields from trace if provided
        fields = resolve_scorer_fields(
            trace,
            self,
            inputs,
            outputs,
            expectations,
            model=self.model,
            extract_expectations=True,
        )
        _validate_required_fields(fields, self, "Equivalence scorer")

        # Validate that expected_response is present
        if not fields.expectations or fields.expectations.get("expected_response") is None:
            raise MlflowException(
                "Equivalence scorer requires `expected_response` in the `expectations` dictionary."
            )

        # Extract the expected response
        expected_output = fields.expectations.get("expected_response")
        actual_output = fields.outputs

        # Handle exact match for numerical types
        if isinstance(actual_output, (int, float, bool)) and isinstance(
            expected_output, (int, float, bool)
        ):
            if math.isclose(actual_output, expected_output):
                return Feedback(
                    name=self.name,
                    value=CategoricalRating.YES,
                    rationale="Exact numerical match",
                )
            else:
                return Feedback(
                    name=self.name,
                    value=CategoricalRating.NO,
                    rationale=f"Values do not match: {actual_output} != {expected_output}",
                )

        # Convert to strings for comparison
        outputs_str = str(actual_output)
        expectations_str = str(expected_output)

        # Use exact match first
        if outputs_str == expectations_str:
            return Feedback(
                name=self.name,
                value=CategoricalRating.YES,
                rationale="Exact string match",
            )

        # Use LLM judge for semantic equivalence

        model = self.model or get_default_model()
        assessment_name = self.name or EQUIVALENCE_FEEDBACK_NAME

        prompt = get_prompt(
            output=outputs_str,
            expected_output=expectations_str,
        )
        feedback = invoke_judge_model(model, prompt, assessment_name=assessment_name)

        return _sanitize_feedback(feedback)



































class MissingColumnsException(MlflowException):
    def __init__(self, scorer: str, missing_columns: set[str]):
        self.scorer = scorer
        self.missing_columns = list(missing_columns)
        super().__init__(
            f"The following columns are required for the scorer {scorer}: {missing_columns}"
        )from collections import defaultdict
from unittest.mock import call, patch

import pandas as pd
import pytest

import mlflow
from mlflow.entities import Assessment, AssessmentSource, AssessmentSourceType, Feedback
from mlflow.entities.assessment_error import AssessmentError
from mlflow.genai import Scorer, scorer
from mlflow.genai.judges import make_judge
from mlflow.genai.judges.utils import CategoricalRating
from mlflow.genai.scorers import Correctness, Guidelines, RetrievalGroundedness
from mlflow.genai.scorers.base import SerializedScorer
from mlflow.genai.scorers.registry import get_scorer, list_scorers


@pytest.fixture(autouse=True)
def increase_db_pool_size(monkeypatch):
    # Set larger pool size for tests to handle concurrent trace creation
    # test_extra_traces_from_customer_scorer_should_be_cleaned_up test requires this
    # to reduce flakiness
    monkeypatch.setenv("MLFLOW_SQLALCHEMYSTORE_POOL_SIZE", "20")
    monkeypatch.setenv("MLFLOW_SQLALCHEMYSTORE_MAX_OVERFLOW", "40")
    return


def always_yes(inputs, outputs, expectations, trace):
    return "yes"


class AlwaysYesScorer(Scorer):
    def __call__(self, inputs, outputs, expectations, trace):
        return "yes"


@pytest.fixture
def sample_data():
    return pd.DataFrame(
        {
            "inputs": [
                {"message": [{"role": "user", "content": "What is Spark??"}]},
                {
                    "messages": [
                        {"role": "user", "content": "How can you minimize data shuffling in Spark?"}
                    ]
                },
            ],
            "outputs": [
                {"choices": [{"message": {"content": "actual response for first question"}}]},
                {"choices": [{"message": {"content": "actual response for second question"}}]},
            ],
            "expectations": [
                {"expected_response": "expected response for first question"},
                {"expected_response": "expected response for second question"},
            ],
        }
    )


@pytest.mark.parametrize("dummy_scorer", [AlwaysYesScorer(name="always_yes"), scorer(always_yes)])
def test_scorer_existence_in_metrics(sample_data, dummy_scorer, is_in_databricks):
    result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])
    assert any("always_yes" in metric for metric in result.metrics.keys())


@pytest.mark.parametrize(
    "dummy_scorer", [AlwaysYesScorer(name="always_no"), scorer(name="always_no")(always_yes)]
)
def test_scorer_name_works(sample_data, dummy_scorer, is_in_databricks):
    _SCORER_NAME = "always_no"
    result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])
    assert any(_SCORER_NAME in metric for metric in result.metrics.keys())


def test_trace_passed_to_builtin_scorers_correctly(
    sample_rag_trace, is_in_databricks, monkeypatch: pytest.MonkeyPatch
):
    if not is_in_databricks:
        pytest.skip("OSS GenAI evaluator doesn't support passing traces yet")

    # Disable logging traces to MLflow to avoid calling mlflow APIs which need to be mocked
    monkeypatch.setenv("AGENT_EVAL_LOG_TRACES_TO_MLFLOW_ENABLED", "false")

    with (
        patch(
            "databricks.agents.evals.judges.correctness",
            return_value=Feedback(name="correctness", value=CategoricalRating.YES),
        ) as mock_correctness,
        patch(
            "databricks.agents.evals.judges.guidelines",
            return_value=Feedback(name="guidelines", value=CategoricalRating.YES),
        ) as mock_guidelines,
        patch(
            "databricks.agents.evals.judges.groundedness",
            return_value=Feedback(name="groundedness", value=CategoricalRating.YES),
        ) as mock_groundedness,
    ):
        mlflow.genai.evaluate(
            data=pd.DataFrame({"trace": [sample_rag_trace]}),
            scorers=[
                RetrievalGroundedness(name="retrieval_groundedness"),
                Correctness(name="correctness"),
                Guidelines(name="english", guidelines=["write in english"]),
            ],
        )

    assert mock_correctness.call_count == 1
    assert mock_guidelines.call_count == 1
    assert mock_groundedness.call_count == 2  # Called per retriever span

    mock_correctness.assert_called_once_with(
        request="{'question': 'query'}",
        response="answer",
        expected_facts=["fact1", "fact2"],
        expected_response="expected answer",
        assessment_name="correctness",
    )
    mock_guidelines.assert_called_once_with(
        guidelines=["write in english"],
        context={"request": "{'question': 'query'}", "response": "answer"},
        assessment_name="english",
    )
    mock_groundedness.assert_has_calls(
        [
            call(
                request="{'question': 'query'}",
                response="answer",
                retrieved_context=[
                    {"content": "content_1", "doc_uri": "url_1"},
                    {"content": "content_2", "doc_uri": "url_2"},
                ],
                assessment_name="retrieval_groundedness",
            ),
            call(
                request="{'question': 'query'}",
                response="answer",
                retrieved_context=[
                    {"content": "content_3"},
                ],
                assessment_name="retrieval_groundedness",
            ),
        ]
    )


def test_trace_passed_to_custom_scorer_correctly(sample_data, is_in_databricks):
    if not is_in_databricks:
        pytest.skip("OSS GenAI evaluator doesn't support passing traces yet")

    actual_call_args_list = []

    @scorer
    def dummy_scorer(inputs, outputs, expectations, trace) -> float:
        actual_call_args_list.append(
            {
                "inputs": inputs,
                "outputs": outputs,
                "expectations": expectations,
            }
        )
        return 0.0

    mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])

    assert len(actual_call_args_list) == len(sample_data)

    # Prepare expected arguments, keyed by expected_response for matching
    sample_data_set = defaultdict(set)
    for i in range(len(sample_data)):
        sample_data_set["inputs"].add(str(sample_data["inputs"][i]))
        sample_data_set["outputs"].add(str(sample_data["outputs"][i]))
        sample_data_set["expectations"].add(
            str(sample_data["expectations"][i]["expected_response"])
        )

    for actual_args in actual_call_args_list:
        # do any check since actual passed input could be reformatted and larger than sample input
        assert any(
            sample_data_input in str(actual_args["inputs"])
            for sample_data_input in sample_data_set["inputs"]
        )
        assert str(actual_args["outputs"]) in sample_data_set["outputs"]
        assert (
            str(actual_args["expectations"]["expected_response"]) in sample_data_set["expectations"]
        )


def test_trace_passed_correctly(is_in_databricks):
    if not is_in_databricks:
        pytest.skip("OSS GenAI evaluator doesn't support passing traces yet")

    @mlflow.trace
    def predict_fn(question):
        return "output: " + str(question)

    actual_call_args_list = []

    @scorer
    def dummy_scorer(inputs, outputs, trace):
        actual_call_args_list.append(
            {
                "inputs": inputs,
                "outputs": outputs,
                "trace": trace,
            }
        )
        return 0.0

    data = [
        {"inputs": {"question": "input1"}},
        {"inputs": {"question": "input2"}},
    ]
    mlflow.genai.evaluate(
        predict_fn=predict_fn,
        data=data,
        scorers=[dummy_scorer],
    )

    assert len(actual_call_args_list) == len(data)
    for actual_args in actual_call_args_list:
        assert actual_args["trace"] is not None
        trace = actual_args["trace"]
        # check if the input is present in the trace
        assert any(
            str(data[i]["inputs"]["question"]) in str(trace.data.request) for i in range(len(data))
        )
        # check if predict_fn was run by making output it starts with "output:"
        assert "output:" in str(trace.data.response)[:10]


@pytest.mark.parametrize(
    "scorer_return",
    [
        "yes",
        42,
        42.0,
        # Feedback object.
        Feedback(name="big_question", value=42, rationale="It's the answer to everything"),
        # List of Feedback objects.
        [
            Feedback(name="big_question", value=42, rationale="It's the answer to everything"),
            Feedback(name="small_question", value=1, rationale="Not sure, just a guess"),
        ],
    ],
)
def test_scorer_on_genai_evaluate(sample_data, scorer_return, is_in_databricks):
    @scorer
    def dummy_scorer(inputs, outputs):
        return scorer_return

    results = mlflow.genai.evaluate(
        data=sample_data,
        scorers=[dummy_scorer],
    )
    if isinstance(scorer_return, Assessment):
        assert any(scorer_return.name in metric for metric in results.metrics.keys())
    elif isinstance(scorer_return, list) and all(
        isinstance(item, Assessment) for item in scorer_return
    ):
        assert any(
            item.name in metric for item in scorer_return for metric in results.metrics.keys()
        )
    else:
        assert any("dummy_scorer" in metric for metric in results.metrics.keys())


def test_custom_scorer_allow_none_return():
    @scorer
    def dummy_scorer(inputs, outputs):
        return None

    assert dummy_scorer.run(inputs={"question": "query"}, outputs="answer") is None


def test_scorer_returns_feedback_with_error(sample_data, is_in_databricks):
    @scorer
    def dummy_scorer(inputs):
        return Feedback(
            name="feedback_with_error",
            error=AssessmentError(error_code="500", error_message="This is an error"),
            source=AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="gpt"),
            metadata={"index": 0},
        )

    results = mlflow.genai.evaluate(
        data=sample_data,
        scorers=[dummy_scorer],
    )

    # Scorer should not be in result when it returns an error
    assert all("dummy_scorer" not in metric for metric in results.metrics.keys())


@pytest.mark.parametrize(
    ("scorer_return", "expected_feedback_name"),
    [
        # Single feedback object with default name -> should be renamed to "my_scorer"
        (Feedback(value=42, rationale="rationale"), "my_scorer"),
        # Single feedback object with custom name -> should NOT be renamed to "my_scorer"
        (Feedback(name="custom_name", value=42, rationale="rationale"), "custom_name"),
    ],
)
def test_custom_scorer_overwrites_default_feedback_name(scorer_return, expected_feedback_name):
    @scorer
    def my_scorer(inputs, outputs):
        return scorer_return

    feedback = my_scorer.run(
        inputs={"question": "What is the capital of France?"},
        outputs="The capital of France is Paris.",
    )
    assert feedback.name == expected_feedback_name
    assert feedback.value == 42


def test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list():
    @scorer
    def my_scorer(inputs, outputs):
        return [
            Feedback(name="big_question", value=42, rationale="It's the answer to everything"),
            Feedback(name="small_question", value=1, rationale="Not sure, just a guess"),
        ]

    feedbacks = my_scorer.run(
        inputs={"question": "What is the capital of France?"},
        outputs="The capital of France is Paris.",
    )
    assert feedbacks[0].name == "big_question"
    assert feedbacks[1].name == "small_question"


def test_custom_scorer_registration_blocked_for_non_databricks_uri():
    experiment_id = mlflow.create_experiment("test_security_experiment")

    @scorer
    def test_custom_scorer(outputs) -> bool:
        return len(outputs) > 0

    with pytest.raises(
        mlflow.exceptions.MlflowException,
        match="Custom scorer registration.*not supported outside of Databricks tracking",
    ):
        test_custom_scorer.register(experiment_id=experiment_id, name="test_scorer")

    mlflow.delete_experiment(experiment_id)


def test_custom_scorer_loading_blocked_for_non_databricks_uri():
    serialized = SerializedScorer(
        name="malicious_scorer",
        call_source="import os\nos.system('echo hacked')\nreturn True",
        call_signature="(outputs)",
        original_func_name="malicious_scorer",
    )

    with pytest.raises(
        mlflow.exceptions.MlflowException, match="Loading custom scorer.*not supported"
    ):
        Scorer._reconstruct_decorator_scorer(serialized)
from unittest import mock
from unittest.mock import call, patch

import pytest

import mlflow
from mlflow.entities.assessment import Feedback
from mlflow.entities.assessment_error import AssessmentError
from mlflow.entities.span import SpanType
from mlflow.genai.judges.base import JudgeField
from mlflow.genai.judges.builtin import CategoricalRating
from mlflow.genai.judges.utils import FieldExtraction
from mlflow.genai.scorers import (
    Correctness,
    Equivalence,
    ExpectationsGuidelines,
    Guidelines,
    RelevanceToQuery,
    RetrievalGroundedness,
    RetrievalRelevance,
    RetrievalSufficiency,
    Safety,
)
from mlflow.genai.scorers.base import Scorer
from mlflow.genai.scorers.builtin_scorers import (
    ExtractedFields,
    _construct_field_extraction_config,
    _validate_required_fields,
    get_all_scorers,
    resolve_scorer_fields,
)
from mlflow.utils.uri import is_databricks_uri

from tests.genai.conftest import databricks_only


@pytest.fixture
def trace_without_inputs_outputs():
    with mlflow.start_span(name="empty_span") as span:
        pass
    return mlflow.get_trace(span.trace_id)


@pytest.fixture
def trace_with_only_inputs():
    with mlflow.start_span(name="inputs_only_span") as span:
        span.set_inputs({"question": "Test question"})
    return mlflow.get_trace(span.trace_id)


@pytest.fixture
def trace_with_only_outputs():
    with mlflow.start_span(name="outputs_only_span") as span:
        span.set_outputs({"response": "Test response"})
    return mlflow.get_trace(span.trace_id)


@pytest.fixture
def mock_judge_with_inputs_outputs():
    judge = mock.Mock()
    judge.get_input_fields.return_value = [
        JudgeField(name="inputs", description="Test inputs"),
        JudgeField(name="outputs", description="Test outputs"),
    ]
    return judge


def test_retrieval_groundedness(sample_rag_trace):
    with patch(
        "mlflow.genai.judges.is_grounded",
        side_effect=lambda *args, **kwargs: Feedback(
            name="retrieval_groundedness", value=CategoricalRating.YES
        ),
    ) as mock_is_grounded:
        # 1. Test with default scorer
        result = RetrievalGroundedness()(trace=sample_rag_trace)

    mock_is_grounded.assert_has_calls(
        [
            call(
                request="{'question': 'query'}",
                response="answer",
                context=[
                    {"content": "content_1", "doc_uri": "url_1"},
                    {"content": "content_2", "doc_uri": "url_2"},
                ],
                name="retrieval_groundedness",
                model=None,
            ),
            call(
                request="{'question': 'query'}",
                response="answer",
                context=[{"content": "content_3"}],
                name="retrieval_groundedness",
                model=None,
            ),
        ],
    )
    assert len(result) == 2
    assert all(isinstance(f, Feedback) for f in result)
    assert result[0].value == CategoricalRating.YES
    expected_span_ids = [
        s.span_id for s in sample_rag_trace.search_spans(span_type=SpanType.RETRIEVER)
    ]
    actual_span_ids = [f.span_id for f in result]
    assert set(actual_span_ids) == set(expected_span_ids)


@databricks_only
def test_retrieval_relevance(sample_rag_trace):
    mock_responses = [
        # First retriever span has 2 chunks
        [
            Feedback(name="retrieval_relevance", value="yes", metadata={"chunk_index": 0}),
            Feedback(name="retrieval_relevance", value="no", metadata={"chunk_index": 1}),
        ],
        # Second retriever span has 1 chunk
        [
            Feedback(name="retrieval_relevance", value="yes", metadata={"chunk_index": 0}),
        ],
    ]

    with patch(
        "databricks.agents.evals.judges.chunk_relevance", side_effect=mock_responses
    ) as mock_chunk_relevance:
        results = RetrievalRelevance()(trace=sample_rag_trace)

    mock_chunk_relevance.assert_has_calls(
        [
            call(
                request="{'question': 'query'}",
                retrieved_context=[
                    {"content": "content_1", "doc_uri": "url_1"},
                    {"content": "content_2", "doc_uri": "url_2"},
                ],
                assessment_name="retrieval_relevance",
            ),
            call(
                request="{'question': 'query'}",
                retrieved_context=[{"content": "content_3"}],
                assessment_name="retrieval_relevance",
            ),
        ],
    )

    assert len(results) == 5  # 2 span-level feedbacks + 3 chunk-level feedbacks
    assert all(isinstance(f, Feedback) for f in results)

    retriever_span_ids = [
        s.span_id for s in sample_rag_trace.search_spans(span_type=SpanType.RETRIEVER)
    ]

    # First feedbacks is a span-level feedback for the first retriever span
    assert results[0].value == 0.5
    assert results[0].name == "retrieval_relevance/precision"
    assert results[0].span_id == retriever_span_ids[0]

    # Second and third feedbacks are chunk-level feedbacks for the first retriever span
    assert results[1].value == "yes"
    assert results[1].name == "retrieval_relevance"
    assert results[1].span_id == retriever_span_ids[0]
    assert results[2].value == "no"
    assert results[2].name == "retrieval_relevance"
    assert results[2].span_id == retriever_span_ids[0]

    # Fourth result is a span-level feedback for the second retriever span
    assert results[3].value == 1.0
    assert results[3].name == "retrieval_relevance/precision"
    assert results[3].span_id == retriever_span_ids[1]

    # Fifth result is a chunk-level feedback for the second retriever span
    assert results[4].value == "yes"
    assert results[4].name == "retrieval_relevance"
    assert results[4].span_id == retriever_span_ids[1]


@databricks_only
def test_retrieval_relevance_handle_error_feedback(sample_rag_trace):
    from databricks.rag_eval.evaluation.entities import CategoricalRating as DatabricksRating

    mock_responses = [
        # Error feedback
        [
            Feedback(name="retrieval_relevance", value=DatabricksRating.YES),
            Feedback(name="retrieval_relevance", error=AssessmentError(error_code="test")),
        ],
        # Empty feedback - skip span
        [],
    ]

    with patch(
        "databricks.agents.evals.judges.chunk_relevance", side_effect=mock_responses
    ) as mock_chunk_relevance:
        results = RetrievalRelevance()(trace=sample_rag_trace)

    assert mock_chunk_relevance.call_count == 2
    assert len(results) == 3
    assert results[0].value == 0.5  # Error feedback is handled as 0.0 relevance
    assert results[1].value == CategoricalRating.YES
    assert results[2].value is None
    assert results[2].error.error_code == "test"


def test_retrieval_relevance_with_custom_model(sample_rag_trace, monkeypatch: pytest.MonkeyPatch):
    # Set a dummy OpenAI key to avoid validation errors
    monkeypatch.setenv("OPENAI_API_KEY", "test-key")

    with patch(
        "mlflow.genai.scorers.builtin_scorers.invoke_judge_model",
        return_value=Feedback(
            name="retrieval_relevance", value="yes", rationale="Relevant content"
        ),
    ) as mock_invoke_judge:
        custom_model = "openai:/gpt-4"
        scorer = RetrievalRelevance(model=custom_model)
        results = scorer(trace=sample_rag_trace)

        # Should be called for each chunk (3 total chunks)
        assert mock_invoke_judge.call_count == 3

        for call_args in mock_invoke_judge.call_args_list:
            args, kwargs = call_args
            assert args[0] == custom_model  # First positional arg is model
            assert kwargs["assessment_name"] == "retrieval_relevance"

        # 2 span-level + 3 chunk-level feedbacks
        assert len(results) == 5
        # Span-level feedbacks should be 100% relevance
        assert results[0].value == 1.0
        assert results[3].value == 1.0


def test_retrieval_sufficiency(sample_rag_trace):
    # 1. Test with default scorer
    with patch(
        "mlflow.genai.judges.is_context_sufficient",
        side_effect=lambda *args, **kwargs: Feedback(
            name="retrieval_sufficiency", value=CategoricalRating.YES
        ),
    ) as mock_is_context_sufficient:
        result = RetrievalSufficiency()(trace=sample_rag_trace)

    mock_is_context_sufficient.assert_has_calls(
        [
            call(
                request="{'question': 'query'}",
                context=[
                    {"content": "content_1", "doc_uri": "url_1"},
                    {"content": "content_2", "doc_uri": "url_2"},
                ],
                # Expectations stored in the trace is exploded
                expected_response="expected answer",
                expected_facts=["fact1", "fact2"],
                name="retrieval_sufficiency",
                model=None,
            ),
            call(
                request="{'question': 'query'}",
                context=[{"content": "content_3"}],
                expected_response="expected answer",
                expected_facts=["fact1", "fact2"],
                name="retrieval_sufficiency",
                model=None,
            ),
        ],
    )

    assert len(result) == 2
    assert all(isinstance(f, Feedback) for f in result)
    assert all(f.value == CategoricalRating.YES for f in result)
    expected_span_ids = [
        s.span_id for s in sample_rag_trace.search_spans(span_type=SpanType.RETRIEVER)
    ]
    actual_span_ids = [f.span_id for f in result]
    assert set(actual_span_ids) == set(expected_span_ids)

    # 2. Test with custom model parameter
    with patch(
        "mlflow.genai.judges.is_context_sufficient",
        side_effect=lambda *args, **kwargs: Feedback(
            name="custom_sufficiency", value=CategoricalRating.YES
        ),
    ) as mock_is_context_sufficient:
        custom_scorer = RetrievalSufficiency(
            name="custom_sufficiency",
            model="openai:/gpt-4.1-mini",
        )
        result = custom_scorer(trace=sample_rag_trace)

    mock_is_context_sufficient.assert_has_calls(
        [
            call(
                request="{'question': 'query'}",
                context=[
                    {"content": "content_1", "doc_uri": "url_1"},
                    {"content": "content_2", "doc_uri": "url_2"},
                ],
                expected_response="expected answer",
                expected_facts=["fact1", "fact2"],
                name="custom_sufficiency",
                model="openai:/gpt-4.1-mini",
            ),
            call(
                request="{'question': 'query'}",
                context=[{"content": "content_3"}],
                expected_response="expected answer",
                expected_facts=["fact1", "fact2"],
                name="custom_sufficiency",
                model="openai:/gpt-4.1-mini",
            ),
        ],
    )
    assert len(result) == 2


def test_retrieval_sufficiency_with_custom_expectations(sample_rag_trace):
    with patch(
        "mlflow.genai.judges.is_context_sufficient",
        return_value=Feedback(name="retrieval_sufficiency", value=CategoricalRating.YES),
    ) as mock_is_context_sufficient:
        RetrievalSufficiency()(
            trace=sample_rag_trace,
            expectations={"expected_facts": ["fact3"]},
        )

    mock_is_context_sufficient.assert_has_calls(
        [
            call(
                request="{'question': 'query'}",
                context=[
                    {"content": "content_1", "doc_uri": "url_1"},
                    {"content": "content_2", "doc_uri": "url_2"},
                ],
                # Expectations stored in the trace is exploded
                expected_facts=["fact3"],
                expected_response="expected answer",
                name="retrieval_sufficiency",
                model=None,
            ),
            call(
                request="{'question': 'query'}",
                context=[{"content": "content_3"}],
                expected_facts=["fact3"],
                expected_response="expected answer",
                name="retrieval_sufficiency",
                model=None,
            ),
        ],
    )


def test_guidelines():
    # 1. Called with per-row guidelines
    with patch("mlflow.genai.judges.meets_guidelines") as mock_guidelines:
        ExpectationsGuidelines()(
            inputs={"question": "query"},
            outputs="answer",
            expectations={"guidelines": ["guideline1", "guideline2"]},
        )

    mock_guidelines.assert_called_once_with(
        guidelines=["guideline1", "guideline2"],
        context={"request": "{'question': 'query'}", "response": "answer"},
        name="expectations_guidelines",
        model=None,
    )

    # 2. Called with global guidelines
    with patch("mlflow.genai.judges.meets_guidelines") as mock_guidelines:
        is_english = Guidelines(
            name="is_english",
            guidelines=["The response should be in English."],
            model="openai:/gpt-4.1-mini",
        )
        is_english(inputs={"question": "query"}, outputs="answer")

    mock_guidelines.assert_called_once_with(
        guidelines=["The response should be in English."],
        context={"request": "{'question': 'query'}", "response": "answer"},
        name="is_english",
        model="openai:/gpt-4.1-mini",
    )

    # 3. Test with string input (should wrap in list)
    with patch("mlflow.genai.judges.meets_guidelines") as mock_guidelines:
        is_polite = Guidelines(
            name="is_polite",
            guidelines="Be polite and respectful.",
            model="openai:/gpt-4.1-mini",
        )
        is_polite(inputs={"question": "query"}, outputs="answer")

    mock_guidelines.assert_called_once_with(
        guidelines="Be polite and respectful.",
        context={"request": "{'question': 'query'}", "response": "answer"},
        name="is_polite",
        model="openai:/gpt-4.1-mini",
    )


def test_relevance_to_query():
    # 1. Test with default scorer
    with patch("mlflow.genai.judges.is_context_relevant") as mock_is_context_relevant:
        RelevanceToQuery()(
            inputs={"question": "query"},
            outputs="answer",
        )

    mock_is_context_relevant.assert_called_once_with(
        request="{'question': 'query'}",
        context="answer",
        name="relevance_to_query",
        model=None,
    )

    # 2. Test with custom model parameter
    with patch("mlflow.genai.judges.is_context_relevant") as mock_is_context_relevant:
        relevance_custom = RelevanceToQuery(
            name="custom_relevance",
            model="openai:/gpt-4.1-mini",
tests/genai/judges/test_judge_base.py:37:        expectations: dict[str, Any] | None = None,
tests/genai/judges/test_make_judge.py:1519:    with pytest.raises(MlflowException, match="'expectations' must be a dictionary, got str"):
tests/genai/judges/test_make_judge.py:1522:    with pytest.raises(MlflowException, match="'expectations' must be a dictionary, got tuple"):
tests/genai/scorers/test_builtin_scorers.py:29:    get_all_scorers,
tests/genai/scorers/test_builtin_scorers.py:570:def test_get_all_scorers_oss(tracking_uri):
tests/genai/scorers/test_builtin_scorers.py:573:    scorers = get_all_scorers()
tests/genai/optimize/test_optimize.py:314:        # Extract expected_response if expectations is a dict
tests/genai/optimize/test_optimize.py:315:        if isinstance(expectations, dict) and "expected_response" in expectations:
tests/genai/evaluate/test_evaluation.py:457:                self, name: str, dataset_id: str, record_id: str, expectations: list[dict[str, Any]]
tests/cli/test_genai_eval_utils.py:243:            "mlflow.cli.genai_eval_utils.get_all_scorers", return_value=[]
tests/cli/test_genai_eval_utils.py:244:        ) as mock_get_all_scorers,
tests/cli/test_genai_eval_utils.py:254:        mock_get_all_scorers.assert_called_once()
tests/cli/test_genai_eval_utils.py:270:            "mlflow.cli.genai_eval_utils.get_all_scorers", return_value=[mock_builtin]
tests/cli/test_genai_eval_utils.py:271:        ) as mock_get_all_scorers,
tests/cli/test_genai_eval_utils.py:282:        mock_get_all_scorers.assert_called_once()
tests/cli/test_genai_eval_utils.py:290:            "mlflow.cli.genai_eval_utils.get_all_scorers", return_value=[]
tests/cli/test_genai_eval_utils.py:291:        ) as mock_get_all_scorers,
tests/cli/test_genai_eval_utils.py:301:        mock_get_all_scorers.assert_called_once()
mlflow/genai/judges/make_judge.py:174:            # Evaluate with expectations (must be dictionaries)
mlflow/genai/judges/instructions_judge/__init__.py:181:        self, expectations: dict[str, Any] | None, trace: Trace | None
mlflow/genai/judges/instructions_judge/__init__.py:184:        if expectations is not None and not isinstance(expectations, dict):
mlflow/genai/judges/instructions_judge/__init__.py:186:                f"'expectations' must be a dictionary, got {type(expectations).__name__}",
mlflow/genai/judges/instructions_judge/__init__.py:199:        expectations: dict[str, Any] | None,
mlflow/genai/judges/instructions_judge/__init__.py:224:        expectations: dict[str, Any] | None,
mlflow/genai/judges/instructions_judge/__init__.py:302:        expectations: dict[str, Any] | None,
mlflow/genai/judges/instructions_judge/__init__.py:328:        self, inputs: Any | None, outputs: Any | None, expectations: dict[str, Any] | None
mlflow/genai/judges/instructions_judge/__init__.py:361:        expectations: dict[str, Any] | None = None,
mlflow/genai/utils/trace_utils.py:153:    expectations: dict[str, Any] | None,
mlflow/genai/scorers/base.py:219:                f"Invalid scorer data: expected a SerializedScorer object or dictionary, "
mlflow/genai/scorers/base.py:432:        expectations: dict[str, Any] | None = None,
mlflow/genai/scorers/builtin_scorers.py:70:    expectations: dict[str, Any] | None = None
mlflow/genai/scorers/builtin_scorers.py:183:    expectations: dict[str, Any] | None = None,
mlflow/genai/scorers/builtin_scorers.py:547:        self, *, trace: Trace, expectations: dict[str, Any] | None = None
mlflow/genai/scorers/builtin_scorers.py:556:            expectations: A dictionary of expectations for the response. Either `expected_facts` or
mlflow/genai/scorers/builtin_scorers.py:921:        expectations: dict[str, Any] | None = None,
mlflow/genai/scorers/builtin_scorers.py:937:            expectations: A dictionary of expectations for the response. This must contain either
mlflow/genai/scorers/builtin_scorers.py:1317:        expectations: dict[str, Any] | None = None,
mlflow/genai/scorers/builtin_scorers.py:1333:            expectations: A dictionary of expectations for the response. This must contain either
mlflow/genai/scorers/builtin_scorers.py:1360:                "in the `expectations` dictionary."
mlflow/genai/scorers/builtin_scorers.py:1474:        expectations: dict[str, Any] | None = None,
mlflow/genai/scorers/builtin_scorers.py:1488:            expectations: A dictionary containing the expected output. Must contain an
mlflow/genai/scorers/builtin_scorers.py:1517:                "Equivalence scorer requires `expected_response` in the `expectations` dictionary."
mlflow/genai/scorers/__init__.py:36:    "get_all_scorers",
mlflow/genai/scorers/__init__.py:77:        get_all_scorers,
mlflow/genai/scorers/__init__.py:93:    "get_all_scorers",
mlflow/genai/evaluation/base.py:206:                - expectations (optional): Column containing a dictionary of ground truths.
mlflow/genai/evaluation/base.py:243:    scorers = validate_scorers(scorers)
mlflow/genai/evaluation/base.py:248:    valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)
mlflow/genai/evaluation/base.py:361:            from mlflow.genai.scorers import get_all_scorers
mlflow/genai/evaluation/base.py:385:                scorers=get_all_scorers(),
mlflow/genai/evaluation/entities.py:33:    expectations: dict[str, Any]
mlflow/genai/evaluation/utils.py:111:    NB: The harness secretly support 'expectations' column as well. It accepts a dictionary of
mlflow/genai/evaluation/utils.py:246:        # Condense all expectations into a single dict
mlflow/genai/evaluation/constant.py:22:# A column name for storing custom expectations dictionary in Agent Evaluation.
mlflow/genai/optimize/util.py:91:    valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)
mlflow/genai/optimize/util.py:157:        expectations: dict[str, Any],
mlflow/server/js/src/experiment-tracking/pages/experiment-evaluation-runs/RunEvaluationButton.tsx:30:  scorers=scorers.get_all_scorers()
mlflow/entities/dataset_record.py:33:    expectations: dict[str, Any] | None = None
mlflow/cli/genai_eval_utils.py:12:from mlflow.genai.scorers import Scorer, get_all_scorers, get_scorer
mlflow/cli/genai_eval_utils.py:121:    builtin_scorers = get_all_scorers()
mlflow/store/tracking/sqlalchemy_store.py:4207:                        expectations=record_dict.get("expectations"),
mlflow/store/tracking/dbmodels/models.py:1665:        if new_expectations := new_record_dict.get("expectations"):
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def test_.*scorer\\|@scorer\\|invalid.*param\\|aggregations\\|signature\" tests/genai/scorers/test_scorer.py; sed -n '1,260p' tests/genai/scorers/test_scorer.py; sed -n '540,630p' tests/genai/scorers/test_builtin_scorers.py; tail -120 mlflow/genai/scorers/builtin_scorers.py; sed -n '1,340p' mlflow/genai/evaluation/utils.py; grep -R -n \"validate_scorers\" tests | head -100; grep -R -n \"Missing required columns\\|MissingColumnsException\\|required columns\" tests/genai tests/evaluation | head -150"
```

退出码：`0`

输出：
```
62:def test_scorer_existence_in_metrics(sample_data, dummy_scorer, is_in_databricks):
70:def test_scorer_name_works(sample_data, dummy_scorer, is_in_databricks):
76:def test_trace_passed_to_builtin_scorers_correctly(
147:def test_trace_passed_to_custom_scorer_correctly(sample_data, is_in_databricks):
153:    @scorer
199:    @scorer
247:def test_scorer_on_genai_evaluate(sample_data, scorer_return, is_in_databricks):
248:    @scorer
268:def test_custom_scorer_allow_none_return():
269:    @scorer
276:def test_scorer_returns_feedback_with_error(sample_data, is_in_databricks):
277:    @scorer
304:def test_custom_scorer_overwrites_default_feedback_name(scorer_return, expected_feedback_name):
305:    @scorer
317:def test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list():
318:    @scorer
333:def test_custom_scorer_registration_blocked_for_non_databricks_uri():
336:    @scorer
337:    def test_custom_scorer(outputs) -> bool:
349:def test_custom_scorer_loading_blocked_for_non_databricks_uri():
353:        call_signature="(outputs)",
363:def test_custom_scorer_loading_blocked_for_databricks_remote_access():
367:        call_signature="(outputs)",
381:def test_custom_scorer_error_message_renders_code_snippet_legibly():
395:        call_signature="(outputs)",
408:    assert "@scorer" in error_msg
414:@scorer
429:def test_make_judge_scorer_works_without_databricks_uri():
from collections import defaultdict
from unittest.mock import call, patch

import pandas as pd
import pytest

import mlflow
from mlflow.entities import Assessment, AssessmentSource, AssessmentSourceType, Feedback
from mlflow.entities.assessment_error import AssessmentError
from mlflow.genai import Scorer, scorer
from mlflow.genai.judges import make_judge
from mlflow.genai.judges.utils import CategoricalRating
from mlflow.genai.scorers import Correctness, Guidelines, RetrievalGroundedness
from mlflow.genai.scorers.base import SerializedScorer
from mlflow.genai.scorers.registry import get_scorer, list_scorers


@pytest.fixture(autouse=True)
def increase_db_pool_size(monkeypatch):
    # Set larger pool size for tests to handle concurrent trace creation
    # test_extra_traces_from_customer_scorer_should_be_cleaned_up test requires this
    # to reduce flakiness
    monkeypatch.setenv("MLFLOW_SQLALCHEMYSTORE_POOL_SIZE", "20")
    monkeypatch.setenv("MLFLOW_SQLALCHEMYSTORE_MAX_OVERFLOW", "40")
    return


def always_yes(inputs, outputs, expectations, trace):
    return "yes"


class AlwaysYesScorer(Scorer):
    def __call__(self, inputs, outputs, expectations, trace):
        return "yes"


@pytest.fixture
def sample_data():
    return pd.DataFrame(
        {
            "inputs": [
                {"message": [{"role": "user", "content": "What is Spark??"}]},
                {
                    "messages": [
                        {"role": "user", "content": "How can you minimize data shuffling in Spark?"}
                    ]
                },
            ],
            "outputs": [
                {"choices": [{"message": {"content": "actual response for first question"}}]},
                {"choices": [{"message": {"content": "actual response for second question"}}]},
            ],
            "expectations": [
                {"expected_response": "expected response for first question"},
                {"expected_response": "expected response for second question"},
            ],
        }
    )


@pytest.mark.parametrize("dummy_scorer", [AlwaysYesScorer(name="always_yes"), scorer(always_yes)])
def test_scorer_existence_in_metrics(sample_data, dummy_scorer, is_in_databricks):
    result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])
    assert any("always_yes" in metric for metric in result.metrics.keys())


@pytest.mark.parametrize(
    "dummy_scorer", [AlwaysYesScorer(name="always_no"), scorer(name="always_no")(always_yes)]
)
def test_scorer_name_works(sample_data, dummy_scorer, is_in_databricks):
    _SCORER_NAME = "always_no"
    result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])
    assert any(_SCORER_NAME in metric for metric in result.metrics.keys())


def test_trace_passed_to_builtin_scorers_correctly(
    sample_rag_trace, is_in_databricks, monkeypatch: pytest.MonkeyPatch
):
    if not is_in_databricks:
        pytest.skip("OSS GenAI evaluator doesn't support passing traces yet")

    # Disable logging traces to MLflow to avoid calling mlflow APIs which need to be mocked
    monkeypatch.setenv("AGENT_EVAL_LOG_TRACES_TO_MLFLOW_ENABLED", "false")

    with (
        patch(
            "databricks.agents.evals.judges.correctness",
            return_value=Feedback(name="correctness", value=CategoricalRating.YES),
        ) as mock_correctness,
        patch(
            "databricks.agents.evals.judges.guidelines",
            return_value=Feedback(name="guidelines", value=CategoricalRating.YES),
        ) as mock_guidelines,
        patch(
            "databricks.agents.evals.judges.groundedness",
            return_value=Feedback(name="groundedness", value=CategoricalRating.YES),
        ) as mock_groundedness,
    ):
        mlflow.genai.evaluate(
            data=pd.DataFrame({"trace": [sample_rag_trace]}),
            scorers=[
                RetrievalGroundedness(name="retrieval_groundedness"),
                Correctness(name="correctness"),
                Guidelines(name="english", guidelines=["write in english"]),
            ],
        )

    assert mock_correctness.call_count == 1
    assert mock_guidelines.call_count == 1
    assert mock_groundedness.call_count == 2  # Called per retriever span

    mock_correctness.assert_called_once_with(
        request="{'question': 'query'}",
        response="answer",
        expected_facts=["fact1", "fact2"],
        expected_response="expected answer",
        assessment_name="correctness",
    )
    mock_guidelines.assert_called_once_with(
        guidelines=["write in english"],
        context={"request": "{'question': 'query'}", "response": "answer"},
        assessment_name="english",
    )
    mock_groundedness.assert_has_calls(
        [
            call(
                request="{'question': 'query'}",
                response="answer",
                retrieved_context=[
                    {"content": "content_1", "doc_uri": "url_1"},
                    {"content": "content_2", "doc_uri": "url_2"},
                ],
                assessment_name="retrieval_groundedness",
            ),
            call(
                request="{'question': 'query'}",
                response="answer",
                retrieved_context=[
                    {"content": "content_3"},
                ],
                assessment_name="retrieval_groundedness",
            ),
        ]
    )


def test_trace_passed_to_custom_scorer_correctly(sample_data, is_in_databricks):
    if not is_in_databricks:
        pytest.skip("OSS GenAI evaluator doesn't support passing traces yet")

    actual_call_args_list = []

    @scorer
    def dummy_scorer(inputs, outputs, expectations, trace) -> float:
        actual_call_args_list.append(
            {
                "inputs": inputs,
                "outputs": outputs,
                "expectations": expectations,
            }
        )
        return 0.0

    mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])

    assert len(actual_call_args_list) == len(sample_data)

    # Prepare expected arguments, keyed by expected_response for matching
    sample_data_set = defaultdict(set)
    for i in range(len(sample_data)):
        sample_data_set["inputs"].add(str(sample_data["inputs"][i]))
        sample_data_set["outputs"].add(str(sample_data["outputs"][i]))
        sample_data_set["expectations"].add(
            str(sample_data["expectations"][i]["expected_response"])
        )

    for actual_args in actual_call_args_list:
        # do any check since actual passed input could be reformatted and larger than sample input
        assert any(
            sample_data_input in str(actual_args["inputs"])
            for sample_data_input in sample_data_set["inputs"]
        )
        assert str(actual_args["outputs"]) in sample_data_set["outputs"]
        assert (
            str(actual_args["expectations"]["expected_response"]) in sample_data_set["expectations"]
        )


def test_trace_passed_correctly(is_in_databricks):
    if not is_in_databricks:
        pytest.skip("OSS GenAI evaluator doesn't support passing traces yet")

    @mlflow.trace
    def predict_fn(question):
        return "output: " + str(question)

    actual_call_args_list = []

    @scorer
    def dummy_scorer(inputs, outputs, trace):
        actual_call_args_list.append(
            {
                "inputs": inputs,
                "outputs": outputs,
                "trace": trace,
            }
        )
        return 0.0

    data = [
        {"inputs": {"question": "input1"}},
        {"inputs": {"question": "input2"}},
    ]
    mlflow.genai.evaluate(
        predict_fn=predict_fn,
        data=data,
        scorers=[dummy_scorer],
    )

    assert len(actual_call_args_list) == len(data)
    for actual_args in actual_call_args_list:
        assert actual_args["trace"] is not None
        trace = actual_args["trace"]
        # check if the input is present in the trace
        assert any(
            str(data[i]["inputs"]["question"]) in str(trace.data.request) for i in range(len(data))
        )
        # check if predict_fn was run by making output it starts with "output:"
        assert "output:" in str(trace.data.response)[:10]


@pytest.mark.parametrize(
    "scorer_return",
    [
        "yes",
        42,
        42.0,
        # Feedback object.
        Feedback(name="big_question", value=42, rationale="It's the answer to everything"),
        # List of Feedback objects.
        [
            Feedback(name="big_question", value=42, rationale="It's the answer to everything"),
            Feedback(name="small_question", value=1, rationale="Not sure, just a guess"),
        ],
    ],
)
def test_scorer_on_genai_evaluate(sample_data, scorer_return, is_in_databricks):
    @scorer
    def dummy_scorer(inputs, outputs):
        return scorer_return

    results = mlflow.genai.evaluate(
        data=sample_data,
        scorers=[dummy_scorer],
    )
    if isinstance(scorer_return, Assessment):
        assert any(scorer_return.name in metric for metric in results.metrics.keys())
    elif isinstance(scorer_return, list) and all(
        isinstance(item, Assessment) for item in scorer_return
    ):


def test_equivalence():
    # Test with default model
    scorer = Equivalence()

    # Test exact numerical match
    result = scorer(outputs=42, expectations={"expected_response": 42})
    assert result.name == "equivalence"
    assert result.value == CategoricalRating.YES
    assert "Exact numerical match" in result.rationale

    # Test exact string match
    result = scorer(outputs="Paris", expectations={"expected_response": "Paris"})
    assert result.value == CategoricalRating.YES
    assert "Exact string match" in result.rationale

    # Test numerical mismatch
    result = scorer(outputs=42, expectations={"expected_response": 43})
    assert result.value == CategoricalRating.NO
    assert "Values do not match" in result.rationale

    # Test with custom name and model
    scorer_custom = Equivalence(name="custom_output_equiv", model="openai:/gpt-4o-mini")
    result = scorer_custom(outputs=100, expectations={"expected_response": 100})
    assert result.name == "custom_output_equiv"
    assert result.value == CategoricalRating.YES


@pytest.mark.parametrize("tracking_uri", ["file://test", "databricks"])
def test_get_all_scorers_oss(tracking_uri):
    mlflow.set_tracking_uri(tracking_uri)

    scorers = get_all_scorers()

    # Safety and RetrievalRelevance are only available in Databricks
    assert len(scorers) == (8 if tracking_uri == "databricks" else 6)
    assert all(isinstance(scorer, Scorer) for scorer in scorers)


def test_retrieval_relevance_get_input_fields():
    if is_databricks_uri(mlflow.get_tracking_uri()):
        relevance = RetrievalRelevance(name="test")
        field_names = [field.name for field in relevance.get_input_fields()]
        assert field_names == ["trace"]


def test_retrieval_sufficiency_get_input_fields():
    if is_databricks_uri(mlflow.get_tracking_uri()):
        sufficiency = RetrievalSufficiency(name="test")
        field_names = [field.name for field in sufficiency.get_input_fields()]
        assert field_names == ["trace", "expectations"]


def test_retrieval_groundedness_get_input_fields():
    if is_databricks_uri(mlflow.get_tracking_uri()):
        groundedness = RetrievalGroundedness(name="test")
        field_names = [field.name for field in groundedness.get_input_fields()]
        assert field_names == ["trace"]


def test_guidelines_get_input_fields():
    guidelines = Guidelines(name="test", guidelines=["Be helpful"])
    field_names = [field.name for field in guidelines.get_input_fields()]
    assert field_names == ["inputs", "outputs"]


def test_expectations_guidelines_get_input_fields():
    exp_guidelines = ExpectationsGuidelines(name="test")
    field_names = [field.name for field in exp_guidelines.get_input_fields()]
    assert field_names == ["inputs", "outputs", "expectations"]


def test_relevance_to_query_get_input_fields():
    relevance_query = RelevanceToQuery(name="test")
    field_names = [field.name for field in relevance_query.get_input_fields()]
    assert field_names == ["inputs", "outputs"]


def test_safety_get_input_fields():
    if is_databricks_uri(mlflow.get_tracking_uri()):
        safety = Safety(name="test")
        field_names = [field.name for field in safety.get_input_fields()]
        assert field_names == ["outputs"]


def test_correctness_get_input_fields():
    correctness = Correctness(name="test")
    field_names = [field.name for field in correctness.get_input_fields()]
    assert field_names == ["inputs", "outputs", "expectations"]

            outputs: The actual output to compare. Optional when trace is provided.
            expectations: A dictionary containing the expected output. Must contain an
                'expected_response' key. Optional when trace is provided.
            trace: MLflow trace object containing the execution to evaluate. When provided,
                outputs and expectations will be automatically extracted from the trace.

        Returns:
            Feedback object with 'yes'/'no' value and rationale
        """
        from mlflow.genai.judges.builtin import _sanitize_feedback
        from mlflow.genai.judges.prompts.equivalence import (
            EQUIVALENCE_FEEDBACK_NAME,
            get_prompt,
        )

        # Use resolve_scorer_fields to extract fields from trace if provided
        fields = resolve_scorer_fields(
            trace,
            self,
            inputs,
            outputs,
            expectations,
            model=self.model,
            extract_expectations=True,
        )
        _validate_required_fields(fields, self, "Equivalence scorer")

        # Validate that expected_response is present
        if not fields.expectations or fields.expectations.get("expected_response") is None:
            raise MlflowException(
                "Equivalence scorer requires `expected_response` in the `expectations` dictionary."
            )

        # Extract the expected response
        expected_output = fields.expectations.get("expected_response")
        actual_output = fields.outputs

        # Handle exact match for numerical types
        if isinstance(actual_output, (int, float, bool)) and isinstance(
            expected_output, (int, float, bool)
        ):
            if math.isclose(actual_output, expected_output):
                return Feedback(
                    name=self.name,
                    value=CategoricalRating.YES,
                    rationale="Exact numerical match",
                )
            else:
                return Feedback(
                    name=self.name,
                    value=CategoricalRating.NO,
                    rationale=f"Values do not match: {actual_output} != {expected_output}",
                )

        # Convert to strings for comparison
        outputs_str = str(actual_output)
        expectations_str = str(expected_output)

        # Use exact match first
        if outputs_str == expectations_str:
            return Feedback(
                name=self.name,
                value=CategoricalRating.YES,
                rationale="Exact string match",
            )

        # Use LLM judge for semantic equivalence

        model = self.model or get_default_model()
        assessment_name = self.name or EQUIVALENCE_FEEDBACK_NAME

        prompt = get_prompt(
            output=outputs_str,
            expected_output=expectations_str,
        )
        feedback = invoke_judge_model(model, prompt, assessment_name=assessment_name)

        return _sanitize_feedback(feedback)



































class MissingColumnsException(MlflowException):
    def __init__(self, scorer: str, missing_columns: set[str]):
        self.scorer = scorer
        self.missing_columns = list(missing_columns)
        super().__init__(
            f"The following columns are required for the scorer {scorer}: {missing_columns}"
        )import json
import logging
import math
from concurrent.futures import Future, as_completed
from typing import TYPE_CHECKING, Any, Collection

from mlflow.entities import Assessment, Trace, TraceData
from mlflow.entities.assessment import DEFAULT_FEEDBACK_NAME, Feedback
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.exceptions import MlflowException
from mlflow.genai.evaluation.constant import (
    AgentEvaluationReserverKey,
)
from mlflow.genai.scorers import Scorer
from mlflow.models import EvaluationMetric

try:
    # `pandas` is not required for `mlflow-skinny`.
    import pandas as pd
except ImportError:
    pass

if TYPE_CHECKING:
    from mlflow.entities.evaluation_dataset import EvaluationDataset as EntityEvaluationDataset
    from mlflow.genai.datasets import EvaluationDataset as ManagedEvaluationDataset
    from mlflow.genai.evaluation.entities import EvalResult

    try:
        import pyspark.sql.dataframe

        EvaluationDatasetTypes = (
            pd.DataFrame
            | pyspark.sql.dataframe.DataFrame
            | list[dict]
            | ManagedEvaluationDataset
            | EntityEvaluationDataset
        )
    except ImportError:
        EvaluationDatasetTypes = (
            pd.DataFrame | list[dict] | ManagedEvaluationDataset | EntityEvaluationDataset
        )


_logger = logging.getLogger(__name__)

USER_DEFINED_ASSESSMENT_NAME_KEY = "_user_defined_assessment_name"
PGBAR_FORMAT = (
    "{l_bar}{bar}| {n_fmt}/{total_fmt} [Elapsed: {elapsed}, Remaining: {remaining}] {postfix}"
)


def _convert_eval_set_to_df(data: "EvaluationDatasetTypes") -> "pd.DataFrame":
    """
    Takes in a dataset in the format that `mlflow.genai.evaluate()` expects and
    converts it into a pandas DataFrame.
    """
    from mlflow.entities.evaluation_dataset import EvaluationDataset as EntityEvaluationDataset
    from mlflow.genai.datasets import EvaluationDataset as ManagedEvaluationDataset

    if isinstance(data, list):
        # validate that every item in the list is a dict and has inputs as key
        for item in data:
            if not isinstance(item, dict):
                raise MlflowException.invalid_parameter_value(
                    "Every item in the list must be a dictionary."
                )
        df = pd.DataFrame(data)
    elif isinstance(data, pd.DataFrame):
        # Data is already a pd DataFrame, just copy it
        df = data.copy()
    elif isinstance(data, (EntityEvaluationDataset, ManagedEvaluationDataset)):
        df = data.to_df()
    else:
        try:
            from mlflow.utils.spark_utils import get_spark_dataframe_type

            if isinstance(data, get_spark_dataframe_type()):
                df = _deserialize_inputs_and_expectations_column(data.toPandas())
            else:
                raise MlflowException.invalid_parameter_value(
                    "Invalid type for parameter `data`. Expected a list of dictionaries, "
                    f"a pandas DataFrame, or a Spark DataFrame. Got: {type(data)}"
                )
        except ImportError:
            raise ImportError(
                "The `pyspark` package is required to use mlflow.genai.evaluate() "
                "Please install it with `pip install pyspark`."
            )

    if len(df) == 0:
        raise MlflowException.invalid_parameter_value(
            "The dataset is empty. Please provide a non-empty dataset."
        )

    if not any(col in df.columns for col in ("trace", "inputs")):
        raise MlflowException.invalid_parameter_value(
            "Either `inputs` or `trace` column is required in the dataset. Please provide inputs "
            "for every datapoint or provide a trace."
        )

    return df


def _convert_to_eval_set(data: "EvaluationDatasetTypes") -> "pd.DataFrame":
    """
    Takes in a dataset in the multiple format that mlflow.genai.evaluate() expects and converts it
    into standardized Pandas DataFrame.
    The expected schema can be found at:
    https://docs.databricks.com/aws/en/generative-ai/agent-evaluation/evaluation-schema

    NB: The harness secretly support 'expectations' column as well. It accepts a dictionary of
        expectations, which is same as the schema that mlflow.genai.evaluate() expects.
        Therefore, we can simply pass through expectations column.
    """
    column_mapping = {
        "inputs": "request",
        "outputs": "response",
    }

    df = _convert_eval_set_to_df(data)

    return (
        df.rename(columns=column_mapping)
        .pipe(_deserialize_trace_column_if_needed)
        .pipe(_extract_request_response_from_trace)
        .pipe(_extract_expectations_from_trace)
    )


def _deserialize_inputs_and_expectations_column(df: "pd.DataFrame") -> "pd.DataFrame":
    """
    Deserialize the `inputs` and `expectations` string columns from the dataframe.

    When managed datasets are read as Spark DataFrames, the `inputs` and `expectations` columns
    are loaded as string columns of JSON strings. This function deserializes these columns into
    dictionaries expected by mlflow.genai.evaluate().
    """
    target_columns = ["inputs", "expectations"]
    for col in target_columns:
        if col not in df.columns or not isinstance(df[col][0], str):
            continue

        try:
            df[col] = df[col].apply(json.loads)
        except json.JSONDecodeError as e:
            if col == "inputs":
                msg = (
                    "The `inputs` column must be a valid JSON string of field names and values. "
                    "For example, `{'question': 'What is the capital of France?'}`"
                )
            else:
                msg = (
                    "The `expectations` column must be a valid JSON string of assessment names and "
                    "values. For example, `{'expected_facts': ['fact1', 'fact2']}`"
                )
            raise MlflowException.invalid_parameter_value(
                f"Failed to parse `{col}` column. Error: {e}\nHint: {msg}"
            )

    return df


def _deserialize_trace_column_if_needed(df: "pd.DataFrame") -> "pd.DataFrame":
    """
    Deserialize the `trace` column from the dataframe if it is a string.

    Since MLflow 3.2.0, mlflow.search_traces() returns a pandas DataFrame with a `trace`
    column that is a trace json representation rather than the Trace object itself. This
    function deserializes the `trace` column into a Trace object.
    """
    if "trace" in df.columns:
        df["trace"] = df["trace"].apply(lambda t: Trace.from_json(t) if isinstance(t, str) else t)
    return df


def _extract_request_response_from_trace(df: "pd.DataFrame") -> "pd.DataFrame":
    """
    Add `request` and `response`columns from traces if it is not already present.
    """
    if "trace" not in df.columns:
        return df

    def _extract_attribute(trace_data: TraceData, attribute_name: str) -> Any:
        if att := getattr(trace_data, attribute_name, None):
            return json.loads(att)
        return None

    if "request" not in df.columns:
        df["request"] = df["trace"].apply(lambda trace: _extract_attribute(trace.data, "request"))
    if "response" not in df.columns:
        df["response"] = df["trace"].apply(lambda trace: _extract_attribute(trace.data, "response"))
    return df


def _extract_expectations_from_trace(df: "pd.DataFrame") -> "pd.DataFrame":
    """
    Add `expectations` columns to the dataframe from assessments
    stored in the traces, if the "expectations" column is not already present.
    """
    if "trace" not in df.columns:
        return df

    expectations_column = []
    for trace in df["trace"]:
        expectations = {}
        for assessment in trace.info.assessments or []:
            if assessment.expectation is not None:
                expectations[assessment.name] = assessment.expectation.value
        expectations_column.append(expectations)
    # If no trace has assessments, not add the column
    if all(len(expectations) == 0 for expectations in expectations_column):
        return df

    df["expectations"] = expectations_column
    return df


def _convert_scorer_to_legacy_metric(scorer: Scorer) -> EvaluationMetric:
    """
    Takes in a Scorer object and converts it into a legacy MLflow 2.x
    Metric object.
    """
    try:
        from databricks.agents.evals import metric
    except ImportError:
        raise ImportError(
            "The `databricks-agents` package is required to use mlflow.genai.evaluate() "
            "Please install it with `pip install databricks-agents`."
        )

    from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
    from mlflow.types.llm import ChatCompletionRequest

    def eval_fn(
        request_id: str,
        request: ChatCompletionRequest | str,
        response: Any | None,
        expected_response: Any | None,
        trace: Trace | None,
        guidelines: list[str] | dict[str, list[str]] | None,
        expected_facts: list[str] | None,
        expected_retrieved_context: list[dict[str, str]] | None,
        custom_expected: dict[str, Any] | None,
        **kwargs,
    ) -> int | float | bool | str | Assessment | list[Assessment]:
        # Condense all expectations into a single dict
        expectations = {}
        if expected_response is not None:
            expectations[AgentEvaluationReserverKey.EXPECTED_RESPONSE] = expected_response
        if expected_facts is not None:
            expectations[AgentEvaluationReserverKey.EXPECTED_FACTS] = expected_facts
        if expected_retrieved_context is not None:
            expectations[AgentEvaluationReserverKey.EXPECTED_RETRIEVED_CONTEXT] = (
                expected_retrieved_context
            )
        if guidelines is not None:
            expectations[AgentEvaluationReserverKey.GUIDELINES] = guidelines
        if custom_expected is not None:
            expectations.update(custom_expected)

        merged = {
            "inputs": request,
            "outputs": response,
            "expectations": expectations,
            "trace": trace,
        }
        return scorer.run(**merged)

    metric_instance = metric(
        eval_fn=eval_fn,
        name=scorer.name,
    )
    # Add aggregations as an attribute since the metric decorator doesn't accept it
    metric_instance.aggregations = scorer.aggregations
    # Add attribute to indicate if this is a built-in scorer
    metric_instance._is_builtin_scorer = isinstance(scorer, BuiltInScorer)

    return metric_instance


def standardize_scorer_value(scorer_name: str, value: Any) -> list[Feedback]:
    """
    Convert the scorer return value to a list of MLflow Assessment (Feedback) objects.

    Scorer can return:
    - A number, boolean, or string, a list of them.
    - An Feedback object
    - A list of Feedback objects

    All of the above will be converted to a list of Feedback objects.
    """
    # None is a valid metric value, return an empty list
    if value is None:
        return []

    # Primitives are valid metric values
    if isinstance(value, (int, float, bool, str)):
        return [
            Feedback(
                name=scorer_name,
                source=make_code_type_assessment_source(scorer_name),
                value=value,
            )
        ]

    if isinstance(value, Feedback):
        value.name = _get_custom_assessment_name(value, scorer_name)
        return [value]

    if isinstance(value, Collection):
        assessments = []
        for item in value:
            if isinstance(item, Feedback):
                # Scorer returns multiple assessments as a list.
                item.name = _get_custom_assessment_name(item, scorer_name)
                assessments.append(item)
            else:
                # If the item is not assessment, the list represents a single assessment
                # value of list type. Convert it to a Feedback object.
                assessments.append(
                    Feedback(
                        name=scorer_name,
                        source=make_code_type_assessment_source(scorer_name),
                        value=item,
                    )
                )
        return assessments

    raise MlflowException.invalid_parameter_value(
        f"Got unsupported result from scorer '{scorer_name}'. "
        f"Expected the metric value to be a number, or a boolean, or a string, "
        "or an Feedback, or a list of Feedbacks. "
        f"Got {value}.",
    )


def _get_custom_assessment_name(assessment: Feedback, scorer_name: str) -> str:
    """Get the name of the custom assessment. Use assessment name if present and not a builtin judge
    name, otherwise use the scorer name.

grep: tests/evaluation: No such file or directory
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "git status --short; sed -n '240,460p' tests/genai/scorers/test_scorer.py; grep -R -n \"validate_aggregations\\|Invalid aggregation\\|Scorer function\\|only.*inputs.*outputs\\|get_all_scorers()\" tests/genai tests | head -250; grep -n \""'^class '"\\(ExpectationsGuidelines\\|Correctness\\|RelevanceToQuery\\|RetrievalSufficiency\\|RetrievalGroundedness\\|Equivalence\\|Safety\\|RetrievalRelevance\\)\\|required_columns\" mlflow/genai/scorers/builtin_scorers.py; sed -n '1220,1545p' mlflow/genai/scorers/builtin_scorers.py; sed -n '220,275p' mlflow/genai/evaluation/base.py"
```

退出码：`0`

输出：
```
        # List of Feedback objects.
        [
            Feedback(name="big_question", value=42, rationale="It's the answer to everything"),
            Feedback(name="small_question", value=1, rationale="Not sure, just a guess"),
        ],
    ],
)
def test_scorer_on_genai_evaluate(sample_data, scorer_return, is_in_databricks):
    @scorer
    def dummy_scorer(inputs, outputs):
        return scorer_return

    results = mlflow.genai.evaluate(
        data=sample_data,
        scorers=[dummy_scorer],
    )
    if isinstance(scorer_return, Assessment):
        assert any(scorer_return.name in metric for metric in results.metrics.keys())
    elif isinstance(scorer_return, list) and all(
        isinstance(item, Assessment) for item in scorer_return
    ):
        assert any(
            item.name in metric for item in scorer_return for metric in results.metrics.keys()
        )
    else:
        assert any("dummy_scorer" in metric for metric in results.metrics.keys())


def test_custom_scorer_allow_none_return():
    @scorer
    def dummy_scorer(inputs, outputs):
        return None

    assert dummy_scorer.run(inputs={"question": "query"}, outputs="answer") is None


def test_scorer_returns_feedback_with_error(sample_data, is_in_databricks):
    @scorer
    def dummy_scorer(inputs):
        return Feedback(
            name="feedback_with_error",
            error=AssessmentError(error_code="500", error_message="This is an error"),
            source=AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id="gpt"),
            metadata={"index": 0},
        )

    results = mlflow.genai.evaluate(
        data=sample_data,
        scorers=[dummy_scorer],
    )

    # Scorer should not be in result when it returns an error
    assert all("dummy_scorer" not in metric for metric in results.metrics.keys())


@pytest.mark.parametrize(
    ("scorer_return", "expected_feedback_name"),
    [
        # Single feedback object with default name -> should be renamed to "my_scorer"
        (Feedback(value=42, rationale="rationale"), "my_scorer"),
        # Single feedback object with custom name -> should NOT be renamed to "my_scorer"
        (Feedback(name="custom_name", value=42, rationale="rationale"), "custom_name"),
    ],
)
def test_custom_scorer_overwrites_default_feedback_name(scorer_return, expected_feedback_name):
    @scorer
    def my_scorer(inputs, outputs):
        return scorer_return

    feedback = my_scorer.run(
        inputs={"question": "What is the capital of France?"},
        outputs="The capital of France is Paris.",
    )
    assert feedback.name == expected_feedback_name
    assert feedback.value == 42


def test_custom_scorer_does_not_overwrite_feedback_name_when_returning_list():
    @scorer
    def my_scorer(inputs, outputs):
        return [
            Feedback(name="big_question", value=42, rationale="It's the answer to everything"),
            Feedback(name="small_question", value=1, rationale="Not sure, just a guess"),
        ]

    feedbacks = my_scorer.run(
        inputs={"question": "What is the capital of France?"},
        outputs="The capital of France is Paris.",
    )
    assert feedbacks[0].name == "big_question"
    assert feedbacks[1].name == "small_question"


def test_custom_scorer_registration_blocked_for_non_databricks_uri():
    experiment_id = mlflow.create_experiment("test_security_experiment")

    @scorer
    def test_custom_scorer(outputs) -> bool:
        return len(outputs) > 0

    with pytest.raises(
        mlflow.exceptions.MlflowException,
        match="Custom scorer registration.*not supported outside of Databricks tracking",
    ):
        test_custom_scorer.register(experiment_id=experiment_id, name="test_scorer")

    mlflow.delete_experiment(experiment_id)


def test_custom_scorer_loading_blocked_for_non_databricks_uri():
    serialized = SerializedScorer(
        name="malicious_scorer",
        call_source="import os\nos.system('echo hacked')\nreturn True",
        call_signature="(outputs)",
        original_func_name="malicious_scorer",
    )

    with pytest.raises(
        mlflow.exceptions.MlflowException, match="Loading custom scorer.*not supported"
    ):
        Scorer._reconstruct_decorator_scorer(serialized)


def test_custom_scorer_loading_blocked_for_databricks_remote_access():
    serialized = SerializedScorer(
        name="malicious_scorer",
        call_source="import os\nos.system('echo hacked')\nreturn True",
        call_signature="(outputs)",
        original_func_name="malicious_scorer",
    )

    with (
        patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=False),
        patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True),
    ):
        with pytest.raises(
            mlflow.exceptions.MlflowException, match="via remote access is not supported"
        ):
            Scorer._reconstruct_decorator_scorer(serialized)


def test_custom_scorer_error_message_renders_code_snippet_legibly():
    serialized = SerializedScorer(
        name="complex_scorer",
        call_source=(
            "if not outputs:\n"
            "    return 0\n"
            "score = 0\n"
            "for word in outputs.split():\n"
            "    if word.isupper():\n"
            "        score += 2\n"
            "    else:\n"
            "        score += 1\n"
            "return score"
        ),
        call_signature="(outputs)",
        original_func_name="complex_scorer",
    )

    with pytest.raises(
        mlflow.exceptions.MlflowException, match="is not supported outside of"
    ) as exc_info:
        Scorer._reconstruct_decorator_scorer(serialized)

    error_msg = str(exc_info.value)

    assert "Registered scorer code:" in error_msg
    assert "from mlflow.genai import scorer" in error_msg
    assert "@scorer" in error_msg
    assert "def complex_scorer(outputs):" in error_msg

    expected_code = """
from mlflow.genai import scorer

@scorer
def complex_scorer(outputs):
    if not outputs:
        return 0
    score = 0
    for word in outputs.split():
        if word.isupper():
            score += 2
        else:
            score += 1
    return score"""

    assert expected_code.strip() in error_msg


def test_make_judge_scorer_works_without_databricks_uri():
    experiment_id = mlflow.create_experiment("test_make_judge_experiment")

    judge_scorer = make_judge(
        instructions="Evaluate if the {{outputs}} is helpful and relevant",
        name="helpfulness_judge",
        feedback_value_type=str,
    )

    registered_scorer = judge_scorer.register(experiment_id=experiment_id, name="helpfulness_judge")

    assert registered_scorer is not None
    assert registered_scorer.name == "helpfulness_judge"

    retrieved_scorer = get_scorer(name="helpfulness_judge", experiment_id=experiment_id)
    assert retrieved_scorer is not None
    assert retrieved_scorer.name == "helpfulness_judge"

    scorers = list_scorers(experiment_id=experiment_id)
    assert len(scorers) == 1
    assert scorers[0].name == "helpfulness_judge"

    mlflow.delete_experiment(experiment_id)
tests/genai/judges/test_make_judge.py:2458:    # Call judge with only trace - should extract inputs/outputs from it
tests/genai/scorers/test_builtin_scorers.py:573:    scorers = get_all_scorers()
tests/genai/judges/test_make_judge.py:2458:    # Call judge with only trace - should extract inputs/outputs from it
tests/genai/scorers/test_builtin_scorers.py:573:    scorers = get_all_scorers()
266:    required_columns: set[str] = set()
325:        missing_columns = self.required_columns - columns
335:class RetrievalRelevance(BuiltInScorer):
369:    required_columns: set[str] = {"inputs", "trace"}
464:class RetrievalSufficiency(BuiltInScorer):
499:    required_columns: set[str] = {"inputs", "trace"}
590:class RetrievalGroundedness(BuiltInScorer):
625:    required_columns: set[str] = {"inputs", "trace"}
751:    required_columns: set[str] = {"inputs", "outputs"}
826:class ExpectationsGuidelines(BuiltInScorer):
872:    required_columns: set[str] = {"inputs", "outputs"}
980:class RelevanceToQuery(BuiltInScorer):
1023:    required_columns: set[str] = {"inputs", "outputs"}
1094:class Safety(BuiltInScorer):
1133:    required_columns: set[str] = {"inputs", "outputs"}
1196:class Correctness(BuiltInScorer):
1260:    required_columns: set[str] = {"inputs", "outputs"}
1380:class Equivalence(BuiltInScorer):
1434:    required_columns: set[str] = {"outputs"}
                "shuffles all data, making reduceByKey more efficient."
            ),
            expectations=[
                {"expected_response": "reduceByKey aggregates data before shuffling"},
                {"expected_response": "groupByKey shuffles all data"},
            ],
        )
        print(assessment)

    Example (with evaluate):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Correctness

        data = [
            {
                "inputs": {
                    "question": (
                        "What is the difference between reduceByKey and groupByKey in Spark?"
                    )
                },
                "outputs": (
                    "reduceByKey aggregates data before shuffling, whereas groupByKey "
                    "shuffles all data, making reduceByKey more efficient."
                ),
                "expectations": {
                    "expected_response": (
                        "reduceByKey aggregates data before shuffling. "
                        "groupByKey shuffles all data"
                    ),
                },
            }
        ]
        result = mlflow.genai.evaluate(data=data, scorers=[Correctness()])
    """

    name: str = "correctness"
    model: str | None = None
    required_columns: set[str] = {"inputs", "outputs"}
    description: str = (
        "Check whether the agent's response matches the facts in expected_response or "
        "expected_facts."
    )

    @property
    def instructions(self) -> str:
        """Get the instructions of what this scorer evaluates."""
        return CORRECTNESS_PROMPT_INSTRUCTIONS

    def validate_columns(self, columns: set[str]) -> None:
        super().validate_columns(columns)
        if (
            "expectations/expected_response" not in columns
            and "expectations/expected_facts" not in columns
        ):
            raise MissingColumnsException(
                self.name,
                ["expectations/expected_response or expectations/expected_facts"],
            )

    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for the Correctness judge.

        Returns:
            List of JudgeField objects defining the input fields based on the __call__ method.
        """
        return [
            JudgeField(
                name="inputs",
                description=(
                    "A dictionary of input data, e.g. "
                    "{'question': 'What is the capital of France?'}."
                ),
            ),
            JudgeField(
                name="outputs",
                description="The response from the model, e.g. 'The capital of France is Paris.'",
            ),
            JudgeField(
                name="expectations",
                description=(
                    "A dictionary of expectations for the response. This must contain either "
                    "`expected_response` or `expected_facts` key, which is used to evaluate the "
                    "response against the expected response or facts respectively. "
                    "E.g., {'expected_facts': ['Paris', 'France', 'Capital']}"
                ),
            ),
        ]

    def __call__(
        self,
        *,
        inputs: dict[str, Any] | None = None,
        outputs: Any | None = None,
        expectations: dict[str, Any] | None = None,
        trace: Trace | None = None,
    ) -> Feedback:
        """
        Evaluate correctness of the response against expectations.

        This scorer can be used in two ways:
        1. Pass an MLflow trace object to automatically extract
           inputs, outputs, and expectations from the trace and its assessments.
        2. Directly provide inputs, outputs, and expectations to evaluate.

        Args:
            inputs: A dictionary of input data, e.g. {"question": "What is the capital of France?"}.
                Optional when trace is provided.
            outputs: The response from the model, e.g. "The capital of France is Paris."
                Optional when trace is provided.
            expectations: A dictionary of expectations for the response. This must contain either
                `expected_response` or `expected_facts` key. Optional when trace is provided;
                will be extracted from trace's human assessment data if available.
            trace: MLflow trace object containing the execution to evaluate. When provided,
                inputs, outputs, and expectations will be automatically extracted from the trace.

        Returns:
            An :py:class:`mlflow.entities.assessment.Feedback~` object with a boolean value
            indicating the correctness of the response.
        """
        fields = resolve_scorer_fields(
            trace,
            self,
            inputs,
            outputs,
            expectations,
            model=self.model,
            extract_expectations=True,
        )
        _validate_required_fields(fields, self, "Correctness scorer")

        if not fields.expectations or (
            fields.expectations.get("expected_response") is None
            and fields.expectations.get("expected_facts") is None
        ):
            raise MlflowException(
                "Correctness scorer requires either `expected_response` or `expected_facts` "
                "in the `expectations` dictionary."
            )

        request = parse_inputs_to_str(fields.inputs)
        response = parse_outputs_to_str(fields.outputs)
        expected_facts = fields.expectations.get("expected_facts")
        expected_response = fields.expectations.get("expected_response")

        feedback = judges.is_correct(
            request=request,
            response=response,
            expected_response=expected_response,
            expected_facts=expected_facts,
            name=self.name,
            model=self.model,
        )
        return _sanitize_scorer_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
class Equivalence(BuiltInScorer):
    """
    Equivalence compares outputs against expected outputs for semantic equivalence.

    This scorer uses exact matching for numerical types (int, float, bool) and
    an LLM judge for text outputs to determine if they are semantically equivalent
    in both content and format.

    You can invoke the scorer directly with a single input for testing, or pass it to
    `mlflow.genai.evaluate` or `mlflow.genai.optimize_prompts` for evaluation.

    Args:
        name: The name of the scorer. Defaults to "equivalence".
        model: {{ model }}

    Example (direct usage):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Equivalence

        # Numerical equivalence
        assessment = Equivalence()(
            outputs=42,
            expectations={"expected_response": 42},
        )
        print(assessment)  # value: ategoricalRating.YES, rationale: 'Exact numerical match'

        # Text equivalence
        assessment = Equivalence()(
            outputs="The capital is Paris",
            expectations={"expected_response": "Paris is the capital"},
        )
        print(assessment)  # value: CategoricalRating.YES (semantically equivalent)

    Example (with evaluate):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Equivalence

        data = [
            {
                "outputs": "The capital is Paris",
                "expectations": {"expected_response": "Paris"},
            }
        ]
        result = mlflow.genai.evaluate(data=data, scorers=[Equivalence()])
    """

    name: str = "equivalence"
    model: str | None = None
    required_columns: set[str] = {"outputs"}
    description: str = "Compare outputs against expected outputs for semantic equivalence."

    @property
    def instructions(self) -> str:
        """Get the instructions of what this scorer evaluates."""
        return EQUIVALENCE_PROMPT_INSTRUCTIONS

    def validate_columns(self, columns: set[str]) -> None:
        super().validate_columns(columns)
        if "expectations/expected_response" not in columns:
            raise MissingColumnsException(self.name, {"expectations/expected_response"})

    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for the Equivalence scorer.

        Returns:
            List of JudgeField objects defining the input fields.
        """
        return [
            JudgeField(
                name="outputs",
                description="The actual output from the program to compare.",
            ),
            JudgeField(
                name="expectations",
                description=(
                    "A dictionary containing the expected output. Must contain an "
                    "'expected_response' key with the expected value, e.g. "
                    "{'expected_response': 'Paris'}."
                ),
            ),
        ]

    def __call__(
        self,
        *,
        inputs: dict[str, Any] | None = None,
        outputs: Any | None = None,
        expectations: dict[str, Any] | None = None,
        trace: Trace | None = None,
    ) -> Feedback:
        """
        Evaluate output equivalence.

        This scorer can be used in two ways:
        1. Pass an MLflow trace object to automatically extract
           outputs and expectations from the trace and its assessments.
        2. Directly provide outputs and expectations to evaluate.

        Args:
            inputs: A dictionary of input data (optional, not used in evaluation).
            outputs: The actual output to compare. Optional when trace is provided.
            expectations: A dictionary containing the expected output. Must contain an
                'expected_response' key. Optional when trace is provided.
            trace: MLflow trace object containing the execution to evaluate. When provided,
                outputs and expectations will be automatically extracted from the trace.

        Returns:
            Feedback object with 'yes'/'no' value and rationale
        """
        from mlflow.genai.judges.builtin import _sanitize_feedback
        from mlflow.genai.judges.prompts.equivalence import (
            EQUIVALENCE_FEEDBACK_NAME,
            get_prompt,
        )

        # Use resolve_scorer_fields to extract fields from trace if provided
        fields = resolve_scorer_fields(
            trace,
            self,
            inputs,
            outputs,
            expectations,
            model=self.model,
            extract_expectations=True,
        )
        _validate_required_fields(fields, self, "Equivalence scorer")

        # Validate that expected_response is present
        if not fields.expectations or fields.expectations.get("expected_response") is None:
            raise MlflowException(
                "Equivalence scorer requires `expected_response` in the `expectations` dictionary."
            )

        # Extract the expected response
        expected_output = fields.expectations.get("expected_response")
        actual_output = fields.outputs

        # Handle exact match for numerical types
        if isinstance(actual_output, (int, float, bool)) and isinstance(
            expected_output, (int, float, bool)
        ):
            if math.isclose(actual_output, expected_output):
                return Feedback(
                    name=self.name,
                    value=CategoricalRating.YES,
                    rationale="Exact numerical match",
                )
            else:
                return Feedback(
                    name=self.name,
                    value=CategoricalRating.NO,
                    rationale=f"Values do not match: {actual_output} != {expected_output}",
                )

        # Convert to strings for comparison
        outputs_str = str(actual_output)
        expectations_str = str(expected_output)

        # Use exact match first
            scoring.

            The function must emit a single trace per call. If it doesn't, decorate
            the function with @mlflow.trace decorator to ensure a trace to be emitted.

        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")
            to associate with the evaluation results. Can be also set globally via the
            :py:func:`mlflow.set_active_model` function.

    Returns:
        An :py:class:`mlflow.models.EvaluationResult~` object.

    Note:
        This function is only supported on Databricks. The tracking URI must be
        set to Databricks.

    .. warning::

        This function is not thread-safe. Please do not use it in multi-threaded
        environments.
    """
    is_managed_dataset = isinstance(data, (EvaluationDataset, EntityEvaluationDataset))

    scorers = validate_scorers(scorers)
    # convert into a pandas dataframe with expected evaluation set schema
    df = data.to_df() if is_managed_dataset else _convert_to_eval_set(data)

    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
    valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)

    # "request" column must exist after conversion
    input_key = "inputs" if is_managed_dataset else "request"
    sample_input = df.iloc[0][input_key]

    # Only check 'inputs' column when it is not derived from the trace object
    if "trace" not in df.columns and not isinstance(sample_input, dict):
        raise MlflowException.invalid_parameter_value(
            "The 'inputs' column must be a dictionary of field names and values. "
            "For example: {'query': 'What is MLflow?'}"
        )

    # If the input dataset is a managed dataset, we pass the original dataset
    # to the evaluate function to preserve metadata like dataset name.
    data = data if is_managed_dataset else df

    if predict_fn:
        predict_fn = convert_predict_fn(predict_fn=predict_fn, sample_input=sample_input)

    return _run_harness(data, scorers, predict_fn, model_id)


@record_usage_event(GenAIEvaluateEvent)
def _run_harness(data, scorers, predict_fn, model_id):
    from mlflow.genai.evaluation import harness

    # NB: The "RAG_EVAL_MAX_WORKERS" env var is used in the DBX agent harness, but is
```

## 原始行 20 · agent_message

```
The three requested bodies are indeed masked out. I’ve confirmed the surrounding model hierarchy and call sites; next I’m reconstructing behavior from the repository’s own tests and adjacent utilities, especially the schema conversion path that renames `inputs`/`outputs` and preserves `expectations`.
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"create_model(.*Scorer\\|__signature__.*inspect\\|_original_func\\|ScorerKind.DECORATOR\" mlflow tests | head -200; grep -R -n \"IS_DBX_AGENTS_INSTALLED\\|databricks.rag_eval.evaluation.metrics.Metric\\|rag_eval.evaluation.metrics\" mlflow tests | head -200; grep -R -n \"get_all_scorers\" . --exclude='*.pyc' --exclude-dir=.git | head -100; grep -R -n \"MissingColumnsException\" . --exclude='*.pyc' --exclude-dir=.git | head -100; sed -n '1,140p' mlflow/genai/judges/base.py; sed -n '1,130p' mlflow/genai/scorers/__init__.py; grep -R -n \"deprecated.*metric\\|legacy.*metric\" mlflow/genai mlflow/utils | head -100"
```

退出码：`0`

输出：
```
mlflow/tracing/fluent.py:405:        wrapped.__signature__ = inspect.signature(fn)
mlflow/genai/scorers/base.py:35:_ALLOWED_SCORERS_FOR_REGISTRATION = [ScorerKind.BUILTIN, ScorerKind.DECORATOR]
mlflow/genai/scorers/base.py:157:        if not getattr(self, "_original_func", None):
mlflow/genai/scorers/base.py:193:        call_body, _ = extract_function_body(self._original_func)
mlflow/genai/scorers/base.py:195:        result["original_func_name"] = self._original_func.__name__
mlflow/genai/scorers/base.py:198:        result["call_signature"] = str(inspect.signature(self._original_func))
mlflow/genai/scorers/base.py:821:        if self.kind == ScorerKind.DECORATOR and not is_databricks_uri(get_tracking_uri()):
mlflow/utils/autologging_utils/safety.py:423:                        event_logger.log_original_function_start(og_args, og_kwargs)
mlflow/utils/autologging_utils/safety.py:427:                        event_logger.log_original_function_success(og_args, og_kwargs)
mlflow/utils/autologging_utils/safety.py:430:                        event_logger.log_original_function_error(og_args, og_kwargs, e)
mlflow/utils/autologging_utils/safety.py:588:                        event_logger.log_original_function_start(og_args, og_kwargs)
mlflow/utils/autologging_utils/safety.py:590:                        event_logger.log_original_function_success(og_args, og_kwargs)
mlflow/utils/autologging_utils/safety.py:593:                        event_logger.log_original_function_error(og_args, og_kwargs, e)
mlflow/utils/autologging_utils/safety.py:789:        updated_wrapper.__signature__ = inspect.signature(wrapped)
mlflow/utils/autologging_utils/events.py:54:    def log_original_function_start(self, args, kwargs):
mlflow/utils/autologging_utils/events.py:55:        self._logger.log_original_function_start(
mlflow/utils/autologging_utils/events.py:60:    def log_original_function_success(self, args, kwargs):
mlflow/utils/autologging_utils/events.py:61:        self._logger.log_original_function_success(
mlflow/utils/autologging_utils/events.py:66:    def log_original_function_error(self, args, kwargs, exception):
mlflow/utils/autologging_utils/events.py:67:        self._logger.log_original_function_error(
mlflow/utils/autologging_utils/events.py:213:    def log_original_function_start(
mlflow/utils/autologging_utils/events.py:239:    def log_original_function_success(
mlflow/utils/autologging_utils/events.py:267:    def log_original_function_error(
tests/autologging/test_autologging_utils.py:630:    AutologgingEventLogger.get_logger().log_original_function_start(
tests/autologging/test_autologging_utils.py:633:    AutologgingEventLogger.get_logger().log_original_function_success(
tests/autologging/test_autologging_utils.py:657:    AutologgingEventLogger.get_logger().log_original_function_start(
tests/autologging/test_autologging_safety_unit.py:108:    def log_original_function_start(
tests/autologging/test_autologging_safety_unit.py:117:    def log_original_function_success(
tests/autologging/test_autologging_safety_unit.py:126:    def log_original_function_error(
tests/autologging/test_autologging_safety_unit.py:183:def test_safe_patch_provides_expected_original_function(
tests/autologging/test_autologging_safety_unit.py:204:def test_safe_patch_propagates_exceptions_raised_from_original_function(
tests/autologging/test_autologging_safety_unit.py:232:def test_safe_patch_logs_exceptions_raised_outside_of_original_function_as_warnings(
tests/autologging/test_autologging_safety_unit.py:252:def test_safe_patch_propagates_exceptions_raised_outside_of_original_function_in_test_mode(
tests/autologging/test_autologging_safety_unit.py:268:def test_safe_patch_calls_original_function_when_patch_preamble_throws(
tests/autologging/test_autologging_safety_unit.py:343:def test_safe_patch_validates_arguments_to_original_function_in_test_mode(
tests/autologging/test_autologging_safety_unit.py:554:def test_safe_patch_provides_original_function_with_expected_signature(
tests/autologging/test_autologging_safety_unit.py:690:def test_safe_patch_makes_expected_event_logging_calls_when_original_function_throws(
tests/autologging/test_autologging_safety_unit.py:761:        def log_original_function_start(
tests/autologging/test_autologging_safety_unit.py:764:            super().log_original_function_start(
tests/autologging/test_autologging_safety_unit.py:769:        def log_original_function_success(
tests/autologging/test_autologging_safety_unit.py:772:            super().log_original_function_success(
tests/autologging/test_autologging_safety_unit.py:777:        def log_original_function_error(
tests/autologging/test_autologging_safety_unit.py:780:            super().log_original_function_error(
tests/autologging/test_autologging_safety_unit.py:1667:def test_safe_patch_preserves_original_function_attributes():
tests/autologging/test_autologging_safety_unit.py:1677:    flavor_name = "test_safe_patch_preserves_original_function_attributes"
tests/genai/scorers/test_scorer_CRUD.py:46:        assert scorers[0]._original_func.__name__ == "test_mlflow_scorer_v2"
tests/genai/scorers/test_scorer_CRUD.py:58:        assert retrieved_scorer_v1._original_func.__name__ == "test_mlflow_scorer_v1"
tests/genai/scorers/test_scorer_CRUD.py:63:        assert retrieved_scorer_v2._original_func.__name__ == "test_mlflow_scorer_v2"
tests/genai/scorers/test_scorer_CRUD.py:66:        assert retrieved_scorer_latest._original_func.__name__ == "test_mlflow_scorer_v2"
tests/genai/scorers/test_scorer_CRUD.py:72:        assert scorers_after_delete[0]._original_func.__name__ == "test_mlflow_scorer_v1"
tests/sklearn/test_sklearn_autolog.py:133:def test_autolog_preserves_original_function_attributes():
tests/sklearn/test_sklearn_autolog.py:140:        attrs["__signature__"] = inspect.signature(f)
mlflow/genai/scorers/validation.py:23:IS_DBX_AGENTS_INSTALLED = importlib.util.find_spec("databricks.agents") is not None
tests/genai/label_schemas/test_label_schemas.py:26:from mlflow.genai.scorers.validation import IS_DBX_AGENTS_INSTALLED
tests/genai/label_schemas/test_label_schemas.py:28:if not IS_DBX_AGENTS_INSTALLED:
tests/genai/conftest.py:11:from mlflow.genai.scorers.validation import IS_DBX_AGENTS_INSTALLED
tests/genai/conftest.py:26:    if request.param and not IS_DBX_AGENTS_INSTALLED:
tests/genai/conftest.py:32:        if not request.param and IS_DBX_AGENTS_INSTALLED:
tests/genai/conftest.py:50:        if not IS_DBX_AGENTS_INSTALLED:
tests/genai/evaluate/test_telemetry.py:16:from mlflow.genai.scorers.validation import IS_DBX_AGENTS_INSTALLED
tests/genai/evaluate/test_telemetry.py:19:if not IS_DBX_AGENTS_INSTALLED:
./mlflow/genai/scorers/__init__.py:36:    "get_all_scorers",
./mlflow/genai/scorers/__init__.py:77:        get_all_scorers,
./mlflow/genai/scorers/__init__.py:93:    "get_all_scorers",
./mlflow/genai/evaluation/base.py:361:            from mlflow.genai.scorers import get_all_scorers
./mlflow/genai/evaluation/base.py:385:                scorers=get_all_scorers(),
./mlflow/server/js/src/experiment-tracking/pages/experiment-evaluation-runs/RunEvaluationButton.tsx:30:  scorers=scorers.get_all_scorers()
./mlflow/cli/genai_eval_utils.py:12:from mlflow.genai.scorers import Scorer, get_all_scorers, get_scorer
./mlflow/cli/genai_eval_utils.py:121:    builtin_scorers = get_all_scorers()
./docs/api_reference/api_inventory.txt:862:mlflow.genai.scorers.get_all_scorers
./tests/genai/scorers/test_builtin_scorers.py:29:    get_all_scorers,
./tests/genai/scorers/test_builtin_scorers.py:570:def test_get_all_scorers_oss(tracking_uri):
./tests/genai/scorers/test_builtin_scorers.py:573:    scorers = get_all_scorers()
./tests/cli/test_genai_eval_utils.py:243:            "mlflow.cli.genai_eval_utils.get_all_scorers", return_value=[]
./tests/cli/test_genai_eval_utils.py:244:        ) as mock_get_all_scorers,
./tests/cli/test_genai_eval_utils.py:254:        mock_get_all_scorers.assert_called_once()
./tests/cli/test_genai_eval_utils.py:270:            "mlflow.cli.genai_eval_utils.get_all_scorers", return_value=[mock_builtin]
./tests/cli/test_genai_eval_utils.py:271:        ) as mock_get_all_scorers,
./tests/cli/test_genai_eval_utils.py:282:        mock_get_all_scorers.assert_called_once()
./tests/cli/test_genai_eval_utils.py:290:            "mlflow.cli.genai_eval_utils.get_all_scorers", return_value=[]
./tests/cli/test_genai_eval_utils.py:291:        ) as mock_get_all_scorers,
./tests/cli/test_genai_eval_utils.py:301:        mock_get_all_scorers.assert_called_once()
./mlflow/genai/scorers/builtin_scorers.py:327:            raise MissingColumnsException(self.name, missing_columns)
./mlflow/genai/scorers/builtin_scorers.py:541:            raise MissingColumnsException(
./mlflow/genai/scorers/builtin_scorers.py:914:            raise MissingColumnsException(self.name, ["expectations/guidelines"])
./mlflow/genai/scorers/builtin_scorers.py:1277:            raise MissingColumnsException(
./mlflow/genai/scorers/builtin_scorers.py:1445:            raise MissingColumnsException(self.name, {"expectations/expected_response"})
./mlflow/genai/scorers/builtin_scorers.py:1600:class MissingColumnsException(MlflowException):
./mlflow/genai/scorers/validation.py:8:from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any

from pydantic import BaseModel, Field

from mlflow.entities.trace import Trace
from mlflow.genai.judges.constants import _RATIONALE_FIELD_DESCRIPTION, _RESULT_FIELD_DESCRIPTION
from mlflow.genai.judges.utils import get_default_optimizer
from mlflow.genai.scorers.base import Scorer, ScorerKind
from mlflow.telemetry.events import AlignJudgeEvent
from mlflow.telemetry.track import record_usage_event
from mlflow.utils.annotations import experimental


@experimental(version="3.4.0")
class AlignmentOptimizer(ABC):
    """
    Abstract base class for judge alignment optimizers.

    Alignment optimizers improve judge accuracy by learning from traces
    that contain human feedback.
    """

    @abstractmethod
    def align(self, judge: Judge, traces: list[Trace]) -> Judge:
        """
        Align a judge using the provided traces.

        Args:
            judge: The judge to be optimized
            traces: List of traces containing alignment data (feedback)

        Returns:
            A new Judge instance that is better aligned with the input traces.
        """


class JudgeField(BaseModel):
    """
    Represents a field definition for judges with name and description.

    Used to define input and output fields for judge evaluation signatures.
    """

    name: str = Field(..., description="Name of the field")
    description: str = Field(..., description="Description of what the field represents")
    value_type: Any = Field(default=str, description="Type of the field's value")


@experimental(version="3.4.0")
class Judge(Scorer):
    """
    Base class for LLM-as-a-judge scorers that can be aligned with human feedback.

    Judges are specialized scorers that use LLMs to evaluate outputs based on
    configurable criteria and the results of human-provided feedback alignment.
    """

    @property
    def kind(self) -> ScorerKind:
        return ScorerKind.BUILTIN

    @property
    @abstractmethod
    def instructions(self) -> str:
        """
        Plain text instructions of what this judge evaluates.
        """

    @abstractmethod
    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for this judge.

        Returns:
            List of JudgeField objects defining the input fields.
        """

    @classmethod
    def get_output_fields(cls) -> list[JudgeField]:
        """
        Get the standard output fields used by all judges.
        This is the source of truth for judge output field definitions.

        Returns:
            List of JudgeField objects defining the standard output fields.
        """
        return [
            JudgeField(name="result", description=_RESULT_FIELD_DESCRIPTION, value_type=str),
            JudgeField(
                name="rationale",
                description=_RATIONALE_FIELD_DESCRIPTION,
                value_type=str,
            ),
        ]

    @experimental(version="3.4.0")
    @record_usage_event(AlignJudgeEvent)
    def align(self, traces: list[Trace], optimizer: AlignmentOptimizer | None = None) -> Judge:
        """
        Align this judge with human preferences using the provided optimizer and traces.

        Args:
            traces: Training traces for alignment
            optimizer: The alignment optimizer to use. If None, uses the default SIMBA optimizer.

        Returns:
            A new Judge instance that is better aligned with the input traces.

        Note on Logging:
            By default, alignment optimization shows minimal progress information.
            To see detailed optimization output, set the optimizer's logger to DEBUG::

                import logging

                # For SIMBA optimizer (default)
                logging.getLogger("mlflow.genai.judges.optimizers.simba").setLevel(logging.DEBUG)
        """
        if optimizer is None:
            optimizer = get_default_optimizer()
        return optimizer.align(self, traces)
from typing import TYPE_CHECKING

from mlflow.genai.scorers.base import Scorer, ScorerSamplingConfig, scorer
from mlflow.genai.scorers.registry import delete_scorer, get_scorer, list_scorers

# NB: We use lazy imports for builtin_scorers to avoid a circular dependency issue.
#
# The circular dependency chain:
# 1. scorers/__init__.py imports from builtin_scorers (if done eagerly)
# 2. builtin_scorers.py has `class BuiltInScorer(Judge)` which imports Judge from judges.base
# 3. judges.base.py has `class Judge(Scorer)` which imports Scorer from scorers.base
# 4. When importing scorers.base, Python first initializes the scorers package (__init__.py)
# 5. This would try to import builtin_scorers, creating a circular import
#
# Solution:
# - We use Python's __getattr__ mechanism to defer the import of builtin_scorers until
#   the specific scorer classes are actually accessed at runtime
# - The TYPE_CHECKING block provides type hints for IDEs and static analysis tools
#   without actually importing the modules at runtime (TYPE_CHECKING is only True
#   during static analysis, never during actual execution)
# - This allows Sphinx autodoc and IDEs to understand the module structure while
#   avoiding the circular import at runtime


# Define the attributes that should be lazily loaded
_LAZY_IMPORTS = {
    "Correctness",
    "ExpectationsGuidelines",
    "Guidelines",
    "Equivalence",
    "RelevanceToQuery",
    "RetrievalGroundedness",
    "RetrievalRelevance",
    "RetrievalSufficiency",
    "Safety",
    "get_all_scorers",
}


def __getattr__(name):
    """Lazily import builtin scorers to avoid circular dependency."""
    if name in _LAZY_IMPORTS:
        # Import the module when first accessed
        from mlflow.genai.scorers import builtin_scorers

        return getattr(builtin_scorers, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    """Return the list of attributes available in this module.

    This is necessary for Sphinx autodoc and other introspection tools
    to discover the lazily-loaded scorer classes.
    """
    # Get the default module attributes
    module_attrs = list(globals().keys())
    # Add the lazy imports
    return sorted(set(module_attrs) | _LAZY_IMPORTS)


# The TYPE_CHECKING block below is for static analysis tools only.
# TYPE_CHECKING is False at runtime, so these imports never execute during normal operation.
# This gives us the best of both worlds: type hints without circular imports.
if TYPE_CHECKING:
    from mlflow.genai.scorers.builtin_scorers import (
        Correctness,
        Equivalence,
        ExpectationsGuidelines,
        Guidelines,
        RelevanceToQuery,
        RetrievalGroundedness,
        RetrievalRelevance,
        RetrievalSufficiency,
        Safety,
        get_all_scorers,
    )

__all__ = [
    "Correctness",
    "ExpectationsGuidelines",
    "Guidelines",
    "Equivalence",
    "RelevanceToQuery",
    "RetrievalGroundedness",
    "RetrievalRelevance",
    "RetrievalSufficiency",
    "Safety",
    "Scorer",
    "scorer",
    "ScorerSamplingConfig",
    "get_all_scorers",
    "get_scorer",
    "list_scorers",
    "delete_scorer",
]
mlflow/genai/evaluation/telemetry.py:77:    # Check for the legacy custom metrics if databricks-agents is installed
mlflow/genai/evaluation/utils.py:218:def _convert_scorer_to_legacy_metric(scorer: Scorer) -> EvaluationMetric:
```

## 原始行 25 · command_execution

命令：
```
/bin/bash -lc "cat tests/genai/scorers/test_scorer_description.py; cat tests/genai/scorers/test_aggregation.py; sed -n '1,150p' tests/genai/scorers/test_serialization.py; python - <<'PY'
import importlib.util
print(importlib.util.find_spec('databricks.agents'))
if importlib.util.find_spec('databricks.agents'):
 import databricks.rag_eval.evaluation.metrics as m
 print(m, [x for x in dir(m) if x == 'Metric'])
 print(m.Metric)
PY
sed -n '60,115p' mlflow/genai/evaluation/telemetry.py; grep -R -n \"A scorer must\\|scorers must\\|scorer.*instance\\|get_all_scorers.*instead\" docs mlflow tests | head -200"
```

退出码：`0`

输出：
```
from unittest.mock import patch

import pytest

from mlflow.genai import scorer
from mlflow.genai.judges import make_judge
from mlflow.genai.judges.instructions_judge import InstructionsJudge
from mlflow.genai.scorers import RelevanceToQuery


@pytest.fixture(autouse=True)
def mock_databricks_runtime():
    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        yield


def test_decorator_scorer_with_description():
    description = "Checks if output length exceeds 100 characters"

    @scorer(description=description)
    def length_check(outputs) -> bool:
        return len(outputs) > 100

    assert length_check.description == description


def test_decorator_scorer_without_description():
    @scorer
    def simple_scorer(outputs) -> bool:
        return True

    assert simple_scorer.description is None


def test_decorator_scorer_with_name_and_description():
    description = "Custom description for scorer"

    @scorer(name="custom_name", description=description)
    def my_scorer(outputs) -> bool:
        return True

    assert my_scorer.name == "custom_name"
    assert my_scorer.description == description


def test_builtin_scorer_with_description():
    description = "Custom description for relevance scorer"
    scorer_instance = RelevanceToQuery(description=description)

    assert scorer_instance.description == description


def test_builtin_scorer_without_description():
    # Built-in scorers now have default descriptions for improved discoverability
    scorer_instance = RelevanceToQuery()

    assert scorer_instance.description is not None
    assert isinstance(scorer_instance.description, str)
    assert len(scorer_instance.description) > 0


@pytest.mark.parametrize(
    ("name", "description"),
    [
        ("test_judge", "Evaluates response quality"),
        ("another_judge", None),
        ("judge_with_desc", "This is a test description"),
    ],
)
def test_make_judge_with_description(name: str, description: str | None):
    judge = make_judge(
        name=name,
        instructions="Evaluate if {{ outputs }} is good quality",
        model="openai:/gpt-4",
        description=description,
        feedback_value_type=str,
    )

    assert judge.name == name
    assert judge.description == description


@pytest.mark.parametrize(
    "description",
    [
        "Direct InstructionsJudge with description",
        None,
    ],
)
def test_instructions_judge_description(description: str | None):
    judge = InstructionsJudge(
        name="test_judge",
        instructions="Evaluate {{ outputs }}",
        model="openai:/gpt-4",
        description=description,
    )

    assert judge.description == description


@pytest.mark.parametrize(
    "description",
    [
        "Test description for serialization",
        None,
    ],
)
def test_scorer_serialization(description: str | None):
    @scorer(description=description)
    def test_scorer(outputs) -> bool:
        return True

    serialized = test_scorer.model_dump()

    assert "description" in serialized
    assert serialized["description"] == description
    assert serialized["name"] == "test_scorer"


def test_scorer_deserialization_with_description():
    from mlflow.genai.scorers.base import Scorer

    description = "Test description for deserialization"

    @scorer(description=description)
    def test_scorer(outputs) -> bool:
        return True

    # Serialize and deserialize
    serialized = test_scorer.model_dump()
    deserialized = Scorer.model_validate(serialized)

    assert deserialized.description == description
    assert deserialized.name == "test_scorer"


def test_backward_compatibility_scorer_without_description():
    # Test decorator scorer - custom scorers still default to None
    @scorer
    def old_scorer(outputs) -> bool:
        return True

    assert old_scorer.description is None

    # Test builtin scorer - built-in scorers now have default descriptions
    builtin = RelevanceToQuery()
    assert builtin.description is not None
    assert isinstance(builtin.description, str)
    assert len(builtin.description) > 0

    # Test InstructionsJudge - custom judges still default to None
    judge = InstructionsJudge(
        name="old_judge",
        instructions="Evaluate {{ outputs }}",
        model="openai:/gpt-4",
    )
    assert judge.description is None
import pytest

from mlflow.entities.assessment import Feedback
from mlflow.genai.evaluation.entities import EvalItem, EvalResult
from mlflow.genai.judges.builtin import CategoricalRating
from mlflow.genai.scorers.aggregation import (
    _cast_assessment_value_to_float,
    compute_aggregated_metrics,
)
from mlflow.genai.scorers.base import Scorer

_EVAL_ITEM = EvalItem(
    request_id="dummy_request_id",
    inputs={"dummy_input": "dummy_input"},
    outputs="dummy_output",
    expectations={"dummy_expectation": "dummy_expectation"},
    tags={"test_tag": "test_value"},
    trace=None,
)


def test_compute_aggregated_metrics():
    scorer1 = Scorer(name="scorer1")  # Should default to ["mean"]
    scorer2 = Scorer(
        name="scorer2", aggregations=["mean", "min", "max", "median", "variance", "p90"]
    )

    eval_results = [
        EvalResult(
            eval_item=_EVAL_ITEM,
            assessments=[Feedback(name="scorer1", value=0.8), Feedback(name="scorer2", value=0.7)],
        ),
        EvalResult(
            eval_item=_EVAL_ITEM,
            assessments=[Feedback(name="scorer1", value=0.9)],
        ),
        EvalResult(
            eval_item=_EVAL_ITEM,
            assessments=[
                Feedback(name="scorer1", value=0.7),
                Feedback(name="scorer2", value=0.5),
                Feedback(name="scorer2", value=0.6),  # Multiple assessments from a scorer
            ],
        ),
        EvalResult(
            eval_item=_EVAL_ITEM,
            # Should filter out assessment without a value
            assessments=[Feedback(name="scorer1", error=Exception("Error"))],
        ),
    ]

    result = compute_aggregated_metrics(eval_results, [scorer1, scorer2])

    assert result["scorer1/mean"] == pytest.approx(0.8)
    assert result["scorer2/mean"] == pytest.approx(0.6)
    assert result["scorer2/min"] == pytest.approx(0.5)
    assert result["scorer2/max"] == pytest.approx(0.7)
    assert result["scorer2/median"] == pytest.approx(0.6)
    assert result["scorer2/variance"] == pytest.approx(0.00666666666)
    assert result["scorer2/p90"] == pytest.approx(0.68)


def test_compute_aggregated_metrics_custom_function():
    def custom_sum(x: list[float]) -> float:
        return sum(x)

    def custom_count(x: list[float]) -> float:
        return len(x)

    scorer = Scorer(name="scorer", aggregations=["mean", custom_sum, custom_count])
    eval_results = [
        EvalResult(eval_item=_EVAL_ITEM, assessments=[Feedback(name="scorer", value=0.8)]),
        EvalResult(eval_item=_EVAL_ITEM, assessments=[Feedback(name="scorer", value=0.9)]),
        EvalResult(eval_item=_EVAL_ITEM, assessments=[Feedback(name="scorer", value=0.7)]),
    ]
    result = compute_aggregated_metrics(eval_results, [scorer])

    assert result["scorer/mean"] == pytest.approx(0.8)
    assert result["scorer/custom_sum"] == pytest.approx(2.4)
    assert result["scorer/custom_count"] == pytest.approx(3)


def test_compute_aggregated_metrics_empty():
    scorer = Scorer(name="scorer", aggregations=["mean"])
    eval_results = []
    result = compute_aggregated_metrics(eval_results, [scorer])
    assert result == {}


def test_compute_aggregated_metrics_with_namespace():
    scorer = Scorer(name="scorer1", aggregations=["mean", "max"])
    eval_results = [
        EvalResult(eval_item=_EVAL_ITEM, assessments=[Feedback(name="foo/scorer1", value=1.0)]),
        EvalResult(eval_item=_EVAL_ITEM, assessments=[Feedback(name="foo/scorer1", value=2.0)]),
    ]

    result = compute_aggregated_metrics(eval_results, [scorer])
    assert result["foo/scorer1/mean"] == pytest.approx(1.5)
    assert result["foo/scorer1/max"] == pytest.approx(2.0)


@pytest.mark.parametrize(
    ("value", "expected_float"),
    [
        (5, 5.0),
        (3.14, 3.14),
        (True, 1.0),
        (False, 0.0),
        (CategoricalRating.YES, 1.0),
        (CategoricalRating.NO, 0.0),
        ("yes", 1.0),
        ("no", 0.0),
        # Case-insensitive
        ("Yes", 1.0),
        ("No", 0.0),
    ],
)
def test_cast_numeric_values(value, expected_float):
    assessment = Feedback(name="test", value=value)
    assert _cast_assessment_value_to_float(assessment) == expected_float
import json
from unittest.mock import patch

import pytest

from mlflow.entities import Feedback
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers import Scorer, scorer
from mlflow.genai.scorers.builtin_scorers import Guidelines


@pytest.fixture(autouse=True)
def mock_databricks_runtime():
    with patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True):
        yield


# ============================================================================
# FORMAT VALIDATION TESTS (Minimal - just check serialization structure)
# ============================================================================


def test_decorator_scorer_serialization_format():
    """Test that decorator scorers serialize with correct format."""

    @scorer(name="test_scorer", aggregations=["mean"])
    def test_scorer(outputs):
        return outputs == "correct"

    serialized = test_scorer.model_dump()

    # Check required fields for decorator scorers
    assert serialized["name"] == "test_scorer"
    assert serialized["aggregations"] == ["mean"]
    assert "call_source" in serialized
    assert "original_func_name" in serialized
    assert serialized["original_func_name"] == "test_scorer"
    assert "call_signature" in serialized

    # Check version metadata
    assert "mlflow_version" in serialized
    assert "serialization_version" in serialized
    assert serialized["serialization_version"] == 1

    # Builtin scorer fields should be None (not populated for decorator scorers)
    assert serialized["builtin_scorer_class"] is None
    assert serialized["builtin_scorer_pydantic_data"] is None


def test_builtin_scorer_serialization_format():
    """Test that builtin scorers serialize with correct format."""
    from mlflow.genai.scorers.builtin_scorers import RelevanceToQuery

    serialized = RelevanceToQuery().model_dump()

    # Check required top-level fields for builtin scorers
    assert serialized["name"] == "relevance_to_query"
    assert "builtin_scorer_class" in serialized
    assert serialized["builtin_scorer_class"] == "RelevanceToQuery"
    assert "builtin_scorer_pydantic_data" in serialized

    # Check fields within builtin_scorer_pydantic_data
    pydantic_data = serialized["builtin_scorer_pydantic_data"]
    assert "required_columns" in pydantic_data

    # Check version metadata
    assert "mlflow_version" in serialized
    assert "serialization_version" in serialized
    assert serialized["serialization_version"] == 1

    # Decorator scorer fields should be None (not populated for builtin scorers)
    assert serialized["call_source"] is None
    assert serialized["call_signature"] is None
    assert serialized["original_func_name"] is None


# ============================================================================
# ROUND-TRIP FUNCTIONALITY TESTS (Comprehensive - test complete cycles)
# ============================================================================


def test_simple_scorer_round_trip():
    """Test basic round-trip serialization and execution."""

    @scorer
    def simple_scorer(outputs):
        return outputs == "correct"

    # Test original functionality
    assert simple_scorer(outputs="correct") is True
    assert simple_scorer(outputs="wrong") is False

    # Serialize and deserialize
    serialized = simple_scorer.model_dump()
    deserialized = Scorer.model_validate(serialized)

    # Test deserialized functionality matches original
    assert deserialized.name == "simple_scorer"
    assert deserialized(outputs="correct") is True
    assert deserialized(outputs="wrong") is False


def test_custom_name_and_aggregations_round_trip():
    @scorer(name="length_check", aggregations=["mean", "max"])
    def my_scorer(inputs, outputs):
        return len(outputs) > len(inputs)

    # Test original
    assert my_scorer(inputs="hi", outputs="hello world") is True
    assert my_scorer(inputs="hello", outputs="hi") is False

    # Round-trip
    serialized = my_scorer.model_dump()
    deserialized = Scorer.model_validate(serialized)

    # Test preserved properties and functionality
    assert deserialized.name == "length_check"
    assert deserialized.aggregations == ["mean", "max"]
    assert deserialized(inputs="hi", outputs="hello world") is True
    assert deserialized(inputs="hello", outputs="hi") is False


def test_multiple_parameters_round_trip():
    @scorer
    def multi_param_scorer(inputs, outputs, expectations):
        return outputs.startswith(inputs) and len(outputs) > expectations.get("min_length", 0)

    # Test original
    test_args = {
        "inputs": "Hello",
        "outputs": "Hello world!",
        "expectations": {"min_length": 5},
    }
    assert multi_param_scorer(**test_args) is True

    # Round-trip
    serialized = multi_param_scorer.model_dump()
    deserialized = Scorer.model_validate(serialized)

    # Test functionality preserved
    assert deserialized(**test_args) is True
    assert (
        deserialized(inputs="Hi", outputs="Hello world!", expectations={"min_length": 5}) is False
    )


def test_complex_logic_round_trip():
    """Test round-trip with complex control flow and logic."""

    @scorer
None
        host_creds=get_databricks_host_creds(),
        endpoint=_EVAL_TELEMETRY_ENDPOINT,
        method="POST",
        headers={
            _CLIENT_VERSION_HEADER: VERSION,
            _SESSION_ID_HEADER: _get_or_create_session_id(),
            _BATCH_SIZE_HEADER: eval_count,
            _CLIENT_NAME_HEADER: "mlflow",
        },
        json_body=json.dumps(event_payload),
    )


def _is_custom_scorer(scorer: Scorer) -> bool:
    if isinstance(scorer, Scorer):
        return not isinstance(scorer, BuiltInScorer)

    # Check for the legacy custom metrics if databricks-agents is installed
    try:
        from databricks.rag_eval.evaluation.custom_metrics import CustomMetric

        return isinstance(scorer, CustomMetric)
    except ImportError:
        return False

    # Treat unknown case as not a custom scorer
    return False


def _get_or_create_session_id() -> str:
    if not hasattr(_sessions, _SESSION_KEY):
        setattr(_sessions, _SESSION_KEY, str(uuid.uuid4()))
    return getattr(_sessions, _SESSION_KEY)


def _hash_metric_name(metric_name: str) -> str:
    """Hash metric name in un-recoverable way to avoid leaking sensitive information"""
    return hashlib.sha256(metric_name.encode("utf-8")).hexdigest()
mlflow/genai/scorers/base.py:363:        scorer_instance = scorer(
mlflow/genai/scorers/base.py:371:        object.__setattr__(scorer_instance, "_cached_dump", original_serialized_data)
mlflow/genai/scorers/base.py:372:        return scorer_instance
mlflow/genai/scorers/base.py:574:        # Create a new scorer instance
mlflow/genai/scorers/base.py:794:        Create a copy of this scorer instance.
mlflow/genai/scorers/registry.py:402:# Create the global scorer store registry instance
mlflow/genai/evaluation/base.py:247:    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
mlflow/genai/evaluation/utils.py:276:    metric_instance._is_builtin_scorer = isinstance(scorer, BuiltInScorer)
mlflow/genai/optimize/util.py:90:    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
mlflow/telemetry/events.py:81:        builtin_scorers = {scorer.name for scorer in scorers if isinstance(scorer, BuiltInScorer)}
mlflow/entities/scorer.py:25:        scorer_version (int): The version number of this scorer instance.
mlflow/entities/scorer.py:88:        The version number of this scorer instance.
tests/genai/scorers/test_scorer_description.py:48:    scorer_instance = RelevanceToQuery(description=description)
tests/genai/scorers/test_scorer_description.py:50:    assert scorer_instance.description == description
tests/genai/scorers/test_scorer_description.py:55:    scorer_instance = RelevanceToQuery()
tests/genai/scorers/test_scorer_description.py:57:    assert scorer_instance.description is not None
tests/genai/scorers/test_scorer_description.py:58:    assert isinstance(scorer_instance.description, str)
tests/genai/scorers/test_scorer_description.py:59:    assert len(scorer_instance.description) > 0
tests/genai/evaluate/test_utils.py:498:    custom_scorer_instance = custom_scorer_func
tests/genai/evaluate/test_utils.py:499:    legacy_metric_custom = _convert_scorer_to_legacy_metric(custom_scorer_instance)
tests/genai/evaluate/test_utils.py:504:    assert legacy_metric_custom.name == custom_scorer_instance.name
tests/genai/evaluate/test_utils.py:505:    assert legacy_metric_custom.aggregations == custom_scorer_instance.aggregations
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' mlflow/genai/scorers/aggregation.py; grep -R -n \"Scorer function.*parameters\\|supported parameters\\|unexpected parameters\\|must only.*inputs\\|only supports.*inputs\" tests docs mlflow | head -150; find . -name 'AGENTS.md' -print"
```

退出码：`0`

输出：
```
"""Generate the metrics logged into MLflow."""

import collections
import logging

import numpy as np

from mlflow.entities.assessment import Feedback
from mlflow.genai.evaluation.entities import EvalResult
from mlflow.genai.judges.builtin import CategoricalRating
from mlflow.genai.scorers.base import AggregationFunc, Scorer

_logger = logging.getLogger(__name__)


_AGGREGATE_FUNCTIONS = {
    "min": np.min,
    "max": np.max,
    "mean": np.mean,
    "median": np.median,
    "variance": np.var,
    "p90": lambda x: np.percentile(x, 90) if x else None,
}


def compute_aggregated_metrics(
    eval_results: list[EvalResult],
    scorers: list[Scorer],
) -> dict[str, float]:
    """
    Generates the aggregated per-run metrics from the evaluation result for each row.

    Args:
        eval_results: List of EvalResult objects
        scorers: List of scorers

    Returns:
        Dictionary of aggregated metrics (metric name -> aggregated value)
    """
    # Collect assessment values in a flat dictionary
    assessment_values: dict[str, list[float]] = collections.defaultdict(list)
    for eval_result in eval_results:
        for assessment in eval_result.assessments:
            if isinstance(assessment, Feedback):
                value = _cast_assessment_value_to_float(assessment)
                if value is not None:  # Exclude None from aggregation
                    assessment_values[assessment.name].append(value)

    # List all aggregations to compute for each scorer
    scorer_aggregations = {}
    for scorer in scorers:
        if scorer.aggregations is not None:
            scorer_aggregations[scorer.name] = scorer.aggregations
        else:
            scorer_aggregations[scorer.name] = ["mean"]  # default to compute mean only

    # Compute aggregates
    result = {}
    for name, values in assessment_values.items():
        if not values:
            continue

        # Get the function name from the returned assessment name.
        scorer_function_name = name.split("/", 1)[-1]

        # Compute aggregations for the scorer, defaulting to just ["mean"]
        aggregations_to_compute = scorer_aggregations.get(scorer_function_name, ["mean"])
        aggregation_results = _compute_aggregations(values, aggregations_to_compute)

        # Each aggregation should be logged as a separate metric
        for agg_name, agg_value in aggregation_results.items():
            result[f"{name}/{agg_name}"] = agg_value

    return result


def _cast_assessment_value_to_float(assessment: Feedback) -> float | None:
    """Cast the value of an assessment to a float."""
    if isinstance(assessment.value, (int, float, bool)):
        return float(assessment.value)
    elif (
        isinstance(assessment.value, str)
        and CategoricalRating(assessment.value.lower()) != CategoricalRating.UNKNOWN
    ):
        return float(assessment.value.lower() == CategoricalRating.YES)


def _compute_aggregations(
    scores: list[float], aggregations: list[str | AggregationFunc]
) -> dict[str, float]:
    """Compute aggregate statistics for a list of scores based on specified aggregations.

    Args:
        scores: List of numeric scores to aggregate
        aggregations: List of aggregation types to compute (e.g. ["min", "max", "mean"])

    Returns:
        Dictionary mapping aggregation names to computed values
    """
    results = {}
    for aggregation in aggregations:
        # Aggregations specified as strings, e.g., "mean"
        if isinstance(aggregation, str):
            if aggregation not in _AGGREGATE_FUNCTIONS:
                raise ValueError(f"Invalid aggregation: {aggregation}")
            results[aggregation] = _AGGREGATE_FUNCTIONS[aggregation](scores)
        # Aggregations specified as a custom function.
        else:
            try:
                results[aggregation.__name__] = aggregation(scores)
            except Exception as e:
                _logger.error(f"Error computing aggregation {aggregation} due to: {e}")
                continue

    return results
docs/docs/genai/flavors/chat-model-intro/index.mdx:338:You can find the full list of supported parameters <APILink fn="mlflow.types.llm.ChatParams">here</APILink>.
mlflow/sagemaker/__init__.py:1104:        config: Configuration parameters. The supported parameters are:
mlflow/sagemaker/__init__.py:2175:            config: Configuration parameters. The supported parameters are:
mlflow/sagemaker/__init__.py:2391:            config: Configuration parameters. The supported parameters are:
mlflow/sagemaker/__init__.py:2627:            config: Configuration parameters. The supported parameters are:
./mlflow/server/AGENTS.md
```

## 原始行 31 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/genai/scorers/validation.py | sed -n '1,260p'; grep -R -n \"expected_retrieved_context\\|custom_expected\\|expected_facts\\|guidelines\" mlflow/genai/evaluation | head -150; sed -n '1,100p' mlflow/genai/evaluation/constant.py; grep -R -n \"The following columns are required\\|will be skipped\\|missing columns\" mlflow/genai | head -100; grep -R -n \"INVALID_PARAMETER_VALUE\" mlflow/genai/scorers tests/genai | head -100"
```

退出码：`0`

输出：
```
     1	import importlib
     2	import logging
     3	from collections import defaultdict
     4	from typing import Any, Callable
     5	
     6	from mlflow.exceptions import MlflowException
     7	from mlflow.genai.scorers.base import AggregationFunc, Scorer
     8	from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException
     9	
    10	
    11	
    12	
    13	
    14	try:
    15	    # `pandas` is not required for `mlflow-skinny`.
    16	    import pandas as pd
    17	except ImportError:
    18	    pass
    19	
    20	_logger = logging.getLogger(__name__)
    21	
    22	
    23	IS_DBX_AGENTS_INSTALLED = importlib.util.find_spec("databricks.agents") is not None
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	def validate_aggregations(aggregations: list[str | AggregationFunc] | None) -> None:
   178	    """
   179	    Validate that aggregations are either valid string names or callable functions.
   180	
   181	    Args:
   182	        aggregations: List of aggregation functions to validate. Can be strings from
   183	                     the standard set or callable functions.
   184	    """
   185	    if not aggregations:
   186	        return
   187	
   188	    from mlflow.genai.scorers.aggregation import _AGGREGATE_FUNCTIONS
   189	
   190	    valid_aggregation_names = set(_AGGREGATE_FUNCTIONS.keys())
   191	
   192	    for agg in aggregations:
   193	        if isinstance(agg, str):
   194	            if agg not in valid_aggregation_names:
   195	                raise MlflowException.invalid_parameter_value(
   196	                    f"Invalid aggregation '{agg}'. Valid aggregations are: "
   197	                    f"{sorted(valid_aggregation_names)}"
   198	                )
   199	        elif not callable(agg):
   200	            raise MlflowException.invalid_parameter_value(
   201	                f"Aggregation must be either a string from {sorted(valid_aggregation_names)} "
   202	                f"or a callable function, got {type(agg).__name__}"
   203	            )
mlflow/genai/evaluation/utils.py:154:                    "values. For example, `{'expected_facts': ['fact1', 'fact2']}`"
mlflow/genai/evaluation/utils.py:240:        guidelines: list[str] | dict[str, list[str]] | None,
mlflow/genai/evaluation/utils.py:241:        expected_facts: list[str] | None,
mlflow/genai/evaluation/utils.py:242:        expected_retrieved_context: list[dict[str, str]] | None,
mlflow/genai/evaluation/utils.py:243:        custom_expected: dict[str, Any] | None,
mlflow/genai/evaluation/utils.py:250:        if expected_facts is not None:
mlflow/genai/evaluation/utils.py:251:            expectations[AgentEvaluationReserverKey.EXPECTED_FACTS] = expected_facts
mlflow/genai/evaluation/utils.py:252:        if expected_retrieved_context is not None:
mlflow/genai/evaluation/utils.py:254:                expected_retrieved_context
mlflow/genai/evaluation/utils.py:256:        if guidelines is not None:
mlflow/genai/evaluation/utils.py:257:            expectations[AgentEvaluationReserverKey.GUIDELINES] = guidelines
mlflow/genai/evaluation/utils.py:258:        if custom_expected is not None:
mlflow/genai/evaluation/utils.py:259:            expectations.update(custom_expected)
mlflow/genai/evaluation/constant.py:8:    EXPECTED_RETRIEVED_CONTEXT = "expected_retrieved_context"
mlflow/genai/evaluation/constant.py:9:    EXPECTED_FACTS = "expected_facts"
mlflow/genai/evaluation/constant.py:10:    GUIDELINES = "guidelines"
mlflow/genai/evaluation/constant.py:23:AGENT_EVAL_CUSTOM_EXPECTATION_KEY = "custom_expected"
class AgentEvaluationReserverKey:
    """
    Expectation column names that are used by Agent Evaluation.
    Ref: https://docs.databricks.com/aws/en/generative-ai/agent-evaluation/evaluation-schema
    """

    EXPECTED_RESPONSE = "expected_response"
    EXPECTED_RETRIEVED_CONTEXT = "expected_retrieved_context"
    EXPECTED_FACTS = "expected_facts"
    GUIDELINES = "guidelines"

    @classmethod
    def get_all(cls) -> set[str]:
        return {
            cls.EXPECTED_RESPONSE,
            cls.EXPECTED_RETRIEVED_CONTEXT,
            cls.EXPECTED_FACTS,
            cls.GUIDELINES,
        }


# A column name for storing custom expectations dictionary in Agent Evaluation.
AGENT_EVAL_CUSTOM_EXPECTATION_KEY = "custom_expected"


# Input dataset column names
class InputDatasetColumn:
    REQUEST_ID = "request_id"
    INPUTS = "inputs"
    REQUEST = "request"
    RESPONSE = "response"
    OUTPUTS = "outputs"
    EXPECTATIONS = "expectations"
    TAGS = "tags"
    TRACE = "trace"


# Result Dataframe column names
class ResultDataFrameColumn:
    REQUEST_ID = "request_id"
    INPUTS = "inputs"
    OUTPUTS = "outputs"
    EXPECTATIONS = "expectations"
    TAGS = "tags"
    TRACE = "trace"
    ERROR_MESSAGE = "error_message"
mlflow/genai/scorers/builtin_scorers.py:1605:            f"The following columns are required for the scorer {scorer}: {missing_columns}"
mlflow/genai/scorers/scorer_utils.py:10:from mlflow.exceptions import INVALID_PARAMETER_VALUE, MlflowException
mlflow/genai/scorers/scorer_utils.py:95:            f"Invalid signature format: '{signature}'", error_code=INVALID_PARAMETER_VALUE
tests/genai/judges/test_judge_tool_get_traces_in_session.py:12:from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE, ErrorCode
tests/genai/judges/test_judge_tool_get_traces_in_session.py:138:    assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)
tests/genai/judges/test_judge_tool_get_traces_in_session.py:148:    assert exc_info.value.error_code == ErrorCode.Name(INVALID_PARAMETER_VALUE)
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def evaluate(\" -A30 mlflow/genai/evaluation/base.py; sed -n '1,115p' mlflow/genai/evaluation/base.py; grep -R -n \"scorers=.*None\\|scorers:.*None\" mlflow/genai | head -50; sed -n '730,940p' mlflow/genai/scorers/builtin_scorers.py; sed -n '1080,1215p' mlflow/genai/scorers/builtin_scorers.py"
```

退出码：`0`

输出：
```
51:def evaluate(
52-    data: "EvaluationDatasetTypes",
53-    scorers: list[Scorer],
54-    predict_fn: Callable[..., Any] | None = None,
55-    model_id: str | None = None,
56-) -> EvaluationResult:
57-    """
58-    Evaluate the performance of a generative AI model/application using specified
59-    data and scorers.
60-
61-    This function allows you to evaluate a model's performance on a given dataset
62-    using various scoring criteria. It supports both built-in scorers provided by
63-    MLflow and custom scorers. The evaluation results include metrics and detailed
64-    per-row assessments.
65-
66-    There are three different ways to use this function:
67-
68-    **1. Use Traces to evaluate the model/application.**
69-
70-    The `data` parameter takes a DataFrame with `trace` column, which contains a
71-    single trace object corresponding to the prediction for the row. This dataframe
72-    is easily obtained from the existing traces stored in MLflow, by using the
73-    :py:func:`mlflow.search_traces` function.
74-
75-    .. code-block:: python
76-
77-        import mlflow
78-        from mlflow.genai.scorers import Correctness, Safety
79-        import pandas as pd
80-
81-        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"
import logging
import os
import time
from contextlib import nullcontext
from typing import TYPE_CHECKING, Any, Callable

import mlflow
from mlflow.data.dataset import Dataset
from mlflow.entities.dataset_input import DatasetInput
from mlflow.entities.evaluation_dataset import EvaluationDataset as EntityEvaluationDataset
from mlflow.entities.logged_model_input import LoggedModelInput
from mlflow.environment_variables import MLFLOW_GENAI_EVAL_MAX_WORKERS
from mlflow.exceptions import MlflowException
from mlflow.genai.datasets.evaluation_dataset import EvaluationDataset
from mlflow.genai.evaluation.constant import InputDatasetColumn
from mlflow.genai.evaluation.utils import (
    _convert_to_eval_set,
)
from mlflow.genai.scorers import Scorer
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer

from mlflow.genai.utils.display_utils import display_evaluation_output
from mlflow.genai.utils.trace_utils import convert_predict_fn
from mlflow.models.evaluation.base import (
    EvaluationResult,
    _is_model_deployment_endpoint_uri,
    _start_run_or_reuse_active_run,
)
from mlflow.models.evaluation.utils.trace import configure_autologging_for_evaluation
from mlflow.telemetry.events import GenAIEvaluateEvent
from mlflow.telemetry.track import record_usage_event
from mlflow.tracing.constant import (
    DATABRICKS_OPTIONS_KEY,
    DATABRICKS_OUTPUT_KEY,
    RETURN_TRACE_OPTION_KEY,
)
from mlflow.tracing.utils.copy import copy_trace_to_experiment
from mlflow.tracking.client import MlflowClient
from mlflow.tracking.fluent import _get_experiment_id, _set_active_model
from mlflow.utils.annotations import experimental
from mlflow.utils.mlflow_tags import MLFLOW_RUN_IS_EVALUATION

if TYPE_CHECKING:
    from mlflow.genai.evaluation.utils import EvaluationDatasetTypes


logger = logging.getLogger(__name__)


@experimental(version="3.0.0")
def evaluate(
    data: "EvaluationDatasetTypes",
    scorers: list[Scorer],
    predict_fn: Callable[..., Any] | None = None,
    model_id: str | None = None,
) -> EvaluationResult:
    """
    Evaluate the performance of a generative AI model/application using specified
    data and scorers.

    This function allows you to evaluate a model's performance on a given dataset
    using various scoring criteria. It supports both built-in scorers provided by
    MLflow and custom scorers. The evaluation results include metrics and detailed
    per-row assessments.

    There are three different ways to use this function:

    **1. Use Traces to evaluate the model/application.**

    The `data` parameter takes a DataFrame with `trace` column, which contains a
    single trace object corresponding to the prediction for the row. This dataframe
    is easily obtained from the existing traces stored in MLflow, by using the
    :py:func:`mlflow.search_traces` function.

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Correctness, Safety
        import pandas as pd

        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"
        trace_df = mlflow.search_traces(model_id="<my-model-id>")

        mlflow.genai.evaluate(
            data=trace_df,
            scorers=[Correctness(), Safety()],
        )

    Built-in scorers will understand the model inputs, outputs, and other intermediate
    information e.g. retrieved context, from the trace object. You can also access to
    the trace object from the custom scorer function by using the `trace` parameter.

    .. code-block:: python

        from mlflow.genai.scorers import scorer


        @scorer
        def faster_than_one_second(inputs, outputs, trace):
            return trace.info.execution_duration < 1000

    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**

    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as
    a column in the dataframe (or equivalent list of dictionaries).

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Correctness
        import pandas as pd

        data = pd.DataFrame(
            [
                {
mlflow/genai/evaluation/harness.py:56:    scorers=None,
mlflow/genai/evaluation/telemetry.py:27:    scorers: list[Scorer], eval_count: int | None, aggregated_metrics: dict[str, float]
mlflow/genai/optimize/util.py:71:    train_data: "pd.DataFrame", scorers: list[Scorer], predict_fn: Callable[..., Any] | None = None
        clarify = Guidelines(
            name="clarify",
            guidelines=["The response must be clear, coherent, and concise"],
        )

        data = [
            {
                "inputs": {"question": "What is the capital of France?"},
                "outputs": "The capital of France is Paris.",
            },
            {
                "inputs": {"question": "What is the capital of Germany?"},
                "outputs": "The capital of Germany is Berlin.",
            },
        ]
        mlflow.genai.evaluate(data=data, scorers=[english, clarify])
    """

    name: str = "guidelines"
    guidelines: str | list[str]
    model: str | None = None
    required_columns: set[str] = {"inputs", "outputs"}
    description: str = (
        "Evaluate whether the agent's response follows specific constraints or instructions "
        "provided in the guidelines."
    )

    @property
    def instructions(self) -> str:
        """Get the instructions of what this scorer evaluates."""
        return GUIDELINES_PROMPT_INSTRUCTIONS

    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for the Guidelines judge.

        Returns:
            List of JudgeField objects defining the input fields based on the __call__ method.
        """
        return [
            JudgeField(
                name="inputs",
                description=(
                    "A dictionary of input data, e.g. "
                    "{'question': 'What is the capital of France?'}."
                ),
            ),
            JudgeField(
                name="outputs",
                description="The response from the model, e.g. 'The capital of France is Paris.'",
            ),
        ]

    def __call__(
        self,
        *,
        inputs: dict[str, Any] | None = None,
        outputs: Any | None = None,
        trace: Trace | None = None,
    ) -> Feedback:
        """
        Evaluate adherence to specified guidelines.

        This scorer can be used in two ways:
        1. Pass an MLflow trace object to automatically extract
           and evaluate the inputs and outputs from the trace.
        2. Directly provide the inputs and outputs to evaluate.

        Args:
            inputs: A dictionary of input data, e.g. {"question": "What is the capital of France?"}.
                Optional when trace is provided.
            outputs: The response from the model, e.g. "The capital of France is Paris."
                Optional when trace is provided.
            trace: MLflow trace object containing the execution to evaluate. When provided,
                inputs and outputs will be automatically extracted from the trace.

        Returns:
            An :py:class:`mlflow.entities.assessment.Feedback~` object with a boolean value
            indicating the adherence to the specified guidelines.
        """
        fields = resolve_scorer_fields(trace, self, inputs, outputs, model=self.model)
        _validate_required_fields(fields, self, "Guidelines scorer")

        feedback = judges.meets_guidelines(
            guidelines=self.guidelines,
            context={
                "request": parse_inputs_to_str(fields.inputs),
                "response": parse_outputs_to_str(fields.outputs),
            },
            name=self.name,
            model=self.model,
        )
        return _sanitize_scorer_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
class ExpectationsGuidelines(BuiltInScorer):
    """
    This scorer evaluates whether the agent's response follows specific constraints
    or instructions provided for each row in the input dataset. This scorer is useful when
    you have a different set of guidelines for each example.

    To use this scorer, the input dataset should contain the `expectations` column with the
    `guidelines` field. Then pass this scorer to `mlflow.genai.evaluate` for running full
    evaluation on the input dataset.

    Args:
        name: The name of the scorer. Defaults to "expectations_guidelines".
        model: {{ model }}

    Example:

    In this example, the guidelines specified in the `guidelines` field of the `expectations`
    column will be applied to each example individually. The evaluation result will contain a
    single "expectations_guidelines" score.

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import ExpectationsGuidelines

        data = [
            {
                "inputs": {"question": "What is the capital of France?"},
                "outputs": "The capital of France is Paris.",
                "expectations": {
                    "guidelines": ["The response must be factual and concise"],
                },
            },
            {
                "inputs": {"question": "How to learn Python?"},
                "outputs": "You can read a book or take a course.",
                "expectations": {
                    "guidelines": ["The response must be helpful and encouraging"],
                },
            },
        ]
        mlflow.genai.evaluate(data=data, scorers=[ExpectationsGuidelines()])
    """

    name: str = "expectations_guidelines"
    model: str | None = None
    required_columns: set[str] = {"inputs", "outputs"}
    description: str = (
        "Evaluate whether the agent's response follows specific constraints or instructions "
        "provided for each row in the input dataset."
    )

    @property
    def instructions(self) -> str:
        """Get the instructions of what this scorer evaluates."""
        return "Evaluates adherence to per-example guidelines provided in the expectations column."

    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for the ExpectationsGuidelines judge.

        Returns:
            List of JudgeField objects defining the input fields based on the __call__ method.
        """
        return [
            JudgeField(
                name="inputs",
                description=(
                    "A dictionary of input data, e.g. "
                    "{'question': 'What is the capital of France?'}."
                ),
            ),
            JudgeField(
                name="outputs",
                description="The response from the model, e.g. 'The capital of France is Paris.'",
            ),
            JudgeField(
                name="expectations",
                description=(
                    "A dictionary containing guidelines for evaluation. "
                    "Must contain a 'guidelines' key (optional)."
                ),
            ),
        ]

    def validate_columns(self, columns: set[str]) -> None:
        super().validate_columns(columns)
        if "expectations/guidelines" not in columns:
            raise MissingColumnsException(self.name, ["expectations/guidelines"])

    def __call__(
        self,
        *,
        inputs: dict[str, Any] | None = None,
        outputs: Any | None = None,
        expectations: dict[str, Any] | None = None,
        trace: Trace | None = None,
    ) -> Feedback:
        """
        Evaluate adherence to specified guidelines.

        This scorer can be used in two ways:
        1. Pass an MLflow trace object to automatically extract
           and evaluate inputs, outputs, and expectations from the trace.
        2. Directly provide the inputs, outputs, and expectations to evaluate.

        Args:
            inputs: A dictionary of input data, e.g. {"question": "What is the capital of France?"}.
                Optional when trace is provided.
            outputs: The response from the model, e.g. "The capital of France is Paris."
                Optional when trace is provided.
            expectations: A dictionary of expectations for the response. This must contain either
                `guidelines` key, which is used to evaluate the response against the guidelines
                specified in the `guidelines` field of the `expectations` column of the dataset.
                E.g., {"guidelines": ["The response must be factual and concise"]}
            indicating the relevance of the response to the query.
        """
        fields = resolve_scorer_fields(trace, self, inputs, outputs, model=self.model)
        _validate_required_fields(fields, self, "RelevanceToQuery scorer")

        # Use the existing scorer implementation with extracted/provided fields
        request = parse_inputs_to_str(fields.inputs)
        feedback = judges.is_context_relevant(
            request=request, context=fields.outputs, name=self.name, model=self.model
        )
        return _sanitize_scorer_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
class Safety(BuiltInScorer):
    """
    Safety ensures that the agent's responses do not contain harmful, offensive, or toxic content.

    You can invoke the scorer directly with a single input for testing, or pass it to
    `mlflow.genai.evaluate` for running full evaluation on a dataset.

    Args:
        name: The name of the scorer. Defaults to "safety".
        model: {{ model }}

    Example (direct usage):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Safety

        assessment = Safety(name="my_safety")(outputs="The capital of France is Paris.")
        print(assessment)

    Example (with evaluate):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Safety

        data = [
            {
                "inputs": {"question": "What is the capital of France?"},
                "outputs": "The capital of France is Paris.",
            }
        ]
        result = mlflow.genai.evaluate(data=data, scorers=[Safety()])
    """

    name: str = "safety"
    model: str | None = None
    required_columns: set[str] = {"inputs", "outputs"}
    description: str = (
        "Ensure that the agent's responses do not contain harmful, offensive, or toxic content."
    )

    @property
    def instructions(self) -> str:
        """Get the instructions of what this scorer evaluates."""
        return "Ensures responses do not contain harmful, offensive, or toxic content."

    def get_input_fields(self) -> list[JudgeField]:
        """
        Get the input fields for the Safety judge.

        Returns:
            List of JudgeField objects defining the input fields based on the __call__ method.
        """
        return [
            JudgeField(
                name="outputs",
                description="The response from the model, e.g. 'The capital of France is Paris.'",
            ),
        ]

    def __init__(self, /, **kwargs):
        super().__init__(**kwargs)

    def __call__(
        self,
        *,
        outputs: Any | None = None,
        trace: Trace | None = None,
    ) -> Feedback:
        """
        Evaluate safety of the response.

        This scorer can be used in two ways:
        1. Pass an MLflow trace object to automatically extract
           and evaluate the outputs from the trace.
        2. Directly provide the outputs to evaluate.

        Args:
            outputs: The response from the model, e.g. "The capital of France is Paris."
                Optional when trace is provided.
            trace: MLflow trace object containing the execution to evaluate. When provided,
                outputs will be automatically extracted from the trace.

        Returns:
            An :py:class:`mlflow.entities.assessment.Feedback~` object with a boolean value
            indicating the safety of the response.
        """
        fields = resolve_scorer_fields(trace, self, outputs=outputs, model=self.model)
        _validate_required_fields(fields, self, "Safety scorer")

        feedback = judges.is_safe(
            content=parse_outputs_to_str(fields.outputs),
            name=self.name,
            model=self.model,
        )
        return _sanitize_scorer_feedback(feedback)


@format_docstring(_MODEL_API_DOC)
class Correctness(BuiltInScorer):
    """
    Correctness ensures that the agent's responses are correct and accurate.

    You can invoke the scorer directly with a single input for testing, or pass it to
    `mlflow.genai.evaluate` for running full evaluation on a dataset.

    Args:
        name: The name of the scorer. Defaults to "correctness".
        model: {{ model }}

    Example (direct usage):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import Correctness

        assessment = Correctness(name="my_correctness")(
            inputs={
```

## 原始行 37 · command_execution

命令：
```
/bin/bash -lc 'grep -n "''^version'"\\|__version__\" pyproject.toml mlflow/version.py | head; grep -R -n \"defaultdict(list)\" mlflow/genai mlflow | head -50; grep -R -n \"cannot be computed\\|will return null\\|will be null\\|missing.*scorer\" mlflow/genai tests/genai | head -100; grep -R -n \"get_all_scorers\" docs | head -50; grep -R -n \"valid_data_for_builtin_scorers\" . --exclude-dir=.git --exclude='*.pyc'"
```

退出码：`0`

输出：
```
pyproject.toml:12:version = "3.6.1.dev0"
mlflow/genai/judges/tools/get_span_performance_and_timing_report.py:129:        children_by_parent = defaultdict(list)
mlflow/genai/scorers/aggregation.py:41:    assessment_values: dict[str, list[float]] = collections.defaultdict(list)
mlflow/dspy/util.py:61:    result = defaultdict(list)
mlflow/tracing/client.py:440:        trace_infos_by_location = defaultdict(list)
mlflow/tracing/utils/__init__.py:187:    children_map: defaultdict[str, list[LiveSpan]] = defaultdict(list)
mlflow/tracing/export/mlflow_v3.py:107:        spans_by_experiment = defaultdict(list)
mlflow/genai/judges/tools/get_span_performance_and_timing_report.py:129:        children_by_parent = defaultdict(list)
mlflow/genai/scorers/aggregation.py:41:    assessment_values: dict[str, list[float]] = collections.defaultdict(list)
mlflow/server/otel_api.py:101:    spans_by_trace_id = defaultdict(list)
mlflow/utils/proto_json_utils.py:582:        data_dict = defaultdict(list)
mlflow/types/utils.py:328:        col_data_mapping = defaultdict(list)
mlflow/pyspark/ml/__init__.py:450:    result_dict = defaultdict(list)
mlflow/pyspark/ml/__init__.py:567:        self._eval_dataset_info_map = defaultdict(lambda: defaultdict(list))
mlflow/pyspark/ml/__init__.py:568:        self._evaluator_call_info = defaultdict(lambda: defaultdict(list))
mlflow/sklearn/__init__.py:711:        self._eval_dataset_info_map = defaultdict(lambda: defaultdict(list))
mlflow/sklearn/__init__.py:712:        self._metric_api_call_info = defaultdict(lambda: defaultdict(list))
mlflow/system_metrics/metrics/base_metrics_monitor.py:11:        self._metrics = defaultdict(list)
mlflow/store/tracking/sqlalchemy_store.py:1859:        outputs_per_run = defaultdict(list)
mlflow/store/tracking/file_store.py:2517:        grouped_metrics = defaultdict(list)
mlflow/store/tracking/databricks_rest_store.py:645:        traces_by_location: dict[str | None, list[str]] = defaultdict(list)
tests/genai/evaluate/test_evaluation.py:648:def test_missing_scorers_argument():
docs/api_reference/api_inventory.txt:862:mlflow.genai.scorers.get_all_scorers
./mlflow/genai/evaluation/base.py:248:    valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)
./mlflow/genai/optimize/util.py:91:    valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc "sed -n '945,1015l' mlflow/genai/scorers/base.py; sed -n '15,190l' mlflow/genai/scorers/validation.py | tail -30; sed -n '1560,1610l' mlflow/genai/scorers/builtin_scorers.py"
```

退出码：`0`

输出：
```
$
            @scorer$
            def num_tool_calls(trace) -> int:$
                spans = trace.search_spans(name="tool_call")$
                return len(spans)$
$
$
            # Use `Feedback` object to return additional information \
about the scorer's$
            # result, such as a rationale for the score.$
            @scorer$
            def harmfulness(outputs) -> Feedback:$
                import openai$
$
                prompt = f'''$
                    Judge if the following text is harmful or not.$
$
                    Text:$
                    {outputs}$
$
                    Return the answer in a JSON object with the follo\
wing format:$
                    {{$
                        "harmful": true$
                        "reason": "The text contains harmful content"$
                    }}$
$
                    Do not output any other characters than the json \
object.$
                '''$
                response = openai.OpenAI().chat.completions.create($
                    model="o4-mini",$
                    messages=[{"role": "user", "content": prompt}],$
                )$
                payload = json.loads(response.choices[0].message.cont\
ent)$
                return Feedback($
                    value=payload["harmful"],$
                    rationale=payload["reason"],$
                    source=AssessmentSource($
                        source_type="LLM_JUDGE",$
                        source_id="openai:/o4-mini",$
                    ),$
                )$
$
$
            # Use the scorer in an evaluation$
            mlflow.genai.evaluate($
                data=data,$
                scorers=[not_empty, exact_match, num_tool_calls, harm\
fulness],$
            )$
    """$
$
    if func is None:$
        return functools.partial($
            scorer, name=name, description=description, aggregations=\
aggregations$
        )$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
def validate_aggregations(aggregations: list[str | AggregationFunc] |\
 None) -> None:$
    """$
    Validate that aggregations are either valid string names or calla\
ble functions.$
$
    Args:$
        aggregations: List of aggregation functions to validate. Can \
be strings from$
                     the standard set or callable functions.$
    """$
    if not aggregations:$
        return$
$
    from mlflow.genai.scorers.aggregation import _AGGREGATE_FUNCTIONS$
$
    valid_aggregation_names = set(_AGGREGATE_FUNCTIONS.keys())$
            expected_output=expectations_str,$
        )$
        feedback = invoke_judge_model(model, prompt, assessment_name=\
assessment_name)$
$
        return _sanitize_feedback(feedback)$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
class MissingColumnsException(MlflowException):$
    def __init__(self, scorer: str, missing_columns: set[str]):$
        self.scorer = scorer$
        self.missing_columns = list(missing_columns)$
        super().__init__($
            f"The following columns are required for the scorer {scor\
er}: {missing_columns}"$
        )$
```

## 原始行 46 · file_change

```
{
  "id": "item_30",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/scorers/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/genai/scorers/builtin_scorers.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/genai/scorers/validation.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 51 · agent_message

```
The first focused run exposed failures in custom-scorer execution while the built-in scorer tests are otherwise progressing. The decorator metadata and serialization structure are working; I’m narrowing the execution failures now and will adjust the wrapper rather than changing evaluation behavior.
```

## 原始行 53 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/genai/scorers/test_scorer.py tests/genai/scorers/test_scorer_description.py tests/genai/scorers/test_serialization.py tests/genai/scorers/test_aggregation.py tests/genai/scorers/test_builtin_scorers.py -q'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 145 items

tests/genai/scorers/test_scorer.py [33ms[0m[33ms[0m[31mF[0m[31mF[0m[33ms[0m[33ms[0m[31mF[0m[31mF[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[32m.[0m[33ms[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m   [ 24%][0m
tests/genai/scorers/test_scorer_description.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m            [ 33%][0m
tests/genai/scorers/test_serialization.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m           [ 47%][0m
tests/genai/scorers/test_aggregation.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                   [ 57%][0m
tests/genai/scorers/test_builtin_scorers.py [32m.[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m [ 76%]
[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                       [100%][0m

=================================== FAILURES ===================================
[31m[1m_____________ test_scorer_existence_in_metrics[oss-dummy_scorer0] ______________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
dummy_scorer = AlwaysYesScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mdummy_scorer[39;49;00m[33m"[39;49;00m, [AlwaysYesScorer(name=[33m"[39;49;00m[33malways_yes[39;49;00m[33m"[39;49;00m), scorer(always_yes)])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_existence_in_metrics[39;49;00m(sample_data, dummy_scorer, is_in_databricks):[90m[39;49;00m
>       result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

dummy_scorer = AlwaysYesScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]

[1m[31mtests/genai/scorers/test_scorer.py[0m:63: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [AlwaysYesScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [AlwaysYesScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:52:57 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________ test_scorer_existence_in_metrics[oss-dummy_scorer1] ______________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
dummy_scorer = DecoratedScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mdummy_scorer[39;49;00m[33m"[39;49;00m, [AlwaysYesScorer(name=[33m"[39;49;00m[33malways_yes[39;49;00m[33m"[39;49;00m), scorer(always_yes)])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_existence_in_metrics[39;49;00m(sample_data, dummy_scorer, is_in_databricks):[90m[39;49;00m
>       result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

dummy_scorer = DecoratedScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]

[1m[31mtests/genai/scorers/test_scorer.py[0m:63: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='always_yes', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:52:57 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________ test_scorer_name_works[oss-dummy_scorer0] ___________________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
dummy_scorer = AlwaysYesScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mdummy_scorer[39;49;00m[33m"[39;49;00m, [AlwaysYesScorer(name=[33m"[39;49;00m[33malways_no[39;49;00m[33m"[39;49;00m), scorer(name=[33m"[39;49;00m[33malways_no[39;49;00m[33m"[39;49;00m)(always_yes)][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_name_works[39;49;00m(sample_data, dummy_scorer, is_in_databricks):[90m[39;49;00m
        _SCORER_NAME = [33m"[39;49;00m[33malways_no[39;49;00m[33m"[39;49;00m[90m[39;49;00m
>       result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

_SCORER_NAME = 'always_no'
dummy_scorer = AlwaysYesScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]

[1m[31mtests/genai/scorers/test_scorer.py[0m:72: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [AlwaysYesScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [AlwaysYesScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:52:57 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________ test_scorer_name_works[oss-dummy_scorer1] ___________________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
dummy_scorer = DecoratedScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mdummy_scorer[39;49;00m[33m"[39;49;00m, [AlwaysYesScorer(name=[33m"[39;49;00m[33malways_no[39;49;00m[33m"[39;49;00m), scorer(name=[33m"[39;49;00m[33malways_no[39;49;00m[33m"[39;49;00m)(always_yes)][90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_name_works[39;49;00m(sample_data, dummy_scorer, is_in_databricks):[90m[39;49;00m
        _SCORER_NAME = [33m"[39;49;00m[33malways_no[39;49;00m[33m"[39;49;00m[90m[39;49;00m
>       result = mlflow.genai.evaluate(data=sample_data, scorers=[dummy_scorer])[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

_SCORER_NAME = 'always_no'
dummy_scorer = DecoratedScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]

[1m[31mtests/genai/scorers/test_scorer.py[0m:72: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='always_no', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:52:58 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m____________________ test_scorer_on_genai_evaluate[oss-yes] ____________________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = 'yes', is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mscorer_return[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            [33m"[39;49;00m[33myes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [94m42[39;49;00m,[90m[39;49;00m
            [94m42.0[39;49;00m,[90m[39;49;00m
            [90m# Feedback object.[39;49;00m[90m[39;49;00m
            Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            [90m# List of Feedback objects.[39;49;00m[90m[39;49;00m
            [[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33msmall_question[39;49;00m[33m"[39;49;00m, value=[94m1[39;49;00m, rationale=[33m"[39;49;00m[33mNot sure, just a guess[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            ],[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_on_genai_evaluate[39;49;00m(sample_data, scorer_return, is_in_databricks):[90m[39;49;00m
        [37m@scorer[39;49;00m[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mdummy_scorer[39;49;00m(inputs, outputs):[90m[39;49;00m
            [94mreturn[39;49;00m scorer_return[90m[39;49;00m
    [90m[39;49;00m
>       results = mlflow.genai.evaluate([90m[39;49;00m
            data=sample_data,[90m[39;49;00m
            scorers=[dummy_scorer],[90m[39;49;00m
        )[90m[39;49;00m

dummy_scorer = DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = 'yes'

[1m[31mtests/genai/scorers/test_scorer.py[0m:252: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:53:01 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m____________________ test_scorer_on_genai_evaluate[oss-42] _____________________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = 42, is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mscorer_return[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            [33m"[39;49;00m[33myes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [94m42[39;49;00m,[90m[39;49;00m
            [94m42.0[39;49;00m,[90m[39;49;00m
            [90m# Feedback object.[39;49;00m[90m[39;49;00m
            Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            [90m# List of Feedback objects.[39;49;00m[90m[39;49;00m
            [[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33msmall_question[39;49;00m[33m"[39;49;00m, value=[94m1[39;49;00m, rationale=[33m"[39;49;00m[33mNot sure, just a guess[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            ],[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_on_genai_evaluate[39;49;00m(sample_data, scorer_return, is_in_databricks):[90m[39;49;00m
        [37m@scorer[39;49;00m[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mdummy_scorer[39;49;00m(inputs, outputs):[90m[39;49;00m
            [94mreturn[39;49;00m scorer_return[90m[39;49;00m
    [90m[39;49;00m
>       results = mlflow.genai.evaluate([90m[39;49;00m
            data=sample_data,[90m[39;49;00m
            scorers=[dummy_scorer],[90m[39;49;00m
        )[90m[39;49;00m

dummy_scorer = DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = 42

[1m[31mtests/genai/scorers/test_scorer.py[0m:252: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:53:01 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_scorer_on_genai_evaluate[oss-42.0] ____________________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = 42.0, is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mscorer_return[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            [33m"[39;49;00m[33myes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [94m42[39;49;00m,[90m[39;49;00m
            [94m42.0[39;49;00m,[90m[39;49;00m
            [90m# Feedback object.[39;49;00m[90m[39;49;00m
            Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            [90m# List of Feedback objects.[39;49;00m[90m[39;49;00m
            [[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33msmall_question[39;49;00m[33m"[39;49;00m, value=[94m1[39;49;00m, rationale=[33m"[39;49;00m[33mNot sure, just a guess[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            ],[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_on_genai_evaluate[39;49;00m(sample_data, scorer_return, is_in_databricks):[90m[39;49;00m
        [37m@scorer[39;49;00m[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mdummy_scorer[39;49;00m(inputs, outputs):[90m[39;49;00m
            [94mreturn[39;49;00m scorer_return[90m[39;49;00m
    [90m[39;49;00m
>       results = mlflow.genai.evaluate([90m[39;49;00m
            data=sample_data,[90m[39;49;00m
            scorers=[dummy_scorer],[90m[39;49;00m
        )[90m[39;49;00m

dummy_scorer = DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = 42.0

[1m[31mtests/genai/scorers/test_scorer.py[0m:252: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:53:01 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________ test_scorer_on_genai_evaluate[oss-scorer_return3] _______________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = Feedback(name='big_question', source=AssessmentSource(source_type='CODE', source_id='default'), trace_id=None, run_id=...ssment_id=None, error=None, expectation=None, feedback=FeedbackValue(value=42, error=None), overrides=None, valid=True)
is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mscorer_return[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            [33m"[39;49;00m[33myes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [94m42[39;49;00m,[90m[39;49;00m
            [94m42.0[39;49;00m,[90m[39;49;00m
            [90m# Feedback object.[39;49;00m[90m[39;49;00m
            Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            [90m# List of Feedback objects.[39;49;00m[90m[39;49;00m
            [[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33msmall_question[39;49;00m[33m"[39;49;00m, value=[94m1[39;49;00m, rationale=[33m"[39;49;00m[33mNot sure, just a guess[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            ],[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_on_genai_evaluate[39;49;00m(sample_data, scorer_return, is_in_databricks):[90m[39;49;00m
        [37m@scorer[39;49;00m[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mdummy_scorer[39;49;00m(inputs, outputs):[90m[39;49;00m
            [94mreturn[39;49;00m scorer_return[90m[39;49;00m
    [90m[39;49;00m
>       results = mlflow.genai.evaluate([90m[39;49;00m
            data=sample_data,[90m[39;49;00m
            scorers=[dummy_scorer],[90m[39;49;00m
        )[90m[39;49;00m

dummy_scorer = DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = Feedback(name='big_question', source=AssessmentSource(source_type='CODE', source_id='default'), trace_id=None, run_id=...ssment_id=None, error=None, expectation=None, feedback=FeedbackValue(value=42, error=None), overrides=None, valid=True)

[1m[31mtests/genai/scorers/test_scorer.py[0m:252: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:53:02 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________ test_scorer_on_genai_evaluate[oss-scorer_return4] _______________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = [Feedback(name='big_question', source=AssessmentSource(source_type='CODE', source_id='default'), trace_id=None, run_id...ssment_id=None, error=None, expectation=None, feedback=FeedbackValue(value=1, error=None), overrides=None, valid=True)]
is_in_databricks = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mscorer_return[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            [33m"[39;49;00m[33myes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [94m42[39;49;00m,[90m[39;49;00m
            [94m42.0[39;49;00m,[90m[39;49;00m
            [90m# Feedback object.[39;49;00m[90m[39;49;00m
            Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            [90m# List of Feedback objects.[39;49;00m[90m[39;49;00m
            [[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33mbig_question[39;49;00m[33m"[39;49;00m, value=[94m42[39;49;00m, rationale=[33m"[39;49;00m[33mIt[39;49;00m[33m'[39;49;00m[33ms the answer to everything[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
                Feedback(name=[33m"[39;49;00m[33msmall_question[39;49;00m[33m"[39;49;00m, value=[94m1[39;49;00m, rationale=[33m"[39;49;00m[33mNot sure, just a guess[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            ],[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_on_genai_evaluate[39;49;00m(sample_data, scorer_return, is_in_databricks):[90m[39;49;00m
        [37m@scorer[39;49;00m[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mdummy_scorer[39;49;00m(inputs, outputs):[90m[39;49;00m
            [94mreturn[39;49;00m scorer_return[90m[39;49;00m
    [90m[39;49;00m
>       results = mlflow.genai.evaluate([90m[39;49;00m
            data=sample_data,[90m[39;49;00m
            scorers=[dummy_scorer],[90m[39;49;00m
        )[90m[39;49;00m

dummy_scorer = DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorer_return = [Feedback(name='big_question', source=AssessmentSource(source_type='CODE', source_id='default'), trace_id=None, run_id...ssment_id=None, error=None, expectation=None, feedback=FeedbackValue(value=1, error=None), overrides=None, valid=True)]

[1m[31mtests/genai/scorers/test_scorer.py[0m:252: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:53:02 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________ test_scorer_returns_feedback_with_error[oss] _________________[0m

sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_in_databricks = False

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_scorer_returns_feedback_with_error[39;49;00m(sample_data, is_in_databricks):[90m[39;49;00m
        [37m@scorer[39;49;00m[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mdummy_scorer[39;49;00m(inputs):[90m[39;49;00m
            [94mreturn[39;49;00m Feedback([90m[39;49;00m
                name=[33m"[39;49;00m[33mfeedback_with_error[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                error=AssessmentError(error_code=[33m"[39;49;00m[33m500[39;49;00m[33m"[39;49;00m, error_message=[33m"[39;49;00m[33mThis is an error[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
                source=AssessmentSource(source_type=AssessmentSourceType.LLM_JUDGE, source_id=[33m"[39;49;00m[33mgpt[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
                metadata={[33m"[39;49;00m[33mindex[39;49;00m[33m"[39;49;00m: [94m0[39;49;00m},[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
>       results = mlflow.genai.evaluate([90m[39;49;00m
            data=sample_data,[90m[39;49;00m
            scorers=[dummy_scorer],[90m[39;49;00m
        )[90m[39;49;00m

dummy_scorer = DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)
is_in_databricks = False
sample_data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]

[1m[31mtests/genai/scorers/test_scorer.py[0m:286: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
scorers = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]
predict_fn = None, model_id = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.0.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mevaluate[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mEvaluationDatasetTypes[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        scorers: [96mlist[39;49;00m[Scorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        model_id: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> EvaluationResult:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Evaluate the performance of a generative AI model/application using specified[39;49;00m
    [33m    data and scorers.[39;49;00m
    [33m[39;49;00m
    [33m    This function allows you to evaluate a model's performance on a given dataset[39;49;00m
    [33m    using various scoring criteria. It supports both built-in scorers provided by[39;49;00m
    [33m    MLflow and custom scorers. The evaluation results include metrics and detailed[39;49;00m
    [33m    per-row assessments.[39;49;00m
    [33m[39;49;00m
    [33m    There are three different ways to use this function:[39;49;00m
    [33m[39;49;00m
    [33m    **1. Use Traces to evaluate the model/application.**[39;49;00m
    [33m[39;49;00m
    [33m    The `data` parameter takes a DataFrame with `trace` column, which contains a[39;49;00m
    [33m    single trace object corresponding to the prediction for the row. This dataframe[39;49;00m
    [33m    is easily obtained from the existing traces stored in MLflow, by using the[39;49;00m
    [33m    :py:func:`mlflow.search_traces` function.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        # model_id is a string starting with "m-", e.g. "m-074689226d3b40bfbbdf4c3ff35832cd"[39;49;00m
    [33m        trace_df = mlflow.search_traces(model_id="<my-model-id>")[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=trace_df,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Built-in scorers will understand the model inputs, outputs, and other intermediate[39;49;00m
    [33m    information e.g. retrieved context, from the trace object. You can also access to[39;49;00m
    [33m    the trace object from the custom scorer function by using the `trace` parameter.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        from mlflow.genai.scorers import scorer[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        @scorer[39;49;00m
    [33m        def faster_than_one_second(inputs, outputs, trace):[39;49;00m
    [33m            return trace.info.execution_duration < 1000[39;49;00m
    [33m[39;49;00m
    [33m    **2. Use DataFrame or dictionary with "inputs", "outputs", "expectations" columns.**[39;49;00m
    [33m[39;49;00m
    [33m    Alternatively, you can pass inputs, outputs, and expectations (ground truth) as[39;49;00m
    [33m    a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness[39;49;00m
    [33m        import pandas as pd[39;49;00m
    [33m[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is MLflow?"},[39;49;00m
    [33m                    "outputs": "MLflow is an ML platform",[39;49;00m
    [33m                    "expectations": "MLflow is an ML platform",[39;49;00m
    [33m                },[39;49;00m
    [33m                {[39;49;00m
    [33m                    "inputs": {"question": "What is Spark?"},[39;49;00m
    [33m                    "outputs": "I don't know",[39;49;00m
    [33m                    "expectations": "Spark is a data engine",[39;49;00m
    [33m                },[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            scorers=[Correctness()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    **3. Pass `predict_fn` and input samples (and optionally expectations).**[39;49;00m
    [33m[39;49;00m
    [33m    If you want to generate the outputs and traces on-the-fly from your input samples,[39;49;00m
    [33m    you can pass a callable to the `predict_fn` parameter. In this case, MLflow will[39;49;00m
    [33m    pass the inputs to the `predict_fn` as keyword arguments. Therefore, the "inputs"[39;49;00m
    [33m    column must be a dictionary with the parameter names as keys.[39;49;00m
    [33m[39;49;00m
    [33m    .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m        import mlflow[39;49;00m
    [33m        from mlflow.genai.scorers import Correctness, Safety[39;49;00m
    [33m        import openai[39;49;00m
    [33m[39;49;00m
    [33m        # Create a dataframe with input samples[39;49;00m
    [33m        data = pd.DataFrame([39;49;00m
    [33m            [[39;49;00m
    [33m                {"inputs": {"question": "What is MLflow?"}},[39;49;00m
    [33m                {"inputs": {"question": "What is Spark?"}},[39;49;00m
    [33m            ][39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        # Define a predict function to evaluate. The "inputs" column will be[39;49;00m
    [33m        # passed to the prediction function as keyword arguments.[39;49;00m
    [33m        def predict_fn(question: str) -> str:[39;49;00m
    [33m            response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                model="gpt-4o-mini",[39;49;00m
    [33m                messages=[{"role": "user", "content": question}],[39;49;00m
    [33m            )[39;49;00m
    [33m            return response.choices[0].message.content[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m        mlflow.genai.evaluate([39;49;00m
    [33m            data=data,[39;49;00m
    [33m            predict_fn=predict_fn,[39;49;00m
    [33m            scorers=[Correctness(), Safety()],[39;49;00m
    [33m        )[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        data: Dataset for the evaluation. Must be one of the following formats:[39;49;00m
    [33m[39;49;00m
    [33m            * An EvaluationDataset entity[39;49;00m
    [33m            * Pandas DataFrame[39;49;00m
    [33m            * Spark DataFrame[39;49;00m
    [33m            * List of dictionaries[39;49;00m
    [33m[39;49;00m
    [33m            The dataset must include either of the following columns:[39;49;00m
    [33m[39;49;00m
    [33m            1. `trace` column that contains a single trace object corresponding[39;49;00m
    [33m                to the prediction for the row.[39;49;00m
    [33m[39;49;00m
    [33m                If this column is present, MLflow extracts inputs, outputs, assessments,[39;49;00m
    [33m                and other intermediate information e.g. retrieved context, from the trace[39;49;00m
    [33m                object and uses them for scoring. When this column is present, the[39;49;00m
    [33m                `predict_fn` parameter must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m            2. `inputs`, `outputs`, `expectations` columns.[39;49;00m
    [33m[39;49;00m
    [33m                Alternatively, you can pass inputs, outputs, and expectations(ground[39;49;00m
    [33m                truth) as a column in the dataframe (or equivalent list of dictionaries).[39;49;00m
    [33m[39;49;00m
    [33m                - inputs (required): Column containing inputs for evaluation. The value[39;49;00m
    [33m                  must be a dictionary. When `predict_fn` is provided, MLflow will pass[39;49;00m
    [33m                  the inputs to the `predict_fn` as keyword arguments. For example,[39;49;00m
    [33m[39;49;00m
    [33m                  * predict_fn: `def predict_fn(question: str, context: str) -> str`[39;49;00m
    [33m                  * inputs: `{"question": "What is MLflow?", "context": "MLflow is an ML platform"}`[39;49;00m
    [33m                  * `predict_fn` will receive "What is MLflow?" as the first argument[39;49;00m
    [33m                    (`question`) and "MLflow is an ML platform" as the second argument (`context`)[39;49;00m
    [33m[39;49;00m
    [33m                - outputs (optional): Column containing model or app outputs.[39;49;00m
    [33m                  If this column is present, `predict_fn` must not be provided.[39;49;00m
    [33m[39;49;00m
    [33m                - expectations (optional): Column containing a dictionary of ground truths.[39;49;00m
    [33m[39;49;00m
    [33m            For list of dictionaries, each dict should follow the above schema.[39;49;00m
    [33m[39;49;00m
    [33m            Optional columns:[39;49;00m
    [33m                - tags (optional): Column containing a dictionary of tags. The tags will be logged[39;49;00m
    [33m                                   to the respective traces.[39;49;00m
    [33m[39;49;00m
    [33m        scorers: A list of Scorer objects that produces evaluation scores from[39;49;00m
    [33m            inputs, outputs, and other additional contexts. MLflow provides pre-defined[39;49;00m
    [33m            scorers, but you can also define custom ones.[39;49;00m
    [33m[39;49;00m
    [33m        predict_fn: The target function to be evaluated. The specified function will be[39;49;00m
    [33m            executed for each row in the input dataset, and outputs will be used for[39;49;00m
    [33m            scoring.[39;49;00m
    [33m[39;49;00m
    [33m            The function must emit a single trace per call. If it doesn't, decorate[39;49;00m
    [33m            the function with @mlflow.trace decorator to ensure a trace to be emitted.[39;49;00m
    [33m[39;49;00m
    [33m        model_id: Optional model identifier (e.g. "m-074689226d3b40bfbbdf4c3ff35832cd")[39;49;00m
    [33m            to associate with the evaluation results. Can be also set globally via the[39;49;00m
    [33m            :py:func:`mlflow.set_active_model` function.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An :py:class:`mlflow.models.EvaluationResult~` object.[39;49;00m
    [33m[39;49;00m
    [33m    Note:[39;49;00m
    [33m        This function is only supported on Databricks. The tracking URI must be[39;49;00m
    [33m        set to Databricks.[39;49;00m
    [33m[39;49;00m
    [33m    .. warning::[39;49;00m
    [33m[39;49;00m
    [33m        This function is not thread-safe. Please do not use it in multi-threaded[39;49;00m
    [33m        environments.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        is_managed_dataset = [96misinstance[39;49;00m(data, (EvaluationDataset, EntityEvaluationDataset))[90m[39;49;00m
    [90m[39;49;00m
>       scorers = validate_scorers(scorers)[90m[39;49;00m
                  ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name 'validate_scorers' is not defined[0m

data       =                                               inputs  ...                                       expectations
0  {'mess...es': [{'role': 'user', 'content': 'How...  ...  {'expected_response': 'expected response for s...

[2 rows x 3 columns]
is_managed_dataset = False
model_id   = None
predict_fn = None
scorers    = [DecoratedScorer(name='dummy_scorer', aggregations=None, description=None, sample_rate=None, filter_string=None)]

[1m[31mmlflow/genai/evaluation/base.py[0m:243: NameError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:53:02 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________________ test_default_parameters_round_trip ______________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_default_parameters_round_trip[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""Test round-trip with default parameter values."""[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       [37m@scorer[39;49;00m[90m[39;49;00m
         ^^^^^^[90m[39;49;00m


[1m[31mtests/genai/scorers/test_serialization.py[0m:216: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

func = <function test_default_parameters_round_trip.<locals>.default_scorer at 0x7803d1517ce0>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mscorer[39;49;00m([90m[39;49;00m
        func=[94mNone[39;49;00m,[90m[39;49;00m
        *,[90m[39;49;00m
        name: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        description: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        aggregations: [96mlist[39;49;00m[_AggregationType] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    A decorator to define a custom scorer that can be used in ``mlflow.genai.evaluate()``.[39;49;00m
    [33m[39;49;00m
    [33m    The scorer function should take in a **subset** of the following parameters:[39;49;00m
    [33m[39;49;00m
    [33m    .. list-table::[39;49;00m
    [33m        :widths: 20 20 20[39;49;00m
    [33m        :header-rows: 1[39;49;00m
    [33m[39;49;00m
    [33m        * - Parameter[39;49;00m
    [33m          - Description[39;49;00m
    [33m          - Source[39;49;00m
    [33m[39;49;00m
    [33m        * - ``inputs``[39;49;00m
    [33m          - A single input to the target model/app.[39;49;00m
    [33m          - Derived from either dataset or trace.[39;49;00m
    [33m[39;49;00m
    [33m            * When the dataset contains ``inputs`` column, the value will be passed as is.[39;49;00m
    [33m            * When traces are provided as evaluation dataset, this will be derived[39;49;00m
    [33m              from the ``inputs`` field of the trace (i.e. inputs captured as the[39;49;00m
    [33m              root span of the trace).[39;49;00m
    [33m[39;49;00m
    [33m        * - ``outputs``[39;49;00m
    [33m          - A single output from the target model/app.[39;49;00m
    [33m          - Derived from either dataset, trace, or output of ``predict_fn``.[39;49;00m
    [33m[39;49;00m
    [33m            * When the dataset contains ``outputs`` column, the value will be passed as is.[39;49;00m
    [33m            * When ``predict_fn`` is provided, MLflow will make a prediction using the[39;49;00m
    [33m              ``inputs`` and the ``predict_fn`` and pass the result as the ``outputs``.[39;49;00m
    [33m            * When traces are provided as evaluation dataset, this will be derived[39;49;00m
    [33m              from the ``response`` field of the trace (i.e. outputs captured as the[39;49;00m
    [33m              root span of the trace).[39;49;00m
    [33m[39;49;00m
    [33m        * - ``expectations``[39;49;00m
    [33m          - Ground truth or any expectation for each prediction e.g., expected retrieved docs.[39;49;00m
    [33m          - Derived from either dataset or trace.[39;49;00m
    [33m[39;49;00m
    [33m            * When the dataset contains ``expectations`` column, the value will be passed as is.[39;49;00m
    [33m            * When traces are provided as evaluation dataset, this will be a dictionary[39;49;00m
    [33m              that contains a set of assessments in the format of[39;49;00m
    [33m              [assessment name]: [assessment value].[39;49;00m
    [33m[39;49;00m
    [33m        * - ``trace``[39;49;00m
    [33m          - A trace object corresponding to the prediction for the row.[39;49;00m
    [33m          - Specified as a ``trace`` column in the dataset, or generated during the prediction.[39;49;00m
    [33m[39;49;00m
    [33m    The scorer function should return one of the following:[39;49;00m
    [33m[39;49;00m
    [33m    * A boolean value[39;49;00m
    [33m    * An integer value[39;49;00m
    [33m    * A float value[39;49;00m
    [33m    * A string value[39;49;00m
    [33m    * A single :class:`~mlflow.entities.Feedback` object[39;49;00m
    [33m    * A list of :class:`~mlflow.entities.Feedback` objects[39;49;00m
    [33m[39;49;00m
    [33m    .. note::[39;49;00m
    [33m[39;49;00m
    [33m        The metric name will be determined by the scorer function's name or a custom name[39;49;00m
    [33m        specified in the `name` parameter for the scorer.[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        func: The scorer function to be decorated.[39;49;00m
    [33m        name: The name of the scorer.[39;49;00m
    [33m        description: A description of what the scorer evaluates.[39;49;00m
    [33m        aggregations: A list of aggregation functions to apply to the scorer's output.[39;49;00m
    [33m            The aggregation functions can be either a string or a callable.[39;49;00m
    [33m[39;49;00m
    [33m            * If a string, it must be one of `["min", "max", "mean", "median", "variance", "p90"]`.[39;49;00m
    [33m            * If a callable, it must take a list of values and return a single value.[39;49;00m
    [33m[39;49;00m
    [33m            By default, "mean" is used as the aggregation function.[39;49;00m
    [33m[39;49;00m
    [33m    Example:[39;49;00m
    [33m[39;49;00m
    [33m        .. code-block:: python[39;49;00m
    [33m[39;49;00m
    [33m            import json[39;49;00m
    [33m            from mlflow.genai.scorers import scorer[39;49;00m
    [33m            from mlflow.entities import AssessmentSource, Feedback[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m            # Basic scorers that returns primitive values[39;49;00m
    [33m            @scorer[39;49;00m
    [33m            def not_empty(outputs) -> bool:[39;49;00m
    [33m                return outputs != ""[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m            @scorer[39;49;00m
    [33m            def exact_match(outputs, expectations) -> bool:[39;49;00m
    [33m                return outputs == expectations["expected_response"][39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m            @scorer[39;49;00m
    [33m            def num_tool_calls(trace) -> int:[39;49;00m
    [33m                spans = trace.search_spans(name="tool_call")[39;49;00m
    [33m                return len(spans)[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m            # Use `Feedback` object to return additional information about the scorer's[39;49;00m
    [33m            # result, such as a rationale for the score.[39;49;00m
    [33m            @scorer[39;49;00m
    [33m            def harmfulness(outputs) -> Feedback:[39;49;00m
    [33m                import openai[39;49;00m
    [33m[39;49;00m
    [33m                prompt = f'''[39;49;00m
    [33m                    Judge if the following text is harmful or not.[39;49;00m
    [33m[39;49;00m
    [33m                    Text:[39;49;00m
    [33m                    {outputs}[39;49;00m
    [33m[39;49;00m
    [33m                    Return the answer in a JSON object with the following format:[39;49;00m
    [33m                    {{[39;49;00m
    [33m                        "harmful": true[39;49;00m
    [33m                        "reason": "The text contains harmful content"[39;49;00m
    [33m                    }}[39;49;00m
    [33m[39;49;00m
    [33m                    Do not output any other characters than the json object.[39;49;00m
    [33m                '''[39;49;00m
    [33m                response = openai.OpenAI().chat.completions.create([39;49;00m
    [33m                    model="o4-mini",[39;49;00m
    [33m                    messages=[{"role": "user", "content": prompt}],[39;49;00m
    [33m                )[39;49;00m
    [33m                payload = json.loads(response.choices[0].message.content)[39;49;00m
    [33m                return Feedback([39;49;00m
    [33m                    value=payload["harmful"],[39;49;00m
    [33m                    rationale=payload["reason"],[39;49;00m
    [33m                    source=AssessmentSource([39;49;00m
    [33m                        source_type="LLM_JUDGE",[39;49;00m
    [33m                        source_id="openai:/o4-mini",[39;49;00m
    [33m                    ),[39;49;00m
    [33m                )[39;49;00m
    [33m[39;49;00m
    [33m[39;49;00m
    [33m            # Use the scorer in an evaluation[39;49;00m
    [33m            mlflow.genai.evaluate([39;49;00m
    [33m                data=data,[39;49;00m
    [33m                scorers=[not_empty, exact_match, num_tool_calls, harmfulness],[39;49;00m
    [33m            )[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m func [95mis[39;49;00m [94mNone[39;49;00m:[90m[39;49;00m
            [94mreturn[39;49;00m functools.partial([90m[39;49;00m
                scorer, name=name, description=description, aggregations=aggregations[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96mcallable[39;49;00m(func):[90m[39;49;00m
            [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m`scorer` must decorate a callable function, got [39;49;00m[33m{[39;49;00m[96mtype[39;49;00m(func).[91m__name__[39;49;00m[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
    [90m[39;49;00m
        signature = inspect.signature(func)[90m[39;49;00m
        supported_parameters = {[33m"[39;49;00m[33minputs[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33moutputs[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mexpectations[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mtrace[39;49;00m[33m"[39;49;00m}[90m[39;49;00m
        invalid_parameters = [[90m[39;49;00m
            parameter.name[90m[39;49;00m
            [94mfor[39;49;00m parameter [95min[39;49;00m signature.parameters.values()[90m[39;49;00m
            [94mif[39;49;00m parameter.name [95mnot[39;49;00m [95min[39;49;00m supported_parameters[90m[39;49;00m
        ][90m[39;49;00m
        [94mif[39;49;00m invalid_parameters:[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mScorer functions may only use the parameters `inputs`, `outputs`, [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33mf[39;49;00m[33m"[39;49;00m[33m`expectations`, and `trace`. Got invalid parameters: [39;49;00m[33m{[39;49;00minvalid_parameters[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: Scorer functions may only use the parameters `inputs`, `outputs`, `expectations`, and `trace`. Got invalid parameters: ['threshold'].[0m

aggregations = None
description = None
func       = <function test_default_parameters_round_trip.<locals>.default_scorer at 0x7803d1517ce0>
invalid_parameters = ['threshold']
name       = None
signature  = <Signature (outputs, threshold=5)>
supported_parameters = {'expectations', 'inputs', 'outputs', 'trace'}

[1m[31mmlflow/genai/scorers/base.py[0m:1012: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:53:05 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
2.22s call     tests/genai/scorers/test_builtin_scorers.py::test_resolve_scorer_fields_partial_extraction
2.17s setup    tests/genai/scorers/test_scorer.py::test_trace_passed_to_builtin_scorers_correctly[databricks]
2.07s call     tests/genai/scorers/test_builtin_scorers.py::test_backwards_compatibility
2.03s setup    tests/genai/scorers/test_builtin_scorers.py::test_trace_not_formatted_into_prompt_for_fallback[<lambda>-safety-is_safe]
1.96s call     tests/genai/scorers/test_builtin_scorers.py::test_equivalence_default_extracts_from_trace
1.91s call     tests/genai/scorers/test_builtin_scorers.py::test_guidelines_with_trace
1.84s setup    tests/genai/scorers/test_builtin_scorers.py::test_retrieval_relevance_with_custom_model
1.83s call     tests/genai/scorers/test_builtin_scorers.py::test_correctness_default_extracts_from_trace
1.81s setup    tests/genai/scorers/test_builtin_scorers.py::test_resolve_scorer_fields_llm_fallback
1.79s call     tests/genai/scorers/test_builtin_scorers.py::test_resolve_scorer_fields_with_trace_extraction

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                          | Duration | Tests | Min    | Max    | Avg    |
| ---- | --------------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/genai/scorers/test_builtin_scorers.py` | 56.61s   | 62    | 0.001s | 2.227s | 0.913s |
| 2    | `tests/genai/scorers/test_scorer.py`          | 7.96s    | 35    | 0.001s | 2.172s | 0.227s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics[oss-dummy_scorer0]' 'tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics[oss-dummy_scorer1]' 'tests/genai/scorers/test_scorer.py::test_scorer_name_works[oss-dummy_scorer0]' 'tests/genai/scorers/test_scorer.py::test_scorer_name_works[oss-dummy_scorer1]' 'tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-yes]' 'tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-42]' 'tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-42.0]' 'tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-scorer_return3]' 'tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-scorer_return4]' 'tests/genai/scorers/test_scorer.py::test_scorer_returns_feedback_with_error[oss]' 'tests/genai/scorers/test_serialization.py::test_default_parameters_round_trip'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_existence_in_metrics[oss-dummy_scorer0][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_existence_in_metrics[oss-dummy_scorer1][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_name_works[oss-dummy_scorer0][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_name_works[oss-dummy_scorer1][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_on_genai_evaluate[oss-yes][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_on_genai_evaluate[oss-42][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_on_genai_evaluate[oss-42.0][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_on_genai_evaluate[oss-scorer_return3][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_on_genai_evaluate[oss-scorer_return4][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_scorer.py::[1mtest_scorer_returns_feedback_with_error[oss][0m - NameError: name 'validate_scorers' is not defined
[31mFAILED | MEM 22.3/33.7 GB | DISK 793.1/915.7 GB[0m tests/genai/scorers/test_serialization.py::[1mtest_default_parameters_round_trip[0m - mlflow.exceptions.MlflowException: Scorer functions may only use the parame...
[31m============ [31m[1m11 failed[0m, [32m114 passed[0m, [33m20 skipped[0m[31m in 65.09s (0:01:05)[0m[31m =============[0m
```

## 原始行 56 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,115p' mlflow/genai/optimize/util.py; grep -R -n \"valid_data_for_builtin_scorers\\|validate_scorers\" mlflow/genai -B12 -A2"
```

退出码：`0`

输出：
```
import functools
from contextlib import contextmanager, nullcontext
from typing import TYPE_CHECKING, Any, Callable

from pydantic import BaseModel, create_model

from mlflow.entities import Trace
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers import Scorer
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer

from mlflow.tracking.client import MlflowClient

if TYPE_CHECKING:
    import pandas as pd


@contextmanager
def prompt_optimization_autolog(
    optimizer_name: str,
    num_prompts: int,
    num_training_samples: int,
    train_data_df: "pd.DataFrame",
):
    """
    Context manager for autologging prompt optimization runs.

    Args:
        optimizer_name: Name of the optimizer being used
        num_prompts: Number of prompts being optimized
        num_training_samples: Number of training samples
        train_data_df: Training data as a pandas DataFrame

    Yields:
        Tuple of (run_id, results_dict) where results_dict should be populated with
        PromptOptimizerOutput and list of optimized PromptVersion objects
    """
    import mlflow.data

    active_run = mlflow.active_run()
    run_context = mlflow.start_run() if active_run is None else nullcontext(active_run)

    with run_context as run:
        client = MlflowClient()
        run_id = run.info.run_id

        mlflow.log_param("optimizer", optimizer_name)
        mlflow.log_param("num_prompts", num_prompts)
        mlflow.log_param("num_training_samples", num_training_samples)

        # Log training dataset as run input
        dataset = mlflow.data.from_pandas(train_data_df, source="prompt_optimization_train_data")
        mlflow.log_input(dataset, context="training")

        results = {}
        yield results

        if "optimized_prompts" in results:
            for prompt in results["optimized_prompts"]:
                client.link_prompt_version_to_run(run_id=run_id, prompt=prompt)

        if "optimizer_output" in results:
            output = results["optimizer_output"]
            if output.initial_eval_score is not None:
                mlflow.log_metric("initial_eval_score", output.initial_eval_score)
            if output.final_eval_score is not None:
                mlflow.log_metric("final_eval_score", output.final_eval_score)


def validate_train_data(
    train_data: "pd.DataFrame", scorers: list[Scorer], predict_fn: Callable[..., Any] | None = None
) -> None:
    """
    Validate that training data has required fields for prompt optimization.

    Args:
        train_data: Training data as a pandas DataFrame.
        scorers: Scorers to validate the training data for.
        predict_fn: The predict function to validate the training data for.

    Raises:
        MlflowException: If any record is missing required 'inputs' field or it is empty.
    """
    for i, record in enumerate(train_data.to_dict("records")):
        if "inputs" not in record or not record["inputs"]:
            raise MlflowException.invalid_parameter_value(
                f"Record {i} is missing required 'inputs' field or it is empty"
            )

    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
    valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)


def infer_type_from_value(value: Any, model_name: str = "Output") -> type:
    """
    Infer the type from the value.
    Only supports primitive types, lists, and dict and Pydantic models.
    """
    if value is None:
        return type(None)
    elif isinstance(value, (bool, int, float, str)):
        return type(value)
    elif isinstance(value, list):
        if not value:
            return list[Any]
        element_types = set()
        for item in value:
            element_types.add(infer_type_from_value(item))
        return list[functools.reduce(lambda x, y: x | y, element_types)]
    elif isinstance(value, dict):
        fields = {k: (infer_type_from_value(v, model_name=k), ...) for k, v in value.items()}
        return create_model(model_name, **fields)
    elif isinstance(value, BaseModel):
        return type(value)
    return Any
grep: mlflow/genai/scorers/__pycache__/validation.cpython-311.pyc: binary file matches
grep: mlflow/genai/evaluation/__pycache__/base.cpython-311.pyc: binary file matches
--
mlflow/genai/scorers/validation.py-14-try:
mlflow/genai/scorers/validation.py-15-    # `pandas` is not required for `mlflow-skinny`.
mlflow/genai/scorers/validation.py-16-    import pandas as pd
mlflow/genai/scorers/validation.py-17-except ImportError:
mlflow/genai/scorers/validation.py-18-    pass
mlflow/genai/scorers/validation.py-19-
mlflow/genai/scorers/validation.py-20-_logger = logging.getLogger(__name__)
mlflow/genai/scorers/validation.py-21-
mlflow/genai/scorers/validation.py-22-
mlflow/genai/scorers/validation.py-23-IS_DBX_AGENTS_INSTALLED = importlib.util.find_spec("databricks.agents") is not None
mlflow/genai/scorers/validation.py-24-
mlflow/genai/scorers/validation.py-25-
mlflow/genai/scorers/validation.py:26:def valid_data_for_builtin_scorers(
mlflow/genai/scorers/validation.py-27-    data: "pd.DataFrame",
mlflow/genai/scorers/validation.py-28-    builtin_scorers: list[BuiltInScorer],
--
mlflow/genai/scorers/validation.py-71-    if missing_columns_by_scorer:
mlflow/genai/scorers/validation.py-72-        diagnostics = "; ".join(
mlflow/genai/scorers/validation.py-73-            f"{scorer}: {', '.join(sorted(set(missing_columns)))}"
mlflow/genai/scorers/validation.py-74-            for scorer, missing_columns in missing_columns_by_scorer.items()
mlflow/genai/scorers/validation.py-75-        )
mlflow/genai/scorers/validation.py-76-        _logger.warning(
mlflow/genai/scorers/validation.py-77-            "Some built-in scorers are missing required columns and may return null results. "
mlflow/genai/scorers/validation.py-78-            "Missing columns by scorer: %s",
mlflow/genai/scorers/validation.py-79-            diagnostics,
mlflow/genai/scorers/validation.py-80-        )
mlflow/genai/scorers/validation.py-81-
mlflow/genai/scorers/validation.py-82-
mlflow/genai/scorers/validation.py:83:def validate_scorers(scorers: list[Any]) -> list[Scorer]:
mlflow/genai/scorers/validation.py-84-    """Validate and return a flat list of scorer instances."""
mlflow/genai/scorers/validation.py-85-    if not isinstance(scorers, list):
--
mlflow/genai/evaluation/base.py-231-
mlflow/genai/evaluation/base.py-232-    Note:
mlflow/genai/evaluation/base.py-233-        This function is only supported on Databricks. The tracking URI must be
mlflow/genai/evaluation/base.py-234-        set to Databricks.
mlflow/genai/evaluation/base.py-235-
mlflow/genai/evaluation/base.py-236-    .. warning::
mlflow/genai/evaluation/base.py-237-
mlflow/genai/evaluation/base.py-238-        This function is not thread-safe. Please do not use it in multi-threaded
mlflow/genai/evaluation/base.py-239-        environments.
mlflow/genai/evaluation/base.py-240-    """
mlflow/genai/evaluation/base.py-241-    is_managed_dataset = isinstance(data, (EvaluationDataset, EntityEvaluationDataset))
mlflow/genai/evaluation/base.py-242-
mlflow/genai/evaluation/base.py:243:    scorers = validate_scorers(scorers)
mlflow/genai/evaluation/base.py-244-    # convert into a pandas dataframe with expected evaluation set schema
mlflow/genai/evaluation/base.py-245-    df = data.to_df() if is_managed_dataset else _convert_to_eval_set(data)
mlflow/genai/evaluation/base.py-246-
mlflow/genai/evaluation/base.py-247-    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
mlflow/genai/evaluation/base.py:248:    valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)
mlflow/genai/evaluation/base.py-249-
mlflow/genai/evaluation/base.py-250-    # "request" column must exist after conversion
grep: mlflow/genai/optimize/__pycache__/util.cpython-311.pyc: binary file matches
--
mlflow/genai/optimize/util.py-79-        predict_fn: The predict function to validate the training data for.
mlflow/genai/optimize/util.py-80-
mlflow/genai/optimize/util.py-81-    Raises:
mlflow/genai/optimize/util.py-82-        MlflowException: If any record is missing required 'inputs' field or it is empty.
mlflow/genai/optimize/util.py-83-    """
mlflow/genai/optimize/util.py-84-    for i, record in enumerate(train_data.to_dict("records")):
mlflow/genai/optimize/util.py-85-        if "inputs" not in record or not record["inputs"]:
mlflow/genai/optimize/util.py-86-            raise MlflowException.invalid_parameter_value(
mlflow/genai/optimize/util.py-87-                f"Record {i} is missing required 'inputs' field or it is empty"
mlflow/genai/optimize/util.py-88-            )
mlflow/genai/optimize/util.py-89-
mlflow/genai/optimize/util.py-90-    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
mlflow/genai/optimize/util.py:91:    valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)
mlflow/genai/optimize/util.py-92-
mlflow/genai/optimize/util.py-93-
```

## 原始行 59 · file_change

```
{
  "id": "item_40",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/evaluation/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/genai/optimize/util.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/genai/scorers/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 62 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/genai/scorers/test_scorer.py tests/genai/scorers/test_serialization.py::test_default_parameters_round_trip -q'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 36 items

tests/genai/scorers/test_scorer.py [33ms[0m[33ms[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m   [ 97%][0m
tests/genai/scorers/test_serialization.py [32m.[0m[32m                              [100%][0m

============================= slowest 10 durations =============================
2.28s call     tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics[oss-dummy_scorer0]
2.04s call     tests/genai/scorers/test_scorer.py::test_scorer_returns_feedback_with_error[oss]
2.00s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-42]
1.98s call     tests/genai/scorers/test_scorer.py::test_scorer_name_works[oss-dummy_scorer1]
1.87s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-scorer_return4]
1.85s call     tests/genai/scorers/test_scorer.py::test_scorer_name_works[oss-dummy_scorer0]
1.85s call     tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics[oss-dummy_scorer1]
1.83s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-yes]
1.83s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-scorer_return3]
1.81s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-42.0]

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                 | Duration | Tests | Min    | Max    | Avg    |
| ---- | ------------------------------------ | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/genai/scorers/test_scorer.py` | 26.28s   | 35    | 0.001s | 2.278s | 0.751s |

::endgroup::

[32m======================= [32m[1m20 passed[0m, [33m16 skipped[0m[32m in 26.31s[0m[32m ========================[0m
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc "git diff --check; git diff --stat; python - <<'PY'
import inspect
import pandas as pd
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers import scorer
from mlflow.genai.scorers.builtin_scorers import Correctness, ExpectationsGuidelines, Equivalence, get_all_scorers
from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers, validate_scorers

@scorer(name='x', aggregations=['mean'])
def f(outputs, threshold=5):
    return len(outputs) > threshold
print(f.name, f.kind, inspect.signature(f), inspect.signature(f.__call__), f(outputs='abcdef'), f.run(outputs='abcdef'))
print([type(x).__name__ for x in get_all_scorers()])
valid_data_for_builtin_scorers(pd.DataFrame({'request':[{}], 'response':['a'], 'expectations':[{'expected_response':'a','guidelines':['x']}]}), [Correctness(), ExpectationsGuidelines(), Equivalence()])
print(validate_scorers([f]))
try:
    valid_data_for_builtin_scorers(pd.DataFrame({'request':[{}], 'expectations':['bad']}), [Correctness()])
except MlflowException as e:
    print(type(e).__name__, e)
PY
ruff check mlflow/genai/scorers/base.py mlflow/genai/scorers/validation.py mlflow/genai/scorers/builtin_scorers.py mlflow/genai/evaluation/base.py mlflow/genai/optimize/util.py"
```

退出码：`2`

输出：
```
 mlflow/genai/evaluation/base.py         |   4 ++
 mlflow/genai/optimize/util.py           |   1 +
 mlflow/genai/scorers/base.py            |  76 +++++++++++++++++++++-
 mlflow/genai/scorers/builtin_scorers.py |  19 +++++-
 mlflow/genai/scorers/validation.py      | 110 +++++++++++++++++++++++++++++++-
 5 files changed, 207 insertions(+), 3 deletions(-)
x ScorerKind.DECORATOR (outputs, threshold=5) (outputs, threshold=5) True True
['ExpectationsGuidelines', 'Correctness', 'RelevanceToQuery', 'RetrievalSufficiency', 'RetrievalGroundedness', 'Equivalence']
[DecoratedScorer(name='x', aggregations=['mean'], description=None, sample_rate=None, filter_string=None)]
MlflowException The `expectations` column must contain dictionaries. Got str at row 0.
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 68 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' mlflow/genai/evaluation/harness.py; sed -n '1,100p' mlflow/entities/dataset_record.py; grep -R -n \"expectations.*None\" tests/genai/evaluate tests/genai/optimize | head -100; grep -R -n \"valid_data\\|validate_train_data\\|expectations.*non\\|expectations.*dictionary\" tests/genai | head -200"
```

退出码：`0`

输出：
```
"""Entry point to the evaluation harness"""

from __future__ import annotations

import logging
import time
import traceback
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Callable

import pandas as pd

import mlflow
from mlflow.entities import SpanType
from mlflow.entities.assessment import Assessment, Feedback
from mlflow.entities.assessment_error import AssessmentError
from mlflow.entities.trace import Trace
from mlflow.environment_variables import (
    MLFLOW_GENAI_EVAL_ENABLE_SCORER_TRACING,
    MLFLOW_GENAI_EVAL_MAX_WORKERS,
)
from mlflow.genai.evaluation import context
from mlflow.genai.evaluation.entities import EvalItem, EvalResult, EvaluationResult
from mlflow.genai.evaluation.telemetry import emit_custom_metric_event
from mlflow.genai.evaluation.utils import (
    complete_eval_futures_with_progress_base,
    is_none_or_nan,
    make_code_type_assessment_source,
    standardize_scorer_value,
    validate_tags,
)
from mlflow.genai.scorers.aggregation import compute_aggregated_metrics
from mlflow.genai.scorers.base import Scorer
from mlflow.genai.utils.trace_utils import (
    _does_store_support_trace_linking,
    batch_link_traces_to_run,
    clean_up_extra_traces,
    construct_eval_result_df,
    create_minimal_trace,
)
from mlflow.pyfunc.context import Context, set_prediction_context
from mlflow.tracing.constant import AssessmentMetadataKey, TraceTagKey
from mlflow.tracing.utils.copy import copy_trace_to_experiment
from mlflow.tracking.client import MlflowClient
from mlflow.utils.mlflow_tags import IMMUTABLE_TAGS

_logger = logging.getLogger(__name__)


@context.eval_context
def run(
    *,
    eval_df: pd.DataFrame,
    predict_fn=None,
    scorers=None,
    run_id: str | None = None,
) -> EvaluationResult:
    """
    Runs GenAI evaluation harness to the given dataset.

    The overall flow is:

    1. Convert the dataset to a list of EvalItem objects
    2. Run the prediction and scoring for each EvalItem in parallel
        a. If predict_fn is provided, invoke the predict_fn for the EvalItem
        b. If predict_fn is not provided, create a dummy trace for the EvalItem
        c. Execute the scorers to compute assessments.
        d. Log the assessments to the trace.
    3. Compute the aggregated metrics from the assessments.
    """
    eval_items = [EvalItem.from_dataset_row(row) for row in eval_df.to_dict(orient="records")]
    eval_start_time = int(time.time() * 1000)

    run_id = context.get_context().get_mlflow_run_id() if run_id is None else run_id

    with ThreadPoolExecutor(
        max_workers=MLFLOW_GENAI_EVAL_MAX_WORKERS.get(),
        thread_name_prefix="MlflowGenAIEvalHarness",
    ) as executor:
        futures = [
            executor.submit(
                _run_single,
                eval_item=eval_item,
                scorers=scorers,
                predict_fn=predict_fn,
                run_id=run_id,
            )
            for eval_item in eval_items
        ]
        eval_results = complete_eval_futures_with_progress_base(futures)

    # Link traces to the run if the backend support it
    batch_link_traces_to_run(run_id=run_id, eval_results=eval_results)

    # Aggregate metrics and log to MLflow run
    aggregated_metrics = compute_aggregated_metrics(eval_results, scorers=scorers)
    mlflow.log_metrics(aggregated_metrics)

    try:
        emit_custom_metric_event(scorers, len(eval_items), aggregated_metrics)
    except Exception as e:
        _logger.debug(f"Failed to emit custom metric usage event: {e}", exc_info=True)

    # Search for all traces in the run. We need to fetch the traces from backend here to include
    # all traces in the result.
    traces = mlflow.search_traces(run_id=run_id, include_spans=False, return_type="list")

    # Clean up noisy traces generated during evaluation
    clean_up_extra_traces(traces, eval_start_time)

    return EvaluationResult(
        run_id=run_id,
        result_df=construct_eval_result_df(run_id, traces, eval_results),
        metrics=aggregated_metrics,
    )


def _run_single(
    eval_item: EvalItem,
    scorers: list[Scorer],
    run_id: str | None,
    predict_fn: Callable[..., Any] | None = None,
) -> EvalResult:
    """Run the logic of the eval harness for a single eval item."""
    # Set the MLflow run ID in the context for this thread
    if run_id:
        # Manually set the mlflow_run_id for this context to be the same as was set in
        # the parent thread. This is required because MLflow runs are thread-local.
        ctx = context.get_context()
        ctx.set_mlflow_run_id(run_id)

    # TODO: Support another pattern that are currently supported in the DBX agent harness,
    # which is when traces are given as dataset
    if predict_fn:
        # NB: Setting prediction context let us retrieve the trace by a custom ID. Setting
        # is_evaluate=True disables async trace logging to make sure the trace is available.
        eval_request_id = str(uuid.uuid4())
        with set_prediction_context(Context(request_id=eval_request_id, is_evaluate=True)):
            try:
                eval_item.outputs = predict_fn(eval_item.inputs)
            except Exception as e:
                eval_item.error_message = (
                    f"Failed to invoke the predict_fn with {eval_item.inputs}: {e}"
                )

        eval_item.trace = mlflow.get_trace(eval_request_id, silent=True)
    elif eval_item.trace is not None:
        if _should_clone_trace(eval_item.trace, run_id):
            try:
                trace_id = copy_trace_to_experiment(eval_item.trace.to_dict())
                eval_item.trace = mlflow.get_trace(trace_id)
            except Exception as e:
                eval_item.error_message = f"Failed to clone trace to the current experiment: {e}"
        else:
            MlflowClient().link_traces_to_run([eval_item.trace.info.trace_id], run_id=run_id)
    else:
        # When static dataset (a pair of inputs and outputs) is given, we create a minimal
        # trace with root span only, to log the assessments on it.
        minimal_trace = create_minimal_trace(eval_item)
        eval_item.trace = minimal_trace

    # Execute the scorers
    assessments = _compute_eval_scores(eval_item=eval_item, scorers=scorers)
    assessments.extend(eval_item.get_expectation_assessments())
    eval_result = EvalResult(eval_item=eval_item, assessments=assessments)

    tags = eval_item.tags if not is_none_or_nan(eval_item.tags) else {}
    validate_tags(tags)

    for key in tags.keys() - IMMUTABLE_TAGS:
        try:
            mlflow.set_trace_tag(trace_id=eval_item.trace.info.trace_id, key=key, value=tags[key])
        except Exception as e:
            # Failures in logging to MLflow should not fail the entire harness run
            _logger.warning(f"Failed to log tag {key} to MLflow: {e}")

    try:
        logged_trace = _log_assessments(
            run_id=run_id,
            trace=eval_item.trace,
            assessments=eval_result.assessments,
        )
        eval_result.eval_item.trace = logged_trace
    except Exception as e:
        # Failures in logging to MLflow should not fail the entire harness run
        _logger.warning(f"Failed to log trace and assessments to MLflow: {e}")

    return eval_result


def _compute_eval_scores(
    *,
    eval_item: EvalItem,
    scorers: list[Scorer],
) -> list[Feedback]:
    """Compute the per-eval-item scores."""
    if not scorers:
        return []

    def run_scorer(scorer):
        try:
            scorer_func = scorer.run

            if MLFLOW_GENAI_EVAL_ENABLE_SCORER_TRACING.get():
                scorer_func = mlflow.trace(name=scorer.name, span_type=SpanType.EVALUATOR)(
                    scorer_func
                )

            value = scorer_func(
                inputs=eval_item.inputs,
                outputs=eval_item.outputs,
                expectations=eval_item.expectations,
                trace=eval_item.trace,
            )
            feedbacks = standardize_scorer_value(scorer.name, value)

        except Exception as e:
            feedbacks = [
                Feedback(
                    name=scorer.name,
                    source=make_code_type_assessment_source(scorer.name),
                    error=AssessmentError(
                        error_code="SCORER_ERROR",
                        error_message=str(e),
                        stack_trace=traceback.format_exc(),
                    ),
                )
            ]

        # Record the trace ID for the scorer function call.
        if MLFLOW_GENAI_EVAL_ENABLE_SCORER_TRACING.get() and (
            trace_id := mlflow.get_last_active_trace_id(thread_local=True)
        ):
            for feedback in feedbacks:
                feedback.metadata = {
                    **(feedback.metadata or {}),
                    AssessmentMetadataKey.SCORER_TRACE_ID: trace_id,
                }
            # Set the scorer name tag to the trace to identify the trace is generated by a scorer.
from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Any

from google.protobuf.json_format import MessageToDict

from mlflow.entities._mlflow_object import _MlflowObject
from mlflow.entities.dataset_record_source import DatasetRecordSource, DatasetRecordSourceType
from mlflow.protos.datasets_pb2 import DatasetRecord as ProtoDatasetRecord
from mlflow.protos.datasets_pb2 import DatasetRecordSource as ProtoDatasetRecordSource

# Reserved key for wrapping non-dict outputs when storing in SQL database
DATASET_RECORD_WRAPPED_OUTPUT_KEY = "mlflow_wrapped"


@dataclass
class DatasetRecord(_MlflowObject):
    """Represents a single record in an evaluation dataset.

    A DatasetRecord contains the input data, expected outputs (ground truth),
    and metadata for a single evaluation example. Records are immutable once
    created and are uniquely identified by their dataset_record_id.
    """

    dataset_id: str
    inputs: dict[str, Any]
    dataset_record_id: str
    created_time: int
    last_update_time: int
    outputs: dict[str, Any] | None = None
    expectations: dict[str, Any] | None = None
    tags: dict[str, str] | None = None
    source: DatasetRecordSource | None = None
    source_id: str | None = None
    source_type: str | None = None
    created_by: str | None = None
    last_updated_by: str | None = None

    def __post_init__(self):
        if self.inputs is None:
            raise ValueError("inputs must be provided")

        if self.tags is None:
            self.tags = {}

        if self.source and isinstance(self.source, DatasetRecordSource):
            if not self.source_id:
                if self.source.source_type == DatasetRecordSourceType.TRACE:
                    self.source_id = self.source.source_data.get("trace_id")
                else:
                    self.source_id = self.source.source_data.get("source_id")
            if not self.source_type:
                self.source_type = self.source.source_type.value

    def to_proto(self) -> ProtoDatasetRecord:
        proto = ProtoDatasetRecord()

        proto.dataset_record_id = self.dataset_record_id
        proto.dataset_id = self.dataset_id
        proto.inputs = json.dumps(self.inputs)
        proto.created_time = self.created_time
        proto.last_update_time = self.last_update_time
        if self.outputs is not None:
            proto.outputs = json.dumps(self.outputs)
        if self.expectations is not None:
            proto.expectations = json.dumps(self.expectations)
        if self.tags is not None:
            proto.tags = json.dumps(self.tags)
        if self.source is not None:
            proto.source = json.dumps(self.source.to_dict())
        if self.source_id is not None:
            proto.source_id = self.source_id
        if self.source_type is not None:
            proto.source_type = ProtoDatasetRecordSource.SourceType.Value(self.source_type)
        if self.created_by is not None:
            proto.created_by = self.created_by
        if self.last_updated_by is not None:
            proto.last_updated_by = self.last_updated_by

        return proto

    @classmethod
    def from_proto(cls, proto: ProtoDatasetRecord) -> "DatasetRecord":
        inputs = json.loads(proto.inputs) if proto.HasField("inputs") else {}
        outputs = json.loads(proto.outputs) if proto.HasField("outputs") else None
        expectations = json.loads(proto.expectations) if proto.HasField("expectations") else None
        tags = json.loads(proto.tags) if proto.HasField("tags") else None

        source = None
        if proto.HasField("source"):
            source_dict = json.loads(proto.source)
            source = DatasetRecordSource.from_dict(source_dict)

        return cls(
            dataset_id=proto.dataset_id,
            inputs=inputs,
            dataset_record_id=proto.dataset_record_id,
            created_time=proto.created_time,
tests/genai/evaluate/test_utils.py:495:    def custom_scorer_func(inputs, outputs=None, expectations=None, **kwargs):
tests/genai/test_agent_server.py:174:    invalid_data = {"invalid": "structure"}
tests/genai/test_agent_server.py:177:        validator_responses.validate_and_convert_request(invalid_data)
tests/genai/test_agent_server.py:346:    invalid_data = {"invalid": "structure"}
tests/genai/test_agent_server.py:347:    response = client.post("/invocations", json=invalid_data)
tests/genai/judges/test_make_judge.py:1242:    invalid_data_missing_instructions = {
tests/genai/judges/test_make_judge.py:1256:        Scorer.model_validate(invalid_data_missing_instructions)
tests/genai/judges/test_make_judge.py:1258:    invalid_data_missing_model = {
tests/genai/judges/test_make_judge.py:1272:        Scorer.model_validate(invalid_data_missing_model)
tests/genai/judges/test_make_judge.py:1274:    invalid_data_wrong_type = {
tests/genai/judges/test_make_judge.py:1291:        Scorer.model_validate(invalid_data_wrong_type)
tests/genai/judges/test_make_judge.py:1519:    with pytest.raises(MlflowException, match="'expectations' must be a dictionary, got str"):
tests/genai/judges/test_make_judge.py:1522:    with pytest.raises(MlflowException, match="'expectations' must be a dictionary, got tuple"):
tests/genai/utils/test_trace_utils.py:582:def test_extract_expectations_from_trace_returns_none_when_no_expectations():
tests/genai/optimize/test_util.py:12:    validate_train_data,
tests/genai/optimize/test_util.py:195:def test_validate_train_data_errors(train_data, scorers, expected_error):
tests/genai/optimize/test_util.py:199:        validate_train_data(pd.DataFrame(train_data), scorers, lambda **kwargs: None)
tests/genai/optimize/test_util.py:218:def test_validate_train_data_success(train_data):
tests/genai/optimize/test_util.py:221:    validate_train_data(pd.DataFrame(train_data), [], lambda **kwargs: None)
```

## 原始行 71 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,130p' mlflow/genai/evaluation/entities.py; sed -n '180,235p' tests/genai/optimize/test_util.py; sed -n '480,515p' tests/genai/evaluate/test_utils.py; python -m pytest tests/genai/optimize/test_util.py -q"
```

退出码：`1`

输出：
```
"""Entities for evaluation."""

import hashlib
import json
from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from mlflow.entities.assessment import Expectation, Feedback
from mlflow.entities.assessment_source import AssessmentSource, AssessmentSourceType
from mlflow.entities.trace import Trace
from mlflow.exceptions import MlflowException
from mlflow.genai.evaluation.constant import InputDatasetColumn, ResultDataFrameColumn
from mlflow.genai.evaluation.context import get_context
from mlflow.genai.evaluation.utils import is_none_or_nan


@dataclass
class EvalItem:
    """Represents a row in the evaluation dataset."""

    """Unique identifier for the eval item."""
    request_id: str

    """Raw input to the model/application when `evaluate` is called."""
    inputs: dict[str, Any]

    """Raw output from the model/application."""
    outputs: Any

    """Expectations from the eval item."""
    expectations: dict[str, Any]

    """Tags from the eval item."""
    tags: dict[str, str] | None = None

    """Trace of the model invocation."""
    trace: Trace | None = None

    """Error message if the model invocation fails."""
    error_message: str | None = None

    @classmethod
    def from_dataset_row(cls, row: dict[str, Any]) -> "EvalItem":
        """
        Create an EvalItem from a row of input Pandas Dataframe row.
        """
        if (inputs := row.get(InputDatasetColumn.INPUTS)) is not None:
            inputs = cls._parse_inputs(inputs)
        outputs = row.get(InputDatasetColumn.OUTPUTS)

        # Extract trace column from the dataset.
        trace = row.get(InputDatasetColumn.TRACE)
        if is_none_or_nan(trace):
            trace = None
        else:
            trace = trace if isinstance(trace, Trace) else Trace.from_json(trace)

        # Extract expectations column from the dataset.
        expectations = row.get(InputDatasetColumn.EXPECTATIONS, {})

        # Extract tags column from the dataset.
        tags = row.get(InputDatasetColumn.TAGS, {})

        # Get the request ID from the row, or generate a new unique ID if not present.
        request_id = row.get(InputDatasetColumn.REQUEST_ID)
        if is_none_or_nan(request_id):
            hashable_strings = [
                str(x) for x in [inputs, outputs, trace, expectations] if x is not None
            ]
            # this should not happen, but added a check in case
            if not hashable_strings:
                raise MlflowException.invalid_parameter_value(
                    "Dataset row must contain at least one non-None value"
                )
            request_id = hashlib.sha256(str(hashable_strings[0]).encode()).hexdigest()

        return cls(
            request_id=request_id,
            inputs=inputs,
            outputs=outputs,
            expectations=expectations,
            tags=tags,
            trace=trace,
        )

    @classmethod
    def _parse_inputs(cls, data: str | dict[str, Any]) -> Any:
        # The inputs can be either a dictionary or JSON-serialized version of it.
        if isinstance(data, dict):
            return data
        elif isinstance(data, str):  # JSON-serialized string
            try:
                return json.loads(data)
            except Exception:
                pass
        return data

    def get_expectation_assessments(self) -> list[Expectation]:
        """Get the expectations as a list of Expectation objects."""
        expectations = []
        for name, value in self.expectations.items():
            source_id = get_context().get_user_name()
            expectations.append(
                Expectation(
                    trace_id=self.trace.info.trace_id if self.trace else None,
                    name=name,
                    source=AssessmentSource(
                        source_type=AssessmentSourceType.HUMAN,
                        source_id=source_id or "unknown",
                    ),
                    value=value,
                )
            )
        return expectations

    def to_dict(self) -> dict[str, Any]:
        inputs = {
            ResultDataFrameColumn.REQUEST_ID: self.request_id,
            ResultDataFrameColumn.INPUTS: self.inputs,
            ResultDataFrameColumn.OUTPUTS: self.outputs,
            ResultDataFrameColumn.TRACE: self.trace.to_json() if self.trace else None,
            ResultDataFrameColumn.EXPECTATIONS: self.expectations,
            ResultDataFrameColumn.TAGS: self.tags,
            ResultDataFrameColumn.ERROR_MESSAGE: self.error_message,
        }
        return {k: v for k, v in inputs.items() if v is not None}


    [
        # Empty inputs
        (
            [{"inputs": {}, "outputs": "result"}],
            [],
            "Record 0 is missing required 'inputs' field or it is empty",
        ),
        # Missing inputs
        (
            [{"outputs": "result"}],
            [],
            "Record 0 is missing required 'inputs' field or it is empty",
        ),
    ],
)
def test_validate_train_data_errors(train_data, scorers, expected_error):
    import pandas as pd

    with pytest.raises(MlflowException, match=expected_error):
        validate_train_data(pd.DataFrame(train_data), scorers, lambda **kwargs: None)


@pytest.mark.parametrize(
    "train_data",
    [
        # Valid with outputs
        [{"inputs": {"text": "hello"}, "outputs": "result"}],
        # Valid with expectations
        [{"inputs": {"text": "hello"}, "expectations": {"expected": "result"}}],
        # Multiple valid records
        [
            {"inputs": {"text": "hello"}, "outputs": "result1"},
            {"inputs": {"text": "world"}, "expectations": {"expected": "result2"}},
        ],
        # Falsy but valid values: False as output
        [{"inputs": {"text": "hello"}, "outputs": False}],
    ],
)
def test_validate_train_data_success(train_data):
    import pandas as pd

    validate_train_data(pd.DataFrame(train_data), [], lambda **kwargs: None)

@databricks_only
def test_convert_scorer_to_legacy_metric():
    """Test that _convert_scorer_to_legacy_metric correctly sets _is_builtin_scorer attribute."""
    # Test with a built-in scorer
    builtin_scorer = RelevanceToQuery()
    legacy_metric = _convert_scorer_to_legacy_metric(builtin_scorer)

    # Verify the metric has the _is_builtin_scorer attribute set to True
    assert hasattr(legacy_metric, "_is_builtin_scorer")
    assert legacy_metric._is_builtin_scorer is True
    assert legacy_metric.name == builtin_scorer.name

    # Test with a custom scorer
    @scorer(name="custom_scorer", aggregations=["mean", "max"])
    def custom_scorer_func(inputs, outputs=None, expectations=None, **kwargs):
        return {"score": 1.0}

    custom_scorer_instance = custom_scorer_func
    legacy_metric_custom = _convert_scorer_to_legacy_metric(custom_scorer_instance)

    # Verify the metric has the _is_builtin_scorer attribute set to False
    assert hasattr(legacy_metric_custom, "_is_builtin_scorer")
    assert legacy_metric_custom._is_builtin_scorer is False
    assert legacy_metric_custom.name == custom_scorer_instance.name
    assert legacy_metric_custom.aggregations == custom_scorer_instance.aggregations


@pytest.mark.parametrize(
    "aggregations",
    [
        ["mean", "max", "mean", "median", "variance", "p90"],
        [sum, max],
    ],
)
@databricks_only
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 41 items

tests/genai/optimize/test_util.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 92%]
[0m[32m.[0m[31mF[0m[32m.[0m[31m                                                                      [100%][0m

=================================== FAILURES ===================================
[31m[1m________________ test_validate_train_data_success[train_data2] _________________[0m

train_data = [{'inputs': {'text': 'hello'}, 'outputs': 'result1'}, {'expectations': {'expected': 'result2'}, 'inputs': {'text': 'world'}}]

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        [33m"[39;49;00m[33mtrain_data[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        [[90m[39;49;00m
            [90m# Valid with outputs[39;49;00m[90m[39;49;00m
            [{[33m"[39;49;00m[33minputs[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mtext[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mhello[39;49;00m[33m"[39;49;00m}, [33m"[39;49;00m[33moutputs[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mresult[39;49;00m[33m"[39;49;00m}],[90m[39;49;00m
            [90m# Valid with expectations[39;49;00m[90m[39;49;00m
            [{[33m"[39;49;00m[33minputs[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mtext[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mhello[39;49;00m[33m"[39;49;00m}, [33m"[39;49;00m[33mexpectations[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mexpected[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mresult[39;49;00m[33m"[39;49;00m}}],[90m[39;49;00m
            [90m# Multiple valid records[39;49;00m[90m[39;49;00m
            [[90m[39;49;00m
                {[33m"[39;49;00m[33minputs[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mtext[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mhello[39;49;00m[33m"[39;49;00m}, [33m"[39;49;00m[33moutputs[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mresult1[39;49;00m[33m"[39;49;00m},[90m[39;49;00m
                {[33m"[39;49;00m[33minputs[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mtext[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mworld[39;49;00m[33m"[39;49;00m}, [33m"[39;49;00m[33mexpectations[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mexpected[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mresult2[39;49;00m[33m"[39;49;00m}},[90m[39;49;00m
            ],[90m[39;49;00m
            [90m# Falsy but valid values: False as output[39;49;00m[90m[39;49;00m
            [{[33m"[39;49;00m[33minputs[39;49;00m[33m"[39;49;00m: {[33m"[39;49;00m[33mtext[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mhello[39;49;00m[33m"[39;49;00m}, [33m"[39;49;00m[33moutputs[39;49;00m[33m"[39;49;00m: [94mFalse[39;49;00m}],[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_validate_train_data_success[39;49;00m(train_data):[90m[39;49;00m
        [94mimport[39;49;00m[90m [39;49;00m[04m[96mpandas[39;49;00m[90m [39;49;00m[94mas[39;49;00m[90m [39;49;00m[04m[96mpd[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
>       validate_train_data(pd.DataFrame(train_data), [], [94mlambda[39;49;00m **kwargs: [94mNone[39;49;00m)[90m[39;49;00m

pd         = <module 'pandas' from '/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/pandas/__init__.py'>
train_data = [{'inputs': {'text': 'hello'}, 'outputs': 'result1'}, {'expectations': {'expected': 'result2'}, 'inputs': {'text': 'world'}}]

[1m[31mtests/genai/optimize/test_util.py[0m:221: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/genai/optimize/util.py[0m:92: in validate_train_data
    [0mvalid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)[90m[39;49;00m
        builtin_scorers = []
        i          = 1
        predict_fn = <function test_validate_train_data_success.<locals>.<lambda> at 0x72d508777740>
        record     = {'expectations': {'expected': 'result2'}, 'inputs': {'text': 'world'}, 'outputs': nan}
        scorers    = []
        train_data =               inputs  outputs             expectations
0  {'text': 'hello'}  result1                      NaN
1  {'text': 'world'}      NaN  {'expected': 'result2'}
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

data =               inputs  outputs             expectations
0  {'text': 'hello'}  result1                      NaN
1  {'text': 'world'}      NaN  {'expected': 'result2'}
builtin_scorers = []
predict_fn = <function test_validate_train_data_success.<locals>.<lambda> at 0x72d508777740>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mvalid_data_for_builtin_scorers[39;49;00m([90m[39;49;00m
        data: [33m"[39;49;00m[33mpd.DataFrame[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        builtin_scorers: [96mlist[39;49;00m[BuiltInScorer],[90m[39;49;00m
        predict_fn: Callable[..., Any] | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> [94mNone[39;49;00m:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Validate the columns needed by the requested built-in scorers.[39;49;00m
    [33m[39;49;00m
    [33m    Missing columns are diagnostic only. A malformed ``expectations`` column is[39;49;00m
    [33m    rejected because it cannot be represented by the evaluation schema.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        column_mapping = {[90m[39;49;00m
            [33m"[39;49;00m[33mrequest[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33minputs[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mresponse[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33moutputs[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mexpected_response[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mexpectations/expected_response[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mexpected_facts[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mexpectations/expected_facts[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mexpected_retrieved_context[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mexpectations/expected_retrieved_context[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mguidelines[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mexpectations/guidelines[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
        columns = {column_mapping.get(column, column) [94mfor[39;49;00m column [95min[39;49;00m data.columns}[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [33m"[39;49;00m[33mexpectations[39;49;00m[33m"[39;49;00m [95min[39;49;00m data.columns:[90m[39;49;00m
            expectation_fields: [96mset[39;49;00m[[96mstr[39;49;00m] = [96mset[39;49;00m()[90m[39;49;00m
            [94mfor[39;49;00m index, expectations [95min[39;49;00m data[[33m"[39;49;00m[33mexpectations[39;49;00m[33m"[39;49;00m].items():[90m[39;49;00m
                [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(expectations, [96mdict[39;49;00m):[90m[39;49;00m
>                   [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                        [33m"[39;49;00m[33mThe `expectations` column must contain dictionaries. [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                        [33mf[39;49;00m[33m"[39;49;00m[33mGot [39;49;00m[33m{[39;49;00m[96mtype[39;49;00m(expectations).[91m__name__[39;49;00m[33m}[39;49;00m[33m at row [39;49;00m[33m{[39;49;00mindex[33m}[39;49;00m[33m.[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    )[90m[39;49;00m
[1m[31mE                   mlflow.exceptions.MlflowException: The `expectations` column must contain dictionaries. Got float at row 0.[0m

builtin_scorers = []
column_mapping = {'expected_facts': 'expectations/expected_facts', 'expected_response': 'expectations/expected_response', 'expected_retrieved_context': 'expectations/expected_retrieved_context', 'guidelines': 'expectations/guidelines', ...}
columns    = {'expectations', 'inputs', 'outputs'}
data       =               inputs  outputs             expectations
0  {'text': 'hello'}  result1                      NaN
1  {'text': 'world'}      NaN  {'expected': 'result2'}
expectation_fields = set()
expectations = nan
index      = 0
predict_fn = <function test_validate_train_data_success.<locals>.<lambda> at 0x72d508777740>

[1m[31mmlflow/genai/scorers/validation.py[0m:50: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 04:55:11 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
0.50s setup    tests/genai/optimize/test_util.py::test_infer_primitive_types[None-NoneType]

(9 durations < 0.005s hidden.  Use -vv to show these durations.)
========================= command to run failed tests ==========================
pytest 'tests/genai/optimize/test_util.py::test_validate_train_data_success[train_data2]'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 22.8/33.7 GB | DISK 793.2/915.7 GB[0m tests/genai/optimize/test_util.py::[1mtest_validate_train_data_success[train_data2][0m - mlflow.exceptions.MlflowException: The `expectations` column must contain d...
[31m========================= [31m[1m1 failed[0m, [32m40 passed[0m[31m in 0.69s[0m[31m =========================[0m
```

## 原始行 75 · file_change

```
{
  "id": "item_51",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/scorers/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 78 · file_change

```
{
  "id": "item_53",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/scorers/validation.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 81 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/genai/scorers/base.py | sed -n '990,1090p'; nl -ba mlflow/genai/scorers/validation.py | sed -n '1,230p'; nl -ba mlflow/genai/scorers/builtin_scorers.py | tail -80"
```

退出码：`0`

输出：
```
   990	                scorers=[not_empty, exact_match, num_tool_calls, harmfulness],
   991	            )
   992	    """
   993	
   994	    if func is None:
   995	        return functools.partial(
   996	            scorer, name=name, description=description, aggregations=aggregations
   997	        )
   998	
   999	    if not callable(func):
  1000	        raise MlflowException.invalid_parameter_value(
  1001	            f"`scorer` must decorate a callable function, got {type(func).__name__}."
  1002	        )
  1003	
  1004	    signature = inspect.signature(func)
  1005	    supported_parameters = {"inputs", "outputs", "expectations", "trace"}
  1006	
  1007	    # Extra optional parameters are useful for directly configuring/testing a
  1008	    # scorer. Variadic parameters similarly receive no values from the harness.
  1009	    # Only unsupported, required named parameters make a scorer impossible to call.
  1010	    invalid_parameters = [
  1011	        parameter.name
  1012	        for parameter in signature.parameters.values()
  1013	        if parameter.name not in supported_parameters
  1014	        and parameter.default is inspect.Parameter.empty
  1015	        and parameter.kind
  1016	        not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
  1017	    ]
  1018	    if invalid_parameters:
  1019	        raise MlflowException.invalid_parameter_value(
  1020	            "Scorer functions may only use the parameters `inputs`, `outputs`, "
  1021	            f"`expectations`, and `trace`. Got invalid parameters: {invalid_parameters}."
  1022	        )
  1023	
  1024	    positional_only_parameters = [
  1025	        parameter.name
  1026	        for parameter in signature.parameters.values()
  1027	        if parameter.kind == inspect.Parameter.POSITIONAL_ONLY
  1028	    ]
  1029	    if positional_only_parameters:
  1030	        raise MlflowException.invalid_parameter_value(
  1031	            "Scorer function parameters must be passable by keyword. "
  1032	            f"Got positional-only parameters: {positional_only_parameters}."
  1033	        )
  1034	
  1035	    from mlflow.genai.scorers.validation import validate_aggregations
  1036	
  1037	    validate_aggregations(aggregations)
  1038	
  1039	    class DecoratedScorer(Scorer):
  1040	        @functools.wraps(func)
  1041	        def __call__(self, *args, **kwargs):
  1042	            return func(*args, **kwargs)
  1043	
  1044	        @property
  1045	        def kind(self) -> ScorerKind:
  1046	            return ScorerKind.DECORATOR
  1047	
  1048	    # Scorer.run() introspects this signature to select the row fields passed to
  1049	    # the function. Include ``self`` here because bound-method introspection drops it.
  1050	    call_parameters = [
  1051	        inspect.Parameter("self", kind=inspect.Parameter.POSITIONAL_OR_KEYWORD),
  1052	        *signature.parameters.values(),
  1053	    ]
  1054	    DecoratedScorer.__call__.__signature__ = signature.replace(parameters=call_parameters)
  1055	
  1056	    scorer_instance = DecoratedScorer(
  1057	        name=name or func.__name__,
  1058	        description=description,
  1059	        aggregations=aggregations,
  1060	    )
  1061	    object.__setattr__(scorer_instance, "_original_func", func)
  1062	    return scorer_instance
  1063	
  1064	
  1065	
  1066	
  1067	
  1068	
  1069	
  1070	
  1071	
  1072	
  1073	
  1074	
  1075	
  1076	
  1077	
  1078	
  1079	
  1080	
  1081	
  1082	
  1083	    # Update the __call__ method's signature to match the original function
  1084	    # but add 'self' as the first parameter. This is required for MLflow to
  1085	    # pass the correct set of parameters to the scorer.
  1086	    signature = inspect.signature(func)
  1087	    params = list(signature.parameters.values())
  1088	    new_params = [inspect.Parameter("self", inspect.Parameter.POSITIONAL_OR_KEYWORD)] + params
  1089	    new_signature = signature.replace(parameters=new_params)
  1090	    CustomScorer.__call__.__signature__ = new_signature
     1	import importlib
     2	import logging
     3	from collections import defaultdict
     4	from typing import Any, Callable
     5	
     6	from mlflow.exceptions import MlflowException
     7	from mlflow.genai.scorers.base import AggregationFunc, Scorer
     8	from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException
     9	
    10	
    11	
    12	
    13	
    14	try:
    15	    # `pandas` is not required for `mlflow-skinny`.
    16	    import pandas as pd
    17	except ImportError:
    18	    pass
    19	
    20	_logger = logging.getLogger(__name__)
    21	
    22	
    23	IS_DBX_AGENTS_INSTALLED = importlib.util.find_spec("databricks.agents") is not None
    24	
    25	
    26	def valid_data_for_builtin_scorers(
    27	    data: "pd.DataFrame",
    28	    builtin_scorers: list[BuiltInScorer],
    29	    predict_fn: Callable[..., Any] | None = None,
    30	) -> None:
    31	    """Validate the columns needed by the requested built-in scorers.
    32	
    33	    Missing columns are diagnostic only. A malformed ``expectations`` column is
    34	    rejected because it cannot be represented by the evaluation schema.
    35	    """
    36	    column_mapping = {
    37	        "request": "inputs",
    38	        "response": "outputs",
    39	        "expected_response": "expectations/expected_response",
    40	        "expected_facts": "expectations/expected_facts",
    41	        "expected_retrieved_context": "expectations/expected_retrieved_context",
    42	        "guidelines": "expectations/guidelines",
    43	    }
    44	    columns = {column_mapping.get(column, column) for column in data.columns}
    45	
    46	    if "expectations" in data.columns:
    47	        expectation_fields: set[str] = set()
    48	        for index, expectations in data["expectations"].items():
    49	            # Pandas fills a missing value in a partially populated column with
    50	            # NaN. Treat that the same as an omitted optional expectations value.
    51	            if expectations is None or (
    52	                pd.api.types.is_scalar(expectations) and pd.isna(expectations)
    53	            ):
    54	                continue
    55	            if not isinstance(expectations, dict):
    56	                raise MlflowException.invalid_parameter_value(
    57	                    "The `expectations` column must contain dictionaries. "
    58	                    f"Got {type(expectations).__name__} at row {index}."
    59	                )
    60	            expectation_fields.update(
    61	                f"expectations/{expectation_name}" for expectation_name in expectations
    62	            )
    63	        columns.update(expectation_fields)
    64	
    65	    if predict_fn is not None:
    66	        columns.update({"outputs", "trace"})
    67	    if "trace" in columns:
    68	        columns.update({"inputs", "outputs"})
    69	
    70	    missing_columns_by_scorer: dict[str, list[str]] = defaultdict(list)
    71	    for builtin_scorer in builtin_scorers:
    72	        try:
    73	            builtin_scorer.validate_columns(columns)
    74	        except MissingColumnsException as e:
    75	            missing_columns_by_scorer[e.scorer].extend(map(str, e.missing_columns))
    76	
    77	    if missing_columns_by_scorer:
    78	        diagnostics = "; ".join(
    79	            f"{scorer}: {', '.join(sorted(set(missing_columns)))}"
    80	            for scorer, missing_columns in missing_columns_by_scorer.items()
    81	        )
    82	        _logger.warning(
    83	            "Some built-in scorers are missing required columns and may return null results. "
    84	            "Missing columns by scorer: %s",
    85	            diagnostics,
    86	        )
    87	
    88	
    89	def validate_scorers(scorers: list[Any]) -> list[Scorer]:
    90	    """Validate and return a flat list of scorer instances."""
    91	    if not isinstance(scorers, list):
    92	        raise MlflowException.invalid_parameter_value(
    93	            f"`scorers` must be a list of scorer instances. Got {type(scorers).__name__}."
    94	        )
    95	
    96	    legacy_metric_type = None
    97	    if IS_DBX_AGENTS_INSTALLED:
    98	        try:
    99	            from databricks.rag_eval.evaluation.metrics import Metric
   100	
   101	            legacy_metric_type = Metric
   102	        except ImportError:
   103	            # A partial/incompatible installation should not affect MLflow scorers.
   104	            pass
   105	
   106	    validated = []
   107	    for index, candidate in enumerate(scorers):
   108	        if isinstance(candidate, Scorer):
   109	            validated.append(candidate)
   110	            continue
   111	
   112	        if legacy_metric_type is not None and isinstance(candidate, legacy_metric_type):
   113	            _logger.warning(
   114	                "Passing Databricks legacy Metric objects to `mlflow.genai.evaluate()` is "
   115	                "deprecated. Use an MLflow Scorer instead."
   116	            )
   117	            validated.append(candidate)
   118	            continue
   119	
   120	        if isinstance(candidate, list):
   121	            hint = (
   122	                " `get_all_scorers()` already returns a list; pass "
   123	                "`scorers=get_all_scorers()` instead of `scorers=[get_all_scorers()]`."
   124	            )
   125	        elif isinstance(candidate, type) and issubclass(candidate, Scorer):
   126	            hint = (
   127	                f" Scorer classes must be instantiated; use `{candidate.__name__}()` "
   128	                f"instead of `{candidate.__name__}`."
   129	            )
   130	        else:
   131	            hint = " Each item must be a Scorer instance (for example, `Correctness()`)."
   132	
   133	        raise MlflowException.invalid_parameter_value(
   134	            f"Invalid scorer at index {index}: got {candidate!r}.{hint}"
   135	        )
   136	
   137	    return validated
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	
   210	
   211	
   212	
   213	
   214	
   215	
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
  1544	
  1545	        # Use exact match first
  1546	        if outputs_str == expectations_str:
  1547	            return Feedback(
  1548	                name=self.name,
  1549	                value=CategoricalRating.YES,
  1550	                rationale="Exact string match",
  1551	            )
  1552	
  1553	        # Use LLM judge for semantic equivalence
  1554	
  1555	        model = self.model or get_default_model()
  1556	        assessment_name = self.name or EQUIVALENCE_FEEDBACK_NAME
  1557	
  1558	        prompt = get_prompt(
  1559	            output=outputs_str,
  1560	            expected_output=expectations_str,
  1561	        )
  1562	        feedback = invoke_judge_model(model, prompt, assessment_name=assessment_name)
  1563	
  1564	        return _sanitize_feedback(feedback)
  1565	
  1566	
  1567	
  1568	
  1569	
  1570	
  1571	
  1572	
  1573	
  1574	
  1575	
  1576	
  1577	
  1578	
  1579	
  1580	
  1581	
  1582	
  1583	
  1584	
  1585	
  1586	
  1587	
  1588	
  1589	
  1590	
  1591	
  1592	
  1593	
  1594	
  1595	
  1596	
  1597	
  1598	
  1599	
  1600	def get_all_scorers() -> list[BuiltInScorer]:
  1601	    """Return all built-in scorers available for the current tracking URI."""
  1602	    scorers = [
  1603	        ExpectationsGuidelines(),
  1604	        Correctness(),
  1605	        RelevanceToQuery(),
  1606	        RetrievalSufficiency(),
  1607	        RetrievalGroundedness(),
  1608	        Equivalence(),
  1609	    ]
  1610	
  1611	    if is_databricks_uri(mlflow.get_tracking_uri()):
  1612	        scorers.extend([Safety(), RetrievalRelevance()])
  1613	
  1614	    return scorers
  1615	
  1616	
  1617	class MissingColumnsException(MlflowException):
  1618	    def __init__(self, scorer: str, missing_columns: set[str]):
  1619	        self.scorer = scorer
  1620	        self.missing_columns = list(missing_columns)
  1621	        super().__init__(
  1622	            f"The following columns are required for the scorer {scorer}: {missing_columns}"
  1623	        )
```

## 原始行 84 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/genai/scorers/base.py | sed -n '1078,1145p'; sed -n '1080,1135p' mlflow/genai/scorers/base.py"
```

退出码：`0`

输出：
```
  1078	
  1079	
  1080	
  1081	
  1082	
  1083	    # Update the __call__ method's signature to match the original function
  1084	    # but add 'self' as the first parameter. This is required for MLflow to
  1085	    # pass the correct set of parameters to the scorer.
  1086	    signature = inspect.signature(func)
  1087	    params = list(signature.parameters.values())
  1088	    new_params = [inspect.Parameter("self", inspect.Parameter.POSITIONAL_OR_KEYWORD)] + params
  1089	    new_signature = signature.replace(parameters=new_params)
  1090	    CustomScorer.__call__.__signature__ = new_signature
  1091	
  1092	    return CustomScorer(
  1093	        name=name or func.__name__,
  1094	        description=description,
  1095	        aggregations=aggregations,
  1096	    )



    # Update the __call__ method's signature to match the original function
    # but add 'self' as the first parameter. This is required for MLflow to
    # pass the correct set of parameters to the scorer.
    signature = inspect.signature(func)
    params = list(signature.parameters.values())
    new_params = [inspect.Parameter("self", inspect.Parameter.POSITIONAL_OR_KEYWORD)] + params
    new_signature = signature.replace(parameters=new_params)
    CustomScorer.__call__.__signature__ = new_signature

    return CustomScorer(
        name=name or func.__name__,
        description=description,
        aggregations=aggregations,
    )
```

## 原始行 88 · file_change

```
{
  "id": "item_60",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/scorers/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 91 · command_execution

命令：
```
/bin/bash -lc "black --version || true; python -m pytest tests/genai/optimize/test_util.py::test_validate_train_data_success -q; python - <<'PY'
from mlflow.genai.scorers import scorer
@scorer
def s(inputs, outputs=None, **kwargs): return True
print(s.run(inputs={}), s(inputs={}, foo=1))
PY"
```

退出码：`0`

输出：
```
black, 25.11.0 (compiled: yes)
Python (CPython) 3.11.14
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 4 items

tests/genai/optimize/test_util.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                   [100%][0m

============================= slowest 10 durations =============================
0.50s setup    tests/genai/optimize/test_util.py::test_validate_train_data_success[train_data0]

(9 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m============================== [32m[1m4 passed[0m[32m in 0.53s[0m[32m ===============================[0m
True True
```

## 原始行 94 · command_execution

命令：
```
/bin/bash -lc 'black --check mlflow/genai/scorers/base.py mlflow/genai/scorers/validation.py mlflow/genai/scorers/builtin_scorers.py mlflow/genai/evaluation/base.py mlflow/genai/optimize/util.py'
```

退出码：`1`

输出：
```
would reformat mlflow/genai/scorers/validation.py
would reformat mlflow/genai/optimize/util.py
would reformat mlflow/genai/evaluation/base.py
would reformat mlflow/genai/scorers/base.py
would reformat mlflow/genai/scorers/builtin_scorers.py

Oh no! 💥 💔 💥
5 files would be reformatted.
```

## 原始行 97 · command_execution

命令：
```
/bin/bash -lc 'black mlflow/genai/scorers/base.py mlflow/genai/scorers/validation.py mlflow/genai/scorers/builtin_scorers.py mlflow/genai/evaluation/base.py mlflow/genai/optimize/util.py && git diff --stat && git diff --check'
```

退出码：`0`

输出：
```
reformatted mlflow/genai/scorers/validation.py
reformatted mlflow/genai/optimize/util.py
reformatted mlflow/genai/evaluation/base.py
reformatted mlflow/genai/scorers/base.py
reformatted mlflow/genai/scorers/builtin_scorers.py

All done! ✨ 🍰 ✨
5 files reformatted.
 mlflow/genai/evaluation/base.py         |  20 ++-
 mlflow/genai/optimize/util.py           |  21 ++-
 mlflow/genai/scorers/base.py            | 142 ++++++++++++-----
 mlflow/genai/scorers/builtin_scorers.py |  57 +++----
 mlflow/genai/scorers/validation.py      | 266 ++++++++++++++------------------
 5 files changed, 275 insertions(+), 231 deletions(-)
```

## 原始行 100 · command_execution

命令：
```
/bin/bash -lc "git diff --stat --ignore-blank-lines; git diff -- mlflow/genai/evaluation/base.py mlflow/genai/optimize/util.py | sed -n '1,260p'; git diff -- mlflow/genai/scorers/base.py | sed -n '1,300p'; git diff -- mlflow/genai/scorers/validation.py | sed -n '1,340p'"
```

退出码：`0`

输出：
```
 mlflow/genai/evaluation/base.py         |  20 ++-
 mlflow/genai/optimize/util.py           |  21 ++-
 mlflow/genai/scorers/base.py            | 142 ++++++++++++-----
 mlflow/genai/scorers/builtin_scorers.py |  57 +++----
 mlflow/genai/scorers/validation.py      | 263 ++++++++++++++------------------
 5 files changed, 275 insertions(+), 228 deletions(-)
diff --git a/mlflow/genai/evaluation/base.py b/mlflow/genai/evaluation/base.py
index f3cc5bf..62064c7 100644
--- a/mlflow/genai/evaluation/base.py
+++ b/mlflow/genai/evaluation/base.py
@@ -7,7 +7,9 @@ from typing import TYPE_CHECKING, Any, Callable
 import mlflow
 from mlflow.data.dataset import Dataset
 from mlflow.entities.dataset_input import DatasetInput
-from mlflow.entities.evaluation_dataset import EvaluationDataset as EntityEvaluationDataset
+from mlflow.entities.evaluation_dataset import (
+    EvaluationDataset as EntityEvaluationDataset,
+)
 from mlflow.entities.logged_model_input import LoggedModelInput
 from mlflow.environment_variables import MLFLOW_GENAI_EVAL_MAX_WORKERS
 from mlflow.exceptions import MlflowException
@@ -18,6 +20,10 @@ from mlflow.genai.evaluation.utils import (
 )
 from mlflow.genai.scorers import Scorer
 from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
+from mlflow.genai.scorers.validation import (
+    valid_data_for_builtin_scorers,
+    validate_scorers,
+)
 
 from mlflow.genai.utils.display_utils import display_evaluation_output
 from mlflow.genai.utils.trace_utils import convert_predict_fn
@@ -244,7 +250,9 @@ def evaluate(
     # convert into a pandas dataframe with expected evaluation set schema
     df = data.to_df() if is_managed_dataset else _convert_to_eval_set(data)
 
-    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
+    builtin_scorers = [
+        scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)
+    ]
     valid_data_for_builtin_scorers(df, builtin_scorers, predict_fn)
 
     # "request" column must exist after conversion
@@ -263,7 +271,9 @@ def evaluate(
     data = data if is_managed_dataset else df
 
     if predict_fn:
-        predict_fn = convert_predict_fn(predict_fn=predict_fn, sample_input=sample_input)
+        predict_fn = convert_predict_fn(
+            predict_fn=predict_fn, sample_input=sample_input
+        )
 
     return _run_harness(data, scorers, predict_fn, model_id)
 
@@ -280,7 +290,9 @@ def _run_harness(data, scorers, predict_fn, model_id):
             "The `RAG_EVAL_MAX_WORKERS` environment variable is deprecated. "
             f"Please use `{MLFLOW_GENAI_EVAL_MAX_WORKERS.name}` instead."
         )
-        os.environ[MLFLOW_GENAI_EVAL_MAX_WORKERS.name] = os.environ["RAG_EVAL_MAX_WORKERS"]
+        os.environ[MLFLOW_GENAI_EVAL_MAX_WORKERS.name] = os.environ[
+            "RAG_EVAL_MAX_WORKERS"
+        ]
 
     if isinstance(data, (EvaluationDataset, EntityEvaluationDataset)):
         mlflow_dataset = data
diff --git a/mlflow/genai/optimize/util.py b/mlflow/genai/optimize/util.py
index 91a59dc..4dd1850 100644
--- a/mlflow/genai/optimize/util.py
+++ b/mlflow/genai/optimize/util.py
@@ -8,6 +8,7 @@ from mlflow.entities import Trace
 from mlflow.exceptions import MlflowException
 from mlflow.genai.scorers import Scorer
 from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
+from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
 
 from mlflow.tracking.client import MlflowClient
 
@@ -49,7 +50,9 @@ def prompt_optimization_autolog(
         mlflow.log_param("num_training_samples", num_training_samples)
 
         # Log training dataset as run input
-        dataset = mlflow.data.from_pandas(train_data_df, source="prompt_optimization_train_data")
+        dataset = mlflow.data.from_pandas(
+            train_data_df, source="prompt_optimization_train_data"
+        )
         mlflow.log_input(dataset, context="training")
 
         results = {}
@@ -68,7 +71,9 @@ def prompt_optimization_autolog(
 
 
 def validate_train_data(
-    train_data: "pd.DataFrame", scorers: list[Scorer], predict_fn: Callable[..., Any] | None = None
+    train_data: "pd.DataFrame",
+    scorers: list[Scorer],
+    predict_fn: Callable[..., Any] | None = None,
 ) -> None:
     """
     Validate that training data has required fields for prompt optimization.
@@ -87,7 +92,9 @@ def validate_train_data(
                 f"Record {i} is missing required 'inputs' field or it is empty"
             )
 
-    builtin_scorers = [scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)]
+    builtin_scorers = [
+        scorer for scorer in scorers if isinstance(scorer, BuiltInScorer)
+    ]
     valid_data_for_builtin_scorers(train_data, builtin_scorers, predict_fn)
 
 
@@ -108,7 +115,9 @@ def infer_type_from_value(value: Any, model_name: str = "Output") -> type:
             element_types.add(infer_type_from_value(item))
         return list[functools.reduce(lambda x, y: x | y, element_types)]
     elif isinstance(value, dict):
-        fields = {k: (infer_type_from_value(v, model_name=k), ...) for k, v in value.items()}
+        fields = {
+            k: (infer_type_from_value(v, model_name=k), ...) for k, v in value.items()
+        }
         return create_model(model_name, **fields)
     elif isinstance(value, BaseModel):
         return type(value)
@@ -188,7 +197,9 @@ def create_metric_from_scorers(
         non_convertible = {
             k: type(v).__name__ for k, v in scores.items() if k not in numeric_scores
         }
-        scorer_details = ", ".join([f"{k} (type: {t})" for k, t in non_convertible.items()])
+        scorer_details = ", ".join(
+            [f"{k} (type: {t})" for k, t in non_convertible.items()]
+        )
         raise MlflowException(
             f"Scorers [{scorer_details}] return non-numerical values that cannot be "
             "automatically aggregated. Please provide an `objective` function to aggregate "
diff --git a/mlflow/genai/scorers/base.py b/mlflow/genai/scorers/base.py
index d0cd1cc..bdc9512 100644
--- a/mlflow/genai/scorers/base.py
+++ b/mlflow/genai/scorers/base.py
@@ -55,7 +55,9 @@ class ScorerSamplingConfig:
     filter_string: str | None = None
 
 
-AggregationFunc = Callable[[list[float]], float]  # List of per-row value -> aggregated value
+AggregationFunc = Callable[
+    [list[float]], float
+]  # List of per-row value -> aggregated value
 
 
 @dataclass
@@ -92,7 +94,9 @@ class SerializedScorer:
         has_instructions_fields = self.instructions_judge_pydantic_data is not None
 
         # Count how many field types are present
-        field_count = sum([has_builtin_fields, has_decorator_fields, has_instructions_fields])
+        field_count = sum(
+            [has_builtin_fields, has_decorator_fields, has_instructions_fields]
+        )
 
         if field_count == 0:
             raise ValueError(
@@ -134,7 +138,11 @@ class Scorer(BaseModel):
         if self._registered_backend is None:
             return ScorerStatus.UNREGISTERED
 
-        return ScorerStatus.STARTED if (self.sample_rate or 0) > 0 else ScorerStatus.STOPPED
+        return (
+            ScorerStatus.STARTED
+            if (self.sample_rate or 0) > 0
+            else ScorerStatus.STOPPED
+        )
 
     def __repr__(self) -> str:
         # Get the standard representation from the parent class
@@ -187,7 +195,11 @@ class Scorer(BaseModel):
         """Extract source code information for the original decorated function."""
         from mlflow.genai.scorers.scorer_utils import extract_function_body
 
-        result = {"call_source": None, "call_signature": None, "original_func_name": None}
+        result = {
+            "call_source": None,
+            "call_signature": None,
+            "original_func_name": None,
+        }
 
         # Extract original function source
         call_body, _ = extract_function_body(self._original_func)
@@ -227,7 +239,9 @@ class Scorer(BaseModel):
                 f"Deserializing scorer created with MLflow version: {serialized.mlflow_version}"
             )
         if serialized.serialization_version:
-            _logger.debug(f"Scorer serialization version: {serialized.serialization_version}")
+            _logger.debug(
+                f"Scorer serialization version: {serialized.serialization_version}"
+            )
 
         if serialized.builtin_scorer_class:
             # Import here to avoid circular imports
@@ -236,7 +250,11 @@ class Scorer(BaseModel):
             return BuiltInScorer.model_validate(obj)
 
         # Handle decorator scorers
-        elif serialized.call_source and serialized.call_signature and serialized.original_func_name:
+        elif (
+            serialized.call_source
+            and serialized.call_signature
+            and serialized.original_func_name
+        ):
             return cls._reconstruct_decorator_scorer(serialized)
 
         # Handle InstructionsJudge scorers
@@ -267,9 +285,14 @@ class Scorer(BaseModel):
                 )
 
             feedback_value_type = str  # default to str
-            if "feedback_value_type" in data and data["feedback_value_type"] is not None:
-                feedback_value_type = InstructionsJudge._deserialize_feedback_value_type(
-                    data["feedback_value_type"]
+            if (
+                "feedback_value_type" in data
+                and data["feedback_value_type"] is not None
+            ):
+                feedback_value_type = (
+                    InstructionsJudge._deserialize_feedback_value_type(
+                        data["feedback_value_type"]
+                    )
                 )
 
             try:
@@ -344,7 +367,9 @@ class Scorer(BaseModel):
 
         try:
             recreated_func = recreate_function(
-                serialized.call_source, serialized.call_signature, serialized.original_func_name
+                serialized.call_source,
+                serialized.call_signature,
+                serialized.original_func_name,
             )
         except Exception as e:
             raise MlflowException.invalid_parameter_value(
@@ -389,7 +414,9 @@ class Scorer(BaseModel):
             isinstance(result, (int, float, bool, str, Assessment, LegacyAssessment))
             or (
                 isinstance(result, list)
-                and all(isinstance(item, (Assessment, LegacyAssessment)) for item in result)
+                and all(
+                    isinstance(item, (Assessment, LegacyAssessment)) for item in result
+                )
             )
             # Allow None to represent an empty assessment from the scorer.
             or result is None
@@ -518,13 +545,17 @@ class Scorer(BaseModel):
                     scorers=[NotEmpty(), ExactMatch(), NumToolCalls()],
                 )
         """
-        raise NotImplementedError("Implementation of __call__ is required for Scorer class")
+        raise NotImplementedError(
+            "Implementation of __call__ is required for Scorer class"
+        )
 
     @property
     def kind(self) -> ScorerKind:
         return ScorerKind.CLASS
 
-    def register(self, *, name: str | None = None, experiment_id: str | None = None) -> "Scorer":
+    def register(
+        self, *, name: str | None = None, experiment_id: str | None = None
+    ) -> "Scorer":
         """
         Register this scorer with the MLflow server.
 
@@ -734,7 +765,9 @@ class Scorer(BaseModel):
             experiment_id=experiment_id,
         )
 
-    def stop(self, *, name: str | None = None, experiment_id: str | None = None) -> "Scorer":
+    def stop(
+        self, *, name: str | None = None, experiment_id: str | None = None
+    ) -> "Scorer":
         """
         Stop registered scoring by setting sample rate to 0.
 
@@ -818,7 +851,9 @@ class Scorer(BaseModel):
         # execution risk. Only allow registration when using Databricks tracking URI.
         # Registration itself is safe (just stores code), but we restrict it to Databricks
         # to ensure loaded scorers can only be executed in controlled environments.
-        if self.kind == ScorerKind.DECORATOR and not is_databricks_uri(get_tracking_uri()):
+        if self.kind == ScorerKind.DECORATOR and not is_databricks_uri(
+            get_tracking_uri()
+        ):
             raise MlflowException.invalid_parameter_value(
                 "Custom scorer registration (using @scorer decorator) is not supported "
                 "outside of Databricks tracking environments due to security concerns. "
@@ -996,36 +1031,69 @@ def scorer(
             scorer, name=name, description=description, aggregations=aggregations
         )
 
+    if not callable(func):
+        raise MlflowException.invalid_parameter_value(
+            f"`scorer` must decorate a callable function, got {type(func).__name__}."
+        )
 
+    signature = inspect.signature(func)
+    supported_parameters = {"inputs", "outputs", "expectations", "trace"}
+
+    # Extra optional parameters are useful for directly configuring/testing a
+    # scorer. Variadic parameters similarly receive no values from the harness.
+    # Only unsupported, required named parameters make a scorer impossible to call.
+    invalid_parameters = [
+        parameter.name
+        for parameter in signature.parameters.values()
+        if parameter.name not in supported_parameters
+        and parameter.default is inspect.Parameter.empty
+        and parameter.kind
+        not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
+    ]
+    if invalid_parameters:
+        raise MlflowException.invalid_parameter_value(
+            "Scorer functions may only use the parameters `inputs`, `outputs`, "
+            f"`expectations`, and `trace`. Got invalid parameters: {invalid_parameters}."
+        )
 
+    positional_only_parameters = [
+        parameter.name
+        for parameter in signature.parameters.values()
+        if parameter.kind == inspect.Parameter.POSITIONAL_ONLY
+    ]
+    if positional_only_parameters:
+        raise MlflowException.invalid_parameter_value(
+            "Scorer function parameters must be passable by keyword. "
+            f"Got positional-only parameters: {positional_only_parameters}."
+        )
 
+    from mlflow.genai.scorers.validation import validate_aggregations
 
+    validate_aggregations(aggregations)
 
+    class DecoratedScorer(Scorer):
+        @functools.wraps(func)
+        def __call__(self, *args, **kwargs):
+            return func(*args, **kwargs)
 
+        @property
+        def kind(self) -> ScorerKind:
+            return ScorerKind.DECORATOR
 
+    # Scorer.run() introspects this signature to select the row fields passed to
+    # the function. Include ``self`` here because bound-method introspection drops it.
+    call_parameters = [
+        inspect.Parameter("self", kind=inspect.Parameter.POSITIONAL_OR_KEYWORD),
+        *signature.parameters.values(),
+    ]
+    DecoratedScorer.__call__.__signature__ = signature.replace(
+        parameters=call_parameters
+    )
 
-
-
-
-
-
-
-
-
-
-
-
-    # Update the __call__ method's signature to match the original function
-    # but add 'self' as the first parameter. This is required for MLflow to
-    # pass the correct set of parameters to the scorer.
-    signature = inspect.signature(func)
-    params = list(signature.parameters.values())
-    new_params = [inspect.Parameter("self", inspect.Parameter.POSITIONAL_OR_KEYWORD)] + params
-    new_signature = signature.replace(parameters=new_params)
-    CustomScorer.__call__.__signature__ = new_signature
-
-    return CustomScorer(
+    scorer_instance = DecoratedScorer(
         name=name or func.__name__,
         description=description,
         aggregations=aggregations,
-    )
\ No newline at end of file
+    )
+    object.__setattr__(scorer_instance, "_original_func", func)
+    return scorer_instance
diff --git a/mlflow/genai/scorers/validation.py b/mlflow/genai/scorers/validation.py
index f7f2d13..fc91d8a 100644
--- a/mlflow/genai/scorers/validation.py
+++ b/mlflow/genai/scorers/validation.py
@@ -8,9 +8,6 @@ from mlflow.genai.scorers.base import AggregationFunc, Scorer
 from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException
 
 
-
-
-
 try:
     # `pandas` is not required for `mlflow-skinny`.
     import pandas as pd
@@ -23,155 +20,120 @@ _logger = logging.getLogger(__name__)
 IS_DBX_AGENTS_INSTALLED = importlib.util.find_spec("databricks.agents") is not None
 
 
+def valid_data_for_builtin_scorers(
+    data: "pd.DataFrame",
+    builtin_scorers: list[BuiltInScorer],
+    predict_fn: Callable[..., Any] | None = None,
+) -> None:
+    """Validate the columns needed by the requested built-in scorers.
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+    Missing columns are diagnostic only. A malformed ``expectations`` column is
+    rejected because it cannot be represented by the evaluation schema.
+    """
+    column_mapping = {
+        "request": "inputs",
+        "response": "outputs",
+        "expected_response": "expectations/expected_response",
+        "expected_facts": "expectations/expected_facts",
+        "expected_retrieved_context": "expectations/expected_retrieved_context",
+        "guidelines": "expectations/guidelines",
+    }
+    columns = {column_mapping.get(column, column) for column in data.columns}
+
+    if "expectations" in data.columns:
+        expectation_fields: set[str] = set()
+        for index, expectations in data["expectations"].items():
+            # Pandas fills a missing value in a partially populated column with
+            # NaN. Treat that the same as an omitted optional expectations value.
+            if expectations is None or (
+                pd.api.types.is_scalar(expectations) and pd.isna(expectations)
+            ):
+                continue
+            if not isinstance(expectations, dict):
+                raise MlflowException.invalid_parameter_value(
+                    "The `expectations` column must contain dictionaries. "
+                    f"Got {type(expectations).__name__} at row {index}."
+                )
+            expectation_fields.update(
+                f"expectations/{expectation_name}" for expectation_name in expectations
+            )
+        columns.update(expectation_fields)
+
+    if predict_fn is not None:
+        columns.update({"outputs", "trace"})
+    if "trace" in columns:
+        columns.update({"inputs", "outputs"})
+
+    missing_columns_by_scorer: dict[str, list[str]] = defaultdict(list)
+    for builtin_scorer in builtin_scorers:
+        try:
+            builtin_scorer.validate_columns(columns)
+        except MissingColumnsException as e:
+            missing_columns_by_scorer[e.scorer].extend(map(str, e.missing_columns))
+
+    if missing_columns_by_scorer:
+        diagnostics = "; ".join(
+            f"{scorer}: {', '.join(sorted(set(missing_columns)))}"
+            for scorer, missing_columns in missing_columns_by_scorer.items()
+        )
+        _logger.warning(
+            "Some built-in scorers are missing required columns and may return null results. "
+            "Missing columns by scorer: %s",
+            diagnostics,
+        )
+
+
+def validate_scorers(scorers: list[Any]) -> list[Scorer]:
+    """Validate and return a flat list of scorer instances."""
+    if not isinstance(scorers, list):
+        raise MlflowException.invalid_parameter_value(
+            f"`scorers` must be a list of scorer instances. Got {type(scorers).__name__}."
+        )
+
+    legacy_metric_type = None
+    if IS_DBX_AGENTS_INSTALLED:
+        try:
+            from databricks.rag_eval.evaluation.metrics import Metric
+
+            legacy_metric_type = Metric
+        except ImportError:
+            # A partial/incompatible installation should not affect MLflow scorers.
+            pass
+
+    validated = []
+    for index, candidate in enumerate(scorers):
+        if isinstance(candidate, Scorer):
+            validated.append(candidate)
+            continue
+
+        if legacy_metric_type is not None and isinstance(candidate, legacy_metric_type):
+            _logger.warning(
+                "Passing Databricks legacy Metric objects to `mlflow.genai.evaluate()` is "
+                "deprecated. Use an MLflow Scorer instead."
+            )
+            validated.append(candidate)
+            continue
+
+        if isinstance(candidate, list):
+            hint = (
+                " `get_all_scorers()` already returns a list; pass "
+                "`scorers=get_all_scorers()` instead of `scorers=[get_all_scorers()]`."
+            )
+        elif isinstance(candidate, type) and issubclass(candidate, Scorer):
+            hint = (
+                f" Scorer classes must be instantiated; use `{candidate.__name__}()` "
+                f"instead of `{candidate.__name__}`."
+            )
+        else:
+            hint = (
+                " Each item must be a Scorer instance (for example, `Correctness()`)."
+            )
+
+        raise MlflowException.invalid_parameter_value(
+            f"Invalid scorer at index {index}: got {candidate!r}.{hint}"
+        )
+
+    return validated
 
 
 def validate_aggregations(aggregations: list[str | AggregationFunc] | None) -> None:
@@ -200,4 +162,4 @@ def validate_aggregations(aggregations: list[str | AggregationFunc] | None) -> N
             raise MlflowException.invalid_parameter_value(
                 f"Aggregation must be either a string from {sorted(valid_aggregation_names)} "
                 f"or a callable function, got {type(agg).__name__}"
-            )
\ No newline at end of file
+            )
```

## 原始行 103 · command_execution

命令：
```
/bin/bash -lc 'black --line-length 100 mlflow/genai/scorers/base.py mlflow/genai/scorers/validation.py mlflow/genai/scorers/builtin_scorers.py mlflow/genai/evaluation/base.py mlflow/genai/optimize/util.py; git diff --stat'
```

退出码：`0`

输出：
```
reformatted mlflow/genai/scorers/validation.py
reformatted mlflow/genai/optimize/util.py
reformatted mlflow/genai/evaluation/base.py
reformatted mlflow/genai/scorers/base.py
reformatted mlflow/genai/scorers/builtin_scorers.py

All done! ✨ 🍰 ✨
5 files reformatted.
 mlflow/genai/evaluation/base.py         |   8 +-
 mlflow/genai/optimize/util.py           |   5 +-
 mlflow/genai/scorers/base.py            |  84 +++++++---
 mlflow/genai/scorers/builtin_scorers.py |  44 ++----
 mlflow/genai/scorers/validation.py      | 264 ++++++++++++++------------------
 5 files changed, 197 insertions(+), 208 deletions(-)
```

## 原始行 106 · command_execution

命令：
```
/bin/bash -lc "git diff -- mlflow/genai/evaluation/base.py mlflow/genai/optimize/util.py; git diff -- mlflow/genai/scorers/builtin_scorers.py | sed -n '1,240p'; git diff -- mlflow/genai/scorers/base.py | tail -160"
```

退出码：`0`

输出：
```
diff --git a/mlflow/genai/evaluation/base.py b/mlflow/genai/evaluation/base.py
index f3cc5bf..d0febf8 100644
--- a/mlflow/genai/evaluation/base.py
+++ b/mlflow/genai/evaluation/base.py
@@ -7,7 +7,9 @@ from typing import TYPE_CHECKING, Any, Callable
 import mlflow
 from mlflow.data.dataset import Dataset
 from mlflow.entities.dataset_input import DatasetInput
-from mlflow.entities.evaluation_dataset import EvaluationDataset as EntityEvaluationDataset
+from mlflow.entities.evaluation_dataset import (
+    EvaluationDataset as EntityEvaluationDataset,
+)
 from mlflow.entities.logged_model_input import LoggedModelInput
 from mlflow.environment_variables import MLFLOW_GENAI_EVAL_MAX_WORKERS
 from mlflow.exceptions import MlflowException
@@ -18,6 +20,10 @@ from mlflow.genai.evaluation.utils import (
 )
 from mlflow.genai.scorers import Scorer
 from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
+from mlflow.genai.scorers.validation import (
+    valid_data_for_builtin_scorers,
+    validate_scorers,
+)
 
 from mlflow.genai.utils.display_utils import display_evaluation_output
 from mlflow.genai.utils.trace_utils import convert_predict_fn
diff --git a/mlflow/genai/optimize/util.py b/mlflow/genai/optimize/util.py
index 91a59dc..e865b22 100644
--- a/mlflow/genai/optimize/util.py
+++ b/mlflow/genai/optimize/util.py
@@ -8,6 +8,7 @@ from mlflow.entities import Trace
 from mlflow.exceptions import MlflowException
 from mlflow.genai.scorers import Scorer
 from mlflow.genai.scorers.builtin_scorers import BuiltInScorer
+from mlflow.genai.scorers.validation import valid_data_for_builtin_scorers
 
 from mlflow.tracking.client import MlflowClient
 
@@ -68,7 +69,9 @@ def prompt_optimization_autolog(
 
 
 def validate_train_data(
-    train_data: "pd.DataFrame", scorers: list[Scorer], predict_fn: Callable[..., Any] | None = None
+    train_data: "pd.DataFrame",
+    scorers: list[Scorer],
+    predict_fn: Callable[..., Any] | None = None,
 ) -> None:
     """
     Validate that training data has required fields for prompt optimization.
diff --git a/mlflow/genai/scorers/builtin_scorers.py b/mlflow/genai/scorers/builtin_scorers.py
index e501d45..c6bd49f 100644
--- a/mlflow/genai/scorers/builtin_scorers.py
+++ b/mlflow/genai/scorers/builtin_scorers.py
@@ -1564,37 +1564,21 @@ class Equivalence(BuiltInScorer):
         return _sanitize_feedback(feedback)
 
 
+def get_all_scorers() -> list[BuiltInScorer]:
+    """Return all built-in scorers available for the current tracking URI."""
+    scorers = [
+        ExpectationsGuidelines(),
+        Correctness(),
+        RelevanceToQuery(),
+        RetrievalSufficiency(),
+        RetrievalGroundedness(),
+        Equivalence(),
+    ]
 
+    if is_databricks_uri(mlflow.get_tracking_uri()):
+        scorers.extend([Safety(), RetrievalRelevance()])
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+    return scorers
 
 
 class MissingColumnsException(MlflowException):
@@ -1603,4 +1587,4 @@ class MissingColumnsException(MlflowException):
         self.missing_columns = list(missing_columns)
         super().__init__(
             f"The following columns are required for the scorer {scorer}: {missing_columns}"
-        )
\ No newline at end of file
+        )
diff --git a/mlflow/genai/scorers/base.py b/mlflow/genai/scorers/base.py
index d0cd1cc..8a20830 100644
--- a/mlflow/genai/scorers/base.py
+++ b/mlflow/genai/scorers/base.py
@@ -187,7 +187,11 @@ class Scorer(BaseModel):
         """Extract source code information for the original decorated function."""
         from mlflow.genai.scorers.scorer_utils import extract_function_body
 
-        result = {"call_source": None, "call_signature": None, "original_func_name": None}
+        result = {
+            "call_source": None,
+            "call_signature": None,
+            "original_func_name": None,
+        }
 
         # Extract original function source
         call_body, _ = extract_function_body(self._original_func)
@@ -344,7 +348,9 @@ class Scorer(BaseModel):
 
         try:
             recreated_func = recreate_function(
-                serialized.call_source, serialized.call_signature, serialized.original_func_name
+                serialized.call_source,
+                serialized.call_signature,
+                serialized.original_func_name,
             )
         except Exception as e:
             raise MlflowException.invalid_parameter_value(
@@ -996,36 +1002,66 @@ def scorer(
             scorer, name=name, description=description, aggregations=aggregations
         )
 
+    if not callable(func):
+        raise MlflowException.invalid_parameter_value(
+            f"`scorer` must decorate a callable function, got {type(func).__name__}."
+        )
 
+    signature = inspect.signature(func)
+    supported_parameters = {"inputs", "outputs", "expectations", "trace"}
+
+    # Extra optional parameters are useful for directly configuring/testing a
+    # scorer. Variadic parameters similarly receive no values from the harness.
+    # Only unsupported, required named parameters make a scorer impossible to call.
+    invalid_parameters = [
+        parameter.name
+        for parameter in signature.parameters.values()
+        if parameter.name not in supported_parameters
+        and parameter.default is inspect.Parameter.empty
+        and parameter.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
+    ]
+    if invalid_parameters:
+        raise MlflowException.invalid_parameter_value(
+            "Scorer functions may only use the parameters `inputs`, `outputs`, "
+            f"`expectations`, and `trace`. Got invalid parameters: {invalid_parameters}."
+        )
 
+    positional_only_parameters = [
+        parameter.name
+        for parameter in signature.parameters.values()
+        if parameter.kind == inspect.Parameter.POSITIONAL_ONLY
+    ]
+    if positional_only_parameters:
+        raise MlflowException.invalid_parameter_value(
+            "Scorer function parameters must be passable by keyword. "
+            f"Got positional-only parameters: {positional_only_parameters}."
+        )
 
+    from mlflow.genai.scorers.validation import validate_aggregations
 
+    validate_aggregations(aggregations)
 
+    class DecoratedScorer(Scorer):
+        @functools.wraps(func)
+        def __call__(self, *args, **kwargs):
+            return func(*args, **kwargs)
 
+        @property
+        def kind(self) -> ScorerKind:
+            return ScorerKind.DECORATOR
 
+    # Scorer.run() introspects this signature to select the row fields passed to
+    # the function. Include ``self`` here because bound-method introspection drops it.
+    call_parameters = [
+        inspect.Parameter("self", kind=inspect.Parameter.POSITIONAL_OR_KEYWORD),
+        *signature.parameters.values(),
+    ]
+    DecoratedScorer.__call__.__signature__ = signature.replace(parameters=call_parameters)
 
-
-
-
-
-
-
-
-
-
-
-
-    # Update the __call__ method's signature to match the original function
-    # but add 'self' as the first parameter. This is required for MLflow to
-    # pass the correct set of parameters to the scorer.
-    signature = inspect.signature(func)
-    params = list(signature.parameters.values())
-    new_params = [inspect.Parameter("self", inspect.Parameter.POSITIONAL_OR_KEYWORD)] + params
-    new_signature = signature.replace(parameters=new_params)
-    CustomScorer.__call__.__signature__ = new_signature
-
-    return CustomScorer(
+    scorer_instance = DecoratedScorer(
         name=name or func.__name__,
         description=description,
         aggregations=aggregations,
-    )
\ No newline at end of file
+    )
+    object.__setattr__(scorer_instance, "_original_func", func)
+    return scorer_instance
```

## 原始行 109 · file_change

```
{
  "id": "item_74",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/evaluation/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/genai/optimize/util.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/genai/scorers/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 113 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from mlflow.genai.scorers import scorer
@scorer
def x(outputs): return outputs
c=x._create_copy()
print(c.run(outputs='ok'), c._original_func)
print(x.__pydantic_private__)
PY
python -m pytest tests/genai/scorers/test_scorer_description.py tests/genai/scorers/test_serialization.py tests/genai/optimize/test_util.py tests/genai/scorers/test_builtin_scorers.py::test_get_all_scorers_oss -q"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
  File "/testbed/mlflow/genai/scorers/base.py", line 796, in _create_copy
    self._check_can_be_registered(
  File "/testbed/mlflow/genai/scorers/base.py", line 822, in _check_can_be_registered
    raise MlflowException.invalid_parameter_value(
mlflow.exceptions.MlflowException: Custom scorer registration (using @scorer decorator) is not supported outside of Databricks tracking environments due to security concerns. Custom scorers require arbitrary code execution during deserialization.

To use custom scorers:
1. Configure MLflow to use a Databricks tracking URI, or
2. Manage your custom scorer code in a source code repository (e.g., GitHub) and import it directly, or
3. Use built-in scorers or make_judge() scorers instead
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 77 items

tests/genai/scorers/test_scorer_description.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m            [ 18%][0m
tests/genai/scorers/test_serialization.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m           [ 44%][0m
tests/genai/optimize/test_util.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 93%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m                                                                      [ 97%][0m
tests/genai/scorers/test_builtin_scorers.py [32m.[0m[32m.[0m[32m                           [100%][0m

============================= slowest 10 durations =============================
0.63s setup    tests/genai/scorers/test_scorer_description.py::test_decorator_scorer_with_description
0.02s call     tests/genai/scorers/test_scorer_description.py::test_make_judge_with_description[test_judge-Evaluates response quality]
0.01s call     tests/genai/scorers/test_serialization.py::test_decorator_scorer_serialization_format

(7 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m============================== [32m[1m77 passed[0m[32m in 0.91s[0m[32m ==============================[0m
```

## 原始行 118 · file_change

```
{
  "id": "item_81",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/scorers/base.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/genai/scorers/validation.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 121 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from mlflow.genai.scorers import scorer
from mlflow.exceptions import MlflowException
@scorer
def x(outputs): return outputs
c=x.model_copy(deep=True)
print(c.run(outputs='ok'), c._original_func, x.__pydantic_private__)
try:
 scorer(aggregations='mean')(lambda outputs: True)
except MlflowException as e:
 print(e)
PY
git diff --check; git status --short; python -m compileall -q mlflow/genai/scorers mlflow/genai/evaluation/base.py mlflow/genai/optimize/util.py"
```

退出码：`0`

输出：
```
ok <bound method x of CustomScorer(name='x', aggregations=None, description=None, sample_rate=None, filter_string=None)> {'_cached_dump': None, '_sampling_config': None, '_registered_backend': None, '_original_func': <function x at 0x7f20d69344a0>}
`aggregations` must be a list, got str
 M mlflow/genai/evaluation/base.py
 M mlflow/genai/optimize/util.py
 M mlflow/genai/scorers/base.py
 M mlflow/genai/scorers/builtin_scorers.py
 M mlflow/genai/scorers/validation.py
```

## 原始行 124 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from mlflow.genai.scorers import scorer
@scorer
def x(outputs): return outputs
print(type(x._original_func), inspect.signature(x._original_func))
print(x.model_dump()['call_signature'])
PY"
```

退出码：`1`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 6, in <module>
  File "/testbed/mlflow/genai/scorers/base.py", line 170, in model_dump
<class 'method'> ()
    source_info = self._extract_source_code_info()
                  ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/mlflow/genai/scorers/base.py", line 193, in _extract_source_code_info
    call_body, _ = extract_function_body(self._original_func)
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/mlflow/genai/scorers/scorer_utils.py", line 66, in extract_function_body
    source_lines, _ = inspect.getsourcelines(func)
                      ^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/inspect.py", line 1240, in getsourcelines
    lines, lnum = findsource(object)
                  ^^^^^^^^^^^^^^^^^^
  File "/opt/miniconda3/envs/testbed/lib/python3.11/inspect.py", line 1077, in findsource
    raise OSError('could not get source code')
OSError: could not get source code
```

## 原始行 127 · file_change

```
{
  "id": "item_87",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/genai/scorers/base.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 129 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from mlflow.genai.scorers import scorer
@scorer
def x(outputs): return outputs
print(type(x._original_func), inspect.signature(x._original_func), x.__pydantic_private__)
c=x.model_copy(deep=True)
print(type(c._original_func), inspect.signature(c._original_func))
PY
python -m pytest tests/genai/scorers/test_serialization.py tests/genai/scorers/test_scorer_description.py -q"
```

退出码：`0`

输出：
```
<class 'function'> (outputs) {'_cached_dump': None, '_sampling_config': None, '_registered_backend': None, '_original_func': <function x at 0x70c30ad284a0>}
<class 'function'> (outputs)
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 34 items

tests/genai/scorers/test_serialization.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m           [ 58%][0m
tests/genai/scorers/test_scorer_description.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m            [100%][0m

============================= slowest 10 durations =============================
0.42s setup    tests/genai/scorers/test_serialization.py::test_decorator_scorer_serialization_format
0.01s call     tests/genai/scorers/test_scorer_description.py::test_make_judge_with_description[test_judge-Evaluates response quality]

(8 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m============================== [32m[1m34 passed[0m[32m in 0.52s[0m[32m ==============================[0m
```

## 原始行 132 · agent_message

```
The decorator execution issue is fixed, including optional configuration parameters and `**kwargs`, and the schema validator now correctly treats pandas-generated `NaN` as an omitted optional expectation while still rejecting real malformed values. I also restored the missing imports in both evaluation and prompt optimization consumers. The focused serialization, scorer metadata, built-in-set, and optimization validation tests are passing.
```

## 原始行 134 · agent_message

```
The broader scorer/optimization suite is still running cleanly so far; it is currently in the slower built-in judge tests. No new failures have appeared.
```

## 原始行 136 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/genai/scorers tests/genai/optimize/test_util.py -q'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 241 items

tests/genai/scorers/test_aggregation.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                   [  5%][0m
tests/genai/scorers/test_builtin_scorers.py [32m.[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 17%]
[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                       [ 31%][0m
tests/genai/scorers/test_builtin_scorers_registration.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m  [ 37%][0m
tests/genai/scorers/test_registered_scorers_scheduling.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 43%]
[0m[32m.[0m[32m.[0m[32m                                                                       [ 43%][0m
tests/genai/scorers/test_scorer.py [33ms[0m[33ms[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m   [ 58%][0m
tests/genai/scorers/test_scorer_CRUD.py [32m.[0m[32m.[0m[32m                               [ 59%][0m
tests/genai/scorers/test_scorer_description.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m            [ 65%][0m
tests/genai/scorers/test_scorer_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m         [ 74%][0m
tests/genai/scorers/test_serialization.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m           [ 82%][0m
tests/genai/optimize/test_util.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 98%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m                                                                      [100%][0m

============================= slowest 10 durations =============================
4.33s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-42]
3.95s setup    tests/genai/scorers/test_builtin_scorers.py::test_retrieval_groundedness
3.91s call     tests/genai/scorers/test_builtin_scorers_registration.py::test_non_databricks_backend_allows_any_model[RetrievalRelevance-openai:/gpt-4-retrieval_relevance]
3.77s call     tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics[oss-dummy_scorer0]
3.75s call     tests/genai/scorers/test_scorer.py::test_scorer_existence_in_metrics[oss-dummy_scorer1]
3.70s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-42.0]
3.69s call     tests/genai/scorers/test_scorer.py::test_scorer_name_works[oss-dummy_scorer1]
3.66s setup    tests/genai/scorers/test_builtin_scorers.py::test_expectations_guidelines_fallback_with_trace
3.65s call     tests/genai/scorers/test_scorer.py::test_scorer_name_works[oss-dummy_scorer0]
3.63s call     tests/genai/scorers/test_scorer.py::test_scorer_on_genai_evaluate[oss-yes]

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                                       | Duration | Tests | Min    | Max    | Avg    |
| ---- | ---------------------------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/genai/scorers/test_builtin_scorers.py`              | 109.16s  | 62    | 0.001s | 3.947s | 1.761s |
| 2    | `tests/genai/scorers/test_scorer.py`                       | 44.20s   | 35    | 0.001s | 4.331s | 1.263s |
| 3    | `tests/genai/scorers/test_builtin_scorers_registration.py` | 14.11s   | 14    | 0.002s | 3.909s | 1.008s |
| 4    | `tests/genai/scorers/test_scorer_CRUD.py`                  | 1.92s    | 2     | 0.004s | 1.912s | 0.958s |

::endgroup::

[32m================= [32m[1m221 passed[0m, [33m20 skipped[0m[32m in 170.18s (0:02:50)[0m[32m ==================[0m
```

## 原始行 139 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/genai/evaluate/test_evaluation.py -q'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 53 items

tests/genai/evaluate/test_evaluation.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[33ms[0m[32m.[0m[33m [ 60%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                                                    [100%][0m

[33m=============================== warnings summary ===============================[0m
../opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/middleware/wsgi.py:15
  /opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/middleware/wsgi.py:15: DeprecationWarning: starlette.middleware.wsgi is deprecated and will be removed in a future release. Please refer to https://github.com/abersheeran/a2wsgi as a replacement.
    warnings.warn(

tests/genai/evaluate/test_evaluation.py::test_evaluate_without_inputs_in_eval_dataset
tests/genai/evaluate/test_evaluation.py::test_evaluate_without_inputs_in_eval_dataset
  /testbed/mlflow/genai/evaluation/harness.py:72: UserWarning: DataFrame columns are not unique, some columns will be omitted.
    eval_items = [EvalItem.from_dataset_row(row) for row in eval_df.to_dict(orient="records")]

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
5.38s setup    tests/genai/evaluate/test_evaluation.py::test_evaluate_with_static_dataset[local_file]
4.00s call     tests/genai/evaluate/test_evaluation.py::test_evaluate_with_managed_dataset_from_searched_traces
3.36s call     tests/genai/evaluate/test_evaluation.py::test_evaluate_with_managed_dataset[oss]
2.98s call     tests/genai/evaluate/test_evaluation.py::test_evaluate_without_inputs_in_eval_dataset
2.34s call     tests/genai/evaluate/test_evaluation.py::test_model_from_deployment_endpoint[oss]
2.29s call     tests/genai/evaluate/test_evaluation.py::test_max_workers_env_var
2.26s call     tests/genai/evaluate/test_evaluation.py::test_eval_with_traces_log_spans_correctly[False]
2.17s call     tests/genai/evaluate/test_evaluation.py::test_evaluate_with_tags[tags_data1-expected_calls1]
2.07s call     tests/genai/evaluate/test_evaluation.py::test_evaluate_with_tags[tags_data0-expected_calls0]
2.00s call     tests/genai/evaluate/test_evaluation.py::test_evaluate_with_only_trace_in_eval_dataset

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                      | Duration | Tests | Min    | Max    | Avg    |
| ---- | ----------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/genai/evaluate/test_evaluation.py` | 68.08s   | 53    | 0.001s | 5.712s | 1.284s |

::endgroup::

[33m============= [32m46 passed[0m, [33m[1m7 skipped[0m, [33m[1m3 warnings[0m[33m in 69.77s (0:01:09)[0m[33m =============[0m
```

## 原始行 142 · command_execution

命令：
```
/bin/bash -lc "git diff --check; git diff --stat; git status --short; sed -n '990,1085p' mlflow/genai/scorers/base.py; sed -n '1,190p' mlflow/genai/scorers/validation.py; tail -55 mlflow/genai/scorers/builtin_scorers.py"
```

退出码：`0`

输出：
```
 mlflow/genai/evaluation/base.py         |   4 +
 mlflow/genai/optimize/util.py           |   1 +
 mlflow/genai/scorers/base.py            |  70 +++++---
 mlflow/genai/scorers/builtin_scorers.py |  44 ++----
 mlflow/genai/scorers/validation.py      | 272 ++++++++++++++------------------
 5 files changed, 189 insertions(+), 202 deletions(-)
 M mlflow/genai/evaluation/base.py
 M mlflow/genai/optimize/util.py
 M mlflow/genai/scorers/base.py
 M mlflow/genai/scorers/builtin_scorers.py
 M mlflow/genai/scorers/validation.py
                scorers=[not_empty, exact_match, num_tool_calls, harmfulness],
            )
    """

    if func is None:
        return functools.partial(
            scorer, name=name, description=description, aggregations=aggregations
        )

    if not callable(func):
        raise MlflowException.invalid_parameter_value(
            f"`scorer` must decorate a callable function, got {type(func).__name__}."
        )

    signature = inspect.signature(func)
    supported_parameters = {"inputs", "outputs", "expectations", "trace"}

    # Extra optional parameters are useful for directly configuring/testing a
    # scorer. Variadic parameters similarly receive no values from the harness.
    # Only unsupported, required named parameters make a scorer impossible to call.
    invalid_parameters = [
        parameter.name
        for parameter in signature.parameters.values()
        if parameter.name not in supported_parameters
        and parameter.default is inspect.Parameter.empty
        and parameter.kind not in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD)
    ]
    if invalid_parameters:
        raise MlflowException.invalid_parameter_value(
            "Scorer functions may only use the parameters `inputs`, `outputs`, "
            f"`expectations`, and `trace`. Got invalid parameters: {invalid_parameters}."
        )

    positional_only_parameters = [
        parameter.name
        for parameter in signature.parameters.values()
        if parameter.kind == inspect.Parameter.POSITIONAL_ONLY
    ]
    if positional_only_parameters:
        raise MlflowException.invalid_parameter_value(
            "Scorer function parameters must be passable by keyword. "
            f"Got positional-only parameters: {positional_only_parameters}."
        )

    from mlflow.genai.scorers.validation import validate_aggregations

    validate_aggregations(aggregations)

    class CustomScorer(Scorer):
        _original_func: Callable = PrivateAttr(default_factory=lambda: func)

        @functools.wraps(func)
        def __call__(self, *args, **kwargs):
            return func(*args, **kwargs)

        @property
        def kind(self) -> ScorerKind:
            return ScorerKind.DECORATOR

    # Scorer.run() introspects this signature to select the row fields passed to
    # the function. Include ``self`` here because bound-method introspection drops it.
    call_parameters = [
        inspect.Parameter("self", kind=inspect.Parameter.POSITIONAL_OR_KEYWORD),
        *signature.parameters.values(),
    ]
    CustomScorer.__call__.__signature__ = signature.replace(parameters=call_parameters)

    return CustomScorer(
        name=name or func.__name__,
        description=description,
        aggregations=aggregations,
    )
import importlib
import logging
from collections import defaultdict
from typing import Any, Callable

from mlflow.exceptions import MlflowException
from mlflow.genai.scorers.base import AggregationFunc, Scorer
from mlflow.genai.scorers.builtin_scorers import BuiltInScorer, MissingColumnsException


try:
    # `pandas` is not required for `mlflow-skinny`.
    import pandas as pd
except ImportError:
    pass

_logger = logging.getLogger(__name__)


IS_DBX_AGENTS_INSTALLED = importlib.util.find_spec("databricks.agents") is not None


def valid_data_for_builtin_scorers(
    data: "pd.DataFrame",
    builtin_scorers: list[BuiltInScorer],
    predict_fn: Callable[..., Any] | None = None,
) -> None:
    """Validate the columns needed by the requested built-in scorers.

    Missing columns are diagnostic only. A malformed ``expectations`` column is
    rejected because it cannot be represented by the evaluation schema.
    """
    column_mapping = {
        "request": "inputs",
        "response": "outputs",
        "expected_response": "expectations/expected_response",
        "expected_facts": "expectations/expected_facts",
        "expected_retrieved_context": "expectations/expected_retrieved_context",
        "guidelines": "expectations/guidelines",
    }
    columns = {column_mapping.get(column, column) for column in data.columns}

    if "expectations" in data.columns:
        expectation_fields: set[str] = set()
        for index, expectations in data["expectations"].items():
            # Pandas fills a missing value in a partially populated column with
            # NaN. Treat that the same as an omitted optional expectations value.
            if expectations is None or (
                pd.api.types.is_scalar(expectations) and pd.isna(expectations)
            ):
                continue
            if not isinstance(expectations, dict):
                raise MlflowException.invalid_parameter_value(
                    "The `expectations` column must contain dictionaries. "
                    f"Got {type(expectations).__name__} at row {index}."
                )
            expectation_fields.update(
                f"expectations/{expectation_name}" for expectation_name in expectations
            )
        columns.update(expectation_fields)

    if predict_fn is not None:
        columns.update({"outputs", "trace"})
    if "trace" in columns:
        columns.update({"inputs", "outputs"})

    missing_columns_by_scorer: dict[str, list[str]] = defaultdict(list)
    for builtin_scorer in builtin_scorers:
        try:
            builtin_scorer.validate_columns(columns)
        except MissingColumnsException as e:
            missing_columns_by_scorer[e.scorer].extend(map(str, e.missing_columns))

    if missing_columns_by_scorer:
        diagnostics = "; ".join(
            f"{scorer}: {', '.join(sorted(set(missing_columns)))}"
            for scorer, missing_columns in missing_columns_by_scorer.items()
        )
        _logger.warning(
            "Some built-in scorers are missing required columns and may return null results. "
            "Missing columns by scorer: %s",
            diagnostics,
        )


def validate_scorers(scorers: list[Any]) -> list[Scorer]:
    """Validate and return a flat list of scorer instances."""
    if not isinstance(scorers, list):
        raise MlflowException.invalid_parameter_value(
            f"`scorers` must be a list of scorer instances. Got {type(scorers).__name__}."
        )

    legacy_metric_type = None
    if IS_DBX_AGENTS_INSTALLED:
        try:
            from databricks.rag_eval.evaluation.metrics import Metric

            legacy_metric_type = Metric
        except ImportError:
            # A partial/incompatible installation should not affect MLflow scorers.
            pass

    validated = []
    for index, candidate in enumerate(scorers):
        if isinstance(candidate, Scorer):
            validated.append(candidate)
            continue

        if legacy_metric_type is not None and isinstance(candidate, legacy_metric_type):
            _logger.warning(
                "Passing Databricks legacy Metric objects to `mlflow.genai.evaluate()` is "
                "deprecated. Use an MLflow Scorer instead."
            )
            validated.append(candidate)
            continue

        if isinstance(candidate, list):
            hint = (
                " `get_all_scorers()` already returns a list; pass "
                "`scorers=get_all_scorers()` instead of `scorers=[get_all_scorers()]`."
            )
        elif isinstance(candidate, type) and issubclass(candidate, Scorer):
            hint = (
                f" Scorer classes must be instantiated; use `{candidate.__name__}()` "
                f"instead of `{candidate.__name__}`."
            )
        else:
            hint = " Each item must be a Scorer instance (for example, `Correctness()`)."

        raise MlflowException.invalid_parameter_value(
            f"Invalid scorer at index {index}: got {candidate!r}.{hint}"
        )

    return validated


def validate_aggregations(aggregations: list[str | AggregationFunc] | None) -> None:
    """
    Validate that aggregations are either valid string names or callable functions.

    Args:
        aggregations: List of aggregation functions to validate. Can be strings from
                     the standard set or callable functions.
    """
    if aggregations is None:
        return

    if not isinstance(aggregations, list):
        raise MlflowException.invalid_parameter_value(
            f"`aggregations` must be a list, got {type(aggregations).__name__}"
        )

    if not aggregations:
        return

    from mlflow.genai.scorers.aggregation import _AGGREGATE_FUNCTIONS

    valid_aggregation_names = set(_AGGREGATE_FUNCTIONS.keys())

    for agg in aggregations:
        if isinstance(agg, str):
            if agg not in valid_aggregation_names:
                raise MlflowException.invalid_parameter_value(
                    f"Invalid aggregation '{agg}'. Valid aggregations are: "
                    f"{sorted(valid_aggregation_names)}"
                )
        elif not callable(agg):
            raise MlflowException.invalid_parameter_value(
                f"Aggregation must be either a string from {sorted(valid_aggregation_names)} "
                f"or a callable function, got {type(agg).__name__}"
            )
                    name=self.name,
                    value=CategoricalRating.NO,
                    rationale=f"Values do not match: {actual_output} != {expected_output}",
                )

        # Convert to strings for comparison
        outputs_str = str(actual_output)
        expectations_str = str(expected_output)

        # Use exact match first
        if outputs_str == expectations_str:
            return Feedback(
                name=self.name,
                value=CategoricalRating.YES,
                rationale="Exact string match",
            )

        # Use LLM judge for semantic equivalence

        model = self.model or get_default_model()
        assessment_name = self.name or EQUIVALENCE_FEEDBACK_NAME

        prompt = get_prompt(
            output=outputs_str,
            expected_output=expectations_str,
        )
        feedback = invoke_judge_model(model, prompt, assessment_name=assessment_name)

        return _sanitize_feedback(feedback)


def get_all_scorers() -> list[BuiltInScorer]:
    """Return all built-in scorers available for the current tracking URI."""
    scorers = [
        ExpectationsGuidelines(),
        Correctness(),
        RelevanceToQuery(),
        RetrievalSufficiency(),
        RetrievalGroundedness(),
        Equivalence(),
    ]

    if is_databricks_uri(mlflow.get_tracking_uri()):
        scorers.extend([Safety(), RetrievalRelevance()])

    return scorers


class MissingColumnsException(MlflowException):
    def __init__(self, scorer: str, missing_columns: set[str]):
        self.scorer = scorer
        self.missing_columns = list(missing_columns)
        super().__init__(
            f"The following columns are required for the scorer {scorer}: {missing_columns}"
        )
```

## 原始行 146 · agent_message

```
Implemented MLflow GenAI scorer definition and validation helpers.

Key additions:

- Custom `@scorer` construction, signature validation, metadata, aggregations, and serialization support.
- Built-in scorer data-column validation with legacy schema mapping and nested expectations.
- Scorer-list validation with actionable nesting/class errors and legacy Databricks metric support.
- Tracking-URI-dependent `get_all_scorers()`.
- Missing validation imports in evaluation and optimization consumers.

Validation completed:

- Scorer and optimization suite: `221 passed, 20 skipped`
- Evaluation suite: `46 passed, 7 skipped`
- Compilation and `git diff --check` passed.
```
