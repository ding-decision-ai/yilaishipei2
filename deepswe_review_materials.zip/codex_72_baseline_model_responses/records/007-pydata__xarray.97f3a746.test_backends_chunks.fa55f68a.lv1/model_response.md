# Codex baseline: pydata__xarray.97f3a746.test_backends_chunks.fa55f68a.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 3 · agent_message

```
I’ll inspect the existing backend chunk code and its tests, then implement the three interfaces and run the focused test set plus related backend tests.
```

## 原始行 5 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' xarray/backends/chunks.py && rg -n \"align_nd_chunks|build_grid_chunks|grid_rechunk\" ."
```

退出码：`127`

输出：
```
import numpy as np

from xarray.core.datatree import Variable




















































































































































































def validate_grid_chunks_alignment(
    nd_v_chunks: tuple[tuple[int, ...], ...] | None,
    enc_chunks: tuple[int, ...],
    backend_shape: tuple[int, ...],
    region: tuple[slice, ...],
    allow_partial_chunks: bool,
    name: str,
):
    if nd_v_chunks is None:
        return
    base_error = (
        "Specified Zarr chunks encoding['chunks']={enc_chunks!r} for "
        "variable named {name!r} would overlap multiple Dask chunks. "
        "Please check the Dask chunks at position {v_chunk_pos} and "
        "{v_chunk_pos_next}, on axis {axis}, they are overlapped "
        "on the same Zarr chunk in the region {region}. "
        "Writing this array in parallel with Dask could lead to corrupted data. "
        "To resolve this issue, consider one of the following options: "
        "- Rechunk the array using `chunk()`. "
        "- Modify or delete `encoding['chunks']`. "
        "- Set `safe_chunks=False`. "
        "- Enable automatic chunks alignment with `align_chunks=True`."
    )

    for axis, chunk_size, v_chunks, interval, size in zip(
        range(len(enc_chunks)),
        enc_chunks,
        nd_v_chunks,
        region,
        backend_shape,
        strict=True,
    ):
        for i, chunk in enumerate(v_chunks[1:-1]):
            if chunk % chunk_size:
                raise ValueError(
                    base_error.format(
                        v_chunk_pos=i + 1,
                        v_chunk_pos_next=i + 2,
                        v_chunk_size=chunk,
                        axis=axis,
                        name=name,
                        chunk_size=chunk_size,
                        region=interval,
                        enc_chunks=enc_chunks,
                    )
                )

        interval_start = interval.start or 0

        if len(v_chunks) > 1:
            # The first border size is the amount of data that needs to be updated on the
            # first chunk taking into account the region slice.
            first_border_size = chunk_size
            if allow_partial_chunks:
                first_border_size = chunk_size - interval_start % chunk_size

            if (v_chunks[0] - first_border_size) % chunk_size:
                raise ValueError(
                    base_error.format(
                        v_chunk_pos=0,
                        v_chunk_pos_next=0,
                        v_chunk_size=v_chunks[0],
                        axis=axis,
                        name=name,
                        chunk_size=chunk_size,
                        region=interval,
                        enc_chunks=enc_chunks,
                    )
                )

        if not allow_partial_chunks:
            region_stop = interval.stop or size

            error_on_last_chunk = base_error.format(
                v_chunk_pos=len(v_chunks) - 1,
                v_chunk_pos_next=len(v_chunks) - 1,
                v_chunk_size=v_chunks[-1],
/bin/bash: line 1: rg: command not found
```

## 原始行 7 · agent_message

```
The target module has placeholders removed above the existing validation helper, and `rg` is unavailable here, so I’m switching to repository-local `grep`/`find` to trace tests and call sites.
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc "sed -n '260,520p' xarray/backends/chunks.py; grep -R -n --exclude-dir=.git -E \"align_nd_chunks|build_grid_chunks|grid_rechunk\" xarray tests 2>/dev/null | head -300; find tests -iname '*chunk*' -o -iname '*zarr*'"
```

退出码：`1`

输出：
```
                v_chunk_size=v_chunks[-1],
                axis=axis,
                name=name,
                chunk_size=chunk_size,
                region=interval,
                enc_chunks=enc_chunks,
            )
            if interval_start % chunk_size:
                # The last chunk which can also be the only one is a partial chunk
                # if it is not aligned at the beginning
                raise ValueError(error_on_last_chunk)

            if np.ceil(region_stop / chunk_size) == np.ceil(size / chunk_size):
                # If the region is covering the last chunk then check
                # if the reminder with the default chunk size
                # is equal to the size of the last chunk
                if v_chunks[-1] % chunk_size != size % chunk_size:
                    raise ValueError(error_on_last_chunk)
            elif v_chunks[-1] % chunk_size:
                raise ValueError(error_on_last_chunk)xarray/backends/zarr.py:1239:                v = grid_rechunk(
find: ‘tests’: No such file or directory
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "find . -maxdepth 3 -type f | head -100; sed -n '1,100p' xarray/backends/zarr.py; sed -n '1200,1260p' xarray/backends/zarr.py; grep -R -n --exclude-dir=.git \"validate_grid_chunks_alignment\" . | head -100; grep -R -n --exclude-dir=.git \"build_grid\" . | head -100"
```

退出码：`0`

输出：
```
./xarray/coders.py
./xarray/convert.py
./xarray/coding/cftimeindex.py
./xarray/coding/common.py
./xarray/coding/calendar_ops.py
./xarray/coding/variables.py
./xarray/coding/frequencies.py
./xarray/coding/times.py
./xarray/coding/strings.py
./xarray/coding/__init__.py
./xarray/coding/cftime_offsets.py
./xarray/py.typed
./xarray/core/indexing.py
./xarray/core/formatting_html.py
./xarray/core/datatree.py
./xarray/core/dataarray.py
./xarray/core/treenode.py
./xarray/core/_typed_ops.py
./xarray/core/extension_array.py
./xarray/core/variable.py
./xarray/core/parallel.py
./xarray/core/groupby.py
./xarray/core/dtypes.py
./xarray/core/options.py
./xarray/core/common.py
./xarray/core/datatree_render.py
./xarray/core/dataset.py
./xarray/core/nputils.py
./xarray/core/dataset_utils.py
./xarray/core/coordinates.py
./xarray/core/coordinate_transform.py
./xarray/core/duck_array_ops.py
./xarray/core/formatting.py
./xarray/core/resample_cftime.py
./xarray/core/missing.py
./xarray/core/types.py
./xarray/core/indexes.py
./xarray/core/accessor_str.py
./xarray/core/utils.py
./xarray/core/extensions.py
./xarray/core/accessor_dt.py
./xarray/core/dataset_variables.py
./xarray/core/resample.py
./xarray/core/__init__.py
./xarray/core/datatree_mapping.py
./xarray/core/_aggregations.py
./xarray/typing.py
./xarray/backends/chunks.py
./xarray/backends/scipy_.py
./xarray/backends/plugins.py
./xarray/backends/lru_cache.py
./xarray/backends/zarr.py
./xarray/backends/writers.py
./xarray/backends/netCDF4_.py
./xarray/backends/common.py
./xarray/backends/netcdf3.py
./xarray/backends/api.py
./xarray/backends/store.py
./xarray/backends/memory.py
./xarray/backends/locks.py
./xarray/backends/h5netcdf_.py
./xarray/backends/file_manager.py
./xarray/backends/pydap_.py
./xarray/backends/__init__.py
./xarray/computation/ops.py
./xarray/computation/computation.py
./xarray/computation/arithmetic.py
./xarray/computation/nanops.py
./xarray/computation/apply_ufunc.py
./xarray/computation/fit.py
./xarray/computation/rolling_exp.py
./xarray/computation/__init__.py
./xarray/computation/rolling.py
./xarray/computation/weighted.py
./xarray/testing/__init__.py
./xarray/testing/strategies.py
./xarray/testing/assertions.py
./xarray/tutorial.py
./xarray/util/generate_aggregations.py
./xarray/util/generate_ops.py
./xarray/util/deprecation_helpers.py
./xarray/util/print_versions.py
./xarray/util/__init__.py
./xarray/plot/facetgrid.py
./xarray/plot/dataset_plot.py
./xarray/plot/dataarray_plot.py
./xarray/plot/accessor.py
./xarray/plot/utils.py
./xarray/plot/__init__.py
./xarray/tests/test_backends.py
./xarray/tests/test_assertions.py
./xarray/tests/test_cftimeindex_resample.py
./xarray/tests/test_dask.py
./xarray/tests/test_coordinate_transform.py
./xarray/tests/test_dataset.py
./xarray/tests/test_backends_api.py
./xarray/tests/test_variable.py
./xarray/tests/test_dtypes.py
./xarray/tests/test_interp.py
./xarray/tests/test_accessor_dt.py
from __future__ import annotations

import base64
import json
import os
import struct
from collections.abc import Hashable, Iterable, Mapping
from typing import TYPE_CHECKING, Any, Literal, Self, cast

import numpy as np
import pandas as pd

from xarray import coding, conventions
from xarray.backends.chunks import validate_grid_chunks_alignment
from xarray.backends.common import (
    BACKEND_ENTRYPOINTS,
    AbstractWritableDataStore,
    BackendArray,
    BackendEntrypoint,
    T_PathFileOrDataStore,
    _encode_variable_name,
    _normalize_path,
    datatree_from_dict_with_io_cleanup,
    ensure_dtype_not_object,
)
from xarray.backends.store import StoreBackendEntrypoint
from xarray.core import indexing
from xarray.core.treenode import NodePath
from xarray.core.types import ZarrWriteModes
from xarray.core.utils import (
    FrozenDict,
    HiddenKeyDict,
    attempt_import,
    close_on_error,
    emit_user_level_warning,
)
from xarray.core.variable import Variable
from xarray.namedarray.parallelcompat import guess_chunkmanager
from xarray.namedarray.pycompat import integer_types
from xarray.namedarray.utils import module_available

if TYPE_CHECKING:
    from xarray.core.dataset import Dataset
    from xarray.core.datatree import DataTree
    from xarray.core.types import ZarrArray, ZarrGroup


def _get_mappers(*, storage_options, store, chunk_store):
    # expand str and path-like arguments
    store = _normalize_path(store)
    chunk_store = _normalize_path(chunk_store)

    kwargs = {}
    if storage_options is None:
        mapper = store
        chunk_mapper = chunk_store
    else:
        if not isinstance(store, str):
            raise ValueError(
                f"store must be a string to use storage_options. Got {type(store)}"
            )

        if _zarr_v3():
            kwargs["storage_options"] = storage_options
            mapper = store
            chunk_mapper = chunk_store
        else:
            from fsspec import get_mapper

            mapper = get_mapper(store, **storage_options)
            if chunk_store is not None:
                chunk_mapper = get_mapper(chunk_store, **storage_options)
            else:
                chunk_mapper = chunk_store
    return kwargs, mapper, chunk_mapper


def _choose_default_mode(
    *,
    mode: ZarrWriteModes | None,
    append_dim: Hashable | None,
    region: Mapping[str, slice | Literal["auto"]] | Literal["auto"] | None,
) -> ZarrWriteModes:
    if mode is None:
        if append_dim is not None:
            mode = "a"
        elif region is not None:
            mode = "r+"
        else:
            mode = "w-"

    if mode not in ["a", "a-"] and append_dim is not None:
        raise ValueError("cannot set append_dim unless mode='a' or mode=None")

    if mode not in ["a", "a-", "r+"] and region is not None:
        raise ValueError(
            "cannot set region unless mode='a', mode='a-', mode='r+' or mode=None"
        )

    if mode not in ["w", "w-", "a", "a-", "r+"]:
            zarr_shape = None
            write_region = self._write_region if self._write_region is not None else {}
            write_region = {dim: write_region.get(dim, slice(None)) for dim in dims}

            if self._mode != "w" and name in existing_keys:
                # existing variable
                zarr_array = self._open_existing_array(name=name)
                if self._append_dim is not None and self._append_dim in dims:
                    # resize existing variable
                    append_axis = dims.index(self._append_dim)
                    assert write_region[self._append_dim] == slice(None)
                    write_region[self._append_dim] = slice(
                        zarr_array.shape[append_axis], None
                    )

                    new_shape = (
                        zarr_array.shape[:append_axis]
                        + (zarr_array.shape[append_axis] + v.shape[append_axis],)
                        + zarr_array.shape[append_axis + 1 :]
                    )
                    zarr_array.resize(new_shape)

                zarr_shape = zarr_array.shape
            region = tuple(write_region[dim] for dim in dims)

            # We need to do this for both new and existing variables to ensure we're not
            # writing to a partial chunk, even though we don't use the `encoding` value
            # when writing to an existing variable. See
            # https://github.com/pydata/xarray/issues/8371 for details.
            # Note: Ideally there should be two functions, one for validating the chunks and
            # another one for extracting the encoding.
            encoding = extract_zarr_variable_encoding(
                v,
                raise_on_invalid=vn in check_encoding_set,
                name=vn,
                zarr_format=3 if is_zarr_v3_format else 2,
            )

            if self._align_chunks and isinstance(encoding["chunks"], tuple):
                v = grid_rechunk(
                    v=v,
                    enc_chunks=encoding["chunks"],
                    region=region,
                )

            if self._safe_chunks and isinstance(encoding["chunks"], tuple):
                # the hard case
                # DESIGN CHOICE: do not allow multiple dask chunks on a single zarr chunk
                # this avoids the need to get involved in zarr synchronization / locking
                # From zarr docs:
                #  "If each worker in a parallel computation is writing to a
                #   separate region of the array, and if region boundaries are perfectly aligned
                #   with chunk boundaries, then no synchronization is required."
                # TODO: incorporate synchronizer to allow writes from multiple dask
                # threads
                shape = zarr_shape or v.shape
                validate_grid_chunks_alignment(
                    nd_v_chunks=v.chunks,
                    enc_chunks=encoding["chunks"],
                    region=region,
                    allow_partial_chunks=self._mode != "r+",
./xarray/backends/chunks.py:184:def validate_grid_chunks_alignment(
./xarray/backends/zarr.py:14:from xarray.backends.chunks import validate_grid_chunks_alignment
./xarray/backends/zarr.py:1256:                validate_grid_chunks_alignment(
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "find xarray/tests -type f \\( -iname '*zarr*' -o -iname '*chunk*' \\) -print; grep -R -n -E \"align_chunks|grid_rechunk|build_grid_chunks|validate_grid_chunks\" xarray/tests | head -400; sed -n '1,230p' xarray/backends/chunks.py"
```

退出码：`0`

输出：
```
xarray/tests/test_backends.py:6812:    def test_dataarray_to_zarr_align_chunks_true(self, tmp_store) -> None:
xarray/tests/test_backends.py:6826:            align_chunks=True,
xarray/tests/test_backends.py:7985:    def test_dataset_to_zarr_align_chunks_true(self, tmp_store) -> None:
xarray/tests/test_backends.py:7986:        # This test is a replica of the one in `test_dataarray_to_zarr_align_chunks_true`
xarray/tests/test_backends.py:8005:                align_chunks=True,
xarray/tests/test_backends.py:8027:                align_chunks=True,
import numpy as np

from xarray.core.datatree import Variable




















































































































































































def validate_grid_chunks_alignment(
    nd_v_chunks: tuple[tuple[int, ...], ...] | None,
    enc_chunks: tuple[int, ...],
    backend_shape: tuple[int, ...],
    region: tuple[slice, ...],
    allow_partial_chunks: bool,
    name: str,
):
    if nd_v_chunks is None:
        return
    base_error = (
        "Specified Zarr chunks encoding['chunks']={enc_chunks!r} for "
        "variable named {name!r} would overlap multiple Dask chunks. "
        "Please check the Dask chunks at position {v_chunk_pos} and "
        "{v_chunk_pos_next}, on axis {axis}, they are overlapped "
        "on the same Zarr chunk in the region {region}. "
        "Writing this array in parallel with Dask could lead to corrupted data. "
        "To resolve this issue, consider one of the following options: "
        "- Rechunk the array using `chunk()`. "
        "- Modify or delete `encoding['chunks']`. "
        "- Set `safe_chunks=False`. "
        "- Enable automatic chunks alignment with `align_chunks=True`."
    )

    for axis, chunk_size, v_chunks, interval, size in zip(
        range(len(enc_chunks)),
        enc_chunks,
        nd_v_chunks,
        region,
        backend_shape,
        strict=True,
    ):
        for i, chunk in enumerate(v_chunks[1:-1]):
            if chunk % chunk_size:
                raise ValueError(
                    base_error.format(
                        v_chunk_pos=i + 1,
                        v_chunk_pos_next=i + 2,
                        v_chunk_size=chunk,
                        axis=axis,
                        name=name,
                        chunk_size=chunk_size,
                        region=interval,
                        enc_chunks=enc_chunks,
                    )
                )
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^version'"\\|current_version' pyproject.toml xarray/__init__.py; sed -n '6780,6855p' xarray/tests/test_backends.py; sed -n '7960,8050p' xarray/tests/test_backends.py; grep -R -n \"chunks.py\" xarray/tests | head -100; grep -R -n \"from xarray.backends.chunks\" xarray/tests | head -100"
```

退出码：`0`

输出：
```
            np.arange(12).reshape((3, 4)), dims=["x", "y"], name="x"
        )

        original_da.to_zarr(tmp_store)

        with open_dataarray(tmp_store, engine="zarr") as loaded_da:
            assert_identical(original_da, loaded_da)

    def test_open_dataarray_options(self, tmp_store) -> None:
        self.skip_if_zarr_python_3_and_zip_store(tmp_store)
        data = DataArray(np.arange(5), coords={"y": ("x", range(1, 6))}, dims=["x"])

        data.to_zarr(tmp_store)

        expected = data.drop_vars("y")
        with open_dataarray(tmp_store, engine="zarr", drop_variables=["y"]) as loaded:
            assert_identical(expected, loaded)

    @requires_dask
    def test_dataarray_to_zarr_compute_false(self, tmp_store) -> None:
        from dask.delayed import Delayed

        skip_if_zarr_format_3(tmp_store)
        original_da = DataArray(np.arange(12).reshape((3, 4)))

        output = original_da.to_zarr(tmp_store, compute=False)
        assert isinstance(output, Delayed)
        output.compute()
        with open_dataarray(tmp_store, engine="zarr") as loaded_da:
            assert_identical(original_da, loaded_da)

    @requires_dask
    def test_dataarray_to_zarr_align_chunks_true(self, tmp_store) -> None:
        # TODO: Improve data integrity checks when using Dask.
        #   Detecting automatic alignment issues in Dask can be tricky,
        #   as unintended misalignment might lead to subtle data corruption.
        #   For now, ensure that the parameter is present, but explore
        #   more robust verification methods to confirm data consistency.

        skip_if_zarr_format_3(tmp_store)
        arr = DataArray(
            np.arange(4), dims=["a"], coords={"a": np.arange(4)}, name="foo"
        ).chunk(a=(2, 1, 1))

        arr.to_zarr(
            tmp_store,
            align_chunks=True,
            encoding={"foo": {"chunks": (3,)}},
        )
        with open_dataarray(tmp_store, engine="zarr") as loaded_da:
            assert_identical(arr, loaded_da)


@requires_scipy_or_netCDF4
def test_no_warning_from_dask_effective_get() -> None:
    with create_tmp_file() as tmpfile:
        with assert_no_warnings():
            ds = Dataset()
            ds.to_netcdf(tmpfile)


@requires_scipy_or_netCDF4
def test_source_encoding_always_present() -> None:
    # Test for GH issue #2550.
    rnddata = np.random.randn(10)
    original = Dataset({"foo": ("x", rnddata)})
    with create_tmp_file() as tmp:
        original.to_netcdf(tmp)
        with open_dataset(tmp) as ds:
            assert ds.encoding["source"] == tmp


@requires_scipy_or_netCDF4
def test_source_encoding_always_present_with_pathlib() -> None:
    # Test for GH issue #5888.
    rnddata = np.random.randn(10)
                # If the chunk is of size equal to the one in the Zarr encoding, but
                # it is partially writing in the first chunk then raise an error
                self.save(
                    store,
                    arr.isel(a=slice(8, None)).chunk(a=3),
                    region="auto",
                    mode="r+",
                )

            with pytest.raises(ValueError):
                self.save(
                    store, arr.isel(a=slice(5, -1)).chunk(a=5), region="auto", mode="r+"
                )

            # Test if the code is detecting the last chunk correctly
            data = np.random.default_rng(0).random((2920, 25, 53))
            ds = xr.Dataset({"temperature": (("time", "lat", "lon"), data)})
            chunks = {"time": 1000, "lat": 25, "lon": 53}
            self.save(store, ds.chunk(chunks), compute=False, mode="w")
            region = {"time": slice(1000, 2000, 1)}
            chunk = ds.isel(region)
            chunk = chunk.chunk()
            self.save(store, chunk.chunk(), region=region)

    @requires_dask
    def test_dataset_to_zarr_align_chunks_true(self, tmp_store) -> None:
        # This test is a replica of the one in `test_dataarray_to_zarr_align_chunks_true`
        # but for datasets
        with self.create_zarr_target() as store:
            ds = (
                DataArray(
                    np.arange(4).reshape((2, 2)),
                    dims=["a", "b"],
                    coords={
                        "a": np.arange(2),
                        "b": np.arange(2),
                    },
                )
                .chunk(a=(1, 1), b=(1, 1))
                .to_dataset(name="foo")
            )

            self.save(
                store,
                ds,
                align_chunks=True,
                encoding={"foo": {"chunks": (3, 3)}},
                mode="w",
            )
            assert_identical(ds, xr.open_zarr(store))

            ds = (
                DataArray(
                    np.arange(4, 8).reshape((2, 2)),
                    dims=["a", "b"],
                    coords={
                        "a": np.arange(2),
                        "b": np.arange(2),
                    },
                )
                .chunk(a=(1, 1), b=(1, 1))
                .to_dataset(name="foo")
            )

            self.save(
                store,
                ds,
                align_chunks=True,
                region="auto",
            )
            assert_identical(ds, xr.open_zarr(store))


@requires_h5netcdf
@requires_fsspec
def test_h5netcdf_storage_options() -> None:
    with create_tmp_files(2, allow_cleanup_failure=ON_WINDOWS) as (f1, f2):
        ds1 = create_test_data()
        ds1.to_netcdf(f1, engine="h5netcdf")

        ds2 = create_test_data()
        ds2.to_netcdf(f2, engine="h5netcdf")

        files = [f"file://{f}" for f in [f1, f2]]
        with xr.open_mfdataset(
            files,
            engine="h5netcdf",
            concat_dim="time",
            data_vars="all",
            combine="nested",
            storage_options={"skip_instance_cache": False},
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def chunk(\" xarray/core/variable.py xarray/core/dataset.py xarray/core/dataarray.py | head -20; sed -n '2550,2650p' xarray/core/variable.py; grep -R -n \"rechunk\" xarray/backends xarray/tests | head -200; grep -n \"align_chunks\" xarray/backends/zarr.py | head -40"
```

退出码：`0`

输出：
```
xarray/core/variable.py:2657:    def chunk(  # type: ignore[override]
xarray/core/variable.py:2791:    def chunk(
xarray/core/dataset.py:2475:    def chunk(
xarray/core/dataarray.py:1402:    def chunk(
        skipna: bool | None = None,
    ) -> Variable | dict[Hashable, Variable]:
        """Index or indices of the minimum of the Variable over one or more dimensions.
        If a sequence is passed to 'dim', then result returned as dict of Variables,
        which can be passed directly to isel(). If a single str is passed to 'dim' then
        returns a Variable with dtype int.

        If there are multiple minima, the indices of the first one found will be
        returned.

        Parameters
        ----------
        dim : "...", str, Iterable of Hashable or None, optional
            The dimensions over which to find the minimum. By default, finds minimum over
            all dimensions - for now returning an int for backward compatibility, but
            this is deprecated, in future will return a dict with indices for all
            dimensions; to return a dict with all dimensions now, pass '...'.
        axis : int, optional
            Axis over which to apply `argmin`. Only one of the 'dim' and 'axis' arguments
            can be supplied.
        keep_attrs : bool, optional
            If True, the attributes (`attrs`) will be copied from the original
            object to the new one.  If False (default), the new object will be
            returned without attributes.
        skipna : bool, optional
            If True, skip missing values (as marked by NaN). By default, only
            skips missing values for float dtypes; other dtypes either do not
            have a sentinel missing value (int) or skipna=True has not been
            implemented (object, datetime64 or timedelta64).

        Returns
        -------
        result : Variable or dict of Variable

        See Also
        --------
        DataArray.argmin, DataArray.idxmin
        """
        return self._unravel_argminmax("argmin", dim, axis, keep_attrs, skipna)

    def argmax(
        self,
        dim: Dims = None,
        axis: int | None = None,
        keep_attrs: bool | None = None,
        skipna: bool | None = None,
    ) -> Variable | dict[Hashable, Variable]:
        """Index or indices of the maximum of the Variable over one or more dimensions.
        If a sequence is passed to 'dim', then result returned as dict of Variables,
        which can be passed directly to isel(). If a single str is passed to 'dim' then
        returns a Variable with dtype int.

        If there are multiple maxima, the indices of the first one found will be
        returned.

        Parameters
        ----------
        dim : "...", str, Iterable of Hashable or None, optional
            The dimensions over which to find the maximum. By default, finds maximum over
            all dimensions - for now returning an int for backward compatibility, but
            this is deprecated, in future will return a dict with indices for all
            dimensions; to return a dict with all dimensions now, pass '...'.
        axis : int, optional
            Axis over which to apply `argmin`. Only one of the 'dim' and 'axis' arguments
            can be supplied.
        keep_attrs : bool, optional
            If True, the attributes (`attrs`) will be copied from the original
            object to the new one.  If False (default), the new object will be
            returned without attributes.
        skipna : bool, optional
            If True, skip missing values (as marked by NaN). By default, only
            skips missing values for float dtypes; other dtypes either do not
            have a sentinel missing value (int) or skipna=True has not been
            implemented (object, datetime64 or timedelta64).

        Returns
        -------
        result : Variable or dict of Variable

        See Also
        --------
        DataArray.argmax, DataArray.idxmax
        """
        return self._unravel_argminmax("argmax", dim, axis, keep_attrs, skipna)

    def _as_sparse(self, sparse_format=_default, fill_value=_default) -> Variable:
        """
        Use sparse-array as backend.
        """
        from xarray.namedarray._typing import _default as _default_named

        if sparse_format is _default:
            sparse_format = _default_named

        if fill_value is _default:
            fill_value = _default_named

        out = super()._as_sparse(sparse_format, fill_value)
        return cast("Variable", out)

    def _to_dense(self) -> Variable:
xarray/backends/zarr.py:308:                "Consider rechunking using `chunk()`."
xarray/backends/zarr.py:314:                "Consider either rechunking using `chunk()` or instead deleting "
xarray/backends/zarr.py:1239:                v = grid_rechunk(
xarray/tests/test_backends.py:2785:            rechunked = original.chunk(chunks=i)
xarray/tests/test_backends.py:2791:                    # chunk size should be the same as rechunked
xarray/tests/test_backends.py:2792:                    assert v.chunks == rechunked[k].chunks
xarray/tests/test_backends.py:2795:        rechunked = original.chunk(chunks=chunks)
xarray/tests/test_backends.py:2803:                assert v.chunks == rechunked[k].chunks
xarray/tests/test_backends.py:2808:                    assert v.chunks == rechunked[k].chunks
xarray/tests/test_dask.py:106:            rechunked = self.lazy_var.chunk(chunks)
xarray/tests/test_dask.py:107:            assert rechunked.chunks == expected
xarray/tests/test_dask.py:108:            self.assertLazyAndIdentical(self.eager_var, rechunked)
xarray/tests/test_dask.py:111:            assert rechunked.chunksizes == expected_chunksizes
xarray/tests/test_dask.py:364:            rechunked = self.lazy_array.chunk(chunks)
xarray/tests/test_dask.py:365:            assert rechunked.chunks == expected
xarray/tests/test_dask.py:366:            self.assertLazyAndIdentical(self.eager_array, rechunked)
xarray/tests/test_dask.py:369:            assert rechunked.chunksizes == expected_chunksizes
xarray/tests/test_dask.py:375:            rechunked = lazy_dataset.chunk(chunks)  # type: ignore[assignment]
xarray/tests/test_dask.py:378:            assert rechunked.chunks == expected_chunksizes
xarray/tests/test_dask.py:379:            self.assertLazyAndIdentical(eager_dataset, rechunked)
xarray/tests/test_dask.py:381:            assert rechunked.chunksizes == expected_chunksizes
xarray/tests/test_dask.py:383:    def test_rechunk(self):
xarray/tests/test_dask.py:1159:    expected = obj.data.rechunk("auto")
xarray/tests/test_dask.py:1174:    expected = da.data.rechunk({0: 10, 1: 120})
xarray/tests/test_dataset.py:1167:        rechunked = ds.chunk(
xarray/tests/test_dataset.py:1170:        assert rechunked.chunksizes["x"] == (2,) * 5
xarray/tests/test_dataset.py:1171:        assert len(rechunked.chunksizes["time"]) == 9
xarray/tests/test_dataset.py:1172:        assert rechunked.chunksizes["x"] == (2,) * 5
xarray/tests/test_dataset.py:1173:        assert sum(rechunked.chunksizes["time"]) == ds.sizes["time"]
xarray/tests/test_dataset.py:1176:            assert rechunked.chunksizes["time"] == (60, 92, 92, 91, 90, 92, 92, 91, 30)
xarray/tests/test_dataset.py:1178:            assert rechunked.chunksizes["time"] == (59, 92, 92, 91, 90, 92, 92, 91, 31)
xarray/tests/test_dataset.py:1180:            assert rechunked.chunksizes["time"] == (60, 90, 90, 90, 90, 90, 90, 90, 40)
xarray/tests/test_dataset.py:1185:        rechunked = ds.chunk(
xarray/tests/test_dataset.py:1188:        assert len(rechunked.chunksizes["time"]) == 9
xarray/tests/test_dataset.py:1189:        assert sum(rechunked.chunksizes["time"]) == ds.sizes["time"]
xarray/tests/test_dataset.py:1190:        assert rechunked.chunksizes["x"] == (2,) * 5
xarray/tests/test_dataset.py:1193:            assert rechunked.chunksizes["time"] == (91, 61, 92, 91, 121, 61, 92, 91, 30)
xarray/tests/test_dataset.py:1195:            assert rechunked.chunksizes["time"] == (90, 61, 92, 91, 121, 61, 92, 91, 31)
xarray/tests/test_dataset.py:1197:            assert rechunked.chunksizes["time"] == (90, 60, 90, 90, 120, 60, 90, 90, 40)
xarray/tests/test_dataset.py:1202:        rechunked_drop_true = ds.chunk(
xarray/tests/test_dataset.py:1205:        rechunked_drop_false = ds.chunk(
xarray/tests/test_dataset.py:1209:            rechunked_drop_true.chunksizes["time"]
xarray/tests/test_dataset.py:1210:            == rechunked_drop_false.chunksizes["time"]
xarray/tests/test_dataset.py:1279:        # make sure dask names change when rechunking by different amounts
xarray/tests/test_dataset.py:1294:        # rechunking with same chunk sizes should not change names
xarray/tests/test_dataset.py:1342:        rechunked = ds.chunk(x=2, time=TimeResampler(freq))
xarray/tests/test_dataset.py:1346:        assert rechunked.chunksizes["time"] == expected
xarray/tests/test_dataset.py:1347:        assert rechunked.chunksizes["x"] == (2,) * 5
xarray/tests/test_dataset.py:1349:        rechunked = ds.chunk({"x": 2, "time": TimeResampler(freq)})
xarray/tests/test_dataset.py:1350:        assert rechunked.chunksizes["time"] == expected
xarray/tests/test_dataset.py:1351:        assert rechunked.chunksizes["x"] == (2,) * 5
xarray/tests/test_variable.py:1972:            # Dask rechunks
xarray/tests/test_variable.py:2426:        # name doesn't change when rechunking by same amount
xarray/tests/test_interp.py:67:        # chunksize=5 lets us check whether we rechunk to 1 with quintic
xarray/tests/test_rolling.py:81:    def test_repeated_rolling_rechunks(self) -> None:
xarray/tests/test_rolling.py:618:    def test_rolling_construct_automatic_rechunk(self):
xarray/tests/test_rolling.py:630:            rechunked = obj.rolling(time=100, center=True).construct(
xarray/tests/test_rolling.py:633:                    automatic_rechunk=True, writeable=False
xarray/tests/test_rolling.py:636:            not_rechunked = obj.rolling(time=100, center=True).construct(
xarray/tests/test_rolling.py:639:                    automatic_rechunk=False, writeable=True
xarray/tests/test_rolling.py:642:            assert rechunked.chunksizes != not_rechunked.chunksizes
xarray/tests/test_rolling.py:646:                np.sum, sliding_window_view_kwargs=dict(automatic_rechunk=True)
xarray/tests/test_rolling.py:649:                np.sum, sliding_window_view_kwargs=dict(automatic_rechunk=False)
xarray/tests/test_dataarray.py:938:        # name doesn't change when rechunking by same amount
xarray/tests/test_parallelcompat.py:53:    def rechunk(self, chunks, **kwargs):
xarray/tests/test_parallelcompat.py:90:    def rechunk(self, data: DummyChunkedArray, chunks, **kwargs) -> DummyChunkedArray:
xarray/tests/test_parallelcompat.py:91:        return data.rechunk(chunks, **kwargs)
xarray/tests/test_parallelcompat.py:109:        allow_rechunk=False,
xarray/tests/test_parallelcompat.py:125:            allow_rechunk=allow_rechunk,
xarray/tests/test_coding_strings.py:263:        strings.char_to_bytes(array.rechunk(1))
602:        "_align_chunks",
633:        align_chunks=False,
681:                align_chunks=align_chunks,
702:        align_chunks=False,
738:            align_chunks=align_chunks,
753:        align_chunks: bool = False,
756:        if align_chunks:
768:        self._align_chunks = align_chunks
800:            align_chunks=self._align_chunks,
1238:            if self._align_chunks and isinstance(encoding["chunks"], tuple):
```

## 原始行 26 · command_execution

命令：
```
/bin/bash -lc "nl -ba xarray/backends/chunks.py | sed -n '1,220p'; sed -n '2650,2750p' xarray/core/variable.py; grep -n \"def chunk(\" xarray/namedarray/core.py | head; sed -n '750,840p' xarray/namedarray/core.py"
```

退出码：`0`

输出：
```
     1	import numpy as np
     2	
     3	from xarray.core.datatree import Variable
     4	
     5	
     6	
     7	
     8	
     9	
    10	
    11	
    12	
    13	
    14	
    15	
    16	
    17	
    18	
    19	
    20	
    21	
    22	
    23	
    24	
    25	
    26	
    27	
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	def validate_grid_chunks_alignment(
   185	    nd_v_chunks: tuple[tuple[int, ...], ...] | None,
   186	    enc_chunks: tuple[int, ...],
   187	    backend_shape: tuple[int, ...],
   188	    region: tuple[slice, ...],
   189	    allow_partial_chunks: bool,
   190	    name: str,
   191	):
   192	    if nd_v_chunks is None:
   193	        return
   194	    base_error = (
   195	        "Specified Zarr chunks encoding['chunks']={enc_chunks!r} for "
   196	        "variable named {name!r} would overlap multiple Dask chunks. "
   197	        "Please check the Dask chunks at position {v_chunk_pos} and "
   198	        "{v_chunk_pos_next}, on axis {axis}, they are overlapped "
   199	        "on the same Zarr chunk in the region {region}. "
   200	        "Writing this array in parallel with Dask could lead to corrupted data. "
   201	        "To resolve this issue, consider one of the following options: "
   202	        "- Rechunk the array using `chunk()`. "
   203	        "- Modify or delete `encoding['chunks']`. "
   204	        "- Set `safe_chunks=False`. "
   205	        "- Enable automatic chunks alignment with `align_chunks=True`."
   206	    )
   207	
   208	    for axis, chunk_size, v_chunks, interval, size in zip(
   209	        range(len(enc_chunks)),
   210	        enc_chunks,
   211	        nd_v_chunks,
   212	        region,
   213	        backend_shape,
   214	        strict=True,
   215	    ):
   216	        for i, chunk in enumerate(v_chunks[1:-1]):
   217	            if chunk % chunk_size:
   218	                raise ValueError(
   219	                    base_error.format(
   220	                        v_chunk_pos=i + 1,
    def _to_dense(self) -> Variable:
        """
        Change backend from sparse to np.array.
        """
        out = super()._to_dense()
        return cast("Variable", out)

    def chunk(  # type: ignore[override]
        self,
        chunks: T_Chunks = {},  # noqa: B006  # even though it's technically unsafe, it is being used intentionally here (#4667)
        name: str | None = None,
        lock: bool | None = None,
        inline_array: bool | None = None,
        chunked_array_type: str | ChunkManagerEntrypoint[Any] | None = None,
        from_array_kwargs: Any = None,
        **chunks_kwargs: Any,
    ) -> Self:
        """Coerce this array's data into a dask array with the given chunks.

        If this variable is a non-dask array, it will be converted to dask
        array. If it's a dask array, it will be rechunked to the given chunk
        sizes.

        If neither chunks is not provided for one or more dimensions, chunk
        sizes along that dimension will not be updated; non-dask arrays will be
        converted into dask arrays with a single block.

        Parameters
        ----------
        chunks : int, tuple or dict, optional
            Chunk sizes along each dimension, e.g., ``5``, ``(5, 5)`` or
            ``{'x': 5, 'y': 5}``.
        name : str, optional
            Used to generate the name for this array in the internal dask
            graph. Does not need not be unique.
        lock : bool, default: False
            Passed on to :py:func:`dask.array.from_array`, if the array is not
            already as dask array.
        inline_array : bool, default: False
            Passed on to :py:func:`dask.array.from_array`, if the array is not
            already as dask array.
        chunked_array_type: str, optional
            Which chunked array type to coerce this datasets' arrays to.
            Defaults to 'dask' if installed, else whatever is registered via the `ChunkManagerEntrypoint` system.
            Experimental API that should not be relied upon.
        from_array_kwargs: dict, optional
            Additional keyword arguments passed on to the `ChunkManagerEntrypoint.from_array` method used to create
            chunked arrays, via whichever chunk manager is specified through the `chunked_array_type` kwarg.
            For example, with dask as the default chunked array type, this method would pass additional kwargs
            to :py:func:`dask.array.from_array`. Experimental API that should not be relied upon.
        **chunks_kwargs : {dim: chunks, ...}, optional
            The keyword arguments form of ``chunks``.
            One of chunks or chunks_kwargs must be provided.

        Returns
        -------
        chunked : xarray.Variable

        See Also
        --------
        Variable.chunks
        Variable.chunksizes
        xarray.unify_chunks
        dask.array.from_array
        """

        if from_array_kwargs is None:
            from_array_kwargs = {}

        # TODO deprecate passing these dask-specific arguments explicitly. In future just pass everything via from_array_kwargs
        _from_array_kwargs = consolidate_dask_from_array_kwargs(
            from_array_kwargs,
            name=name,
            lock=lock,
            inline_array=inline_array,
        )

        return super().chunk(
            chunks=chunks,
            chunked_array_type=chunked_array_type,
            from_array_kwargs=_from_array_kwargs,
            **chunks_kwargs,
        )


class IndexVariable(Variable):
    """Wrapper for accommodating a pandas.Index in an xarray.Variable.

    IndexVariable preserve loaded values in the form of a pandas.Index instead
    of a NumPy array. Hence, their values are immutable and must always be one-
    dimensional.

    They also have a name property, which is the name of their sole dimension
    unless another name is given.
    """

    __slots__ = ()

    # TODO: PandasIndexingAdapter doesn't match the array api:
    _data: PandasIndexingAdapter  # type: ignore[assignment]

754:    def chunk(
    def sizes(self) -> dict[_Dim, _IntOrUnknown]:
        """Ordered mapping from dimension names to lengths."""
        return dict(zip(self.dims, self.shape, strict=True))

    def chunk(
        self,
        chunks: T_Chunks = {},  # noqa: B006  # even though it's unsafe, it is being used intentionally here (#4667)
        chunked_array_type: str | ChunkManagerEntrypoint[Any] | None = None,
        from_array_kwargs: Any = None,
        **chunks_kwargs: Any,
    ) -> Self:
        """Coerce this array's data into a dask array with the given chunks.

        If this variable is a non-dask array, it will be converted to dask
        array. If it's a dask array, it will be rechunked to the given chunk
        sizes.

        If neither chunks is not provided for one or more dimensions, chunk
        sizes along that dimension will not be updated; non-dask arrays will be
        converted into dask arrays with a single block.

        Parameters
        ----------
        chunks : int, tuple or dict, optional
            Chunk sizes along each dimension, e.g., ``5``, ``(5, 5)`` or
            ``{'x': 5, 'y': 5}``.
        chunked_array_type: str, optional
            Which chunked array type to coerce this datasets' arrays to.
            Defaults to 'dask' if installed, else whatever is registered via the `ChunkManagerEntrypoint` system.
            Experimental API that should not be relied upon.
        from_array_kwargs: dict, optional
            Additional keyword arguments passed on to the `ChunkManagerEntrypoint.from_array` method used to create
            chunked arrays, via whichever chunk manager is specified through the `chunked_array_type` kwarg.
            For example, with dask as the default chunked array type, this method would pass additional kwargs
            to :py:func:`dask.array.from_array`. Experimental API that should not be relied upon.
        **chunks_kwargs : {dim: chunks, ...}, optional
            The keyword arguments form of ``chunks``.
            One of chunks or chunks_kwargs must be provided.

        Returns
        -------
        chunked : xarray.Variable

        See Also
        --------
        Variable.chunks
        Variable.chunksizes
        xarray.unify_chunks
        dask.array.from_array
        """

        if from_array_kwargs is None:
            from_array_kwargs = {}

        if chunks is None:
            warnings.warn(
                "None value for 'chunks' is deprecated. "
                "It will raise an error in the future. Use instead '{}'",
                category=FutureWarning,
                stacklevel=2,
            )
            chunks = {}

        if isinstance(chunks, float | str | int | tuple | list):
            # TODO we shouldn't assume here that other chunkmanagers can handle these types
            # TODO should we call normalize_chunks here?
            pass  # dask.array.from_array can handle these directly
        else:
            chunks = either_dict_or_kwargs(chunks, chunks_kwargs, "chunk")

        if is_dict_like(chunks):
            # This method of iteration allows for duplicated dimension names, GH8579
            chunks = {
                dim_number: chunks[dim]
                for dim_number, dim in enumerate(self.dims)
                if dim in chunks
            }

        chunkmanager = guess_chunkmanager(chunked_array_type)

        data_old = self._data
        if chunkmanager.is_chunked_array(data_old):
            data_chunked = chunkmanager.rechunk(data_old, chunks)  # type: ignore[arg-type]
        else:
            ndata: duckarray[Any, Any]
            if not isinstance(data_old, ExplicitlyIndexed):
                ndata = data_old
            else:
                # Unambiguously handle array storage backends (like NetCDF4 and h5py)
                # that can't handle general array indexing. For example, in netCDF4 you
                # can do "outer" indexing along two dimensions independent, which works
```

## 原始行 29 · command_execution

命令：
```
/bin/bash -lc "grep -R -n --exclude-dir=.git \"align_chunks\" . | head -200; grep -R -n --exclude-dir=.git \"automatic chunks alignment\\|automatic chunk alignment\\|chunk alignment\" doc xarray 2>/dev/null | head -200; find . -maxdepth 2 -type f -name 'pyproject.toml' -print -exec grep -n 'version' {} \\; | head -30"
```

退出码：`0`

输出：
```
./xarray/core/dataarray.py:4269:        align_chunks: bool = False,
./xarray/core/dataarray.py:4293:        align_chunks: bool = False,
./xarray/core/dataarray.py:4315:        align_chunks: bool = False,
./xarray/core/dataarray.py:4417:        align_chunks: bool, default False
./xarray/core/dataarray.py:4519:            align_chunks=align_chunks,
./xarray/core/dataset.py:2136:        align_chunks: bool = False,
./xarray/core/dataset.py:2160:        align_chunks: bool = False,
./xarray/core/dataset.py:2182:        align_chunks: bool = False,
./xarray/core/dataset.py:2292:        align_chunks: bool, default False
./xarray/core/dataset.py:2386:            align_chunks=align_chunks,
./xarray/backends/chunks.py:205:        "- Enable automatic chunks alignment with `align_chunks=True`."
./xarray/backends/zarr.py:602:        "_align_chunks",
./xarray/backends/zarr.py:633:        align_chunks=False,
./xarray/backends/zarr.py:681:                align_chunks=align_chunks,
./xarray/backends/zarr.py:702:        align_chunks=False,
./xarray/backends/zarr.py:738:            align_chunks=align_chunks,
./xarray/backends/zarr.py:753:        align_chunks: bool = False,
./xarray/backends/zarr.py:756:        if align_chunks:
./xarray/backends/zarr.py:768:        self._align_chunks = align_chunks
./xarray/backends/zarr.py:800:            align_chunks=self._align_chunks,
./xarray/backends/zarr.py:1238:            if self._align_chunks and isinstance(encoding["chunks"], tuple):
./xarray/backends/writers.py:645:    align_chunks: bool = False,
./xarray/backends/writers.py:677:        align_chunks=align_chunks,
./xarray/backends/writers.py:701:    align_chunks: bool = False,
./xarray/backends/writers.py:725:    align_chunks: bool = False,
./xarray/backends/writers.py:747:    align_chunks: bool = False,
./xarray/backends/writers.py:783:        align_chunks=align_chunks,
./xarray/backends/writers.py:943:    align_chunks: bool = False,
./xarray/backends/writers.py:983:        align_chunks=align_chunks,
./xarray/tests/test_backends.py:6812:    def test_dataarray_to_zarr_align_chunks_true(self, tmp_store) -> None:
./xarray/tests/test_backends.py:6826:            align_chunks=True,
./xarray/tests/test_backends.py:7985:    def test_dataset_to_zarr_align_chunks_true(self, tmp_store) -> None:
./xarray/tests/test_backends.py:7986:        # This test is a replica of the one in `test_dataarray_to_zarr_align_chunks_true`
./xarray/tests/test_backends.py:8005:                align_chunks=True,
./xarray/tests/test_backends.py:8027:                align_chunks=True,
./doc/whats-new.rst:246:- Fix the ``align_chunks`` parameter on the :py:meth:`~xarray.Dataset.to_zarr` method, it was not being
./doc/whats-new.rst:656:  can now be prevented using the new ``align_chunks`` parameter in
xarray/backends/chunks.py:205:        "- Enable automatic chunks alignment with `align_chunks=True`."
./pyproject.toml
15:dynamic = ["version"]
108:fallback_version = "9999"
342:  "default:is currently not part .* the Zarr version 3 specification.",
358:minversion = "7"
```

## 原始行 31 · command_execution

命令：
```
/bin/bash -lc "sed -n '215,265p' doc/whats-new.rst; sed -n '630,675p' doc/whats-new.rst; find xarray/tests -type f | wc -l; grep -R -n \"chunks\" xarray/tests/test_backends.py | tail -100"
```

退出码：`0`

输出：
````

- The HTML reprs for :py:class:`DataArray`, :py:class:`Dataset` and
  :py:class:`DataTree` have been tweaked to hide empty sections, consistent
  with the text reprs. The ``DataTree`` HTML repr also now automatically expands
  sub-groups (:pull:`10785`).
  By `Stephan Hoyer <https://github.com/shoyer>`_.

- Zarr stores written with Xarray now consistently use a default Zarr fill value
  of ``NaN`` for float variables, for both Zarr v2 and v3 (:issue:`10646``). All
  other dtypes still use the Zarr default ``fill_value`` of zero. To customize,
  explicitly set encoding in :py:meth:`~Dataset.to_zarr`, e.g.,
  ``encoding=dict.fromkey(ds.data_vars, {'fill_value': 0})``.
  By `Stephan Hoyer <https://github.com/shoyer>`_.

Deprecations
~~~~~~~~~~~~


Bug fixes
~~~~~~~~~

- Xarray objects opened from file-like objects with ``engine='h5netcdf'`` can
  now be pickled, as long as the underlying file-like object also supports
  pickle (:issue:`10712`).
  By `Stephan Hoyer <https://github.com/shoyer>`_.

- Closing Xarray objects opened from file-like objects with ```engine='scipy'``
  no longer closes the underlying file, consistent with the h5netcdf backend
  (:pull:`10624`).
  By `Stephan Hoyer <https://github.com/shoyer>`_.

- Fix the ``align_chunks`` parameter on the :py:meth:`~xarray.Dataset.to_zarr` method, it was not being
  passed to the underlying :py:meth:`~xarray.backends.api` method (:issue:`10501`, :pull:`10516`).
- Fix error when encoding an empty :py:class:`numpy.datetime64` array
  (:issue:`10722`, :pull:`10723`). By `Spencer Clark
  <https://github.com/spencerkclark>`_.
- Propagate coordinate attrs in :py:meth:`xarray.Dataset.map` (:issue:`9317`, :pull:`10602`).
- Fix error from ``to_netcdf(..., compute=False)`` when using Dask Distributed
  (:issue:`10725`).
  By `Stephan Hoyer <https://github.com/shoyer>`_.
- Propagation coordinate attrs in :py:meth:`xarray.Dataset.map` (:issue:`9317`, :pull:`10602`).
  By `Justus Magin <https://github.com/keewis>`_.
- Allow ``combine_attrs="drop_conflicts"`` to handle objects with ``__eq__`` methods that return
  non-bool values (e.g., numpy arrays) without raising ``ValueError`` (:pull:`10726`).
  By `Maximilian Roos <https://github.com/max-sixty>`_.

Documentation
~~~~~~~~~~~~~

- Fixed Zarr encoding documentation with consistent examples and added comprehensive
  coverage of dimension and coordinate encoding differences between Zarr V2 and V3 formats.

- Remove dependency on ``typing_extensions`` (:pull:`10413`). By `Simon Perkins <https://github.com/sjperkins>`_.

.. _whats-new.2025.06.0:

v2025.06.0 (Jun 10, 2025)
-------------------------

This release brings HTML reprs to the documentation, fixes to flexible Xarray indexes, performance optimizations, more ergonomic seasonal grouping and resampling
with new :py:class:`~xarray.groupers.SeasonGrouper` and :py:class:`~xarray.groupers.SeasonResampler` objects, and bugfixes.
Thanks to the 33 contributors to this release:
Andrecho, Antoine Gibek, Benoit Bovy, Brian Michell, Christine P. Chai, David Huard, Davis Bennett, Deepak Cherian, Dimitri Papadopoulos Orfanos, Elliott Sales de Andrade, Erik, Erik Månsson, Giacomo Caria, Ilan Gold, Illviljan, Jesse Rusak, Jonathan Neuhauser, Justus Magin, Kai Mühlbauer, Kimoon Han, Konstantin Ntokas, Mark Harfouche, Michael Niklas, Nick Hodgskin, Niko Sirmpilatze, Pascal Bourgault, Scott Henderson, Simon Perkins, Spencer Clark, Tom Vo, Trevor James Smith, joseph nowak and micguerr-bopen

New Features
~~~~~~~~~~~~
- Switch docs to jupyter-execute sphinx extension for HTML reprs. (:issue:`3893`, :pull:`10383`)
  By `Scott Henderson <https://github.com/scottyhq>`_.
- Allow an Xarray index that uses multiple dimensions checking equality with another
  index for only a subset of those dimensions (i.e., ignoring the dimensions
  that are excluded from alignment).
  (:issue:`10243`, :pull:`10293`)
  By `Benoit Bovy <https://github.com/benbovy>`_.
- New :py:class:`~xarray.groupers.SeasonGrouper` and :py:class:`~xarray.groupers.SeasonResampler` objects for ergonomic seasonal aggregation.
  See the docs on :ref:`seasonal_grouping` or `blog post <https://xarray.dev/blog/season-grouping>`_ for more.
  By `Deepak Cherian <https://github.com/dcherian>`_.
- Data corruption issues arising from misaligned Dask and Zarr chunks
  can now be prevented using the new ``align_chunks`` parameter in
  :py:meth:`~xarray.DataArray.to_zarr`. This option automatically rechunk
  the Dask array to align it with the Zarr storage chunks. For now, it is
  disabled by default, but this could change on the future.
  (:issue:`9914`, :pull:`10336`)
  By `Joseph Nowak <https://github.com/josephnowak>`_.

Documentation
~~~~~~~~~~~~~
- HTML reprs! By `Scott Henderson <https://github.com/scottyhq>`_.

Bug fixes
~~~~~~~~~
- Fix :py:class:`~xarray.groupers.BinGrouper` when ``labels`` is not specified (:issue:`10284`).
  By `Deepak Cherian <https://github.com/dcherian>`_.
- Allow accessing arbitrary attributes on Pandas ExtensionArrays.
  By `Deepak Cherian <https://github.com/dcherian>`_.
- Fix coding empty (zero-size) timedelta64 arrays, ``units`` taking precedence when encoding,
  fallback to default values when decoding (:issue:`10310`, :pull:`10313`).
  By `Kai Mühlbauer <https://github.com/kmuehlbauer>`_.
83
3698:            assert original.chunks == actual.chunks
3707:        with self.roundtrip(original, open_kwargs={"chunks": {}}) as actual:
3709:                assert original[name].chunks == actual_var.chunks
3710:            assert original.chunks == actual.chunks
3756:        # on read we should receive chunks filled with `fill_value`
3776:        # Since chunks, are not written, we should receive on `fill_value`
4072:                "chunks": (2, 2),
4091:                # Verify chunks are preserved
4092:                assert actual["var1"].encoding["chunks"] == (2, 2)
4112:                ds = xr.open_zarr(store, consolidated=False, chunks=None)
4307:            ds = xr.open_zarr(store, consolidated=False, chunks=None)
4317:    ds = xr.open_zarr(store, consolidated=False, chunks=None)
4473:            encoding = {"test": {"chunks": (1, 1, 1)}}
4480:                write_empty_chunks=write_empty,
4492:                    "write_empty_chunks": write_empty,
4505:                    # for write_empty_chunks in append
5004:                "chunksizes": (5, 5),
5266:        open_kwargs.setdefault("chunks", -1)
5276:    def test_write_inconsistent_chunks(self) -> None:
5279:        x = da.zeros((100, 100), dtype="f4", chunks=(50, 100))
5281:        x.encoding["chunksizes"] = (50, 100)
5283:        y = da.ones((100, 100), dtype="f4", chunks=(100, 50))
5285:        y.encoding["chunksizes"] = (100, 50)
5290:            assert actual["x"].encoding["chunksizes"] == (50, 100)
5291:            assert actual["y"].encoding["chunksizes"] == (100, 50)
5367:def chunks(request):
5400:    readengine, nfiles, parallel, chunks, file_cache_maxsize
5424:            chunks=chunks if (not chunks and readengine != "zarr") else "auto",
5857:                    assert actual.foo.variable.data.chunks == ((5, 5),)
5860:                    [tmp1, tmp2], concat_dim="x", combine="nested", chunks={"x": 3}
5862:                    assert actual.foo.variable.data.chunks == ((3, 2, 3, 2),)
5893:                            assert actual.foo.variable.data.chunks == ((5, 5), (4, 4))
5899:                            chunks={"x": 3, "y": 2},
5901:                            assert actual.foo.variable.data.chunks == (
6251:            with open_dataset(tmp, chunks={"x": 5}) as actual:
6253:                assert actual.foo.variable.data.chunks == ((5, 5),)
6255:            with open_dataset(tmp, chunks=5) as actual:
6323:        with self.roundtrip(original, open_kwargs={"chunks": "auto"}) as actual:
6334:            chunks = {"dim1": 4, "dim2": 4, "dim3": 4, "time": 10}
6335:            with open_dataset(tmp, chunks=chunks) as dask_ds:
6419:            chunks = {"time": 10}
6425:                open_dataset(tmp, inline_array=False, chunks=chunks) as not_inlined_ds,
6426:                open_dataset(tmp, inline_array=True, chunks=chunks) as inlined_ds,
6432:                    tmp, inline_array=False, chunks=chunks
6434:                open_dataarray(tmp, inline_array=True, chunks=chunks) as inlined_da,
6512:        with self.create_datasets(chunks={"j": 2}) as (actual, expected):
6812:    def test_dataarray_to_zarr_align_chunks_true(self, tmp_store) -> None:
6826:            align_chunks=True,
6827:            encoding={"foo": {"chunks": (3,)}},
7082:    assert "chunks" in actual
7083:    assert actual["chunks"] == ("auto" if has_zarr_v3 else None)
7085:    var = xr.Variable("x", [1, 2], encoding={"chunks": (1,)})
7087:    assert actual["chunks"] == (1,)
7176:    "chunks", ["auto", -1, {}, {"x": "auto"}, {"x": -1}, {"x": "auto", "y": -1}]
7178:def test_open_dataset_chunking_zarr(chunks, tmp_path: Path) -> None:
7179:    encoded_chunks = 100
7181:        np.ones((500, 500), dtype="float64"), chunks=encoded_chunks
7191:    ds["test"].encoding["chunks"] = encoded_chunks
7195:        expected = ds.chunk(chunks)
7197:            tmp_path / "test.zarr", engine="zarr", chunks=chunks
7199:            xr.testing.assert_chunks_equal(actual, expected)
7205:    "chunks", ["auto", -1, {}, {"x": "auto"}, {"x": -1}, {"x": "auto", "y": -1}]
7207:@pytest.mark.filterwarnings("ignore:The specified chunks separate")
7208:def test_chunking_consintency(chunks, tmp_path: Path) -> None:
7209:    encoded_chunks: dict[str, Any] = {}
7211:        np.ones((500, 500), dtype="float64"), chunks=encoded_chunks
7221:    ds["test"].encoding["chunks"] = encoded_chunks
7226:        expected = ds.chunk(chunks)
7228:            tmp_path / "test.zarr", engine="zarr", chunks=chunks
7230:            xr.testing.assert_chunks_equal(actual, expected)
7232:        with xr.open_dataset(tmp_path / "test.nc", chunks=chunks) as actual:
7233:            xr.testing.assert_chunks_equal(actual, expected)
7664:        Check that writing to partial chunks with `region` fails, assuming `safe_chunks=False`.
7700:            self.save(target, da, mode="w", encoding={"foo": {"chunks": (5, 5, 1)}})
7708:                    encoding={"foo": {"chunks": (1, 1, 1)}},
7712:            with pytest.raises(ValueError, match="Specified Zarr chunks"):
7739:                safe_chunks=False,
7756:            self.save(store, da.isel(x=slice(0, 7)), safe_chunks=True, mode="w")
7763:                    safe_chunks=True,
7766:            self.save(store, da.isel(x=slice(0, 7)), safe_chunks=True, mode="w")
7771:                safe_chunks=True,
7776:            self.save(store, da.isel(x=slice(0, 7)), safe_chunks=True, mode="w")
7781:                safe_chunks=True,
7786:            self.save(store, da.isel(x=slice(0, 7)), safe_chunks=True, mode="w")
7793:                    safe_chunks=True,
7796:            self.save(store, da.isel(x=slice(0, 7)), safe_chunks=True, mode="w")
7804:                    safe_chunks=True,
7807:            self.save(store, da.isel(x=slice(0, 7)), safe_chunks=True, mode="w")
7814:                safe_chunks=True,
7828:                # There are two Dask chunks on the same Zarr chunk,
7849:                # The first chunk is safe but the other two chunks are overlapping with
7858:            # Fully update two contiguous chunks is safe in any mode
7951:                # if it is partial covering other Zarr chunks
7977:            chunks = {"time": 1000, "lat": 25, "lon": 53}
7978:            self.save(store, ds.chunk(chunks), compute=False, mode="w")
7985:    def test_dataset_to_zarr_align_chunks_true(self, tmp_store) -> None:
7986:        # This test is a replica of the one in `test_dataarray_to_zarr_align_chunks_true`
8005:                align_chunks=True,
8006:                encoding={"foo": {"chunks": (3, 3)}},
8027:                align_chunks=True,
````

## 原始行 36 · command_execution

命令：
```
/bin/bash -lc "grep -n \"Variable\" xarray/core/datatree.py | head -20; python - <<'PY'
from xarray.core.datatree import Variable as A
from xarray.core.variable import Variable as B
print(A, A is B)
PY
python - <<'PY'
try:
 import dask
 print('dask',dask.__version__)
except Exception as e: print(e)
try:
 import zarr
 print('zarr',zarr.__version__)
except Exception as e: print(e)
PY"
```

退出码：`0`

输出：
```
38:from xarray.core.dataset_variables import DataVariables
66:from xarray.core.variable import Variable
124:) -> tuple[dict[Hashable, Variable], dict[Hashable, Variable]]:
226:            "Variables stored in DataTree objects cannot have names containing '/' characters, as this would make path-like access to variables ambiguous."
265:        variables: dict[Any, Variable],
328:        variables: dict[Any, Variable],
356:        variables: dict[Hashable, Variable] | None = None,
495:    _data_variables: dict[Hashable, Variable]
496:    _node_coord_variables: dict[Hashable, Variable]
576:    def _node_coord_variables_with_index(self) -> Mapping[Hashable, Variable]:
582:    def _coord_variables(self) -> ChainMap[Hashable, Variable]:
721:    def variables(self) -> Mapping[Hashable, Variable]:
722:        """Low level interface to node contents as dict of Variable objects.
993:            if not isinstance(val, DataArray | Variable):
994:                # accommodate other types that can be coerced into Variables
1047:    def update(self, other: Mapping[Hashable, DataArray | Variable]) -> None: ...
1050:    def update(self, other: Mapping[str, DataTree | DataArray | Variable]) -> None: ...
1056:            | Mapping[Hashable, DataArray | Variable]
1057:            | Mapping[str, DataTree | DataArray | Variable]
1079:                elif isinstance(v, DataArray | Variable):
<class 'xarray.core.variable.Variable'> True
dask 2025.11.0
zarr 3.1.3
```

## 原始行 38 · agent_message

```
I’ve reduced the alignment rule to boundary invariants: every resulting interior boundary must lie on the backend grid, already-safe variable boundaries should be retained, and any added grouping must stay under `max(largest variable chunk, regular backend chunk)`. I’m implementing that directly, including partial first/last backend cells.
```

## 原始行 40 · file_change

```
{
  "id": "item_26",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/xarray/backends/chunks.py",
      "kind": "update"
    },
    {
      "path": "/testbed/xarray/backends/zarr.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,190p' xarray/backends/chunks.py; python - <<'PY'
from xarray.backends.chunks import align_nd_chunks, build_grid_chunks

for args in [(13,5,None),(10,15,None),(10,4,slice(1,99)),(20,5,slice(2,999)),(0,5,None)]:
 print('grid',args,build_grid_chunks(*args))

cases = [
 (((2,1,1),), ((3,1),)),
 (((1,1),), ((2,),)),
 (((10,10),), ((4,4,4,4,4),)),
 (((5,5,5),), ((3,3,3,3,3),)),
 (((10,10),), ((3,5,5,5,2),)),
 (((5,5,5),), ((5,5,5),)),
]
for a,b in cases:
 print('align', a,b,'=>',align_nd_chunks(a,b))
PY
pytest -q xarray/tests/test_backends.py -k 'align_chunks_true'"
```

退出码：`2`

输出：
```
import numpy as np

from xarray.core.datatree import Variable


def align_nd_chunks(
    nd_v_chunks: tuple[tuple[int, ...], ...],
    nd_backend_chunks: tuple[tuple[int, ...], ...],
) -> tuple[tuple[int, ...], ...]:
    """Align variable chunks with an n-dimensional backend chunk grid.

    Resulting chunk boundaries are backend boundaries, so two chunks in the
    variable cannot write to the same backend chunk.  Boundaries which are
    already shared by the two layouts are kept, and additional boundaries are
    introduced only when needed to keep chunks from becoming too large.
    """
    if len(nd_v_chunks) != len(nd_backend_chunks):
        raise ValueError(
            "The number of dimensions in the variable chunks and backend "
            "chunks must match"
        )

    aligned_dimensions: list[tuple[int, ...]] = []

    for axis, (v_chunks, backend_chunks) in enumerate(
        zip(nd_v_chunks, nd_backend_chunks, strict=True)
    ):
        v_size = sum(v_chunks)
        backend_size = sum(backend_chunks)
        if v_size != backend_size:
            raise ValueError(
                "The variable chunks and backend chunks must describe the "
                f"same size on axis {axis}: {v_size} != {backend_size}"
            )

        # A single variable chunk is safe because it is the only writer for
        # every backend chunk it intersects.  Conversely, a backend consisting
        # of one chunk requires the whole variable dimension to be one chunk.
        if len(v_chunks) == 1:
            aligned_dimensions.append(v_chunks)
            continue
        if len(backend_chunks) == 1:
            aligned_dimensions.append(backend_chunks)
            continue

        # Grid chunks may be partial only at the two borders.  The largest
        # backend chunk is therefore the regular grid size (or, for a grid
        # shorter than two cells, the best information available here).
        backend_chunk_size = max(backend_chunks)
        if any(
            chunk != backend_chunk_size for chunk in backend_chunks[1:-1]
        ):
            raise ValueError(
                "Backend chunks must be uniformly sized except for border "
                f"chunks (axis {axis}, chunks {backend_chunks!r}). This is "
                "an internal error; please report it."
            )

        max_chunk_size = max(max(v_chunks), backend_chunk_size)

        def cumulative_boundaries(chunks: tuple[int, ...]) -> tuple[int, ...]:
            position = 0
            boundaries: list[int] = []
            for chunk in chunks[:-1]:
                position += chunk
                boundaries.append(position)
            return tuple(boundaries)

        v_boundaries = set(cumulative_boundaries(v_chunks))
        backend_boundaries = cumulative_boundaries(backend_chunks)
        # Shared boundaries are safe and retaining them preserves as much of
        # the original variable layout as possible.
        required_boundaries = v_boundaries.intersection(backend_boundaries)

        new_chunks: list[int] = []
        current_size = 0
        position = 0
        for backend_chunk in backend_chunks:
            next_position = position + backend_chunk

            # A backend cell is indivisible.  Finish the current output chunk
            # before adding it if the configured memory bound would otherwise
            # be exceeded.
            if current_size and current_size + backend_chunk > max_chunk_size:
                new_chunks.append(current_size)
                current_size = 0

            current_size += backend_chunk
            position = next_position

            if position in required_boundaries:
                new_chunks.append(current_size)
                current_size = 0

        if current_size or not new_chunks:
            new_chunks.append(current_size)

        aligned_dimensions.append(tuple(new_chunks))

    return tuple(aligned_dimensions)


def build_grid_chunks(
    size: int, chunk_size: int, region: slice | None = None
) -> tuple[int, ...]:
    """Partition a dimension into chunks aligned with a backend grid."""
    if chunk_size <= 0:
        raise ValueError("chunk_size must be a positive integer")
    if size < 0:
        raise ValueError("size must be non-negative")

    offset = 0 if region is None or region.start is None else region.start
    first_chunk = chunk_size - offset % chunk_size

    if first_chunk >= size:
        return (size,)

    full_chunks, last_chunk = divmod(size - first_chunk, chunk_size)
    chunks = (first_chunk,) + (chunk_size,) * full_chunks
    if last_chunk:
        chunks += (last_chunk,)
    return chunks


def grid_rechunk(
    v: Variable, enc_chunks: tuple[int, ...], region: tuple[slice, ...]
) -> Variable:
    """Rechunk a chunked variable so its boundaries align to a backend grid."""
    if v.chunks is None:
        return v

    if len(enc_chunks) != v.ndim or len(region) != v.ndim:
        raise ValueError(
            "enc_chunks and region must each have one entry per variable dimension"
        )

    backend_chunks = tuple(
        build_grid_chunks(size, chunk_size, interval)
        for size, chunk_size, interval in zip(
            v.shape, enc_chunks, region, strict=True
        )
    )
    aligned_chunks = align_nd_chunks(v.chunks, backend_chunks)
    if aligned_chunks == v.chunks:
        return v
    return v.chunk(aligned_chunks)












































grid (13, 5, None) (5, 5, 3)
grid (10, 15, None) (10,)
grid (10, 4, slice(1, 99, None)) (3, 4, 3)
grid (20, 5, slice(2, 999, None)) (3, 5, 5, 5, 2)
grid (0, 5, None) (0,)
align ((2, 1, 1),) ((3, 1),) => ((3, 1),)
align ((1, 1),) ((2,),) => ((2,),)
align ((10, 10),) ((4, 4, 4, 4, 4),) => ((8, 8, 4),)
align ((5, 5, 5),) ((3, 3, 3, 3, 3),) => ((3, 3, 3, 3, 3),)
align ((10, 10),) ((3, 5, 5, 5, 2),) => ((8, 10, 2),)
align ((5, 5, 5),) ((5, 5, 5),) => ((5, 5, 5),)

==================================== ERRORS ====================================
________________ ERROR collecting xarray/tests/test_backends.py ________________
ImportError while importing test module '/testbed/xarray/tests/test_backends.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
xarray/tests/test_backends.py:63: in <module>
    from xarray.core.common import _contains_cftime_datetimes
E   ImportError: cannot import name '_contains_cftime_datetimes' from 'xarray.core.common' (/testbed/xarray/core/common.py)
=========================== short test summary info ============================
ERROR xarray/tests/test_backends.py
!!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
1 error in 1.40s
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "find xarray/tests -maxdepth 1 -type f -printf '%f\\n' | sort; grep -R -n \"internal error; please report\\|Backend chunks must\\|variable chunks and backend\" . --exclude=chunks.py --exclude-dir=.git | head -100; git diff -- xarray/backends/chunks.py xarray/backends/zarr.py"
```

退出码：`0`

输出：
```
CLAUDE.md
__init__.py
arrays.py
conftest.py
indexes.py
namespace.py
test_accessor_dt.py
test_accessor_str.py
test_array_api.py
test_assertions.py
test_backends.py
test_backends_api.py
test_backends_common.py
test_backends_datatree.py
test_backends_file_manager.py
test_backends_locks.py
test_backends_lru_cache.py
test_calendar_ops.py
test_cftime_offsets.py
test_cftimeindex.py
test_cftimeindex_resample.py
test_coarsen.py
test_coding.py
test_coding_strings.py
test_coding_times.py
test_combine.py
test_computation.py
test_concat.py
test_conventions.py
test_coordinate_transform.py
test_coordinates.py
test_cupy.py
test_dask.py
test_dataarray.py
test_dataarray_typing.yml
test_dataset.py
test_dataset_typing.yml
test_datatree.py
test_datatree_mapping.py
test_datatree_typing.yml
test_deprecation_helpers.py
test_distributed.py
test_dtypes.py
test_duck_array_ops.py
test_duck_array_wrapping.py
test_error_messages.py
test_extensions.py
test_formatting.py
test_formatting_html.py
test_groupby.py
test_hashable.py
test_indexes.py
test_indexing.py
test_interp.py
test_merge.py
test_missing.py
test_namedarray.py
test_nd_point_index.py
test_nputils.py
test_options.py
test_pandas_to_xarray.py
test_parallelcompat.py
test_plot.py
test_plugins.py
test_print_versions.py
test_range_index.py
test_rolling.py
test_sparse.py
test_strategies.py
test_treenode.py
test_tutorial.py
test_typed_ops.py
test_ufuncs.py
test_units.py
test_utils.py
test_variable.py
test_weighted.py
grep: ./xarray/backends/__pycache__/chunks.cpython-311.pyc: binary file matches
diff --git a/xarray/backends/chunks.py b/xarray/backends/chunks.py
index ae0a883..5f88d81 100644
--- a/xarray/backends/chunks.py
+++ b/xarray/backends/chunks.py
@@ -3,6 +3,149 @@ import numpy as np
 from xarray.core.datatree import Variable
 
 
+def align_nd_chunks(
+    nd_v_chunks: tuple[tuple[int, ...], ...],
+    nd_backend_chunks: tuple[tuple[int, ...], ...],
+) -> tuple[tuple[int, ...], ...]:
+    """Align variable chunks with an n-dimensional backend chunk grid.
+
+    Resulting chunk boundaries are backend boundaries, so two chunks in the
+    variable cannot write to the same backend chunk.  Boundaries which are
+    already shared by the two layouts are kept, and additional boundaries are
+    introduced only when needed to keep chunks from becoming too large.
+    """
+    if len(nd_v_chunks) != len(nd_backend_chunks):
+        raise ValueError(
+            "The number of dimensions in the variable chunks and backend "
+            "chunks must match"
+        )
+
+    aligned_dimensions: list[tuple[int, ...]] = []
+
+    for axis, (v_chunks, backend_chunks) in enumerate(
+        zip(nd_v_chunks, nd_backend_chunks, strict=True)
+    ):
+        v_size = sum(v_chunks)
+        backend_size = sum(backend_chunks)
+        if v_size != backend_size:
+            raise ValueError(
+                "The variable chunks and backend chunks must describe the "
+                f"same size on axis {axis}: {v_size} != {backend_size}"
+            )
+
+        # A single variable chunk is safe because it is the only writer for
+        # every backend chunk it intersects.  Conversely, a backend consisting
+        # of one chunk requires the whole variable dimension to be one chunk.
+        if len(v_chunks) == 1:
+            aligned_dimensions.append(v_chunks)
+            continue
+        if len(backend_chunks) == 1:
+            aligned_dimensions.append(backend_chunks)
+            continue
+
+        # Grid chunks may be partial only at the two borders.  The largest
+        # backend chunk is therefore the regular grid size (or, for a grid
+        # shorter than two cells, the best information available here).
+        backend_chunk_size = max(backend_chunks)
+        if any(
+            chunk != backend_chunk_size for chunk in backend_chunks[1:-1]
+        ):
+            raise ValueError(
+                "Backend chunks must be uniformly sized except for border "
+                f"chunks (axis {axis}, chunks {backend_chunks!r}). This is "
+                "an internal error; please report it."
+            )
+
+        max_chunk_size = max(max(v_chunks), backend_chunk_size)
+
+        def cumulative_boundaries(chunks: tuple[int, ...]) -> tuple[int, ...]:
+            position = 0
+            boundaries: list[int] = []
+            for chunk in chunks[:-1]:
+                position += chunk
+                boundaries.append(position)
+            return tuple(boundaries)
+
+        v_boundaries = set(cumulative_boundaries(v_chunks))
+        backend_boundaries = cumulative_boundaries(backend_chunks)
+        # Shared boundaries are safe and retaining them preserves as much of
+        # the original variable layout as possible.
+        required_boundaries = v_boundaries.intersection(backend_boundaries)
+
+        new_chunks: list[int] = []
+        current_size = 0
+        position = 0
+        for backend_chunk in backend_chunks:
+            next_position = position + backend_chunk
+
+            # A backend cell is indivisible.  Finish the current output chunk
+            # before adding it if the configured memory bound would otherwise
+            # be exceeded.
+            if current_size and current_size + backend_chunk > max_chunk_size:
+                new_chunks.append(current_size)
+                current_size = 0
+
+            current_size += backend_chunk
+            position = next_position
+
+            if position in required_boundaries:
+                new_chunks.append(current_size)
+                current_size = 0
+
+        if current_size or not new_chunks:
+            new_chunks.append(current_size)
+
+        aligned_dimensions.append(tuple(new_chunks))
+
+    return tuple(aligned_dimensions)
+
+
+def build_grid_chunks(
+    size: int, chunk_size: int, region: slice | None = None
+) -> tuple[int, ...]:
+    """Partition a dimension into chunks aligned with a backend grid."""
+    if chunk_size <= 0:
+        raise ValueError("chunk_size must be a positive integer")
+    if size < 0:
+        raise ValueError("size must be non-negative")
+
+    offset = 0 if region is None or region.start is None else region.start
+    first_chunk = chunk_size - offset % chunk_size
+
+    if first_chunk >= size:
+        return (size,)
+
+    full_chunks, last_chunk = divmod(size - first_chunk, chunk_size)
+    chunks = (first_chunk,) + (chunk_size,) * full_chunks
+    if last_chunk:
+        chunks += (last_chunk,)
+    return chunks
+
+
+def grid_rechunk(
+    v: Variable, enc_chunks: tuple[int, ...], region: tuple[slice, ...]
+) -> Variable:
+    """Rechunk a chunked variable so its boundaries align to a backend grid."""
+    if v.chunks is None:
+        return v
+
+    if len(enc_chunks) != v.ndim or len(region) != v.ndim:
+        raise ValueError(
+            "enc_chunks and region must each have one entry per variable dimension"
+        )
+
+    backend_chunks = tuple(
+        build_grid_chunks(size, chunk_size, interval)
+        for size, chunk_size, interval in zip(
+            v.shape, enc_chunks, region, strict=True
+        )
+    )
+    aligned_chunks = align_nd_chunks(v.chunks, backend_chunks)
+    if aligned_chunks == v.chunks:
+        return v
+    return v.chunk(aligned_chunks)
+
+
 
 
 
@@ -276,4 +419,4 @@ def validate_grid_chunks_alignment(
                 if v_chunks[-1] % chunk_size != size % chunk_size:
                     raise ValueError(error_on_last_chunk)
             elif v_chunks[-1] % chunk_size:
-                raise ValueError(error_on_last_chunk)
\ No newline at end of file
+                raise ValueError(error_on_last_chunk)
diff --git a/xarray/backends/zarr.py b/xarray/backends/zarr.py
index 84a5995..fe004c2 100644
--- a/xarray/backends/zarr.py
+++ b/xarray/backends/zarr.py
@@ -11,7 +11,7 @@ import numpy as np
 import pandas as pd
 
 from xarray import coding, conventions
-from xarray.backends.chunks import validate_grid_chunks_alignment
+from xarray.backends.chunks import grid_rechunk, validate_grid_chunks_alignment
 from xarray.backends.common import (
     BACKEND_ENTRYPOINTS,
     AbstractWritableDataStore,
```

## 原始行 50 · agent_message

```
The repository’s full backend test module cannot currently collect because an unrelated masked helper (`_contains_cftime_datetimes`) is absent. The new functions import and pass direct cases, so I’m validating the actual Zarr write paths independently, including a region offset and multi-dimensional chunks.
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile
import numpy as np
import xarray as xr
from xarray.backends.chunks import grid_rechunk, validate_grid_chunks_alignment

cases = [
    (np.arange(4), (2, 1, 1), (3,), (slice(None),)),
    (np.arange(20), (6, 6, 6, 2), (5,), (slice(2, 22),)),
]
for values, chunks, enc, region in cases:
    v = xr.Variable(('x',), values).chunk(chunks)
    out = grid_rechunk(v, enc, region)
    print(v.chunks, '=>', out.chunks)
    validate_grid_chunks_alignment(out.chunks, enc, (region[0].stop or len(values),), region, True, 'v')
    np.testing.assert_array_equal(out.compute(), v.compute())

v = xr.Variable(('x','y'), np.arange(24).reshape(4,6)).chunk(((2,1,1),(4,2)))
out = grid_rechunk(v, (3,4), (slice(None),slice(None)))
print(v.chunks, '=>', out.chunks)
np.testing.assert_array_equal(out.compute(), v.compute())

with tempfile.TemporaryDirectory() as store:
    arr = xr.DataArray(np.arange(4), dims=['a'], name='foo').chunk(a=(2,1,1))
    arr.to_zarr(store, align_chunks=True, encoding={'foo': {'chunks': (3,)}})
    actual = xr.open_dataarray(store)
    xr.testing.assert_identical(arr, actual)
    actual.close()
print('zarr roundtrip passed')
PY
python -m compileall -q xarray/backends/chunks.py xarray/backends/zarr.py"
```

退出码：`0`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 12, in <module>
  File "/testbed/xarray/backends/chunks.py", line 146, in grid_rechunk
    return v.chunk(aligned_chunks)
           ^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/xarray/core/variable.py", line 2727, in chunk
    return super().chunk(
           ^^^^^^^^^^^^^^
  File "/testbed/xarray/namedarray/core.py", line 832, in chunk
    data_chunked = chunkmanager.rechunk(data_old, chunks)  # type: ignore[arg-type]
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/xarray/namedarray/parallelcompat.py", line 352, in rechunk
    if _contains_cftime_datetimes(data):
       ^^^^^^^^^^^^^^^^^^^^^^^^^^
NameError: name '_contains_cftime_datetimes' is not defined
```

## 原始行 56 · command_execution

命令：
```
/bin/bash -lc "grep -R -n --exclude-dir=.git \"_contains_cftime_datetimes\" xarray | head -100; sed -n '1,180p' xarray/core/common.py; sed -n '300,375p' xarray/namedarray/parallelcompat.py; git diff --stat"
```

退出码：`0`

输出：
```
grep: xarray/coding/__pycache__/cftimeindex.cpython-311.pyc: binary file matches
grep: xarray/core/__pycache__/common.cpython-311.pyc: binary file matches
grep: xarray/core/__pycache__/duck_array_ops.cpython-311.pyc: binary file matches
grep: xarray/__pycache__/groupers.cpython-311.pyc: binary file matches
grep: xarray/tests/__pycache__/test_backends.cpython-311-pytest-9.0.1.pyc: binary file matches
grep: xarray/namedarray/__pycache__/utils.cpython-311.pyc: binary file matches
grep: xarray/namedarray/__pycache__/parallelcompat.cpython-311.pyc: binary file matches
xarray/coding/cftimeindex.py:532:        if _contains_cftime_datetimes(np.array(other)):
xarray/core/common.py:2095:    return _contains_cftime_datetimes(var._data)
xarray/core/common.py:2119:        or _contains_cftime_datetimes(var._data)
xarray/core/duck_array_ops.py:751:    from xarray.core.common import _contains_cftime_datetimes
xarray/core/duck_array_ops.py:771:    elif _contains_cftime_datetimes(array):
xarray/tests/test_backends.py:63:from xarray.core.common import _contains_cftime_datetimes
xarray/tests/test_backends.py:6325:            assert _contains_cftime_datetimes(actual.time)
xarray/tests/test_coding_times.py:840:def test_contains_cftime_datetimes_1d(data) -> None:
xarray/tests/test_coding_times.py:846:def test_contains_cftime_datetimes_dask_1d(data) -> None:
xarray/tests/test_coding_times.py:851:def test_contains_cftime_datetimes_3d(times_3d) -> None:
xarray/tests/test_coding_times.py:857:def test_contains_cftime_datetimes_dask_3d(times_3d) -> None:
xarray/tests/test_coding_times.py:862:def test_contains_cftime_datetimes_non_cftimes(non_cftime_data) -> None:
xarray/tests/test_coding_times.py:868:def test_contains_cftime_datetimes_non_cftimes_dask(non_cftime_data) -> None:
xarray/tests/test_coding_times.py:1355:    from xarray.core.common import _contains_cftime_datetimes
xarray/tests/test_coding_times.py:1362:    assert _contains_cftime_datetimes(array)
xarray/groupers.py:958:        if _contains_cftime_datetimes(group.data):
xarray/namedarray/utils.py:214:    from xarray.core.common import _contains_cftime_datetimes
xarray/namedarray/utils.py:233:    if _contains_cftime_datetimes(data):
xarray/namedarray/utils.py:285:    from xarray.core.common import _contains_cftime_datetimes
xarray/namedarray/utils.py:287:    if not _contains_cftime_datetimes(data):
xarray/namedarray/parallelcompat.py:352:        if _contains_cftime_datetimes(data):
from __future__ import annotations

import datetime
import warnings
from collections.abc import Callable, Hashable, Iterable, Iterator, Mapping
from contextlib import suppress
from html import escape
from textwrap import dedent
from typing import TYPE_CHECKING, Any, Concatenate, ParamSpec, TypeVar, Union, overload

import numpy as np
import pandas as pd

from xarray.core import dtypes, duck_array_ops, formatting, formatting_html
from xarray.core.indexing import BasicIndexer, ExplicitlyIndexed
from xarray.core.options import OPTIONS, _get_keep_attrs
from xarray.core.types import ResampleCompatible
from xarray.core.utils import (
    Frozen,
    either_dict_or_kwargs,
    is_scalar,
)
from xarray.namedarray.core import _raise_if_any_duplicate_dimensions
from xarray.namedarray.parallelcompat import get_chunked_array_type, guess_chunkmanager
from xarray.namedarray.pycompat import is_chunked_array

try:
    import cftime
except ImportError:
    cftime = None

# Used as a sentinel value to indicate a all dimensions
ALL_DIMS = ...


if TYPE_CHECKING:
    from numpy.typing import DTypeLike

    from xarray.computation.rolling_exp import RollingExp
    from xarray.core.dataarray import DataArray
    from xarray.core.dataset import Dataset
    from xarray.core.indexes import Index
    from xarray.core.resample import Resample
    from xarray.core.types import (
        DatetimeLike,
        DTypeLikeSave,
        ScalarOrArray,
        Self,
        SideOptions,
        T_Chunks,
        T_DataWithCoords,
        T_Variable,
    )
    from xarray.core.variable import Variable
    from xarray.groupers import Resampler

    DTypeMaybeMapping = Union[DTypeLikeSave, Mapping[Any, DTypeLikeSave]]


T_Resample = TypeVar("T_Resample", bound="Resample")
C = TypeVar("C")
T = TypeVar("T")
P = ParamSpec("P")


class ImplementsArrayReduce:
    __slots__ = ()

    @classmethod
    def _reduce_method(cls, func: Callable, include_skipna: bool, numeric_only: bool):
        if include_skipna:

            def wrapped_func(self, dim=None, axis=None, skipna=None, **kwargs):
                return self.reduce(
                    func=func, dim=dim, axis=axis, skipna=skipna, **kwargs
                )

        else:

            def wrapped_func(self, dim=None, axis=None, **kwargs):  # type: ignore[misc]
                return self.reduce(func=func, dim=dim, axis=axis, **kwargs)

        return wrapped_func

    _reduce_extra_args_docstring = dedent(
        """\
        dim : str or sequence of str, optional
            Dimension(s) over which to apply `{name}`.
        axis : int or sequence of int, optional
            Axis(es) over which to apply `{name}`. Only one of the 'dim'
            and 'axis' arguments can be supplied. If neither are supplied, then
            `{name}` is calculated over axes."""
    )

    _cum_extra_args_docstring = dedent(
        """\
        dim : str or sequence of str, optional
            Dimension over which to apply `{name}`.
        axis : int or sequence of int, optional
            Axis over which to apply `{name}`. Only one of the 'dim'
            and 'axis' arguments can be supplied."""
    )


class ImplementsDatasetReduce:
    __slots__ = ()

    @classmethod
    def _reduce_method(cls, func: Callable, include_skipna: bool, numeric_only: bool):
        if include_skipna:

            def wrapped_func(self, dim=None, skipna=None, **kwargs):
                return self.reduce(
                    func=func,
                    dim=dim,
                    skipna=skipna,
                    numeric_only=numeric_only,
                    **kwargs,
                )

        else:

            def wrapped_func(self, dim=None, **kwargs):  # type: ignore[misc]
                return self.reduce(
                    func=func, dim=dim, numeric_only=numeric_only, **kwargs
                )

        return wrapped_func

    _reduce_extra_args_docstring = dedent(
        """
        dim : str or sequence of str, optional
            Dimension(s) over which to apply `{name}`.  By default `{name}` is
            applied over all dimensions.
        """
    ).strip()

    _cum_extra_args_docstring = dedent(
        """
        dim : str or sequence of str, optional
            Dimension over which to apply `{name}`.
        axis : int or sequence of int, optional
            Axis over which to apply `{name}`. Only one of the 'dim'
            and 'axis' arguments can be supplied.
        """
    ).strip()


class AbstractArray:
    """Shared base class for DataArray and Variable."""

    __slots__ = ()

    def __bool__(self: Any) -> bool:
        return bool(self.values)

    def __float__(self: Any) -> float:
        return float(self.values)

    def __int__(self: Any) -> int:
        return int(self.values)

    def __complex__(self: Any) -> complex:
        return complex(self.values)

    def __array__(
        self: Any, dtype: DTypeLike | None = None, /, *, copy: bool | None = None
    ) -> np.ndarray:
        if not copy:
            if np.lib.NumpyVersion(np.__version__) >= "2.0.0":
                copy = None
            elif np.lib.NumpyVersion(np.__version__) <= "1.28.0":
                copy = False
            else:
                # 2.0.0 dev versions, handle cases where copy may or may not exist
                try:
                    np.array([1]).__array__(copy=None)
                    copy = None
                except TypeError:
                    copy = False

        Generally input should have a ``.shape``, ``.ndim``, ``.dtype`` and support numpy-style slicing.

        Called when the .chunk method is called on an xarray object that is not already chunked.
        Also called within open_dataset (when chunks is not None) to create a chunked array from
        an xarray lazily indexed array.

        Parameters
        ----------
        data : array_like
        chunks : int, tuple
            How to chunk the array.

        See Also
        --------
        dask.array.from_array
        cubed.from_array
        """
        raise NotImplementedError()

    def rechunk(
        self,
        data: T_ChunkedArray,
        chunks: _NormalizedChunks | tuple[int, ...] | _Chunks,
        **kwargs: Any,
    ) -> Any:
        """
        Changes the chunking pattern of the given array.

        Called when the .chunk method is called on an xarray object that is already chunked.

        Parameters
        ----------
        data : dask array
            Array to be rechunked.
        chunks :  int, tuple, dict or str, optional
            The new block dimensions to create. -1 indicates the full size of the
            corresponding dimension. Default is "auto" which automatically
            determines chunk sizes.

        Returns
        -------
        chunked array

        See Also
        --------
        dask.array.Array.rechunk
        cubed.Array.rechunk
        """

        from xarray.namedarray.utils import _get_chunk

        if _contains_cftime_datetimes(data):
            chunks2 = _get_chunk(data, chunks, self, preferred_chunks={})  # type: ignore[arg-type]
        else:
            chunks2 = chunks  # type: ignore[assignment]
        return data.rechunk(chunks2, **kwargs)

    @abstractmethod
    def compute(
        self, *data: T_ChunkedArray | Any, **kwargs: Any
    ) -> tuple[np.ndarray[Any, _DType_co], ...]:
        """
        Computes one or more chunked arrays, returning them as eager numpy arrays.

        Called anytime something needs to computed, including multiple arrays at once.
        Used by `.compute`, `.persist`, `.values`.

        Parameters
        ----------
        *data : object
            Any number of objects. If an object is an instance of the chunked array type, it is computed
            and the in-memory result returned as a numpy array. All other types should be passed through unchanged.

        Returns
        -------
 xarray/backends/chunks.py | 145 +++++++++++++++++++++++++++++++++++++++++++++-
 xarray/backends/zarr.py   |   2 +-
 2 files changed, 145 insertions(+), 2 deletions(-)
```

## 原始行 59 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,90p' xarray/namedarray/parallelcompat.py; nl -ba xarray/core/common.py | sed -n '2020,2140p'; git status --short"
```

退出码：`0`

输出：
```
"""
The code in this module is an experiment in going from N=1 to N=2 parallel computing frameworks in xarray.
It could later be used as the basis for a public interface allowing any N frameworks to interoperate with xarray,
but for now it is just a private experiment.
"""

from __future__ import annotations

import functools
from abc import ABC, abstractmethod
from collections.abc import Callable, Iterable, Sequence
from importlib.metadata import EntryPoint, entry_points
from typing import TYPE_CHECKING, Any, Generic, Protocol, TypeVar

import numpy as np

from xarray.core.options import OPTIONS
from xarray.core.utils import emit_user_level_warning
from xarray.namedarray.pycompat import is_chunked_array

if TYPE_CHECKING:
    from xarray.namedarray._typing import (
        T_Chunks,
        _Chunks,
        _DType,
        _DType_co,
        _NormalizedChunks,
        _ShapeType,
        duckarray,
    )


class ChunkedArrayMixinProtocol(Protocol):
    def rechunk(self, chunks: Any, **kwargs: Any) -> Any: ...

    @property
    def dtype(self) -> np.dtype[Any]: ...

    @property
    def chunks(self) -> _NormalizedChunks: ...

    def compute(
        self, *data: Any, **kwargs: Any
    ) -> tuple[np.ndarray[Any, _DType_co], ...]: ...


T_ChunkedArray = TypeVar("T_ChunkedArray", bound=ChunkedArrayMixinProtocol)

KNOWN_CHUNKMANAGERS = {
    "dask": "dask",
    "cubed": "cubed-xarray",
    "arkouda": "arkouda-xarray",
}


@functools.lru_cache(maxsize=1)
def list_chunkmanagers() -> dict[str, ChunkManagerEntrypoint[Any]]:
    """
    Return a dictionary of available chunk managers and their ChunkManagerEntrypoint subclass objects.

    Returns
    -------
    chunkmanagers : dict
        Dictionary whose values are registered ChunkManagerEntrypoint subclass instances, and whose values
        are the strings under which they are registered.
    """
    entrypoints = entry_points(group="xarray.chunkmanagers")

    return load_chunkmanagers(entrypoints)


def load_chunkmanagers(
    entrypoints: Sequence[EntryPoint],
) -> dict[str, ChunkManagerEntrypoint[Any]]:
    """Load entrypoints and instantiate chunkmanagers only once."""

    loaded_entrypoints = {}
    for entrypoint in entrypoints:
        try:
            loaded_entrypoints[entrypoint.name] = entrypoint.load()
        except ModuleNotFoundError as e:
            emit_user_level_warning(
                f"Failed to load chunk manager entrypoint {entrypoint.name} due to {e}. Skipping.",
            )

    available_chunkmanagers = {
        name: chunkmanager()
        for name, chunkmanager in loaded_entrypoints.items()
        if chunkmanager.available
    }
  2020	    >>> x
  2021	    <xarray.DataArray (lat: 2, lon: 3)> Size: 48B
  2022	    array([[0, 1, 2],
  2023	           [3, 4, 5]])
  2024	    Coordinates:
  2025	      * lat      (lat) int64 16B 1 2
  2026	      * lon      (lon) int64 24B 0 1 2
  2027	
  2028	    >>> xr.ones_like(x)
  2029	    <xarray.DataArray (lat: 2, lon: 3)> Size: 48B
  2030	    array([[1, 1, 1],
  2031	           [1, 1, 1]])
  2032	    Coordinates:
  2033	      * lat      (lat) int64 16B 1 2
  2034	      * lon      (lon) int64 24B 0 1 2
  2035	
  2036	    See Also
  2037	    --------
  2038	    zeros_like
  2039	    full_like
  2040	
  2041	    """
  2042	    return full_like(
  2043	        other,
  2044	        1,
  2045	        dtype,
  2046	        chunks=chunks,
  2047	        chunked_array_type=chunked_array_type,
  2048	        from_array_kwargs=from_array_kwargs,
  2049	    )
  2050	
  2051	
  2052	def get_chunksizes(
  2053	    variables: Iterable[Variable],
  2054	) -> Mapping[Any, tuple[int, ...]]:
  2055	    chunks: dict[Any, tuple[int, ...]] = {}
  2056	    for v in variables:
  2057	        if hasattr(v._data, "chunks"):
  2058	            for dim, c in v.chunksizes.items():
  2059	                if dim in chunks and c != chunks[dim]:
  2060	                    raise ValueError(
  2061	                        f"Object has inconsistent chunks along dimension {dim}. "
  2062	                        "This can be fixed by calling unify_chunks()."
  2063	                    )
  2064	                chunks[dim] = c
  2065	    return Frozen(chunks)
  2066	
  2067	
  2068	def is_np_datetime_like(dtype: DTypeLike | None) -> bool:
  2069	    """Check if a dtype is a subclass of the numpy datetime types"""
  2070	    return np.issubdtype(dtype, np.datetime64) or np.issubdtype(dtype, np.timedelta64)
  2071	
  2072	
  2073	def is_np_timedelta_like(dtype: DTypeLike | None) -> bool:
  2074	    """Check whether dtype is of the timedelta64 dtype."""
  2075	    return np.issubdtype(dtype, np.timedelta64)
  2076	
  2077	
  2078	
  2079	
  2080	
  2081	
  2082	
  2083	
  2084	
  2085	
  2086	
  2087	
  2088	
  2089	
  2090	
  2091	
  2092	
  2093	def contains_cftime_datetimes(var: T_Variable) -> bool:
  2094	    """Check if an xarray.Variable contains cftime.datetime objects"""
  2095	    return _contains_cftime_datetimes(var._data)
  2096	
  2097	
  2098	def _contains_datetime_like_objects(var: T_Variable) -> bool:
  2099	    """Check if a variable contains datetime like objects (either
  2100	    np.datetime64, np.timedelta64, or cftime.datetime)
  2101	    """
  2102	    return is_np_datetime_like(var.dtype) or contains_cftime_datetimes(var)
  2103	
  2104	
  2105	def _is_numeric_aggregatable_dtype(var: T_Variable) -> bool:
  2106	    """Check if a variable's dtype can be used in numeric aggregations like mean().
  2107	
  2108	    This includes:
  2109	    - Numeric types (int, float, complex)
  2110	    - Boolean type
  2111	    - Datetime types (datetime64, timedelta64)
  2112	    - Object arrays containing datetime-like objects (e.g., cftime)
  2113	    """
  2114	    return (
  2115	        np.issubdtype(var.dtype, np.number)
  2116	        or (var.dtype == np.bool_)
  2117	        or np.issubdtype(var.dtype, np.datetime64)
  2118	        or np.issubdtype(var.dtype, np.timedelta64)
  2119	        or _contains_cftime_datetimes(var._data)
  2120	    )
 M xarray/backends/chunks.py
 M xarray/backends/zarr.py
```

## 原始行 62 · command_execution

命令：
```
/bin/bash -lc "sed -n '810,880p' xarray/tests/test_coding_times.py; sed -n '1335,1370p' xarray/tests/test_coding_times.py; sed -n '180,250p' xarray/namedarray/utils.py; sed -n '250,305p' xarray/namedarray/utils.py"
```

退出码：`0`

输出：
```

    return cftime.num2date(
        np.arange(4),
        units="hours since 2000-01-01",
        calendar=calendar,
        only_use_cftime_datetimes=True,
    )


@pytest.fixture
def data(times):
    data = np.random.rand(2, 2, 4)
    lons = np.linspace(0, 11, 2)
    lats = np.linspace(0, 20, 2)
    return DataArray(
        data, coords=[lons, lats, times], dims=["lon", "lat", "time"], name="data"
    )


@pytest.fixture
def times_3d(times):
    lons = np.linspace(0, 11, 2)
    lats = np.linspace(0, 20, 2)
    times_arr = np.random.choice(times, size=(2, 2, 4))
    return DataArray(
        times_arr, coords=[lons, lats, times], dims=["lon", "lat", "time"], name="data"
    )


@requires_cftime
def test_contains_cftime_datetimes_1d(data) -> None:
    assert contains_cftime_datetimes(data.time.variable)


@requires_cftime
@requires_dask
def test_contains_cftime_datetimes_dask_1d(data) -> None:
    assert contains_cftime_datetimes(data.time.variable.chunk())


@requires_cftime
def test_contains_cftime_datetimes_3d(times_3d) -> None:
    assert contains_cftime_datetimes(times_3d.variable)


@requires_cftime
@requires_dask
def test_contains_cftime_datetimes_dask_3d(times_3d) -> None:
    assert contains_cftime_datetimes(times_3d.variable.chunk())


@pytest.mark.parametrize("non_cftime_data", [DataArray([]), DataArray([1, 2])])
def test_contains_cftime_datetimes_non_cftimes(non_cftime_data) -> None:
    assert not contains_cftime_datetimes(non_cftime_data.variable)


@requires_dask
@pytest.mark.parametrize("non_cftime_data", [DataArray([]), DataArray([1, 2])])
def test_contains_cftime_datetimes_non_cftimes_dask(non_cftime_data) -> None:
    assert not contains_cftime_datetimes(non_cftime_data.variable.chunk())


@requires_cftime
@pytest.mark.parametrize("shape", [(24,), (8, 3), (2, 4, 3)])
def test_encode_cf_datetime_overflow(shape) -> None:
    # Test for fix to GH 2272
    dates = pd.date_range("2100", periods=24).values.reshape(shape)
    units = "days since 1800-01-01"
    calendar = "standard"

    num, _, _ = encode_cf_datetime(dates, units, calendar)
    values = np.array([num], dtype="float32")
    with pytest.warns(
        SerializationWarning,
        match=f"Can't decode floating point datetimes to {time_unit!r}",
    ):
        decode_cf_datetime(values, units, calendar, time_unit=time_unit)


@requires_cftime
def test_scalar_unit() -> None:
    # test that a scalar units (often NaN when using to_netcdf) does not raise an error
    variable = Variable(("x", "y"), np.array([[0, 1], [2, 3]]), {"units": np.nan})
    result = CFDatetimeCoder().decode(variable)
    assert np.isnan(result.attrs["units"])


@requires_cftime
def test_contains_cftime_lazy() -> None:
    import cftime

    from xarray.core.common import _contains_cftime_datetimes

    times = np.array(
        [cftime.DatetimeGregorian(1, 1, 2, 0), cftime.DatetimeGregorian(1, 1, 2, 0)],
        dtype=object,
    )
    array = FirstElementAccessibleArray(times)
    assert _contains_cftime_datetimes(array)


@pytest.mark.parametrize(
    "timestr, format, dtype, fill_value, use_encoding",
    [
        ("1677-09-21T00:12:43.145224193", "ns", np.int64, 20, True),
        ("1970-09-21T00:12:44.145224808", "ns", np.float64, 1e30, True),
        (
            )
        yield from existing_dims


def either_dict_or_kwargs(
    pos_kwargs: Mapping[Any, T] | None,
    kw_kwargs: Mapping[str, T],
    func_name: str,
) -> Mapping[Hashable, T]:
    if pos_kwargs is None or pos_kwargs == {}:
        # Need an explicit cast to appease mypy due to invariance; see
        # https://github.com/python/mypy/issues/6228
        return cast(Mapping[Hashable, T], kw_kwargs)

    if not is_dict_like(pos_kwargs):
        raise ValueError(f"the first argument to .{func_name} must be a dictionary")
    if kw_kwargs:
        raise ValueError(
            f"cannot specify both keyword and positional arguments to .{func_name}"
        )
    return pos_kwargs


def _get_chunk(  # type: ignore[no-untyped-def]
    data: DuckArray[Any],
    chunks,
    chunkmanager: ChunkManagerEntrypoint[Any],
    *,
    preferred_chunks,
    dims=None,
) -> Mapping[Any, T_ChunkDim]:
    """
    Return map from each dim to chunk sizes, accounting for backend's preferred chunks.
    """
    from xarray.core.common import _contains_cftime_datetimes
    from xarray.core.utils import emit_user_level_warning
    from xarray.structure.chunks import _get_breaks_cached

    dims = chunks.keys() if dims is None else dims
    shape = data.shape

    # Determine the explicit requested chunks.
    preferred_chunk_shape = tuple(
        itertools.starmap(preferred_chunks.get, zip(dims, shape, strict=True))
    )
    if isinstance(chunks, Number) or (chunks == "auto"):
        chunks = dict.fromkeys(dims, chunks)
    chunk_shape = tuple(
        chunks.get(dim, None) or preferred_chunk_sizes
        for dim, preferred_chunk_sizes in zip(dims, preferred_chunk_shape, strict=True)
    )

    limit: int | None
    if _contains_cftime_datetimes(data):
        limit, dtype = fake_target_chunksize(data, chunkmanager.get_auto_chunk_size())
    else:
        limit = None
        dtype = data.dtype

    chunk_shape = chunkmanager.normalize_chunks(
        chunk_shape,
        shape=shape,
        dtype=dtype,
        limit=limit,
        previous_chunks=preferred_chunk_shape,
    )

    # Warn where requested chunks break preferred chunks, provided that the variable
    # contains data.
    if data.size:  # type: ignore[unused-ignore,attr-defined]  # DuckArray protocol doesn't include 'size' - should it?
        for dim, size, chunk_sizes in zip(dims, shape, chunk_shape, strict=True):
        for dim, size, chunk_sizes in zip(dims, shape, chunk_shape, strict=True):
            if preferred_chunk_sizes := preferred_chunks.get(dim):
                disagreement = _get_breaks_cached(
                    size=size,
                    chunk_sizes=chunk_sizes,
                    preferred_chunk_sizes=preferred_chunk_sizes,
                )
                if disagreement:
                    emit_user_level_warning(
                        "The specified chunks separate the stored chunks along "
                        f'dimension "{dim}" starting at index {disagreement}. This could '
                        "degrade performance. Instead, consider rechunking after loading.",
                    )

    return dict(zip(dims, chunk_shape, strict=True))


def fake_target_chunksize(
    data: DuckArray[Any],
    limit: int,
) -> tuple[int, np.dtype[Any]]:
    """
    The `normalize_chunks` algorithm takes a size `limit` in bytes, but will not
    work for object dtypes.  So we rescale the `limit` to an appropriate one based
    on `float64` dtype, and pass that to `normalize_chunks`.

    Arguments
    ---------
    data : Variable or ChunkedArray
        The data for which we want to determine chunk sizes.
    limit : int
        The target chunk size in bytes. Passed to the chunk manager's `normalize_chunks` method.
    """

    # Short circuit for non-object dtypes
    from xarray.core.common import _contains_cftime_datetimes

    if not _contains_cftime_datetimes(data):
        return limit, data.dtype

    from xarray.core.formatting import first_n_items

    output_dtype = np.dtype(np.float64)

    nbytes_approx: int = sys.getsizeof(first_n_items(data, 1))  # type: ignore[no-untyped-call]

    f64_nbytes = output_dtype.itemsize

    limit = int(limit * (f64_nbytes / nbytes_approx))

    return limit, output_dtype


class ReprObject:
    """Object that prints as the given value, for use with sentinel values."""
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"class FirstElementAccessibleArray\" xarray/tests; grep -R -n \"def first_n_items\\|def first_n_items\" xarray/core xarray/namedarray | head -20; sed -n '50,95p' xarray/tests/test_coding_times.py; grep -n \"first_n_items\" xarray/core/formatting.py | head -10"
```

退出码：`0`

输出：
```
xarray/tests/arrays.py:36:class FirstElementAccessibleArray(InaccessibleArray):
xarray/core/formatting.py:77:def first_n_items(array, n_desired):
    arm_xfail,
    assert_array_equal,
    assert_duckarray_allclose,
    assert_duckarray_equal,
    assert_no_warnings,
    has_cftime,
    requires_cftime,
    requires_dask,
)

_CF_DATETIME_NUM_DATES_UNITS = [
    (np.arange(10), "days since 2000-01-01", "s"),
    (np.arange(10).astype("float64"), "days since 2000-01-01", "s"),
    (np.arange(10).astype("float32"), "days since 2000-01-01", "s"),
    (np.arange(10).reshape(2, 5), "days since 2000-01-01", "s"),
    (12300 + np.arange(5), "hours since 1680-01-01 00:00:00", "s"),
    # here we add a couple minor formatting errors to test
    # the robustness of the parsing algorithm.
    (12300 + np.arange(5), "hour since 1680-01-01  00:00:00", "s"),
    (12300 + np.arange(5), "Hour  since 1680-01-01 00:00:00", "s"),
    (12300 + np.arange(5), " Hour  since  1680-01-01 00:00:00 ", "s"),
    (10, "days since 2000-01-01", "s"),
    ([10], "daYs  since 2000-01-01", "s"),
    ([[10]], "days since 2000-01-01", "s"),
    ([10, 10], "days since 2000-01-01", "s"),
    (np.array(10), "days since 2000-01-01", "s"),
    (0, "days since 1000-01-01", "s"),
    ([0], "days since 1000-01-01", "s"),
    ([[0]], "days since 1000-01-01", "s"),
    (np.arange(2), "days since 1000-01-01", "s"),
    (np.arange(0, 100000, 20000), "days since 1900-01-01", "s"),
    (np.arange(0, 100000, 20000), "days since 1-01-01", "s"),
    (17093352.0, "hours since 1-1-1 00:00:0.0", "s"),
    ([0.5, 1.5], "hours since 1900-01-01T00:00:00", "s"),
    (0, "milliseconds since 2000-01-01T00:00:00", "s"),
    (0, "microseconds since 2000-01-01T00:00:00", "s"),
    (np.int32(788961600), "seconds since 1981-01-01", "s"),  # GH2002
    (12300 + np.arange(5), "hour since 1680-01-01 00:00:00.500000", "us"),
    (164375, "days since 1850-01-01 00:00:00", "s"),
    (164374.5, "days since 1850-01-01 00:00:00", "s"),
    ([164374.5, 168360.5], "days since 1850-01-01 00:00:00", "s"),
]
_CF_DATETIME_TESTS = [
    num_dates_units + (calendar,)
    for num_dates_units, calendar in product(
        _CF_DATETIME_NUM_DATES_UNITS, _STANDARD_CALENDAR_NAMES
77:def first_n_items(array, n_desired):
235:        first_n_items(array, (max_possibly_relevant + 1) // 2)
```

## 原始行 67 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,65p' xarray/tests/arrays.py; sed -n '65,100p' xarray/core/formatting.py; sed -n '1,35p' xarray/tests/test_coding_times.py"
```

退出码：`0`

输出：
```
"""
This module contains various lazy array classes which can be wrapped and manipulated by xarray objects but will raise on data access.
"""

from collections.abc import Callable, Iterable
from typing import Any, Self

import numpy as np

from xarray.core import utils
from xarray.core.indexing import ExplicitlyIndexed


class UnexpectedDataAccess(Exception):
    pass


class InaccessibleArray(utils.NDArrayMixin, ExplicitlyIndexed):
    """Disallows any loading."""

    def __init__(self, array):
        self.array = array

    def get_duck_array(self):
        raise UnexpectedDataAccess("Tried accessing data")

    def __array__(
        self, dtype: np.typing.DTypeLike | None = None, /, *, copy: bool | None = None
    ) -> np.ndarray:
        raise UnexpectedDataAccess("Tried accessing data")

    def __getitem__(self, key):
        raise UnexpectedDataAccess("Tried accessing data.")


class FirstElementAccessibleArray(InaccessibleArray):
    def __getitem__(self, key):
        tuple_idxr = key.tuple
        if len(tuple_idxr) > 1:
            raise UnexpectedDataAccess("Tried accessing more than one element.")
        return self.array[tuple_idxr]


class DuckArrayWrapper(utils.NDArrayMixin):
    """Array-like that prevents casting to array.
    Modeled after cupy."""

    def __init__(self, array: np.ndarray):
        self.array = array

    def __getitem__(self, key):
        return type(self)(self.array[key])

    def to_numpy(self) -> np.ndarray:
        """Allow explicit conversions to numpy in `to_numpy`, but disallow np.asarray etc."""
        return self.array

    def __array__(
        self, dtype: np.typing.DTypeLike | None = None, /, *, copy: bool | None = None
    ) -> np.ndarray:
        raise UnexpectedDataAccess("Tried accessing data")

    def __array_namespace__(self):
        """Present to satisfy is_duck_array test."""
        from xarray.tests import namespace
    assert 0 < n_desired <= math.prod(shape)
    cum_items = np.cumprod(shape[::-1])
    n_steps = np.argmax(cum_items >= n_desired)
    stop = math.ceil(float(n_desired) / np.r_[1, cum_items][n_steps])
    indexer = (
        ((-1 if from_end else 0),) * (len(shape) - 1 - n_steps)
        + ((slice(-stop, None) if from_end else slice(stop)),)
        + (slice(None),) * n_steps
    )
    return indexer


def first_n_items(array, n_desired):
    """Returns the first n_desired items of an array"""
    # Unfortunately, we can't just do array.flat[:n_desired] here because it
    # might not be a numpy.ndarray. Moreover, access to elements of the array
    # could be very expensive (e.g. if it's only available over DAP), so go out
    # of our way to get them in a single call to __getitem__ using only slices.
    from xarray.core.variable import Variable

    if n_desired < 1:
        raise ValueError("must request at least one item")

    if array.size == 0:
        # work around for https://github.com/numpy/numpy/issues/5195
        return []

    if n_desired < array.size:
        indexer = _get_indexer_at_least_n_items(array.shape, n_desired, from_end=False)
        if isinstance(array, ExplicitlyIndexed):
            indexer = BasicIndexer(indexer)
        array = array[indexer]

    # We pass variable objects in to handle indexing
    # with indexer above. It would not work with our
    # lazy indexing classes at the moment, so we cannot
from __future__ import annotations

import warnings
from datetime import datetime, timedelta
from itertools import product, starmap
from typing import Literal

import numpy as np
import pandas as pd
import pytest
from pandas.errors import OutOfBoundsDatetime, OutOfBoundsTimedelta

from xarray import (
    DataArray,
    Dataset,
    Variable,
    conventions,
    date_range,
    decode_cf,
)
from xarray.coders import CFDatetimeCoder, CFTimedeltaCoder
from xarray.coding.times import (
    _encode_datetime_with_cftime,
    _netcdf_to_numpy_timeunit,
    _numpy_to_netcdf_timeunit,
    _should_cftime_be_used,
    cftime_to_nptime,
    decode_cf_datetime,
    decode_cf_timedelta,
    encode_cf_datetime,
    encode_cf_timedelta,
    format_cftime_datetime,
    infer_datetime_units,
    infer_timedelta_units,
)
```

## 原始行 69 · command_execution

命令：
```
/bin/bash -lc "sed -n '100,130p' xarray/core/formatting.py; grep -R -n \"isinstance.*cftime.datetime\\|cftime.datetime\" xarray/core xarray/coding | head -100"
```

退出码：`0`

输出：
```
    # lazy indexing classes at the moment, so we cannot
    # pass Variable._data
    if isinstance(array, Variable):
        array = array._data
    return ravel(to_duck_array(array))[:n_desired]


def last_n_items(array, n_desired):
    """Returns the last n_desired items of an array"""
    # Unfortunately, we can't just do array.flat[-n_desired:] here because it
    # might not be a numpy.ndarray. Moreover, access to elements of the array
    # could be very expensive (e.g. if it's only available over DAP), so go out
    # of our way to get them in a single call to __getitem__ using only slices.
    from xarray.core.variable import Variable

    if (n_desired == 0) or (array.size == 0):
        return []

    if n_desired < array.size:
        indexer = _get_indexer_at_least_n_items(array.shape, n_desired, from_end=True)
        if isinstance(array, ExplicitlyIndexed):
            indexer = BasicIndexer(indexer)
        array = array[indexer]

    # We pass variable objects in to handle indexing
    # with indexer above. It would not work with our
    # lazy indexing classes at the moment, so we cannot
    # pass Variable._data
    if isinstance(array, Variable):
        array = array._data
    return ravel(to_duck_array(array))[-n_desired:]
grep: xarray/core/__pycache__/resample_cftime.cpython-311.pyc: binary file matches
grep: xarray/core/__pycache__/common.cpython-311.pyc: binary file matches
grep: xarray/core/__pycache__/dataset.cpython-311.pyc: binary file matches
grep: xarray/core/__pycache__/duck_array_ops.cpython-311.pyc: binary file matches
grep: xarray/core/__pycache__/dataarray.cpython-311.pyc: binary file matches
grep: xarray/core/__pycache__/accessor_dt.cpython-311.pyc: binary file matches
grep: xarray/coding/__pycache__/cftimeindex.cpython-311.pyc: binary file matches
grep: xarray/coding/__pycache__/frequencies.cpython-311.pyc: binary file matches
xarray/core/dataarray.py:6749:            date range permits it, and :py:class:`cftime.datetime` objects if not.
xarray/core/dataarray.py:7456:        origin : {'epoch', 'start', 'start_day', 'end', 'end_day'}, pd.Timestamp, datetime.datetime, np.datetime64, or cftime.datetime, default 'start_day'
xarray/core/common.py:948:        origin : {'epoch', 'start', 'start_day', 'end', 'end_day'}, pd.Timestamp, datetime.datetime, np.datetime64, or cftime.datetime, default 'start_day'
xarray/core/common.py:2093:def contains_cftime_datetimes(var: T_Variable) -> bool:
xarray/core/common.py:2094:    """Check if an xarray.Variable contains cftime.datetime objects"""
xarray/core/common.py:2095:    return _contains_cftime_datetimes(var._data)
xarray/core/common.py:2100:    np.datetime64, np.timedelta64, or cftime.datetime)
xarray/core/common.py:2102:    return is_np_datetime_like(var.dtype) or contains_cftime_datetimes(var)
xarray/core/common.py:2119:        or _contains_cftime_datetimes(var._data)
xarray/core/dataset.py:9879:            date range permits it, and :py:class:`cftime.datetime` objects if not.
xarray/core/dataset.py:10400:        origin : {'epoch', 'start', 'start_day', 'end', 'end_day'}, pd.Timestamp, datetime.datetime, np.datetime64, or cftime.datetime, default 'start_day'
xarray/core/duck_array_ops.py:616:    offset : None, datetime or cftime.datetime
xarray/core/duck_array_ops.py:749:    """inhouse mean that can handle np.datetime64 or cftime.datetime
xarray/core/duck_array_ops.py:751:    from xarray.core.common import _contains_cftime_datetimes
xarray/core/duck_array_ops.py:771:    elif _contains_cftime_datetimes(array):
xarray/core/resample_cftime.py:112:            # specific ``cftime.datetime`` index stands for the resample result
xarray/core/resample_cftime.py:113:            # from the current ``cftime.datetime`` minus ``freq`` to the current
xarray/core/resample_cftime.py:114:            # ``cftime.datetime`` with a right close.
xarray/core/resample_cftime.py:199:    origin : {'epoch', 'start', 'start_day', 'end', 'end_day'} or cftime.datetime, default 'start_day'
xarray/core/resample_cftime.py:309:    first : cftime.datetime
xarray/core/resample_cftime.py:312:    last : cftime.datetime
xarray/core/resample_cftime.py:321:    origin : {'epoch', 'start', 'start_day', 'end', 'end_day'} or cftime.datetime, default 'start_day'
xarray/core/resample_cftime.py:336:    first : cftime.datetime
xarray/core/resample_cftime.py:338:    last : cftime.datetime
xarray/core/resample_cftime.py:370:    first : cftime.datetime
xarray/core/resample_cftime.py:372:    last : cftime.datetime
xarray/core/resample_cftime.py:380:    origin : {'epoch', 'start', 'start_day', 'end', 'end_day'} or cftime.datetime, default 'start_day'
xarray/core/resample_cftime.py:395:    fresult : cftime.datetime
xarray/core/resample_cftime.py:398:    lresult : cftime.datetime
xarray/core/resample_cftime.py:417:    elif isinstance(origin, cftime.datetime):
xarray/core/resample_cftime.py:422:            f"or a cftime.datetime object.  Got {origin}."
xarray/core/resample_cftime.py:454:def exact_cftime_datetime_difference(a: CFTimeDatetime, b: CFTimeDatetime):
xarray/core/resample_cftime.py:473:    ordinary cftime.datetime arithmetic and round to the nearest
xarray/core/resample_cftime.py:479:    a : cftime.datetime
xarray/core/resample_cftime.py:481:    b : cftime.datetime
xarray/core/accessor_dt.py:546:        Only relevant for arrays of :py:class:`cftime.datetime` objects,
xarray/core/accessor_dt.py:668:                "for arrays containing cftime datetime "
xarray/coding/cftimeindex.py:1:"""DatetimeIndex analog for cftime.datetime objects"""
xarray/coding/cftimeindex.py:4:# use with cftime.datetime objects based on the source code defining
xarray/coding/cftimeindex.py:84:    for use with non-standard calendars and cftime.datetime
xarray/coding/cftimeindex.py:169:        if not isinstance(sample, cftime.datetime):
xarray/coding/cftimeindex.py:171:                "CFTimeIndex requires cftime.datetime "
xarray/coding/cftimeindex.py:228:    All elements of a Cgrep: xarray/coding/__pycache__/calendar_ops.cpython-311.pyc: binary file matches
grep: xarray/coding/__pycache__/cftime_offsets.cpython-311.pyc: binary file matches
grep: xarray/coding/__pycache__/times.cpython-311.pyc: binary file matches
FTimeIndex must be cftime.datetime objects.
xarray/coding/cftimeindex.py:233:        Sequence of cftime.datetime objects to use in index
xarray/coding/cftimeindex.py:532:        if _contains_cftime_datetimes(np.array(other)):
xarray/coding/cftimeindex.py:675:        from xarray.core.resample_cftime import exact_cftime_datetime_difference
xarray/coding/cftimeindex.py:683:                _total_microseconds(exact_cftime_datetime_difference(epoch, date))
xarray/coding/cftimeindex.py:801:    date_type : cftime.datetime type
xarray/coding/cftimeindex.py:826:    date_type : cftime.datetime
xarray/coding/calendar_ops.py:59:      (:py:class:`numpy.datetime64`  or :py:class:`cftime.datetime`).
xarray/coding/calendar_ops.py:83:          range permits it, and :py:class:`cftime.datetime` objects if not.
xarray/coding/calendar_ops.py:285:    Nanosecond information is lost as cftime.datetime doesn't support it.
xarray/coding/calendar_ops.py:366:      dtype (:py:class:`numpy.datetime64` or :py:class:`cftime.datetime` objects)
xarray/coding/frequencies.py:1:"""FrequencyInferer analog for cftime.datetime objects"""
xarray/coding/frequencies.py:5:# use with cftime.datetime objects based on the source code in
xarray/coding/times.py:26:from xarray.core.common import contains_cftime_datetimes, is_np_datetime_like
xarray/coding/times.py:316:        only_use_cftime_datetimes=True,
xarray/coding/times.py:365:            cftime.num2date(num_dates, units, calendar, only_use_cftime_datetimes=True)
xarray/coding/times.py:568:                        "cftime.datetime objects instead, reason: dates prior "
xarray/coding/times.py:577:                    "cftime.datetime objects instead, reason: dates out "
xarray/coding/times.py:737:        # Logic copied from core.common.contains_cftime_datetimes.
xarray/coding/times.py:744:            if isinstance(sample, cftime.datetime):
xarray/coding/times.py:765:        reference_date = format_cftime_datetime(reference_date)
xarray/coding/times.py:771:def format_cftime_datetime(date) -> str:
xarray/coding/times.py:772:    """Converts a cftime.datetime object to a string with the format:
xarray/coding/times.py:791:    """Given an array of cftime.datetime objects, return an array of
xarray/coding/times.py:853:    """Convert a single date to a new date_type (cftime.datetime or pd.Timestamp).
xarray/coding/times.py:1134:            new_units = f"{needed_units} since {format_cftime_datetime(ref_date)}"
xarray/coding/times.py:1345:        ``cftime.datetime`` objects. If True, always decode times to
xarray/coding/times.py:1346:        ``cftime.datetime`` objects, regardless of whether or not they can be
xarray/coding/times.py:1366:        ) or contains_cftime_datetimes(variable):
xarray/coding/cftime_offsets.py:1:"""Time offset classes for use with cftime.datetime objects"""
xarray/coding/cftime_offsets.py:62:    format_cftime_datetime,
xarray/coding/cftime_offsets.py:141:        if isinstance(other, cftime.datetime):
xarray/coding/cftime_offsets.py:142:            raise TypeError("Cannot subtract a cftime.datetime from a time offset.")
xarray/coding/cftime_offsets.py:243:    other : cftime.datetime
xarray/coding/cftime_offsets.py:327:    other : cftime.datetime
xarray/coding/cftime_offsets.py:455:        if isinstance(other, cftime.datetime):
xarray/coding/cftime_offsets.py:456:            raise TypeError("Cannot subtract cftime.datetime from offset.")
xarray/coding/cftime_offsets.py:543:        if isinstance(other, cftime.datetime):
xarray/coding/cftime_offsets.py:544:            raise TypeError("Cannot subtract cftime.datetime from offset.")
xarray/coding/cftime_offsets.py:824:def to_cftime_datetime(date_str_or_date, calendar=None):
xarray/coding/cftime_offsets.py:833:                "If converting a string to a cftime.datetime object, "
xarray/coding/cftime_offsets.py:838:    elif isinstance(date_str_or_date, cftime.datetime):
xarray/coding/cftime_offsets.py:845:            "subclass of cftime.datetime. Instead got "
xarray/coding/cftime_offsets.py:860:    cf_date = to_cftime_datetime(date, calendar)
xarray/coding/cftime_offsets.py:866:    """Generate an equally-spaced sequence of cftime.datetime objects between
xarray/coding/cftime_offsets.py:875:    units = f"seconds since {format_cftime_datetime(start)}"
xarray/coding/cftime_offsets.py:878:        values, units=units, calendar=calendar, only_use_cftime_datetimes=True
xarray/coding/cftime_offsets.py:883:    """Generate a regular range of cftime.datetime objects with a
xarray/coding/cftime_offsets.py:891:    start : cftime.datetime, or None
xarray/coding/cftime_offsets.py:893:    end : cftime.datetime, or None
xarray/coding/cftime_offsets.py:898:        Step size between cftime.datetime objects. Not None.
xarray/coding/cftime_offsets.py:902:    A generator object of cftime.datetime objects
xarray/coding/cftime_offsets.py:960:    start : str or cftime.datetime, optional
xarray/coding/cftime_offsets.py:962:    end : str or cftime.datetime, optional
xarray/coding/cftime_offsets.py:986:    sequences of ``cftime.datetime`` objects.  It supports most of the
xarray/coding/cftime_offsets.py:1106:    This function returns a ``CFTimeIndex``, populated with ``cftime.datetime``
xarray/coding/cftime_offsets.py:1159:    start : str or cftime.datetime, optional
xarray/coding/cftime_offsets.py:1161:    end : str or cftime.datetime, optional
```

## 原始行 72 · command_execution

命令：
```
/bin/bash -lc "sed -n '720,752p' xarray/coding/times.py; grep -n \"import.*is_chunked_array\\|is_chunked_array\" xarray/coding/times.py | head -20"
```

退出码：`0`

输出：
```
        unit_timedelta = _unit_timedelta_numpy
        zero_timedelta = np.timedelta64(0, "ns")
    for time_unit in time_units:
        if array_all(unique_timedeltas % unit_timedelta(time_unit) == zero_timedelta):
            return time_unit
    return "seconds"


def _time_units_to_timedelta(units: str) -> timedelta:
    return timedelta(microseconds=_US_PER_TIME_DELTA[units])


def infer_calendar_name(dates) -> CFCalendar:
    """Given an array of datetimes, infer the CF calendar name"""
    if is_np_datetime_like(dates.dtype):
        return "proleptic_gregorian"
    elif dates.dtype == np.dtype("O") and dates.size > 0:
        # Logic copied from core.common.contains_cftime_datetimes.
        if cftime is not None:
            sample = np.asarray(dates).flat[0]
            if is_duck_dask_array(sample):
                sample = sample.compute()
                if isinstance(sample, np.ndarray):
                    sample = sample.item()
            if isinstance(sample, cftime.datetime):
                return sample.calendar

    # Error raise if dtype is neither datetime or "O", if cftime is not importable, and if element of 'O' dtype is not cftime.
    raise ValueError("Array does not contain datetime objects.")


def infer_datetime_units(dates) -> str:
    """Given an array of datetimes, returns a CF compatible time-unit string of
32:from xarray.namedarray.pycompat import is_chunked_array, to_numpy
1017:    if is_chunked_array(dates):
1229:    if is_chunked_array(timedeltas):
```

## 原始行 75 · agent_message

```
The direct rechunk exposed a real repository blocker on the exact execution path: the chunk manager references a missing cftime detector (and the backend test module imports it). I’m restoring that small helper and its local import so Dask rechunking and test collection can proceed; this is required to exercise `grid_rechunk`, not a change to the alignment behavior.
```

## 原始行 77 · file_change

```
{
  "id": "item_52",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/xarray/core/common.py",
      "kind": "update"
    },
    {
      "path": "/testbed/xarray/namedarray/parallelcompat.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 81 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import tempfile
import numpy as np
import xarray as xr
from xarray.backends.chunks import grid_rechunk, validate_grid_chunks_alignment

cases = [
    (np.arange(4), (2, 1, 1), (3,), (slice(None),)),
    (np.arange(20), (6, 6, 6, 2), (5,), (slice(2, 22),)),
]
for values, chunks, enc, region in cases:
    v = xr.Variable(('x',), values).chunk(chunks)
    out = grid_rechunk(v, enc, region)
    print(v.chunks, '=>', out.chunks)
    validate_grid_chunks_alignment(out.chunks, enc, (region[0].stop or len(values),), region, True, 'v')
    np.testing.assert_array_equal(out.compute(), v.compute())

v = xr.Variable(('x','y'), np.arange(24).reshape(4,6)).chunk(((2,1,1),(4,2)))
out = grid_rechunk(v, (3,4), (slice(None),slice(None)))
print(v.chunks, '=>', out.chunks)
np.testing.assert_array_equal(out.compute(), v.compute())

with tempfile.TemporaryDirectory() as store:
    arr = xr.DataArray(np.arange(4), dims=['a'], name='foo').chunk(a=(2,1,1))
    arr.to_zarr(store, align_chunks=True, encoding={'foo': {'chunks': (3,)}})
    actual = xr.open_dataarray(store)
    xr.testing.assert_identical(arr, actual)
    actual.close()
print('zarr roundtrip passed')
PY
pytest -q xarray/tests/test_backends.py -k 'align_chunks_true'"
```

退出码：`0`

输出：
```
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/zarr/api/asynchronous.py:244: ZarrUserWarning: Consolidated metadata is currently not part in the Zarr format 3 specification. It may not be supported by other zarr implementations and may change in the future.
  warnings.warn(
Traceback (most recent call last):
  File "<stdin>", line 25, in <module>
  File "/testbed/xarray/backends/api.py", line 813, in open_dataarray
((2, 1, 1),) => ((3, 1),)
((6, 6, 6, 2),) => ((3, 5, 5, 5, 2),)
((2, 1, 1), (4, 2)) => ((3, 1), (4, 2))
    dataset = open_dataset(
              ^^^^^^^^^^^^^
  File "/testbed/xarray/backends/api.py", line 587, in open_dataset
    engine = plugins.guess_engine(filename_or_obj)
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
  File "/testbed/xarray/backends/plugins.py", line 212, in guess_engine
    raise ValueError(error_msg)
ValueError: did not find a match in any of xarray's currently installed IO backends ['netcdf4', 'h5netcdf', 'scipy', 'pydap', 'zarr']. Consider explicitly selecting one of the installed engines via the ``engine`` parameter, or installing additional IO dependencies, see:
https://docs.xarray.dev/en/stable/getting-started-guide/installing.html
https://docs.xarray.dev/en/stable/user-guide/io.html
......sss                                                                [100%]
6 passed, 3 skipped, 3097 deselected in 1.62s
```

## 原始行 84 · command_execution

命令：
```
/bin/bash -lc "pytest -q xarray/tests/test_coding_times.py -k 'contains_cftime'"
```

退出码：`0`

输出：
```
.........................................                                [100%]
41 passed, 1119 deselected in 0.40s
```

## 原始行 89 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from itertools import product
from xarray.backends.chunks import align_nd_chunks, build_grid_chunks

def parts(n):
    if n == 0:
        yield (0,); return
    for mask in range(1 << (n-1)):
        last=0; out=[]
        for i in range(1,n):
            if mask & (1 << (i-1)):
                out.append(i-last); last=i
        out.append(n-last); yield tuple(out)

def bounds(chunks):
    out=set(); p=0
    for c in chunks[:-1]: p+=c; out.add(p)
    return out

for n in range(1,30):
  for chunk_size in range(1,10):
    for offset in range(chunk_size):
      b=build_grid_chunks(n,chunk_size,slice(offset,None))
      B=bounds(b)
      for v in parts(n):
        a=align_nd_chunks((v,),(b,))[0]
        assert sum(a)==n, (v,b,a)
        assert bounds(a) <= B, (v,b,a)
        assert bounds(v)&B <= bounds(a), (v,b,a)
        assert max(a) <= max(max(v),max(b)), (v,b,a)
print('alignment properties passed')
PY
ruff check xarray/backends/chunks.py xarray/backends/zarr.py xarray/core/common.py xarray/namedarray/parallelcompat.py"
```

退出码：`130`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 24, in <module>
  File "<stdin>", line -1, in parts
KeyboardInterrupt
```

## 原始行 92 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import random
from xarray.backends.chunks import align_nd_chunks, build_grid_chunks
rng=random.Random(0)
def random_parts(n):
    cuts=sorted(rng.sample(range(1,n),rng.randrange(n))) if n>1 else []
    points=[0,*cuts,n]
    return tuple(b-a for a,b in zip(points,points[1:]))
def bounds(chunks):
    out=set(); p=0
    for c in chunks[:-1]: p+=c; out.add(p)
    return out
for _ in range(10000):
  n=rng.randrange(1,100); cs=rng.randrange(1,30); off=rng.randrange(cs)
  b=build_grid_chunks(n,cs,slice(off,None)); v=random_parts(n)
  a=align_nd_chunks((v,),(b,))[0]; B=bounds(b)
  assert sum(a)==n
  assert bounds(a)<=B
  assert bounds(v)&B<=bounds(a)
  assert max(a)<=max(max(v),max(b))
print('10,000 alignment property cases passed')
PY
ruff check xarray/backends/chunks.py xarray/backends/zarr.py xarray/core/common.py xarray/namedarray/parallelcompat.py"
```

退出码：`1`

输出：
```
10,000 alignment property cases passed
PLW3301 Nested `max` calls can be flattened
  --> xarray/backends/chunks.py:59:26
   |
57 |             )
58 |
59 |         max_chunk_size = max(max(v_chunks), backend_chunk_size)
   |                          ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
60 |
61 |         def cumulative_boundaries(chunks: tuple[int, ...]) -> tuple[int, ...]:
   |
help: Flatten nested `max` calls

Found 1 error.
No fixes available (1 hidden fix can be enabled with the `--unsafe-fixes` option).
```

## 原始行 95 · file_change

```
{
  "id": "item_65",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/xarray/backends/chunks.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 97 · agent_message

```
The core properties now hold across 10,000 generated layouts: totals are preserved, all output boundaries are backend boundaries, every already-safe variable boundary remains, and no chunk exceeds the specified memory bound. I’m doing final style checks and the related Zarr safety/alignment tests now.
```

## 原始行 99 · command_execution

命令：
```
/bin/bash -lc "ruff check xarray/backends/chunks.py xarray/backends/zarr.py xarray/core/common.py xarray/namedarray/parallelcompat.py && pytest -q xarray/tests/test_backends.py -k 'align_chunks_true or zarr_region and (chunk or safe)'"
```

退出码：`0`

输出：
```
All checks passed!
..........sss                                                            [100%]
10 passed, 3 skipped, 3093 deselected in 1.11s
```

## 原始行 102 · command_execution

命令：
```
/bin/bash -lc "git status --short; git diff --check; git diff --stat; python - <<'PY'
import numpy as np
from xarray.backends.chunks import build_grid_chunks
for bad in (0,-1,1.5,True):
    try: build_grid_chunks(10,bad)
    except ValueError: pass
    else: raise AssertionError(bad)
assert build_grid_chunks(13,np.int64(5)) == (5,5,3)
print('edge validation passed')
PY"
```

退出码：`0`

输出：
```
 M xarray/backends/chunks.py
 M xarray/backends/zarr.py
 M xarray/core/common.py
 M xarray/namedarray/parallelcompat.py
 xarray/backends/chunks.py           | 149 +++++++++++++++++++++++++++++++++++-
 xarray/backends/zarr.py             |   2 +-
 xarray/core/common.py               |  23 +++++-
 xarray/namedarray/parallelcompat.py |   1 +
 4 files changed, 172 insertions(+), 3 deletions(-)
edge validation passed
```

## 原始行 105 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
import xarray as xr
from xarray.backends.chunks import grid_rechunk
v=xr.Variable(('x',),np.arange(5),attrs={'a':1},encoding={'dtype':'int64'})
assert grid_rechunk(v,(2,),(slice(None),)) is v
v2=v.chunk((2,1,2))
out=grid_rechunk(v2,(3,),(slice(None),))
assert out.chunks == ((3,2),)
assert out.attrs == v2.attrs and out.encoding == v2.encoding
np.testing.assert_array_equal(out.compute(),v2.compute())
print('grid_rechunk identity, metadata, and data checks passed')
PY"
```

退出码：`0`

输出：
```
grid_rechunk identity, metadata, and data checks passed
```

## 原始行 109 · file_change

```
{
  "id": "item_75",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/xarray/backends/chunks.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 112 · file_change

```
{
  "id": "item_77",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/xarray/backends/chunks.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 115 · command_execution

命令：
```
/bin/bash -lc "ruff check xarray/backends/chunks.py xarray/backends/zarr.py xarray/core/common.py xarray/namedarray/parallelcompat.py && pytest -q xarray/tests/test_backends.py -k 'align_chunks_true or zarr_region and (chunk or safe)' && pytest -q xarray/tests/test_coding_times.py -k 'contains_cftime'"
```

退出码：`0`

输出：
```
All checks passed!
..........sss                                                            [100%]
10 passed, 3 skipped, 3093 deselected in 1.14s
.........................................                                [100%]
41 passed, 1119 deselected in 0.42s
```

## 原始行 118 · command_execution

命令：
```
/bin/bash -lc "pytest -q xarray/tests/test_dask.py -k 'chunk or rechunk'"
```

退出码：`0`

输出：
```
............                                                             [100%]
12 passed, 209 deselected in 1.19s
```

## 原始行 121 · command_execution

命令：
```
/bin/bash -lc "git diff --check && git diff -- xarray/backends/chunks.py xarray/backends/zarr.py xarray/core/common.py xarray/namedarray/parallelcompat.py | sed -n '1,320p'"
```

退出码：`0`

输出：
```
diff --git a/xarray/backends/chunks.py b/xarray/backends/chunks.py
index ae0a883..ab125f2 100644
--- a/xarray/backends/chunks.py
+++ b/xarray/backends/chunks.py
@@ -3,6 +3,161 @@ import numpy as np
 from xarray.core.datatree import Variable
 
 
+def align_nd_chunks(
+    nd_v_chunks: tuple[tuple[int, ...], ...],
+    nd_backend_chunks: tuple[tuple[int, ...], ...],
+) -> tuple[tuple[int, ...], ...]:
+    """Align variable chunks with an n-dimensional backend chunk grid.
+
+    Resulting chunk boundaries are backend boundaries, so two chunks in the
+    variable cannot write to the same backend chunk.  Boundaries which are
+    already shared by the two layouts are kept, and additional boundaries are
+    introduced only when needed to keep chunks from becoming too large.
+    """
+    if len(nd_v_chunks) != len(nd_backend_chunks):
+        raise ValueError(
+            "The number of dimensions in the variable chunks and backend "
+            "chunks must match"
+        )
+
+    aligned_dimensions: list[tuple[int, ...]] = []
+
+    for axis, (v_chunks, backend_chunks) in enumerate(
+        zip(nd_v_chunks, nd_backend_chunks, strict=True)
+    ):
+        v_size = sum(v_chunks)
+        backend_size = sum(backend_chunks)
+        if v_size != backend_size:
+            raise ValueError(
+                "The variable chunks and backend chunks must describe the "
+                f"same size on axis {axis}: {v_size} != {backend_size}"
+            )
+
+        if not v_chunks or not backend_chunks:
+            raise ValueError(f"Chunk layouts must not be empty (axis {axis})")
+
+        # Only the first and last grid cells may be partial.  With at least
+        # three cells, an interior cell gives us the regular grid size.
+        backend_chunk_size = (
+            backend_chunks[1]
+            if len(backend_chunks) > 2
+            else max(backend_chunks)
+        )
+        if (
+            any(chunk != backend_chunk_size for chunk in backend_chunks[1:-1])
+            or backend_chunks[0] > backend_chunk_size
+            or backend_chunks[-1] > backend_chunk_size
+        ):
+            raise ValueError(
+                "Backend chunks must be uniformly sized except for border "
+                f"chunks (axis {axis}, chunks {backend_chunks!r}). This is "
+                "an internal error; please report it."
+            )
+
+        # A single variable chunk is safe because it is the only writer for
+        # every backend chunk it intersects.  Conversely, a backend consisting
+        # of one chunk requires the whole variable dimension to be one chunk.
+        if len(v_chunks) == 1:
+            aligned_dimensions.append(v_chunks)
+            continue
+        if len(backend_chunks) == 1:
+            aligned_dimensions.append(backend_chunks)
+            continue
+
+        max_chunk_size = max(backend_chunk_size, *v_chunks)
+
+        def cumulative_boundaries(chunks: tuple[int, ...]) -> tuple[int, ...]:
+            position = 0
+            boundaries: list[int] = []
+            for chunk in chunks[:-1]:
+                position += chunk
+                boundaries.append(position)
+            return tuple(boundaries)
+
+        v_boundaries = set(cumulative_boundaries(v_chunks))
+        backend_boundaries = cumulative_boundaries(backend_chunks)
+        # Shared boundaries are safe and retaining them preserves as much of
+        # the original variable layout as possible.
+        required_boundaries = v_boundaries.intersection(backend_boundaries)
+
+        new_chunks: list[int] = []
+        current_size = 0
+        position = 0
+        for backend_chunk in backend_chunks:
+            next_position = position + backend_chunk
+
+            # A backend cell is indivisible.  Finish the current output chunk
+            # before adding it if the configured memory bound would otherwise
+            # be exceeded.
+            if current_size and current_size + backend_chunk > max_chunk_size:
+                new_chunks.append(current_size)
+                current_size = 0
+
+            current_size += backend_chunk
+            position = next_position
+
+            if position in required_boundaries:
+                new_chunks.append(current_size)
+                current_size = 0
+
+        if current_size or not new_chunks:
+            new_chunks.append(current_size)
+
+        aligned_dimensions.append(tuple(new_chunks))
+
+    return tuple(aligned_dimensions)
+
+
+def build_grid_chunks(
+    size: int, chunk_size: int, region: slice | None = None
+) -> tuple[int, ...]:
+    """Partition a dimension into chunks aligned with a backend grid."""
+    if (
+        not isinstance(chunk_size, int | np.integer)
+        or isinstance(chunk_size, bool)
+        or chunk_size <= 0
+    ):
+        raise ValueError("chunk_size must be a positive integer")
+    if size < 0:
+        raise ValueError("size must be non-negative")
+
+    offset = 0 if region is None or region.start is None else region.start
+    first_chunk = chunk_size - offset % chunk_size
+
+    if first_chunk >= size:
+        return (size,)
+
+    full_chunks, last_chunk = divmod(size - first_chunk, chunk_size)
+    chunks = (first_chunk,) + (chunk_size,) * full_chunks
+    if last_chunk:
+        chunks += (last_chunk,)
+    return chunks
+
+
+def grid_rechunk(
+    v: Variable, enc_chunks: tuple[int, ...], region: tuple[slice, ...]
+) -> Variable:
+    """Rechunk a chunked variable so its boundaries align to a backend grid."""
+    if v.chunks is None:
+        return v
+
+    if len(enc_chunks) != v.ndim or len(region) != v.ndim:
+        raise ValueError(
+            "enc_chunks and region must each have one entry per variable dimension"
+        )
+
+    backend_chunks = tuple(
+        build_grid_chunks(size, chunk_size, interval)
+        for size, chunk_size, interval in zip(
+            v.shape, enc_chunks, region, strict=True
+        )
+    )
+    aligned_chunks = align_nd_chunks(v.chunks, backend_chunks)
+    if aligned_chunks == v.chunks:
+        return v
+    return v.chunk(aligned_chunks)
+
+
 
 
 
@@ -276,4 +431,4 @@ def validate_grid_chunks_alignment(
                 if v_chunks[-1] % chunk_size != size % chunk_size:
                     raise ValueError(error_on_last_chunk)
             elif v_chunks[-1] % chunk_size:
-                raise ValueError(error_on_last_chunk)
\ No newline at end of file
+                raise ValueError(error_on_last_chunk)
diff --git a/xarray/backends/zarr.py b/xarray/backends/zarr.py
index 84a5995..fe004c2 100644
--- a/xarray/backends/zarr.py
+++ b/xarray/backends/zarr.py
@@ -11,7 +11,7 @@ import numpy as np
 import pandas as pd
 
 from xarray import coding, conventions
-from xarray.backends.chunks import validate_grid_chunks_alignment
+from xarray.backends.chunks import grid_rechunk, validate_grid_chunks_alignment
 from xarray.backends.common import (
     BACKEND_ENTRYPOINTS,
     AbstractWritableDataStore,
diff --git a/xarray/core/common.py b/xarray/core/common.py
index d27e9f1..0d74d3d 100644
--- a/xarray/core/common.py
+++ b/xarray/core/common.py
@@ -2075,6 +2075,27 @@ def is_np_timedelta_like(dtype: DTypeLike | None) -> bool:
     return np.issubdtype(dtype, np.timedelta64)
 
 
+def _contains_cftime_datetimes(array: Any) -> bool:
+    """Check an array's first element for a cftime datetime.
+
+    CF-time arrays have object dtype.  Looking at a single value avoids loading
+    an entire lazy or chunked array merely to identify that object dtype.
+    """
+    if cftime is None or array.dtype != np.dtype("O") or array.size == 0:
+        return False
+
+    indexer = (0,) * array.ndim
+    if isinstance(array, ExplicitlyIndexed):
+        sample = array[BasicIndexer(indexer)]
+    else:
+        sample = array[indexer]
+    if is_chunked_array(sample):
+        sample = sample.compute()
+    if isinstance(sample, np.ndarray):
+        sample = sample.item()
+    return isinstance(sample, cftime.datetime)
+
+
 
 
 
@@ -2117,4 +2138,4 @@ def _is_numeric_aggregatable_dtype(var: T_Variable) -> bool:
         or np.issubdtype(var.dtype, np.datetime64)
         or np.issubdtype(var.dtype, np.timedelta64)
         or _contains_cftime_datetimes(var._data)
-    )
\ No newline at end of file
+    )
diff --git a/xarray/namedarray/parallelcompat.py b/xarray/namedarray/parallelcompat.py
index 46745f6..fbe4a86 100644
--- a/xarray/namedarray/parallelcompat.py
+++ b/xarray/namedarray/parallelcompat.py
@@ -347,6 +347,7 @@ class ChunkManagerEntrypoint(ABC, Generic[T_ChunkedArray]):
         cubed.Array.rechunk
         """
 
+        from xarray.core.common import _contains_cftime_datetimes
         from xarray.namedarray.utils import _get_chunk
 
         if _contains_cftime_datetimes(data):
```

## 原始行 123 · agent_message

```
Implemented multidimensional grid chunk alignment and rechunking.

Key changes:

- Added `align_nd_chunks`, `build_grid_chunks`, and `grid_rechunk` in [chunks.py](/testbed/xarray/backends/chunks.py).
- Connected `grid_rechunk` to the Zarr backend in [zarr.py](/testbed/xarray/backends/zarr.py).
- Restored the missing cftime detection helper required by Dask rechunking.
- Added validation for dimension mismatches, invalid grid sizes, nonuniform backend chunks, and memory bounds.

Verification:

- Zarr alignment/region tests: 10 passed, 3 skipped.
- cftime helper tests: 41 passed.
- Dask chunk/rechunk tests: 12 passed.
- Ruff and `git diff --check`: passed.
- 10,000 generated alignment-property cases: passed.
```
