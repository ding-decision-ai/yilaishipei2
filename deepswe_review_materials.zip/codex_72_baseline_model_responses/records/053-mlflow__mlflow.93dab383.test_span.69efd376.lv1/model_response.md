# Codex baseline: mlflow__mlflow.93dab383.test_span.69efd376.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 3 · agent_message

```
I’ll inspect the existing tracing implementation and visible tests first, then fill the specified interfaces and run focused tests before the broader suite.
```

## 原始行 5 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' mlflow/entities/span.py && sed -n '1,260p' mlflow/tracing/trace_manager.py && sed -n '1,240p' mlflow/tracing/utils/otlp.py"
```

退出码：`0`

输出：
```
import base64
import json
import logging
from functools import lru_cache
from typing import Any, Union

from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
from opentelemetry.sdk.resources import Resource as _OTelResource
from opentelemetry.sdk.trace import Event as OTelEvent
from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags
from opentelemetry.trace import Span as OTelSpan
from opentelemetry.trace import Status as OTelStatus
from opentelemetry.trace import StatusCode as OTelStatusCode

import mlflow
from mlflow.entities.span_event import SpanEvent
from mlflow.entities.span_status import SpanStatus, SpanStatusCode
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.tracing.constant import TRACE_REQUEST_ID_PREFIX, SpanAttributeKey
from mlflow.tracing.utils import (
    build_otel_context,
    decode_id,
    dump_span_attribute_value,
    encode_span_id,
    encode_trace_id,
    generate_mlflow_trace_id_from_otel_trace_id,
    generate_trace_id_v4_from_otel_trace_id,
    parse_trace_id_v4,
)
from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue






_logger = logging.getLogger(__name__)


# Not using enum as we want to allow custom span type string.
class SpanType:
    """
    Predefined set of span types.
    """

    LLM = "LLM"
    CHAIN = "CHAIN"
    AGENT = "AGENT"
    TOOL = "TOOL"
    CHAT_MODEL = "CHAT_MODEL"
    RETRIEVER = "RETRIEVER"
    PARSER = "PARSER"
    EMBEDDING = "EMBEDDING"
    RERANKER = "RERANKER"
    MEMORY = "MEMORY"
    UNKNOWN = "UNKNOWN"
    WORKFLOW = "WORKFLOW"
    TASK = "TASK"
    GUARDRAIL = "GUARDRAIL"
    EVALUATOR = "EVALUATOR"



























class Span:
    """
    A span object. A span represents a unit of work or operation and is the building
    block of Traces.

    This Span class represents immutable span data that is already finished and persisted.
    The "live" span that is being created and updated during the application runtime is
    represented by the :py:class:`LiveSpan <mlflow.entities.LiveSpan>` subclass.
    """

    def __init__(self, otel_span: OTelReadableSpan):
        if not isinstance(otel_span, OTelReadableSpan):
            raise MlflowException(
                "The `otel_span` argument for the Span class must be an instance of ReadableSpan, "
                f"but got {type(otel_span)}.",
                INVALID_PARAMETER_VALUE,
            )

        self._span = otel_span
        # Since the span is immutable, we can cache the attributes to avoid the redundant
        # deserialization of the attribute values.
        self._attributes = _CachedSpanAttributesRegistry(otel_span)

    @property
    @lru_cache(maxsize=1)
    def trace_id(self) -> str:
        """The trace ID of the span, a unique identifier for the trace it belongs to."""
        return self.get_attribute(SpanAttributeKey.REQUEST_ID)






    @property
    def span_id(self) -> str:
        """The ID of the span. This is only unique within a trace."""
        return encode_span_id(self._span.context.span_id)

    @property
    def name(self) -> str:
        """The name of the span."""
        return self._span.name

    @property
    def start_time_ns(self) -> int:
        """The start time of the span in nanosecond."""
        return self._span._start_time

    @property
    def end_time_ns(self) -> int | None:
        """The end time of the span in nanosecond."""
        return self._span._end_time

    @property
    def parent_id(self) -> str | None:
        """The span ID of the parent span."""
        if self._span.parent is None:
            return None
        return encode_span_id(self._span.parent.span_id)

    @property
    def status(self) -> SpanStatus:
        """The status of the span."""
        return SpanStatus.from_otel_status(self._span.status)

    @property
    def inputs(self) -> Any:
        """The input values of the span."""
        return self.get_attribute(SpanAttributeKey.INPUTS)

    @property
    def outputs(self) -> Any:
        """The output values of the span."""
        return self.get_attribute(SpanAttributeKey.OUTPUTS)






    @property
    def _trace_id(self) -> str:
        """
        The OpenTelemetry trace ID of the span. Note that this should not be exposed to
        the user, instead, use trace_id property as an unique identifier for a trace.
        """
        return encode_trace_id(self._span.context.trace_id)






























    def __repr__(self):
        return (
            f"{type(self).__name__}(name={self.name!r}, trace_id={self.trace_id!r}, "
            f"span_id={self.span_id!r}, parent_id={self.parent_id!r})"
        )

    def get_attribute(self, key: str) -> Any | None:
        """
        Get a single attribute value from the span.

        Args:
            key: The key of the attribute to get.

        Returns:
            The value of the attribute if it exists, otherwise None.
        """
        return self._attributes.get(key)































    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Span":
        """Create a Span object from the given dictionary."""
        try:
            # Try to deserialize the span using the v3 schema
            request_id = data.get("attributes", {}).get(SpanAttributeKey.REQUEST_ID)
            if not request_id:
                raise MlflowException(
                    f"The {SpanAttributeKey.REQUEST_ID} attribute is empty or missing.",
                    INVALID_PARAMETER_VALUE,
                )

            if Span._is_span_v2_schema(data):
                return cls.from_dict_v2(data)

            if _is_base64_encoded(data["trace_id"]):
                otel_trace_id = _decode_id_from_byte(data["trace_id"])
                span_id = _decode_id_from_byte(data["span_id"])
                # Parent ID always exists in proto (empty string) even if the span is a root span.
                parent_id = (
                    _decode_id_from_byte(data["parent_span_id"]) if data["parent_span_id"] else None
                )
            else:
                # In 3.5.0, Span.to_dict keeps trace_id and span_id as the object's properties
import contextlib
import logging
import threading
from dataclasses import dataclass, field
from typing import Generator, Sequence

from mlflow.entities import LiveSpan, Trace, TraceData, TraceInfo
from mlflow.entities.model_registry import PromptVersion
from mlflow.environment_variables import MLFLOW_TRACE_TIMEOUT_SECONDS
from mlflow.prompt.constants import LINKED_PROMPTS_TAG_KEY
from mlflow.tracing.utils.prompt import update_linked_prompts_tag
from mlflow.tracing.utils.timeout import get_trace_cache_with_timeout


_logger = logging.getLogger(__name__)


# Internal representation to keep the state of a trace.
# Dict[str, Span] is used instead of TraceData to allow access by span_id.
@dataclass
class _Trace:
    info: TraceInfo
    span_dict: dict[str, LiveSpan] = field(default_factory=dict)
    prompts: list[PromptVersion] = field(default_factory=list)










    def get_root_span(self) -> LiveSpan | None:
        for span in self.span_dict.values():
            if span.parent_id is None:
                return span
        return None


@dataclass
class ManagerTrace:
    """
    Wrapper around a trace and its associated prompts.
    """

    trace: Trace
    prompts: Sequence[PromptVersion]


class InMemoryTraceManager:
    """
    Manage spans and traces created by the tracing system in memory.
    """

    _instance_lock = threading.RLock()
    _instance = None

    @classmethod
    def get_instance(cls):
        if cls._instance is None:
            with cls._instance_lock:
                if cls._instance is None:
                    cls._instance = InMemoryTraceManager()
        return cls._instance

    def __init__(self):
        # In-memory cache to store trace_od -> _Trace mapping.
        self._traces = get_trace_cache_with_timeout()

        # Store mapping between OpenTelemetry trace ID and MLflow trace ID
        self._otel_id_to_mlflow_trace_id: dict[int, str] = {}
        self._lock = threading.RLock()  # Lock for _traces

    def register_trace(self, otel_trace_id: int, trace_info: TraceInfo):
        """
        Register a new trace info object to the in-memory trace registry.

        Args:
            otel_trace_id: The OpenTelemetry trace ID for the new trace.
            trace_info: The trace info object to be stored.
        """
        # Check for a new timeout setting whenever a new trace is created.
        self._check_timeout_update()
        with self._lock:
            self._traces[trace_info.trace_id] = _Trace(trace_info)
            self._otel_id_to_mlflow_trace_id[otel_trace_id] = trace_info.trace_id

    def register_span(self, span: LiveSpan):
        """
        Store the given span in the in-memory trace data.

        Args:
            span: The span to be stored.
        """
        if not isinstance(span, LiveSpan):
            _logger.debug(f"Invalid span object {type(span)} is passed. Skipping.")
            return

        with self._lock:
            trace_data_dict = self._traces[span.request_id].span_dict
            trace_data_dict[span.span_id] = span

    def register_prompt(self, trace_id: str, prompt: PromptVersion):
        """
        Register a prompt to link to the trace with the given trace ID.

        Args:
            trace_id: The ID of the trace to which the prompt belongs.
            prompt: The prompt version to be registered.
        """
        with self._lock:
            if prompt not in self._traces[trace_id].prompts:
                self._traces[trace_id].prompts.append(prompt)

            # NB: Set prompt URIs in trace tags for linking. This is a short-term solution until
            # LinkPromptsToTraces endpoint is implemented in the backend.
            # TODO: Remove this once LinkPromptsToTraces endpoint is implemented in the backend.
            try:
                current_tag = self._traces[trace_id].info.tags.get(LINKED_PROMPTS_TAG_KEY)
                updated_tag = update_linked_prompts_tag(current_tag, [prompt])
                self._traces[trace_id].info.tags[LINKED_PROMPTS_TAG_KEY] = updated_tag
            except Exception:
                _logger.debug(f"Failed to update prompts tag for trace {trace_id}", exc_info=True)
                raise

    @contextlib.contextmanager
    def get_trace(self, trace_id: str) -> Generator[_Trace | None, None, None]:
        """
        Yield the trace info for the given trace ID..
        This is designed to be used as a context manager to ensure the trace info is accessed
        with the lock held.
        """
        with self._lock:
            yield self._traces.get(trace_id)

    def get_span_from_id(self, trace_id: str, span_id: str) -> LiveSpan | None:
        """
        Get a span object for the given trace_id and span_id.
        """
        with self._lock:
            trace = self._traces.get(trace_id)

        return trace.span_dict.get(span_id) if trace else None

    def get_root_span_id(self, trace_id) -> str | None:
        """
        Get the root span ID for the given trace ID.
        """
        with self._lock:
            trace = self._traces.get(trace_id)

        if trace:
            for span in trace.span_dict.values():
                if span.parent_id is None:
                    return span.span_id

        return None

    def get_mlflow_trace_id_from_otel_id(self, otel_trace_id: int) -> str | None:
        """
        Get the MLflow trace ID for the given OpenTelemetry trace ID.
        """
        return self._otel_id_to_mlflow_trace_id.get(otel_trace_id)

    def set_trace_metadata(self, trace_id: str, key: str, value: str):
        """
        Set the trace metadata for the given request ID.
        """
        with self.get_trace(trace_id) as trace:
            if trace:
                trace.info.trace_metadata[key] = value

    def pop_trace(self, otel_trace_id: int) -> ManagerTrace | None:
        """
        Pop trace data for the given OpenTelemetry trace ID and
        return it as a ManagerTrace wrapper containing the trace and prompts.
        """
        with self._lock:
            mlflow_trace_id = self._otel_id_to_mlflow_trace_id.pop(otel_trace_id, None)
            internal_trace = self._traces.pop(mlflow_trace_id, None) if mlflow_trace_id else None
            if internal_trace is None:
                return None
            return ManagerTrace(
                trace=internal_trace.to_mlflow_trace(), prompts=internal_trace.prompts
            )

    def _check_timeout_update(self):
        """
        TTL/Timeout may be updated by users after initial cache creation. This method checks
        for the update and create a new cache instance with the updated timeout.
        """
        new_timeout = MLFLOW_TRACE_TIMEOUT_SECONDS.get()
        if new_timeout != getattr(self._traces, "timeout", None):
            if len(self._traces) > 0:
                _logger.warning(
                    f"The timeout of the trace buffer has been updated to {new_timeout} seconds. "
                    "This operation discards all in-progress traces at the moment. Please make "
                    "sure to update the timeout when there are no in-progress traces."
                )

            with self._lock:
                # We need to check here again in case this method runs in parallel
                if new_timeout != getattr(self._traces, "timeout", None):
                    self._traces = get_trace_cache_with_timeout()

    @classmethod
    def reset(cls):
        """Clear all the aggregated trace data. This should only be used for testing."""
        if cls._instance:
            with cls._instance._lock:
                cls._instance._traces.clear()
            cls._instance = Noneimport os
from typing import Any

from opentelemetry.proto.common.v1.common_pb2 import AnyValue
from opentelemetry.sdk.trace.export import SpanExporter

from mlflow.environment_variables import MLFLOW_ENABLE_OTLP_EXPORTER
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import RESOURCE_DOES_NOT_EXIST

# Constants for OpenTelemetry integration
MLFLOW_EXPERIMENT_ID_HEADER = "x-mlflow-experiment-id"
OTLP_TRACES_PATH = "/v1/traces"


def should_use_otlp_exporter() -> bool:
    """
    Determine if OTLP traces should be exported based on environment configuration.
    """
    return _get_otlp_endpoint() is not None and MLFLOW_ENABLE_OTLP_EXPORTER.get()


def should_export_otlp_metrics() -> bool:
    """
    Determine if OTLP metrics should be exported based on environment configuration.

    Returns True if metrics endpoint is configured.
    """
    return _get_otlp_metrics_endpoint() is not None


def get_otlp_exporter() -> SpanExporter:
    """
    Get the OTLP exporter based on the configured protocol.
    """
    endpoint = _get_otlp_endpoint()
    protocol = _get_otlp_protocol()
    if protocol == "grpc":
        try:
            from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter
        except ImportError:
            raise MlflowException(
                "gRPC OTLP exporter is not available. Please install the required dependency by "
                "running `pip install opentelemetry-exporter-otlp-proto-grpc`.",
                error_code=RESOURCE_DOES_NOT_EXIST,
            )

        return OTLPSpanExporter(endpoint=endpoint)
    elif protocol == "http/protobuf":
        try:
            from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
        except ImportError as e:
            raise MlflowException(
                "HTTP OTLP exporter is not available. Please install the required dependency by "
                "running `pip install opentelemetry-exporter-otlp-proto-http`.",
                error_code=RESOURCE_DOES_NOT_EXIST,
            ) from e

        return OTLPSpanExporter(endpoint=endpoint)
    else:
        raise MlflowException.invalid_parameter_value(
            f"Unsupported OTLP protocol '{protocol}' is configured. Please set "
            "the protocol to either 'grpc' or 'http/protobuf'."
        )


def _get_otlp_endpoint() -> str | None:
    """
    Get the OTLP endpoint from the environment variables.
    Ref: https://opentelemetry.io/docs/languages/sdk-configuration/otlp-exporter/#endpoint-configuration
    """
    # Use `or` instead of default value to do lazy eval
    return os.environ.get("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT") or os.environ.get(
        "OTEL_EXPORTER_OTLP_ENDPOINT"
    )


def _get_otlp_metrics_endpoint() -> str | None:
    """
    Get the OTLP metrics endpoint from the environment variables.
    """
    return os.environ.get("OTEL_EXPORTER_OTLP_METRICS_ENDPOINT") or os.environ.get(
        "OTEL_EXPORTER_OTLP_ENDPOINT"
    )


def _get_otlp_protocol(default_value: str = "grpc") -> str:
    """
    Get the OTLP traces protocol from environment variables.

    Returns the value of OTEL_EXPORTER_OTLP_TRACES_PROTOCOL if set,
    otherwise falls back to OTEL_EXPORTER_OTLP_PROTOCOL, then to default_value.

    Args:
        default_value: The default protocol to use if no environment variables are set.
    """
    return os.environ.get("OTEL_EXPORTER_OTLP_TRACES_PROTOCOL") or os.environ.get(
        "OTEL_EXPORTER_OTLP_PROTOCOL", default_value
    )


def _get_otlp_metrics_protocol(default_value: str = "grpc") -> str:
    """
    Get the OTLP metrics protocol from environment variables.

    Returns the value of OTEL_EXPORTER_OTLP_METRICS_PROTOCOL if set,
    otherwise falls back to OTEL_EXPORTER_OTLP_PROTOCOL, then to default_value.

    Args:
        default_value: The default protocol to use if no environment variables are set.
    """
    return os.environ.get("OTEL_EXPORTER_OTLP_METRICS_PROTOCOL") or os.environ.get(
        "OTEL_EXPORTER_OTLP_PROTOCOL", default_value
    )







def _set_otel_proto_anyvalue(pb_any_value: AnyValue, value: Any) -> None:
    """Set a value on an OTel protobuf AnyValue message.

    Args:
        pb_any_value: The OTel protobuf AnyValue message to populate.
        value: The value to set.
    """
    if value is None:
        # Leave the value unset for None
        pass
    elif isinstance(value, bool):
        pb_any_value.bool_value = value
    elif isinstance(value, str):
        pb_any_value.string_value = value
    elif isinstance(value, int):
        pb_any_value.int_value = value
    elif isinstance(value, float):
        pb_any_value.double_value = value
    elif isinstance(value, bytes):
        pb_any_value.bytes_value = value
    elif isinstance(value, (list, tuple)):
        # Handle arrays
        for item in value:
            _set_otel_proto_anyvalue(pb_any_value.array_value.values.add(), item)
    elif isinstance(value, dict):
        # Handle key-value lists
        for k, v in value.items():
            kv = pb_any_value.kvlist_value.values.add()
            kv.key = str(k)
            _set_otel_proto_anyvalue(kv.value, v)
    else:
        # For unknown types, convert to string
        pb_any_value.string_value = str(value)
```

## 原始行 8 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/entities/span.py | sed -n '1,760p'
rg -n \"to_mlflow_trace|from_otel_proto|to_otel_proto|NoOpSpan|create_mlflow_span|_decode_otel_proto_anyvalue|_CachedSpanAttributesRegistry\" tests mlflow | head -300"
```

退出码：`0`

输出：
```
     1	import base64
     2	import json
     3	import logging
     4	from functools import lru_cache
     5	from typing import Any, Union
     6	
     7	from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
     8	from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
     9	from opentelemetry.sdk.resources import Resource as _OTelResource
    10	from opentelemetry.sdk.trace import Event as OTelEvent
    11	from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
    12	from opentelemetry.trace import NonRecordingSpan, SpanContext, TraceFlags
    13	from opentelemetry.trace import Span as OTelSpan
    14	from opentelemetry.trace import Status as OTelStatus
    15	from opentelemetry.trace import StatusCode as OTelStatusCode
    16	
    17	import mlflow
    18	from mlflow.entities.span_event import SpanEvent
    19	from mlflow.entities.span_status import SpanStatus, SpanStatusCode
    20	from mlflow.exceptions import MlflowException
    21	from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    22	from mlflow.tracing.constant import TRACE_REQUEST_ID_PREFIX, SpanAttributeKey
    23	from mlflow.tracing.utils import (
    24	    build_otel_context,
    25	    decode_id,
    26	    dump_span_attribute_value,
    27	    encode_span_id,
    28	    encode_trace_id,
    29	    generate_mlflow_trace_id_from_otel_trace_id,
    30	    generate_trace_id_v4_from_otel_trace_id,
    31	    parse_trace_id_v4,
    32	)
    33	from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue
    34	
    35	
    36	
    37	
    38	
    39	
    40	_logger = logging.getLogger(__name__)
    41	
    42	
    43	# Not using enum as we want to allow custom span type string.
    44	class SpanType:
    45	    """
    46	    Predefined set of span types.
    47	    """
    48	
    49	    LLM = "LLM"
    50	    CHAIN = "CHAIN"
    51	    AGENT = "AGENT"
    52	    TOOL = "TOOL"
    53	    CHAT_MODEL = "CHAT_MODEL"
    54	    RETRIEVER = "RETRIEVER"
    55	    PARSER = "PARSER"
    56	    EMBEDDING = "EMBEDDING"
    57	    RERANKER = "RERANKER"
    58	    MEMORY = "MEMORY"
    59	    UNKNOWN = "UNKNOWN"
    60	    WORKFLOW = "WORKFLOW"
    61	    TASK = "TASK"
    62	    GUARDRAIL = "GUARDRAIL"
    63	    EVALUATOR = "EVALUATOR"
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	class Span:
    92	    """
    93	    A span object. A span represents a unit of work or operation and is the building
    94	    block of Traces.
    95	
    96	    This Span class represents immutable span data that is already finished and persisted.
    97	    The "live" span that is being created and updated during the application runtime is
    98	    represented by the :py:class:`LiveSpan <mlflow.entities.LiveSpan>` subclass.
    99	    """
   100	
   101	    def __init__(self, otel_span: OTelReadableSpan):
   102	        if not isinstance(otel_span, OTelReadableSpan):
   103	            raise MlflowException(
   104	                "The `otel_span` argument for the Span class must be an instance of ReadableSpan, "
   105	                f"but got {type(otel_span)}.",
   106	                INVALID_PARAMETER_VALUE,
   107	            )
   108	
   109	        self._span = otel_span
   110	        # Since the span is immutable, we can cache the attributes to avoid the redundant
   111	        # deserialization of the attribute values.
   112	        self._attributes = _CachedSpanAttributesRegistry(otel_span)
   113	
   114	    @property
   115	    @lru_cache(maxsize=1)
   116	    def trace_id(self) -> str:
   117	        """The trace ID of the span, a unique identifier for the trace it belongs to."""
   118	        return self.get_attribute(SpanAttributeKey.REQUEST_ID)
   119	
   120	
   121	
   122	
   123	
   124	
   125	    @property
   126	    def span_id(self) -> str:
   127	        """The ID of the span. This is only unique within a trace."""
   128	        return encode_span_id(self._span.context.span_id)
   129	
   130	    @property
   131	    def name(self) -> str:
   132	        """The name of the span."""
   133	        return self._span.name
   134	
   135	    @property
   136	    def start_time_ns(self) -> int:
   137	        """The start time of the span in nanosecond."""
   138	        return self._span._start_time
   139	
   140	    @property
   141	    def end_time_ns(self) -> int | None:
   142	        """The end time of the span in nanosecond."""
   143	        return self._span._end_time
   144	
   145	    @property
   146	    def parent_id(self) -> str | None:
   147	        """The span ID of the parent span."""
   148	        if self._span.parent is None:
   149	            return None
   150	        return encode_span_id(self._span.parent.span_id)
   151	
   152	    @property
   153	    def status(self) -> SpanStatus:
   154	        """The status of the span."""
   155	        return SpanStatus.from_otel_status(self._span.status)
   156	
   157	    @property
   158	    def inputs(self) -> Any:
   159	        """The input values of the span."""
   160	        return self.get_attribute(SpanAttributeKey.INPUTS)
   161	
   162	    @property
   163	    def outputs(self) -> Any:
   164	        """The output values of the span."""
   165	        return self.get_attribute(SpanAttributeKey.OUTPUTS)
   166	
   167	
   168	
   169	
   170	
   171	
   172	    @property
   173	    def _trace_id(self) -> str:
   174	        """
   175	        The OpenTelemetry trace ID of the span. Note that this should not be exposed to
   176	        the user, instead, use trace_id property as an unique identifier for a trace.
   177	        """
   178	        return encode_trace_id(self._span.context.trace_id)
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	    def __repr__(self):
   210	        return (
   211	            f"{type(self).__name__}(name={self.name!r}, trace_id={self.trace_id!r}, "
   212	            f"span_id={self.span_id!r}, parent_id={self.parent_id!r})"
   213	        )
   214	
   215	    def get_attribute(self, key: str) -> Any | None:
   216	        """
   217	        Get a single attribute value from the span.
   218	
   219	        Args:
   220	            key: The key of the attribute to get.
   221	
   222	        Returns:
   223	            The value of the attribute if it exists, otherwise None.
   224	        """
   225	        return self._attributes.get(key)
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	    @classmethod
   258	    def from_dict(cls, data: dict[str, Any]) -> "Span":
   259	        """Create a Span object from the given dictionary."""
   260	        try:
   261	            # Try to deserialize the span using the v3 schema
   262	            request_id = data.get("attributes", {}).get(SpanAttributeKey.REQUEST_ID)
   263	            if not request_id:
   264	                raise MlflowException(
   265	                    f"The {SpanAttributeKey.REQUEST_ID} attribute is empty or missing.",
   266	                    INVALID_PARAMETER_VALUE,
   267	                )
   268	
   269	            if Span._is_span_v2_schema(data):
   270	                return cls.from_dict_v2(data)
   271	
   272	            if _is_base64_encoded(data["trace_id"]):
   273	                otel_trace_id = _decode_id_from_byte(data["trace_id"])
   274	                span_id = _decode_id_from_byte(data["span_id"])
   275	                # Parent ID always exists in proto (empty string) even if the span is a root span.
   276	                parent_id = (
   277	                    _decode_id_from_byte(data["parent_span_id"]) if data["parent_span_id"] else None
   278	                )
   279	            else:
   280	                # In 3.5.0, Span.to_dict keeps trace_id and span_id as the object's properties
   281	                # format, so we need special handling for it.
   282	                otel_trace_id = decode_id(
   283	                    parse_trace_id_v4(data["trace_id"])[1].removeprefix(TRACE_REQUEST_ID_PREFIX)
   284	                )
   285	                span_id = decode_id(data["span_id"])
   286	                parent_id = decode_id(data["parent_span_id"]) if data["parent_span_id"] else None
   287	
   288	            status_code_str = data["status"]["code"]
   289	            try:
   290	                status_code = SpanStatusCode.from_otel_proto_status_code_name(status_code_str)
   291	            except MlflowException:
   292	                # In 3.5.0 Span.to_dict keeps status code as the SpanStatusCode enum value
   293	                # Fall back to value format (e.g., "OK", "ERROR")
   294	                status_code = SpanStatusCode(status_code_str)
   295	            status = SpanStatus(
   296	                status_code=status_code,
   297	                description=data["status"].get("message", ""),
   298	            )
   299	
   300	            end_time_ns = data.get("end_time_unix_nano")
   301	            end_time_ns = int(end_time_ns) if end_time_ns else None
   302	
   303	            otel_span = OTelReadableSpan(
   304	                name=data["name"],
   305	                context=build_otel_context(otel_trace_id, span_id),
   306	                parent=build_otel_context(otel_trace_id, parent_id) if parent_id else None,
   307	                start_time=int(data["start_time_unix_nano"]),
   308	                end_time=end_time_ns,
   309	                attributes=data["attributes"],
   310	                status=status.to_otel_status(),
   311	                # Setting an empty resource explicitly. Otherwise OTel create a new Resource by
   312	                # Resource.create(), which introduces a significant overhead in some environments.
   313	                # https://github.com/mlflow/mlflow/issues/15625
   314	                resource=_OTelResource.get_empty(),
   315	                events=[
   316	                    OTelEvent(
   317	                        name=event["name"],
   318	                        timestamp=int(event["time_unix_nano"]),
   319	                        attributes=event.get("attributes", {}),
   320	                    )
   321	                    for event in data.get("events", [])
   322	                ],
   323	            )
   324	            return cls(otel_span)
   325	        except Exception as e:
   326	            raise MlflowException(
   327	                "Failed to create a Span object from the given dictionary",
   328	                INVALID_PARAMETER_VALUE,
   329	            ) from e
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	
   414	
   415	
   416	
   417	
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	
   426	
   427	
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	
   437	
   438	
   439	
   440	
   441	
   442	
   443	
   444	
   445	
   446	
   447	
   448	
   449	
   450	
   451	
   452	
   453	
   454	
   455	
   456	
   457	
   458	
   459	
   460	
   461	
   462	
   463	
   464	
   465	
   466	
   467	
   468	
   469	
   470	
   471	
   472	
   473	
   474	
   475	
   476	
   477	
   478	
   479	
   480	
   481	
   482	
   483	
   484	class LiveSpan(Span):
   485	    """
   486	    A "live" version of the :py:class:`Span <mlflow.entities.Span>` class.
   487	
   488	    The live spans are those being created and updated during the application runtime.
   489	    When users start a new span using the tracing APIs within their code, this live span
   490	    object is returned to get and set the span attributes, status, events, and etc.
   491	    """
   492	
   493	    def __init__(
   494	        self,
   495	        otel_span: OTelSpan,
   496	        trace_id: str,
   497	        span_type: str = SpanType.UNKNOWN,
   498	    ):
   499	        """
   500	        The `otel_span` argument takes an instance of OpenTelemetry Span class, which is
   501	        indeed a subclass of ReadableSpan. Thanks to this, the getter methods of the Span
   502	        class can be reused without any modification.
   503	
   504	        Note that the constructor doesn't call the super().__init__ method, because the Span
   505	        initialization logic is a bit different from the immutable span.
   506	        """
   507	        if not isinstance(otel_span, OTelReadableSpan):
   508	            raise MlflowException(
   509	                "The `otel_span` argument for the LiveSpan class must be an instance of "
   510	                f"trace.Span, but got {type(otel_span)}.",
   511	                INVALID_PARAMETER_VALUE,
   512	            )
   513	
   514	        self._span = otel_span
   515	        self._attributes = _SpanAttributesRegistry(otel_span)
   516	        self._attributes.set(SpanAttributeKey.REQUEST_ID, trace_id)
   517	        self._attributes.set(SpanAttributeKey.SPAN_TYPE, span_type)
   518	        # Track the original span name for deduplication purposes during span logging.
   519	        # Why: When traces contain multiple spans with identical names (e.g., multiple "LLM"
   520	        # or "query" spans), it's difficult for users to distinguish between them in the UI
   521	        # and logs. As spans are logged, we incrementally add numeric suffixes (_1, _2, etc.) to
   522	        # make each span uniquely identifiable within its trace
   523	        self._original_name = otel_span.name
   524	
   525	
   526	
   527	
   528	
   529	    def set_inputs(self, inputs: Any):
   530	        """Set the input values to the span."""
   531	        self.set_attribute(SpanAttributeKey.INPUTS, inputs)
   532	
   533	    def set_outputs(self, outputs: Any):
   534	        """Set the output values to the span."""
   535	        self.set_attribute(SpanAttributeKey.OUTPUTS, outputs)
   536	
   537	    def set_attributes(self, attributes: dict[str, Any]):
   538	        """
   539	        Set the attributes to the span. The attributes must be a dictionary of key-value pairs.
   540	        This method is additive, i.e. it will add new attributes to the existing ones. If an
   541	        attribute with the same key already exists, it will be overwritten.
   542	        """
   543	        if not isinstance(attributes, dict):
   544	            _logger.warning(
   545	                f"Attributes must be a dictionary, but got {type(attributes)}. Skipping."
   546	            )
   547	            return
   548	
   549	        for key, value in attributes.items():
   550	            self.set_attribute(key, value)
   551	
   552	    def set_attribute(self, key: str, value: Any):
   553	        """Set a single attribute to the span."""
   554	        self._attributes.set(key, value)
   555	
   556	    def set_status(self, status: SpanStatusCode | str):
   557	        """
   558	        Set the status of the span.
   559	
   560	        Args:
   561	            status: The status of the span. This can be a
   562	                :py:class:`SpanStatus <mlflow.entities.SpanStatus>` object or a string representing
   563	                of the status code defined in
   564	                :py:class:`SpanStatusCode <mlflow.entities.SpanStatusCode>`
   565	                e.g. ``"OK"``, ``"ERROR"``.
   566	        """
   567	        if isinstance(status, str):
   568	            status = SpanStatus(status)
   569	
   570	        # NB: We need to set the OpenTelemetry native StatusCode, because span's set_status
   571	        #     method only accepts a StatusCode enum in their definition.
   572	        #     https://github.com/open-telemetry/opentelemetry-python/blob/8ed71b15fb8fc9534529da8ce4a21e686248a8f3/opentelemetry-sdk/src/opentelemetry/sdk/trace/__init__.py#L949
   573	        #     Working around this is possible, but requires some hack to handle automatic status
   574	        #     propagation mechanism, so here we just use the native object that meets our
   575	        #     current requirements at least. Nevertheless, declaring the new class extending
   576	        #     the OpenTelemetry Status class so users code doesn't have to import the OTel's
   577	        #     StatusCode object, which makes future migration easier.
   578	        self._span.set_status(status.to_otel_status())
   579	
   580	    def add_event(self, event: SpanEvent):
   581	        """
   582	        Add an event to the span.
   583	
   584	        Args:
   585	            event: The event to add to the span. This should be a
   586	                :py:class:`SpanEvent <mlflow.entities.SpanEvent>` object.
   587	        """
   588	        self._span.add_event(event.name, event.attributes, event.timestamp)
   589	
   590	    def record_exception(self, exception: str | Exception):
   591	        """
   592	        Record an exception on the span, adding an exception event and setting span status to ERROR.
   593	
   594	        Args:
   595	            exception: The exception to record. Can be an Exception instance or a string
   596	                describing the exception.
   597	        """
   598	        if isinstance(exception, Exception):
   599	            self.add_event(SpanEvent.from_exception(exception))
   600	        elif isinstance(exception, str):
   601	            self.add_event(SpanEvent.from_exception(Exception(exception)))
   602	        else:
   603	            raise MlflowException(
   604	                "The `exception` parameter must be an Exception instance or a string.",
   605	                INVALID_PARAMETER_VALUE,
   606	            )
   607	
   608	        self.set_status(
   609	            SpanStatus(
   610	                status_code=SpanStatusCode.ERROR,
   611	                description=f"{type(exception).__name__}: {exception}",
   612	            )
   613	        )
   614	
   615	    def end(
   616	        self,
   617	        outputs: Any | None = None,
   618	        attributes: dict[str, Any] | None = None,
   619	        status: SpanStatus | str | None = None,
   620	        end_time_ns: int | None = None,
   621	    ):
   622	        """
   623	        End the span.
   624	
   625	        outputs: Outputs to set on the span.
   626	        attributes: A dictionary of attributes to set on the span. If the span already has
   627	            attributes, the new attributes will be merged with the existing ones. If the same
   628	            key already exists, the new value will overwrite the old one.
   629	        status: The status of the span. This can be a
   630	            :py:class:`SpanStatus <mlflow.entities.SpanStatus>` object or a string
   631	            representing the status code defined in
   632	            :py:class:`SpanStatusCode <mlflow.entities.SpanStatusCode>`
   633	            e.g. ``"OK"``, ``"ERROR"``. The default status is OK.
   634	        end_time_ns: The end time of the span in nano seconds since the UNIX epoch.
   635	            If not provided, the current time will be used.
   636	
   637	        :meta private:
   638	        """
   639	        try:
   640	            self.set_attributes(attributes or {})
   641	            if outputs is not None:
   642	                self.set_outputs(outputs)
   643	            if status is not None:
   644	                self.set_status(status)
   645	
   646	            # NB: In OpenTelemetry, status code remains UNSET if not explicitly set
   647	            # by the user. However, there is not way to set the status when using
   648	            # @mlflow.trace decorator. Therefore, we just automatically set the status
   649	            # to OK if it is not ERROR.
   650	            if self.status.status_code != SpanStatusCode.ERROR:
   651	                self.set_status(SpanStatus(SpanStatusCode.OK))
   652	
   653	            # Apply span processors
   654	            apply_span_processors(self)
   655	
   656	            self._span.end(end_time=end_time_ns)
   657	
   658	        except Exception as e:
   659	            _logger.warning(
   660	                f"Failed to end span {self.span_id}: {e}. "
   661	                "For full traceback, set logging level to debug.",
   662	                exc_info=_logger.isEnabledFor(logging.DEBUG),
   663	            )
   664	
   665	
   666	
   667	
   668	
   669	
   670	
   671	
   672	
   673	
   674	
   675	
   676	
   677	    @classmethod
   678	    def from_immutable_span(
   679	        cls,
   680	        span: Span,
   681	        parent_span_id: str | None = None,
   682	        trace_id: str | None = None,
   683	        experiment_id: str | None = None,
   684	        otel_trace_id: str | None = None,
   685	    ) -> "LiveSpan":
   686	        """
   687	        Create a new LiveSpan object from the given immutable span by
   688	        cloning the underlying OpenTelemetry span within current context.
   689	
   690	        This is particularly useful when we merging a remote trace into the current trace.
   691	        We cannot merge the remote trace directly, because it is already stored as an immutable
   692	        span, meaning that we cannot update metadata like trace ID, parent span ID,
   693	        which are necessary for merging the trace.
   694	
   695	        Args:
   696	            span: The immutable span object to clone.
   697	            parent_span_id: The parent span ID of the new span.
   698	                If it is None, the span will be created as a root span.
   699	            trace_id: The trace ID to be set on the new span. Specify this if you want to
   700	                create the new span with a particular trace ID.
   701	            experiment_id: The experiment ID to be set on the new span. If not specified, the
   702	                experiment ID will be set to the current experiment ID.
   703	            otel_trace_id: The OpenTelemetry trace ID of the new span in hex encoded format.
   704	                If not specified, the newly generated trace ID will be used.
   705	
   706	        Returns:
   707	            The new LiveSpan object with the same state as the original span.
   708	
   709	        :meta private:
   710	        """
   711	        from mlflow.tracing.trace_manager import InMemoryTraceManager
   712	
   713	        trace_manager = InMemoryTraceManager.get_instance()
   714	        parent_span = trace_manager.get_span_from_id(trace_id, parent_span_id)
   715	
   716	        # Create a new span with the same name, parent, and start time
   717	        otel_span = mlflow.tracing.provider.start_detached_span(
   718	            name=span.name,
   719	            parent=parent_span._span if parent_span else None,
   720	            start_time_ns=span.start_time_ns,
   721	            experiment_id=experiment_id,
   722	        )
   723	
   724	        # The latter one from attributes is the newly generated trace ID by the span processor.
   725	        trace_id = trace_id or json.loads(otel_span.attributes.get(SpanAttributeKey.REQUEST_ID))
   726	        # Span processor registers a new span in the in-memory trace manager, but we want to pop it
   727	        clone_span = trace_manager._traces[trace_id].span_dict.pop(
   728	            encode_span_id(otel_span.context.span_id)
   729	        )
   730	
   731	        # Copy all the attributes, inputs, outputs, and events from the original span
   732	        clone_span.set_status(span.status)
   733	        clone_span.set_attributes(
   734	            {k: v for k, v in span.attributes.items() if k != SpanAttributeKey.REQUEST_ID}
   735	        )
   736	        if span.inputs:
   737	            clone_span.set_inputs(span.inputs)
   738	        if span.outputs:
   739	            clone_span.set_outputs(span.outputs)
   740	        for event in span.events:
   741	            clone_span.add_event(event)
   742	
   743	        # Update trace ID and span ID
   744	        context = span._span.get_span_context()
   745	        clone_span._span._context = SpanContext(
   746	            # Override otel_trace_id if provided, otherwise use the new trace ID
   747	            trace_id=decode_id(otel_trace_id) if otel_trace_id else otel_span.context.trace_id,
   748	            # Re-use same span ID as their ID space is local to the trace
   749	            span_id=context.span_id,
   750	            is_remote=context.is_remote,
   751	            # Override trace flag as if it is sampled within current context.
   752	            trace_flags=TraceFlags(TraceFlags.SAMPLED),
   753	        )
   754	
   755	        return clone_span
   756	
   757	
   758	NO_OP_SPAN_TRACE_ID = "MLFLOW_NO_OP_SPAN_TRACE_ID"
   759	
   760	
/bin/bash: line 2: rg: command not found
```

## 原始行 11 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/entities/span.py | sed -n '250,520p'; nl -ba mlflow/entities/span.py | sed -n '740,1120p'; find tests -type f | grep -E 'span|trace_manager|otlp' | head -100"
```

退出码：`0`

输出：
```
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	    @classmethod
   258	    def from_dict(cls, data: dict[str, Any]) -> "Span":
   259	        """Create a Span object from the given dictionary."""
   260	        try:
   261	            # Try to deserialize the span using the v3 schema
   262	            request_id = data.get("attributes", {}).get(SpanAttributeKey.REQUEST_ID)
   263	            if not request_id:
   264	                raise MlflowException(
   265	                    f"The {SpanAttributeKey.REQUEST_ID} attribute is empty or missing.",
   266	                    INVALID_PARAMETER_VALUE,
   267	                )
   268	
   269	            if Span._is_span_v2_schema(data):
   270	                return cls.from_dict_v2(data)
   271	
   272	            if _is_base64_encoded(data["trace_id"]):
   273	                otel_trace_id = _decode_id_from_byte(data["trace_id"])
   274	                span_id = _decode_id_from_byte(data["span_id"])
   275	                # Parent ID always exists in proto (empty string) even if the span is a root span.
   276	                parent_id = (
   277	                    _decode_id_from_byte(data["parent_span_id"]) if data["parent_span_id"] else None
   278	                )
   279	            else:
   280	                # In 3.5.0, Span.to_dict keeps trace_id and span_id as the object's properties
   281	                # format, so we need special handling for it.
   282	                otel_trace_id = decode_id(
   283	                    parse_trace_id_v4(data["trace_id"])[1].removeprefix(TRACE_REQUEST_ID_PREFIX)
   284	                )
   285	                span_id = decode_id(data["span_id"])
   286	                parent_id = decode_id(data["parent_span_id"]) if data["parent_span_id"] else None
   287	
   288	            status_code_str = data["status"]["code"]
   289	            try:
   290	                status_code = SpanStatusCode.from_otel_proto_status_code_name(status_code_str)
   291	            except MlflowException:
   292	                # In 3.5.0 Span.to_dict keeps status code as the SpanStatusCode enum value
   293	                # Fall back to value format (e.g., "OK", "ERROR")
   294	                status_code = SpanStatusCode(status_code_str)
   295	            status = SpanStatus(
   296	                status_code=status_code,
   297	                description=data["status"].get("message", ""),
   298	            )
   299	
   300	            end_time_ns = data.get("end_time_unix_nano")
   301	            end_time_ns = int(end_time_ns) if end_time_ns else None
   302	
   303	            otel_span = OTelReadableSpan(
   304	                name=data["name"],
   305	                context=build_otel_context(otel_trace_id, span_id),
   306	                parent=build_otel_context(otel_trace_id, parent_id) if parent_id else None,
   307	                start_time=int(data["start_time_unix_nano"]),
   308	                end_time=end_time_ns,
   309	                attributes=data["attributes"],
   310	                status=status.to_otel_status(),
   311	                # Setting an empty resource explicitly. Otherwise OTel create a new Resource by
   312	                # Resource.create(), which introduces a significant overhead in some environments.
   313	                # https://github.com/mlflow/mlflow/issues/15625
   314	                resource=_OTelResource.get_empty(),
   315	                events=[
   316	                    OTelEvent(
   317	                        name=event["name"],
   318	                        timestamp=int(event["time_unix_nano"]),
   319	                        attributes=event.get("attributes", {}),
   320	                    )
   321	                    for event in data.get("events", [])
   322	                ],
   323	            )
   324	            return cls(otel_span)
   325	        except Exception as e:
   326	            raise MlflowException(
   327	                "Failed to create a Span object from the given dictionary",
   328	                INVALID_PARAMETER_VALUE,
   329	            ) from e
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	
   414	
   415	
   416	
   417	
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	
   426	
   427	
   428	
   429	
   430	
   431	
   432	
   433	
   434	
   435	
   436	
   437	
   438	
   439	
   440	
   441	
   442	
   443	
   444	
   445	
   446	
   447	
   448	
   449	
   450	
   451	
   452	
   453	
   454	
   455	
   456	
   457	
   458	
   459	
   460	
   461	
   462	
   463	
   464	
   465	
   466	
   467	
   468	
   469	
   470	
   471	
   472	
   473	
   474	
   475	
   476	
   477	
   478	
   479	
   480	
   481	
   482	
   483	
   484	class LiveSpan(Span):
   485	    """
   486	    A "live" version of the :py:class:`Span <mlflow.entities.Span>` class.
   487	
   488	    The live spans are those being created and updated during the application runtime.
   489	    When users start a new span using the tracing APIs within their code, this live span
   490	    object is returned to get and set the span attributes, status, events, and etc.
   491	    """
   492	
   493	    def __init__(
   494	        self,
   495	        otel_span: OTelSpan,
   496	        trace_id: str,
   497	        span_type: str = SpanType.UNKNOWN,
   498	    ):
   499	        """
   500	        The `otel_span` argument takes an instance of OpenTelemetry Span class, which is
   501	        indeed a subclass of ReadableSpan. Thanks to this, the getter methods of the Span
   502	        class can be reused without any modification.
   503	
   504	        Note that the constructor doesn't call the super().__init__ method, because the Span
   505	        initialization logic is a bit different from the immutable span.
   506	        """
   507	        if not isinstance(otel_span, OTelReadableSpan):
   508	            raise MlflowException(
   509	                "The `otel_span` argument for the LiveSpan class must be an instance of "
   510	                f"trace.Span, but got {type(otel_span)}.",
   511	                INVALID_PARAMETER_VALUE,
   512	            )
   513	
   514	        self._span = otel_span
   515	        self._attributes = _SpanAttributesRegistry(otel_span)
   516	        self._attributes.set(SpanAttributeKey.REQUEST_ID, trace_id)
   517	        self._attributes.set(SpanAttributeKey.SPAN_TYPE, span_type)
   518	        # Track the original span name for deduplication purposes during span logging.
   519	        # Why: When traces contain multiple spans with identical names (e.g., multiple "LLM"
   520	        # or "query" spans), it's difficult for users to distinguish between them in the UI
   740	        for event in span.events:
   741	            clone_span.add_event(event)
   742	
   743	        # Update trace ID and span ID
   744	        context = span._span.get_span_context()
   745	        clone_span._span._context = SpanContext(
   746	            # Override otel_trace_id if provided, otherwise use the new trace ID
   747	            trace_id=decode_id(otel_trace_id) if otel_trace_id else otel_span.context.trace_id,
   748	            # Re-use same span ID as their ID space is local to the trace
   749	            span_id=context.span_id,
   750	            is_remote=context.is_remote,
   751	            # Override trace flag as if it is sampled within current context.
   752	            trace_flags=TraceFlags(TraceFlags.SAMPLED),
   753	        )
   754	
   755	        return clone_span
   756	
   757	
   758	NO_OP_SPAN_TRACE_ID = "MLFLOW_NO_OP_SPAN_TRACE_ID"
   759	
   760	
   761	class NoOpSpan(Span):
   762	    """
   763	    No-op implementation of the Span interface.
   764	
   765	    This instance should be returned from the mlflow.start_span context manager when span
   766	    creation fails. This class should have exactly the same interface as the Span so that
   767	    user's setter calls do not raise runtime errors.
   768	
   769	    E.g.
   770	
   771	    .. code-block:: python
   772	
   773	        with mlflow.start_span("span_name") as span:
   774	            # Even if the span creation fails, the following calls should pass.
   775	            span.set_inputs({"x": 1})
   776	            # Do something
   777	
   778	    """
   779	
   780	    def __init__(self):
   781	        self._span = NonRecordingSpan(context=None)
   782	        self._attributes = {}
   783	
   784	
   785	
   786	
   787	
   788	
   789	
   790	
   791	
   792	
   793	
   794	
   795	
   796	
   797	
   798	
   799	
   800	
   801	
   802	
   803	
   804	
   805	
   806	
   807	    @property
   808	    def context(self):
   809	        return None
   810	
   811	    @property
   812	    def parent_id(self):
   813	        return None
   814	
   815	
   816	
   817	
   818	
   819	
   820	
   821	
   822	
   823	
   824	
   825	
   826	
   827	
   828	
   829	
   830	
   831	
   832	
   833	
   834	
   835	
   836	
   837	
   838	
   839	
   840	
   841	    def record_exception(self, exception: str | Exception):
   842	        pass
   843	
   844	
   845	
   846	
   847	
   848	
   849	
   850	
   851	
   852	
   853	
   854	class _SpanAttributesRegistry:
   855	    """
   856	    A utility class to manage the span attributes.
   857	
   858	    In MLflow users can add arbitrary key-value pairs to the span attributes, however,
   859	    OpenTelemetry only allows a limited set of types to be stored in the attribute values.
   860	    Therefore, we serialize all values into JSON string before storing them in the span.
   861	    This class provides simple getter and setter methods to interact with the span attributes
   862	    without worrying about the serde process.
   863	    """
   864	
   865	    def __init__(self, otel_span: OTelSpan):
   866	        self._span = otel_span
   867	
   868	
   869	
   870	
   871	    def get(self, key: str):
   872	        serialized_value = self._span.attributes.get(key)
   873	        if serialized_value:
   874	            try:
   875	                return json.loads(serialized_value)
   876	            except Exception:
   877	                # If failed to deserialize (e.g., string value is directly set to OTel span),
   878	                # return the original value as is.
   879	                return serialized_value
   880	
   881	    def set(self, key: str, value: Any):
   882	        if not isinstance(key, str):
   883	            _logger.warning(f"Attribute key must be a string, but got {type(key)}. Skipping.")
   884	            return
   885	
   886	        # NB: OpenTelemetry attribute can store not only string but also a few primitives like
   887	        #   int, float, bool, and list of them. However, we serialize all into JSON string here
   888	        #   for the simplicity in deserialization process.
   889	        self._span.set_attribute(key, dump_span_attribute_value(value))
   890	
   891	
   892	class _CachedSpanAttributesRegistry(_SpanAttributesRegistry):
   893	    """
   894	    A cache-enabled version of the SpanAttributesRegistry.
   895	
   896	    The caching helps to avoid the redundant deserialization of the attribute, however, it does
   897	    not handle the value change well. Therefore, this class should only be used for the persisted
   898	    spans that are immutable, and thus implemented as a subclass of _SpanAttributesRegistry.
   899	    """
   900	
   901	    @lru_cache(maxsize=128)
   902	    def get(self, key: str):
   903	        return super().get(key)
   904	
tests/tracing/otel/test_span_translation.py
tests/tracing/test_trace_manager.py
tests/tracing/utils/test_otlp.py
tests/genai/judges/test_judge_tool_get_root_span.py
tests/genai/judges/test_judge_tool_get_span.py
tests/genai/judges/test_judge_tool_get_span_performance_and_timing_report.py
tests/genai/judges/test_judge_tool_list_spans.py
tests/langgraph/sample_code/langgraph_with_custom_span.py
tests/entities/test_span_event.py
tests/entities/test_span_status.py
```

## 原始行 13 · agent_message

```
The source is intentionally masked in large sections: the core classes exist, but many methods are absent rather than stubbed. I’m mapping the expected behavior from the repository’s tests and neighboring entities so the implementation stays consistent with this version’s schemas.
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,360p' tests/tracing/otel/test_span_translation.py; sed -n '1,420p' tests/tracing/test_trace_manager.py; sed -n '1,320p' tests/tracing/utils/test_otlp.py"
```

退出码：`0`

输出：
```
import json
from typing import Any
from unittest import mock

import pytest

from mlflow.entities.span import Span, SpanType
from mlflow.tracing.constant import SpanAttributeKey, TokenUsageKey
from mlflow.tracing.otel.translation import (
    translate_loaded_span,
    translate_span_type_from_otel,
    translate_span_when_storing,
)
from mlflow.tracing.otel.translation.base import OtelSchemaTranslator
from mlflow.tracing.otel.translation.genai_semconv import GenAiTranslator
from mlflow.tracing.otel.translation.google_adk import GoogleADKTranslator
from mlflow.tracing.otel.translation.open_inference import OpenInferenceTranslator
from mlflow.tracing.otel.translation.traceloop import TraceloopTranslator


@pytest.mark.parametrize(
    ("translator", "otel_kind", "expected_type"),
    [
        (OpenInferenceTranslator, "LLM", SpanType.LLM),
        (OpenInferenceTranslator, "CHAIN", SpanType.CHAIN),
        (OpenInferenceTranslator, "AGENT", SpanType.AGENT),
        (OpenInferenceTranslator, "TOOL", SpanType.TOOL),
        (OpenInferenceTranslator, "RETRIEVER", SpanType.RETRIEVER),
        (OpenInferenceTranslator, "EMBEDDING", SpanType.EMBEDDING),
        (OpenInferenceTranslator, "RERANKER", SpanType.RERANKER),
        (OpenInferenceTranslator, "GUARDRAIL", SpanType.GUARDRAIL),
        (OpenInferenceTranslator, "EVALUATOR", SpanType.EVALUATOR),
        (TraceloopTranslator, "workflow", SpanType.WORKFLOW),
        (TraceloopTranslator, "task", SpanType.TASK),
        (TraceloopTranslator, "agent", SpanType.AGENT),
        (TraceloopTranslator, "tool", SpanType.TOOL),
        (GenAiTranslator, "chat", SpanType.CHAT_MODEL),
        (GenAiTranslator, "create_agent", SpanType.AGENT),
        (GenAiTranslator, "embeddings", SpanType.EMBEDDING),
        (GenAiTranslator, "execute_tool", SpanType.TOOL),
        (GenAiTranslator, "generate_content", SpanType.LLM),
        (GenAiTranslator, "invoke_agent", SpanType.AGENT),
        (GenAiTranslator, "text_completion", SpanType.LLM),
    ],
)
def test_translate_span_type_from_otel(
    translator: OtelSchemaTranslator, otel_kind: str, expected_type: SpanType
):
    attributes = {translator.SPAN_KIND_ATTRIBUTE_KEY: otel_kind}
    result = translate_span_type_from_otel(attributes)
    assert result == expected_type


@pytest.mark.parametrize(
    "attributes",
    [
        {"some.other.attribute": "value"},
        {OpenInferenceTranslator.SPAN_KIND_ATTRIBUTE_KEY: "UNKNOWN_TYPE"},
        {TraceloopTranslator.SPAN_KIND_ATTRIBUTE_KEY: "unknown_type"},
    ],
)
def test_translate_span_type_returns_none(attributes):
    result = translate_span_type_from_otel(attributes)
    assert result is None


@pytest.mark.parametrize(
    ("attr_key", "attr_value", "expected_type"),
    [
        (OpenInferenceTranslator.SPAN_KIND_ATTRIBUTE_KEY, json.dumps("LLM"), SpanType.LLM),
        (TraceloopTranslator.SPAN_KIND_ATTRIBUTE_KEY, json.dumps("agent"), SpanType.AGENT),
    ],
)
def test_json_serialized_values(attr_key, attr_value, expected_type):
    attributes = {attr_key: attr_value}
    result = translate_span_type_from_otel(attributes)
    assert result == expected_type


@pytest.mark.parametrize(
    ("attr_key", "attr_value", "expected_type"),
    [
        (OpenInferenceTranslator.SPAN_KIND_ATTRIBUTE_KEY, "LLM", SpanType.LLM),
        (TraceloopTranslator.SPAN_KIND_ATTRIBUTE_KEY, "agent", SpanType.AGENT),
    ],
)
def test_translate_loaded_span_sets_span_type(attr_key, attr_value, expected_type):
    span_dict = {"attributes": {attr_key: attr_value}}
    result = translate_loaded_span(span_dict)

    assert SpanAttributeKey.SPAN_TYPE in result["attributes"]
    span_type = json.loads(result["attributes"][SpanAttributeKey.SPAN_TYPE])
    assert span_type == expected_type


@pytest.mark.parametrize(
    ("span_dict", "should_have_span_type", "expected_type"),
    [
        (
            {
                "attributes": {
                    SpanAttributeKey.SPAN_TYPE: json.dumps(SpanType.TOOL),
                    "openinference.span.kind": "LLM",
                }
            },
            True,
            SpanType.TOOL,
        ),
        ({"attributes": {"some.other.attribute": "value"}}, False, None),
        ({}, False, None),
    ],
)
def test_translate_loaded_span_edge_cases(span_dict, should_have_span_type, expected_type):
    result = translate_loaded_span(span_dict)
    if should_have_span_type:
        assert SpanAttributeKey.SPAN_TYPE in result["attributes"]
        span_type = json.loads(result["attributes"][SpanAttributeKey.SPAN_TYPE])
        assert span_type == expected_type
    else:
        assert SpanAttributeKey.SPAN_TYPE not in result.get("attributes", {})


@pytest.mark.parametrize(
    "translator", [OpenInferenceTranslator, GenAiTranslator, TraceloopTranslator]
)
@pytest.mark.parametrize("total_token_exists", [True, False])
def test_translate_token_usage_from_otel(translator: OtelSchemaTranslator, total_token_exists):
    span = mock.Mock(spec=Span)
    span.parent_id = "parent_123"
    span_dict = {
        "attributes": {
            translator.INPUT_TOKEN_KEY: 100,
            translator.OUTPUT_TOKEN_KEY: 50,
        }
    }
    if total_token_exists and translator.TOTAL_TOKEN_KEY:
        span_dict["attributes"][translator.TOTAL_TOKEN_KEY] = 150

    span.to_dict.return_value = span_dict

    result = translate_span_when_storing(span)

    assert SpanAttributeKey.CHAT_USAGE in result["attributes"]
    usage = json.loads(result["attributes"][SpanAttributeKey.CHAT_USAGE])
    assert usage[TokenUsageKey.INPUT_TOKENS] == 100
    assert usage[TokenUsageKey.OUTPUT_TOKENS] == 50
    assert usage[TokenUsageKey.TOTAL_TOKENS] == 150


@pytest.mark.parametrize(
    ("attributes", "expected_input", "expected_output", "expected_total"),
    [
        (
            {"gen_ai.usage.input_tokens": 75, "gen_ai.usage.output_tokens": 25},
            75,
            25,
            100,
        ),
        (
            {
                SpanAttributeKey.CHAT_USAGE: json.dumps(
                    {
                        TokenUsageKey.INPUT_TOKENS: 200,
                        TokenUsageKey.OUTPUT_TOKENS: 100,
                        TokenUsageKey.TOTAL_TOKENS: 300,
                    }
                ),
                "gen_ai.usage.input_tokens": 50,
                "gen_ai.usage.output_tokens": 25,
            },
            200,
            100,
            300,
        ),
    ],
)
def test_translate_token_usage_edge_cases(
    attributes, expected_input, expected_output, expected_total
):
    span = mock.Mock(spec=Span)
    span.parent_id = "parent_123"
    span_dict = {"attributes": attributes}
    span.to_dict.return_value = span_dict

    result = translate_span_when_storing(span)

    usage = json.loads(result["attributes"][SpanAttributeKey.CHAT_USAGE])
    assert usage[TokenUsageKey.INPUT_TOKENS] == expected_input
    assert usage[TokenUsageKey.OUTPUT_TOKENS] == expected_output
    assert usage[TokenUsageKey.TOTAL_TOKENS] == expected_total


@pytest.mark.parametrize(
    "translator",
    [OpenInferenceTranslator, GenAiTranslator, GoogleADKTranslator],
)
@pytest.mark.parametrize(
    "input_value",
    ["test input", {"query": "test"}, 123],
)
@pytest.mark.parametrize("parent_id", [None, "parent_123"])
def test_translate_inputs_for_spans(
    parent_id: str | None, translator: OtelSchemaTranslator, input_value: Any
):
    span = mock.Mock(spec=Span)
    span.parent_id = parent_id
    for input_key in translator.INPUT_VALUE_KEYS:
        span_dict = {"attributes": {input_key: json.dumps(input_value)}}
        span.to_dict.return_value = span_dict

        result = translate_span_when_storing(span)

        assert result["attributes"][SpanAttributeKey.INPUTS] == json.dumps(input_value)


@pytest.mark.parametrize(
    "input_key",
    [
        "traceloop.entity.input",
        "gen_ai.prompt.0.content",
        "gen_ai.prompt.1.content",
        "gen_ai.completion.0.tool_calls.0.arguments",
        "gen_ai.completion.1.tool_calls.1.arguments",
    ],
)
@pytest.mark.parametrize(
    "input_value",
    ["test input", {"query": "test"}, 123],
)
def test_translate_inputs_for_spans_traceloop(input_key: str, input_value: Any):
    span = mock.Mock(spec=Span)
    span.parent_id = "parent_123"
    span_dict = {"attributes": {input_key: json.dumps(input_value)}}
    span.to_dict.return_value = span_dict

    result = translate_span_when_storing(span)
    assert result["attributes"][SpanAttributeKey.INPUTS] == json.dumps(input_value)


@pytest.mark.parametrize(
    "translator",
    [OpenInferenceTranslator, GenAiTranslator, GoogleADKTranslator],
)
@pytest.mark.parametrize("parent_id", [None, "parent_123"])
def test_translate_outputs_for_spans(parent_id: str | None, translator: OtelSchemaTranslator):
    output_value = "test output"
    span = mock.Mock(spec=Span)
    span.parent_id = parent_id
    for output_key in translator.OUTPUT_VALUE_KEYS:
        span_dict = {"attributes": {output_key: json.dumps(output_value)}}
        span.to_dict.return_value = span_dict

        result = translate_span_when_storing(span)

        assert result["attributes"][SpanAttributeKey.OUTPUTS] == json.dumps(output_value)


@pytest.mark.parametrize(
    "output_key",
    [
        "traceloop.entity.output",
        "gen_ai.completion.0.content",
        "gen_ai.completion.1.content",
    ],
)
@pytest.mark.parametrize(
    "output_value",
    ["test input", {"query": "test"}, 123],
)
def test_translate_outputs_for_spans_traceloop(output_key: str, output_value: Any):
    span = mock.Mock(spec=Span)
    span.parent_id = "parent_123"
    span_dict = {"attributes": {output_key: json.dumps(output_value)}}
    span.to_dict.return_value = span_dict

    result = translate_span_when_storing(span)
    assert result["attributes"][SpanAttributeKey.OUTPUTS] == json.dumps(output_value)


@pytest.mark.parametrize(
    (
        "parent_id",
        "attributes",
        "expected_inputs",
        "expected_outputs",
    ),
    [
        (
            "parent_123",
            {
                OpenInferenceTranslator.INPUT_VALUE_KEYS[0]: json.dumps("test input"),
                OpenInferenceTranslator.OUTPUT_VALUE_KEYS[0]: json.dumps("test output"),
            },
            "test input",
            "test output",
        ),
        (
            None,
            {
                SpanAttributeKey.INPUTS: json.dumps("existing input"),
                SpanAttributeKey.OUTPUTS: json.dumps("existing output"),
                OpenInferenceTranslator.INPUT_VALUE_KEYS[0]: json.dumps("new input"),
                OpenInferenceTranslator.OUTPUT_VALUE_KEYS[0]: json.dumps("new output"),
            },
            "existing input",
            "existing output",
        ),
    ],
)
def test_translate_inputs_outputs_edge_cases(
    parent_id,
    attributes,
    expected_inputs,
    expected_outputs,
):
    span = mock.Mock(spec=Span)
    span.parent_id = parent_id
    span_dict = {"attributes": attributes}
    span.to_dict.return_value = span_dict

    result = translate_span_when_storing(span)

    assert SpanAttributeKey.INPUTS in result["attributes"]
    inputs = json.loads(result["attributes"][SpanAttributeKey.INPUTS])
    assert inputs == expected_inputs
    assert SpanAttributeKey.OUTPUTS in result["attributes"]
    outputs = json.loads(result["attributes"][SpanAttributeKey.OUTPUTS])
    assert outputs == expected_outputs
import json
import time
from threading import Thread

from mlflow.entities import LiveSpan, Span
from mlflow.entities.model_registry.prompt_version import PromptVersion
from mlflow.entities.span_status import SpanStatusCode
from mlflow.prompt.constants import LINKED_PROMPTS_TAG_KEY
from mlflow.tracing.trace_manager import InMemoryTraceManager, ManagerTrace

from tests.tracing.helper import create_mock_otel_span, create_test_trace_info


def test_aggregator_singleton():
    obj1 = InMemoryTraceManager.get_instance()
    obj2 = InMemoryTraceManager.get_instance()
    assert obj1 is obj2


def test_add_spans():
    trace_manager = InMemoryTraceManager.get_instance()

    # Add a new trace info
    request_id_1 = "tr-1"
    trace_id_1 = 12345
    trace_manager.register_trace(trace_id_1, create_test_trace_info(request_id_1, "test_1"))

    # Add a span for a new trace
    span_1_1 = _create_test_span(request_id_1, trace_id_1, span_id=1)
    trace_manager.register_span(span_1_1)

    assert request_id_1 in trace_manager._traces
    assert len(trace_manager._traces[request_id_1].span_dict) == 1

    # Add more spans to the same trace
    span_1_1_1 = _create_test_span(request_id_1, trace_id_1, span_id=2, parent_id=1)
    span_1_1_2 = _create_test_span(request_id_1, trace_id_1, span_id=3, parent_id=1)
    trace_manager.register_span(span_1_1_1)
    trace_manager.register_span(span_1_1_2)

    assert len(trace_manager._traces[request_id_1].span_dict) == 3

    # Add a span for another trace under the different experiment
    request_id_2 = "tr-2"
    trace_id_2 = 67890
    trace_manager.register_trace(trace_id_2, create_test_trace_info(request_id_2, "test_2"))

    span_2_1 = _create_test_span(request_id_2, trace_id_2, span_id=1)
    span_2_1_1 = _create_test_span(request_id_2, trace_id_2, span_id=2, parent_id=1)
    trace_manager.register_span(span_2_1)
    trace_manager.register_span(span_2_1_1)

    assert request_id_2 in trace_manager._traces
    assert len(trace_manager._traces[request_id_2].span_dict) == 2

    # Pop the trace data
    manager_trace = trace_manager.pop_trace(trace_id_1)
    assert isinstance(manager_trace, ManagerTrace)
    assert manager_trace.trace.info.request_id == request_id_1
    assert len(manager_trace.trace.data.spans) == 3
    assert request_id_1 not in trace_manager._traces

    # Convert to MLflow trace to check immutable spans
    trace = manager_trace.trace
    assert isinstance(trace.data.spans[0], Span)
    assert not isinstance(trace.data.spans[0], LiveSpan)

    manager_trace = trace_manager.pop_trace(trace_id_2)
    assert isinstance(manager_trace, ManagerTrace)
    assert manager_trace.trace.info.request_id == request_id_2
    assert len(manager_trace.trace.data.spans) == 2
    assert request_id_2 not in trace_manager._traces

    # Pop a trace that does not exist
    assert trace_manager.pop_trace(90123) is None


def test_add_and_pop_span_thread_safety():
    trace_manager = InMemoryTraceManager.get_instance()

    # Add spans from 10 different threads to 5 different traces
    trace_ids = list(range(5))
    num_threads = 10

    for trace_id in trace_ids:
        trace_manager.register_trace(trace_id, create_test_trace_info(f"tr-{trace_id}", "test"))

    def add_spans(thread_id):
        for trace_id in trace_ids:
            trace_manager.register_span(
                _create_test_span(f"tr-{trace_id}", trace_id=trace_id, span_id=thread_id)
            )

    threads = [Thread(target=add_spans, args=[i]) for i in range(num_threads)]

    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    for trace_id in trace_ids:
        manager_trace = trace_manager.pop_trace(trace_id)
        assert manager_trace is not None
        assert manager_trace.trace.info.request_id == f"tr-{trace_id}"
        assert len(manager_trace.trace.data.spans) == num_threads


def test_traces_buffer_expires_after_ttl(monkeypatch):
    monkeypatch.setenv("MLFLOW_TRACE_BUFFER_TTL_SECONDS", "1")

    trace_manager = InMemoryTraceManager.get_instance()
    request_id_1 = "tr-1"
    trace_manager.register_trace(12345, create_test_trace_info(request_id_1, "test"))

    span_1_1 = _create_test_span(request_id_1)
    trace_manager.register_span(span_1_1)

    assert request_id_1 in trace_manager._traces
    assert len(trace_manager._traces[request_id_1].span_dict) == 1

    time.sleep(1)

    assert request_id_1 not in trace_manager._traces

    # Clear singleton instance again to avoid side effects to other tests
    InMemoryTraceManager._instance = None


def test_traces_buffer_expires_and_log_when_timeout_is_set(monkeypatch):
    # Setting MLFLOW_TRACE_TIMEOUT_SECONDS let MLflow to periodically check the
    # expired traces and log expired ones to the backend.
    monkeypatch.setenv("MLFLOW_TRACE_TIMEOUT_SECONDS", "1")
    monkeypatch.setenv("MLFLOW_TRACE_TTL_CHECK_INTERVAL_SECONDS", "1")

    trace_manager = InMemoryTraceManager.get_instance()
    request_id_1 = "tr-1"
    trace_info = create_test_trace_info(request_id_1, "test")
    trace_manager.register_trace(12345, trace_info)

    span_1_1 = _create_test_span(request_id_1)
    trace_manager.register_span(span_1_1)

    assert trace_manager._traces.get(request_id_1) is not None
    assert len(trace_manager._traces[request_id_1].span_dict) == 1

    assert request_id_1 in trace_manager._traces

    time.sleep(3)

    assert request_id_1 not in trace_manager._traces
    assert span_1_1.status.status_code == SpanStatusCode.ERROR


def test_traces_buffer_max_size_limit(monkeypatch):
    monkeypatch.setenv("MLFLOW_TRACE_BUFFER_MAX_SIZE", "1")

    trace_manager = InMemoryTraceManager.get_instance()
    request_id_1 = "tr-1"
    trace_manager.register_trace(12345, create_test_trace_info(request_id_1, "experiment"))

    span_1_1 = _create_test_span(request_id_1)
    trace_manager.register_span(span_1_1)

    assert request_id_1 in trace_manager._traces
    assert len(trace_manager._traces) == 1

    request_id_2 = "tr-2"
    trace_manager.register_trace(67890, create_test_trace_info(request_id_2, "experiment"))
    span_2_1 = _create_test_span(request_id_2)
    trace_manager.register_span(span_2_1)

    assert request_id_1 not in trace_manager._traces
    assert request_id_2 in trace_manager._traces
    assert len(trace_manager._traces) == 1

    # Clear singleton instance again to avoid side effects to other tests
    InMemoryTraceManager._instance = None


def test_get_span_from_id():
    trace_manager = InMemoryTraceManager.get_instance()
    request_id_1 = "tr-1"
    trace_manager.register_trace(12345, create_test_trace_info(request_id_1, "test"))
    span_1_1 = _create_test_span(request_id_1, trace_id=111, span_id=1)
    span_1_2 = _create_test_span(request_id_1, trace_id=111, span_id=2, parent_id=1)

    request_id_2 = "tr-2"
    trace_manager.register_trace(67890, create_test_trace_info(request_id_2, "test"))
    span_2_1 = _create_test_span(request_id_2, trace_id=222, span_id=1)
    span_2_2 = _create_test_span(request_id_2, trace_id=222, span_id=2, parent_id=1)

    # Add a span for a new trace
    trace_manager.register_span(span_1_1)
    trace_manager.register_span(span_1_2)
    trace_manager.register_span(span_2_1)
    trace_manager.register_span(span_2_2)

    assert trace_manager.get_span_from_id(request_id_1, span_1_1.span_id) == span_1_1
    assert trace_manager.get_span_from_id(request_id_2, span_2_2.span_id) == span_2_2


def test_get_root_span_id():
    trace_manager = InMemoryTraceManager.get_instance()

    request_id_1 = "tr-1"
    trace_manager.register_trace(12345, create_test_trace_info(request_id_1, "test"))
    span_1_1 = _create_test_span(request_id_1, span_id=1)
    span_1_2 = _create_test_span(request_id_1, span_id=2, parent_id=1)

    # Add a span for a new trace
    trace_manager.register_span(span_1_1)
    trace_manager.register_span(span_1_2)

    assert trace_manager.get_root_span_id(request_id_1) == span_1_1.span_id

    # Non-existing trace
    assert trace_manager.get_root_span_id("tr-2") is None


def test_register_prompt():
    prompt_version = PromptVersion(name="test_prompt", version=1, template="Test template")

    trace_manager = InMemoryTraceManager.get_instance()
    request_id_1 = "tr-1"
    trace_manager.register_trace(12345, create_test_trace_info(request_id_1, "test"))
    trace_manager.register_prompt(request_id_1, prompt_version)

    trace = trace_manager._traces[request_id_1]
    assert trace.prompts == [prompt_version]
    assert json.loads(trace.info.tags[LINKED_PROMPTS_TAG_KEY]) == [
        {"name": "test_prompt", "version": "1"}
    ]

    # Adding multiple prompts to the same trace
    prompt_version_2 = PromptVersion(name="test_prompt_2", version=2, template="Test template 2")

    trace_manager.register_prompt(request_id_1, prompt_version_2)
    assert trace.prompts == [prompt_version, prompt_version_2]
    assert json.loads(trace.info.tags[LINKED_PROMPTS_TAG_KEY]) == [
        {"name": "test_prompt", "version": "1"},
        {"name": "test_prompt_2", "version": "2"},
    ]

    # Registering the same prompt should not add it again
    trace_manager.register_prompt(request_id_1, prompt_version)
    assert trace.prompts == [prompt_version, prompt_version_2]
    assert json.loads(trace.info.tags[LINKED_PROMPTS_TAG_KEY]) == [
        {"name": "test_prompt", "version": "1"},
        {"name": "test_prompt_2", "version": "2"},
    ]


def test_register_prompt_thread_safety():
    trace_manager = InMemoryTraceManager.get_instance()
    request_id_1 = "tr-1"
    trace_manager.register_trace(12345, create_test_trace_info(request_id_1, "test"))
    prompt_versions = [
        PromptVersion(name=f"test_prompt_{i}", version=i, template=f"Test template {i}")
        for i in range(10)
    ]

    def register_prompt(prompt_version):
        trace_manager.register_prompt(request_id_1, prompt_version)

    threads = [Thread(target=register_prompt, args=[pv]) for pv in prompt_versions]
    for thread in threads:
        thread.start()
    for thread in threads:
        thread.join()

    trace = trace_manager._traces[request_id_1]
    assert len(trace.prompts) == len(prompt_versions)
    assert len(json.loads(trace.info.tags[LINKED_PROMPTS_TAG_KEY])) == len(prompt_versions)


def _create_test_span(
    request_id="tr-12345",
    trace_id: int = 12345,
    span_id: int = 123,
    parent_id: int | None = None,
    start_time=None,
    end_time=None,
):
    mock_otel_span = create_mock_otel_span(
        trace_id=trace_id,
        span_id=span_id,
        parent_id=parent_id,
        start_time=start_time,
        end_time=end_time,
    )

    span = LiveSpan(mock_otel_span, request_id)
    span.set_status("OK")
    return span
import time

import pytest

import mlflow
from mlflow.entities.span import SpanType
from mlflow.environment_variables import MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT
from mlflow.tracing.processor.mlflow_v3 import MlflowV3SpanProcessor
from mlflow.tracing.processor.otel import OtelSpanProcessor
from mlflow.tracing.provider import _get_trace_exporter, _get_tracer
from mlflow.tracking import MlflowClient
from mlflow.utils.os import is_windows

from tests.tracing.helper import get_traces

# OTLP exporters are not installed in some CI jobs
try:
    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
        OTLPSpanExporter as GrpcExporter,
    )
    from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
        OTLPSpanExporter as HttpExporter,
    )
except ImportError:
    pytest.skip("OTLP exporters are not installed", allow_module_level=True)

from mlflow.exceptions import MlflowException
from mlflow.tracing.utils.otlp import get_otlp_exporter, should_use_otlp_exporter

_TEST_HTTP_OTLP_ENDPOINT = "http://127.0.0.1:4317/v1/traces"
_TEST_HTTPS_OTLP_ENDPOINT = "https://127.0.0.1:4317/v1/traces"


@pytest.mark.parametrize(
    ("traces_endpoint", "otlp_endpoint", "mlflow_enable", "expected"),
    [
        # No endpoints configured
        (None, None, None, False),  # Default behavior - no export without endpoint
        (None, None, "true", False),  # Explicit enable but no endpoint
        (None, None, "false", False),  # Explicit disable and no endpoint
        # OTEL_EXPORTER_OTLP_TRACES_ENDPOINT configured
        (_TEST_HTTP_OTLP_ENDPOINT, None, None, True),  # Default behavior - export enabled
        (_TEST_HTTP_OTLP_ENDPOINT, None, "true", True),  # Explicit enable
        (_TEST_HTTP_OTLP_ENDPOINT, None, "false", False),  # Explicit disable
        # OTEL_EXPORTER_OTLP_ENDPOINT configured
        (None, _TEST_HTTP_OTLP_ENDPOINT, None, True),  # Default behavior - export enabled
        (None, _TEST_HTTP_OTLP_ENDPOINT, "true", True),  # Explicit enable
        (None, _TEST_HTTP_OTLP_ENDPOINT, "false", False),  # Explicit disable
        # Both endpoints configured (traces endpoint takes precedence)
        (_TEST_HTTP_OTLP_ENDPOINT, _TEST_HTTPS_OTLP_ENDPOINT, None, True),
        (_TEST_HTTP_OTLP_ENDPOINT, _TEST_HTTPS_OTLP_ENDPOINT, "false", False),
    ],
)
def test_should_use_otlp_exporter(
    traces_endpoint, otlp_endpoint, mlflow_enable, expected, monkeypatch
):
    # Clear all relevant environment variables to ensure test isolation
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", raising=False)
    monkeypatch.delenv("OTEL_EXPORTER_OTLP_ENDPOINT", raising=False)
    monkeypatch.delenv("MLFLOW_ENABLE_OTLP_EXPORTER", raising=False)

    # Set environment variables based on test parameters
    if traces_endpoint is not None:
        monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", traces_endpoint)
    if otlp_endpoint is not None:
        monkeypatch.setenv("OTEL_EXPORTER_OTLP_ENDPOINT", otlp_endpoint)
    if mlflow_enable is not None:
        monkeypatch.setenv("MLFLOW_ENABLE_OTLP_EXPORTER", mlflow_enable)

    assert should_use_otlp_exporter() is expected


@pytest.mark.parametrize(
    ("endpoint", "protocol", "expected_type"),
    [
        (_TEST_HTTP_OTLP_ENDPOINT, None, GrpcExporter),
        (_TEST_HTTP_OTLP_ENDPOINT, "grpc", GrpcExporter),
        (_TEST_HTTPS_OTLP_ENDPOINT, "grpc", GrpcExporter),
        (_TEST_HTTP_OTLP_ENDPOINT, "http/protobuf", HttpExporter),
        (_TEST_HTTPS_OTLP_ENDPOINT, "http/protobuf", HttpExporter),
    ],
)
def test_get_otlp_exporter_success(endpoint, protocol, expected_type, monkeypatch):
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", endpoint)
    if protocol:
        monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_PROTOCOL", protocol)

    exporter = get_otlp_exporter()
    assert isinstance(exporter, expected_type)

    if isinstance(exporter, GrpcExporter):
        assert exporter._endpoint == "127.0.0.1:4317"
    else:
        assert exporter._endpoint == endpoint


def test_get_otlp_exporter_invalid_protocol(monkeypatch):
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_PROTOCOL", _TEST_HTTP_OTLP_ENDPOINT)

    with pytest.raises(MlflowException, match="Unsupported OTLP protocol"):
        get_otlp_exporter()


@pytest.mark.skipif(is_windows(), reason="Otel collector docker image does not support Windows")
@pytest.mark.parametrize("dual_export", [True, False, None], ids=["enable", "disable", "default"])
def test_export_to_otel_collector(otel_collector, monkeypatch, dual_export):
    if dual_export:
        monkeypatch.setenv("MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT", "true")
    elif dual_export is False:
        monkeypatch.setenv("MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT", "false")

    from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import OTLPSpanExporter

    _, _, port = otel_collector
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", f"http://127.0.0.1:{port}/v1/traces")

    class TestModel:
        @mlflow.trace()
        def predict(self, x, y):
            z = x + y
            z = self.add_one(z)
            z = mlflow.trace(self.square)(z)
            return z  # noqa: RET504

        @mlflow.trace(
            span_type=SpanType.LLM, name="add_one_with_custom_name", attributes={"delta": 1}
        )
        def add_one(self, z):
            return z + 1

        def square(self, t):
            res = t**2
            time.sleep(0.1)
            return res

    model = TestModel()
    model.predict(2, 5)

    # Tracer should be configured to export to OTLP
    exporter = _get_trace_exporter()
    assert isinstance(exporter, OTLPSpanExporter)
    assert exporter._endpoint == f"127.0.0.1:{port}"

    mlflow_traces = get_traces()
    if dual_export:
        assert len(mlflow_traces) == 1
        assert mlflow_traces[0].info.state == "OK"
        assert len(mlflow_traces[0].data.spans) == 3
    else:
        assert len(mlflow_traces) == 0

    # Wait for collector to receive spans, checking every second for up to 60 seconds
    _, output_file, _ = otel_collector
    spans_found = False
    for _ in range(60):
        time.sleep(1)
        with open(output_file) as f:
            collector_logs = f.read()
        # Check if spans are in the logs - the debug exporter outputs span details
        # The BatchSpanProcessor may send spans in multiple batches, so we check for any evidence
        # that the collector is receiving spans from our test
        if (
            "predict" in collector_logs
            and "add_one_with_custom_name" in collector_logs
            and "square" in collector_logs
        ):
            # We found evidence that spans are being exported to the collector
            # The child spans may come in separate batches, but OTLP export works
            spans_found = True
            break

    # Assert that spans were found in collector logs
    assert spans_found, (
        f"Expected spans not found in collector logs after 60 seconds. "
        f"Logs: {collector_logs[:2000]}"
    )


@pytest.mark.skipif(is_windows(), reason="Otel collector docker image does not support Windows")
def test_dual_export_to_mlflow_and_otel(otel_collector, monkeypatch):
    """
    Test that dual export mode sends traces to both MLflow and OTLP collector.
    """
    _, _, port = otel_collector
    monkeypatch.setenv(MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT.name, "true")
    monkeypatch.setenv("OTEL_EXPORTER_OTLP_TRACES_ENDPOINT", f"http://127.0.0.1:{port}/v1/traces")

    experiment = mlflow.set_experiment("dual_export_test")

    processors = _get_tracer("test").span_processor._span_processors
    assert len(processors) == 2
    assert isinstance(processors[0], OtelSpanProcessor)
    assert isinstance(processors[1], MlflowV3SpanProcessor)

    @mlflow.trace(name="parent_span")
    def parent_function():
        result = child_function("Hello", "World")
        return f"Parent: {result}"

    @mlflow.trace(name="child_span")
    def child_function(arg1, arg2):
        # Test that update_current_trace works in dual export mode
        mlflow.update_current_trace({"env": "production", "version": "1.0"})
        return f"{arg1} {arg2}"

    result = parent_function()
    assert result == "Parent: Hello World"

    client = MlflowClient()
    traces = client.search_traces(experiment_ids=[experiment.experiment_id])
    assert len(traces) == 1
    trace = traces[0]
    assert len(trace.data.spans) == 2

    # Verify trace tags were set correctly
    assert "env" in trace.info.tags
    assert trace.info.tags["env"] == "production"
    assert "version" in trace.info.tags
    assert trace.info.tags["version"] == "1.0"

    # Wait for collector to receive spans, checking every second for up to 60 seconds
    _, output_file, _ = otel_collector
    spans_found = False
    for _ in range(60):
        time.sleep(1)
        with open(output_file) as f:
            collector_logs = f.read()
        # Check if spans are in the logs - the debug exporter outputs span details
        # Look for evidence that spans were received
        if "parent_span" in collector_logs or "child_span" in collector_logs:
            # Evidence of traces being exported to OTLP
            spans_found = True
            break

    # Assert that spans were found in collector logs
    assert spans_found, (
        f"Expected spans not found in collector logs after 60 seconds. "
        f"Logs: {collector_logs[:2000]}"
    )
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "find tests -type f | grep -E 'entities.*span|tracing.*span|span.*test' | sort; grep -R -n \"from_otel_proto\\|to_otel_proto\\|to_dict()\\|create_mlflow_span\\|NO_OP_SPAN_TRACE_ID\\|span.attributes\\|span.events\\|from_dict_v2\" tests --include='*.py' | head -400"
```

退出码：`0`

输出：
```
tests/entities/test_span_event.py
tests/entities/test_span_status.py
tests/tracing/otel/test_span_translation.py
tests/langchain/test_langchain_tracer.py:63:    trace_dict = trace.to_dict()
tests/langchain/test_langchain_tracer.py:117:    assert llm_span.events[0].name == "new_token"
tests/langchain/test_langchain_tracer.py:143:    assert llm_span.events[0].name == error_event.name
tests/langchain/test_langchain_tracer.py:144:    assert llm_span.events[0].attributes == error_event.attributes
tests/langchain/test_langchain_tracer.py:309:        MlflowDocument.from_langchain_document(doc).to_dict() for doc in documents
tests/langchain/test_langchain_tracer.py:336:    assert retriever_span.events[0].name == error_event.name
tests/langchain/test_langchain_tracer.py:337:    assert retriever_span.events[0].attributes == error_event.attributes
tests/langchain/test_langchain_tracer.py:441:            ).to_dict()
tests/langchain/test_langchain_databricks_dependency_extraction.py:442:            resource_name = resource.to_dict()[resource_type][0]["name"]
tests/metrics/genai/prompts/test_v1.py:45:    ).to_dict()
tests/metrics/genai/prompts/test_v1.py:157:    ).to_dict()
tests/metrics/genai/prompts/test_v1.py:225:    ).to_dict()
tests/pyfunc/test_spark.py:964:            assert model_input.to_dict() == input_pdf.to_dict()
tests/pyfunc/test_chat_model_validation.py:155:    assert ChatMessage.from_dict(data).to_dict() == data
tests/pyfunc/test_chat_model_validation.py:198:    response = ChatCompletionResponse.from_dict(sample_output).to_dict()
tests/pyfunc/test_chat_model_validation.py:205:    response = ChatCompletionResponse.from_dict(MOCK_RESPONSE).to_dict()
tests/pyfunc/test_pyfunc_schema_enforcement.py:186:    actual_types = res.dtypes.to_dict()
tests/pyfunc/test_pyfunc_schema_enforcement.py:200:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_pyfunc_schema_enforcement.py:207:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_pyfunc_schema_enforcement.py:225:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_pyfunc_schema_enforcement.py:242:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_pyfunc_schema_enforcement.py:276:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_pyfunc_schema_enforcement.py:281:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_pyfunc_schema_enforcement.py:306:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_pyfunc_schema_enforcement.py:338:    assert res.dtypes.to_dict() == expected_types
tests/pyfunc/test_model_export_with_class_and_artifacts.py:1282:    assert model_info.signature.inputs.to_dict() == [
tests/pyfunc/test_model_export_with_class_and_artifacts.py:1285:    assert model_info.signature.outputs.to_dict() == [
tests/pyfunc/test_model_export_with_class_and_artifacts.py:1321:    assert model.signature.inputs.to_dict() == [
tests/pyfunc/test_model_export_with_class_and_artifacts.py:1324:    assert model.signature.outputs.to_dict() == [
tests/pyfunc/test_model_export_with_class_and_artifacts.py:1394:    assert model.signature.inputs.to_dict() == [{"type": "string", "required": True}]
tests/pyfunc/test_model_export_with_class_and_artifacts.py:1395:    assert model.signature.outputs.to_dict() == [{"type": "string", "required": True}]
tests/pyfunc/test_chat_model.py:99:                    "content": json.dumps([m.to_dict() for m in messages]),
tests/pyfunc/test_chat_model.py:107:                    "content": json.dumps(params.to_dict()),
tests/pyfunc/test_chat_model.py:471:        "messages": [message.to_dict() for message in input_example],
tests/pyfunc/test_chat_model.py:608:        .to_dict()
tests/pyfunc/test_chat_model.py:660:    assert pyfunc_model.predict(input_data) == response.to_dict()
tests/pyfunc/test_chat_model.py:661:    assert next(iter(pyfunc_model.predict_stream(input_data))) == chunk_response.to_dict()
tests/ag2/test_ag2_autolog.py:115:    assert llm_span.attributes["cost"] >= 0
tests/tracing/test_otel_loading.py:123:    assert span.attributes["test.string"] == "string-value"
tests/tracing/test_otel_loading.py:124:    assert span.attributes["test.number"] == 42
tests/tracing/test_otel_loading.py:125:    assert span.attributes["test.boolean"] is True
tests/tracing/test_otel_loading.py:126:    assert span.attributes["operation.type"] == "llm_request"
tests/tracing/test_otel_loading.py:169:    assert parent_span.attributes["span.level"] == "parent"
tests/tracing/test_otel_loading.py:172:    assert child_span.attributes["span.level"] == "child"
tests/tracing/test_otel_loading.py:173:    assert child_span.attributes["child.operation"] == "process_data"
tests/tracing/test_otel_loading.py:177:def test_get_trace_with_otel_span_events(mlflow_server: str, is_async):
tests/tracing/test_otel_loading.py:201:    assert len(retrieved_span.events) == 1
tests/tracing/test_otel_loading.py:202:    event = retrieved_span.events[0]
tests/tracing/test_otel_logging.py:216:    # Don't set trace_id - this should cause from_otel_proto to fail
tests/tracing/utils/test_processor.py:48:    assert span.attributes["test_attribute"] == "test_value"
tests/tracing/utils/test_processor.py:69:    assert span.attributes["attr_1"] == "value_1"
tests/tracing/utils/test_processor.py:70:    assert span.attributes["attr_2"] == "value_2"
tests/tracing/utils/test_timeout.py:87:    assert root_span.events[0].name == "exception"
tests/tracing/utils/test_timeout.py:89:        root_span.events[0]
tests/tracing/utils/test_utils.py:321:    span.attributes = {
tests/tracing/utils/test_utils.py:349:    span.attributes = {}
tests/tracing/utils/test_utils.py:358:    span.attributes = Mock()
tests/tracing/utils/test_utils.py:359:    span.attributes.get.return_value = None
tests/tracing/utils/test_utils.py:368:    span.attributes = {
tests/tracing/utils/test_utils.py:383:    span.attributes = {
tests/tracing/test_tracing_client.py:10:from mlflow.entities.span import create_mlflow_span
tests/tracing/test_tracing_client.py:202:    span = create_mlflow_span(otel_span, trace_id, "LLM")
tests/tracing/test_tracing_client.py:218:    assert loaded_span.attributes.get("llm.model_name") == "test-model"
tests/tracing/test_tracing_client.py:219:    assert loaded_span.attributes.get("custom.attribute") == "test-value"
tests/tracing/test_tracing_client.py:250:    span = create_mlflow_span(otel_span, trace_id, "LLM")
tests/tracing/test_fluent.py:226:    assert root_span.attributes == {
tests/tracing/test_fluent.py:301:    assert len(root_span.events) == 9
tests/tracing/test_fluent.py:302:    assert root_span.events[0].name == "mlflow.chunk.item.0"
tests/tracing/test_fluent.py:303:    assert root_span.events[0].attributes == {"mlflow.chunk.value": "0"}
tests/tracing/test_fluent.py:304:    assert root_span.events[8].name == "mlflow.chunk.item.8"
tests/tracing/test_fluent.py:421:    assert root_span.attributes == {
tests/tracing/test_fluent.py:428:    assert root_span.events == []
tests/tracing/test_fluent.py:720:    assert root_span.attributes == {
tests/tracing/test_fluent.py:802:    assert root_span.attributes == {
tests/tracing/test_fluent.py:1050:        assert df.iloc[idx].spans == [s.to_dict() for s in trace.data.spans]
tests/tracing/test_fluent.py:1756:    exception_events = [event for event in test_span.events if "exception" in event.name.lower()]
tests/tracing/test_fluent.py:1780:    exception_events = [event for event in test_span.events if "exception" in event.name.lower()]
tests/tracing/test_fluent.py:1826:    exception_events = [event for event in root_span.events if "exception" in event.name.lower()]
tests/tracing/test_fluent.py:1979:    assert child_span.events == rs.events
tests/tracing/test_fluent.py:1982:        assert child_span.attributes[k] == rs.attributes[k]
tests/tracing/test_fluent.py:2004:    assert child_span.events == rs.events
tests/tracing/test_fluent.py:2008:        assert child_span.attributes[k] == rs.attributes[k]
tests/tracing/test_assessment.py:507:        if span.span_id is not None and span.trace_id != "MLFLOW_NO_OP_SPAN_TRACE_ID":
tests/tracing/export/test_inference_table_exporter.py:116:    assert stored_span.attributes == {
tests/tracing/export/test_uc_table_exporter.py:51:    assert args[0][1][0].to_dict() == span.to_dict()
tests/tracing/processor/test_inference_table_processor.py:88:    assert child_span.attributes.get(SpanAttributeKey.REQUEST_ID) == json.dumps(expected_trace_id)
tests/tracing/processor/test_inference_table_processor.py:141:    # Trace info should be updated according to the span attributes
tests/tracing/processor/test_mlflow_v3_processor.py:37:    assert span.attributes.get(SpanAttributeKey.REQUEST_ID) == json.dumps(request_id)
tests/tracing/processor/test_mlflow_v3_processor.py:45:    assert child_span.attributes.get(SpanAttributeKey.REQUEST_ID) == json.dumps(request_id)
tests/tracing/processor/test_mlflow_v3_processor.py:62:    assert span.attributes.get(SpanAttributeKey.REQUEST_ID) == json.dumps(request_id)
tests/tracing/processor/test_mlflow_v3_processor.py:170:    # Trace info should be updated according to the span attributes
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:22:def test_databricks_evaluation_dataset_source_to_dict():
tests/genai/datasets/test_databricks_evaluation_dataset_source.py:26:    assert source.to_dict() == {
tests/genai/evaluate/test_to_predict_fn.py:61:        "databricks_output": {"trace": sample_rag_trace.to_dict()},
tests/genai/evaluate/test_to_predict_fn.py:148:        "databricks_output": {"trace": sample_rag_trace.to_dict()},
tests/genai/evaluate/test_to_predict_fn.py:250:    trace_dict = sample_rag_trace.to_dict()
tests/genai/evaluate/test_to_predict_fn.py:301:        trace_dict = sample_rag_trace.to_dict()
tests/genai/evaluate/test_to_predict_fn.py:348:        trace_dict = sample_rag_trace.to_dict()
tests/tracking/test_client.py:41:from mlflow.entities.span import create_mlflow_span
tests/tracking/test_client.py:797:    assert root_span.attributes == {
tests/tracking/test_client.py:3460:            create_mlflow_span(otel_span1, trace_id, "LLM"),
tests/tracking/test_client.py:3461:            create_mlflow_span(otel_span2, trace_id, "LLM"),
tests/tracking/test_client.py:3494:        assert parent_span.attributes.get("llm.model_name") == "test-model"
tests/tracking/test_client.py:3495:        assert parent_span.attributes.get("custom.attribute") == "parent-value"
tests/tracking/test_client.py:3503:        assert child_span.attributes.get("operation.type") == "database_query"
tests/tracking/test_client.py:3504:        assert child_span.attributes.get("custom.attribute") == "child-value"
tests/tracking/test_rest_tracking.py:2864:    assert trace_data.spans[0].to_dict() == span.to_dict()
tests/llama_index/test_llama_index_serialization.py:73:    expected_kwargs = {k: v for k, v in o.to_dict().items() if k not in {"class_name", "api_key"}}
tests/llama_index/test_llama_index_serialization.py:81:    expected_kwargs = {k: v for k, v in o.to_dict().items() if k not in {"class_name", "api_key"}}
tests/llama_index/test_llama_index_tracer.py:489:    # Validate span attributes for some key spans
tests/llama_index/test_llama_index_tracer.py:560:    assert tool_span.attributes["name"] == "add"
tests/llama_index/test_llama_index_tracer.py:561:    assert tool_span.attributes["description"] is not None
tests/llama_index/test_llama_index_tracer.py:562:    assert tool_span.attributes["parameters"] is not None
tests/llama_index/test_llama_index_tracer.py:564:    # Validate the chat messages and tool calls are captured in LLM span attributes
tests/haystack/test_haystack_tracing.py:109:    assert span.attributes[SpanAttributeKey.CHAT_USAGE] == {
tests/strands/test_strands_tracing.py:177:    assert SpanAttributeKey.CHAT_USAGE not in agent_span.attributes
tests/strands/test_strands_tracing.py:179:    usage_spans = [span for span in spans if span.attributes.get(SpanAttributeKey.CHAT_USAGE)]
tests/lightgbm/test_lightgbm_autolog.py:651:    assert signature.outputs.to_dict() == [
tests/lightgbm/test_lightgbm_autolog.py:772:            {"mlflow_colspec": _infer_schema(train_set.data).to_dict()}
tests/lightgbm/test_lightgbm_autolog.py:789:        {"mlflow_colspec": _infer_schema(train_set.data).to_dict()}
tests/lightgbm/test_lightgbm_autolog.py:793:        {"mlflow_colspec": _infer_schema(valid_set.data).to_dict()}
tests/openai/test_openai_model_export.py:145:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_model_export.py:149:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:187:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_model_export.py:191:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:223:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_model_export.py:227:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:265:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_model_export.py:269:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:307:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_model_export.py:310:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:378:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_model_export.py:381:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:510:    assert model.signature.inputs.to_dict() == [{"type": "string", "required": True}]
tests/openai/test_openai_model_export.py:511:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:640:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_model_export.py:644:    assert model.signature.outputs.to_dict() == [
tests/openai/test_openai_model_export.py:703:    assert model.signature.inputs.to_dict() == [
tests/openai/test_openai_responses_autolog.py:60:    assert span.attributes["model"] == "gpt-4o"
tests/openai/test_openai_responses_autolog.py:61:    assert span.attributes["temperature"] == 0
tests/openai/test_openai_responses_autolog.py:121:    assert span.attributes[SpanAttributeKey.CHAT_TOOLS] == [
tests/openai/test_openai_responses_autolog.py:150:    assert span.attributes[SpanAttributeKey.CHAT_TOOLS] == [
tests/openai/test_openai_responses_autolog.py:249:    assert span.attributes[SpanAttributeKey.CHAT_TOOLS] == [
tests/openai/test_openai_responses_autolog.py:252:    assert span.attributes[SpanAttributeKey.MESSAGE_FORMAT] == "openai"
tests/openai/test_openai_responses_autolog.py:288:    assert span.attributes["model"] == "gpt-4o"
tests/openai/test_openai_responses_autolog.py:289:    assert span.attributes["stream"] is True
tests/openai/test_openai_autolog.py:117:    assert span.attributes["model"] == "gpt-4o-mini"
tests/openai/test_openai_autolog.py:118:    assert span.attributes["temperature"] == 0
tests/openai/test_openai_autolog.py:269:    assert span.events[0].name == "exception"
tests/openai/test_openai_autolog.py:270:    assert span.events[0].attributes["exception.type"] == "UnprocessableEntityError"
tests/openai/test_openai_autolog.py:320:    assert parent_span.events[0].name == "exception"
tests/openai/test_openai_autolog.py:321:    assert parent_span.events[0].attributes["exception.type"] == "mlflow.exceptions.MlflowException"
tests/openai/test_openai_autolog.py:322:    assert parent_span.events[0].attributes["exception.message"] == "Failed to create completions"
tests/openai/test_openai_autolog.py:329:    assert child_span.events[0].name == "exception"
tests/openai/test_openai_autolog.py:330:    assert child_span.events[0].attributes["exception.type"] == "UnprocessableEntityError"
tests/openai/test_openai_autolog.py:563:    assert span.attributes[SpanAttributeKey.CHAT_TOOLS] == MOCK_TOOLS
tests/openai/test_openai_autolog.py:606:    assert span.attributes[SpanAttributeKey.CHAT_TOOLS] == MOCK_TOOLS
tests/openai/test_openai_autolog.py:891:        OutputItem(**chunk1.item.to_dict()),
tests/openai/test_openai_autolog.py:892:        OutputItem(**chunk2.item.to_dict()),
tests/types/test_schema.py:58:    a4 = ColSpec(**a1.to_dict())
tests/types/test_schema.py:60:    assert ColSpec(**json.loads(json.dumps(a1.to_dict()))) == a1
tests/types/test_schema.py:64:    assert ColSpec(**json.loads(json.dumps(a5.to_dict()))) == a5
tests/types/test_schema.py:87:    a5 = TensorSpec.from_json_dict(**a1.to_dict())
tests/types/test_schema.py:89:    assert TensorSpec.from_json_dict(**json.loads(json.dumps(a1.to_dict()))) == a1
tests/types/test_schema.py:93:    assert TensorSpec.from_json_dict(**json.loads(json.dumps(a6.to_dict()))) == a6
tests/types/test_schema.py:478:        recreated_spec = TensorSpec.from_json_dict(**spec.to_dict())
tests/types/test_schema.py:837:    assert spec.to_dict() == {
tests/types/test_schema.py:843:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:846:    assert spec.to_dict() == {
tests/types/test_schema.py:852:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:855:    assert spec.to_dict() == {
tests/types/test_schema.py:861:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:864:    assert spec.to_dict() == {
tests/types/test_schema.py:870:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:873:    assert spec.to_dict() == {
tests/types/test_schema.py:879:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:882:    assert spec.to_dict() == {
tests/types/test_schema.py:888:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:891:    assert spec.to_dict() == {
tests/types/test_schema.py:897:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:900:    assert spec.to_dict() == {
tests/types/test_schema.py:906:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:909:    assert spec.to_dict() == {
tests/types/test_schema.py:915:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:918:    assert spec.to_dict() == {
tests/types/test_schema.py:924:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:927:    assert spec.to_dict() == {
tests/types/test_schema.py:933:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:936:    assert spec.to_dict() == {
tests/types/test_schema.py:942:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:947:    assert spec.to_dict() == {
tests/types/test_schema.py:953:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:961:    assert spec.to_dict() == {
tests/types/test_schema.py:967:    assert ParamSpec.from_json_dict(**json.loads(json.dumps(spec.to_dict()))) == spec
tests/types/test_schema.py:1104:    assert schema.to_dict() == [
tests/types/test_schema.py:1110:        | object_schema.to_dict()
tests/types/test_schema.py:1112:    assert ParamSchema.from_json(json.dumps(schema.to_dict())) == schema
tests/types/test_schema.py:1151:    assert prop.to_dict() == {"data": {"type": data_type.name, "required": True}}
tests/types/test_schema.py:1152:    assert Property.from_json_dict(**json.loads(json.dumps(prop.to_dict()))) == prop
tests/types/test_schema.py:1156:    assert prop.to_dict() == {
tests/types/test_schema.py:1163:    assert Property.from_json_dict(**json.loads(json.dumps(prop.to_dict()))) == prop
tests/types/test_schema.py:1167:    assert prop.to_dict() == {
tests/types/test_schema.py:1174:    assert Property.from_json_dict(**json.loads(json.dumps(prop.to_dict()))) == prop
tests/types/test_schema.py:1253:    assert obj.to_dict() == {
tests/types/test_schema.py:1257:    assert Object.from_json_dict(**json.loads(json.dumps(obj.to_dict()))) == obj
tests/types/test_schema.py:1291:    assert arr.to_dict() == {"type": "array", "items": {"type": data_type.name}}
tests/types/test_schema.py:1292:    assert Array.from_json_dict(**json.loads(json.dumps(arr.to_dict()))) == arr
tests/types/test_schema.py:1296:    assert arr.to_dict() == {
tests/types/test_schema.py:1303:    assert Array.from_json_dict(**json.loads(json.dumps(arr.to_dict()))) == arr
tests/types/test_schema.py:1356:    assert arr.to_dict() == {
tests/types/test_schema.py:1380:    assert Array.from_json_dict(**json.loads(json.dumps(arr.to_dict()))) == arr
tests/types/test_schema.py:1390:    obj1_dict = obj1.to_dict()
tests/types/test_schema.py:1397:    obj2_dict = obj2.to_dict()
tests/types/test_schema.py:1406:    assert obj1.to_dict() == obj1_dict
tests/types/test_schema.py:1407:    assert obj2.to_dict() == obj2_dict
tests/types/test_schema.py:1415:    prop1_dict = prop1.to_dict()
tests/types/test_schema.py:1425:    prop2_dict = prop2.to_dict()
tests/types/test_schema.py:1436:    assert prop1.to_dict() == prop1_dict
tests/types/test_schema.py:1437:    assert prop2.to_dict() == prop2_dict
tests/types/test_schema.py:1536:    assert schema.to_dict() == [
tests/types/test_schema.py:1551:    assert Schema.from_json(json.dumps(schema.to_dict())) == schema
tests/types/test_schema.py:1585:    assert schema.to_dict() == [
tests/types/test_schema.py:1605:    assert Schema.from_json(json.dumps(schema.to_dict())) == schema
tests/types/test_schema.py:1785:    schema_dict = schema.to_dict()
tests/types/test_schema.py:1802:    schema_dict = schema.to_dict()
tests/types/test_schema.py:1849:    schema_dict = schema.to_dict()
tests/transformers/test_transformers_model_export.py:223:    assert model_provided_card.data.to_dict()["tags"] == ["vision", "image-classification"]
tests/transformers/test_transformers_model_export.py:1519:    inference_dict = inference.to_dict()
tests/transformers/test_transformers_model_export.py:1759:    assert len(values.to_dict()) == 2
tests/transformers/test_transformers_model_export.py:1760:    assert len(values.to_dict()["score"]) == 5
tests/transformers/test_transformers_model_export.py:1773:    assert len(values.to_dict()) == 2
tests/transformers/test_transformers_model_export.py:1774:    assert len(values.to_dict()["score"]) == 1
tests/transformers/test_transformers_model_export.py:1799:    values_dict = values.to_dict()
tests/transformers/test_transformers_model_export.py:1841:    assert len(values.to_dict()) == 3
tests/transformers/test_transformers_model_export.py:1842:    assert len(values.to_dict()["labels"]) == 2
tests/transformers/test_transformers_model_export.py:1865:    assert len(values.to_dict()) == 3
tests/transformers/test_transformers_model_export.py:1866:    assert len(values.to_dict()["labels"]) == 6
tests/transformers/test_transformers_model_export.py:2660:    custom_data = card_data.data.to_dict()
tests/transformers/test_transformers_model_export.py:2669:    assert data == card_data.data.to_dict()
tests/xgboost/test_xgboost_autolog.py:639:    assert ("saved_input_example_info" in model_conf.to_dict()) == log_input_examples
tests/xgboost/test_xgboost_autolog.py:640:    assert ("signature" in model_conf.to_dict()) == log_model_signatures
tests/entities/test_trace_info.py:62:    trace_info_dict = trace_info.to_dict()
tests/entities/test_trace_info.py:143:    dict_trace_info_v4 = trace_info_v4.to_dict()
tests/entities/test_trace_info.py:235:    dict_trace_info = trace_info.to_dict()
tests/entities/test_trace_info.py:353:    dict_v4 = trace_info_v4.to_dict()
tests/entities/test_trace_info.py:365:    dict_regular = trace_info.to_dict()
tests/entities/test_trace_info_v2.py:90:    trace_as_dict = trace_info.to_dict()
tests/entities/test_trace_info_v2.py:127:    trace_info_as_dict = trace_info.to_dict()
tests/entities/test_dataset_record_source.py:177:    data = source.to_dict()
tests/entities/test_span_event.py:25:def test_span_event_to_otel_proto_conversion(event_attrs):
tests/entities/test_span_event.py:34:    otel_proto_event = event.to_otel_proto()
tests/entities/test_trace_data.py:37:    trace_data_dict = trace_data.to_dict()
tests/entities/test_trace_data.py:152:    assert trace_data.to_dict() == trace_data_from_dict.to_dict()
tests/entities/test_trace_data.py:207:def test_to_dict():
tests/entities/test_trace_data.py:211:    trace_dict = trace.data.to_dict()
tests/entities/test_dataset_record.py:199:    data = record.to_dict()
tests/entities/test_dataset_record.py:475:    data = record.to_dict()
tests/entities/test_evaluation_dataset.py:175:    data = dataset.to_dict()
tests/entities/test_evaluation_dataset.py:218:    data = dataset.to_dict()
tests/entities/test_evaluation_dataset.py:298:    data = dataset.to_dict()
tests/entities/test_trace.py:230:    trace_dict = trace.to_dict()
tests/entities/test_trace.py:482:    assert trace_from_proto.to_dict() == trace.to_dict()
tests/entities/test_span_status.py:91:    mlflow_status = SpanStatus.from_otel_proto_status(proto_status)
tests/entities/test_span_status.py:104:def test_mlflow_status_to_otel_proto_status_conversion(
tests/entities/test_span_status.py:112:    proto_status = mlflow_status.to_otel_proto_status()
tests/sklearn/test_sklearn_autolog.py:1035:    assert "signature" not in model_conf.to_dict()
tests/sklearn/test_sklearn_autolog.py:1036:    assert "saved_input_example_info" not in model_conf.to_dict()
tests/sklearn/test_sklearn_autolog.py:1052:    assert "signature" not in model_conf.to_dict()
tests/sklearn/test_sklearn_autolog.py:1073:    assert "signature" not in model_conf.to_dict()
tests/sklearn/test_sklearn_autolog.py:1090:    assert "signature" not in model_conf.to_dict()
tests/sklearn/test_sklearn_autolog.py:1109:    assert "signature" in model_conf.to_dict()
tests/sklearn/test_sklearn_autolog.py:1124:    assert ("saved_input_example_info" in model_conf.to_dict()) == log_input_examples
tests/sklearn/test_sklearn_autolog.py:1125:    assert ("signature" in model_conf.to_dict()) == log_model_signatures
tests/models/test_display_utils.py:27:).to_dict()
tests/models/test_display_utils.py:38:).to_dict()
tests/models/test_model.py:243:        assert model_signature.to_dict() == sig.to_dict()
tests/models/test_model.py:461:    m_dict = m.to_dict()
tests/models/test_resources.py:28:    assert endpoint.to_dict() == expected
tests/models/test_resources.py:43:    assert index.to_dict() == expected
tests/models/test_resources.py:58:    assert sql_warehouse.to_dict() == expected
tests/models/test_resources.py:73:    assert uc_function.to_dict() == expected
tests/models/test_resources.py:89:    assert genie_space.to_dict() == expected
tests/models/test_resources.py:108:    assert uc_function.to_dict() == expected
tests/models/test_resources.py:124:    assert table.to_dict() == expected
tests/models/test_resources.py:139:    assert app.to_dict() == expected
tests/models/test_resources.py:156:    assert lakebase.to_dict() == expected
tests/models/test_dependencies_schema.py:29:def test_retriever_to_dict():
tests/models/test_dependencies_schema.py:48:    assert vsi.to_dict() == expected_dict
tests/models/test_dependencies_schema.py:67:def test_dependencies_schemas_to_dict():
tests/models/test_dependencies_schema.py:89:    assert schema.to_dict() == expected_dict
tests/models/test_dependencies_schema.py:100:        assert schema.to_dict()["dependencies_schemas"] == {
tests/models/test_dependencies_schema.py:114:        assert schema.to_dict() is None
tests/models/test_dependencies_schema.py:127:        assert schema.to_dict()["dependencies_schemas"] == {
tests/models/test_dependencies_schema.py:141:        assert schema.to_dict() is None
tests/models/test_dependencies_schema.py:147:        assert schema.to_dict() is None
tests/models/test_dependencies_schema.py:167:        assert schema.to_dict()["dependencies_schemas"] == {
tests/models/test_dependencies_schema.py:188:        assert schema.to_dict() is None
tests/models/test_dependencies_schema.py:222:        assert schema.to_dict()["dependencies_schemas"] == {
tests/models/test_dependencies_schema.py:269:        assert schema.to_dict()["dependencies_schemas"] == {
tests/models/test_model_config.py:79:def test_config_development_config_to_dict():
tests/models/test_model_config.py:81:    assert config.to_dict() == {"llm_parameters": {"temperature": 0.01}}
tests/models/test_model_config.py:84:    assert config.to_dict() == {
tests/models/test_signature.py:49:    as_json = json.dumps(signature1.to_dict())
tests/models/test_signature.py:55:    as_json = json.dumps(signature5.to_dict())
tests/models/test_signature.py:82:    as_json = json.dumps(signature1.to_dict())
tests/models/test_signature.py:112:    as_json = json.dumps(signature8.to_dict())
tests/models/test_signature.py:259:    assert signature.to_dict() == {
tests/models/test_signature.py:266:    assert signature.to_dict() == {
tests/models/test_signature.py:273:    assert signature.to_dict() == {
tests/models/test_signature.py:298:    signature_dict = signature.to_dict()
tests/models/test_signature.py:368:        schema for schema in inferred_signature.inputs.to_dict() if schema["name"] == "custom_input"
tests/models/test_signature.py:373:        schema for schema in inferred_signature.inputs.to_dict() if schema["name"] == "messages"
tests/models/test_auth_policy.py:32:    serialized_auth_policy = auth_policy.to_dict()
tests/models/test_auth_policy.py:68:    serialized_auth_policy = auth_policy.to_dict()
tests/models/test_auth_policy.py:95:    serialized_auth_policy = auth_policy.to_dict()
tests/models/test_auth_policy.py:117:    serialized_auth_policy = auth_policy.to_dict()
tests/sentence_transformers/test_sentence_transformers_model_export.py:351:    assert default_signature.to_dict() == expected_signature
tests/data/test_meta_dataset.py:63:    assert json.loads(parsed_json["schema"])["mlflow_colspec"] == schema.to_dict()
tests/data/test_delta_dataset_source.py:39:    assert delta_datasource.to_dict()["path"] == path
tests/data/test_delta_dataset_source.py:59:    assert delta_datasource.to_dict()["delta_table_name"] == "temp_delta"
tests/data/test_delta_dataset_source.py:87:    config = delta_datasource.to_dict()
tests/data/test_code_dataset_source.py:10:    assert code_datasource.to_dict() == {
tests/bedrock/test_bedrock_autolog.py:24:        assert SpanAttributeKey.CHAT_USAGE not in span.attributes, (
tests/bedrock/test_bedrock_autolog.py:25:            f"Expected no usage but found: {span.attributes.get(SpanAttributeKey.CHAT_USAGE)}"
tests/bedrock/test_bedrock_autolog.py:28:        usage = span.attributes.get(SpanAttributeKey.CHAT_USAGE)
tests/bedrock/test_bedrock_autolog.py:312:    assert len(span.events) == 1
tests/bedrock/test_bedrock_autolog.py:313:    assert span.events[0].name == "exception"
tests/bedrock/test_bedrock_autolog.py:314:    assert span.events[0].attributes["exception.message"].startswith("Unable to locate credentials")
tests/bedrock/test_bedrock_autolog.py:395:    # Raw chunks must be recorded as span events
tests/bedrock/test_bedrock_autolog.py:396:    assert len(span.events) == len(dummy_chunks)
tests/bedrock/test_bedrock_autolog.py:398:        assert span.events[i].name == dummy_chunks[i]["type"]
tests/bedrock/test_bedrock_autolog.py:399:        assert json.loads(span.events[i].attributes["json"]) == dummy_chunks[i]
tests/bedrock/test_bedrock_autolog.py:402:    assert SpanAttributeKey.CHAT_USAGE in span.attributes
tests/bedrock/test_bedrock_autolog.py:403:    usage = span.attributes[SpanAttributeKey.CHAT_USAGE]
tests/bedrock/test_bedrock_autolog.py:802:    assert len(span.events) == 1
tests/bedrock/test_bedrock_autolog.py:883:    assert len(span.events) > 0
tests/bedrock/test_bedrock_autolog.py:884:    assert span.events[0].name == "messageStart"
tests/bedrock/test_bedrock_autolog.py:885:    assert json.loads(span.events[0].attributes["json"]) == {"role": "assistant"}
tests/resources/mlflow-test-plugin/mlflow_test_plugin/dummy_dataset.py:44:            "schema": json.dumps({"mlflow_colspec": self.schema.to_dict()}),
tests/resources/data/dataset.py:44:        config = super().to_dict()
tests/resources/data/dataset.py:47:                "schema": json.dumps({"mlflow_colspec": self.schema.to_dict()}),
tests/semantic_kernel/test_semantic_kernel_autolog.py:244:    assert "sk.available_functions" in child_span.attributes
tests/semantic_kernel/test_semantic_kernel_autolog.py:290:    assert llm_span.events[0].name == "exception"
tests/semantic_kernel/test_semantic_kernel_autolog.py:291:    assert error_message in llm_span.events[0].attributes["exception.message"]
tests/agno/test_agno_tracing.py:173:    assert span.attributes["entrypoint"] is not None
tests/agno/test_agno_tracing.py:194:    assert span.attributes["entrypoint"] is not None
tests/diviner/test_diviner_model_export.py:86:        for value in diviner_data.df[diviner_data.key_columns].iloc[[i]].to_dict().values():
tests/store/tracking/test_databricks_rest_store.py:74:    mock_span1.to_otel_proto.return_value = otel_span1
tests/store/tracking/test_databricks_rest_store.py:78:    mock_span2.to_otel_proto.return_value = otel_span2
tests/store/tracking/test_sqlalchemy_store.py:49:from mlflow.entities.span import Span, create_mlflow_span
tests/store/tracking/test_sqlalchemy_store.py:205:    return create_mlflow_span(otel_span, trace_id, span_type)
tests/store/tracking/test_sqlalchemy_store.py:5144:    return create_mlflow_span(otel_span, trace_id, span_type)
tests/store/tracking/test_sqlalchemy_store.py:5350:def test_search_traces_with_span_attributes_filter(store: SqlAlchemyStore):
tests/store/tracking/test_sqlalchemy_store.py:5351:    exp_id = store.create_experiment("test_span_attributes_search")
tests/store/tracking/test_sqlalchemy_store.py:5391:    traces, _ = store.search_traces([exp_id], filter_string='span.attributes.model LIKE "%gpt-4%"')
tests/store/tracking/test_sqlalchemy_store.py:5396:        [exp_id], filter_string='span.attributes.temperature LIKE "%0.7%"'
tests/store/tracking/test_sqlalchemy_store.py:5402:        [exp_id], filter_string='span.attributes.provider LIKE "%anthropic%"'
tests/store/tracking/test_sqlalchemy_store.py:5408:        [exp_id], filter_string='span.attributes.database LIKE "%pinecone%"'
tests/store/tracking/test_sqlalchemy_store.py:5414:        [exp_id], filter_string='span.attributes.nonexistent LIKE "%value%"'
tests/store/tracking/test_sqlalchemy_store.py:5419:        [exp_id], filter_string='span.attributes.similarity.threshold LIKE "%0.8%"'
tests/store/tracking/test_sqlalchemy_store.py:6341:def test_search_traces_with_span_attributes_rlike_filters(store: SqlAlchemyStore):
tests/store/tracking/test_sqlalchemy_store.py:6342:    exp_id = store.create_experiment("test_span_attributes_rlike")
tests/store/tracking/test_sqlalchemy_store.py:6389:    traces, _ = store.search_traces([exp_id], filter_string='span.attributes.model RLIKE "^gpt"')
tests/store/tracking/test_sqlalchemy_store.py:6393:    traces, _ = store.search_traces([exp_id], filter_string='span.attributes.model RLIKE "^claude"')
tests/store/tracking/test_sqlalchemy_store.py:6398:        [exp_id], filter_string='span.attributes.model RLIKE "(preview|[0-9]{8})"'
tests/store/tracking/test_sqlalchemy_store.py:6404:        [exp_id], filter_string='span.attributes.provider RLIKE "^openai"'
tests/store/tracking/test_sqlalchemy_store.py:6409:    traces, _ = store.search_traces([exp_id], filter_string='span.attributes.model RLIKE "turbo"')
tests/store/tracking/test_sqlalchemy_store.py:7027:    span = create_mlflow_span(readable_span, trace_info.trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:7100:    span1 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:7120:    span2 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:7176:    span = create_mlflow_span(readable_span, trace_id)
tests/store/tracking/test_sqlalchemy_store.py:7243:    span = create_mlflow_span(readable_span, trace_id)
tests/store/tracking/test_sqlalchemy_store.py:7294:    span1 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:7325:    span2 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:7356:    span3 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:7395:    span1 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:7426:    span2 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:7457:    span3 = create_mlflow_span(
tests/store/tracking/test_sqlalchemy_store.py:9855:    child_span = create_mlflow_span(child_otel_span, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:9903:    root_span = create_mlflow_span(root_otel_span, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:9937:    root_span = create_mlflow_span(root_unset_span, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:9973:    child_span = create_mlflow_span(child_otel_span, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:9995:    root_span = create_mlflow_span(root_otel_span, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:10930:    span = create_mlflow_span(otel_span, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:10944:    assert loaded_span.attributes.get("llm.model_name") == "gpt-4"
tests/store/tracking/test_sqlalchemy_store.py:10945:    assert loaded_span.attributes.get("llm.input_tokens") == 100
tests/store/tracking/test_sqlalchemy_store.py:10946:    assert loaded_span.attributes.get("llm.output_tokens") == 50
tests/store/tracking/test_sqlalchemy_store.py:10947:    assert loaded_span.attributes.get("custom.key") == "custom_value"
tests/store/tracking/test_sqlalchemy_store.py:10995:    trace_1_spans = [span.to_dict() for span in loaded_spans_1]
tests/store/tracking/test_sqlalchemy_store.py:10996:    trace_2_spans = [span.to_dict() for span in loaded_spans_2]
tests/store/tracking/test_sqlalchemy_store.py:10998:    assert [span.to_dict() for span in loaded_spans_1] == trace_1_spans
tests/store/tracking/test_sqlalchemy_store.py:10999:    assert [span.to_dict() for span in loaded_spans_2] == trace_2_spans
tests/store/tracking/test_sqlalchemy_store.py:11146:    span = create_mlflow_span(otel_span, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:11189:    span1 = create_mlflow_span(otel_span1, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:11217:    span2 = create_mlflow_span(otel_span2, trace_id, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:11250:    span1 = create_mlflow_span(otel_span1, trace_id_1, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:11272:    span2 = create_mlflow_span(otel_span2, trace_id_2, "LLM")
tests/store/tracking/test_sqlalchemy_store.py:11287:    span3 = create_mlflow_span(otel_span3, trace_id_3, "UNKNOWN")
tests/store/tracking/__init__.py:27:            tags=[RunTag(MLFLOW_LOGGED_MODELS, json.dumps([m.to_dict()]))],
tests/store/tracking/__init__.py:38:            tags=[RunTag(MLFLOW_LOGGED_MODELS, json.dumps([m.to_dict(), m2.to_dict()]))],
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,280p' mlflow/entities/span_event.py; sed -n '1,280p' mlflow/entities/span_status.py; sed -n '1,280p' mlflow/entities/trace_data.py; sed -n '1,320p' mlflow/entities/trace.py; grep -R -n \"set_request_response_preview\\|request_preview\\|response_preview\" mlflow/entities mlflow/tracing | head -100"
```

退出码：`0`

输出：
```
import json
import time
import traceback
from dataclasses import dataclass, field
from datetime import datetime

from opentelemetry.util.types import AttributeValue

from mlflow.entities._mlflow_object import _MlflowObject
from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue


@dataclass
class SpanEvent(_MlflowObject):
    """
    An event that records a specific occurrences or moments in time
    during a span, such as an exception being thrown. Compatible with OpenTelemetry.

    Args:
        name: Name of the event.
        timestamp:  The exact time the event occurred, measured in nanoseconds.
            If not provided, the current time will be used.
        attributes: A collection of key-value pairs representing detailed
            attributes of the event, such as the exception stack trace.
            Attributes value must be one of ``[str, int, float, bool, bytes]``
            or a sequence of these types.
    """

    name: str
    # Use current time if not provided. We need to use default factory otherwise
    # the default value will be fixed to the build time of the class.
    timestamp: int = field(default_factory=lambda: int(time.time() * 1e6))
    attributes: dict[str, AttributeValue] = field(default_factory=dict)

    @classmethod
    def from_exception(cls, exception: Exception):
        "Create a span event from an exception."

        stack_trace = cls._get_stacktrace(exception)
        return cls(
            name="exception",
            attributes={
                "exception.message": str(exception),
                "exception.type": exception.__class__.__name__,
                "exception.stacktrace": stack_trace,
            },
        )

    @staticmethod
    def _get_stacktrace(error: BaseException) -> str:
        """Get the stacktrace of the parent error."""
        msg = repr(error)
        try:
            tb = traceback.format_exception(error)
            return "".join(tb).strip()
        except Exception:
            return msg

    def json(self):
        return {
            "name": self.name,
            "timestamp": self.timestamp,
            "attributes": json.dumps(self.attributes, cls=CustomEncoder)
            if self.attributes
            else None,
        }

    def to_otel_proto(self):
        """
        Convert to OpenTelemetry protobuf event format for OTLP export.
        This is an internal method used for logging spans via OTel protocol.

        Returns:
            An OpenTelemetry protobuf Span.Event message.
        """
        from opentelemetry.proto.trace.v1.trace_pb2 import Span

        otel_event = Span.Event()
        otel_event.name = self.name
        otel_event.time_unix_nano = self.timestamp

        for key, value in self.attributes.items():
            attr = otel_event.attributes.add()
            attr.key = key
            _set_otel_proto_anyvalue(attr.value, value)

        return otel_event


class CustomEncoder(json.JSONEncoder):
    """
    Custom encoder to handle json serialization.
    """

    def default(self, o):
        try:
            return super().default(o)
        except TypeError:
            # convert datetime to string format by default
            if isinstance(o, datetime):
                return o.isoformat()
            # convert object direct to string to avoid error in serialization
            return str(o)
from __future__ import annotations

from dataclasses import dataclass
from enum import Enum

from opentelemetry import trace as trace_api
from opentelemetry.proto.trace.v1.trace_pb2 import Status as OtelStatus

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE


class SpanStatusCode(str, Enum):
    """Enum for status code of a span"""

    # Uses the same set of status codes as OpenTelemetry
    UNSET = "UNSET"
    OK = "OK"
    ERROR = "ERROR"

    def to_otel_proto_status_code_name(self) -> str:
        """
        Convert the SpanStatusCode to the corresponding OpenTelemetry protobuf enum name.
        """
        proto_code = OtelStatus.StatusCode
        mapping = {
            SpanStatusCode.UNSET: proto_code.Name(proto_code.STATUS_CODE_UNSET),
            SpanStatusCode.OK: proto_code.Name(proto_code.STATUS_CODE_OK),
            SpanStatusCode.ERROR: proto_code.Name(proto_code.STATUS_CODE_ERROR),
        }
        return mapping[self]

    @staticmethod
    def from_otel_proto_status_code_name(status_code_name: str) -> SpanStatusCode:
        """
        Convert an OpenTelemetry protobuf enum name to the corresponding SpanStatusCode enum value.
        """
        proto_code = OtelStatus.StatusCode
        mapping = {
            proto_code.Name(proto_code.STATUS_CODE_UNSET): SpanStatusCode.UNSET,
            proto_code.Name(proto_code.STATUS_CODE_OK): SpanStatusCode.OK,
            proto_code.Name(proto_code.STATUS_CODE_ERROR): SpanStatusCode.ERROR,
        }
        try:
            return mapping[status_code_name]
        except KeyError:
            raise MlflowException(
                f"Invalid status code name: {status_code_name}. "
                f"Valid values are: {', '.join(mapping.keys())}",
                error_code=INVALID_PARAMETER_VALUE,
            )


@dataclass
class SpanStatus:
    """
    Status of the span or the trace.

    Args:
        status_code: The status code of the span or the trace. This must be one of the
            values of the :py:class:`mlflow.entities.SpanStatusCode` enum or a string
            representation of it like "OK", "ERROR".
        description: Description of the status. This should be only set when the status
            is ERROR, otherwise it will be ignored.
    """

    status_code: SpanStatusCode
    description: str = ""

    def __post_init__(self):
        """
        If user provides a string status code, validate it and convert to
        the corresponding enum value.
        """
        if isinstance(self.status_code, str):
            try:
                self.status_code = SpanStatusCode(self.status_code)
            except ValueError:
                raise MlflowException(
                    f"{self.status_code} is not a valid SpanStatusCode value. "
                    f"Please use one of {[status_code.value for status_code in SpanStatusCode]}",
                    error_code=INVALID_PARAMETER_VALUE,
                )


















































    @classmethod
    def from_otel_proto_status(cls, otel_proto_status) -> SpanStatus:
        """
        Create a SpanStatus from an OpenTelemetry protobuf Status.

        :meta private:
        """
        # Map protobuf status codes to SpanStatusCode
        if otel_proto_status.code == OtelStatus.STATUS_CODE_OK:
            status_code = SpanStatusCode.OK
        elif otel_proto_status.code == OtelStatus.STATUS_CODE_ERROR:
            status_code = SpanStatusCode.ERROR
        else:
            status_code = SpanStatusCode.UNSET

        return cls(status_code, otel_proto_status.message or "")from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from mlflow.entities import Span
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.utils.annotations import deprecated


@dataclass
class TraceData:
    """A container object that holds the spans data of a trace.

    Args:
        spans: List of spans that are part of the trace.
    """

    spans: list[Span] = field(default_factory=list)

    # NB: Custom constructor to allow passing additional kwargs for backward compatibility for
    # DBX agent evaluator. Once they migrates to trace V3 schema, we can remove this.
    def __init__(self, spans: list[Span] | None = None, **kwargs):
        self.spans = spans or []

    @classmethod
    def from_dict(cls, d):
        if not isinstance(d, dict):
            raise TypeError(f"TraceData.from_dict() expects a dictionary. Got: {type(d).__name__}")
        return cls(spans=[Span.from_dict(span) for span in d.get("spans", [])])

    def to_dict(self) -> dict[str, Any]:
        return {"spans": [span.to_dict() for span in self.spans]}

    # TODO: remove this property in 3.7.0
    @property
    @deprecated(since="3.6.0", alternative="trace.search_spans(name=...)")
    def intermediate_outputs(self) -> dict[str, Any] | None:
        """
        .. deprecated:: 3.6.0
            Use `trace.search_spans(name=...)` to search for spans and get the outputs.

        Returns intermediate outputs produced by the model or agent while handling the request.
        There are mainly two flows to return intermediate outputs:
        1. When a trace is generate by the `mlflow.log_trace` API,
        return `intermediate_outputs` attribute of the span.
        2. When a trace is created normally with a tree of spans,
        aggregate the outputs of non-root spans.
        """
        root_span = self._get_root_span()
        if root_span and root_span.get_attribute(SpanAttributeKey.INTERMEDIATE_OUTPUTS):
            return root_span.get_attribute(SpanAttributeKey.INTERMEDIATE_OUTPUTS)

        if len(self.spans) > 1:
            result = {}
            # spans may have duplicate names, so deduplicate the names by appending an index number.
            span_name_counter = Counter(span.name for span in self.spans)
            span_name_counter = {name: 1 for name, count in span_name_counter.items() if count > 1}
            for span in self.spans:
                span_name = span.name
                if count := span_name_counter.get(span_name):
                    span_name_counter[span_name] += 1
                    span_name = f"{span_name}_{count}"
                if span.parent_id and span.outputs is not None:
                    result[span_name] = span.outputs
            return result

    def _get_root_span(self) -> Span | None:
        for span in self.spans:
            if span.parent_id is None:
                return span

    # `request` and `response` are preserved for backward compatibility with v2

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any, Literal

from mlflow.entities._mlflow_object import _MlflowObject
from mlflow.entities.span import Span, SpanType
from mlflow.entities.trace_data import TraceData
from mlflow.entities.trace_info import TraceInfo
from mlflow.entities.trace_info_v2 import TraceInfoV2
from mlflow.environment_variables import MLFLOW_TRACING_SQL_WAREHOUSE_ID
from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.protos.service_pb2 import Trace as ProtoTrace

if TYPE_CHECKING:
    from mlflow.entities.assessment import Assessment

_logger = logging.getLogger(__name__)


@dataclass
class Trace(_MlflowObject):
    """A trace object.

    Args:
        info: A lightweight object that contains the metadata of a trace.
        data: A container object that holds the spans data of a trace.
    """

    info: TraceInfo
    data: TraceData

    def __post_init__(self):
        if isinstance(self.info, TraceInfoV2):
            self.info = self.info.to_v3(request=self.data.request, response=self.data.response)

    def __repr__(self) -> str:
        return f"Trace(trace_id={self.info.trace_id})"

    def to_dict(self) -> dict[str, Any]:
        return {"info": self.info.to_dict(), "data": self.data.to_dict()}

    def to_json(self, pretty=False) -> str:
        from mlflow.tracing.utils import TraceJSONEncoder

        return json.dumps(self.to_dict(), cls=TraceJSONEncoder, indent=2 if pretty else None)

    @classmethod
    def from_dict(cls, trace_dict: dict[str, Any]) -> Trace:
        info = trace_dict.get("info")
        data = trace_dict.get("data")
        if info is None or data is None:
            raise MlflowException(
                "Unable to parse Trace from dictionary. Expected keys: 'info' and 'data'. "
                f"Received keys: {list(trace_dict.keys())}",
                error_code=INVALID_PARAMETER_VALUE,
            )

        return cls(
            info=TraceInfo.from_dict(info),
            data=TraceData.from_dict(data),
        )

    @classmethod
    def from_json(cls, trace_json: str) -> Trace:
        try:
            trace_dict = json.loads(trace_json)
        except json.JSONDecodeError as e:
            raise MlflowException(
                f"Unable to parse trace JSON: {trace_json}. Error: {e}",
                error_code=INVALID_PARAMETER_VALUE,
            )
        return cls.from_dict(trace_dict)

    def _serialize_for_mimebundle(self):
        # databricks notebooks will use the trace ID to
        # fetch the trace from the backend. including the
        # full JSON can cause notebooks to exceed size limits
        return json.dumps(
            {
                "trace_id": self.info.trace_id,
                # TODO: remove this once sql_warehouse_id
                # is optional in the v4 tracing APIs
                "sql_warehouse_id": MLFLOW_TRACING_SQL_WAREHOUSE_ID.get(),
            }
        )

    def _repr_mimebundle_(self, include=None, exclude=None):
        """
        This method is used to trigger custom display logic in IPython notebooks.
        See https://ipython.readthedocs.io/en/stable/config/integrating.html#MyObject
        for more details.

        At the moment, the only supported MIME type is "application/databricks.mlflow.trace",
        which contains a JSON representation of the Trace object. This object is deserialized
        in Databricks notebooks to display the Trace object in a nicer UI.
        """
        from mlflow.tracing.display import (
            get_display_handler,
            get_notebook_iframe_html,
            is_using_tracking_server,
        )
        from mlflow.utils.databricks_utils import is_in_databricks_runtime

        bundle = {"text/plain": repr(self)}

        if not get_display_handler().disabled:
            if is_in_databricks_runtime():
                bundle["application/databricks.mlflow.trace"] = self._serialize_for_mimebundle()
            elif is_using_tracking_server():
                bundle["text/html"] = get_notebook_iframe_html([self])

        return bundle

    def to_pandas_dataframe_row(self) -> dict[str, Any]:
        return {
            "trace_id": self.info.trace_id,
            "trace": self.to_json(),  # json string to be compatible with Spark DataFrame
            "client_request_id": self.info.client_request_id,
            "state": self.info.state,
            "request_time": self.info.request_time,
            "execution_duration": self.info.execution_duration,
            "request": self._deserialize_json_attr(self.data.request),
            "response": self._deserialize_json_attr(self.data.response),
            "trace_metadata": self.info.trace_metadata,
            "tags": self.info.tags,
            "spans": [span.to_dict() for span in self.data.spans],
            "assessments": [assessment.to_dictionary() for assessment in self.info.assessments],
        }

    def _deserialize_json_attr(self, value: str):
        try:
            return json.loads(value)
        except Exception:
            _logger.debug(f"Failed to deserialize JSON attribute: {value}", exc_info=True)
            return value

    def search_spans(
        self,
        span_type: SpanType | None = None,
        name: str | re.Pattern | None = None,
        span_id: str | None = None,
    ) -> list[Span]:
        """
        Search for spans that match the given criteria within the trace.

        Args:
            span_type: The type of the span to search for.
            name: The name of the span to search for. This can be a string or a regular expression.
            span_id: The ID of the span to search for.

        Returns:
            A list of spans that match the given criteria.
            If there is no match, an empty list is returned.

        .. code-block:: python

            import mlflow
            import re
            from mlflow.entities import SpanType


            @mlflow.trace(span_type=SpanType.CHAIN)
            def run(x: int) -> int:
                x = add_one(x)
                x = add_two(x)
                x = multiply_by_two(x)
                return x


            @mlflow.trace(span_type=SpanType.TOOL)
            def add_one(x: int) -> int:
                return x + 1


            @mlflow.trace(span_type=SpanType.TOOL)
            def add_two(x: int) -> int:
                return x + 2


            @mlflow.trace(span_type=SpanType.TOOL)
            def multiply_by_two(x: int) -> int:
                return x * 2


            # Run the function and get the trace
            y = run(2)
            trace_id = mlflow.get_last_active_trace_id()
            trace = mlflow.get_trace(trace_id)

            # 1. Search spans by name (exact match)
            spans = trace.search_spans(name="add_one")
            print(spans)
            # Output: [Span(name='add_one', ...)]

            # 2. Search spans by name (regular expression)
            pattern = re.compile(r"add.*")
            spans = trace.search_spans(name=pattern)
            print(spans)
            # Output: [Span(name='add_one', ...), Span(name='add_two', ...)]

            # 3. Search spans by type
            spans = trace.search_spans(span_type=SpanType.LLM)
            print(spans)
            # Output: [Span(name='run', ...)]

            # 4. Search spans by name and type
            spans = trace.search_spans(name="add_one", span_type=SpanType.TOOL)
            print(spans)
            # Output: [Span(name='add_one', ...)]
        """

        def _match_name(span: Span) -> bool:
            if isinstance(name, str):
                return span.name == name
            elif isinstance(name, re.Pattern):
                return name.search(span.name) is not None
            elif name is None:
                return True
            else:
                raise MlflowException(
                    f"Invalid type for 'name'. Expected str or re.Pattern. Got: {type(name)}",
                    error_code=INVALID_PARAMETER_VALUE,
                )

        def _match_type(span: Span) -> bool:
            if isinstance(span_type, str):
                return span.span_type == span_type
            elif span_type is None:
                return True
            else:
                raise MlflowException(
                    "Invalid type for 'span_type'. Expected str or mlflow.entities.SpanType. "
                    f"Got: {type(span_type)}",
                    error_code=INVALID_PARAMETER_VALUE,
                )

        def _match_id(span: Span) -> bool:
            if span_id is None:
                return True
            else:
                return span.span_id == span_id

        return [
            span
            for span in self.data.spans
            if _match_name(span) and _match_type(span) and _match_id(span)
        ]

    def search_assessments(
        self,
        name: str | None = None,
        *,
        span_id: str | None = None,
        all: bool = False,
        type: Literal["expectation", "feedback"] | None = None,
    ) -> list["Assessment"]:
        """
        Get assessments for a given name / span ID. By default, this only returns assessments
        that are valid (i.e. have not been overridden by another assessment). To return all
        assessments, specify `all=True`.

        Args:
            name: The name of the assessment to get. If not provided, this will match
                all assessment names.
            span_id: The span ID to get assessments for.
                If not provided, this will match all spans.
            all: If True, return all assessments regardless of validity.
            type: The type of assessment to get (one of "feedback" or "expectation").
                If not provided, this will match all assessment types.

        Returns:
            A list of assessments that meet the given conditions.
        """

        def validate_type(assessment: Assessment) -> bool:
            from mlflow.entities.assessment import Expectation, Feedback

            if type == "expectation":
                return isinstance(assessment, Expectation)
            elif type == "feedback":
                return isinstance(assessment, Feedback)

            return True

        return [
            assessment
            for assessment in self.info.assessments
            if (name is None or assessment.name == name)
            and (span_id is None or assessment.span_id == span_id)
            # valid defaults to true, so Nones are valid
            and (all or assessment.valid in (True, None))
            and (type is None or validate_type(assessment))
        ]

    @staticmethod
    def pandas_dataframe_columns() -> list[str]:
        return [
            "trace_id",
            "trace",
            "client_request_id",
            "state",
            "request_time",
            "execution_duration",
            "request",
            "response",
            "trace_metadata",
            "tags",
            "spans",
            "assessments",
        ]

    def to_proto(self):
        """
        Convert into a proto object to sent to the MLflow backend.
        """
mlflow/entities/trace_info.py:31:        request_preview: Request to the model/agent, equivalent to the input of the root,
mlflow/entities/trace_info.py:33:        response_preview: Response from the model/agent, equivalent to the output of the
mlflow/entities/trace_info.py:50:    request_preview: str | None = None
mlflow/entities/trace_info.py:51:    response_preview: str | None = None
mlflow/entities/trace_info.py:116:            request_preview=self.request_preview,
mlflow/entities/trace_info.py:117:            response_preview=self.response_preview,
mlflow/entities/trace_info.py:152:            request_preview=proto.request_preview if proto.HasField("request_preview") else None,
mlflow/entities/trace_info.py:153:            response_preview=proto.response_preview if proto.HasField("response_preview") else None,
mlflow/entities/trace_info_v2.py:138:            request_preview=request,
mlflow/entities/trace_info_v2.py:139:            response_preview=response,
mlflow/tracing/fluent.py:1012:    request_preview: str | None = None,
mlflow/tracing/fluent.py:1013:    response_preview: str | None = None,
mlflow/tracing/fluent.py:1029:        request_preview: A preview of the request to be shown in the Trace list view in the UI.
mlflow/tracing/fluent.py:1032:        response_preview: A preview of the response to be shown in the Trace list view in the UI.
mlflow/tracing/fluent.py:1091:                mlflow.update_current_trace(request_preview=custom_preview)
mlflow/tracing/fluent.py:1145:    if request_preview is not None and not isinstance(request_preview, str):
mlflow/tracing/fluent.py:1147:            "The `request_preview` parameter must be a string."
mlflow/tracing/fluent.py:1149:    if response_preview is not None and not isinstance(response_preview, str):
mlflow/tracing/fluent.py:1151:            "The `response_preview` parameter must be a string."
mlflow/tracing/fluent.py:1159:        if request_preview:
mlflow/tracing/fluent.py:1160:            trace.info.request_preview = request_preview
mlflow/tracing/fluent.py:1161:        if response_preview:
mlflow/tracing/fluent.py:1162:            trace.info.response_preview = response_preview
```

## 原始行 24 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"def .*preview\\|set.*preview\\|truncate.*preview\" mlflow/tracing mlflow/entities | head -100; sed -n '1,230p' mlflow/entities/trace_info.py; grep -n \"def to_otel_status\\|def to_otel_proto_status\" -B3 -A18 mlflow/entities/span_status.py; sed -n '1,280p' tests/entities/test_trace_data.py"
```

退出码：`0`

输出：
```
import json
from dataclasses import dataclass, field
from typing import Any

from google.protobuf.duration_pb2 import Duration
from google.protobuf.json_format import MessageToDict
from google.protobuf.timestamp_pb2 import Timestamp

from mlflow.entities._mlflow_object import _MlflowObject
from mlflow.entities.assessment import Assessment
from mlflow.entities.trace_location import TraceLocation
from mlflow.entities.trace_state import TraceState
from mlflow.entities.trace_status import TraceStatus
from mlflow.protos.databricks_tracing_pb2 import TraceInfo as ProtoTraceInfoV4
from mlflow.protos.service_pb2 import TraceInfoV3 as ProtoTraceInfoV3
from mlflow.tracing.constant import TraceMetadataKey


@dataclass
class TraceInfo(_MlflowObject):
    """Metadata about a trace, such as its ID, location, timestamp, etc.

    Args:
        trace_id: The primary identifier for the trace.
        trace_location: The location where the trace is stored, represented as
            a :py:class:`~mlflow.entities.TraceLocation` object. MLflow currently
            support MLflow Experiment or Databricks Inference Table as a trace location.
        request_time: Start time of the trace, in milliseconds.
        state: State of the trace, represented as a :py:class:`~mlflow.entities.TraceState`
            enum. Can be one of [`OK`, `ERROR`, `IN_PROGRESS`, `STATE_UNSPECIFIED`].
        request_preview: Request to the model/agent, equivalent to the input of the root,
            span but JSON-encoded and can be truncated.
        response_preview: Response from the model/agent, equivalent to the output of the
            root span but JSON-encoded and can be truncated.
        client_request_id: Client supplied request ID associated with the trace. This
            could be used to identify the trace/request from an external system that
            produced the trace, e.g., a session ID in a web application.
        execution_duration: Duration of the trace, in milliseconds.
        trace_metadata: Key-value pairs associated with the trace. They are designed
            for immutable values like run ID associated with the trace.
        tags: Tags associated with the trace. They are designed for mutable values,
            that can be updated after the trace is created via MLflow UI or API.
        assessments: List of assessments associated with the trace.
    """

    trace_id: str
    trace_location: TraceLocation
    request_time: int
    state: TraceState
    request_preview: str | None = None
    response_preview: str | None = None
    client_request_id: str | None = None
    execution_duration: int | None = None
    trace_metadata: dict[str, str] = field(default_factory=dict)
    tags: dict[str, str] = field(default_factory=dict)
    assessments: list[Assessment] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Convert the TraceInfoV3 object to a dictionary."""
        res = MessageToDict(self.to_proto(), preserving_proto_field_name=True)
        if self.execution_duration is not None:
            res.pop("execution_duration", None)
            res["execution_duration_ms"] = self.execution_duration
        # override trace_id to be the same as trace_info.trace_id since it's parsed
        # when converting to proto if it's v4
        res["trace_id"] = self.trace_id
        return res

    @classmethod
    def from_dict(cls, d: dict[str, Any]) -> "TraceInfo":
        """Create a TraceInfoV3 object from a dictionary."""
        if "request_id" in d:
            from mlflow.entities.trace_info_v2 import TraceInfoV2

            return TraceInfoV2.from_dict(d).to_v3()

        d = d.copy()
        if assessments := d.get("assessments"):
            d["assessments"] = [Assessment.from_dictionary(a) for a in assessments]

        if trace_location := d.get("trace_location"):
            d["trace_location"] = TraceLocation.from_dict(trace_location)

        if state := d.get("state"):
            d["state"] = TraceState(state)

        if request_time := d.get("request_time"):
            timestamp = Timestamp()
            timestamp.FromJsonString(request_time)
            d["request_time"] = timestamp.ToMilliseconds()

        if (execution_duration := d.pop("execution_duration_ms", None)) is not None:
            d["execution_duration"] = execution_duration

        return cls(**d)

    def to_proto(self) -> ProtoTraceInfoV3 | ProtoTraceInfoV4:
        from mlflow.entities.trace_info_v2 import _truncate_request_metadata, _truncate_tags

        if self._is_v4():
            from mlflow.utils.databricks_tracing_utils import trace_info_to_v4_proto

            return trace_info_to_v4_proto(self)

        request_time = Timestamp()
        request_time.FromMilliseconds(self.request_time)
        execution_duration = None
        if self.execution_duration is not None:
            execution_duration = Duration()
            execution_duration.FromMilliseconds(self.execution_duration)

        return ProtoTraceInfoV3(
            trace_id=self.trace_id,
            client_request_id=self.client_request_id,
            trace_location=self.trace_location.to_proto(),
            request_preview=self.request_preview,
            response_preview=self.response_preview,
            request_time=request_time,
            execution_duration=execution_duration,
            state=self.state.to_proto(),
            trace_metadata=_truncate_request_metadata(self.trace_metadata),
            tags=_truncate_tags(self.tags),
            assessments=[a.to_proto() for a in self.assessments],
        )

    @classmethod
    def from_proto(cls, proto) -> "TraceInfo":
        if "request_id" in proto.DESCRIPTOR.fields_by_name:
            from mlflow.entities.trace_info_v2 import TraceInfoV2

            return TraceInfoV2.from_proto(proto).to_v3()

        # import inside the function to avoid introducing top-level dependency on
        # mlflow.tracing.utils in entities module
        from mlflow.tracing.utils import construct_trace_id_v4

        trace_location = TraceLocation.from_proto(proto.trace_location)
        if trace_location.uc_schema:
            trace_id = construct_trace_id_v4(
                location=f"{trace_location.uc_schema.catalog_name}.{trace_location.uc_schema.schema_name}",
                trace_id=proto.trace_id,
            )
        else:
            trace_id = proto.trace_id

        return cls(
            trace_id=trace_id,
            client_request_id=(
                proto.client_request_id if proto.HasField("client_request_id") else None
            ),
            trace_location=trace_location,
            request_preview=proto.request_preview if proto.HasField("request_preview") else None,
            response_preview=proto.response_preview if proto.HasField("response_preview") else None,
            request_time=proto.request_time.ToMilliseconds(),
            execution_duration=(
                proto.execution_duration.ToMilliseconds()
                if proto.HasField("execution_duration")
                else None
            ),
            state=TraceState.from_proto(proto.state),
            trace_metadata=dict(proto.trace_metadata),
            tags=dict(proto.tags),
            assessments=[Assessment.from_proto(a) for a in proto.assessments],
        )

    # Aliases for backward compatibility with V2 format
    @property
    def request_id(self) -> str:
        """Deprecated. Use `trace_id` instead."""
        return self.trace_id

    @property
    def experiment_id(self) -> str | None:
        """
        An MLflow experiment ID associated with the trace, if the trace is stored
        in MLflow tracking server. Otherwise, None.
        """
        return (
            self.trace_location.mlflow_experiment
            and self.trace_location.mlflow_experiment.experiment_id
        )

    @experiment_id.setter
    def experiment_id(self, value: str | None) -> None:
        self.trace_location.mlflow_experiment.experiment_id = value

    @property
    def request_metadata(self) -> dict[str, str]:
        """Deprecated. Use `trace_metadata` instead."""
        return self.trace_metadata

    @property
    def timestamp_ms(self) -> int:
        return self.request_time

    @timestamp_ms.setter
    def timestamp_ms(self, value: int) -> None:
        self.request_time = value

    @property
    def execution_time_ms(self) -> int | None:
        return self.execution_duration

    @execution_time_ms.setter
    def execution_time_ms(self, value: int | None) -> None:
        self.execution_duration = value

    @property
    def status(self) -> TraceStatus:
        """Deprecated. Use `state` instead."""
        return TraceStatus.from_state(self.state)

    @status.setter
    def status(self, value: TraceStatus) -> None:
        self.state = value.to_state()

    @property
    def token_usage(self) -> dict[str, int] | None:
        """
        Returns the aggregated token usage for the trace.

        Returns:
            A dictionary containing the aggregated LLM token usage for the trace.
            - "input_tokens": The total number of input tokens.
            - "output_tokens": The total number of output tokens.
            - "total_tokens": Sum of input and output tokens.

        .. note::

            The token usage tracking is not supported for all LLM providers.
18-    OK = "OK"
19-    ERROR = "ERROR"
20-
21:    def to_otel_proto_status_code_name(self) -> str:
22-        """
23-        Convert the SpanStatusCode to the corresponding OpenTelemetry protobuf enum name.
24-        """
25-        proto_code = OtelStatus.StatusCode
26-        mapping = {
27-            SpanStatusCode.UNSET: proto_code.Name(proto_code.STATUS_CODE_UNSET),
28-            SpanStatusCode.OK: proto_code.Name(proto_code.STATUS_CODE_OK),
29-            SpanStatusCode.ERROR: proto_code.Name(proto_code.STATUS_CODE_ERROR),
30-        }
31-        return mapping[self]
32-
33-    @staticmethod
34-    def from_otel_proto_status_code_name(status_code_name: str) -> SpanStatusCode:
35-        """
36-        Convert an OpenTelemetry protobuf enum name to the corresponding SpanStatusCode enum value.
37-        """
38-        proto_code = OtelStatus.StatusCode
39-        mapping = {
import json
from unittest import mock

import pytest

import mlflow
from mlflow.entities import SpanType, TraceData
from mlflow.entities.span_event import SpanEvent


def test_json_deserialization():
    class TestModel:
        @mlflow.trace()
        def predict(self, x, y):
            z = x + y

            with mlflow.start_span(name="with_ok_event") as span:
                span.add_event(SpanEvent(name="ok_event", attributes={"foo": "bar"}))

            self.always_fail()
            return z

        @mlflow.trace(span_type=SpanType.LLM, name="always_fail_name", attributes={"delta": 1})
        def always_fail(self):
            raise Exception("Error!")

    model = TestModel()

    # Verify the exception is not absorbed by the context manager
    with pytest.raises(Exception, match="Error!"):
        model.predict(2, 5)

    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())
    trace_data = trace.data

    # Compare events separately as it includes exception stacktrace which is hard to hardcode
    trace_data_dict = trace_data.to_dict()
    span_to_events = {span["name"]: span.get("events") for span in trace_data_dict["spans"]}

    assert trace_data_dict == {
        "spans": [
            {
                "name": "predict",
                "trace_id": mock.ANY,
                "span_id": mock.ANY,
                "parent_span_id": None,
                "start_time_unix_nano": trace.data.spans[0].start_time_ns,
                "end_time_unix_nano": trace.data.spans[0].end_time_ns,
                "status": {
                    "code": "STATUS_CODE_ERROR",
                    "message": "Exception: Error!",
                },
                "attributes": {
                    "mlflow.traceRequestId": json.dumps(trace.info.trace_id),
                    "mlflow.spanType": '"UNKNOWN"',
                    "mlflow.spanFunctionName": '"predict"',
                    "mlflow.spanInputs": '{"x": 2, "y": 5}',
                },
                "events": [
                    {
                        "name": "exception",
                        "time_unix_nano": trace.data.spans[0].events[0].timestamp,
                        "attributes": {
                            "exception.message": "Error!",
                            "exception.type": "Exception",
                            "exception.stacktrace": mock.ANY,
                            "exception.escaped": "False",
                        },
                    }
                ],
            },
            {
                "name": "with_ok_event",
                "trace_id": mock.ANY,
                "span_id": mock.ANY,
                "parent_span_id": mock.ANY,
                "start_time_unix_nano": trace.data.spans[1].start_time_ns,
                "end_time_unix_nano": trace.data.spans[1].end_time_ns,
                "status": {
                    "code": "STATUS_CODE_OK",
                    "message": "",
                },
                "attributes": {
                    "mlflow.traceRequestId": json.dumps(trace.info.trace_id),
                    "mlflow.spanType": '"UNKNOWN"',
                },
                "events": [
                    {
                        "name": "ok_event",
                        "time_unix_nano": trace.data.spans[1].events[0].timestamp,
                        "attributes": {"foo": "bar"},
                    }
                ],
            },
            {
                "name": "always_fail_name",
                "trace_id": mock.ANY,
                "span_id": mock.ANY,
                "parent_span_id": mock.ANY,
                "start_time_unix_nano": trace.data.spans[2].start_time_ns,
                "end_time_unix_nano": trace.data.spans[2].end_time_ns,
                "status": {
                    "code": "STATUS_CODE_ERROR",
                    "message": "Exception: Error!",
                },
                "attributes": {
                    "delta": "1",
                    "mlflow.traceRequestId": json.dumps(trace.info.trace_id),
                    "mlflow.spanType": '"LLM"',
                    "mlflow.spanFunctionName": '"always_fail"',
                    "mlflow.spanInputs": "{}",
                },
                "events": [
                    {
                        "name": "exception",
                        "time_unix_nano": trace.data.spans[2].events[0].timestamp,
                        "attributes": {
                            "exception.message": "Error!",
                            "exception.type": "Exception",
                            "exception.stacktrace": mock.ANY,
                            "exception.escaped": "False",
                        },
                    }
                ],
            },
        ],
    }

    ok_events = span_to_events["with_ok_event"]
    assert len(ok_events) == 1
    assert ok_events[0]["name"] == "ok_event"
    assert ok_events[0]["attributes"] == {"foo": "bar"}

    error_events = span_to_events["always_fail_name"]
    assert len(error_events) == 1
    assert error_events[0]["name"] == "exception"
    assert error_events[0]["attributes"]["exception.message"] == "Error!"
    assert error_events[0]["attributes"]["exception.type"] == "Exception"
    assert error_events[0]["attributes"]["exception.stacktrace"] is not None

    parent_events = span_to_events["predict"]
    assert len(parent_events) == 1
    assert parent_events[0]["name"] == "exception"
    assert parent_events[0]["attributes"]["exception.message"] == "Error!"
    assert parent_events[0]["attributes"]["exception.type"] == "Exception"
    # Parent span includes exception event bubbled up from the child span, hence the
    # stack trace includes the function call
    assert "self.always_fail()" in parent_events[0]["attributes"]["exception.stacktrace"]

    # Convert back from dict to TraceData and compare
    trace_data_from_dict = TraceData.from_dict(trace_data_dict)
    assert trace_data.to_dict() == trace_data_from_dict.to_dict()


def test_intermediate_outputs_from_attribute():
    intermediate_outputs = {
        "retrieved_documents": ["document 1", "document 2"],
        "generative_prompt": "prompt",
    }

    def run():
        with mlflow.start_span(name="run") as span:
            span.set_attribute("mlflow.trace.intermediate_outputs", intermediate_outputs)

    run()
    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())

    assert trace.data.intermediate_outputs == intermediate_outputs


def test_intermediate_outputs_from_spans():
    @mlflow.trace()
    def retrieved_documents():
        return ["document 1", "document 2"]

    @mlflow.trace()
    def llm(i):
        return f"Hi, this is LLM {i}"

    @mlflow.trace()
    def predict():
        retrieved_documents()
        llm(1)
        llm(2)

    predict()
    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())

    assert trace.data.intermediate_outputs == {
        "retrieved_documents": ["document 1", "document 2"],
        "llm_1": "Hi, this is LLM 1",
        "llm_2": "Hi, this is LLM 2",
    }


def test_intermediate_outputs_no_value():
    def run():
        with mlflow.start_span(name="run") as span:
            span.set_outputs(1)

    run()
    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())

    assert trace.data.intermediate_outputs is None


def test_to_dict():
    with mlflow.start_span():
        pass
    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())
    trace_dict = trace.data.to_dict()
    assert len(trace_dict["spans"]) == 1
    # Ensure the legacy properties are not present
    assert "request" not in trace_dict
    assert "response" not in trace_dict


def test_request_and_response_are_still_available():
    with mlflow.start_span() as s:
        s.set_inputs("foo")
        s.set_outputs("bar")

    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())
    trace_data = trace.data
    assert trace_data.request == '"foo"'
    assert trace_data.response == '"bar"'

    with mlflow.start_span():
        pass

    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())
    trace_data = trace.data
    assert trace_data.request is None
    assert trace_data.response is None
```

## 原始行 27 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/entities/span_status.py; tail -80 mlflow/entities/trace_data.py; grep -R -n \"_is_span_v2_schema\\|from_dict_v2\\|_decode_id_from_byte\\|_is_base64_encoded\" mlflow --exclude=span.py; grep -R -n \"def set_request_response_preview\\|request_preview =\\|response_preview =\" mlflow | head -100"
```

退出码：`0`

输出：
```
     1	from __future__ import annotations
     2	
     3	from dataclasses import dataclass
     4	from enum import Enum
     5	
     6	from opentelemetry import trace as trace_api
     7	from opentelemetry.proto.trace.v1.trace_pb2 import Status as OtelStatus
     8	
     9	from mlflow.exceptions import MlflowException
    10	from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
    11	
    12	
    13	class SpanStatusCode(str, Enum):
    14	    """Enum for status code of a span"""
    15	
    16	    # Uses the same set of status codes as OpenTelemetry
    17	    UNSET = "UNSET"
    18	    OK = "OK"
    19	    ERROR = "ERROR"
    20	
    21	    def to_otel_proto_status_code_name(self) -> str:
    22	        """
    23	        Convert the SpanStatusCode to the corresponding OpenTelemetry protobuf enum name.
    24	        """
    25	        proto_code = OtelStatus.StatusCode
    26	        mapping = {
    27	            SpanStatusCode.UNSET: proto_code.Name(proto_code.STATUS_CODE_UNSET),
    28	            SpanStatusCode.OK: proto_code.Name(proto_code.STATUS_CODE_OK),
    29	            SpanStatusCode.ERROR: proto_code.Name(proto_code.STATUS_CODE_ERROR),
    30	        }
    31	        return mapping[self]
    32	
    33	    @staticmethod
    34	    def from_otel_proto_status_code_name(status_code_name: str) -> SpanStatusCode:
    35	        """
    36	        Convert an OpenTelemetry protobuf enum name to the corresponding SpanStatusCode enum value.
    37	        """
    38	        proto_code = OtelStatus.StatusCode
    39	        mapping = {
    40	            proto_code.Name(proto_code.STATUS_CODE_UNSET): SpanStatusCode.UNSET,
    41	            proto_code.Name(proto_code.STATUS_CODE_OK): SpanStatusCode.OK,
    42	            proto_code.Name(proto_code.STATUS_CODE_ERROR): SpanStatusCode.ERROR,
    43	        }
    44	        try:
    45	            return mapping[status_code_name]
    46	        except KeyError:
    47	            raise MlflowException(
    48	                f"Invalid status code name: {status_code_name}. "
    49	                f"Valid values are: {', '.join(mapping.keys())}",
    50	                error_code=INVALID_PARAMETER_VALUE,
    51	            )
    52	
    53	
    54	@dataclass
    55	class SpanStatus:
    56	    """
    57	    Status of the span or the trace.
    58	
    59	    Args:
    60	        status_code: The status code of the span or the trace. This must be one of the
    61	            values of the :py:class:`mlflow.entities.SpanStatusCode` enum or a string
    62	            representation of it like "OK", "ERROR".
    63	        description: Description of the status. This should be only set when the status
    64	            is ERROR, otherwise it will be ignored.
    65	    """
    66	
    67	    status_code: SpanStatusCode
    68	    description: str = ""
    69	
    70	    def __post_init__(self):
    71	        """
    72	        If user provides a string status code, validate it and convert to
    73	        the corresponding enum value.
    74	        """
    75	        if isinstance(self.status_code, str):
    76	            try:
    77	                self.status_code = SpanStatusCode(self.status_code)
    78	            except ValueError:
    79	                raise MlflowException(
    80	                    f"{self.status_code} is not a valid SpanStatusCode value. "
    81	                    f"Please use one of {[status_code.value for status_code in SpanStatusCode]}",
    82	                    error_code=INVALID_PARAMETER_VALUE,
    83	                )
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	    @classmethod
   135	    def from_otel_proto_status(cls, otel_proto_status) -> SpanStatus:
   136	        """
   137	        Create a SpanStatus from an OpenTelemetry protobuf Status.
   138	
   139	        :meta private:
   140	        """
   141	        # Map protobuf status codes to SpanStatusCode
   142	        if otel_proto_status.code == OtelStatus.STATUS_CODE_OK:
   143	            status_code = SpanStatusCode.OK
   144	        elif otel_proto_status.code == OtelStatus.STATUS_CODE_ERROR:
   145	            status_code = SpanStatusCode.ERROR
   146	        else:
   147	            status_code = SpanStatusCode.UNSET
   148	
   149	        return cls(status_code, otel_proto_status.message or "")
from collections import Counter
from dataclasses import dataclass, field
from typing import Any

from mlflow.entities import Span
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.utils.annotations import deprecated


@dataclass
class TraceData:
    """A container object that holds the spans data of a trace.

    Args:
        spans: List of spans that are part of the trace.
    """

    spans: list[Span] = field(default_factory=list)

    # NB: Custom constructor to allow passing additional kwargs for backward compatibility for
    # DBX agent evaluator. Once they migrates to trace V3 schema, we can remove this.
    def __init__(self, spans: list[Span] | None = None, **kwargs):
        self.spans = spans or []

    @classmethod
    def from_dict(cls, d):
        if not isinstance(d, dict):
            raise TypeError(f"TraceData.from_dict() expects a dictionary. Got: {type(d).__name__}")
        return cls(spans=[Span.from_dict(span) for span in d.get("spans", [])])

    def to_dict(self) -> dict[str, Any]:
        return {"spans": [span.to_dict() for span in self.spans]}

    # TODO: remove this property in 3.7.0
    @property
    @deprecated(since="3.6.0", alternative="trace.search_spans(name=...)")
    def intermediate_outputs(self) -> dict[str, Any] | None:
        """
        .. deprecated:: 3.6.0
            Use `trace.search_spans(name=...)` to search for spans and get the outputs.

        Returns intermediate outputs produced by the model or agent while handling the request.
        There are mainly two flows to return intermediate outputs:
        1. When a trace is generate by the `mlflow.log_trace` API,
        return `intermediate_outputs` attribute of the span.
        2. When a trace is created normally with a tree of spans,
        aggregate the outputs of non-root spans.
        """
        root_span = self._get_root_span()
        if root_span and root_span.get_attribute(SpanAttributeKey.INTERMEDIATE_OUTPUTS):
            return root_span.get_attribute(SpanAttributeKey.INTERMEDIATE_OUTPUTS)

        if len(self.spans) > 1:
            result = {}
            # spans may have duplicate names, so deduplicate the names by appending an index number.
            span_name_counter = Counter(span.name for span in self.spans)
            span_name_counter = {name: 1 for name, count in span_name_counter.items() if count > 1}
            for span in self.spans:
                span_name = span.name
                if count := span_name_counter.get(span_name):
                    span_name_counter[span_name] += 1
                    span_name = f"{span_name}_{count}"
                if span.parent_id and span.outputs is not None:
                    result[span_name] = span.outputs
            return result

    def _get_root_span(self) -> Span | None:
        for span in self.spans:
            if span.parent_id is None:
                return span

    # `request` and `response` are preserved for backward compatibility with v2

mlflow/tracing/fluent.py:1160:            trace.info.request_preview = request_preview
mlflow/tracing/fluent.py:1162:            trace.info.response_preview = response_preview
mlflow/protos/databricks_tracing.proto:347:  optional string request_preview = 4;
mlflow/protos/databricks_tracing.proto:351:  optional string response_preview = 5;
mlflow/protos/service.proto:2858:  optional string request_preview = 12;
mlflow/protos/service.proto:2862:  optional string response_preview = 13;
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:115229:     * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:115239:     * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:115249:     * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:115261:     * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:115271:     * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:115281:     * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:116184:     * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:116197:     * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:116221:     * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:116247:     * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:116260:     * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:116284:     * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:117966:       * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:117978:       * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118001:       * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118023:       * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118043:       * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118058:       * <code>optional string request_preview = 12;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118080:       * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118092:       * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118115:       * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118137:       * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118157:       * <code>optional string response_preview = 13;</code>
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:118172:       * <code>optional string response_preview = 13;</code>
mlflow/claude_code/tracing.py:602:                    in_memory_trace.info.request_preview = user_prompt_text[:MAX_PREVIEW_LENGTH]
mlflow/claude_code/tracing.py:604:                    in_memory_trace.info.response_preview = final_response[:MAX_PREVIEW_LENGTH]
mlflow/store/tracking/dbmodels/models.py:706:    request_preview = Column(String(1000), nullable=True)
mlflow/store/tracking/dbmodels/models.py:710:    response_preview = Column(String(1000), nullable=True)
```

## 原始行 30 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"MAX.*PREVIEW\\|TRACE.*PREVIEW\\|preview\" mlflow/tracing | head -150; grep -R -n \"\\.request\\|def request\\|def response\" mlflow/entities/trace_data.py tests/entities/test_trace_data.py | tail -60; grep -R -n \"from_otel_proto(\" mlflow tests --include='*.py'; grep -R -n \"to_otel_proto()\" mlflow tests --include='*.py' | grep -E 'span|Span' | head -100; sed -n '1,300p' tests/tracing/test_otel_loading.py; sed -n '1,280p' tests/tracing/test_otel_logging.py"
```

退出码：`0`

输出：
```
mlflow/tracing/utils/truncation.py:8:    TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_DBX,
mlflow/tracing/utils/truncation.py:9:    TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_OSS,
mlflow/tracing/fluent.py:1012:    request_preview: str | None = None,
mlflow/tracing/fluent.py:1013:    response_preview: str | None = None,
mlflow/tracing/fluent.py:1029:        request_preview: A preview of the request to be shown in the Trace list view in the UI.
mlflow/tracing/fluent.py:1031:            This parameter allows you to specify a custom preview string.
mlflow/tracing/fluent.py:1032:        response_preview: A preview of the response to be shown in the Trace list view in the UI.
mlflow/tracing/fluent.py:1034:            This parameter allows you to specify a custom preview string.
mlflow/tracing/fluent.py:1079:        Updating request preview:
mlflow/tracing/fluent.py:1089:                # Customize the request preview to show the first and last messages
mlflow/tracing/fluent.py:1090:                custom_preview = f"{messages[0]['content'][:10]} ... {messages[-1]['content'][:10]}"
mlflow/tracing/fluent.py:1091:                mlflow.update_current_trace(request_preview=custom_preview)
mlflow/tracing/fluent.py:1111:            # The request preview rendered in the UI will be:
mlflow/tracing/fluent.py:1145:    if request_preview is not None and not isinstance(request_preview, str):
mlflow/tracing/fluent.py:1147:            "The `request_preview` parameter must be a string."
mlflow/tracing/fluent.py:1149:    if response_preview is not None and not isinstance(response_preview, str):
mlflow/tracing/fluent.py:1151:            "The `response_preview` parameter must be a string."
mlflow/tracing/fluent.py:1159:        if request_preview:
mlflow/tracing/fluent.py:1160:            trace.info.request_preview = request_preview
mlflow/tracing/fluent.py:1161:        if response_preview:
mlflow/tracing/fluent.py:1162:            trace.info.response_preview = response_preview
mlflow/tracing/constant.py:96:TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_DBX = 10000
mlflow/tracing/constant.py:97:TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_OSS = 1000
tests/entities/test_trace_data.py:225:    assert trace_data.request == '"foo"'
tests/entities/test_trace_data.py:233:    assert trace_data.request is None
mlflow/server/otel_api.py:106:                    mlflow_span = Span.from_otel_proto(otel_proto_span)
mlflow/utils/databricks_tracing_utils.py:140:        data=TraceData(spans=[Span.from_otel_proto(span, location_id) for span in proto.spans]),
mlflow/entities/trace.py:331:            data=TraceData(spans=[Span.from_otel_proto(span) for span in proto.spans]),
mlflow/utils/databricks_tracing_utils.py:133:        spans=[span.to_otel_proto() for span in trace.data.spans],
mlflow/entities/trace.py:324:            spans=[span.to_otel_proto() for span in self.data.spans],
mlflow/store/tracking/rest_store.py:1739:        scope_spans.spans.extend(span.to_otel_proto() for span in spans)
mlflow/store/tracking/databricks_rest_store.py:483:        scope_spans.spans.extend(span.to_otel_proto() for span in spans)
tests/entities/test_span_event.py:34:    otel_proto_event = event.to_otel_proto()
import uuid

import pytest
from opentelemetry import trace as otel_trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.sdk.resources import Resource as OTelSDKResource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import SimpleSpanProcessor
from opentelemetry.trace import Status, StatusCode
from opentelemetry.util._once import Once

import mlflow
from mlflow.entities import SpanStatusCode
from mlflow.entities.assessment import AssessmentSource, Expectation, Feedback
from mlflow.entities.assessment_source import AssessmentSourceType
from mlflow.tracing.constant import SpanAttributeKey
from mlflow.tracing.otel.translation.base import OtelSchemaTranslator
from mlflow.tracing.otel.translation.genai_semconv import GenAiTranslator
from mlflow.tracing.otel.translation.open_inference import OpenInferenceTranslator
from mlflow.tracing.otel.translation.traceloop import TraceloopTranslator
from mlflow.tracing.provider import _get_trace_exporter
from mlflow.tracing.utils import encode_trace_id
from mlflow.tracing.utils.otlp import MLFLOW_EXPERIMENT_ID_HEADER
from mlflow.tracking._tracking_service.utils import _use_tracking_uri
from mlflow.version import IS_TRACING_SDK_ONLY

from tests.tracking.integration_test_utils import _init_server

if IS_TRACING_SDK_ONLY:
    pytest.skip("OTel get_trace tests require full MLflow server", allow_module_level=True)


@pytest.fixture
def mlflow_server(tmp_path):
    backend_store_uri = f"sqlite:///{tmp_path / 'mlflow.db'}"
    artifact_root = tmp_path.as_uri()

    # Use _init_server with FastAPI (which is now the default)
    with _init_server(backend_store_uri, artifact_root) as url:
        yield url


@pytest.fixture(autouse=True)
def tracking_uri_setup(mlflow_server):
    with _use_tracking_uri(mlflow_server):
        yield


@pytest.fixture(params=[True, False])
def is_async(request, monkeypatch):
    monkeypatch.setenv("MLFLOW_ASYNC_TRACE_LOGGING", "true" if request.param else "false")


def _flush_async_logging():
    exporter = _get_trace_exporter()
    assert hasattr(exporter, "_async_queue"), "Async queue is not initialized"
    exporter._async_queue.flush(terminate=True)


def create_tracer(mlflow_server: str, experiment_id: str, service_name: str = "test-service"):
    resource = OTelSDKResource.create({"service.name": service_name, "service.version": "1.0.0"})
    tracer_provider = TracerProvider(resource=resource)

    exporter = OTLPSpanExporter(
        endpoint=f"{mlflow_server}/v1/traces",
        headers={MLFLOW_EXPERIMENT_ID_HEADER: experiment_id},
        timeout=10,
    )

    span_processor = SimpleSpanProcessor(exporter)
    tracer_provider.add_span_processor(span_processor)

    # Reset the global tracer provider
    otel_trace._TRACER_PROVIDER_SET_ONCE = Once()
    otel_trace._TRACER_PROVIDER = None
    otel_trace.set_tracer_provider(tracer_provider)

    return otel_trace.get_tracer(__name__)


def test_get_trace_for_otel_sent_span(mlflow_server: str, is_async):
    experiment = mlflow.set_experiment("otel-get-trace-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(mlflow_server, experiment_id, "test-service-get-trace")

    # Create a span with various attributes to test conversion
    with tracer.start_as_current_span("otel-test-span") as span:
        span.set_attribute("test.string", "string-value")
        span.set_attribute("test.number", 42)
        span.set_attribute("test.boolean", True)
        span.set_attribute("operation.type", "llm_request")

        # Capture the OTel trace ID
        otel_trace_id = span.get_span_context().trace_id
        assert span.get_span_context().is_valid
        assert otel_trace_id != 0

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )

    assert len(traces) > 0, "No traces found in the database"

    trace_id = traces[0].info.trace_id
    retrieved_trace = mlflow.get_trace(trace_id)

    assert retrieved_trace.info.trace_id == trace_id
    assert retrieved_trace.info.trace_location.mlflow_experiment.experiment_id == experiment_id

    assert len(retrieved_trace.data.spans) == 1
    span = retrieved_trace.data.spans[0]

    assert span.name == "otel-test-span"
    assert span.trace_id == trace_id
    # OTel spans default to UNSET status if not explicitly set
    assert span.status.status_code == SpanStatusCode.UNSET

    # Verify attributes were converted correctly
    assert span.attributes["test.string"] == "string-value"
    assert span.attributes["test.number"] == 42
    assert span.attributes["test.boolean"] is True
    assert span.attributes["operation.type"] == "llm_request"

    # Verify the trace ID matches the expected format
    expected_trace_id = f"tr-{encode_trace_id(otel_trace_id)}"
    assert trace_id == expected_trace_id


def test_get_trace_for_otel_nested_spans(mlflow_server: str, is_async):
    experiment = mlflow.set_experiment("otel-nested-spans-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(mlflow_server, experiment_id, "nested-test-service")

    # Create nested spans
    with tracer.start_as_current_span("parent-span") as parent_span:
        parent_span.set_attribute("span.level", "parent")

        with tracer.start_as_current_span("child-span") as child_span:
            child_span.set_attribute("span.level", "child")
            child_span.set_attribute("child.operation", "process_data")

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )

    assert len(traces) > 0, "No traces found in the database"

    trace_id = traces[0].info.trace_id
    retrieved_trace = mlflow.get_trace(trace_id)

    assert len(retrieved_trace.data.spans) == 2

    spans_by_name = {span.name: span for span in retrieved_trace.data.spans}

    assert "parent-span" in spans_by_name
    assert "child-span" in spans_by_name

    parent_span = spans_by_name["parent-span"]
    child_span = spans_by_name["child-span"]

    assert parent_span.attributes["span.level"] == "parent"
    assert parent_span.parent_id is None  # Root span has no parent

    assert child_span.attributes["span.level"] == "child"
    assert child_span.attributes["child.operation"] == "process_data"
    assert child_span.parent_id == parent_span.span_id  # Child should reference parent


def test_get_trace_with_otel_span_events(mlflow_server: str, is_async):
    experiment = mlflow.set_experiment("otel-events-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(mlflow_server, experiment_id, "events-test-service")

    # Create span with events using OTel SDK
    with tracer.start_as_current_span("span-with-events") as span:
        span.add_event("test_event", attributes={"event.type": "processing"})

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )

    trace_id = traces[0].info.trace_id
    retrieved_trace = mlflow.get_trace(trace_id)

    assert len(retrieved_trace.data.spans) == 1
    retrieved_span = retrieved_trace.data.spans[0]

    assert retrieved_span.name == "span-with-events"
    assert len(retrieved_span.events) == 1
    event = retrieved_span.events[0]
    assert event.name == "test_event"
    assert event.attributes["event.type"] == "processing"


def test_get_trace_nonexistent_otel_trace(mlflow_server: str):
    # Create a fake trace ID in OTel format
    fake_otel_trace_id = uuid.uuid4().hex
    fake_trace_id = f"tr-{fake_otel_trace_id}"

    # MLflow get_trace returns None for non-existent traces
    trace = mlflow.get_trace(fake_trace_id)
    assert trace is None


def test_get_trace_with_otel_span_status(mlflow_server: str, is_async):
    experiment = mlflow.set_experiment("otel-status-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(mlflow_server, experiment_id, "status-test-service")

    # Create span with error status using OTel SDK
    with tracer.start_as_current_span("error-span") as span:
        span.set_status(Status(StatusCode.ERROR, "Something went wrong"))

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )

    trace_id = traces[0].info.trace_id
    retrieved_trace = mlflow.get_trace(trace_id)

    assert len(retrieved_trace.data.spans) == 1
    retrieved_span = retrieved_trace.data.spans[0]

    assert retrieved_span.name == "error-span"
    assert retrieved_span.status.status_code == SpanStatusCode.ERROR
    assert "Something went wrong" in retrieved_span.status.description


def test_set_trace_tag_on_otel_trace(mlflow_server: str, is_async):
    experiment = mlflow.set_experiment("otel-tag-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(mlflow_server, experiment_id, "tag-test-service")

    with tracer.start_as_current_span("tagged-span") as span:
        span.set_attribute("test.attribute", "value")

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )
    trace_id = traces[0].info.trace_id

    mlflow.set_trace_tag(trace_id, "environment", "test")
    mlflow.set_trace_tag(trace_id, "version", "1.0.0")

    retrieved_trace = mlflow.get_trace(trace_id)
    assert retrieved_trace.info.tags["environment"] == "test"
    assert retrieved_trace.info.tags["version"] == "1.0.0"


def test_log_expectation_on_otel_trace(mlflow_server: str, is_async):
    experiment = mlflow.set_experiment("otel-expectation-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(mlflow_server, experiment_id, "expectation-test-service")

    # Create a span that represents a question-answer scenario
    with tracer.start_as_current_span("qa-span") as span:
        span.set_attribute("question", "What is MLflow?")
        span.set_attribute("answer", "MLflow is an open-source ML platform")

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )
    trace_id = traces[0].info.trace_id

    expectation_source = AssessmentSource(
        source_type=AssessmentSourceType.HUMAN, source_id="test_user@example.com"
    )

    logged_assessment = mlflow.log_expectation(
        trace_id=trace_id,
        name="expected_answer",
        value="MLflow is an open-source machine learning platform",
        source=expectation_source,
        metadata={"confidence": "high", "reviewed_by": "expert"},
    )
    expectation = mlflow.get_assessment(
"""
Tests for OpenTelemetry client integration with MLflow otel_api.py endpoint.

This test suite verifies that the experiment ID header functionality works correctly
when using OpenTelemetry clients to send spans to MLflow's OTel endpoint.
"""

import shutil
import time
from pathlib import Path
from typing import Iterator
from unittest import mock

import pytest
import requests
from opentelemetry import trace as otel_trace
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.proto.collector.trace.v1.trace_service_pb2 import ExportTraceServiceRequest
from opentelemetry.proto.common.v1.common_pb2 import InstrumentationScope
from opentelemetry.proto.resource.v1.resource_pb2 import Resource
from opentelemetry.proto.trace.v1.trace_pb2 import ResourceSpans, ScopeSpans
from opentelemetry.proto.trace.v1.trace_pb2 import Span as OTelProtoSpan
from opentelemetry.sdk.resources import Resource as OTelSDKResource
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.trace.export import BatchSpanProcessor, SimpleSpanProcessor
from opentelemetry.util._once import Once

import mlflow
from mlflow.server import handlers
from mlflow.server.fastapi_app import app as mlflow_app
from mlflow.server.handlers import initialize_backend_stores
from mlflow.store.tracking.sqlalchemy_store import SqlAlchemyStore
from mlflow.tracing.utils import encode_trace_id
from mlflow.tracing.utils.otlp import MLFLOW_EXPERIMENT_ID_HEADER
from mlflow.version import IS_TRACING_SDK_ONLY

from tests.helper_functions import get_safe_port
from tests.store.tracking.test_sqlalchemy_store import ARTIFACT_URI
from tests.tracking.integration_test_utils import ServerThread

if IS_TRACING_SDK_ONLY:
    pytest.skip("OTel endpoint tests require full MLflow server", allow_module_level=True)


@pytest.fixture(scope="module")
def cached_db(tmp_path_factory) -> Path:
    """Creates and caches a SQLite database to avoid repeated migrations for each test run."""
    tmp_path = tmp_path_factory.mktemp("sqlite_db")
    db_path = tmp_path / "mlflow.db"
    db_uri = f"sqlite:///{db_path}"
    store = SqlAlchemyStore(db_uri, ARTIFACT_URI)
    store.engine.dispose()
    return db_path


@pytest.fixture
def mlflow_server(tmp_path: Path, cached_db: Path) -> Iterator[str]:
    # Copy the pre-initialized cached DB into this test's tmp path
    db_path = tmp_path / "mlflow.db"
    shutil.copy(cached_db, db_path)

    backend_store_uri = f"sqlite:///{db_path}"
    artifact_root = tmp_path.as_uri()

    handlers._tracking_store = None
    handlers._model_registry_store = None
    initialize_backend_stores(backend_store_uri, default_artifact_root=artifact_root)

    # Start the FastAPI app in a background thread and yield its URL.
    with ServerThread(mlflow_app, get_safe_port()) as url:
        yield url


def test_otel_client_sends_spans_to_mlflow_database(mlflow_server: str, monkeypatch):
    """
    Test end-to-end: OpenTelemetry client sends spans via experiment ID header to MLflow.

    Note: This test verifies that spans are successfully accepted by the server.
    Without artifact upload, traces won't be retrievable via search_traces.
    """
    # Enable synchronous trace logging to ensure traces are immediately available
    monkeypatch.setenv("MLFLOW_ASYNC_TRACE_LOGGING", "false")

    mlflow.set_tracking_uri(mlflow_server)

    experiment = mlflow.set_experiment("otel-test-experiment")
    experiment_id = experiment.experiment_id

    resource = OTelSDKResource.create({"service.name": "test-service-e2e"})
    tracer_provider = TracerProvider(resource=resource)

    # First, verify the endpoint is reachable
    test_response = requests.get(f"{mlflow_server}/health", timeout=5)
    assert test_response.status_code == 200, (
        f"Server health check failed: {test_response.status_code}"
    )

    exporter = OTLPSpanExporter(
        endpoint=f"{mlflow_server}/v1/traces",
        headers={MLFLOW_EXPERIMENT_ID_HEADER: experiment_id},
        timeout=10,  # Explicit timeout
    )

    # Use SimpleSpanProcessor for immediate span export in tests
    # This ensures spans are sent immediately rather than batched
    span_processor = SimpleSpanProcessor(exporter)
    tracer_provider.add_span_processor(span_processor)

    # Reset the global tracer provider to avoid conflicts with other tests.
    # This is necessary because OpenTelemetry doesn't allow overriding an already-set provider.
    #
    # NOTE: We're using internal APIs here (_TRACER_PROVIDER_SET_ONCE and _TRACER_PROVIDER)
    # because OpenTelemetry doesn't provide a public API to reset the global tracer provider.
    # The library is designed to set the provider once at application startup, which doesn't
    # work well for testing scenarios where different tests need different configurations.
    # This pattern is also used in tests/semantic_kernel/conftest.py for the same reason.
    otel_trace._TRACER_PROVIDER_SET_ONCE = Once()
    otel_trace._TRACER_PROVIDER = None

    # Set the tracer provider
    otel_trace.set_tracer_provider(tracer_provider)
    tracer = otel_trace.get_tracer(__name__)

    with tracer.start_as_current_span("otel-e2e-test-span") as span:
        span.set_attribute("test.e2e.attribute", "e2e-test-value")
        # Capture the OTel trace ID to verify it matches the MLflow trace ID
        otel_trace_id = span.get_span_context().trace_id
        # Verify the span was actually created and has valid context
        assert span.get_span_context().is_valid, "Span context is not valid"
        assert otel_trace_id != 0, "Trace ID is zero"

    # Add a small delay to ensure the server has processed the spans
    time.sleep(0.5)

    # Wait up to 30 seconds for search_traces() to return a trace
    traces = []
    for _ in range(30):
        traces = mlflow.search_traces(
            experiment_ids=[experiment_id], include_spans=False, return_type="list"
        )
        if traces:
            break
        time.sleep(1)

    assert len(traces) > 0, "No traces found in the database after sending spans"

    # Verify the trace ID matches the expected format based on the OTel span
    expected_trace_id = f"tr-{encode_trace_id(otel_trace_id)}"
    actual_trace_id = traces[0].info.trace_id
    assert actual_trace_id == expected_trace_id, (
        f"Trace ID mismatch: expected {expected_trace_id}, got {actual_trace_id}"
    )


def test_otel_endpoint_requires_experiment_id_header(mlflow_server: str):
    """
    Test that the OTel endpoint requires experiment ID header.
    """
    # Create protobuf request
    span = OTelProtoSpan()
    span.trace_id = bytes.fromhex("0000000000000002" + "0" * 16)
    span.span_id = bytes.fromhex("00000002" + "0" * 8)
    span.name = "test-span-no-header"

    scope = InstrumentationScope()
    scope.name = "test-scope"

    scope_spans = ScopeSpans()
    scope_spans.scope.CopyFrom(scope)
    scope_spans.spans.append(span)

    resource = Resource()
    resource_spans = ResourceSpans()
    resource_spans.resource.CopyFrom(resource)
    resource_spans.scope_spans.append(scope_spans)

    request = ExportTraceServiceRequest()
    request.resource_spans.append(resource_spans)

    response = requests.post(
        f"{mlflow_server}/v1/traces",
        data=request.SerializeToString(),
        headers={"Content-Type": "application/x-protobuf"},
        timeout=10,
    )

    assert response.status_code == 422


def test_invalid_otel_span_format_returns_400(mlflow_server: str):
    """
    Test that invalid OpenTelemetry protobuf format returns HTTP 400.
    """
    # Send completely invalid protobuf data
    invalid_protobuf_data = b"this is not valid protobuf data at all"

    response = requests.post(
        f"{mlflow_server}/v1/traces",
        data=invalid_protobuf_data,
        headers={
            "Content-Type": "application/x-protobuf",
            MLFLOW_EXPERIMENT_ID_HEADER: "test-experiment",
        },
        timeout=10,
    )

    assert response.status_code == 400, f"Expected 400, got {response.status_code}"


def test_missing_required_span_fields_returns_422(mlflow_server: str):
    """
    Test that spans that fail MLflow conversion return HTTP 422.
    """
    # Create protobuf request with missing trace_id (this should cause MLflow conversion to fail)
    span = OTelProtoSpan()
    # Don't set trace_id - this should cause from_otel_proto to fail
    span.span_id = bytes.fromhex("00000001" + "0" * 8)
    span.name = "incomplete-span"

    scope = InstrumentationScope()
    scope.name = "test-scope"

    scope_spans = ScopeSpans()
    scope_spans.scope.CopyFrom(scope)
    scope_spans.spans.append(span)

    resource = Resource()
    resource_spans = ResourceSpans()
    resource_spans.resource.CopyFrom(resource)
    resource_spans.scope_spans.append(scope_spans)

    request = ExportTraceServiceRequest()
    request.resource_spans.append(resource_spans)

    response = requests.post(
        f"{mlflow_server}/v1/traces",
        data=request.SerializeToString(),
        headers={
            "Content-Type": "application/x-protobuf",
            MLFLOW_EXPERIMENT_ID_HEADER: "test-experiment",
        },
        timeout=10,
    )

    assert response.status_code == 422


def test_missing_experiment_id_header_returns_422(mlflow_server: str):
    """
    Test that missing experiment ID header returns HTTP 422 (FastAPI validation error).
    """
    # Create valid protobuf request
    span = OTelProtoSpan()
    span.trace_id = bytes.fromhex("0000000000000003" + "0" * 16)
    span.span_id = bytes.fromhex("00000003" + "0" * 8)
    span.name = "test-span"

    scope = InstrumentationScope()
    scope.name = "test-scope"

    scope_spans = ScopeSpans()
    scope_spans.scope.CopyFrom(scope)
    scope_spans.spans.append(span)

    resource = Resource()
    resource_spans = ResourceSpans()
    resource_spans.resource.CopyFrom(resource)
    resource_spans.scope_spans.append(scope_spans)

    request = ExportTraceServiceRequest()
    request.resource_spans.append(resource_spans)

    response = requests.post(
        f"{mlflow_server}/v1/traces",
        data=request.SerializeToString(),
        headers={"Content-Type": "application/x-protobuf"},
        timeout=10,
    )

    assert response.status_code == 422
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' mlflow/tracing/utils/truncation.py; sed -n '300,350p' mlflow/entities/trace.py; sed -n '1,430p' mlflow/tracing/utils/__init__.py; sed -n '1,180p' tests/entities/test_span_status.py; sed -n '1,100p' tests/entities/test_span_event.py"
```

退出码：`0`

输出：
```
import json
from functools import lru_cache
from typing import Any

from mlflow.entities.trace_data import TraceData
from mlflow.entities.trace_info import TraceInfo
from mlflow.tracing.constant import (
    TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_DBX,
    TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_OSS,
)
from mlflow.tracking._tracking_service.utils import get_tracking_uri
from mlflow.utils.uri import is_databricks_uri



























































































def _is_message(item: Any) -> bool:
    return isinstance(item, dict) and "role" in item and "content" in item


def _get_last_message(messages: list[dict[str, Any]], role: str) -> dict[str, Any]:
    """
    Return last message with the given role.
    If the messages don't include a message with the given role, return the last one.
    """
    for message in reversed(messages):
        if message.get("role") == role:
            return message
    return messages[-1]


def _get_text_content_from_message(message: dict[str, Any]) -> str:
    content = message.get("content")
    if isinstance(content, list):
        # content is a list of content parts
        for part in content:
            if isinstance(part, str):
                return part
            elif isinstance(part, dict) and part.get("type") in ["text", "output_text"]:
                return part.get("text")
    elif isinstance(content, str):
        return content
    return ""    @staticmethod
    def pandas_dataframe_columns() -> list[str]:
        return [
            "trace_id",
            "trace",
            "client_request_id",
            "state",
            "request_time",
            "execution_duration",
            "request",
            "response",
            "trace_metadata",
            "tags",
            "spans",
            "assessments",
        ]

    def to_proto(self):
        """
        Convert into a proto object to sent to the MLflow backend.
        """

        return ProtoTrace(
            trace_info=self.info.to_proto(),
            spans=[span.to_otel_proto() for span in self.data.spans],
        )

    @classmethod
    def from_proto(cls, proto: ProtoTrace) -> "Trace":
        return cls(
            info=TraceInfo.from_proto(proto.trace_info),
            data=TraceData(spans=[Span.from_otel_proto(span) for span in proto.spans]),
        )
# TODO: Split this file into multiple files and move under utils directory.
from __future__ import annotations

import inspect
import json
import logging
import uuid
from collections import defaultdict
from contextlib import contextmanager
from dataclasses import asdict, is_dataclass
from functools import lru_cache
from typing import TYPE_CHECKING, Any, Generator

from opentelemetry import trace as trace_api
from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
from opentelemetry.sdk.trace import Span as OTelSpan

from mlflow.exceptions import BAD_REQUEST, MlflowException, MlflowTracingException
from mlflow.tracing.constant import (
    ASSESSMENT_ID_PREFIX,
    TRACE_ID_V4_PREFIX,
    TRACE_REQUEST_ID_PREFIX,
    SpanAttributeKey,
    TokenUsageKey,
    TraceMetadataKey,
    TraceSizeStatsKey,
)
from mlflow.utils.mlflow_tags import IMMUTABLE_TAGS
from mlflow.version import IS_TRACING_SDK_ONLY

_logger = logging.getLogger(__name__)

SPANS_COLUMN_NAME = "spans"

if TYPE_CHECKING:
    from mlflow.entities import LiveSpan, Trace
    from mlflow.pyfunc.context import Context
    from mlflow.types.chat import ChatTool


def capture_function_input_args(func, args, kwargs) -> dict[str, Any] | None:
    try:
        func_signature = inspect.signature(func)
        bound_arguments = func_signature.bind(*args, **kwargs)
        bound_arguments.apply_defaults()

        # Remove `self` from bound arguments if it exists
        if bound_arguments.arguments.get("self"):
            del bound_arguments.arguments["self"]

        # Remove `cls` from bound arguments if it's the first parameter and it's a type
        # This detects classmethods more reliably
        params = list(bound_arguments.arguments.keys())
        if params and params[0] == "cls" and isinstance(bound_arguments.arguments["cls"], type):
            del bound_arguments.arguments["cls"]

        return bound_arguments.arguments
    except Exception:
        _logger.warning(f"Failed to capture inputs for function {func.__name__}.")
        return None


class TraceJSONEncoder(json.JSONEncoder):
    """
    Custom JSON encoder for serializing non-OpenTelemetry compatible objects in a trace or span.

    Trace may contain types that require custom serialization logic, such as Pydantic models,
    non-JSON-serializable types, etc.
    """

    def default(self, obj):
        try:
            import pydantic

            if isinstance(obj, pydantic.BaseModel):
                return obj.model_dump()
        except ImportError:
            pass

        # Some dataclass object defines __str__ method that doesn't return the full object
        # representation, so we use dict representation instead.
        # E.g. https://github.com/run-llama/llama_index/blob/29ece9b058f6b9a1cf29bc723ed4aa3a39879ad5/llama-index-core/llama_index/core/chat_engine/types.py#L63-L64
        if is_dataclass(obj):
            try:
                return asdict(obj)
            except TypeError:
                pass

        # Some object has dangerous side effect in __str__ method, so we use class name instead.
        if not self._is_safe_to_encode_str(obj):
            return type(obj)

        try:
            return super().default(obj)
        except TypeError:
            return str(obj)

    def _is_safe_to_encode_str(self, obj) -> bool:
        """Check if it's safe to encode the object as a string."""
        try:
            # These Llama Index objects are not safe to encode as string, because their __str__
            # method consumes the stream and make it unusable.
            # E.g. https://github.com/run-llama/llama_index/blob/54f2da61ba8a573284ab8336f2b2810d948c3877/llama-index-core/llama_index/core/base/response/schema.py#L120-L127
            from llama_index.core.base.response.schema import (
                AsyncStreamingResponse,
                StreamingResponse,
            )
            from llama_index.core.chat_engine.types import StreamingAgentChatResponse

            if isinstance(
                obj,
                (AsyncStreamingResponse, StreamingResponse, StreamingAgentChatResponse),
            ):
                return False
        except ImportError:
            pass

        return True


def dump_span_attribute_value(value: Any) -> str:
    # NB: OpenTelemetry attribute can store not only string but also a few primitives like
    #   int, float, bool, and list of them. However, we serialize all into JSON string here
    #   for the simplicity in deserialization process.
    return json.dumps(value, cls=TraceJSONEncoder, ensure_ascii=False)


@lru_cache(maxsize=1)
def encode_span_id(span_id: int) -> str:
    """
    Encode the given integer span ID to a 16-byte hex string.
    # https://github.com/open-telemetry/opentelemetry-python/blob/9398f26ecad09e02ad044859334cd4c75299c3cd/opentelemetry-sdk/src/opentelemetry/sdk/trace/__init__.py#L507-L508
    # NB: We don't add '0x' prefix to the hex string here for simpler parsing in backend.
    #   Some backend (e.g. Databricks) disallow this prefix.
    """
    return trace_api.format_span_id(span_id)


@lru_cache(maxsize=1)
def encode_trace_id(trace_id: int) -> str:
    """
    Encode the given integer trace ID to a 32-byte hex string.
    """
    return trace_api.format_trace_id(trace_id)


def decode_id(span_or_trace_id: str) -> int:
    """
    Decode the given hex string span or trace ID to an integer.
    """
    return int(span_or_trace_id, 16)


def get_mlflow_span_for_otel_span(span: OTelSpan) -> LiveSpan | None:
    """
    Get the active MLflow span for the given OpenTelemetry span.
    """
    from mlflow.tracing.trace_manager import InMemoryTraceManager

    trace_id = get_otel_attribute(span, SpanAttributeKey.REQUEST_ID)
    mlflow_span_id = encode_span_id(span.get_span_context().span_id)
    return InMemoryTraceManager.get_instance().get_span_from_id(trace_id, mlflow_span_id)


def build_otel_context(trace_id: int, span_id: int) -> trace_api.SpanContext:
    """
    Build an OpenTelemetry SpanContext object from the given trace and span IDs.
    """
    return trace_api.SpanContext(
        trace_id=trace_id,
        span_id=span_id,
        # NB: This flag is OpenTelemetry's concept to indicate whether the context is
        # propagated from remote parent or not. We don't support distributed tracing
        # yet so always set it to False.
        is_remote=False,
    )


def aggregate_usage_from_spans(spans: list[LiveSpan]) -> dict[str, int] | None:
    """Aggregate token usage information from all spans in the trace."""
    input_tokens = 0
    output_tokens = 0
    total_tokens = 0
    has_usage_data = False

    span_id_to_spans = {span.span_id: span for span in spans}
    children_map: defaultdict[str, list[LiveSpan]] = defaultdict(list)
    roots: list[LiveSpan] = []

    for span in spans:
        parent_id = span.parent_id
        if parent_id and parent_id in span_id_to_spans:
            children_map[parent_id].append(span)
        else:
            roots.append(span)

    def dfs(span: LiveSpan, ancestor_has_usage: bool) -> None:
        nonlocal input_tokens, output_tokens, total_tokens, has_usage_data

        usage = span.get_attribute(SpanAttributeKey.CHAT_USAGE)
        span_has_usage = usage is not None

        if span_has_usage and not ancestor_has_usage:
            input_tokens += usage.get(TokenUsageKey.INPUT_TOKENS, 0)
            output_tokens += usage.get(TokenUsageKey.OUTPUT_TOKENS, 0)
            total_tokens += usage.get(TokenUsageKey.TOTAL_TOKENS, 0)
            has_usage_data = True

        next_ancestor_has_usage = ancestor_has_usage or span_has_usage
        for child in children_map.get(span.span_id, []):
            dfs(child, next_ancestor_has_usage)

    for root in roots:
        dfs(root, False)

    # If none of the spans have token usage data, we shouldn't log token usage metadata.
    if not has_usage_data:
        return None

    return {
        TokenUsageKey.INPUT_TOKENS: input_tokens,
        TokenUsageKey.OUTPUT_TOKENS: output_tokens,
        TokenUsageKey.TOTAL_TOKENS: total_tokens,
    }


def get_otel_attribute(span: trace_api.Span, key: str) -> str | None:
    """
    Get the attribute value from the OpenTelemetry span in a decoded format.

    Args:
        span: The OpenTelemetry span object.
        key: The key of the attribute to retrieve.

    Returns:
        The attribute value as decoded string. If the attribute is not found or cannot
        be parsed, return None.
    """
    try:
        attribute_value = span.attributes.get(key)
        if attribute_value is None:
            return None
        return json.loads(attribute_value)
    except Exception:
        _logger.debug(f"Failed to get attribute {key} with from span {span}.", exc_info=True)


def _try_get_prediction_context():
    # NB: Tracing is enabled in mlflow-skinny, but the pyfunc module cannot be imported as it
    #     relies on numpy, which is not installed in skinny.
    try:
        from mlflow.pyfunc.context import get_prediction_context
    except (ImportError, KeyError):
        return

    return get_prediction_context()


def maybe_get_request_id(is_evaluate=False) -> str | None:
    """Get the request ID if the current prediction is as a part of MLflow model evaluation."""
    context = _try_get_prediction_context()
    if not context or (is_evaluate and not context.is_evaluate):
        return None

    if not context.request_id and is_evaluate:
        _logger.warning(
            f"Missing request_id for context {context}. request_id can't be None when "
            "is_evaluate=True. This is likely an internal error of MLflow, please file "
            "a bug report at https://github.com/mlflow/mlflow/issues."
        )
        return None

    return context.request_id


def maybe_get_dependencies_schemas() -> dict[str, Any] | None:
    context = _try_get_prediction_context()
    if context:
        return context.dependencies_schemas


def maybe_get_logged_model_id() -> str | None:
    """
    Get the logged model ID associated with the current prediction context.
    """
    if context := _try_get_prediction_context():
        return context.model_id


def exclude_immutable_tags(tags: dict[str, str]) -> dict[str, str]:
    """Exclude immutable tags e.g. "mlflow.user" from the given tags."""
    return {k: v for k, v in tags.items() if k not in IMMUTABLE_TAGS}


def generate_mlflow_trace_id_from_otel_trace_id(otel_trace_id: int) -> str:
    """
    Generate an MLflow trace ID from an OpenTelemetry trace ID.

    Args:
        otel_trace_id: The OpenTelemetry trace ID as an integer.

    Returns:
        The MLflow trace ID string in format "tr-<hex_trace_id>".
    """
    return TRACE_REQUEST_ID_PREFIX + encode_trace_id(otel_trace_id)


def generate_trace_id_v4_from_otel_trace_id(otel_trace_id: int, location: str) -> str:
    """
    Generate a trace ID in v4 format from the given OpenTelemetry trace ID.

    Args:
        otel_trace_id: The OpenTelemetry trace ID as an integer.
        location: The location, of the trace.

    Returns:
        The MLflow trace ID string in format "trace:/<location>/<hex_trace_id>".
    """
    return construct_trace_id_v4(location, encode_trace_id(otel_trace_id))


def generate_trace_id_v4(span: OTelSpan, location: str) -> str:
    """
    Generate a trace ID for the given span.

    Args:
        span: The OpenTelemetry span object.
        location: The location, of the trace.

    Returns:
        Trace ID with format "trace:/<location>/<hex_trace_id>".
    """
    return generate_trace_id_v4_from_otel_trace_id(span.context.trace_id, location)


def generate_trace_id_v3(span: OTelSpan) -> str:
    """
    Generate a trace ID for the given span (V3 trace schema).

    The format will be "tr-<trace_id>" where the trace_id is hex-encoded Otel trace ID.
    """
    return generate_mlflow_trace_id_from_otel_trace_id(span.context.trace_id)


def generate_request_id_v2() -> str:
    """
    Generate a request ID for the given span.

    This should only be used for V2 trace schema where we use a random UUID as
    request ID. In the V3 schema, "request_id" is renamed to "trace_id" and
    we use the otel-generated trace ID with encoding.
    """
    return uuid.uuid4().hex


def construct_full_inputs(func, *args, **kwargs) -> dict[str, Any]:
    """
    Construct the full input arguments dictionary for the given function,
    including positional and keyword arguments.
    """
    signature = inspect.signature(func)
    # this does not create copy. So values should not be mutated directly
    arguments = signature.bind_partial(*args, **kwargs).arguments

    if "self" in arguments:
        arguments.pop("self")

    return arguments


@contextmanager
def maybe_set_prediction_context(context: "Context" | None):
    """
    Set the prediction context if the given context
    is not None. Otherwise no-op.
    """
    if not IS_TRACING_SDK_ONLY and context:
        from mlflow.pyfunc.context import set_prediction_context

        with set_prediction_context(context):
            yield
    else:
        yield


def set_span_chat_tools(span: LiveSpan, tools: list[ChatTool]):
    """
    Set the `mlflow.chat.tools` attribute on the specified span. This
    attribute is used in the UI, and also by downstream applications that
    consume trace data, such as MLflow evaluate.

    Args:
        span: The LiveSpan to add the attribute to
        tools: A list of standardized chat tool definitions (refer to the
              `spec <../llms/tracing/tracing-schema.html#chat-completion-spans>`_
              for details)

    Example:

    .. code-block:: python
        :test:

        import mlflow
        from mlflow.tracing import set_span_chat_tools

        tools = [
            {
                "type": "function",
                "function": {
                    "name": "add",
                    "description": "Add two numbers",
                    "parameters": {
                        "type": "object",
                        "properties": {
                            "a": {"type": "number"},
                            "b": {"type": "number"},
                        },
                        "required": ["a", "b"],
                    },
                },
            }
        ]


        @mlflow.trace
        def f():
            span = mlflow.get_current_active_span()
            set_span_chat_tools(span, tools)
            return 0

import pytest
from opentelemetry import trace as trace_api
from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
from opentelemetry.trace import Status as OTelStatus
from opentelemetry.trace import StatusCode as OTelStatusCode

from mlflow.entities import SpanStatus, SpanStatusCode
from mlflow.exceptions import MlflowException


@pytest.mark.parametrize("status_code", [SpanStatusCode.OK, "OK"])
def test_span_status_init(status_code):
    span_status = SpanStatus(status_code)
    assert span_status.status_code == SpanStatusCode.OK


def test_span_status_raise_invalid_status_code():
    with pytest.raises(MlflowException, match=r"INVALID is not a valid SpanStatusCode value."):
        SpanStatus("INVALID", description="test")


@pytest.mark.parametrize(
    ("status_code", "otel_status_code"),
    [
        (SpanStatusCode.OK, trace_api.StatusCode.OK),
        (SpanStatusCode.ERROR, trace_api.StatusCode.ERROR),
        (SpanStatusCode.UNSET, trace_api.StatusCode.UNSET),
    ],
)
def test_otel_status_conversion(status_code, otel_status_code):
    span_status = SpanStatus(status_code, description="test")
    otel_status = span_status.to_otel_status()

    # OpenTelemetry only allows specify description when status is ERROR
    # Otherwise it will be ignored with warning message.
    expected_description = "test" if status_code == SpanStatusCode.ERROR else None

    assert otel_status.status_code == otel_status_code
    assert otel_status.description == expected_description

    span_status = SpanStatus.from_otel_status(otel_status)
    assert span_status.status_code == status_code
    assert span_status.description == (expected_description or "")


@pytest.mark.parametrize(
    ("status_code", "status_desc", "expected_code", "expected_desc"),
    [
        # OTel only keeps description for ERROR status
        (OTelStatusCode.OK, "Success", SpanStatusCode.OK, ""),
        (OTelStatusCode.ERROR, "Failed", SpanStatusCode.ERROR, "Failed"),
        (OTelStatusCode.UNSET, "", SpanStatusCode.UNSET, ""),
    ],
)
def test_otel_status_to_mlflow_status_conversion(
    status_code, status_desc, expected_code, expected_desc
):
    """Test conversion from OTel SDK status to MLflow SpanStatus."""
    # Create OTel status
    otel_status = OTelStatus(status_code, status_desc)

    # Convert to MLflow status
    mlflow_status = SpanStatus.from_otel_status(otel_status)
    assert mlflow_status.status_code == expected_code
    # OTel SDK clears description for non-ERROR statuses
    assert mlflow_status.description == (status_desc if status_code == OTelStatusCode.ERROR else "")

    # Convert back to OTel status
    converted_status = mlflow_status.to_otel_status()
    assert converted_status.status_code == status_code
    # Description is only preserved for ERROR status
    assert converted_status.description == expected_desc


@pytest.mark.parametrize(
    ("proto_code", "expected_mlflow_code"),
    [
        (OTelProtoStatus.STATUS_CODE_OK, SpanStatusCode.OK),
        (OTelProtoStatus.STATUS_CODE_ERROR, SpanStatusCode.ERROR),
        (OTelProtoStatus.STATUS_CODE_UNSET, SpanStatusCode.UNSET),
    ],
)
def test_otel_proto_status_to_mlflow_status_conversion(proto_code, expected_mlflow_code):
    """Test conversion from OTel protobuf status to MLflow SpanStatus."""
    # Create proto status
    proto_status = OTelProtoStatus()
    proto_status.code = proto_code
    proto_status.message = "test message"

    # Convert to MLflow status
    mlflow_status = SpanStatus.from_otel_proto_status(proto_status)
    assert mlflow_status.status_code == expected_mlflow_code
    assert mlflow_status.description == "test message"


@pytest.mark.parametrize(
    ("mlflow_code", "description", "expected_proto_code"),
    [
        (SpanStatusCode.OK, "Success", OTelProtoStatus.STATUS_CODE_OK),
        (SpanStatusCode.ERROR, "Failed", OTelProtoStatus.STATUS_CODE_ERROR),
        (SpanStatusCode.UNSET, "", OTelProtoStatus.STATUS_CODE_UNSET),
    ],
)
def test_mlflow_status_to_otel_proto_status_conversion(
    mlflow_code, description, expected_proto_code
):
    """Test conversion from MLflow SpanStatus to OTel protobuf status."""
    # Create MLflow status
    mlflow_status = SpanStatus(mlflow_code, description)

    # Convert to OTel proto status
    proto_status = mlflow_status.to_otel_proto_status()
    assert proto_status.code == expected_proto_code
    assert proto_status.message == description
import pytest

from mlflow.entities import SpanEvent
from mlflow.exceptions import MlflowException


def test_from_exception():
    exception = MlflowException("test")
    span_event = SpanEvent.from_exception(exception)
    assert span_event.name == "exception"
    assert span_event.attributes["exception.message"] == "test"
    assert span_event.attributes["exception.type"] == "MlflowException"
    assert span_event.attributes["exception.stacktrace"] is not None


@pytest.mark.parametrize(
    "event_attrs",
    [
        {},
        {"simple": "string"},
        {"number": 42, "float": 3.14, "bool": True},
        {"list": [1, 2, 3], "dict": {"nested": "value"}},
    ],
)
def test_span_event_to_otel_proto_conversion(event_attrs):
    # Create span event
    event = SpanEvent(
        name="test_event",
        timestamp=1234567890,
        attributes=event_attrs,
    )

    # Convert to OTel proto
    otel_proto_event = event.to_otel_proto()

    # Verify fields
    assert otel_proto_event.name == "test_event"
    assert otel_proto_event.time_unix_nano == 1234567890

    # Verify attributes
    from mlflow.tracing.utils.otlp import _decode_otel_proto_anyvalue

    decoded_attrs = {}
    for attr in otel_proto_event.attributes:
        decoded_attrs[attr.key] = _decode_otel_proto_anyvalue(attr.value)

    assert decoded_attrs == event_attrs
```

## 原始行 35 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"truncation import\\|utils.truncation\" mlflow tests --include='*.py'; grep -R -n \"trace.info.request_preview\\|request_preview ==\\|response_preview ==\" tests/tracing tests/entities --include='*.py' | head -200; sed -n '1,180p' mlflow/tracing/constant.py; python - <<'PY'
import inspect
from opentelemetry.sdk.trace import ReadableSpan, Event, Span
from opentelemetry.proto.trace.v1.trace_pb2 import Span as PSpan
print(inspect.signature(ReadableSpan))
print(inspect.signature(Event))
print(PSpan())
PY"
```

退出码：`0`

输出：
```
tests/tracing/utils/test_truncation.py:6:from mlflow.tracing.utils.truncation import _get_truncated_preview
tests/tracing/utils/test_truncation.py:12:    with patch("mlflow.tracing.utils.truncation._get_max_length", return_value=50):
tests/tracing/test_otel_loading.py:507:    assert retrieved_trace.info.request_preview == '"Hello, world!"'
tests/tracing/test_otel_loading.py:508:    assert retrieved_trace.info.response_preview == '"Bye!"'
tests/tracing/opentelemetry/test_integration.py:51:    assert trace.info.request_preview == ""
tests/tracing/opentelemetry/test_integration.py:52:    assert trace.info.response_preview == ""
tests/tracing/opentelemetry/test_integration.py:106:    assert trace.info.request_preview == '{"text": "hello"}'
tests/tracing/opentelemetry/test_integration.py:107:    assert trace.info.response_preview == '{"text": "world"}'
tests/tracing/opentelemetry/test_integration.py:153:    assert trace.info.request_preview == '{"text": "hello"}'
tests/tracing/opentelemetry/test_integration.py:154:    assert trace.info.response_preview == '{"text": "world"}'
tests/entities/test_trace_info.py:169:    assert proto_trace_info_v4.request_preview == "request"
tests/entities/test_trace_info.py:170:    assert proto_trace_info_v4.response_preview == "response"
tests/entities/test_trace_info.py:273:    assert trace_info.request_preview == "request"
tests/entities/test_trace_info.py:274:    assert trace_info.response_preview == "response"
tests/entities/test_trace_info_v2.py:153:    assert v3_proto.request_preview == "request"
tests/entities/test_trace_info_v2.py:154:    assert v3_proto.response_preview == "response"
tests/entities/test_trace.py:359:    assert len(trace_info.request_preview) == 1000
tests/entities/test_trace.py:360:    assert trace_info.request_preview.startswith("Hello!")
tests/entities/test_trace.py:377:    assert len(trace_info.request_preview) == 1000
tests/entities/test_trace.py:378:    assert trace_info.request_preview.startswith('{"question": "startaaa')
tests/entities/test_trace.py:398:    assert trace_info.request_preview == "custom request preview"
tests/entities/test_trace.py:399:    assert trace_info.response_preview == "custom response preview"
from enum import Enum


# NB: These keys are placeholders and subject to change
class TraceMetadataKey:
    INPUTS = "mlflow.traceInputs"
    OUTPUTS = "mlflow.traceOutputs"
    SOURCE_RUN = "mlflow.sourceRun"
    MODEL_ID = "mlflow.modelId"
    # Trace size statistics including total size, number of spans, and max span size
    SIZE_STATS = "mlflow.trace.sizeStats"
    # Aggregated token usage information in a single trace, stored as a dumped JSON string.
    TOKEN_USAGE = "mlflow.trace.tokenUsage"
    # Store the user ID/name of the application request. Do not confuse this with mlflow.user
    # tag, which stores "who created the trace" i.e. developer or system name.
    TRACE_USER = "mlflow.trace.user"
    # Store the session ID of the application request.
    TRACE_SESSION = "mlflow.trace.session"

    # Total size of the trace in bytes. Deprecated, use SIZE_STATS instead.
    SIZE_BYTES = "mlflow.trace.sizeBytes"


class TraceTagKey:
    TRACE_NAME = "mlflow.traceName"
    EVAL_REQUEST_ID = "mlflow.eval.requestId"
    SPANS_LOCATION = "mlflow.trace.spansLocation"
    # Store the source scorer name that generated the trace. This tag is used to determine if a
    # trace is generated by a scorer or prediction during evaluation and filter out the scorer
    # traces in the UI. This supposed to be immutable, but we use tag because we can only set this
    # after the scorer is executed, which is not possible with trace metadata.
    SOURCE_SCORER_NAME = "mlflow.trace.sourceScorer"


class TokenUsageKey:
    """Key for the token usage information in the `mlflow.chat.tokenUsage` span attribute."""

    INPUT_TOKENS = "input_tokens"
    OUTPUT_TOKENS = "output_tokens"
    TOTAL_TOKENS = "total_tokens"

    @classmethod
    def all_keys(cls):
        return [cls.INPUT_TOKENS, cls.OUTPUT_TOKENS, cls.TOTAL_TOKENS]


class TraceSizeStatsKey:
    TOTAL_SIZE_BYTES = "total_size_bytes"
    NUM_SPANS = "num_spans"
    MAX_SPAN_SIZE_BYTES = "max"
    P25_SPAN_SIZE_BYTES = "p25"
    P50_SPAN_SIZE_BYTES = "p50"
    P75_SPAN_SIZE_BYTES = "p75"


# A set of reserved attribute keys
class SpanAttributeKey:
    EXPERIMENT_ID = "mlflow.experimentId"
    REQUEST_ID = "mlflow.traceRequestId"
    INPUTS = "mlflow.spanInputs"
    OUTPUTS = "mlflow.spanOutputs"
    SPAN_TYPE = "mlflow.spanType"
    FUNCTION_NAME = "mlflow.spanFunctionName"
    START_TIME_NS = "mlflow.spanStartTimeNs"
    CHAT_TOOLS = "mlflow.chat.tools"
    # This attribute is used to store token usage information from LLM responses.
    # Stored in {"input_tokens": int, "output_tokens": int, "total_tokens": int} format.
    CHAT_USAGE = "mlflow.chat.tokenUsage"
    # This attribute indicates which flavor/format generated the LLM span. This is
    # used by downstream (e.g., UI) to determine the message format for parsing.
    MESSAGE_FORMAT = "mlflow.message.format"
    # This attribute is used to populate `intermediate_outputs` property of a trace data
    # representing intermediate outputs of the trace. This attribute is not empty only on
    # the root span of a trace created by the `mlflow.log_trace` API. The `intermediate_outputs`
    # property of the normal trace is generated by the outputs of non-root spans.
    INTERMEDIATE_OUTPUTS = "mlflow.trace.intermediate_outputs"


class AssessmentMetadataKey:
    # When the assessment is generated by an eval run, log the run ID here.
    SOURCE_RUN_ID = "mlflow.assessment.sourceRunId"
    # Total LLM cost spent for generating the feedback (llm-as-a-judge).
    JUDGE_COST = "mlflow.assessment.judgeCost"
    # When the scorer generates a trace for assessment scoring, log the trace ID here.
    SCORER_TRACE_ID = "mlflow.assessment.scorerTraceId"


# All storage backends are guaranteed to support request_metadata key/value up to 250 characters
MAX_CHARS_IN_TRACE_INFO_METADATA = 250
# All storage backends are guaranteed to support tag keys up to 250 characters,
# values up to 4096 characters
MAX_CHARS_IN_TRACE_INFO_TAGS_KEY = 250
MAX_CHARS_IN_TRACE_INFO_TAGS_VALUE = 4096
TRUNCATION_SUFFIX = "..."

TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_DBX = 10000
TRACE_REQUEST_RESPONSE_PREVIEW_MAX_LENGTH_OSS = 1000

# Trace request ID must have the prefix "tr-" appended to the OpenTelemetry trace ID
TRACE_REQUEST_ID_PREFIX = "tr-"
# Trace ID V4 format starts with "trace:/" in the format of "trace:/<location>/<trace_id>"
TRACE_ID_V4_PREFIX = "trace:/"

# Schema version of traces and spans.
TRACE_SCHEMA_VERSION = 3

# Key for the trace schema version in the trace. This key is also used in
# Databricks model serving to be careful when modifying it.
TRACE_SCHEMA_VERSION_KEY = "mlflow.trace_schema.version"


STREAM_CHUNK_EVENT_NAME_FORMAT = "mlflow.chunk.item.{index}"
STREAM_CHUNK_EVENT_VALUE_KEY = "mlflow.chunk.value"


# Key for Databricks model serving options to return the trace in the response
DATABRICKS_OPTIONS_KEY = "databricks_options"
RETURN_TRACE_OPTION_KEY = "return_trace"
DATABRICKS_OUTPUT_KEY = "databricks_output"

# Assessment constants
ASSESSMENT_ID_PREFIX = "a-"


# Maximum number of seconds to retry getting a trace from the v4 endpoint.
# V4 traces have some delay in propagation after the log_spans call returns success response.
# To make sure get_trace API does not fail due to this delay, we retry up to a reasonable timeout.
# Setting 15 seconds because the initial version of the backend is known to have 1~5 seconds delay.
GET_TRACE_V4_RETRY_TIMEOUT_SECONDS = 15


# The location of the spans in the trace.
# This is used to determine where the spans are stored when exporting.
class SpansLocation(str, Enum):
    TRACKING_STORE = "TRACKING_STORE"
    ARTIFACT_REPO = "ARTIFACT_REPO"


# Path to the notebook trace renderer directory
TRACE_RENDERER_ASSET_PATH = "/static-files/lib/notebook-trace-renderer"
(name: str, context: Optional[opentelemetry.trace.span.SpanContext] = None, parent: Optional[opentelemetry.trace.span.SpanContext] = None, resource: Optional[opentelemetry.sdk.resources.Resource] = None, attributes: Optional[Mapping[str, Union[str, bool, int, float, Sequence[str], Sequence[bool], Sequence[int], Sequence[float]]]] = None, events: Sequence[opentelemetry.sdk.trace.Event] = (), links: Sequence[opentelemetry.trace.Link] = (), kind: opentelemetry.trace.SpanKind = <SpanKind.INTERNAL: 0>, instrumentation_info: Optional[opentelemetry.sdk.util.instrumentation.InstrumentationInfo] = None, status: opentelemetry.trace.status.Status = <opentelemetry.trace.status.Status object at 0x74eaf1024e50>, start_time: Optional[int] = None, end_time: Optional[int] = None, instrumentation_scope: Optional[opentelemetry.sdk.util.instrumentation.InstrumentationScope] = None) -> None
(name: str, attributes: Optional[Mapping[str, Union[str, bool, int, float, Sequence[str], Sequence[bool], Sequence[int], Sequence[float]]]] = None, timestamp: Optional[int] = None, limit: Optional[int] = 128) -> None
```

## 原始行 38 · command_execution

命令：
```
/bin/bash -lc "sed -n '320,420p' tests/entities/test_trace.py; sed -n '1,180p' tests/tracing/utils/test_truncation.py; sed -n '1,180p' tests/tracing/opentelemetry/test_integration.py; sed -n '450,530p' tests/tracing/test_otel_loading.py; grep -R -n \"Span.from_dict_v2\\|_is_span_v2_schema\" tests --include='*.py'"
```

退出码：`1`

输出：
```

    run(2)
    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())

    with pytest.raises(MlflowException, match="Invalid type for 'span_type'"):
        trace.search_spans(span_type=123)

    with pytest.raises(MlflowException, match="Invalid type for 'name'"):
        trace.search_spans(name=123)


def test_from_v2_dict():
    trace = Trace.from_dict(V2_TRACE_DICT)
    assert trace.info.request_id == "58f4e27101304034b15c512b603bf1b2"
    assert trace.info.request_time == 100
    assert trace.info.execution_duration == 200
    assert len(trace.data.spans) == 2

    # Verify that schema version was updated from "2" to current version during V2 to V3 conversion
    assert trace.info.trace_metadata[TRACE_SCHEMA_VERSION_KEY] == "2"

    # Verify that other metadata was preserved
    assert trace.info.trace_metadata["mlflow.traceInputs"] == '{"x": 2, "y": 5}'
    assert trace.info.trace_metadata["mlflow.traceOutputs"] == "8"


def test_request_response_smart_truncation():
    @mlflow.trace
    def f(messages: list[dict[str, Any]]) -> dict[str, Any]:
        return {"choices": [{"message": {"role": "assistant", "content": "Hi!" * 1000}}]}

    # NB: Since MLflow OSS backend still uses v2 tracing schema, the most accurate way to
    # check if the preview is truncated properly is to mock the upload_trace_data call.
    with mock.patch(
        "mlflow.tracing.export.mlflow_v3.TracingClient.start_trace"
    ) as mock_start_trace:
        f([{"role": "user", "content": "Hello!" * 1000}])

    trace_info = mock_start_trace.call_args[0][0]
    assert len(trace_info.request_preview) == 1000
    assert trace_info.request_preview.startswith("Hello!")
    assert len(trace_info.response_preview) == 1000
    assert trace_info.response_preview.startswith("Hi!")


def test_request_response_smart_truncation_non_chat_format():
    # Non-chat request/response will be naively truncated
    @mlflow.trace
    def f(question: str) -> list[str]:
        return ["a" * 5000, "b" * 5000, "c" * 5000]

    with mock.patch(
        "mlflow.tracing.export.mlflow_v3.TracingClient.start_trace"
    ) as mock_start_trace:
        f("start" + "a" * 1000)

    trace_info = mock_start_trace.call_args[0][0]
    assert len(trace_info.request_preview) == 1000
    assert trace_info.request_preview.startswith('{"question": "startaaa')
    assert len(trace_info.response_preview) == 1000
    assert trace_info.response_preview.startswith('["aaaaa')


def test_request_response_custom_truncation():
    @mlflow.trace
    def f(messages: list[dict[str, Any]]) -> dict[str, Any]:
        mlflow.update_current_trace(
            request_preview="custom request preview",
            response_preview="custom response preview",
        )
        return {"choices": [{"message": {"role": "assistant", "content": "Hi!" * 10000}}]}

    with mock.patch(
        "mlflow.tracing.export.mlflow_v3.TracingClient.start_trace"
    ) as mock_start_trace:
        f([{"role": "user", "content": "Hello!" * 10000}])

    trace_info = mock_start_trace.call_args[0][0]
    assert trace_info.request_preview == "custom request preview"
    assert trace_info.response_preview == "custom response preview"


def test_search_assessments():
    assessments = [
        Feedback(
            trace_id="trace_id",
            name="relevance",
            value=False,
            source=AssessmentSource(source_type="HUMAN", source_id="user_1"),
            rationale="The judge is wrong",
            span_id=None,
            overrides="2",
        ),
        Feedback(
            trace_id="trace_id",
            name="relevance",
            value=True,
            source=AssessmentSource(source_type="LLM_JUDGE", source_id="databricks"),
            span_id=None,
            valid=False,
        ),
import json
from unittest.mock import patch

import pytest

from mlflow.tracing.utils.truncation import _get_truncated_preview


@pytest.fixture(autouse=True)
def patch_max_length():
    # Patch max length to 50 to make tests faster
    with patch("mlflow.tracing.utils.truncation._get_max_length", return_value=50):
        yield


@pytest.mark.parametrize(
    ("input_str", "expected"),
    [
        ("short string", "short string"),
        ("{'a': 'b'}", "{'a': 'b'}"),
        ("start" + "a" * 50, "start" + "a" * 42 + "..."),
        (None, ""),
    ],
    ids=["short string", "short json", "long string", "none"],
)
def test_truncate_simple_string(input_str, expected):
    assert _get_truncated_preview(input_str, role="user") == expected


def test_truncate_long_non_message_json():
    input_str = json.dumps(
        {
            "a": "b" + "a" * 30,
            "b": "c" + "a" * 30,
        }
    )
    result = _get_truncated_preview(input_str, role="user")
    assert len(result) == 50
    assert result.startswith('{"a": "b')


_TEST_MESSAGE_HISTORY = [
    {"role": "user", "content": "First"},
    {"role": "assistant", "content": "Second"},
    {"role": "user", "content": "Third" + "a" * 50},
    {"role": "assistant", "content": "Fourth"},
]


@pytest.mark.parametrize(
    "input",
    [
        # ChatCompletion API
        {"messages": _TEST_MESSAGE_HISTORY},
        # Responses API
        {"input": _TEST_MESSAGE_HISTORY},
        # Responses Agent
        {"request": {"input": _TEST_MESSAGE_HISTORY}},
    ],
    ids=["chat_completion", "responses", "responses_agent"],
)
def test_truncate_request_messages(input):
    input_str = json.dumps(input)
    assert _get_truncated_preview(input_str, role="assistant") == "Fourth"
    # Long content should be truncated
    assert _get_truncated_preview(input_str, role="user") == "Third" + "a" * 42 + "..."
    # If non-existing role is provided, return the last message
    assert _get_truncated_preview(input_str, role="system") == "Fourth"


def test_truncate_request_choices():
    input_str = json.dumps(
        {
            "choices": [
                {
                    "index": 1,
                    "message": {"role": "assistant", "content": "First" + "a" * 50},
                    "finish_reason": "stop",
                },
            ],
            "object": "chat.completions",
        }
    )
    assert _get_truncated_preview(input_str, role="assistant").startswith("First")


def test_truncate_multi_content_messages():
    # If text content exists, use it
    assert (
        _get_truncated_preview(
            json.dumps(
                {"messages": [{"role": "user", "content": [{"type": "text", "text": "a" * 60}]}]}
            ),
            role="user",
        )
        == "a" * 47 + "..."
    )

    # Ignore non text content
    assert (
        _get_truncated_preview(
            json.dumps(
                {
                    "messages": [
                        {
                            "role": "user",
                            "content": [
                                {"type": "text", "text": "a" * 60},
                                {"type": "image", "image_url": "http://example.com/image.jpg"},
                            ],
                        },
                    ]
                }
            ),
            role="user",
        )
        == "a" * 47 + "..."
    )

    # If non-text content exists, truncate the full json as-is
    assert _get_truncated_preview(
        json.dumps(
            {
                "messages": [
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "image",
                                "image_url": "http://example.com/image.jpg" + "a" * 50,
                            }
                        ],
                    },
                ]
            }
        ),
        role="user",
    ).startswith('{"messages":')


def test_truncate_responses_api_output():
    input_str = json.dumps(
        {
            "output": [
                {
                    "type": "message",
                    "id": "test",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": "a" * 60}],
                }
            ],
        }
    )

    assert _get_truncated_preview(input_str, role="assistant") == "a" * 47 + "..."


@pytest.mark.parametrize(
    "input_data",
    [
        {"messages": 123, "long_data": "a" * 50},
        {"messages": []},
        {"input": "string"},
        {"output": 123},
        {"choices": {"0": "value"}},
        {"request": "string"},
        {"choices": [{"message": "not a dict"}]},
        {"choices": [{"message": {"role": "user"}}]},
    ],
)
def test_truncate_invalid_messages(input_data):
    input_str = json.dumps(input_data)
    result = _get_truncated_preview(input_str, role="user")
    if "long_data" in input_data:
        assert len(result) == 50
        assert result.startswith(input_str[:20])
    else:
        assert result == input_str


import pytest
from opentelemetry import trace as otel_trace

import mlflow
from mlflow.entities.span import SpanStatusCode, encode_span_id
from mlflow.entities.trace_location import MlflowExperimentLocation
from mlflow.entities.trace_state import TraceState
from mlflow.environment_variables import MLFLOW_USE_DEFAULT_TRACER_PROVIDER
from mlflow.utils.os import is_windows

from tests.tracing.helper import get_traces


@pytest.mark.skipif(is_windows(), reason="Skipping as this is flaky on Windows")
def test_mlflow_and_opentelemetry_unified_tracing_with_otel_root_span(monkeypatch):
    monkeypatch.setenv(MLFLOW_USE_DEFAULT_TRACER_PROVIDER.name, "false")

    # Use set_destination to trigger tracer provider initialization
    experiment_id = mlflow.set_experiment("test_experiment").experiment_id
    mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id))

    otel_tracer = otel_trace.get_tracer(__name__)
    with otel_tracer.start_as_current_span("parent_span") as root_span:
        root_span.set_attribute("key1", "value1")
        root_span.add_event("event1", attributes={"key2": "value2"})

        # Active span id should be set
        assert mlflow.get_current_active_span().span_id == encode_span_id(root_span.context.span_id)

        with mlflow.start_span("mlflow_span") as mlflow_span:
            mlflow_span.set_inputs({"text": "hello"})
            mlflow_span.set_attributes({"key3": "value3"})

            with otel_tracer.start_as_current_span("child_span") as child_span:
                child_span.set_attribute("key4", "value4")
                child_span.set_status(otel_trace.Status(otel_trace.StatusCode.OK))

            mlflow_span.set_outputs({"text": "world"})

        root_span.set_status(otel_trace.Status(otel_trace.StatusCode.OK))

    traces = get_traces()
    assert len(traces) == 1
    trace = traces[0]
    assert trace.info.trace_id.startswith("tr-")  # trace ID should be in MLflow format
    assert trace.info.trace_id == mlflow.get_last_active_trace_id()
    assert trace.info.experiment_id == experiment_id
    assert trace.info.status == TraceState.OK
    assert trace.info.request_time == root_span.start_time // 1_000_000
    assert trace.info.execution_duration == (root_span.end_time - root_span.start_time) // 1_000_000
    assert trace.info.request_preview == ""
    assert trace.info.response_preview == ""

    spans = trace.data.spans
    assert len(spans) == 3
    assert spans[0].name == "parent_span"
    assert spans[0].attributes["key1"] == "value1"
    assert len(spans[0].events) == 1
    assert spans[0].events[0].name == "event1"
    assert spans[0].events[0].attributes["key2"] == "value2"
    assert spans[0].parent_id is None
    assert spans[0].status.status_code == SpanStatusCode.OK
    assert spans[1].name == "mlflow_span"
    assert spans[1].attributes["key3"] == "value3"
    assert spans[1].events == []
    assert spans[1].parent_id == spans[0].span_id
    assert spans[1].status.status_code == SpanStatusCode.OK
    assert spans[2].name == "child_span"
    assert spans[2].attributes["key4"] == "value4"
    assert spans[2].events == []
    assert spans[2].parent_id == spans[1].span_id
    assert spans[2].status.status_code == SpanStatusCode.OK


@pytest.mark.skipif(is_windows(), reason="Skipping as this is flaky on Windows")
def test_mlflow_and_opentelemetry_unified_tracing_with_mlflow_root_span(monkeypatch):
    monkeypatch.setenv(MLFLOW_USE_DEFAULT_TRACER_PROVIDER.name, "false")

    experiment_id = mlflow.set_experiment("test_experiment").experiment_id

    otel_tracer = otel_trace.get_tracer(__name__)
    with mlflow.start_span("mlflow_span") as mlflow_span:
        mlflow_span.set_inputs({"text": "hello"})

        with otel_tracer.start_as_current_span("otel_span") as otel_span:
            otel_span.set_attributes({"key3": "value3"})
            otel_span.set_status(otel_trace.Status(otel_trace.StatusCode.OK))

            with mlflow.start_span("child_span") as child_span:
                child_span.set_attribute("key4", "value4")

        mlflow_span.set_outputs({"text": "world"})

    traces = get_traces()
    assert len(traces) == 1
    trace = traces[0]
    assert trace.info.trace_id.startswith("tr-")  # trace ID should be in MLflow format
    assert trace.info.trace_id == mlflow.get_last_active_trace_id()
    assert trace.info.experiment_id == experiment_id
    assert trace.info.status == TraceState.OK
    assert trace.info.request_time == mlflow_span.start_time_ns // 1_000_000
    assert (
        trace.info.execution_duration
        == (mlflow_span.end_time_ns - mlflow_span.start_time_ns) // 1_000_000
    )
    assert trace.info.request_preview == '{"text": "hello"}'
    assert trace.info.response_preview == '{"text": "world"}'

    spans = trace.data.spans
    assert len(spans) == 3
    assert spans[0].name == "mlflow_span"
    assert spans[0].inputs == {"text": "hello"}
    assert spans[0].outputs == {"text": "world"}
    assert spans[0].status.status_code == SpanStatusCode.OK
    assert spans[1].name == "otel_span"
    assert spans[1].attributes["key3"] == "value3"
    assert spans[1].events == []
    assert spans[1].parent_id == spans[0].span_id
    assert spans[1].status.status_code == SpanStatusCode.OK
    assert spans[2].name == "child_span"
    assert spans[2].attributes["key4"] == "value4"
    assert spans[2].events == []
    assert spans[2].parent_id == spans[1].span_id
    assert spans[2].status.status_code == SpanStatusCode.OK


def test_mlflow_and_opentelemetry_isolated_tracing(monkeypatch):
    monkeypatch.setenv(MLFLOW_USE_DEFAULT_TRACER_PROVIDER.name, "true")

    experiment_id = mlflow.set_experiment("test_experiment").experiment_id

    otel_tracer = otel_trace.get_tracer(__name__)

    with otel_tracer.start_as_current_span("parent_span") as root_span:
        root_span.set_attribute("key1", "value1")

    with mlflow.start_span("mlflow_span") as mlflow_span:
        mlflow_span.set_inputs({"text": "hello"})
        mlflow_span.set_outputs({"text": "world"})

    traces = get_traces()
    assert len(traces) == 1
    trace = traces[0]
    assert trace is not None
    assert trace.info.experiment_id == experiment_id
    assert trace.info.trace_id.startswith("tr-")  # trace ID should be in MLflow format
    assert trace.info.status == TraceState.OK
    assert trace.info.request_time == mlflow_span.start_time_ns // 1_000_000
    assert (
        trace.info.execution_duration
        == (mlflow_span.end_time_ns - mlflow_span.start_time_ns) // 1_000_000
    )
    assert trace.info.request_preview == '{"text": "hello"}'
    assert trace.info.response_preview == '{"text": "world"}'

    spans = trace.data.spans
    assert len(spans) == 1
    assert spans[0].name == "mlflow_span"
    assert spans[0].inputs == {"text": "hello"}
    assert spans[0].outputs == {"text": "world"}
    assert spans[0].status.status_code == SpanStatusCode.OK
    tracer = create_tracer(mlflow_server, experiment_id, "span-kind-translation-test-service")

    with tracer.start_as_current_span("llm-call") as span:
        span.set_attribute(OpenInferenceTranslator.SPAN_KIND_ATTRIBUTE_KEY, "LLM")

    with tracer.start_as_current_span("retriever-call") as span:
        span.set_attribute(OpenInferenceTranslator.SPAN_KIND_ATTRIBUTE_KEY, "RETRIEVER")

    with tracer.start_as_current_span("tool-call") as span:
        span.set_attribute(TraceloopTranslator.SPAN_KIND_ATTRIBUTE_KEY, "tool")

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )

    assert len(traces) == 3
    for trace_info in traces:
        retrieved_trace = mlflow.get_trace(trace_info.info.trace_id)
        for span in retrieved_trace.data.spans:
            if span.name == "llm-call":
                assert span.span_type == "LLM"
            elif span.name == "retriever-call":
                assert span.span_type == "RETRIEVER"
            elif span.name == "tool-call":
                assert span.span_type == "TOOL"


@pytest.mark.parametrize(
    "translator", [GenAiTranslator, OpenInferenceTranslator, TraceloopTranslator]
)
def test_span_inputs_outputs_translation(
    mlflow_server: str, is_async, translator: OtelSchemaTranslator
):
    experiment = mlflow.set_experiment("span-inputs-outputs-translation-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(
        mlflow_server, experiment_id, "span-inputs-outputs-translation-test-service"
    )

    with tracer.start_as_current_span("llm-call") as span:
        span.set_attribute(translator.INPUT_VALUE_KEYS[0], "Hello, world!")
        span.set_attribute(translator.OUTPUT_VALUE_KEYS[0], "Bye!")

    if is_async:
        _flush_async_logging()

    traces = mlflow.search_traces(
        experiment_ids=[experiment_id], include_spans=False, return_type="list"
    )
    assert len(traces) == 1
    retrieved_trace = mlflow.get_trace(traces[0].info.trace_id)
    assert retrieved_trace.data.spans[0].inputs == "Hello, world!"
    assert retrieved_trace.data.spans[0].outputs == "Bye!"
    assert retrieved_trace.info.request_preview == '"Hello, world!"'
    assert retrieved_trace.info.response_preview == '"Bye!"'


@pytest.mark.parametrize(
    "translator", [GenAiTranslator, OpenInferenceTranslator, TraceloopTranslator]
)
def test_span_token_usage_translation(
    mlflow_server: str, is_async, translator: OtelSchemaTranslator
):
    experiment = mlflow.set_experiment("span-token-usage-translation-test")
    experiment_id = experiment.experiment_id

    tracer = create_tracer(
        mlflow_server, experiment_id, "span-token-usage-translation-test-service"
    )

    with tracer.start_as_current_span("llm-call") as span:
        span.set_attribute(translator.INPUT_TOKEN_KEY, 100)
        span.set_attribute(translator.OUTPUT_TOKEN_KEY, 50)

    if is_async:
        _flush_async_logging()
```

## 原始行 41 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"V2_TRACE_DICT\" tests/entities/test_trace.py; sed -n '1,150p' tests/entities/test_trace.py; grep -R -n '\"request_id\".*\"span_id\"\\|span_id.*request_id' tests --include='*.json' --include='*.py' | head -100"
```

退出码：`0`

输出：
```
34:    V2_TRACE_DICT,
332:    trace = Trace.from_dict(V2_TRACE_DICT)
import importlib
import importlib.util
import json
import re
from datetime import datetime
from typing import Any
from unittest import mock

import pytest

import mlflow
import mlflow.tracking.context.default_context
from mlflow.entities import (
    AssessmentSource,
    Feedback,
    SpanType,
    Trace,
    TraceData,
    TraceInfo,
    TraceLocation,
)
from mlflow.entities.assessment import Expectation
from mlflow.entities.trace_state import TraceState
from mlflow.environment_variables import MLFLOW_TRACKING_USERNAME
from mlflow.exceptions import MlflowException
from mlflow.tracing.constant import TRACE_SCHEMA_VERSION_KEY
from mlflow.tracing.utils import TraceJSONEncoder
from mlflow.utils.mlflow_tags import MLFLOW_ARTIFACT_LOCATION
from mlflow.utils.proto_json_utils import (
    milliseconds_to_proto_timestamp,
)

from tests.tracing.helper import (
    V2_TRACE_DICT,
    create_test_trace_info,
    create_test_trace_info_with_uc_table,
)


def _test_model(datetime=datetime.now()):
    class TestModel:
        @mlflow.trace()
        def predict(self, x, y):
            z = x + y
            z = self.add_one(z)
            return z  # noqa: RET504

        @mlflow.trace(
            span_type=SpanType.LLM,
            name="add_one_with_custom_name",
            attributes={
                "delta": 1,
                "metadata": {"foo": "bar"},
                # Test for non-json-serializable input
                "datetime": datetime,
            },
        )
        def add_one(self, z):
            return z + 1

    return TestModel()


def test_json_deserialization(monkeypatch):
    monkeypatch.setattr(mlflow.tracking.context.default_context, "_get_source_name", lambda: "test")
    monkeypatch.setenv(MLFLOW_TRACKING_USERNAME.name, "bob")
    datetime_now = datetime.now()

    model = _test_model(datetime_now)
    model.predict(2, 5)

    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())
    trace_json = trace.to_json()

    trace_json_as_dict = json.loads(trace_json)
    assert trace_json_as_dict == {
        "info": {
            "trace_id": trace.info.request_id,
            "trace_location": {
                "mlflow_experiment": {
                    "experiment_id": "0",
                },
                "type": "MLFLOW_EXPERIMENT",
            },
            "request_time": milliseconds_to_proto_timestamp(trace.info.timestamp_ms),
            "execution_duration_ms": trace.info.execution_time_ms,
            "state": "OK",
            "request_preview": '{"x": 2, "y": 5}',
            "response_preview": "8",
            "trace_metadata": {
                "mlflow.traceInputs": '{"x": 2, "y": 5}',
                "mlflow.traceOutputs": "8",
                "mlflow.source.name": mock.ANY,
                "mlflow.source.type": "LOCAL",
                "mlflow.source.git.branch": mock.ANY,
                "mlflow.source.git.commit": mock.ANY,
                "mlflow.source.git.repoURL": mock.ANY,
                "mlflow.user": mock.ANY,
                "mlflow.trace.sizeBytes": mock.ANY,
                "mlflow.trace.sizeStats": mock.ANY,
                "mlflow.trace_schema.version": "3",
            },
            "tags": {
                "mlflow.traceName": "predict",
                "mlflow.artifactLocation": trace.info.tags[MLFLOW_ARTIFACT_LOCATION],
                "mlflow.trace.spansLocation": mock.ANY,
            },
        },
        "data": {
            "spans": [
                {
                    "name": "predict",
                    "trace_id": mock.ANY,
                    "span_id": mock.ANY,
                    "parent_span_id": None,
                    "start_time_unix_nano": trace.data.spans[0].start_time_ns,
                    "end_time_unix_nano": trace.data.spans[0].end_time_ns,
                    "events": [],
                    "status": {
                        "code": "STATUS_CODE_OK",
                        "message": "",
                    },
                    "attributes": {
                        "mlflow.traceRequestId": json.dumps(trace.info.request_id),
                        "mlflow.spanType": '"UNKNOWN"',
                        "mlflow.spanFunctionName": '"predict"',
                        "mlflow.spanInputs": '{"x": 2, "y": 5}',
                        "mlflow.spanOutputs": "8",
                    },
                },
                {
                    "name": "add_one_with_custom_name",
                    "trace_id": mock.ANY,
                    "span_id": mock.ANY,
                    "parent_span_id": mock.ANY,
                    "start_time_unix_nano": trace.data.spans[1].start_time_ns,
                    "end_time_unix_nano": trace.data.spans[1].end_time_ns,
                    "events": [],
                    "status": {
                        "code": "STATUS_CODE_OK",
                        "message": "",
                    },
                    "attributes": {
                        "mlflow.traceRequestId": json.dumps(trace.info.request_id),
                        "mlflow.spanType": '"LLM"',
                        "mlflow.spanFunctionName": '"add_one"',
                        "mlflow.spanInputs": '{"z": 7}',
                        "mlflow.spanOutputs": "8",
                        "delta": "1",
                        "datetime": json.dumps(str(datetime_now)),
tests/tracing/test_trace_manager.py:214:    assert trace_manager.get_root_span_id(request_id_1) == span_1_1.span_id
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc 'grep -n "V2_TRACE_DICT" -A130 -B5 tests/tracing/helper.py'
```

退出码：`0`

输出：
```
252-            "Skipping test because it requires mlflow or mlflow-skinny to be installed.",
253-            allow_module_level=True,
254-        )
255-
256-
257:V2_TRACE_DICT = {
258-    "info": {
259-        "request_id": "58f4e27101304034b15c512b603bf1b2",
260-        "experiment_id": "0",
261-        "timestamp_ms": 100,
262-        "execution_time_ms": 200,
263-        "status": "OK",
264-        "request_metadata": {
265-            "mlflow.trace_schema.version": "2",
266-            "mlflow.traceInputs": '{"x": 2, "y": 5}',
267-            "mlflow.traceOutputs": "8",
268-        },
269-        "tags": {
270-            "mlflow.source.name": "test",
271-            "mlflow.source.type": "LOCAL",
272-            "mlflow.traceName": "predict",
273-            "mlflow.artifactLocation": "/path/to/artifact",
274-        },
275-        "assessments": [],
276-    },
277-    "data": {
278-        "spans": [
279-            {
280-                "name": "predict",
281-                "context": {
282-                    "span_id": "0d48a6670588966b",
283-                    "trace_id": "63076d0c1b90f1df0970f897dc428bd6",
284-                },
285-                "parent_id": None,
286-                "start_time": 100,
287-                "end_time": 200,
288-                "status_code": "OK",
289-                "status_message": "",
290-                "attributes": {
291-                    "mlflow.traceRequestId": '"58f4e27101304034b15c512b603bf1b2"',
292-                    "mlflow.spanType": '"UNKNOWN"',
293-                    "mlflow.spanFunctionName": '"predict"',
294-                    "mlflow.spanInputs": '{"x": 2, "y": 5}',
295-                    "mlflow.spanOutputs": "8",
296-                },
297-                "events": [],
298-            },
299-            {
300-                "name": "add_one_with_custom_name",
301-                "context": {
302-                    "span_id": "6fc32f36ef591f60",
303-                    "trace_id": "63076d0c1b90f1df0970f897dc428bd6",
304-                },
305-                "parent_id": "0d48a6670588966b",
306-                "start_time": 300,
307-                "end_time": 400,
308-                "status_code": "OK",
309-                "status_message": "",
310-                "attributes": {
311-                    "mlflow.traceRequestId": '"58f4e27101304034b15c512b603bf1b2"',
312-                    "mlflow.spanType": '"LLM"',
313-                    "delta": "1",
314-                    "metadata": '{"foo": "bar"}',
315-                    "datetime": '"2025-04-29 08:37:06.772253"',
316-                    "mlflow.spanFunctionName": '"add_one"',
317-                    "mlflow.spanInputs": '{"z": 7}',
318-                    "mlflow.spanOutputs": "8",
319-                },
320-                "events": [],
321-            },
322-        ],
323-        "request": '{"x": 2, "y": 5}',
324-        "response": "8",
325-    },
326-}
```

## 原始行 48 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"def apply_span_processors\\|apply_span_processors\" mlflow | head -30; grep -R -n \"def .*span_processor\" mlflow/tracing | head; python - <<'PY'
from tests.tracing.helper import create_mock_otel_span
from opentelemetry.sdk.trace import ReadableSpan, Span
from opentelemetry.trace import Span as APISpan
s=create_mock_otel_span()
print(type(s), isinstance(s, ReadableSpan), isinstance(s, APISpan))
print(type(s).__mro__)
PY"
```

退出码：`1`

输出：
```
mlflow/entities/span.py:654:            apply_span_processors(self)
mlflow/tracing/provider.py:418:def _get_span_processors(disabled: bool = False) -> list[SpanProcessor]:
mlflow/tracing/provider.py:490:def _get_mlflow_span_processor(tracking_uri: str):
mlflow/tracing/utils/processor.py:35:def validate_span_processors(span_processors):
Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
TypeError: create_mock_otel_span() missing 2 required positional arguments: 'trace_id' and 'span_id'
```

## 原始行 51 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,220p' mlflow/tracing/utils/processor.py; grep -R -n \"apply_span\" mlflow tests | head -50; python - <<'PY'
from tests.tracing.helper import create_mock_otel_span
from opentelemetry.sdk.trace import ReadableSpan
from opentelemetry.trace import Span as APISpan
s=create_mock_otel_span(1,2)
print(type(s), isinstance(s, ReadableSpan), isinstance(s, APISpan), type(s).__mro__)
PY
sed -n '1,120p' tests/tracing/utils/test_processor.py"
```

退出码：`0`

输出：
```
import logging

from mlflow.exceptions import MlflowException

_logger = logging.getLogger(__name__)





























def validate_span_processors(span_processors):
    """Validate that the span processor is a valid function."""
    span_processors = span_processors or []

    for span_processor in span_processors:
        if not callable(span_processor):
            raise MlflowException.invalid_parameter_value(
                "Span processor must be a callable function."
            )

        # Skip validation for builtin functions and partial functions that don't have __code__
        if not hasattr(span_processor, "__code__"):
            continue

        if span_processor.__code__.co_argcount != 1:
            raise MlflowException.invalid_parameter_value(
                "Span processor must take exactly one argument that accepts a LiveSpan object."
            )

    return span_processorsgrep: mlflow/entities/__pycache__/span.cpython-311.pyc: binary file matches
mlflow/entities/span.py:654:            apply_span_processors(self)
tests/tracing/utils/test_processor.py:51:def test_apply_span_processors_multiple_processors_success():
tests/tracing/utils/test_processor.py:73:def test_apply_span_processors_returns_non_none_warning():
tests/tracing/utils/test_processor.py:96:def test_apply_span_processors_exception_handling():
<class 'tests.tracing.helper.create_mock_otel_span.<locals>._MockOTelSpan'> True True (<class 'tests.tracing.helper.create_mock_otel_span.<locals>._MockOTelSpan'>, <class 'opentelemetry.trace.span.Span'>, <class 'abc.ABC'>, <class 'opentelemetry.sdk.trace.ReadableSpan'>, <class 'object'>)
from unittest.mock import patch

import pytest

import mlflow
from mlflow.exceptions import MlflowException
from mlflow.tracing.utils.processor import validate_span_processors

from tests.tracing.helper import get_traces


@mlflow.trace
def predict(text: str):
    return "Answer: " + text


@pytest.fixture(autouse=True)
def reset_tracing_config():
    """Reset tracing configuration before each test."""
    mlflow.tracing.reset()


def test_span_processors_no_processors_configured():
    """Test that function returns early when no processors are configured."""
    mlflow.tracing.configure(span_processors=[])

    predict("test")

    span = get_traces()[0].data.spans[0]
    assert span.inputs == {"text": "test"}
    assert span.outputs == "Answer: test"


def test_span_processors_single_processor_success():
    """Test successful execution of a single processor."""

    def test_processor(span):
        span.set_outputs("overridden_output")
        span.set_attribute("test_attribute", "test_value")

    mlflow.tracing.configure(span_processors=[test_processor])

    predict("test")

    span = get_traces()[0].data.spans[0]
    assert span.inputs == {"text": "test"}
    assert span.outputs == "overridden_output"
    assert span.attributes["test_attribute"] == "test_value"


def test_apply_span_processors_multiple_processors_success():
    """Test successful execution of multiple processors in sequence."""

    def processor1(span):
        span.set_outputs("overridden_output_1")
        span.set_attribute("attr_1", "value_1")

    def processor2(span):
        span.set_outputs("overridden_output_2")
        span.set_attribute("attr_2", "value_2")

    mlflow.tracing.configure(span_processors=[processor1, processor2])

    predict("test")

    span = get_traces()[0].data.spans[0]
    assert span.inputs == {"text": "test"}
    assert span.outputs == "overridden_output_2"
    assert span.attributes["attr_1"] == "value_1"
    assert span.attributes["attr_2"] == "value_2"


def test_apply_span_processors_returns_non_none_warning():
    """Test warning is logged when processor returns a non-None value."""

    def bad_processor(span):
        return "some_value"  # Should return nothing

    def good_processor(span):
        span.set_outputs("overridden_output")

    with patch("mlflow.tracing.utils.processor._logger") as mock_logger:
        mlflow.tracing.configure(span_processors=[bad_processor, good_processor])

        predict("test")

    mock_logger.warning.assert_called_once()
    message = mock_logger.warning.call_args[0][0]
    assert message.startswith("Span processors ['bad_processor'] returned a non-null value")

    # Other processors should still be applied
    span = get_traces()[0].data.spans[0]
    assert span.outputs == "overridden_output"


def test_apply_span_processors_exception_handling():
    """Test that processor exceptions are caught and logged."""

    def failing_processor(span):
        raise ValueError("Test error")

    def good_processor(span):
        span.set_outputs("overridden_output")

    with patch("mlflow.tracing.utils.processor._logger") as mock_logger:
        mlflow.tracing.configure(span_processors=[failing_processor, good_processor])

        predict("test")

    span = get_traces()[0].data.spans[0]
    assert span.outputs == "overridden_output"
    mock_logger.warning.assert_called_once()
    message = mock_logger.warning.call_args[0][0]
    assert message.startswith("Span processor failing_processor failed")


def test_validate_span_processors_empty_input():
    assert validate_span_processors(None) == []
    assert validate_span_processors([]) == []
```

## 原始行 54 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"span_processors\" mlflow/tracing | head -100; sed -n '1,240p' mlflow/tracing/configure.py 2>/dev/null || true; grep -R -n \"class TracingConfig\\|def configure\" mlflow/tracing | head -50; find mlflow/tracing -maxdepth 2 -type f | sort | grep config"
```

退出码：`0`

输出：
```
grep: mlflow/tracing/__pycache__/config.cpython-311.pyc: binary file matches
grep: mlflow/tracing/__pycache__/provider.cpython-311.pyc: binary file matches
grep: mlflow/tracing/utils/__pycache__/processor.cpython-311.pyc: binary file matches
mlflow/tracing/provider.py:343:        processors = tracer_provider._active_span_processor._span_processors
mlflow/tracing/provider.py:357:    processors = _get_span_processors(disabled=disabled)
mlflow/tracing/provider.py:418:def _get_span_processors(disabled: bool = False) -> list[SpanProcessor]:
mlflow/tracing/utils/processor.py:35:def validate_span_processors(span_processors):
mlflow/tracing/utils/processor.py:37:    span_processors = span_processors or []
mlflow/tracing/utils/processor.py:39:    for span_processor in span_processors:
mlflow/tracing/utils/processor.py:54:    return span_processors
mlflow/tracing/config.py:4:from mlflow.tracing.utils.processor import validate_span_processors
mlflow/tracing/config.py:17:    span_processors: list[Callable[["LiveSpan"], None]] = field(default_factory=list)
mlflow/tracing/config.py:20:        self.span_processors = validate_span_processors(self.span_processors)
mlflow/tracing/config.py:66:    span_processors: list[Callable[["LiveSpan"], None]] | None = None,
mlflow/tracing/config.py:74:        span_processors: List of functions to process spans before export.
mlflow/tracing/config.py:112:            mlflow.tracing.configure(span_processors=[pii_filter])
mlflow/tracing/config.py:115:            with mlflow.tracing.configure(span_processors=[pii_filter]):
mlflow/tracing/config.py:121:    if span_processors is not None:
mlflow/tracing/config.py:122:        config_updates["span_processors"] = span_processors
mlflow/tracing/config.py:12:class TracingConfig:
mlflow/tracing/config.py:27:class TracingConfigContext:
mlflow/tracing/config.py:65:def configure(
mlflow/tracing/__pycache__/config.cpython-311.pyc
mlflow/tracing/config.py
```

## 原始行 56 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,170p' mlflow/tracing/config.py; grep -R -n \"get_config\" mlflow/tracing | head -40"
```

退出码：`0`

输出：
```
from dataclasses import dataclass, field, replace
from typing import TYPE_CHECKING, Any, Callable

from mlflow.tracing.utils.processor import validate_span_processors
from mlflow.utils.annotations import experimental

if TYPE_CHECKING:
    from mlflow.entities.span import LiveSpan


@dataclass
class TracingConfig:
    """Configuration for MLflow tracing behavior."""

    # TODO: Move more configuration options here, such as async logging, display, etc.
    # A list of functions to process spans before export.
    span_processors: list[Callable[["LiveSpan"], None]] = field(default_factory=list)

    def __post_init__(self):
        self.span_processors = validate_span_processors(self.span_processors)


# Global configuration instance for tracing
_MLFLOW_TRACING_CONFIG = TracingConfig()


class TracingConfigContext:
    """Context manager for temporary tracing configuration changes."""

    def __init__(self, config_updates: dict[str, Any]):
        self.config_updates = config_updates
        # Create a shallow copy of the current config
        self.previous_config = replace(_MLFLOW_TRACING_CONFIG)

        for key, value in self.config_updates.items():
            setattr(_MLFLOW_TRACING_CONFIG, key, value)

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        global _MLFLOW_TRACING_CONFIG
        _MLFLOW_TRACING_CONFIG = self.previous_config












def reset_config():
    """
    Reset the tracing configuration to defaults.
    """
    global _MLFLOW_TRACING_CONFIG
    _MLFLOW_TRACING_CONFIG = TracingConfig()


@experimental(version="3.2.0")
def configure(
    span_processors: list[Callable[["LiveSpan"], None]] | None = None,
) -> TracingConfigContext:
    """
    Configure MLflow tracing. Can be used as function or context manager.

    Only updates explicitly provided arguments, leaving others unchanged.

    Args:
        span_processors: List of functions to process spans before export.
            This is helpful for filtering/masking particular attributes from the span to
            prevent sensitive data from being logged or for reducing the size of the span.
            Each function must accept a single argument of type LiveSpan and should not
            return any value. When multiple functions are provided, they are applied
            sequentially in the order they are provided.

    Returns:
        TracingConfigContext: Context manager for temporary configuration changes.
            When used as a function, the configuration changes persist.
            When used as a context manager, changes are reverted on exit.

    Examples:

        .. code-block:: python

            def pii_filter(span):
                \"\"\"Example PII filter that masks sensitive data in span attributes.\"\"\"
                # Mask sensitive inputs
                if inputs := span.inputs:
                    for key, value in inputs.items():
                        if "password" in key.lower() or "token" in key.lower():
                            span.set_inputs({**inputs, key: "[REDACTED]"})

                # Mask sensitive outputs
                if outputs := span.outputs:
                    if isinstance(outputs, dict):
                        for key in outputs:
                            if "secret" in key.lower():
                                outputs[key] = "[REDACTED]"
                        span.set_outputs(outputs)

                # Mask sensitive attributes
                for attr_key in list(span.attributes.keys()):
                    if "api_key" in attr_key.lower():
                        span.set_attribute(attr_key, "[REDACTED]")

            # Permanent configuration change
            mlflow.tracing.configure(span_processors=[pii_filter])

            # Temporary configuration change
            with mlflow.tracing.configure(span_processors=[pii_filter]):
                # PII filtering enabled only in this block
                pass
    """
    # Collect only the arguments that were explicitly provided
    config_updates = {}
    if span_processors is not None:
        config_updates["span_processors"] = span_processors

    # Return TracingConfigContext which handles both function and context manager usage
    return TracingConfigContext(config_updates)
```

## 原始行 59 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from opentelemetry.trace import NonRecordingSpan
try:
 s=NonRecordingSpan(context=None); print('ok',s)
except Exception as e: print(type(e),e)
PY"
```

退出码：`0`

输出：
```
ok NonRecordingSpan(None)
```

## 原始行 62 · file_change

```
{
  "id": "item_39",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/span.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 65 · file_change

```
{
  "id": "item_41",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/span.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 68 · file_change

```
{
  "id": "item_43",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracing/utils/otlp.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 71 · file_change

```
{
  "id": "item_45",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracing/trace_manager.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 74 · file_change

```
{
  "id": "item_47",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracing/utils/truncation.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 77 · file_change

```
{
  "id": "item_49",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/span_status.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/entities/trace_data.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracing/utils/processor.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 79 · agent_message

```
The main interfaces are now implemented, including v2/v3 dictionary round-trips, OTLP conversion, live-to-immutable transitions, no-op behavior, and preview population. I also restored the masked status/preview/processor helpers those paths call; I’m running focused tests now to catch version-specific OpenTelemetry details.
```

## 原始行 81 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/entities/test_span_status.py tests/entities/test_span_event.py tests/tracing/utils/test_truncation.py tests/tracing/test_trace_manager.py tests/entities/test_trace_data.py'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 61 items

tests/entities/test_span_status.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                       [ 24%][0m
tests/entities/test_span_event.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                  [ 32%][0m
tests/tracing/utils/test_truncation.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m         [ 73%][0m
tests/tracing/test_trace_manager.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                           [ 90%][0m
tests/entities/test_trace_data.py [31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31m                                 [100%][0m

=================================== FAILURES ===================================
[31m[1m___ test_otel_status_to_mlflow_status_conversion[StatusCode.OK-Success-OK-] ____[0m

status_code = <StatusCode.OK: 1>, status_desc = 'Success'
expected_code = <SpanStatusCode.OK: 'OK'>, expected_desc = ''

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        ([33m"[39;49;00m[33mstatus_code[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mstatus_desc[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mexpected_code[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mexpected_desc[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        [[90m[39;49;00m
            [90m# OTel only keeps description for ERROR status[39;49;00m[90m[39;49;00m
            (OTelStatusCode.OK, [33m"[39;49;00m[33mSuccess[39;49;00m[33m"[39;49;00m, SpanStatusCode.OK, [33m"[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            (OTelStatusCode.ERROR, [33m"[39;49;00m[33mFailed[39;49;00m[33m"[39;49;00m, SpanStatusCode.ERROR, [33m"[39;49;00m[33mFailed[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            (OTelStatusCode.UNSET, [33m"[39;49;00m[33m"[39;49;00m, SpanStatusCode.UNSET, [33m"[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_otel_status_to_mlflow_status_conversion[39;49;00m([90m[39;49;00m
        status_code, status_desc, expected_code, expected_desc[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Test conversion from OTel SDK status to MLflow SpanStatus."""[39;49;00m[90m[39;49;00m
        [90m# Create OTel status[39;49;00m[90m[39;49;00m
        otel_status = OTelStatus(status_code, status_desc)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Convert to MLflow status[39;49;00m[90m[39;49;00m
        mlflow_status = SpanStatus.from_otel_status(otel_status)[90m[39;49;00m
        [94massert[39;49;00m mlflow_status.status_code == expected_code[90m[39;49;00m
        [90m# OTel SDK clears description for non-ERROR statuses[39;49;00m[90m[39;49;00m
        [94massert[39;49;00m mlflow_status.description == (status_desc [94mif[39;49;00m status_code == OTelStatusCode.ERROR [94melse[39;49;00m [33m"[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Convert back to OTel status[39;49;00m[90m[39;49;00m
        converted_status = mlflow_status.to_otel_status()[90m[39;49;00m
        [94massert[39;49;00m converted_status.status_code == status_code[90m[39;49;00m
        [90m# Description is only preserved for ERROR status[39;49;00m[90m[39;49;00m
>       [94massert[39;49;00m converted_status.description == expected_desc[90m[39;49;00m
[1m[31mE       AssertionError: assert None == ''[0m
[1m[31mE        +  where None = <opentelemetry.trace.status.Status object at 0x7de4fabafc10>.description[0m

converted_status = <opentelemetry.trace.status.Status object at 0x7de4fabafc10>
expected_code = <SpanStatusCode.OK: 'OK'>
expected_desc = ''
mlflow_status = SpanStatus(status_code=<SpanStatusCode.OK: 'OK'>, description='')
otel_status = <opentelemetry.trace.status.Status object at 0x7de4fabad810>
status_code = <StatusCode.OK: 1>
status_desc = 'Success'

[1m[31mtests/entities/test_span_status.py[0m:72: AssertionError
------------------------------ Captured log call -------------------------------
[33mWARNING [0m opentelemetry.trace.status:status.py:57 description should only be set when status_code is set to StatusCode.ERROR
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:38:48 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m____ test_otel_status_to_mlflow_status_conversion[StatusCode.UNSET--UNSET-] ____[0m

status_code = <StatusCode.UNSET: 0>, status_desc = ''
expected_code = <SpanStatusCode.UNSET: 'UNSET'>, expected_desc = ''

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        ([33m"[39;49;00m[33mstatus_code[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mstatus_desc[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mexpected_code[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mexpected_desc[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        [[90m[39;49;00m
            [90m# OTel only keeps description for ERROR status[39;49;00m[90m[39;49;00m
            (OTelStatusCode.OK, [33m"[39;49;00m[33mSuccess[39;49;00m[33m"[39;49;00m, SpanStatusCode.OK, [33m"[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            (OTelStatusCode.ERROR, [33m"[39;49;00m[33mFailed[39;49;00m[33m"[39;49;00m, SpanStatusCode.ERROR, [33m"[39;49;00m[33mFailed[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
            (OTelStatusCode.UNSET, [33m"[39;49;00m[33m"[39;49;00m, SpanStatusCode.UNSET, [33m"[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_otel_status_to_mlflow_status_conversion[39;49;00m([90m[39;49;00m
        status_code, status_desc, expected_code, expected_desc[90m[39;49;00m
    ):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Test conversion from OTel SDK status to MLflow SpanStatus."""[39;49;00m[90m[39;49;00m
        [90m# Create OTel status[39;49;00m[90m[39;49;00m
        otel_status = OTelStatus(status_code, status_desc)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Convert to MLflow status[39;49;00m[90m[39;49;00m
        mlflow_status = SpanStatus.from_otel_status(otel_status)[90m[39;49;00m
        [94massert[39;49;00m mlflow_status.status_code == expected_code[90m[39;49;00m
        [90m# OTel SDK clears description for non-ERROR statuses[39;49;00m[90m[39;49;00m
        [94massert[39;49;00m mlflow_status.description == (status_desc [94mif[39;49;00m status_code == OTelStatusCode.ERROR [94melse[39;49;00m [33m"[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Convert back to OTel status[39;49;00m[90m[39;49;00m
        converted_status = mlflow_status.to_otel_status()[90m[39;49;00m
        [94massert[39;49;00m converted_status.status_code == status_code[90m[39;49;00m
        [90m# Description is only preserved for ERROR status[39;49;00m[90m[39;49;00m
>       [94massert[39;49;00m converted_status.description == expected_desc[90m[39;49;00m
[1m[31mE       AssertionError: assert None == ''[0m
[1m[31mE        +  where None = <opentelemetry.trace.status.Status object at 0x7de4fabaef90>.description[0m

converted_status = <opentelemetry.trace.status.Status object at 0x7de4fabaef90>
expected_code = <SpanStatusCode.UNSET: 'UNSET'>
expected_desc = ''
mlflow_status = SpanStatus(status_code=<SpanStatusCode.UNSET: 'UNSET'>, description='')
otel_status = <opentelemetry.trace.status.Status object at 0x7de4fabafe10>
status_code = <StatusCode.UNSET: 0>
status_desc = ''

[1m[31mtests/entities/test_span_status.py[0m:72: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:38:48 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m__________________________ test_json_deserialization ___________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_json_deserialization[39;49;00m():[90m[39;49;00m
        [94mclass[39;49;00m[90m [39;49;00m[04m[92mTestModel[39;49;00m:[90m[39;49;00m
            [37m@mlflow[39;49;00m.trace()[90m[39;49;00m
            [94mdef[39;49;00m[90m [39;49;00m[92mpredict[39;49;00m([96mself[39;49;00m, x, y):[90m[39;49;00m
                z = x + y[90m[39;49;00m
    [90m[39;49;00m
                [94mwith[39;49;00m mlflow.start_span(name=[33m"[39;49;00m[33mwith_ok_event[39;49;00m[33m"[39;49;00m) [94mas[39;49;00m span:[90m[39;49;00m
                    span.add_event(SpanEvent(name=[33m"[39;49;00m[33mok_event[39;49;00m[33m"[39;49;00m, attributes={[33m"[39;49;00m[33mfoo[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mbar[39;49;00m[33m"[39;49;00m}))[90m[39;49;00m
    [90m[39;49;00m
                [96mself[39;49;00m.always_fail()[90m[39;49;00m
                [94mreturn[39;49;00m z[90m[39;49;00m
    [90m[39;49;00m
            [37m@mlflow[39;49;00m.trace(span_type=SpanType.LLM, name=[33m"[39;49;00m[33malways_fail_name[39;49;00m[33m"[39;49;00m, attributes={[33m"[39;49;00m[33mdelta[39;49;00m[33m"[39;49;00m: [94m1[39;49;00m})[90m[39;49;00m
            [94mdef[39;49;00m[90m [39;49;00m[92malways_fail[39;49;00m([96mself[39;49;00m):[90m[39;49;00m
                [94mraise[39;49;00m [96mException[39;49;00m([33m"[39;49;00m[33mError![39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        model = TestModel()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Verify the exception is not absorbed by the context manager[39;49;00m[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises([96mException[39;49;00m, match=[33m"[39;49;00m[33mError![39;49;00m[33m"[39;49;00m):[90m[39;49;00m
            model.predict([94m2[39;49;00m, [94m5[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        trace = mlflow.get_trace(mlflow.get_last_active_trace_id())[90m[39;49;00m
>       trace_data = trace.data[90m[39;49;00m
                     ^^^^^^^^^^[90m[39;49;00m
[1m[31mE       AttributeError: 'NoneType' object has no attribute 'data'[0m

TestModel  = <class 'tests.entities.test_trace_data.test_json_deserialization.<locals>.TestModel'>
model      = <tests.entities.test_trace_data.test_json_deserialization.<locals>.TestModel object at 0x7de4fab585d0>
trace      = None

[1m[31mtests/entities/test_trace_data.py[0m:34: AttributeError
----------------------------- Captured stderr call -----------------------------
2026/10/11 19:38:54 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 19:38:54 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 19:38:54 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 19:38:54 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 19:38:54 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 19:38:54 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:55 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 19:38:55 WARNING mlflow.tracing.fluent: Failed to get trace from the tracking store: Trace with ID 'None' not found. For full traceback, set logging level to debug.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:38:55 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m___________________ test_intermediate_outputs_from_attribute ___________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_intermediate_outputs_from_attribute[39;49;00m():[90m[39;49;00m
        intermediate_outputs = {[90m[39;49;00m
            [33m"[39;49;00m[33mretrieved_documents[39;49;00m[33m"[39;49;00m: [[33m"[39;49;00m[33mdocument 1[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mdocument 2[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
            [33m"[39;49;00m[33mgenerative_prompt[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mprompt[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
    [90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mrun[39;49;00m():[90m[39;49;00m
            [94mwith[39;49;00m mlflow.start_span(name=[33m"[39;49;00m[33mrun[39;49;00m[33m"[39;49;00m) [94mas[39;49;00m span:[90m[39;49;00m
                span.set_attribute([33m"[39;49;00m[33mmlflow.trace.intermediate_outputs[39;49;00m[33m"[39;49;00m, intermediate_outputs)[90m[39;49;00m
    [90m[39;49;00m
        run()[90m[39;49;00m
        trace = mlflow.get_trace(mlflow.get_last_active_trace_id())[90m[39;49;00m
    [90m[39;49;00m
>       [94massert[39;49;00m trace.data.intermediate_outputs == intermediate_outputs[90m[39;49;00m
               ^^^^^^^^^^[90m[39;49;00m
[1m[31mE       AttributeError: 'NoneType' object has no attribute 'data'[0m

intermediate_outputs = {'generative_prompt': 'prompt', 'retrieved_documents': ['document 1', 'document 2']}
run        = <function test_intermediate_outputs_from_attribute.<locals>.run at 0x7de4f1fc3ec0>
trace      = None

[1m[31mtests/entities/test_trace_data.py[0m:168: AttributeError
----------------------------- Captured stderr call -----------------------------
2026/10/11 19:38:55 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 19:38:56 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 19:38:56 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 19:38:56 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 19:38:56 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 19:38:56 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 19:38:57 WARNING mlflow.tracing.fluent: Failed to get trace from the tracking store: Trace with ID 'None' not found. For full traceback, set logging level to debug.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:38:57 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________ test_intermediate_outputs_from_spans _____________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_intermediate_outputs_from_spans[39;49;00m():[90m[39;49;00m
        [37m@mlflow[39;49;00m.trace()[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mretrieved_documents[39;49;00m():[90m[39;49;00m
            [94mreturn[39;49;00m [[33m"[39;49;00m[33mdocument 1[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mdocument 2[39;49;00m[33m"[39;49;00m][90m[39;49;00m
    [90m[39;49;00m
        [37m@mlflow[39;49;00m.trace()[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mllm[39;49;00m(i):[90m[39;49;00m
            [94mreturn[39;49;00m [33mf[39;49;00m[33m"[39;49;00m[33mHi, this is LLM [39;49;00m[33m{[39;49;00mi[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [37m@mlflow[39;49;00m.trace()[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mpredict[39;49;00m():[90m[39;49;00m
            retrieved_documents()[90m[39;49;00m
            llm([94m1[39;49;00m)[90m[39;49;00m
            llm([94m2[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        predict()[90m[39;49;00m
        trace = mlflow.get_trace(mlflow.get_last_active_trace_id())[90m[39;49;00m
    [90m[39;49;00m
>       [94massert[39;49;00m trace.data.intermediate_outputs == {[90m[39;49;00m
               ^^^^^^^^^^[90m[39;49;00m
            [33m"[39;49;00m[33mretrieved_documents[39;49;00m[33m"[39;49;00m: [[33m"[39;49;00m[33mdocument 1[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mdocument 2[39;49;00m[33m"[39;49;00m],[90m[39;49;00m
            [33m"[39;49;00m[33mllm_1[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mHi, this is LLM 1[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            [33m"[39;49;00m[33mllm_2[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mHi, this is LLM 2[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
        }[90m[39;49;00m
[1m[31mE       AttributeError: 'NoneType' object has no attribute 'data'[0m

llm        = <function test_intermediate_outputs_from_spans.<locals>.llm at 0x7de4f1ad4d60>
predict    = <function test_intermediate_outputs_from_spans.<locals>.predict at 0x7de4f1ad5120>
retrieved_documents = <function test_intermediate_outputs_from_spans.<locals>.retrieved_documents at 0x7de4f1ab0b80>
trace      = None

[1m[31mtests/entities/test_trace_data.py[0m:189: AttributeError
----------------------------- Captured stderr call -----------------------------
2026/10/11 19:38:57 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 19:38:57 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 19:38:57 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 19:38:57 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 19:38:57 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 19:38:57 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 19:38:58 WARNING mlflow.tracing.fluent: Failed to get trace from the tracking store: Trace with ID 'None' not found. For full traceback, set logging level to debug.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:38:58 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________________ test_intermediate_outputs_no_value ______________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_intermediate_outputs_no_value[39;49;00m():[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mrun[39;49;00m():[90m[39;49;00m
            [94mwith[39;49;00m mlflow.start_span(name=[33m"[39;49;00m[33mrun[39;49;00m[33m"[39;49;00m) [94mas[39;49;00m span:[90m[39;49;00m
                span.set_outputs([94m1[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        run()[90m[39;49;00m
        trace = mlflow.get_trace(mlflow.get_last_active_trace_id())[90m[39;49;00m
    [90m[39;49;00m
>       [94massert[39;49;00m trace.data.intermediate_outputs [95mis[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
               ^^^^^^^^^^[90m[39;49;00m
[1m[31mE       AttributeError: 'NoneType' object has no attribute 'data'[0m

run        = <function test_intermediate_outputs_no_value.<locals>.run at 0x7de4f177fd80>
trace      = None

[1m[31mtests/entities/test_trace_data.py[0m:204: AttributeError
----------------------------- Captured stderr call -----------------------------
2026/10/11 19:38:58 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 19:38:58 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 19:38:58 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 19:38:58 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 19:38:58 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 19:38:58 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 19:38:59 WARNING mlflow.tracing.fluent: Failed to get trace from the tracking store: Trace with ID 'None' not found. For full traceback, set logging level to debug.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:38:59 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________________________ test_to_dict _________________________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_to_dict[39;49;00m():[90m[39;49;00m
        [94mwith[39;49;00m mlflow.start_span():[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
        trace = mlflow.get_trace(mlflow.get_last_active_trace_id())[90m[39;49;00m
>       trace_dict = trace.data.to_dict()[90m[39;49;00m
                     ^^^^^^^^^^[90m[39;49;00m
[1m[31mE       AttributeError: 'NoneType' object has no attribute 'data'[0m

trace      = None

[1m[31mtests/entities/test_trace_data.py[0m:211: AttributeError
----------------------------- Captured stderr call -----------------------------
2026/10/11 19:38:59 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 19:38:59 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 19:38:59 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 19:38:59 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 19:38:59 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 19:38:59 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 19:39:00 WARNING mlflow.tracing.fluent: Failed to get trace from the tracking store: Trace with ID 'None' not found. For full traceback, set logging level to debug.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:39:00 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m________________ test_request_and_response_are_still_available _________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_request_and_response_are_still_available[39;49;00m():[90m[39;49;00m
        [94mwith[39;49;00m mlflow.start_span() [94mas[39;49;00m s:[90m[39;49;00m
            s.set_inputs([33m"[39;49;00m[33mfoo[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
            s.set_outputs([33m"[39;49;00m[33mbar[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        trace = mlflow.get_trace(mlflow.get_last_active_trace_id())[90m[39;49;00m
>       trace_data = trace.data[90m[39;49;00m
                     ^^^^^^^^^^[90m[39;49;00m
[1m[31mE       AttributeError: 'NoneType' object has no attribute 'data'[0m

s          = NoOpSpan(name=None, trace_id='MLFLOW_NO_OP_SPAN_TRACE_ID', span_id=None, parent_id=None)
trace      = None

[1m[31mtests/entities/test_trace_data.py[0m:224: AttributeError
----------------------------- Captured stderr call -----------------------------
2026/10/11 19:39:00 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 19:39:00 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 19:39:00 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 19:39:01 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 19:39:01 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 19:39:01 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 19:39:01 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 19:39:02 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 19:39:02 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 19:39:02 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:39:02 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 19:39:02 WARNING mlflow.tracing.fluent: Failed to get trace from the tracking store: Trace with ID 'None' not found. For full traceback, set logging level to debug.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:39:02 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
3.00s call     tests/tracing/test_trace_manager.py::test_traces_buffer_expires_and_log_when_timeout_is_set
1.83s call     tests/entities/test_trace_data.py::test_json_deserialization
1.30s call     tests/entities/test_trace_data.py::test_to_dict
1.23s call     tests/entities/test_trace_data.py::test_intermediate_outputs_from_spans
1.19s call     tests/entities/test_trace_data.py::test_intermediate_outputs_no_value
1.19s call     tests/entities/test_trace_data.py::test_request_and_response_are_still_available
1.18s call     tests/entities/test_trace_data.py::test_intermediate_outputs_from_attribute
1.00s call     tests/tracing/test_trace_manager.py::test_traces_buffer_expires_after_ttl
1.00s teardown tests/tracing/test_trace_manager.py::test_traces_buffer_expires_and_log_when_timeout_is_set
0.02s call     tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                  | Duration | Tests | Min    | Max    | Avg    |
| ---- | ------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/entities/test_trace_data.py`   | 8.05s    | 6     | 1.183s | 1.929s | 1.342s |
| 2    | `tests/tracing/test_trace_manager.py` | 5.05s    | 10    | 0.001s | 4.003s | 0.505s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/entities/test_span_status.py::test_otel_status_to_mlflow_status_conversion[StatusCode.OK-Success-OK-]' 'tests/entities/test_span_status.py::test_otel_status_to_mlflow_status_conversion[StatusCode.UNSET--UNSET-]' 'tests/entities/test_trace_data.py::test_json_deserialization' 'tests/entities/test_trace_data.py::test_intermediate_outputs_from_attribute' 'tests/entities/test_trace_data.py::test_intermediate_outputs_from_spans' 'tests/entities/test_trace_data.py::test_intermediate_outputs_no_value' 'tests/entities/test_trace_data.py::test_to_dict' 'tests/entities/test_trace_data.py::test_request_and_response_are_still_available'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_span_status.py::[1mtest_otel_status_to_mlflow_status_conversion[StatusCode.OK-Success-OK-][0m - AssertionError: assert None == ''
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_span_status.py::[1mtest_otel_status_to_mlflow_status_conversion[StatusCode.UNSET--UNSET-][0m - AssertionError: assert None == ''
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_trace_data.py::[1mtest_json_deserialization[0m - AttributeError: 'NoneType' object has no attribute 'data'
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_trace_data.py::[1mtest_intermediate_outputs_from_attribute[0m - AttributeError: 'NoneType' object has no attribute 'data'
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_trace_data.py::[1mtest_intermediate_outputs_from_spans[0m - AttributeError: 'NoneType' object has no attribute 'data'
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_trace_data.py::[1mtest_intermediate_outputs_no_value[0m - AttributeError: 'NoneType' object has no attribute 'data'
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_trace_data.py::[1mtest_to_dict[0m - AttributeError: 'NoneType' object has no attribute 'data'
[31mFAILED | MEM 19.0/46.9 GB | DISK 794.6/915.7 GB[0m tests/entities/test_trace_data.py::[1mtest_request_and_response_are_still_available[0m - AttributeError: 'NoneType' object has no attribute 'data'
[31m======================== [31m[1m8 failed[0m, [32m53 passed[0m[31m in 13.32s[0m[31m =========================[0m
```

## 原始行 84 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import logging
logging.basicConfig(level=logging.DEBUG)
import mlflow
with mlflow.start_span('x') as s:
 print('SPAN',s, type(s))
print('last',mlflow.get_last_active_trace_id())
PY"
```

退出码：`0`

输出：
```
/testbed/mlflow/tracking/_tracking_service/utils.py:140: FutureWarning: Filesystem tracking backend (e.g., './mlruns') is deprecated. Please switch to a database backend (e.g., 'sqlite:///mlflow.db'). For feedback, see: https://github.com/mlflow/mlflow/issues/18534
  return FileStore(store_uri, store_uri)
DEBUG:git.cmd:Popen(['git', 'version'], cwd=/testbed, stdin=None, shell=False, universal_newlines=False)
DEBUG:git.cmd:Popen(['git', 'version'], cwd=/testbed, stdin=None, shell=False, universal_newlines=False)
DEBUG:git.util:sys.platform='linux', git_executable='git'
DEBUG:git.cmd:Popen(['git', 'check-ignore', '/testbed'], cwd=/testbed, stdin=None, shell=False, universal_newlines=False)
DEBUG:git.cmd:Popen(['git', 'cat-file', '--batch-check'], cwd=/testbed, stdin=<valid stream>, shell=False, universal_newlines=False)
DEBUG:git.util:sys.platform='linux', git_executable='git'
DEBUG:git.util:sys.platform='linux', git_executable='git'
SPAN NoOpSpan(name=None, trace_id='MLFLOW_NO_OP_SPAN_TRACE_ID', span_id=None, parent_id=None) <class 'mlflow.entities.span.NoOpSpan'>
last None
```

## 原始行 87 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"Failed to start span\\|NoOpSpan()\\|create_mlflow_span\" mlflow/tracing | head -100; sed -n '220,390p' mlflow/tracing/fluent.py; sed -n '250,430p' mlflow/tracing/provider.py"
```

退出码：`0`

输出：
````
grep: mlflow/tracing/__pycache__/fluent.cpython-311.pyc: binary file matches
grep: mlflow/tracing/processor/__pycache__/base_mlflow.cpython-311.pyc: binary file matches
mlflow/tracing/fluent.py:315:            return NoOpSpan()
mlflow/tracing/fluent.py:497:        _logger.debug(f"Failed to start span {name}.", exc_info=True)
mlflow/tracing/fluent.py:498:        mlflow_span = NoOpSpan()
mlflow/tracing/fluent.py:571:        return NoOpSpan()
mlflow/tracing/fluent.py:612:            f"Failed to start span {name}: {e}. For full traceback, set logging level to debug.",
mlflow/tracing/fluent.py:615:    return NoOpSpan()
mlflow/tracing/processor/inference_table.py:9:from mlflow.entities.span import create_mlflow_span
mlflow/tracing/processor/inference_table.py:114:        self._trace_manager.register_span(create_mlflow_span(span, trace_id))
mlflow/tracing/processor/base_mlflow.py:87:        InMemoryTraceManager.get_instance().register_span(create_mlflow_span(span, trace_id))
mlflow/tracing/processor/otel.py:4:from mlflow.entities.span import create_mlflow_span
mlflow/tracing/processor/otel.py:53:            self._trace_manager.register_span(create_mlflow_span(span, trace_id))

            with start_span(
                name=span_name,
                span_type=span_type,
                attributes=attributes,
                trace_destination=trace_destination,
            ) as span:
                span.set_attribute(SpanAttributeKey.FUNCTION_NAME, fn.__name__)
                inputs = capture_function_input_args(fn, args, kwargs)
                span.set_inputs(inputs)
                result = yield  # sync/async function output to be sent here
                span.set_outputs(result)
                try:
                    yield result
                except GeneratorExit:
                    # Swallow `GeneratorExit` raised when the generator is closed
                    pass

        def __init__(self, fn, args, kwargs):
            self.coro = self._wrapping_logic(fn, args, kwargs)

        def __enter__(self):
            next(self.coro)
            return self.coro

        def __exit__(self, exc_type, exc_value, traceback):
            # Since the function call occurs outside the coroutine,
            # if an exception occurs, we need to throw it back in, so that
            # we return control to the coro (in particular, so that the __exit__'s
            # of start_span and OTel's use_span can execute).
            if exc_type is not None:
                self.coro.throw(exc_type, exc_value, traceback)
            self.coro.close()

    if inspect.iscoroutinefunction(fn):

        async def wrapper(*args, **kwargs):
            with _WrappingContext(fn, args, kwargs) as wrapping_coro:
                return wrapping_coro.send(await fn(*args, **kwargs))
    else:

        def wrapper(*args, **kwargs):
            with _WrappingContext(fn, args, kwargs) as wrapping_coro:
                return wrapping_coro.send(fn(*args, **kwargs))

    return _wrap_function_safe(fn, wrapper)


def _wrap_generator(
    fn: Callable[..., Any],
    name: str | None = None,
    span_type: str = SpanType.UNKNOWN,
    attributes: dict[str, Any] | None = None,
    output_reducer: Callable[[list[Any]], Any] | None = None,
    trace_destination: TraceLocationBase | None = None,
) -> Callable[..., Any]:
    """
    Wrap a generator function to create a span.
    Generator functions need special handling because of its lazy evaluation nature.
    Let's say we have a generator function like this:
    ```
    @mlflow.trace
    def generate_stream():
        # B
        for i in range(10):
            # C
            yield i * 2
        # E


    stream = generate_stream()
    # A
    for chunk in stream:
        # D
        pass
    # F
    ```
    The execution order is A -> B -> C -> D -> C -> D -> ... -> E -> F.
    The span should only be "active" at B, C, and E, namely, when the code execution
    is inside the generator function. Otherwise it will create wrong span tree, or
    even worse, leak span context and pollute subsequent traces.
    """

    def _start_stream_span(fn, inputs):
        try:
            return start_span_no_context(
                name=name or fn.__name__,
                parent_span=get_current_active_span(),
                span_type=span_type,
                attributes=attributes,
                inputs=inputs,
                experiment_id=getattr(trace_destination, "experiment_id", None),
            )
        except Exception as e:
            _logger.debug(f"Failed to start stream span: {e}")
            return NoOpSpan()

    def _end_stream_span(
        span: LiveSpan,
        inputs: dict[str, Any] | None = None,
        outputs: list[Any] | None = None,
        output_reducer: Callable[[list[Any]], Any] | None = None,
        error: Exception | None = None,
    ):
        if error:
            span.add_event(SpanEvent.from_exception(error))
            span.end(status=SpanStatusCode.ERROR)
            return

        if output_reducer:
            try:
                outputs = output_reducer(outputs)
            except Exception as e:
                _logger.debug(f"Failed to reduce outputs from stream: {e}")

        span.end(outputs=outputs)

    def _record_chunk_event(span: LiveSpan, chunk: Any, chunk_index: int):
        try:
            event = SpanEvent(
                name=STREAM_CHUNK_EVENT_NAME_FORMAT.format(index=chunk_index),
                # OpenTelemetry SpanEvent only support str-str key-value pairs for attributes
                attributes={STREAM_CHUNK_EVENT_VALUE_KEY: json.dumps(chunk, cls=TraceJSONEncoder)},
            )
            span.add_event(event)
        except Exception as e:
            _logger.debug(f"Failing to record chunk event for span {span.name}: {e}")

    if inspect.isgeneratorfunction(fn):

        def wrapper(*args, **kwargs):
            inputs = capture_function_input_args(fn, args, kwargs)
            span = _start_stream_span(fn, inputs)
            generator = fn(*args, **kwargs)

            i = 0
            outputs = []
            while True:
                try:
                    # NB: Set the span to active only when the generator is running
                    with safe_set_span_in_context(span):
                        value = next(generator)
                except StopIteration:
                    break
                except Exception as e:
                    _end_stream_span(span, error=e)
                    raise e
                else:
                    outputs.append(value)
                    _record_chunk_event(span, value, i)
                    yield value
                    i += 1
            _end_stream_span(span, inputs, outputs, output_reducer)
    else:

        async def wrapper(*args, **kwargs):
            inputs = capture_function_input_args(fn, args, kwargs)
            span = _start_stream_span(fn, inputs)
            generator = fn(*args, **kwargs)

            i = 0
            outputs = []
            while True:
                try:
                    with safe_set_span_in_context(span):
                        value = await generator.__anext__()
                except StopAsyncIteration:
                    break
                except Exception as e:
                    _end_stream_span(span, error=e)
                    raise e
            - :py:class:`~mlflow.entities.trace_location.MlflowExperimentLocation`: Logs traces to
                an MLflow experiment.
            - :py:class:`~mlflow.entities.trace_location.UCSchemaLocation`: Logs traces to a
                Databricks Unity Catalog schema. Only available in Databricks.

        context_local: If False (default), the destination is set globally. If True, the destination
            is isolated per async task or thread, providing isolation in concurrent applications.

    Example:

        **Logging traces to MLflow Experiment:**

        .. code-block:: python

            from mlflow.entities.trace_location import MlflowExperimentLocation

            mlflow.tracing.set_destination(MlflowExperimentLocation(experiment_id="123"))

        Note: This has the same effect as setting the active MLflow experiment via the
        ``MLFLOW_EXPERIMENT_ID`` environment variable or the ``mlflow.set_experiment`` API,
        but with narrower scope.

        **Logging traces to Databricks Unity Catalog:**

        .. code-block:: python

            from mlflow.entities.trace_location import UCSchemaLocation

            mlflow.tracing.set_destination(
                UCSchemaLocation(catalog_name="catalog", schema_name="schema")
            )

        **Isolate the destination between async tasks or threads:**

        .. code-block:: python

            from mlflow.tracing.destination import Databricks

            mlflow.tracing.set_destination(
                MlflowExperimentLocation(experiment_id="123"),
                context_local=True,
            )

        The destination set with the ``context_local`` flag will only be effective within the
        current async task or thread. This is particularly useful when you want to send traces
        to different destinations from a multi-tenant application.

        ** Reset the destination:**

        .. code-block:: python

            mlflow.tracing.reset()

    """
    if isinstance(destination, TraceDestination):
        # NB: Deprecation warnings are issued in the constructor of the destination classes
        # so we don't need to issue a warning here.
        destination = destination.to_location()

    if not isinstance(destination, TraceLocationBase):
        raise MlflowException.invalid_parameter_value(
            f"Invalid destination type: {type(destination)}. "
            "The destination must be an instance of TraceLocation."
        )

    if isinstance(destination, UCSchemaLocation) and (
        mlflow.get_tracking_uri() is None or not mlflow.get_tracking_uri().startswith("databricks")
    ):
        mlflow.set_tracking_uri("databricks")
        _logger.info(
            "Automatically setting the tracking URI to `databricks` "
            "because the tracing destination is set to Databricks."
        )

    _MLFLOW_TRACE_USER_DESTINATION.set(destination, context_local=context_local)
    _initialize_tracer_provider()


def _get_tracer(module_name: str) -> trace.Tracer:
    """
    Get a tracer instance for the given module name.

    If the tracer provider is not initialized, this function will initialize the tracer provider.
    Other simultaneous calls to this function will block until the initialization is done.
    """
    return provider.get_or_init_tracer(module_name)


def _get_trace_exporter():
    """
    Get the exporter instance that is used by the current tracer provider.
    """
    if tracer_provider := provider.get():
        processors = tracer_provider._active_span_processor._span_processors
        # There should be only one processor used for MLflow tracing
        processor = processors[0]
        return processor.span_exporter


def _initialize_tracer_provider(disabled=False):
    """
    Instantiate a tracer provider and set it as the global tracer provider.

    Note that this function ALWAYS updates the global tracer provider, regardless of the current
    state. It is the caller's responsibility to ensure that the tracer provider is initialized
    only once, and update the _INITIALIZED flag accordingly.
    """
    processors = _get_span_processors(disabled=disabled)
    if not processors:
        provider.set(trace.NoOpTracerProvider())
        return

    # Demote the "Failed to detach context" log raised by the OpenTelemetry logger to DEBUG
    # level so that it does not show up in the user's console. This warning may indicate
    # some incorrect context handling, but in many cases just false positive that does not
    # cause any issue in the generated trace.
    # Note that we need to apply it permanently rather than just the scope of prediction call,
    # because the exception can happen for streaming case, where the error log might be
    # generated when the iterator is consumed and we don't know when it will happen.
    suppress_warning("opentelemetry.context", "Failed to detach context")

    # These Otel warnings are occasionally raised in a valid case, e.g. we timeout a trace
    # but some spans are still active. We suppress them because they are not actionable.
    suppress_warning("opentelemetry.sdk.trace", "Setting attribute on ended span")
    suppress_warning("opentelemetry.sdk.trace", "Calling end() on an ended span")

    # NB: If otel resource env vars are set explicitly, don't create an empty resource
    # so that they are propagated to otel spans.
    otel_service_name = os.getenv("OTEL_SERVICE_NAME")
    otel_resource_attributes = os.getenv("OTEL_RESOURCE_ATTRIBUTES")
    resource = None
    if not otel_service_name and not otel_resource_attributes:
        # Setting an empty resource to avoid triggering resource aggregation, which causes
        # an issue in LiteLLM tracing: https://github.com/mlflow/mlflow/issues/16296
        # Add telemetry resource: https://opentelemetry.io/docs/specs/semconv/resource/#telemetry-sdk
        resource = Resource(
            {
                "telemetry.sdk.language": "python",
                "telemetry.sdk.name": "mlflow",
                "telemetry.sdk.version": mlflow.__version__,
            }
        )
    tracer_provider = TracerProvider(resource=resource, sampler=_get_trace_sampler())
    for processor in processors:
        tracer_provider.add_span_processor(processor)

    provider.set(tracer_provider)


def _get_trace_sampler() -> TraceIdRatioBased | None:
    """
    Get the sampler configuration based on environment variable.

    Returns:
        TraceIdRatioBased sampler or None for default sampling.
    """
    sampling_ratio = MLFLOW_TRACE_SAMPLING_RATIO.get()
    if sampling_ratio is not None:
        if not (0.0 <= sampling_ratio <= 1.0):
            _logger.warning(
                f"{MLFLOW_TRACE_SAMPLING_RATIO} must be between 0.0 and 1.0, got {sampling_ratio}. "
                "Ignoring the invalid value and using default sampling (1.0)."
            )
            return None
        return TraceIdRatioBased(sampling_ratio)
    return None


def _get_span_processors(disabled: bool = False) -> list[SpanProcessor]:
    """
    Get the list of span processors based on configuration.

    Args:
        disabled: If True, returns an empty list of processors because tracing is disabled.

    Returns:
        List of span processors to be added to the TracerProvider.
    """
    if disabled:
        return []
````

## 原始行 89 · command_execution

命令：
```
/bin/bash -lc "sed -n '430,535p' mlflow/tracing/provider.py; sed -n '430,525p' mlflow/tracing/fluent.py; sed -n '560,625p' mlflow/tracing/fluent.py"
```

退出码：`0`

输出：
```

    processors = []

    if should_use_otlp_exporter():
        from mlflow.tracing.processor.otel import OtelSpanProcessor

        exporter = get_otlp_exporter()
        otel_processor = OtelSpanProcessor(
            span_exporter=exporter,
            # Only export metrics from the Otel processor if dual export is not enabled. Otherwise,
            # both Otel and MLflow processors will export metrics, causing duplication
            export_metrics=should_export_otlp_metrics()
            and not MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT.get(),
        )
        processors.append(otel_processor)

        if not MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT.get():
            return processors

    # TODO: Update this logic to pluggable registry where
    #  1. Partners can implement span processor/exporter and destination class.
    #  2. They can register their implementation to the registry via entry points.
    #  3. MLflow will pick the implementation based on given destination id.
    trace_destination = _MLFLOW_TRACE_USER_DESTINATION.get()
    if trace_destination:
        # in PrPr, users must set the destination to UCSchemaLocation to export traces to UC
        if isinstance(trace_destination, UCSchemaLocation):
            from mlflow.tracing.export.uc_table import DatabricksUCTableSpanExporter
            from mlflow.tracing.processor.uc_table import DatabricksUCTableSpanProcessor

            exporter = DatabricksUCTableSpanExporter(tracking_uri=mlflow.get_tracking_uri())
            processor = DatabricksUCTableSpanProcessor(span_exporter=exporter)
            processors.append(processor)
        elif isinstance(trace_destination, (MlflowExperimentLocation)):
            if is_in_databricks_model_serving_environment():
                _logger.info(
                    "Traces will be sent to the destination set by `mlflow.tracing.set_destination`"
                    " API. To enable saving traces to both MLflow experiment and inference table, "
                    "remove this API call from your model and set `MLFLOW_EXPERIMENT_ID` env var "
                    "instead."
                )
            processor = _get_mlflow_span_processor(tracking_uri=mlflow.get_tracking_uri())
            processors.append(processor)
    elif is_in_databricks_model_serving_environment():
        if not is_mlflow_tracing_enabled_in_model_serving():
            return processors

        from mlflow.tracing.export.inference_table import InferenceTableSpanExporter
        from mlflow.tracing.processor.inference_table import InferenceTableSpanProcessor

        exporter = InferenceTableSpanExporter()
        processor = InferenceTableSpanProcessor(exporter)
        processors.append(processor)
    else:
        processor = _get_mlflow_span_processor(tracking_uri=mlflow.get_tracking_uri())
        processors.append(processor)

    return processors


def _get_mlflow_span_processor(tracking_uri: str):
    """
    Get the MLflow span processor instance that is used by the current tracer provider.
    """
    # Databricks and SQL backends support V3 traces
    from mlflow.tracing.export.mlflow_v3 import MlflowV3SpanExporter
    from mlflow.tracing.processor.mlflow_v3 import MlflowV3SpanProcessor

    exporter = MlflowV3SpanExporter(tracking_uri=tracking_uri)
    return MlflowV3SpanProcessor(
        span_exporter=exporter,
        export_metrics=should_export_otlp_metrics(),
    )


@raise_as_trace_exception
def disable():
    """
    Disable tracing.

    .. note::

        This function sets up `OpenTelemetry` to use
        `NoOpTracerProvider <https://github.com/open-telemetry/opentelemetry-python/blob/4febd337b019ea013ccaab74893bd9883eb59000/opentelemetry-api/src/opentelemetry/trace/__init__.py#L222>`_
        and effectively disables all tracing operations.

    Example:

    .. code-block:: python
        :test:

        import mlflow


        @mlflow.trace
        def f():
            return 0


        # Tracing is enabled by default
        f()
        assert len(mlflow.search_traces()) == 1

        # Disable tracing
        mlflow.tracing.disable()
        f()
    .. code-block:: python
        :test:

        import mlflow

        with mlflow.start_span("my_span") as span:
            x = 1
            y = 2
            span.set_inputs({"x": x, "y": y})

            z = x + y

            span.set_outputs(z)
            span.set_attribute("key", "value")
            # do something

    When this context manager is used in the top-level scope, i.e. not within another span context,
    the span will be treated as a root span. The root span doesn't have a parent reference and
    **the entire trace will be logged when the root span is ended**.


    .. tip::

        If you want more explicit control over the trace lifecycle, you can use
        the `mlflow.start_span_no_context()` API. It provides lower
        level to start spans and control the parent-child relationships explicitly.
        However, it is generally recommended to use this context manager as long as it satisfies
        your requirements, because it requires less boilerplate code and is less error-prone.

    .. note::

        The context manager doesn't propagate the span context across threads by default. see
        `Multi Threading <https://mlflow.org/docs/latest/tracing/api/manual-instrumentation#multi-threading>`_
        for how to propagate the span context across threads.

    Args:
        name: The name of the span.
        span_type: The type of the span. Can be either a string or
            a :py:class:`SpanType <mlflow.entities.SpanType>` enum value
        attributes: A dictionary of attributes to set on the span.
        trace_destination: The destination to log the trace to, such as MLflow Experiment. If
            not provided, the destination will be an active MLflow experiment or an destination
            set by the :py:func:`mlflow.tracing.set_destination` function. This parameter
            should only be used for root span and setting this for non-root spans will be
            ignored with a warning.

    Returns:
        Yields an :py:class:`mlflow.entities.Span` that represents the created span.
    """
    try:
        otel_span = provider.start_span_in_context(
            name, experiment_id=trace_destination.experiment_id if trace_destination else None
        )

        # Create a new MLflow span and register it to the in-memory trace manager
        request_id = get_otel_attribute(otel_span, SpanAttributeKey.REQUEST_ID)

        # SpanProcessor should have already registered the span in the in-memory trace manager
        trace_manager = InMemoryTraceManager.get_instance()
        mlflow_span = trace_manager.get_span_from_id(
            request_id, encode_span_id(otel_span.context.span_id)
        )
        mlflow_span.set_span_type(span_type)
        attributes = dict(attributes) if attributes is not None else {}
        mlflow_span.set_attributes(attributes)

    except Exception:
        _logger.debug(f"Failed to start span {name}.", exc_info=True)
        mlflow_span = NoOpSpan()
        yield mlflow_span
        return

    try:
        # Setting end_on_exit = False to suppress the default span
        # export and instead invoke MLflow span's end() method.
        with trace_api.use_span(mlflow_span._span, end_on_exit=False):
            yield mlflow_span
    finally:
        try:
            mlflow_span.end()
        except Exception:
            _logger.debug(f"Failed to end span {mlflow_span.span_id}.", exc_info=True)


def start_span_no_context(
    name: str,
    span_type: str = SpanType.UNKNOWN,
    parent_span: LiveSpan | None = None,
    inputs: Any | None = None,
    attributes: dict[str, str] | None = None,
    tags: dict[str, str] | None = None,
    experiment_id: str | None = None,
    start_time_ns: int | None = None,
) -> LiveSpan:
    """
    Start a span without attaching it to the global tracing context.
                # Manually specify the parent span
                parent_span=root_span,
            )
            # Do something...
            child_span.end()

            root_span.end()

    """
    # If parent span is no-op span, the child should also be no-op too
    if parent_span and parent_span.trace_id == NO_OP_SPAN_TRACE_ID:
        return NoOpSpan()

    try:
        # Create new trace and a root span
        # Once OTel span is created, SpanProcessor.on_start is invoked
        # TraceInfo is created and logged into backend store inside on_start method
        otel_span = provider.start_detached_span(
            name,
            parent=parent_span._span if parent_span else None,
            start_time_ns=start_time_ns,
            experiment_id=experiment_id,
        )

        if parent_span:
            trace_id = parent_span.trace_id
        else:
            trace_id = get_otel_attribute(otel_span, SpanAttributeKey.REQUEST_ID)

        # SpanProcessor should have already registered the span in the in-memory trace manager
        trace_manager = InMemoryTraceManager.get_instance()
        mlflow_span = trace_manager.get_span_from_id(
            trace_id, encode_span_id(otel_span.context.span_id)
        )
        mlflow_span.set_span_type(span_type)

        # # If the span is a no-op span i.e. tracing is disabled, do nothing
        if isinstance(mlflow_span, NoOpSpan):
            return mlflow_span

        if inputs is not None:
            mlflow_span.set_inputs(inputs)
        mlflow_span.set_attributes(attributes or {})

        if tags := exclude_immutable_tags(tags or {}):
            # Update trace tags for trace in in-memory trace manager
            with trace_manager.get_trace(trace_id) as trace:
                trace.info.tags.update(tags)

        return mlflow_span
    except Exception as e:
        _logger.warning(
            f"Failed to start span {name}: {e}. For full traceback, set logging level to debug.",
            exc_info=_logger.isEnabledFor(logging.DEBUG),
        )
    return NoOpSpan()


@deprecated_parameter("request_id", "trace_id")
def get_trace(trace_id: str, silent: bool = False) -> Trace | None:
    """
    Get a trace by the given request ID if it exists.

    This function retrieves the trace from the in-memory buffer first, and if it doesn't exist,
    it fetches the trace from the tracking store. If the trace is not found in the tracking store,
    it returns None.
```

## 原始行 92 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import logging
logging.getLogger('mlflow.tracing.fluent').setLevel(logging.DEBUG)
logging.getLogger('mlflow').setLevel(logging.DEBUG)
import mlflow
s=mlflow.start_span_no_context('x')
print(s,type(s))
PY"
```

退出码：`0`

输出：
```
/testbed/mlflow/tracking/_tracking_service/utils.py:140: FutureWarning: Filesystem tracking backend (e.g., './mlruns') is deprecated. Please switch to a database backend (e.g., 'sqlite:///mlflow.db'). For feedback, see: https://github.com/mlflow/mlflow/issues/18534
  return FileStore(store_uri, store_uri)
NoOpSpan(name=None, trace_id='MLFLOW_NO_OP_SPAN_TRACE_ID', span_id=None, parent_id=None) <class 'mlflow.entities.span.NoOpSpan'>
2026/10/11 19:39:23 WARNING mlflow.tracing.fluent: Failed to start span x: name 'create_mlflow_span' is not defined. For full traceback, set logging level to debug.
```

## 原始行 95 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,125p' mlflow/tracing/processor/base_mlflow.py; sed -n '1,100p' mlflow/entities/__init__.py | grep -n Span -C2; grep -n \"create_mlflow_span\" mlflow/entities/__init__.py mlflow/tracing/processor/base_mlflow.py"
```

退出码：`0`

输出：
```
import json
import logging
import threading
from typing import Any

from opentelemetry.context import Context
from opentelemetry.sdk.trace import ReadableSpan as OTelReadableSpan
from opentelemetry.sdk.trace import Span as OTelSpan
from opentelemetry.sdk.trace.export import SimpleSpanProcessor, SpanExporter


from mlflow.entities.trace_info import TraceInfo
from mlflow.tracing.constant import (
    MAX_CHARS_IN_TRACE_INFO_METADATA,
    TRACE_SCHEMA_VERSION,
    TRACE_SCHEMA_VERSION_KEY,
    TRUNCATION_SUFFIX,
    SpanAttributeKey,
    TraceMetadataKey,
    TraceTagKey,
)
from mlflow.tracing.processor.otel_metrics_mixin import OtelMetricsMixin
from mlflow.tracing.trace_manager import InMemoryTraceManager, _Trace
from mlflow.tracing.utils import (
    aggregate_usage_from_spans,
    get_otel_attribute,
    maybe_get_dependencies_schemas,
    maybe_get_logged_model_id,
    maybe_get_request_id,
    update_trace_state_from_span_conditionally,
)
from mlflow.tracing.utils.environment import resolve_env_metadata
from mlflow.tracking.fluent import (
    _get_active_model_id_global,
    _get_latest_active_run,
)

_logger = logging.getLogger(__name__)


class BaseMlflowSpanProcessor(OtelMetricsMixin, SimpleSpanProcessor):
    """
    Defines custom hooks to be executed when a span is started or ended (before exporting).

    """

    def __init__(
        self,
        span_exporter: SpanExporter,
        export_metrics: bool,
    ):
        super().__init__(span_exporter)
        self.span_exporter = span_exporter
        self._export_metrics = export_metrics
        self._env_metadata = resolve_env_metadata()
        # Lock to prevent race conditions during concurrent span name deduplication
        # This ensures that when multiple spans end simultaneously, their names are
        # deduplicated atomically without interference
        self._deduplication_lock = threading.RLock()

    def on_start(self, span: OTelSpan, parent_context: Context | None = None):
        """
        Handle the start of a span. This method is called when an OpenTelemetry span is started.

        Args:
            span: An OpenTelemetry Span object that is started.
            parent_context: The context of the span. Note that this is only passed when the context
                object is explicitly specified to OpenTelemetry start_span call. If the parent span
                is obtained from the global context, it won't be passed here so we should not rely
                on it.
        """
        trace_id = self._trace_manager.get_mlflow_trace_id_from_otel_id(span.context.trace_id)

        if not trace_id and span.parent is not None:
            _logger.debug(
                "Received a non-root span but the trace ID is not found."
                "The trace has likely been halted due to a timeout expiration."
            )
            return

        if span.parent is None:
            trace_info = self._start_trace(span)
            if trace_info is None:
                return
            trace_id = trace_info.trace_id

        InMemoryTraceManager.get_instance().register_span(create_mlflow_span(span, trace_id))

    def _start_trace(self, root_span: OTelSpan) -> TraceInfo:
        raise NotImplementedError("Subclasses must implement this method.")

    def on_end(self, span: OTelReadableSpan) -> None:
        """
        Handle the end of a span. This method is called when an OpenTelemetry span is ended.

        Args:
            span: An OpenTelemetry ReadableSpan object that is ended.
        """
        if self._export_metrics:
            self.record_metrics_for_span(span)

        trace_id = get_otel_attribute(span, SpanAttributeKey.REQUEST_ID)

        # Acquire lock before accessing and modifying trace data to prevent race conditions
        # during concurrent span endings. This ensures span name deduplication happens
        # atomically without interference from other threads
        with self._deduplication_lock:
            with self._trace_manager.get_trace(trace_id) as trace:
                if trace is not None:
                    if span._parent is None:
                        self._update_trace_info(trace, span)
                else:
                    _logger.debug(f"Trace data with request ID {trace_id} not found.")
        super().on_end(span)

    def _get_basic_trace_metadata(self) -> dict[str, Any]:
        metadata = self._env_metadata.copy()

        metadata[TRACE_SCHEMA_VERSION_KEY] = str(TRACE_SCHEMA_VERSION)

        # If the span is started within an active MLflow run, we should record it as a trace tag
        # Note `mlflow.active_run()` can only get thread-local active run,
        # but tracing routine might be applied to model inference worker threads
        # in the following cases:
        #  - langchain model `chain.batch` which uses thread pool to spawn workers.
42-from mlflow.entities.scorer import ScorerVersion
43-from mlflow.entities.source_type import SourceType
44:from mlflow.entities.span import LiveSpan, NoOpSpan, Span, SpanType
45:from mlflow.entities.span_event import SpanEvent
46:from mlflow.entities.span_status import SpanStatus, SpanStatusCode
47-from mlflow.entities.trace import Trace
48-from mlflow.entities.trace_data import TraceData
--
85-    "RunInputs",
86-    "RunOutputs",
87:    "Span",
88:    "LiveSpan",
89:    "NoOpSpan",
90:    "SpanEvent",
91:    "SpanStatus",
92:    "SpanType",
93-    "Trace",
94-    "TraceData",
mlflow/tracing/processor/base_mlflow.py:87:        InMemoryTraceManager.get_instance().register_span(create_mlflow_span(span, trace_id))
```

## 原始行 98 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from opentelemetry.trace import Status
print(inspect.getsource(Status))
PY"
```

退出码：`0`

输出：
```
class Status:
    """Represents the status of a finished Span.

    Args:
        status_code: The canonical status code that describes the result
            status of the operation.
        description: An optional description of the status.
    """

    def __init__(
        self,
        status_code: StatusCode = StatusCode.UNSET,
        description: typing.Optional[str] = None,
    ):
        self._status_code = status_code
        self._description = None

        if description:
            if not isinstance(description, str):
                logger.warning("Invalid status description type, expected str")
                return
            if status_code is not StatusCode.ERROR:
                logger.warning(
                    "description should only be set when status_code is set to StatusCode.ERROR"
                )
                return

        self._description = description

    @property
    def status_code(self) -> StatusCode:
        """Represents the canonical status code of a finished Span."""
        return self._status_code

    @property
    def description(self) -> typing.Optional[str]:
        """Status description"""
        return self._description

    @property
    def is_ok(self) -> bool:
        """Returns false if this represents an error, true otherwise."""
        return self.is_unset or self._status_code is StatusCode.OK

    @property
    def is_unset(self) -> bool:
        """Returns true if unset, false otherwise."""
        return self._status_code is StatusCode.UNSET
```

## 原始行 101 · file_change

```
{
  "id": "item_65",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/span_status.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracing/processor/base_mlflow.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 104 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import logging
logging.getLogger('mlflow.tracing.fluent').setLevel(logging.DEBUG)
import mlflow
s=mlflow.start_span_no_context('x')
print(s,type(s),s.trace_id)
if hasattr(s,'end'): s.end()
print('last',mlflow.get_last_active_trace_id())
PY"
```

退出码：`0`

输出：
```
/testbed/mlflow/tracking/_tracking_service/utils.py:140: FutureWarning: Filesystem tracking backend (e.g., './mlruns') is deprecated. Please switch to a database backend (e.g., 'sqlite:///mlflow.db'). For feedback, see: https://github.com/mlflow/mlflow/issues/18534
  return FileStore(store_uri, store_uri)
2026/10/11 19:39:45 WARNING mlflow.tracing.export.mlflow_v3: Failed to send trace to MLflow backend: Experiment 0 does not exist.
LiveSpan(name='x', trace_id='tr-8a1eff04a5da4bddef1fc5be6098f3de', span_id='930f6336d8a444aa', parent_id=None) <class 'mlflow.entities.span.LiveSpan'> tr-8a1eff04a5da4bddef1fc5be6098f3de
last tr-8a1eff04a5da4bddef1fc5be6098f3de
```

## 原始行 107 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/entities/test_span_status.py tests/entities/test_trace_data.py tests/entities/test_trace.py::test_from_v2_dict tests/entities/test_trace.py::test_request_response_smart_truncation tests/entities/test_trace.py::test_request_response_smart_truncation_non_chat_format tests/entities/test_trace.py::test_request_response_custom_truncation tests/tracing/utils/test_processor.py'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 34 items

tests/entities/test_span_status.py [32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                       [ 44%][0m
tests/entities/test_trace_data.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                 [ 61%][0m
tests/entities/test_trace.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                        [ 73%][0m
tests/tracing/utils/test_processor.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                          [100%][0m

=================================== FAILURES ===================================
[31m[1m________________ test_otel_status_conversion[OK-StatusCode.OK] _________________[0m

status_code = <SpanStatusCode.OK: 'OK'>, otel_status_code = <StatusCode.OK: 1>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        ([33m"[39;49;00m[33mstatus_code[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33motel_status_code[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        [[90m[39;49;00m
            (SpanStatusCode.OK, trace_api.StatusCode.OK),[90m[39;49;00m
            (SpanStatusCode.ERROR, trace_api.StatusCode.ERROR),[90m[39;49;00m
            (SpanStatusCode.UNSET, trace_api.StatusCode.UNSET),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_otel_status_conversion[39;49;00m(status_code, otel_status_code):[90m[39;49;00m
        span_status = SpanStatus(status_code, description=[33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        otel_status = span_status.to_otel_status()[90m[39;49;00m
    [90m[39;49;00m
        [90m# OpenTelemetry only allows specify description when status is ERROR[39;49;00m[90m[39;49;00m
        [90m# Otherwise it will be ignored with warning message.[39;49;00m[90m[39;49;00m
        expected_description = [33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m [94mif[39;49;00m status_code == SpanStatusCode.ERROR [94melse[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94massert[39;49;00m otel_status.status_code == otel_status_code[90m[39;49;00m
>       [94massert[39;49;00m otel_status.description == expected_description[90m[39;49;00m
[1m[31mE       AssertionError: assert '' == None[0m
[1m[31mE        +  where '' = <opentelemetry.trace.status.Status object at 0x796aa2e0d810>.description[0m

expected_description = None
otel_status = <opentelemetry.trace.status.Status object at 0x796aa2e0d810>
otel_status_code = <StatusCode.OK: 1>
span_status = SpanStatus(status_code=<SpanStatusCode.OK: 'OK'>, description='test')
status_code = <SpanStatusCode.OK: 'OK'>

[1m[31mtests/entities/test_span_status.py[0m:39: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:39:49 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________ test_otel_status_conversion[UNSET-StatusCode.UNSET] ______________[0m

status_code = <SpanStatusCode.UNSET: 'UNSET'>
otel_status_code = <StatusCode.UNSET: 0>

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        ([33m"[39;49;00m[33mstatus_code[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33motel_status_code[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        [[90m[39;49;00m
            (SpanStatusCode.OK, trace_api.StatusCode.OK),[90m[39;49;00m
            (SpanStatusCode.ERROR, trace_api.StatusCode.ERROR),[90m[39;49;00m
            (SpanStatusCode.UNSET, trace_api.StatusCode.UNSET),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_otel_status_conversion[39;49;00m(status_code, otel_status_code):[90m[39;49;00m
        span_status = SpanStatus(status_code, description=[33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        otel_status = span_status.to_otel_status()[90m[39;49;00m
    [90m[39;49;00m
        [90m# OpenTelemetry only allows specify description when status is ERROR[39;49;00m[90m[39;49;00m
        [90m# Otherwise it will be ignored with warning message.[39;49;00m[90m[39;49;00m
        expected_description = [33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m [94mif[39;49;00m status_code == SpanStatusCode.ERROR [94melse[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94massert[39;49;00m otel_status.status_code == otel_status_code[90m[39;49;00m
>       [94massert[39;49;00m otel_status.description == expected_description[90m[39;49;00m
[1m[31mE       AssertionError: assert '' == None[0m
[1m[31mE        +  where '' = <opentelemetry.trace.status.Status object at 0x796aa2cb7950>.description[0m

expected_description = None
otel_status = <opentelemetry.trace.status.Status object at 0x796aa2cb7950>
otel_status_code = <StatusCode.UNSET: 0>
span_status = SpanStatus(status_code=<SpanStatusCode.UNSET: 'UNSET'>, description='test')
status_code = <SpanStatusCode.UNSET: 'UNSET'>

[1m[31mtests/entities/test_span_status.py[0m:39: AssertionError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:39:49 INFO mlflow.tracking.fluent: Active model is cleared
[33m=============================== warnings summary ===============================[0m
tests/entities/test_trace_data.py::test_intermediate_outputs_from_attribute
  /testbed/tests/entities/test_trace_data.py:168: FutureWarning: ``mlflow.entities.trace_data.TraceData.intermediate_outputs`` is deprecated since 3.6.0. This method will be removed in a future release. Use ``trace.search_spans(name=...)`` instead.
    assert trace.data.intermediate_outputs == intermediate_outputs

tests/entities/test_trace_data.py::test_intermediate_outputs_from_spans
  /testbed/tests/entities/test_trace_data.py:189: FutureWarning: ``mlflow.entities.trace_data.TraceData.intermediate_outputs`` is deprecated since 3.6.0. This method will be removed in a future release. Use ``trace.search_spans(name=...)`` instead.
    assert trace.data.intermediate_outputs == {

tests/entities/test_trace_data.py::test_intermediate_outputs_no_value
  /testbed/tests/entities/test_trace_data.py:204: FutureWarning: ``mlflow.entities.trace_data.TraceData.intermediate_outputs`` is deprecated since 3.6.0. This method will be removed in a future release. Use ``trace.search_spans(name=...)`` instead.
    assert trace.data.intermediate_outputs is None

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
1.91s call     tests/tracing/utils/test_processor.py::test_apply_span_processors_multiple_processors_success
1.83s call     tests/entities/test_trace.py::test_request_response_smart_truncation_non_chat_format
1.80s call     tests/entities/test_trace_data.py::test_intermediate_outputs_no_value
1.78s call     tests/entities/test_trace_data.py::test_to_dict
1.74s call     tests/entities/test_trace_data.py::test_request_and_response_are_still_available
1.72s call     tests/tracing/utils/test_processor.py::test_apply_span_processors_returns_non_none_warning
1.72s call     tests/tracing/utils/test_processor.py::test_span_processors_single_processor_success
1.71s call     tests/tracing/utils/test_processor.py::test_span_processors_no_processors_configured
1.70s call     tests/entities/test_trace.py::test_request_response_custom_truncation
1.68s call     tests/tracing/utils/test_processor.py::test_apply_span_processors_exception_handling

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                    | Duration | Tests | Min    | Max    | Avg    |
| ---- | --------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/entities/test_trace_data.py`     | 9.25s    | 6     | 1.065s | 1.803s | 1.541s |
| 2    | `tests/tracing/utils/test_processor.py` | 8.76s    | 9     | 0.002s | 1.912s | 0.973s |
| 3    | `tests/entities/test_trace.py`          | 5.20s    | 4     | 0.002s | 1.829s | 1.300s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/entities/test_span_status.py::test_otel_status_conversion[OK-StatusCode.OK]' 'tests/entities/test_span_status.py::test_otel_status_conversion[UNSET-StatusCode.UNSET]'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 19.3/46.9 GB | DISK 789.8/915.7 GB[0m tests/entities/test_span_status.py::[1mtest_otel_status_conversion[OK-StatusCode.OK][0m - AssertionError: assert '' == None
[31mFAILED | MEM 19.3/46.9 GB | DISK 789.8/915.7 GB[0m tests/entities/test_span_status.py::[1mtest_otel_status_conversion[UNSET-StatusCode.UNSET][0m - AssertionError: assert '' == None
[31m================== [31m[1m2 failed[0m, [32m32 passed[0m, [33m3 warnings[0m[31m in 23.35s[0m[31m ===================[0m
```

## 原始行 110 · file_change

```
{
  "id": "item_71",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/span_status.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 113 · command_execution

命令：
```
/bin/bash -lc "sed -n '180,270p' tests/tracing/test_tracing_client.py; sed -n '6990,7045p' tests/store/tracking/test_sqlalchemy_store.py; sed -n '7160,7195p' tests/store/tracking/test_sqlalchemy_store.py; sed -n '10910,10955p' tests/store/tracking/test_sqlalchemy_store.py; sed -n '1,250p' tests/tracing/helper.py"
```

退出码：`0`

输出：
```

    store = client.store

    otel_span = OTelReadableSpan(
        name="test_span",
        context=trace_api.SpanContext(
            trace_id=12345,
            span_id=111,
            is_remote=False,
            trace_flags=trace_api.TraceFlags(1),
        ),
        parent=None,
        attributes={
            "mlflow.traceRequestId": json.dumps(trace_id, cls=TraceJSONEncoder),
            "llm.model_name": "test-model",
            "custom.attribute": "test-value",
        },
        start_time=1_000_000_000,
        end_time=2_000_000_000,
        resource=None,
    )

    span = create_mlflow_span(otel_span, trace_id, "LLM")

    store.log_spans(experiment_id, [span])

    trace = client.get_trace(trace_id)

    assert trace.info.trace_id == trace_id
    assert trace.info.tags.get(TraceTagKey.SPANS_LOCATION) == SpansLocation.TRACKING_STORE

    assert len(trace.data.spans) == 1
    loaded_span = trace.data.spans[0]

    assert loaded_span.name == "test_span"
    assert loaded_span.trace_id == trace_id
    assert loaded_span.start_time_ns == 1_000_000_000
    assert loaded_span.end_time_ns == 2_000_000_000
    assert loaded_span.attributes.get("llm.model_name") == "test-model"
    assert loaded_span.attributes.get("custom.attribute") == "test-value"


@skip_when_testing_trace_sdk
def test_tracing_client_get_trace_error_handling():
    client = TracingClient()

    experiment_id = mlflow.create_experiment("test")
    trace_id = f"tr-{uuid.uuid4().hex}"

    store = client.store

    otel_span = OTelReadableSpan(
        name="test_span",
        context=trace_api.SpanContext(
            trace_id=12345,
            span_id=111,
            is_remote=False,
            trace_flags=trace_api.TraceFlags(1),
        ),
        parent=None,
        attributes={
            "mlflow.traceRequestId": json.dumps(trace_id, cls=TraceJSONEncoder),
            "llm.model_name": "test-model",
            "custom.attribute": "test-value",
        },
        start_time=1_000_000_000,
        end_time=2_000_000_000,
        resource=None,
    )

    span = create_mlflow_span(otel_span, trace_id, "LLM")

    store.log_spans(experiment_id, [span])
    trace = client.get_trace(trace_id)
    trace_info = trace.info
    trace_info.trace_metadata[TraceMetadataKey.SIZE_STATS] = json.dumps(
        {TraceSizeStatsKey.NUM_SPANS: 2}
    )
    store.start_trace(trace_info)

    with pytest.raises(MlflowException, match=rf"Trace with ID {trace_id} is not found"):
        client.get_trace(trace_id)
    )
    trace_info = store.start_trace(trace_info)

    # Create a mock OpenTelemetry span

    # Create mock context
    mock_context = mock.Mock()
    mock_context.trace_id = 12345
    mock_context.span_id = 222 if not is_async else 333
    mock_context.is_remote = False
    mock_context.trace_flags = trace_api.TraceFlags(1)
    mock_context.trace_state = trace_api.TraceState()  # Empty TraceState

    parent_mock_context = mock.Mock()
    parent_mock_context.trace_id = 12345
    parent_mock_context.span_id = 111
    parent_mock_context.is_remote = False
    parent_mock_context.trace_flags = trace_api.TraceFlags(1)
    parent_mock_context.trace_state = trace_api.TraceState()  # Empty TraceState

    readable_span = OTelReadableSpan(
        name="test_span",
        context=mock_context,
        parent=parent_mock_context if not is_async else None,
        attributes={
            "mlflow.traceRequestId": json.dumps(trace_info.trace_id),
            "mlflow.spanInputs": json.dumps({"input": "test_input"}, cls=TraceJSONEncoder),
            "mlflow.spanOutputs": json.dumps({"output": "test_output"}, cls=TraceJSONEncoder),
            "mlflow.spanType": json.dumps("LLM" if not is_async else "CHAIN", cls=TraceJSONEncoder),
            "custom_attr": json.dumps("custom_value", cls=TraceJSONEncoder),
        },
        start_time=1000000000 if not is_async else 3000000000,
        end_time=2000000000 if not is_async else 4000000000,
        resource=_OTelResource.get_empty(),
    )

    # Create MLflow span from OpenTelemetry span
    span = create_mlflow_span(readable_span, trace_info.trace_id, "LLM")
    assert isinstance(span, Span)

    # Test logging the span using sync or async method
    if is_async:
        logged_spans = await store.log_spans_async(experiment_id, [span])
    else:
        logged_spans = store.log_spans(experiment_id, [span])

    # Verify the returned spans are the same
    assert len(logged_spans) == 1
    assert logged_spans[0] == span
    assert logged_spans[0].trace_id == trace_info.trace_id
    assert logged_spans[0].span_id == span.span_id

    # Verify the span was saved to the database
    with store.ManagedSessionMaker() as session:
        saved_span = (
            session.query(SqlSpan)
        context=trace_api.SpanContext(
            trace_id=98765,
            span_id=555,
            is_remote=False,
            trace_flags=trace_api.TraceFlags(1),
        ),
        parent=None,
        attributes={
            "mlflow.traceRequestId": json.dumps(trace_id, cls=TraceJSONEncoder),
            "mlflow.experimentId": json.dumps(experiment_id, cls=TraceJSONEncoder),
        },
        start_time=5000000000,
        end_time=6000000000,
        resource=_OTelResource.get_empty(),
    )

    span = create_mlflow_span(readable_span, trace_id)

    # Log the span - should create the trace automatically
    if is_async:
        logged_spans = await store.log_spans_async(experiment_id, [span])
    else:
        logged_spans = store.log_spans(experiment_id, [span])

    assert len(logged_spans) == 1
    assert logged_spans[0] == span

    # Verify the trace was created
    with store.ManagedSessionMaker() as session:
        created_trace = (
            session.query(SqlTraceInfo).filter(SqlTraceInfo.request_id == trace_id).first()
        )

        assert created_trace is not None
        assert created_trace.experiment_id == int(experiment_id)
        assert created_trace.timestamp_ms == 5000000000 // 1_000_000

    otel_span = create_test_otel_span(
        trace_id=trace_id,
        name="complex_span",
        status_code=trace_api.StatusCode.ERROR,
        status_description="Test error",
        start_time=1_000_000_000,
        end_time=2_000_000_000,
        trace_id_num=12345,
        span_id_num=111,
    )

    otel_span._attributes = {
        "llm.model_name": "gpt-4",
        "llm.input_tokens": 100,
        "llm.output_tokens": 50,
        "custom.key": "custom_value",
        "mlflow.traceRequestId": json.dumps(trace_id, cls=TraceJSONEncoder),
    }

    span = create_mlflow_span(otel_span, trace_id, "LLM")

    store.log_spans(experiment_id, [span])
    traces = store.batch_get_traces([trace_id])

    assert len(traces) == 1
    loaded_spans = traces[0].data.spans

    assert len(loaded_spans) == 1
    loaded_span = loaded_spans[0]

    assert loaded_span.status.status_code == "ERROR"
    assert loaded_span.status.description == "Test error"

    assert loaded_span.attributes.get("llm.model_name") == "gpt-4"
    assert loaded_span.attributes.get("llm.input_tokens") == 100
    assert loaded_span.attributes.get("llm.output_tokens") == 50
    assert loaded_span.attributes.get("custom.key") == "custom_value"


def test_batch_get_traces_multiple_traces(store: SqlAlchemyStore) -> None:
    experiment_id = store.create_experiment("test_load_spans_multiple")
    trace_id_1 = f"tr-{uuid.uuid4().hex}"
    trace_id_2 = f"tr-{uuid.uuid4().hex}"

    spans_trace_1 = [
import os
import time
import uuid
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from typing import Any
from unittest import mock

import opentelemetry.trace as trace_api
import pytest
from opentelemetry.sdk.trace import Event, ReadableSpan

import mlflow
from mlflow.entities import Trace, TraceData, TraceInfo
from mlflow.entities.trace_location import TraceLocation
from mlflow.entities.trace_state import TraceState
from mlflow.ml_package_versions import FLAVOR_TO_MODULE_NAME
from mlflow.tracing.client import TracingClient
from mlflow.tracing.constant import TRACE_SCHEMA_VERSION, TRACE_SCHEMA_VERSION_KEY
from mlflow.tracing.export.inference_table import pop_trace
from mlflow.tracing.processor.mlflow_v3 import MlflowV3SpanProcessor
from mlflow.tracing.provider import _get_tracer
from mlflow.tracking.fluent import _get_experiment_id
from mlflow.utils.autologging_utils import AUTOLOGGING_INTEGRATIONS, get_autolog_function
from mlflow.utils.autologging_utils.safety import revert_patches
from mlflow.version import IS_TRACING_SDK_ONLY


def create_mock_otel_span(
    trace_id: int,
    span_id: int,
    name: str = "test_span",
    parent_id: int | None = None,
    start_time: int | None = None,
    end_time: int | None = None,
):
    """
    Create a mock OpenTelemetry span for testing purposes.

    OpenTelemetry doesn't allow creating a span outside of a tracer. So here we create a mock span
    that extends ReadableSpan (data object) and exposes the necessary attributes for testing.
    """

    @dataclass
    class _MockSpanContext:
        trace_id: str
        span_id: str
        trace_flags: trace_api.TraceFlags = trace_api.TraceFlags(1)
        trace_state: trace_api.TraceState = field(default_factory=trace_api.TraceState)

    class _MockOTelSpan(trace_api.Span, ReadableSpan):
        def __init__(
            self,
            name,
            context,
            parent,
            start_time=None,
            end_time=None,
            status=trace_api.Status(trace_api.StatusCode.UNSET),
        ):
            self._name = name
            self._parent = parent
            self._context = context
            self._start_time = start_time if start_time is not None else int(time.time() * 1e9)
            self._end_time = end_time
            self._status = status
            self._attributes = {}
            self._events = []

        # NB: The following methods are defined as abstract method in the Span class.
        def set_attributes(self, attributes):
            self._attributes.update(attributes)

        def set_attribute(self, key, value):
            self._attributes[key] = value

        def set_status(self, status):
            self._status = status

        def add_event(self, name, attributes=None, timestamp=None):
            self._events.append(Event(name, attributes, timestamp))

        def get_span_context(self):
            return self._context

        def is_recording(self):
            return self._end_time is None

        def update_name(self, name):
            self.name = name

        def end(self, end_time_ns=None):
            pass

        def record_exception():
            pass

    return _MockOTelSpan(
        name=name,
        context=_MockSpanContext(trace_id, span_id),
        parent=_MockSpanContext(trace_id, parent_id) if parent_id else None,
        start_time=start_time,
        end_time=end_time,
    )


def create_trace(request_id) -> Trace:
    return Trace(info=create_test_trace_info(request_id), data=TraceData())


def create_test_trace_info(
    trace_id,
    experiment_id="test",
    request_time=0,
    execution_duration=1,
    state=TraceState.OK,
    trace_metadata=None,
    tags=None,
):
    # Add schema version to metadata if not provided, to match real trace creation behavior
    final_metadata = trace_metadata or {}
    if TRACE_SCHEMA_VERSION_KEY not in final_metadata:
        final_metadata = final_metadata.copy()
        final_metadata[TRACE_SCHEMA_VERSION_KEY] = str(TRACE_SCHEMA_VERSION)

    return TraceInfo(
        trace_id=trace_id,
        trace_location=TraceLocation.from_experiment_id(experiment_id),
        request_time=request_time,
        execution_duration=execution_duration,
        state=state,
        trace_metadata=final_metadata,
        tags=tags or {},
    )


def create_test_trace_info_with_uc_table(
    trace_id: str, catalog_name: str, schema_name: str
) -> TraceInfo:
    return TraceInfo(
        trace_id=trace_id,
        trace_location=TraceLocation.from_databricks_uc_schema(catalog_name, schema_name),
        request_time=0,
        execution_duration=1,
        state=TraceState.OK,
        trace_metadata={TRACE_SCHEMA_VERSION_KEY: str(TRACE_SCHEMA_VERSION)},
        tags={},
    )


def get_traces(experiment_id=None) -> list[Trace]:
    # Get all traces from the backend
    return TracingClient().search_traces(
        locations=[experiment_id or _get_experiment_id()],
    )


def purge_traces(experiment_id=None):
    if len(get_traces(experiment_id)) == 0:
        return

    # Delete all traces from the backend
    TracingClient().delete_traces(
        experiment_id=experiment_id or _get_experiment_id(),
        max_traces=1000,
        max_timestamp_millis=int(time.time() * 1000),
    )


def get_tracer_tracking_uri() -> str | None:
    """Get current tracking URI configured as the trace export destination."""
    from opentelemetry import trace

    tracer = _get_tracer(__name__)
    if isinstance(tracer, trace.ProxyTracer):
        tracer = tracer._tracer
    span_processor = tracer.span_processor._span_processors[0]

    if isinstance(span_processor, MlflowV3SpanProcessor):
        return span_processor.span_exporter._client.tracking_uri


@pytest.fixture
def reset_autolog_state():
    """Reset autologging state to avoid interference between tests"""
    yield

    for flavor in FLAVOR_TO_MODULE_NAME:
        # 1. Remove post-import hooks (registered by global mlflow.autolog() function)
        mlflow.utils.import_hooks._post_import_hooks.pop(flavor, None)

    for flavor in AUTOLOGGING_INTEGRATIONS.keys():
        # 2. Disable autologging for the flavor. This is necessary because some autologging
        #    update global settings (e.g. callbacks) and we need to revert them.
        try:
            if autolog := get_autolog_function(flavor):
                autolog(disable=True)
        except ImportError:
            pass

        # 3. Revert any patches applied by autologging
        revert_patches(flavor)

    AUTOLOGGING_INTEGRATIONS.clear()


def score_in_model_serving(model_uri: str, model_input: dict[str, Any]):
    """
    A helper function to emulate model prediction inside a Databricks model serving environment.

    This is highly simplified version, but captures important aspects for testing tracing:
      1. Setting env vars that users set for enable tracing in model serving
      2. Load the model in a background thread
    """
    from mlflow.pyfunc.context import Context, set_prediction_context

    with mock.patch.dict(
        "os.environ",
        os.environ | {"IS_IN_DB_MODEL_SERVING_ENV": "true", "ENABLE_MLFLOW_TRACING": "true"},
        clear=True,
    ):
        # Reset tracing setup to start fresh w/ model serving environment
        mlflow.tracing.reset()

        def _load_model():
            return mlflow.pyfunc.load_model(model_uri)

        with ThreadPoolExecutor(max_workers=1) as executor:
            model = executor.submit(_load_model).result()

        # Score the model
        request_id = uuid.uuid4().hex
        with set_prediction_context(Context(request_id=request_id)):
            predictions = model.predict(model_input)

        trace = pop_trace(request_id)
        return (request_id, predictions, trace)


def skip_when_testing_trace_sdk(f):
    # Decorator to Skip the test if only mlflow-tracing package is installed and
    # not the full mlflow package.
    msg = "Skipping test because it requires mlflow or mlflow-skinny to be installed."
    skip_decorator = pytest.mark.skipif(IS_TRACING_SDK_ONLY, reason=msg)
    return skip_decorator(f)


def skip_module_when_testing_trace_sdk():
    """Skip the entire module if only mlflow-tracing package is installed"""
    if IS_TRACING_SDK_ONLY:
```

## 原始行 116 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from opentelemetry.sdk.trace import Event
print(inspect.getsource(Event))
PY
python -m compileall -q mlflow/entities/span.py mlflow/tracing/trace_manager.py mlflow/tracing/utils/otlp.py"
```

退出码：`0`

输出：
```
class Event(EventBase):
    """A text annotation with a set of attributes. The attributes of an event
    are immutable.

    Args:
        name: Name of the event.
        attributes: Attributes of the event.
        timestamp: Timestamp of the event. If `None` it will filled
            automatically.
    """

    def __init__(
        self,
        name: str,
        attributes: types.Attributes = None,
        timestamp: Optional[int] = None,
        limit: Optional[int] = _DEFAULT_OTEL_SPAN_ATTRIBUTE_COUNT_LIMIT,
    ) -> None:
        super().__init__(name, timestamp)
        self._attributes = attributes

    @property
    def attributes(self) -> types.Attributes:
        return self._attributes

    @property
    def dropped_attributes(self) -> int:
        if isinstance(self._attributes, BoundedAttributes):
            return self._attributes.dropped
        return 0
```

## 原始行 120 · file_change

```
{
  "id": "item_78",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/span.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/entities/span_status.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 123 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/entities/test_span_status.py tests/entities/test_trace.py tests/entities/test_trace_data.py tests/entities/test_span_event.py'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 49 items

tests/entities/test_span_status.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                       [ 30%][0m
tests/entities/test_trace.py [32m.[0m[32m.[0m[33ms[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                     [ 77%][0m
tests/entities/test_trace_data.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                                 [ 89%][0m
tests/entities/test_span_event.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[33m                                  [100%][0m

[33m=============================== warnings summary ===============================[0m
tests/entities/test_trace_data.py::test_intermediate_outputs_from_attribute
  /testbed/tests/entities/test_trace_data.py:168: FutureWarning: ``mlflow.entities.trace_data.TraceData.intermediate_outputs`` is deprecated since 3.6.0. This method will be removed in a future release. Use ``trace.search_spans(name=...)`` instead.
    assert trace.data.intermediate_outputs == intermediate_outputs

tests/entities/test_trace_data.py::test_intermediate_outputs_from_spans
  /testbed/tests/entities/test_trace_data.py:189: FutureWarning: ``mlflow.entities.trace_data.TraceData.intermediate_outputs`` is deprecated since 3.6.0. This method will be removed in a future release. Use ``trace.search_spans(name=...)`` instead.
    assert trace.data.intermediate_outputs == {

tests/entities/test_trace_data.py::test_intermediate_outputs_no_value
  /testbed/tests/entities/test_trace_data.py:204: FutureWarning: ``mlflow.entities.trace_data.TraceData.intermediate_outputs`` is deprecated since 3.6.0. This method will be removed in a future release. Use ``trace.search_spans(name=...)`` instead.
    assert trace.data.intermediate_outputs is None

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
3.53s call     tests/entities/test_trace.py::test_json_deserialization
3.30s call     tests/entities/test_trace.py::test_trace_to_from_dict_and_json
3.18s call     tests/entities/test_trace.py::test_search_spans[None-None-expected0]
2.20s call     tests/entities/test_trace.py::test_search_spans[None-_two$-expected5]
2.07s call     tests/entities/test_trace_data.py::test_intermediate_outputs_from_attribute
1.84s call     tests/entities/test_trace.py::test_search_spans[None-.*ONE-expected6]
1.83s call     tests/entities/test_trace.py::test_search_spans[None-add_two-expected2]
1.77s call     tests/entities/test_trace.py::test_search_spans[CHAIN-None-expected1]
1.71s call     tests/entities/test_trace.py::test_search_spans_raise_for_invalid_param_type
1.70s call     tests/entities/test_trace.py::test_search_spans[None-add.*-expected3]

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                | Duration | Tests | Min    | Max    | Avg    |
| ---- | ----------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/entities/test_trace.py`      | 33.97s   | 23    | 0.000s | 3.536s | 1.477s |
| 2    | `tests/entities/test_trace_data.py` | 10.05s   | 6     | 1.520s | 2.070s | 1.675s |

::endgroup::

[33m================== [32m48 passed[0m, [33m[1m1 skipped[0m, [33m[1m3 warnings[0m[33m in 44.08s[0m[33m ==================[0m
```

## 原始行 126 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/entities/span.py | sed -n '90,520p'; nl -ba mlflow/entities/span.py | sed -n '640,1080p'"
```

退出码：`0`

输出：
```
    90	
    91	
    92	class Span:
    93	    """
    94	    A span object. A span represents a unit of work or operation and is the building
    95	    block of Traces.
    96	
    97	    This Span class represents immutable span data that is already finished and persisted.
    98	    The "live" span that is being created and updated during the application runtime is
    99	    represented by the :py:class:`LiveSpan <mlflow.entities.LiveSpan>` subclass.
   100	    """
   101	
   102	    def __init__(self, otel_span: OTelReadableSpan):
   103	        if not isinstance(otel_span, OTelReadableSpan):
   104	            raise MlflowException(
   105	                "The `otel_span` argument for the Span class must be an instance of ReadableSpan, "
   106	                f"but got {type(otel_span)}.",
   107	                INVALID_PARAMETER_VALUE,
   108	            )
   109	
   110	        self._span = otel_span
   111	        # Since the span is immutable, we can cache the attributes to avoid the redundant
   112	        # deserialization of the attribute values.
   113	        self._attributes = _CachedSpanAttributesRegistry(otel_span)
   114	
   115	    @property
   116	    @lru_cache(maxsize=1)
   117	    def trace_id(self) -> str:
   118	        """The trace ID of the span, a unique identifier for the trace it belongs to."""
   119	        return self.get_attribute(SpanAttributeKey.REQUEST_ID)
   120	
   121	    @property
   122	    def request_id(self) -> str:
   123	        """Deprecated alias for :attr:`trace_id`."""
   124	        return self.trace_id
   125	
   126	    @property
   127	    def attributes(self) -> dict[str, Any]:
   128	        """Return all span attributes, deserialized to Python values."""
   129	        return {key: self._attributes.get(key) for key in self._span.attributes}
   130	
   131	    @property
   132	    def events(self) -> list[SpanEvent]:
   133	        """Return the events recorded on this span."""
   134	        return [
   135	            SpanEvent(
   136	                name=event.name,
   137	                timestamp=event.timestamp,
   138	                attributes=dict(event.attributes or {}),
   139	            )
   140	            for event in (self._span.events or [])
   141	        ]
   142	
   143	    @property
   144	    def span_type(self) -> str:
   145	        """The semantic type assigned to the span."""
   146	        return self.get_attribute(SpanAttributeKey.SPAN_TYPE)
   147	
   148	
   149	
   150	
   151	
   152	
   153	    @property
   154	    def span_id(self) -> str:
   155	        """The ID of the span. This is only unique within a trace."""
   156	        return encode_span_id(self._span.context.span_id)
   157	
   158	    @property
   159	    def name(self) -> str:
   160	        """The name of the span."""
   161	        return self._span.name
   162	
   163	    @property
   164	    def start_time_ns(self) -> int:
   165	        """The start time of the span in nanosecond."""
   166	        return self._span._start_time
   167	
   168	    @property
   169	    def end_time_ns(self) -> int | None:
   170	        """The end time of the span in nanosecond."""
   171	        return self._span._end_time
   172	
   173	    @property
   174	    def parent_id(self) -> str | None:
   175	        """The span ID of the parent span."""
   176	        if self._span.parent is None:
   177	            return None
   178	        return encode_span_id(self._span.parent.span_id)
   179	
   180	    @property
   181	    def status(self) -> SpanStatus:
   182	        """The status of the span."""
   183	        return SpanStatus.from_otel_status(self._span.status)
   184	
   185	    @property
   186	    def inputs(self) -> Any:
   187	        """The input values of the span."""
   188	        return self.get_attribute(SpanAttributeKey.INPUTS)
   189	
   190	    @property
   191	    def outputs(self) -> Any:
   192	        """The output values of the span."""
   193	        return self.get_attribute(SpanAttributeKey.OUTPUTS)
   194	
   195	
   196	
   197	
   198	
   199	
   200	    @property
   201	    def _trace_id(self) -> str:
   202	        """
   203	        The OpenTelemetry trace ID of the span. Note that this should not be exposed to
   204	        the user, instead, use trace_id property as an unique identifier for a trace.
   205	        """
   206	        return encode_trace_id(self._span.context.trace_id)
   207	
   208	
   209	
   210	
   211	
   212	
   213	
   214	
   215	
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	    def __repr__(self):
   238	        return (
   239	            f"{type(self).__name__}(name={self.name!r}, trace_id={self.trace_id!r}, "
   240	            f"span_id={self.span_id!r}, parent_id={self.parent_id!r})"
   241	        )
   242	
   243	    def get_attribute(self, key: str) -> Any | None:
   244	        """
   245	        Get a single attribute value from the span.
   246	
   247	        Args:
   248	            key: The key of the attribute to get.
   249	
   250	        Returns:
   251	            The value of the attribute if it exists, otherwise None.
   252	        """
   253	        return self._attributes.get(key)
   254	
   255	    def to_dict(self) -> dict[str, Any]:
   256	        """Serialize this span using the OpenTelemetry-compatible v3 schema."""
   257	        context = self._span.get_span_context()
   258	        parent = self._span.parent
   259	        return {
   260	            "name": self.name,
   261	            "trace_id": _encode_id_to_byte(context.trace_id, 16),
   262	            "span_id": _encode_id_to_byte(context.span_id, 8),
   263	            "parent_span_id": _encode_id_to_byte(parent.span_id, 8) if parent else None,
   264	            "start_time_unix_nano": self.start_time_ns,
   265	            "end_time_unix_nano": self.end_time_ns,
   266	            "events": [
   267	                {
   268	                    "name": event.name,
   269	                    "time_unix_nano": event.timestamp,
   270	                    "attributes": event.attributes,
   271	                }
   272	                for event in self.events
   273	            ],
   274	            "status": {
   275	                "code": self.status.status_code.to_otel_proto_status_code_name(),
   276	                "message": self.status.description,
   277	            },
   278	            "attributes": dict(self._span.attributes or {}),
   279	        }
   280	
   281	    def to_otel_proto(self) -> OTelProtoSpan:
   282	        """Convert this span to an OTLP protobuf span."""
   283	        context = self._span.get_span_context()
   284	        proto = OTelProtoSpan(
   285	            trace_id=context.trace_id.to_bytes(16, byteorder="big", signed=False),
   286	            span_id=context.span_id.to_bytes(8, byteorder="big", signed=False),
   287	            name=self.name,
   288	            start_time_unix_nano=self.start_time_ns,
   289	            end_time_unix_nano=self.end_time_ns or 0,
   290	            status=self.status.to_otel_proto_status(),
   291	        )
   292	        if self._span.parent is not None:
   293	            proto.parent_span_id = self._span.parent.span_id.to_bytes(
   294	                8, byteorder="big", signed=False
   295	            )
   296	        for key, value in self.attributes.items():
   297	            attribute = proto.attributes.add()
   298	            attribute.key = key
   299	            _set_otel_proto_anyvalue(attribute.value, value)
   300	        proto.events.extend(event.to_otel_proto() for event in self.events)
   301	        return proto
   302	
   303	    @classmethod
   304	    def from_otel_proto(cls, otel_proto_span, location_id: str | None = None) -> "Span":
   305	        """Create an immutable MLflow span from an OTLP protobuf span."""
   306	        try:
   307	            if len(otel_proto_span.trace_id) != 16:
   308	                raise ValueError("OTel trace_id must contain exactly 16 bytes")
   309	            if len(otel_proto_span.span_id) != 8:
   310	                raise ValueError("OTel span_id must contain exactly 8 bytes")
   311	            otel_trace_id = int.from_bytes(otel_proto_span.trace_id, byteorder="big")
   312	            otel_span_id = int.from_bytes(otel_proto_span.span_id, byteorder="big")
   313	            if not otel_trace_id or not otel_span_id:
   314	                raise ValueError("OTel trace_id and span_id must be non-zero")
   315	
   316	            trace_id = (
   317	                generate_trace_id_v4_from_otel_trace_id(otel_trace_id, location_id)
   318	                if location_id is not None
   319	                else generate_mlflow_trace_id_from_otel_trace_id(otel_trace_id)
   320	            )
   321	            attributes = {
   322	                attribute.key: dump_span_attribute_value(
   323	                    _decode_otel_proto_anyvalue(attribute.value)
   324	                )
   325	                for attribute in otel_proto_span.attributes
   326	            }
   327	            attributes[SpanAttributeKey.REQUEST_ID] = dump_span_attribute_value(trace_id)
   328	            parent_id = (
   329	                int.from_bytes(otel_proto_span.parent_span_id, byteorder="big")
   330	                if otel_proto_span.parent_span_id
   331	                else None
   332	            )
   333	            events = [
   334	                OTelEvent(
   335	                    name=event.name,
   336	                    timestamp=event.time_unix_nano,
   337	                    attributes={
   338	                        attribute.key: _decode_otel_proto_anyvalue(attribute.value)
   339	                        for attribute in event.attributes
   340	                    },
   341	                )
   342	                for event in otel_proto_span.events
   343	            ]
   344	            otel_span = OTelReadableSpan(
   345	                name=otel_proto_span.name,
   346	                context=build_otel_context(otel_trace_id, otel_span_id),
   347	                parent=build_otel_context(otel_trace_id, parent_id) if parent_id else None,
   348	                start_time=otel_proto_span.start_time_unix_nano,
   349	                end_time=otel_proto_span.end_time_unix_nano or None,
   350	                attributes=attributes,
   351	                events=events,
   352	                status=SpanStatus.from_otel_proto_status(otel_proto_span.status).to_otel_status(),
   353	                resource=_OTelResource.get_empty(),
   354	            )
   355	            return cls(otel_span)
   356	        except Exception as e:
   357	            raise MlflowException(
   358	                "Failed to create a Span object from the OpenTelemetry protobuf span",
   359	                INVALID_PARAMETER_VALUE,
   360	            ) from e
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	    @classmethod
   393	    def from_dict(cls, data: dict[str, Any]) -> "Span":
   394	        """Create a Span object from the given dictionary."""
   395	        try:
   396	            # Try to deserialize the span using the v3 schema
   397	            request_id = data.get("attributes", {}).get(SpanAttributeKey.REQUEST_ID)
   398	            if not request_id:
   399	                raise MlflowException(
   400	                    f"The {SpanAttributeKey.REQUEST_ID} attribute is empty or missing.",
   401	                    INVALID_PARAMETER_VALUE,
   402	                )
   403	
   404	            if Span._is_span_v2_schema(data):
   405	                return cls.from_dict_v2(data)
   406	
   407	            if _is_base64_encoded(data["trace_id"]):
   408	                otel_trace_id = _decode_id_from_byte(data["trace_id"])
   409	                span_id = _decode_id_from_byte(data["span_id"])
   410	                # Parent ID always exists in proto (empty string) even if the span is a root span.
   411	                parent_id = (
   412	                    _decode_id_from_byte(data["parent_span_id"]) if data["parent_span_id"] else None
   413	                )
   414	            else:
   415	                # In 3.5.0, Span.to_dict keeps trace_id and span_id as the object's properties
   416	                # format, so we need special handling for it.
   417	                otel_trace_id = decode_id(
   418	                    parse_trace_id_v4(data["trace_id"])[1].removeprefix(TRACE_REQUEST_ID_PREFIX)
   419	                )
   420	                span_id = decode_id(data["span_id"])
   421	                parent_id = decode_id(data["parent_span_id"]) if data["parent_span_id"] else None
   422	
   423	            status_code_str = data["status"]["code"]
   424	            try:
   425	                status_code = SpanStatusCode.from_otel_proto_status_code_name(status_code_str)
   426	            except MlflowException:
   427	                # In 3.5.0 Span.to_dict keeps status code as the SpanStatusCode enum value
   428	                # Fall back to value format (e.g., "OK", "ERROR")
   429	                status_code = SpanStatusCode(status_code_str)
   430	            status = SpanStatus(
   431	                status_code=status_code,
   432	                description=data["status"].get("message", ""),
   433	            )
   434	
   435	            end_time_ns = data.get("end_time_unix_nano")
   436	            end_time_ns = int(end_time_ns) if end_time_ns else None
   437	
   438	            otel_span = OTelReadableSpan(
   439	                name=data["name"],
   440	                context=build_otel_context(otel_trace_id, span_id),
   441	                parent=build_otel_context(otel_trace_id, parent_id) if parent_id else None,
   442	                start_time=int(data["start_time_unix_nano"]),
   443	                end_time=end_time_ns,
   444	                attributes=data["attributes"],
   445	                status=status.to_otel_status(),
   446	                # Setting an empty resource explicitly. Otherwise OTel create a new Resource by
   447	                # Resource.create(), which introduces a significant overhead in some environments.
   448	                # https://github.com/mlflow/mlflow/issues/15625
   449	                resource=_OTelResource.get_empty(),
   450	                events=[
   451	                    OTelEvent(
   452	                        name=event["name"],
   453	                        timestamp=int(event["time_unix_nano"]),
   454	                        attributes=event.get("attributes", {}),
   455	                    )
   456	                    for event in data.get("events", [])
   457	                ],
   458	            )
   459	            return cls(otel_span)
   460	        except Exception as e:
   461	            raise MlflowException(
   462	                "Failed to create a Span object from the given dictionary",
   463	                INVALID_PARAMETER_VALUE,
   464	            ) from e
   465	
   466	    @staticmethod
   467	    def _is_span_v2_schema(data: dict[str, Any]) -> bool:
   468	        return "context" in data or "start_time" in data or "status_code" in data
   469	
   470	    @classmethod
   471	    def from_dict_v2(cls, data: dict[str, Any]) -> "Span":
   472	        """Deserialize the legacy MLflow tracing v2 span schema."""
   473	        context = data["context"]
   474	        trace_id = decode_id(context["trace_id"])
   475	        span_id = decode_id(context["span_id"])
   476	        parent_id = decode_id(data["parent_id"]) if data.get("parent_id") else None
   477	        status = SpanStatus(
   478	            status_code=data.get("status_code", SpanStatusCode.UNSET),
   479	            description=data.get("status_message", ""),
   480	        )
   481	        return cls(
   482	            OTelReadableSpan(
   483	                name=data["name"],
   484	                context=build_otel_context(trace_id, span_id),
   485	                parent=build_otel_context(trace_id, parent_id) if parent_id else None,
   486	                start_time=int(data["start_time"]),
   487	                end_time=int(data["end_time"]) if data.get("end_time") is not None else None,
   488	                attributes=data.get("attributes", {}),
   489	                events=[
   490	                    OTelEvent(
   491	                        name=event["name"],
   492	                        timestamp=int(event.get("timestamp", event.get("time_unix_nano", 0))),
   493	                        attributes=event.get("attributes", {}),
   494	                    )
   495	                    for event in data.get("events", [])
   496	                ],
   497	                status=status.to_otel_status(),
   498	                resource=_OTelResource.get_empty(),
   499	            )
   500	        )
   501	
   502	
   503	
   504	
   505	
   506	
   507	
   508	
   509	
   510	
   511	
   512	
   513	
   514	
   515	
   516	
   517	
   518	
   519	
   520	
   640	
   641	
   642	
   643	
   644	
   645	
   646	
   647	
   648	
   649	
   650	
   651	
   652	
   653	
   654	
   655	class LiveSpan(Span):
   656	    """
   657	    A "live" version of the :py:class:`Span <mlflow.entities.Span>` class.
   658	
   659	    The live spans are those being created and updated during the application runtime.
   660	    When users start a new span using the tracing APIs within their code, this live span
   661	    object is returned to get and set the span attributes, status, events, and etc.
   662	    """
   663	
   664	    def __init__(
   665	        self,
   666	        otel_span: OTelSpan,
   667	        trace_id: str,
   668	        span_type: str = SpanType.UNKNOWN,
   669	    ):
   670	        """
   671	        The `otel_span` argument takes an instance of OpenTelemetry Span class, which is
   672	        indeed a subclass of ReadableSpan. Thanks to this, the getter methods of the Span
   673	        class can be reused without any modification.
   674	
   675	        Note that the constructor doesn't call the super().__init__ method, because the Span
   676	        initialization logic is a bit different from the immutable span.
   677	        """
   678	        if not isinstance(otel_span, OTelReadableSpan):
   679	            raise MlflowException(
   680	                "The `otel_span` argument for the LiveSpan class must be an instance of "
   681	                f"trace.Span, but got {type(otel_span)}.",
   682	                INVALID_PARAMETER_VALUE,
   683	            )
   684	
   685	        self._span = otel_span
   686	        self._attributes = _SpanAttributesRegistry(otel_span)
   687	        self._attributes.set(SpanAttributeKey.REQUEST_ID, trace_id)
   688	        self._attributes.set(SpanAttributeKey.SPAN_TYPE, span_type)
   689	        # Track the original span name for deduplication purposes during span logging.
   690	        # Why: When traces contain multiple spans with identical names (e.g., multiple "LLM"
   691	        # or "query" spans), it's difficult for users to distinguish between them in the UI
   692	        # and logs. As spans are logged, we incrementally add numeric suffixes (_1, _2, etc.) to
   693	        # make each span uniquely identifiable within its trace
   694	        self._original_name = otel_span.name
   695	
   696	    @classmethod
   697	    def from_dict(cls, data: dict[str, Any]) -> "Span":
   698	        raise NotImplementedError(
   699	            "LiveSpan cannot be reconstructed from a dictionary. Use Span.from_dict() instead."
   700	        )
   701	
   702	    def set_span_type(self, span_type: str):
   703	        """Set the semantic type of this span."""
   704	        self.set_attribute(SpanAttributeKey.SPAN_TYPE, span_type)
   705	
   706	    def to_immutable_span(self) -> "Span":
   707	        """Return an immutable view backed by the same OpenTelemetry span."""
   708	        return Span(self._span)
   709	
   710	
   711	
   712	
   713	
   714	    def set_inputs(self, inputs: Any):
   715	        """Set the input values to the span."""
   716	        self.set_attribute(SpanAttributeKey.INPUTS, inputs)
   717	
   718	    def set_outputs(self, outputs: Any):
   719	        """Set the output values to the span."""
   720	        self.set_attribute(SpanAttributeKey.OUTPUTS, outputs)
   721	
   722	    def set_attributes(self, attributes: dict[str, Any]):
   723	        """
   724	        Set the attributes to the span. The attributes must be a dictionary of key-value pairs.
   725	        This method is additive, i.e. it will add new attributes to the existing ones. If an
   726	        attribute with the same key already exists, it will be overwritten.
   727	        """
   728	        if not isinstance(attributes, dict):
   729	            _logger.warning(
   730	                f"Attributes must be a dictionary, but got {type(attributes)}. Skipping."
   731	            )
   732	            return
   733	
   734	        for key, value in attributes.items():
   735	            self.set_attribute(key, value)
   736	
   737	    def set_attribute(self, key: str, value: Any):
   738	        """Set a single attribute to the span."""
   739	        self._attributes.set(key, value)
   740	
   741	    def set_status(self, status: SpanStatusCode | str):
   742	        """
   743	        Set the status of the span.
   744	
   745	        Args:
   746	            status: The status of the span. This can be a
   747	                :py:class:`SpanStatus <mlflow.entities.SpanStatus>` object or a string representing
   748	                of the status code defined in
   749	                :py:class:`SpanStatusCode <mlflow.entities.SpanStatusCode>`
   750	                e.g. ``"OK"``, ``"ERROR"``.
   751	        """
   752	        if isinstance(status, str):
   753	            status = SpanStatus(status)
   754	
   755	        # NB: We need to set the OpenTelemetry native StatusCode, because span's set_status
   756	        #     method only accepts a StatusCode enum in their definition.
   757	        #     https://github.com/open-telemetry/opentelemetry-python/blob/8ed71b15fb8fc9534529da8ce4a21e686248a8f3/opentelemetry-sdk/src/opentelemetry/sdk/trace/__init__.py#L949
   758	        #     Working around this is possible, but requires some hack to handle automatic status
   759	        #     propagation mechanism, so here we just use the native object that meets our
   760	        #     current requirements at least. Nevertheless, declaring the new class extending
   761	        #     the OpenTelemetry Status class so users code doesn't have to import the OTel's
   762	        #     StatusCode object, which makes future migration easier.
   763	        self._span.set_status(status.to_otel_status())
   764	
   765	    def add_event(self, event: SpanEvent):
   766	        """
   767	        Add an event to the span.
   768	
   769	        Args:
   770	            event: The event to add to the span. This should be a
   771	                :py:class:`SpanEvent <mlflow.entities.SpanEvent>` object.
   772	        """
   773	        self._span.add_event(event.name, event.attributes, event.timestamp)
   774	
   775	    def record_exception(self, exception: str | Exception):
   776	        """
   777	        Record an exception on the span, adding an exception event and setting span status to ERROR.
   778	
   779	        Args:
   780	            exception: The exception to record. Can be an Exception instance or a string
   781	                describing the exception.
   782	        """
   783	        if isinstance(exception, Exception):
   784	            self.add_event(SpanEvent.from_exception(exception))
   785	        elif isinstance(exception, str):
   786	            self.add_event(SpanEvent.from_exception(Exception(exception)))
   787	        else:
   788	            raise MlflowException(
   789	                "The `exception` parameter must be an Exception instance or a string.",
   790	                INVALID_PARAMETER_VALUE,
   791	            )
   792	
   793	        self.set_status(
   794	            SpanStatus(
   795	                status_code=SpanStatusCode.ERROR,
   796	                description=f"{type(exception).__name__}: {exception}",
   797	            )
   798	        )
   799	
   800	    def end(
   801	        self,
   802	        outputs: Any | None = None,
   803	        attributes: dict[str, Any] | None = None,
   804	        status: SpanStatus | str | None = None,
   805	        end_time_ns: int | None = None,
   806	    ):
   807	        """
   808	        End the span.
   809	
   810	        outputs: Outputs to set on the span.
   811	        attributes: A dictionary of attributes to set on the span. If the span already has
   812	            attributes, the new attributes will be merged with the existing ones. If the same
   813	            key already exists, the new value will overwrite the old one.
   814	        status: The status of the span. This can be a
   815	            :py:class:`SpanStatus <mlflow.entities.SpanStatus>` object or a string
   816	            representing the status code defined in
   817	            :py:class:`SpanStatusCode <mlflow.entities.SpanStatusCode>`
   818	            e.g. ``"OK"``, ``"ERROR"``. The default status is OK.
   819	        end_time_ns: The end time of the span in nano seconds since the UNIX epoch.
   820	            If not provided, the current time will be used.
   821	
   822	        :meta private:
   823	        """
   824	        try:
   825	            self.set_attributes(attributes or {})
   826	            if outputs is not None:
   827	                self.set_outputs(outputs)
   828	            if status is not None:
   829	                self.set_status(status)
   830	
   831	            # NB: In OpenTelemetry, status code remains UNSET if not explicitly set
   832	            # by the user. However, there is not way to set the status when using
   833	            # @mlflow.trace decorator. Therefore, we just automatically set the status
   834	            # to OK if it is not ERROR.
   835	            if self.status.status_code != SpanStatusCode.ERROR:
   836	                self.set_status(SpanStatus(SpanStatusCode.OK))
   837	
   838	            # Apply span processors
   839	            apply_span_processors(self)
   840	
   841	            self._span.end(end_time=end_time_ns)
   842	
   843	        except Exception as e:
   844	            _logger.warning(
   845	                f"Failed to end span {self.span_id}: {e}. "
   846	                "For full traceback, set logging level to debug.",
   847	                exc_info=_logger.isEnabledFor(logging.DEBUG),
   848	            )
   849	
   850	
   851	
   852	
   853	
   854	
   855	
   856	
   857	
   858	
   859	
   860	
   861	
   862	    @classmethod
   863	    def from_immutable_span(
   864	        cls,
   865	        span: Span,
   866	        parent_span_id: str | None = None,
   867	        trace_id: str | None = None,
   868	        experiment_id: str | None = None,
   869	        otel_trace_id: str | None = None,
   870	    ) -> "LiveSpan":
   871	        """
   872	        Create a new LiveSpan object from the given immutable span by
   873	        cloning the underlying OpenTelemetry span within current context.
   874	
   875	        This is particularly useful when we merging a remote trace into the current trace.
   876	        We cannot merge the remote trace directly, because it is already stored as an immutable
   877	        span, meaning that we cannot update metadata like trace ID, parent span ID,
   878	        which are necessary for merging the trace.
   879	
   880	        Args:
   881	            span: The immutable span object to clone.
   882	            parent_span_id: The parent span ID of the new span.
   883	                If it is None, the span will be created as a root span.
   884	            trace_id: The trace ID to be set on the new span. Specify this if you want to
   885	                create the new span with a particular trace ID.
   886	            experiment_id: The experiment ID to be set on the new span. If not specified, the
   887	                experiment ID will be set to the current experiment ID.
   888	            otel_trace_id: The OpenTelemetry trace ID of the new span in hex encoded format.
   889	                If not specified, the newly generated trace ID will be used.
   890	
   891	        Returns:
   892	            The new LiveSpan object with the same state as the original span.
   893	
   894	        :meta private:
   895	        """
   896	        from mlflow.tracing.trace_manager import InMemoryTraceManager
   897	
   898	        trace_manager = InMemoryTraceManager.get_instance()
   899	        parent_span = trace_manager.get_span_from_id(trace_id, parent_span_id)
   900	
   901	        # Create a new span with the same name, parent, and start time
   902	        otel_span = mlflow.tracing.provider.start_detached_span(
   903	            name=span.name,
   904	            parent=parent_span._span if parent_span else None,
   905	            start_time_ns=span.start_time_ns,
   906	            experiment_id=experiment_id,
   907	        )
   908	
   909	        # The latter one from attributes is the newly generated trace ID by the span processor.
   910	        trace_id = trace_id or json.loads(otel_span.attributes.get(SpanAttributeKey.REQUEST_ID))
   911	        # Span processor registers a new span in the in-memory trace manager, but we want to pop it
   912	        clone_span = trace_manager._traces[trace_id].span_dict.pop(
   913	            encode_span_id(otel_span.context.span_id)
   914	        )
   915	
   916	        # Copy all the attributes, inputs, outputs, and events from the original span
   917	        clone_span.set_status(span.status)
   918	        clone_span.set_attributes(
   919	            {k: v for k, v in span.attributes.items() if k != SpanAttributeKey.REQUEST_ID}
   920	        )
   921	        if span.inputs:
   922	            clone_span.set_inputs(span.inputs)
   923	        if span.outputs:
   924	            clone_span.set_outputs(span.outputs)
   925	        for event in span.events:
   926	            clone_span.add_event(event)
   927	
   928	        # Update trace ID and span ID
   929	        context = span._span.get_span_context()
   930	        clone_span._span._context = SpanContext(
   931	            # Override otel_trace_id if provided, otherwise use the new trace ID
   932	            trace_id=decode_id(otel_trace_id) if otel_trace_id else otel_span.context.trace_id,
   933	            # Re-use same span ID as their ID space is local to the trace
   934	            span_id=context.span_id,
   935	            is_remote=context.is_remote,
   936	            # Override trace flag as if it is sampled within current context.
   937	            trace_flags=TraceFlags(TraceFlags.SAMPLED),
   938	        )
   939	
   940	        return clone_span
   941	
   942	
   943	NO_OP_SPAN_TRACE_ID = "MLFLOW_NO_OP_SPAN_TRACE_ID"
   944	
   945	
   946	class NoOpSpan(Span):
   947	    """
   948	    No-op implementation of the Span interface.
   949	
   950	    This instance should be returned from the mlflow.start_span context manager when span
   951	    creation fails. This class should have exactly the same interface as the Span so that
   952	    user's setter calls do not raise runtime errors.
   953	
   954	    E.g.
   955	
   956	    .. code-block:: python
   957	
   958	        with mlflow.start_span("span_name") as span:
   959	            # Even if the span creation fails, the following calls should pass.
   960	            span.set_inputs({"x": 1})
   961	            # Do something
   962	
   963	    """
   964	
   965	    def __init__(self):
   966	        self._span = NonRecordingSpan(context=None)
   967	        self._attributes = {}
   968	
   969	    @property
   970	    def _trace_id(self):
   971	        return None
   972	
   973	    @property
   974	    def trace_id(self):
   975	        return NO_OP_SPAN_TRACE_ID
   976	
   977	    @property
   978	    def request_id(self):
   979	        return self.trace_id
   980	
   981	    @property
   982	    def span_id(self):
   983	        return None
   984	
   985	    @property
   986	    def name(self):
   987	        return None
   988	
   989	    @property
   990	    def start_time_ns(self):
   991	        return None
   992	
   993	    @property
   994	    def end_time_ns(self):
   995	        return None
   996	
   997	    @property
   998	    def status(self):
   999	        return None
  1000	
  1001	    @property
  1002	    def attributes(self):
  1003	        return {}
  1004	
  1005	    @property
  1006	    def events(self):
  1007	        return []
  1008	
  1009	    @property
  1010	    def inputs(self):
  1011	        return None
  1012	
  1013	    @property
  1014	    def outputs(self):
  1015	        return None
  1016	
  1017	    @property
  1018	    def span_type(self):
  1019	        return None
  1020	
  1021	
  1022	
  1023	
  1024	
  1025	
  1026	
  1027	
  1028	
  1029	
  1030	
  1031	
  1032	
  1033	
  1034	
  1035	
  1036	
  1037	
  1038	
  1039	
  1040	
  1041	
  1042	
  1043	
  1044	    @property
  1045	    def context(self):
  1046	        return None
  1047	
  1048	    @property
  1049	    def parent_id(self):
  1050	        return None
  1051	
  1052	    def get_attribute(self, key: str):
  1053	        return None
  1054	
  1055	    def set_attribute(self, key: str, value: Any):
  1056	        pass
  1057	
  1058	    def set_attributes(self, attributes: dict[str, Any]):
  1059	        pass
  1060	
  1061	    def set_inputs(self, inputs: dict[str, Any]):
  1062	        pass
  1063	
  1064	    def set_outputs(self, outputs: dict[str, Any]):
  1065	        pass
  1066	
  1067	    def set_span_type(self, span_type: str):
  1068	        pass
  1069	
  1070	    def set_status(self, status: SpanStatus):
  1071	        pass
  1072	
  1073	    def add_event(self, event: SpanEvent):
  1074	        pass
  1075	
  1076	    def end(
  1077	        self,
  1078	        outputs: Any | None = None,
  1079	        attributes: dict[str, Any] | None = None,
  1080	        status: SpanStatus | str | None = None,
```

## 原始行 129 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"\\.context\" mlflow tests --include='*.py' | grep -E \"span\\.context|mlflow_span\\.context|root_span\\.context|child_span\\.context\" | head -100; grep -R -n \"\\.duration_ns\\|duration_ns\" mlflow tests --include='*.py' | head -50; grep -R -n \"to_immutable_span\\|set_span_type\" tests --include='*.py' | head -100; grep -R -n \"NoOpSpan\" tests --include='*.py' | head -100"
```

退出码：`0`

输出：
```
mlflow/ag2/ag2_logger.py:238:                    pending.span._span._parent = span._span.context
mlflow/tracing/utils/__init__.py:333:    return generate_trace_id_v4_from_otel_trace_id(span.context.trace_id, location)
mlflow/tracing/utils/__init__.py:342:    return generate_mlflow_trace_id_from_otel_trace_id(span.context.trace_id)
mlflow/tracing/fluent.py:490:            request_id, encode_span_id(otel_span.context.span_id)
mlflow/tracing/fluent.py:592:            trace_id, encode_span_id(otel_span.context.span_id)
mlflow/tracing/fluent.py:923:    return trace_manager.get_span_from_id(request_id, encode_span_id(otel_span.context.span_id))
mlflow/tracing/export/mlflow_v3.py:110:            mlflow_trace_id = manager.get_mlflow_trace_id_from_otel_id(span.context.trace_id)
mlflow/tracing/export/mlflow_v3.py:112:            span_id = encode_span_id(span.context.span_id)
mlflow/tracing/export/mlflow_v3.py:132:            manager_trace = manager.pop_trace(span.context.trace_id)
mlflow/tracing/export/inference_table.py:76:            manager_trace = self._trace_manager.pop_trace(span.context.trace_id)
mlflow/tracing/processor/mlflow_v3.py:51:        self._trace_manager.register_trace(root_span.context.trace_id, trace_info)
mlflow/tracing/processor/uc_table.py:61:        self._trace_manager.register_trace(root_span.context.trace_id, trace_info)
mlflow/tracing/processor/inference_table.py:112:            self._trace_manager.register_trace(span.context.trace_id, trace_info)
mlflow/tracing/processor/base_mlflow.py:72:        trace_id = self._trace_manager.get_mlflow_trace_id_from_otel_id(span.context.trace_id)
mlflow/tracing/processor/otel_metrics_mixin.py:111:            span.context.trace_id
mlflow/tracing/processor/otel.py:48:                self._trace_manager.register_trace(span.context.trace_id, trace_info)
mlflow/tracing/processor/otel.py:51:                    span.context.trace_id
mlflow/tracing/processor/otel.py:62:            self._trace_manager.pop_trace(span.context.trace_id)
mlflow/entities/span.py:156:        return encode_span_id(self._span.context.span_id)
mlflow/entities/span.py:206:        return encode_trace_id(self._span.context.trace_id)
mlflow/entities/span.py:913:            encode_span_id(otel_span.context.span_id)
mlflow/entities/span.py:932:            trace_id=decode_id(otel_trace_id) if otel_trace_id else otel_span.context.trace_id,
tests/tracing/export/test_inference_table_exporter.py:259:    trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_inference_table_exporter.py:335:    trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_inference_table_exporter.py:380:    trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_inference_table_exporter.py:445:    trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_inference_table_exporter.py:502:        trace_manager.register_trace(span._span.context.trace_id, trace_info)
tests/tracing/export/test_uc_table_exporter.py:31:    trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_mlflow_v3_exporter.py:293:        trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_mlflow_v3_exporter.py:384:        trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_mlflow_v3_exporter.py:454:        trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/export/test_mlflow_v3_exporter.py:494:    trace_manager.register_trace(otel_span.context.trace_id, trace_info)
tests/tracing/processor/test_mlflow_v3_processor.py:84:        trace_id = "tr-" + encode_trace_id(span.context.trace_id)
tests/tracing/opentelemetry/test_integration.py:28:        assert mlflow.get_current_active_span().span_id == encode_span_id(root_span.context.span_id)
tests/llama_index/test_llama_index_tracer.py:837:        trace_id = f"{otel_span.context.trace_id:032x}"
mlflow/claude_code/tracing.py:450:            duration_ns = next_timestamp_ns - timestamp_ns
mlflow/claude_code/tracing.py:452:            duration_ns = int(1000 * NANOSECONDS_PER_MS)  # 1 second default
mlflow/claude_code/tracing.py:484:            llm_span.end(end_time_ns=timestamp_ns + duration_ns)
mlflow/claude_code/tracing.py:489:            tool_duration_ns = duration_ns // len(tool_uses)
mlflow/claude_code/tracing.py:492:                tool_start_ns = timestamp_ns + (idx * tool_duration_ns)
mlflow/claude_code/tracing.py:509:                tool_span.end(end_time_ns=tool_start_ns + tool_duration_ns)
mlflow/store/tracking/dbmodels/models.py:1736:    duration_ns = Column(
mlflow/store/tracking/dbmodels/models.py:1768:        Index("index_spans_experiment_id_duration", "experiment_id", "duration_ns"),
mlflow/store/db_migrations/versions/a1b2c3d4e5f6_add_spans_table.py:36:            "duration_ns",
mlflow/store/db_migrations/versions/a1b2c3d4e5f6_add_spans_table.py:78:            ["experiment_id", "duration_ns"],
tests/store/tracking/test_sqlalchemy_store.py:7058:        assert saved_span.duration_ns == (span.end_time_ns - span.start_time_ns)
tests/utils/test_databricks_tracing_utils.py:199:        mlflow_span = span.to_immutable_span()
tests/utils/test_databricks_tracing_utils.py:249:        mlflow_span = span.to_immutable_span()
tests/utils/test_databricks_tracing_utils.py:311:        mlflow_span = span.to_immutable_span()
tests/tracing/test_fluent.py:1832:    """Test that record_exception works gracefully with NoOpSpan."""
tests/tracing/test_fluent.py:1834:    from mlflow.entities.span import NoOpSpan
tests/tracing/test_fluent.py:1836:    no_op_span = NoOpSpan()
```

## 原始行 131 · agent_message

```
The focused entity and lifecycle tests now pass. One compatibility issue surfaced in the masked processor module—a missing factory import prevented real spans from starting—so I restored that integration point as well. I’m now checking protobuf round-trips, factory dispatch, and the no-op contract directly, then I’ll run the broader tracing subset.
```

## 原始行 133 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import json
from opentelemetry.proto.trace.v1.trace_pb2 import Span as PSpan, Status
from mlflow.entities.span import Span, NoOpSpan, LiveSpan, create_mlflow_span
from mlflow.tracing.utils.otlp import _set_otel_proto_anyvalue, _decode_otel_proto_anyvalue

p=PSpan(trace_id=(123).to_bytes(16,'big'), span_id=(45).to_bytes(8,'big'), name='p', start_time_unix_nano=1, end_time_unix_nano=2, status=Status(code=Status.STATUS_CODE_ERROR,message='bad'))
for k,v in {'s':'x','i':2,'b':False,'n':None,'a':[1,'x',False], 'd':{'x':3}}.items():
 a=p.attributes.add(); a.key=k; _set_otel_proto_anyvalue(a.value,v)
e=p.events.add(); e.name='evt'; e.time_unix_nano=3
a=e.attributes.add(); a.key='nested'; _set_otel_proto_anyvalue(a.value, {'a':[1,True]})
s=Span.from_otel_proto(p)
assert s.trace_id.endswith('0000000000000000000000000000007b')
assert s.attributes['b'] is False and s.attributes['d']=={'x':3}
assert s.events[0].attributes == {'nested':{'a':[1,True]}}
p2=s.to_otel_proto(); s2=Span.from_otel_proto(p2)
assert s2.attributes == s.attributes
assert Span.from_dict(s.to_dict()).to_dict() == s.to_dict()
no=NoOpSpan(); no.set_inputs({}); no.set_outputs({}); no.set_attributes({}); no.add_event(None); no.end()
assert no.trace_id=='MLFLOW_NO_OP_SPAN_TRACE_ID' and no._trace_id is None
assert isinstance(create_mlflow_span(None,'x'), NoOpSpan)
try: LiveSpan.from_dict({})
except NotImplementedError: pass
else: raise AssertionError
print('manual span contracts passed')
PY"
```

退出码：`0`

输出：
```
manual span contracts passed
```

## 原始行 136 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/tracing --ignore=tests/tracing/test_otel_loading.py --ignore=tests/tracing/test_otel_logging.py'
```

退出码：`2`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 469 items / 1 error / 1 skipped

==================================== ERRORS ====================================
[31m[1m_____________ ERROR collecting tests/tracing/utils/test_config.py ______________[0m
[31mImportError while importing test module '/testbed/tests/tracing/utils/test_config.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
tests/tracing/utils/test_config.py:4: in <module>
    from mlflow.tracing.config import TracingConfig, get_config
E   ImportError: cannot import name 'get_config' from 'mlflow.tracing.config' (/testbed/mlflow/tracing/config.py)[0m
[36m[1m=========================== short test summary info ============================[0m
[31mERROR[0m tests/tracing/utils/test_config.py
!!!!!!!!!!!!!!!!!!!! Interrupted: 1 error during collection !!!!!!!!!!!!!!!!!!!!
[31m========================= [33m1 skipped[0m, [31m[1m1 error[0m[31m in 0.71s[0m[31m ==========================[0m
```

## 原始行 139 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' tests/tracing/utils/test_config.py; nl -ba mlflow/tracing/config.py | sed -n '1,150p'"
```

退出码：`0`

输出：
```
import pytest

import mlflow
from mlflow.tracing.config import TracingConfig, get_config


@pytest.fixture(autouse=True)
def reset_tracing_config():
    mlflow.tracing.reset()


def test_tracing_config_default_values():
    """Test that TracingConfig has expected default values."""
    config = TracingConfig()
    assert config.span_processors == []


def test_configure():
    # Default config
    assert get_config().span_processors == []

    def dummy_filter(span):
        pass

    mlflow.tracing.configure(span_processors=[dummy_filter])
    assert get_config().span_processors == [dummy_filter]

    mlflow.tracing.configure(span_processors=[])
    assert get_config().span_processors == []


def test_configure_empty_call():
    def dummy_filter(span):
        pass

    mlflow.tracing.configure(span_processors=[dummy_filter])
    assert get_config().span_processors == [dummy_filter]

    # No-op
    mlflow.tracing.configure()
    assert get_config().span_processors == [dummy_filter]


def test_reset_config():
    def filter1(span):
        pass

    assert get_config().span_processors == []

    mlflow.tracing.configure(span_processors=[filter1])
    assert get_config().span_processors == [filter1]

    mlflow.tracing.reset()
    assert get_config().span_processors == []


def test_configure_context_manager():
    def filter1(span):
        return

    def filter2(span):
        return

    # Set initial config
    mlflow.tracing.configure(span_processors=[filter1])

    assert get_config().span_processors == [filter1]

    with mlflow.tracing.configure(span_processors=[filter2]):
        assert get_config().span_processors == [filter2]

        with mlflow.tracing.configure(span_processors=[filter1, filter2]):
            assert get_config().span_processors == [filter1, filter2]

        # Config should be restored after context exit
        assert get_config().span_processors == [filter2]

    assert get_config().span_processors == [filter1]


def test_context_manager_with_exception():
    """Test context manager restores config even when exception occurs."""

    def filter1(span):
        pass

    def filter2(span):
        pass

    mlflow.tracing.configure(span_processors=[filter1])

    with pytest.raises(ValueError, match="test error"):  # noqa: PT012
        with mlflow.tracing.configure(span_processors=[filter2]):
            assert get_config().span_processors == [filter2]
            raise ValueError("test error")

    # Config should be restored despite exception
    assert get_config().span_processors == [filter1]


def test_context_manager_with_non_copyable_callable():
    """Test context manager handles non-copyable callables gracefully."""

    # Lambda functions are not deepcopyable
    lambda_filter = lambda span: None  # noqa: E731

    # Configure with a lambda function
    mlflow.tracing.configure(span_processors=[lambda_filter])
    assert get_config().span_processors == [lambda_filter]

    def regular_filter(span):
        pass

    # Context manager should still work with non-copyable callables
    with mlflow.tracing.configure(span_processors=[regular_filter]):
        assert get_config().span_processors == [regular_filter]

    # Config should be restored
    assert get_config().span_processors == [lambda_filter]
     1	from dataclasses import dataclass, field, replace
     2	from typing import TYPE_CHECKING, Any, Callable
     3	
     4	from mlflow.tracing.utils.processor import validate_span_processors
     5	from mlflow.utils.annotations import experimental
     6	
     7	if TYPE_CHECKING:
     8	    from mlflow.entities.span import LiveSpan
     9	
    10	
    11	@dataclass
    12	class TracingConfig:
    13	    """Configuration for MLflow tracing behavior."""
    14	
    15	    # TODO: Move more configuration options here, such as async logging, display, etc.
    16	    # A list of functions to process spans before export.
    17	    span_processors: list[Callable[["LiveSpan"], None]] = field(default_factory=list)
    18	
    19	    def __post_init__(self):
    20	        self.span_processors = validate_span_processors(self.span_processors)
    21	
    22	
    23	# Global configuration instance for tracing
    24	_MLFLOW_TRACING_CONFIG = TracingConfig()
    25	
    26	
    27	class TracingConfigContext:
    28	    """Context manager for temporary tracing configuration changes."""
    29	
    30	    def __init__(self, config_updates: dict[str, Any]):
    31	        self.config_updates = config_updates
    32	        # Create a shallow copy of the current config
    33	        self.previous_config = replace(_MLFLOW_TRACING_CONFIG)
    34	
    35	        for key, value in self.config_updates.items():
    36	            setattr(_MLFLOW_TRACING_CONFIG, key, value)
    37	
    38	    def __enter__(self):
    39	        return self
    40	
    41	    def __exit__(self, exc_type, exc_val, exc_tb):
    42	        global _MLFLOW_TRACING_CONFIG
    43	        _MLFLOW_TRACING_CONFIG = self.previous_config
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	def reset_config():
    57	    """
    58	    Reset the tracing configuration to defaults.
    59	    """
    60	    global _MLFLOW_TRACING_CONFIG
    61	    _MLFLOW_TRACING_CONFIG = TracingConfig()
    62	
    63	
    64	@experimental(version="3.2.0")
    65	def configure(
    66	    span_processors: list[Callable[["LiveSpan"], None]] | None = None,
    67	) -> TracingConfigContext:
    68	    """
    69	    Configure MLflow tracing. Can be used as function or context manager.
    70	
    71	    Only updates explicitly provided arguments, leaving others unchanged.
    72	
    73	    Args:
    74	        span_processors: List of functions to process spans before export.
    75	            This is helpful for filtering/masking particular attributes from the span to
    76	            prevent sensitive data from being logged or for reducing the size of the span.
    77	            Each function must accept a single argument of type LiveSpan and should not
    78	            return any value. When multiple functions are provided, they are applied
    79	            sequentially in the order they are provided.
    80	
    81	    Returns:
    82	        TracingConfigContext: Context manager for temporary configuration changes.
    83	            When used as a function, the configuration changes persist.
    84	            When used as a context manager, changes are reverted on exit.
    85	
    86	    Examples:
    87	
    88	        .. code-block:: python
    89	
    90	            def pii_filter(span):
    91	                \"\"\"Example PII filter that masks sensitive data in span attributes.\"\"\"
    92	                # Mask sensitive inputs
    93	                if inputs := span.inputs:
    94	                    for key, value in inputs.items():
    95	                        if "password" in key.lower() or "token" in key.lower():
    96	                            span.set_inputs({**inputs, key: "[REDACTED]"})
    97	
    98	                # Mask sensitive outputs
    99	                if outputs := span.outputs:
   100	                    if isinstance(outputs, dict):
   101	                        for key in outputs:
   102	                            if "secret" in key.lower():
   103	                                outputs[key] = "[REDACTED]"
   104	                        span.set_outputs(outputs)
   105	
   106	                # Mask sensitive attributes
   107	                for attr_key in list(span.attributes.keys()):
   108	                    if "api_key" in attr_key.lower():
   109	                        span.set_attribute(attr_key, "[REDACTED]")
   110	
   111	            # Permanent configuration change
   112	            mlflow.tracing.configure(span_processors=[pii_filter])
   113	
   114	            # Temporary configuration change
   115	            with mlflow.tracing.configure(span_processors=[pii_filter]):
   116	                # PII filtering enabled only in this block
   117	                pass
   118	    """
   119	    # Collect only the arguments that were explicitly provided
   120	    config_updates = {}
   121	    if span_processors is not None:
   122	        config_updates["span_processors"] = span_processors
   123	
   124	    # Return TracingConfigContext which handles both function and context manager usage
   125	    return TracingConfigContext(config_updates)
```

## 原始行 142 · file_change

```
{
  "id": "item_93",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracing/config.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 146 · agent_message

```
The broad tracing run is progressing through the core exporters, processors, OpenTelemetry integration, and fluent lifecycle tests successfully. The only failures seen so far are in unrelated masked display/metrics helpers; I’ll inspect the final report to separate those from any tracing-span regressions.
```

## 原始行 150 · command_execution

命令：
```
/bin/bash -lc 'ruff check mlflow/entities/span.py mlflow/entities/span_status.py mlflow/entities/trace_data.py mlflow/tracing/trace_manager.py mlflow/tracing/utils/otlp.py mlflow/tracing/utils/truncation.py mlflow/tracing/utils/processor.py mlflow/tracing/processor/base_mlflow.py mlflow/tracing/config.py'
```

退出码：`2`

输出：
```
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 151 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/tracing --ignore=tests/tracing/test_otel_loading.py --ignore=tests/tracing/test_otel_logging.py'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 476 items / 1 skipped

tests/tracing/display/test_ipython.py [31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[31mF[0m[32m.[0m[32m.[0m[31mF[0m[31m                          [  1%][0m
tests/tracing/export/test_async_export_queue.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                     [  2%][0m
tests/tracing/export/test_inference_table_exporter.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m          [  4%][0m
tests/tracing/export/test_mlflow_v3_exporter.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m             [  7%][0m
tests/tracing/export/test_uc_table_exporter.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                      [  7%][0m
tests/tracing/opentelemetry/test_integration.py [32m.[0m[32m.[0m[32m.[0m[31m                      [  8%][0m
tests/tracing/otel/test_span_translation.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m [ 14%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m             [ 27%][0m
tests/tracing/processor/test_inference_table_processor.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m         [ 28%][0m
tests/tracing/processor/test_mlflow_v3_processor.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                [ 29%][0m
tests/tracing/processor/test_otel_metrics.py [31mF[0m[32m.[0m[31m                          [ 29%][0m
tests/tracing/processor/test_uc_table_processor.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                [ 31%][0m
tests/tracing/test_archival.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                    [ 32%][0m
tests/tracing/test_assessment.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m [ 40%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                                        [ 44%][0m
tests/tracing/test_databricks.py [32m.[0m[32m.[0m[32m.[0m[31m                                     [ 44%][0m
tests/tracing/test_enablement.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                                [ 46%][0m
tests/tracing/test_fluent.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m [ 55%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m    [ 69%][0m
tests/tracing/test_provider.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[31m                 [ 75%][0m
tests/tracing/test_trace_manager.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                           [ 77%][0m
tests/tracing/test_tracing_client.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                           [ 79%][0m
tests/tracing/utils/test_config.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                               [ 80%][0m
tests/tracing/utils/test_environment.py [32m.[0m[32m.[0m[31m                               [ 81%][0m
tests/tracing/utils/test_exception.py [32m.[0m[31m                                  [ 81%][0m
tests/tracing/utils/test_processor.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m                          [ 83%][0m
tests/tracing/utils/test_prompt.py [32m.[0m[32m.[0m[31m                                    [ 83%][0m
tests/tracing/utils/test_search.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m               [ 88%][0m
tests/tracing/utils/test_timeout.py [32m.[0m[33ms[0m[32m.[0m[33ms[0m[31m                                 [ 89%][0m
tests/tracing/utils/test_truncation.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m         [ 94%][0m
tests/tracing/utils/test_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31m               [ 99%][0m
tests/tracing/utils/test_warning.py [32m.[0m[32m.[0m[31m                                   [100%][0m

=================================== FAILURES ===================================
[31m[1m__________________ test_display_is_not_called_without_ipython __________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef4f0d0>

    [0m[37m@in_databricks[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_is_not_called_without_ipython[39;49;00m(monkeypatch):[90m[39;49;00m
        [90m# in an IPython environment, the interactive shell will[39;49;00m[90m[39;49;00m
        [90m# be returned. however, for test purposes, just mock that[39;49;00m[90m[39;49;00m
        [90m# the value is not None.[39;49;00m[90m[39;49;00m
        mock_display = Mock()[90m[39;49;00m
>       monkeypatch.setattr([33m"[39;49;00m[33mIPython.display.display[39;49;00m[33m"[39;49;00m, mock_display)[90m[39;49;00m

mock_display = <Mock id='124189767157008'>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef4f0d0>

[1m[31mtests/tracing/display/test_ipython.py[0m:59: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:104: in derive_importpath
    [0mtarget = resolve(module)[90m[39;49;00m
             ^^^^^^^^^^^^^^^[90m[39;49;00m
        attr       = 'display'
        import_path = 'IPython.display.display'
        module     = 'IPython.display'
        raising    = True
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'IPython.display'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m(name: [96mstr[39;49;00m) -> [96mobject[39;49;00m:[90m[39;49;00m
        [90m# Simplified from zope.dottedname.[39;49;00m[90m[39;49;00m
        parts = name.split([33m"[39;49;00m[33m.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        used = parts.pop([94m0[39;49;00m)[90m[39;49;00m
>       found: [96mobject[39;49;00m = [96m__import__[39;49;00m(used)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'IPython'[0m

name       = 'IPython.display'
parts      = ['display']
used       = 'IPython'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:67: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:42:43 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________ test_ipython_client_clears_display_after_execution ______________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef4e450>

    [0m[37m@in_databricks[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_ipython_client_clears_display_after_execution[39;49;00m(monkeypatch):[90m[39;49;00m
        mock_ipython = MockIPython()[90m[39;49;00m
>       monkeypatch.setattr([33m"[39;49;00m[33mIPython.get_ipython[39;49;00m[33m"[39;49;00m, [94mlambda[39;49;00m: mock_ipython)[90m[39;49;00m

mock_ipython = <tests.tracing.display.test_ipython.MockIPython object at 0x70f32ef4efd0>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef4e450>

[1m[31mtests/tracing/display/test_ipython.py[0m:83: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:104: in derive_importpath
    [0mtarget = resolve(module)[90m[39;49;00m
             ^^^^^^^^^^^^^^^[90m[39;49;00m
        attr       = 'get_ipython'
        import_path = 'IPython.get_ipython'
        module     = 'IPython'
        raising    = True
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'IPython'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m(name: [96mstr[39;49;00m) -> [96mobject[39;49;00m:[90m[39;49;00m
        [90m# Simplified from zope.dottedname.[39;49;00m[90m[39;49;00m
        parts = name.split([33m"[39;49;00m[33m.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        used = parts.pop([94m0[39;49;00m)[90m[39;49;00m
>       found: [96mobject[39;49;00m = [96m__import__[39;49;00m(used)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'IPython'[0m

name       = 'IPython'
parts      = []
used       = 'IPython'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:67: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:42:43 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_________________ test_display_is_called_in_correct_functions __________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef4e390>

    [0m[37m@in_databricks[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_is_called_in_correct_functions[39;49;00m(monkeypatch):[90m[39;49;00m
        mock_ipython = MockIPython()[90m[39;49;00m
>       monkeypatch.setattr([33m"[39;49;00m[33mIPython.get_ipython[39;49;00m[33m"[39;49;00m, [94mlambda[39;49;00m: mock_ipython)[90m[39;49;00m

mock_ipython = <tests.tracing.display.test_ipython.MockIPython object at 0x70f32ef22090>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef4e390>

[1m[31mtests/tracing/display/test_ipython.py[0m:107: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:104: in derive_importpath
    [0mtarget = resolve(module)[90m[39;49;00m
             ^^^^^^^^^^^^^^^[90m[39;49;00m
        attr       = 'get_ipython'
        import_path = 'IPython.get_ipython'
        module     = 'IPython'
        raising    = True
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'IPython'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m(name: [96mstr[39;49;00m) -> [96mobject[39;49;00m:[90m[39;49;00m
        [90m# Simplified from zope.dottedname.[39;49;00m[90m[39;49;00m
        parts = name.split([33m"[39;49;00m[33m.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        used = parts.pop([94m0[39;49;00m)[90m[39;49;00m
>       found: [96mobject[39;49;00m = [96m__import__[39;49;00m(used)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'IPython'[0m

name       = 'IPython'
parts      = []
used       = 'IPython'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:67: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:42:43 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________ test_display_deduplicates_traces _______________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32eb79850>

    [0m[37m@in_databricks[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_deduplicates_traces[39;49;00m(monkeypatch):[90m[39;49;00m
        mock_ipython = MockIPython()[90m[39;49;00m
>       monkeypatch.setattr([33m"[39;49;00m[33mIPython.get_ipython[39;49;00m[33m"[39;49;00m, [94mlambda[39;49;00m: mock_ipython)[90m[39;49;00m

mock_ipython = <tests.tracing.display.test_ipython.MockIPython object at 0x70f32eb7b750>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32eb79850>

[1m[31mtests/tracing/display/test_ipython.py[0m:125: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:104: in derive_importpath
    [0mtarget = resolve(module)[90m[39;49;00m
             ^^^^^^^^^^^^^^^[90m[39;49;00m
        attr       = 'get_ipython'
        import_path = 'IPython.get_ipython'
        module     = 'IPython'
        raising    = True
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'IPython'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m(name: [96mstr[39;49;00m) -> [96mobject[39;49;00m:[90m[39;49;00m
        [90m# Simplified from zope.dottedname.[39;49;00m[90m[39;49;00m
        parts = name.split([33m"[39;49;00m[33m.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        used = parts.pop([94m0[39;49;00m)[90m[39;49;00m
>       found: [96mobject[39;49;00m = [96m__import__[39;49;00m(used)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'IPython'[0m

name       = 'IPython'
parts      = []
used       = 'IPython'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:67: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:42:43 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________ test_display_respects_max_limit ________________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef1bcd0>

    [0m[37m@in_databricks[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_display_respects_max_limit[39;49;00m(monkeypatch):[90m[39;49;00m
        mock_ipython = MockIPython()[90m[39;49;00m
>       monkeypatch.setattr([33m"[39;49;00m[33mIPython.get_ipython[39;49;00m[33m"[39;49;00m, [94mlambda[39;49;00m: mock_ipython)[90m[39;49;00m

mock_ipython = <tests.tracing.display.test_ipython.MockIPython object at 0x70f32e7497d0>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32ef1bcd0>

[1m[31mtests/tracing/display/test_ipython.py[0m:156: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:104: in derive_importpath
    [0mtarget = resolve(module)[90m[39;49;00m
             ^^^^^^^^^^^^^^^[90m[39;49;00m
        attr       = 'get_ipython'
        import_path = 'IPython.get_ipython'
        module     = 'IPython'
        raising    = True
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'IPython'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m(name: [96mstr[39;49;00m) -> [96mobject[39;49;00m:[90m[39;49;00m
        [90m# Simplified from zope.dottedname.[39;49;00m[90m[39;49;00m
        parts = name.split([33m"[39;49;00m[33m.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        used = parts.pop([94m0[39;49;00m)[90m[39;49;00m
>       found: [96mobject[39;49;00m = [96m__import__[39;49;00m(used)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'IPython'[0m

name       = 'IPython'
parts      = []
used       = 'IPython'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:67: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:42:43 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________ test_enable_and_disable_display ________________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32e6dce50>

    [0m[37m@in_databricks[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_enable_and_disable_display[39;49;00m(monkeypatch):[90m[39;49;00m
        mock_ipython = MockIPython()[90m[39;49;00m
>       monkeypatch.setattr([33m"[39;49;00m[33mIPython.get_ipython[39;49;00m[33m"[39;49;00m, [94mlambda[39;49;00m: mock_ipython)[90m[39;49;00m

mock_ipython = <tests.tracing.display.test_ipython.MockIPython object at 0x70f32e6dcdd0>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32e6dce50>

[1m[31mtests/tracing/display/test_ipython.py[0m:180: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:104: in derive_importpath
    [0mtarget = resolve(module)[90m[39;49;00m
             ^^^^^^^^^^^^^^^[90m[39;49;00m
        attr       = 'get_ipython'
        import_path = 'IPython.get_ipython'
        module     = 'IPython'
        raising    = True
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'IPython'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m(name: [96mstr[39;49;00m) -> [96mobject[39;49;00m:[90m[39;49;00m
        [90m# Simplified from zope.dottedname.[39;49;00m[90m[39;49;00m
        parts = name.split([33m"[39;49;00m[33m.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        used = parts.pop([94m0[39;49;00m)[90m[39;49;00m
>       found: [96mobject[39;49;00m = [96m__import__[39;49;00m(used)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'IPython'[0m

name       = 'IPython'
parts      = []
used       = 'IPython'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:67: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:42:43 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________________ test_display_in_oss ______________________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32eb20090>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_display_in_oss[39;49;00m(monkeypatch):[90m[39;49;00m
        mock_ipython = MockIPython()[90m[39;49;00m
>       monkeypatch.setattr([33m"[39;49;00m[33mIPython.get_ipython[39;49;00m[33m"[39;49;00m, [94mlambda[39;49;00m: mock_ipython)[90m[39;49;00m

mock_ipython = <tests.tracing.display.test_ipython.MockIPython object at 0x70f32eb20150>
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f32eb20090>

[1m[31mtests/tracing/display/test_ipython.py[0m:255: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:104: in derive_importpath
    [0mtarget = resolve(module)[90m[39;49;00m
             ^^^^^^^^^^^^^^^[90m[39;49;00m
        attr       = 'get_ipython'
        import_path = 'IPython.get_ipython'
        module     = 'IPython'
        raising    = True
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

name = 'IPython'

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mresolve[39;49;00m(name: [96mstr[39;49;00m) -> [96mobject[39;49;00m:[90m[39;49;00m
        [90m# Simplified from zope.dottedname.[39;49;00m[90m[39;49;00m
        parts = name.split([33m"[39;49;00m[33m.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        used = parts.pop([94m0[39;49;00m)[90m[39;49;00m
>       found: [96mobject[39;49;00m = [96m__import__[39;49;00m(used)[90m[39;49;00m
                        ^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'IPython'[0m

name       = 'IPython'
parts      = []
used       = 'IPython'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_pytest/monkeypatch.py[0m:67: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:42:43 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_____________________________ test_metrics_export ______________________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f31fa22890>
metric_reader = <opentelemetry.sdk.metrics._internal.export.InMemoryMetricReader object at 0x70f31fa22910>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_metrics_export[39;49;00m([90m[39;49;00m
        monkeypatch: pytest.MonkeyPatch, metric_reader: InMemoryMetricReader[90m[39;49;00m
    ) -> [94mNone[39;49;00m:[90m[39;49;00m
        monkeypatch.setenv([33m"[39;49;00m[33mOTEL_EXPORTER_OTLP_METRICS_ENDPOINT[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mhttp://localhost:9090[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        mlflow.set_experiment([33m"[39;49;00m[33mtest_experiment[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [37m@mlflow[39;49;00m.trace(span_type=[33m"[39;49;00m[33mCHAIN[39;49;00m[33m"[39;49;00m, name=[33m"[39;49;00m[33mparent[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mparent_function[39;49;00m() -> [96mstr[39;49;00m:[90m[39;49;00m
            mlflow.update_current_trace({[33m"[39;49;00m[33menv[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mversion[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33m1.0[39;49;00m[33m"[39;49;00m})[90m[39;49;00m
            time.sleep([94m0.01[39;49;00m)  [90m# 10ms[39;49;00m[90m[39;49;00m
            [94mreturn[39;49;00m child_function()[90m[39;49;00m
    [90m[39;49;00m
        [37m@mlflow[39;49;00m.trace(span_type=[33m"[39;49;00m[33mLLM[39;49;00m[33m"[39;49;00m, name=[33m"[39;49;00m[33mchild[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mchild_function[39;49;00m() -> [96mstr[39;49;00m:[90m[39;49;00m
            time.sleep([94m0.25[39;49;00m)  [90m# 250ms[39;49;00m[90m[39;49;00m
            [94mreturn[39;49;00m [33m"[39;49;00m[33mresult[39;49;00m[33m"[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [37m@mlflow[39;49;00m.trace(span_type=[33m"[39;49;00m[33mTOOL[39;49;00m[33m"[39;49;00m, name=[33m"[39;49;00m[33merror_function[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92merror_function[39;49;00m() -> [94mNone[39;49;00m:[90m[39;49;00m
            time.sleep([94m1.0[39;49;00m)  [90m# 1000ms[39;49;00m[90m[39;49;00m
            [94mraise[39;49;00m [96mValueError[39;49;00m([33m"[39;49;00m[33mTest error[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Execute successful trace[39;49;00m[90m[39;49;00m
        parent_function()[90m[39;49;00m
        [90m# Execute error trace[39;49;00m[90m[39;49;00m
        [94mwith[39;49;00m pytest.raises([96mValueError[39;49;00m, match=[33m"[39;49;00m[33mTest error[39;49;00m[33m"[39;49;00m):[90m[39;49;00m
            error_function()[90m[39;49;00m
    [90m[39;49;00m
        metrics_data = metric_reader.get_metrics_data()[90m[39;49;00m
>       [94massert[39;49;00m metrics_data [95mis[39;49;00m [95mnot[39;49;00m [94mNone[39;49;00m[90m[39;49;00m
[1m[31mE       assert None is not None[0m

child_function = <function test_metrics_export.<locals>.child_function at 0x70f31f8eccc0>
error_function = <function test_metrics_export.<locals>.error_function at 0x70f31f8ec2c0>
metric_reader = <opentelemetry.sdk.metrics._internal.export.InMemoryMetricReader object at 0x70f31fa22910>
metrics_data = None
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f31fa22890>
parent_function = <function test_metrics_export.<locals>.parent_function at 0x70f31fa03a60>

[1m[31mtests/tracing/processor/test_otel_metrics.py[0m:50: AssertionError
----------------------------- Captured stderr call -----------------------------
2026/10/11 19:43:13 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 19:43:13 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 19:43:13 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 19:43:13 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 19:43:13 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 19:43:14 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 19:43:14 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 19:43:14 INFO mlflow.tracking.fluent: Experiment with name 'test_experiment' does not exist. Creating a new experiment.
2026/10/11 19:43:15 WARNING mlflow.entities.span: Failed to end span 382ded75eb1e36fe: No module named 'opentelemetry.exporter'. For full traceback, set logging level to debug.
2026/10/11 19:43:15 WARNING mlflow.entities.span: Failed to end span 3eff3c716755ab6b: No module named 'opentelemetry.exporter'. For full traceback, set logging level to debug.
2026/10/11 19:43:16 WARNING mlflow.entities.span: Failed to end span 474ef43fe782deda: No module named 'opentelemetry.exporter'. For full traceback, set logging level to debug.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:43:16 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m______________ test_metrics_export_with_otlp_trace_export[False] _______________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_otlp_exporter[39;49;00m() -> SpanExporter:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Get the OTLP exporter based on the configured protocol.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        endpoint = _get_otlp_endpoint()[90m[39;49;00m
        protocol = _get_otlp_protocol()[90m[39;49;00m
        [94mif[39;49;00m protocol == [33m"[39;49;00m[33mgrpc[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
>               [94mfrom[39;49;00m[90m [39;49;00m[04m[96mopentelemetry[39;49;00m[04m[96m.[39;49;00m[04m[96mexporter[39;49;00m[04m[96m.[39;49;00m[04m[96motlp[39;49;00m[04m[96m.[39;49;00m[04m[96mproto[39;49;00m[04m[96m.[39;49;00m[04m[96mgrpc[39;49;00m[04m[96m.[39;49;00m[04m[96mtrace_exporter[39;49;00m[90m [39;49;00m[94mimport[39;49;00m OTLPSpanExporter[90m[39;49;00m
[1m[31mE               ModuleNotFoundError: No module named 'opentelemetry.exporter'[0m

endpoint   = 'http://localhost:4317'
protocol   = 'grpc'

[1m[31mmlflow/tracing/utils/otlp.py[0m:55: ModuleNotFoundError

[33mDuring handling of the above exception, another exception occurred:[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f2c0741a10>
dual_export = False

    [0m[37m@skip_when_testing_trace_sdk[39;49;00m[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mdual_export[39;49;00m[33m"[39;49;00m, [[94mFalse[39;49;00m, [94mTrue[39;49;00m])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_metrics_export_with_otlp_trace_export[39;49;00m(monkeypatch, dual_export):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Test metrics export configuration when OTLP is enabled."""[39;49;00m[90m[39;49;00m
        monkeypatch.setenv([33m"[39;49;00m[33mOTEL_EXPORTER_OTLP_TRACES_ENDPOINT[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mhttp://localhost:4317[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv([33m"[39;49;00m[33mOTEL_EXPORTER_OTLP_METRICS_ENDPOINT[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mhttp://localhost:9090[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m dual_export:[90m[39;49;00m
            monkeypatch.setenv(MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT.name, [33m"[39;49;00m[33mtrue[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        mlflow.tracing.reset()[90m[39;49;00m
>       tracer = _get_tracer([33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

dual_export = False
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f2c0741a10>

[1m[31mtests/tracing/test_provider.py[0m:463: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/tracing/provider.py[0m:335: in _get_tracer
    [0m[94mreturn[39;49;00m provider.get_or_init_tracer(module_name)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        module_name = 'test'
[1m[31mmlflow/tracing/provider.py[0m:100: in get_or_init_tracer
    [0m[96mself[39;49;00m.once.do_once(_initialize_tracer_provider)[90m[39;49;00m
        module_name = 'test'
        self       = <mlflow.tracing.provider._TracerProviderWrapper object at 0x70f38fbc5910>
[1m[31mmlflow/tracing/utils/once.py[0m:23: in do_once
    [0mfunc()[90m[39;49;00m
        func       = <function _initialize_tracer_provider at 0x70f38fbcc7c0>
        self       = <mlflow.tracing.utils.once.Once object at 0x70f38fbc5950>
[1m[31mmlflow/tracing/provider.py[0m:357: in _initialize_tracer_provider
    [0mprocessors = _get_span_processors(disabled=disabled)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        disabled   = False
[1m[31mmlflow/tracing/provider.py[0m:436: in _get_span_processors
    [0mexporter = get_otlp_exporter()[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        OtelSpanProcessor = <class 'mlflow.tracing.processor.otel.OtelSpanProcessor'>
        disabled   = False
        processors = []
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_otlp_exporter[39;49;00m() -> SpanExporter:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Get the OTLP exporter based on the configured protocol.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        endpoint = _get_otlp_endpoint()[90m[39;49;00m
        protocol = _get_otlp_protocol()[90m[39;49;00m
        [94mif[39;49;00m protocol == [33m"[39;49;00m[33mgrpc[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mfrom[39;49;00m[90m [39;49;00m[04m[96mopentelemetry[39;49;00m[04m[96m.[39;49;00m[04m[96mexporter[39;49;00m[04m[96m.[39;49;00m[04m[96motlp[39;49;00m[04m[96m.[39;49;00m[04m[96mproto[39;49;00m[04m[96m.[39;49;00m[04m[96mgrpc[39;49;00m[04m[96m.[39;49;00m[04m[96mtrace_exporter[39;49;00m[90m [39;49;00m[94mimport[39;49;00m OTLPSpanExporter[90m[39;49;00m
            [94mexcept[39;49;00m [96mImportError[39;49;00m:[90m[39;49;00m
>               [94mraise[39;49;00m MlflowException([90m[39;49;00m
                    [33m"[39;49;00m[33mgRPC OTLP exporter is not available. Please install the required dependency by [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33m"[39;49;00m[33mrunning `pip install opentelemetry-exporter-otlp-proto-grpc`.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    error_code=RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
                )[90m[39;49;00m
[1m[31mE               mlflow.exceptions.MlflowException: gRPC OTLP exporter is not available. Please install the required dependency by running `pip install opentelemetry-exporter-otlp-proto-grpc`.[0m

endpoint   = 'http://localhost:4317'
protocol   = 'grpc'

[1m[31mmlflow/tracing/utils/otlp.py[0m:57: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:47:22 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________ test_metrics_export_with_otlp_trace_export[True] _______________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_otlp_exporter[39;49;00m() -> SpanExporter:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Get the OTLP exporter based on the configured protocol.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        endpoint = _get_otlp_endpoint()[90m[39;49;00m
        protocol = _get_otlp_protocol()[90m[39;49;00m
        [94mif[39;49;00m protocol == [33m"[39;49;00m[33mgrpc[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
>               [94mfrom[39;49;00m[90m [39;49;00m[04m[96mopentelemetry[39;49;00m[04m[96m.[39;49;00m[04m[96mexporter[39;49;00m[04m[96m.[39;49;00m[04m[96motlp[39;49;00m[04m[96m.[39;49;00m[04m[96mproto[39;49;00m[04m[96m.[39;49;00m[04m[96mgrpc[39;49;00m[04m[96m.[39;49;00m[04m[96mtrace_exporter[39;49;00m[90m [39;49;00m[94mimport[39;49;00m OTLPSpanExporter[90m[39;49;00m
[1m[31mE               ModuleNotFoundError: No module named 'opentelemetry.exporter'[0m

endpoint   = 'http://localhost:4317'
protocol   = 'grpc'

[1m[31mmlflow/tracing/utils/otlp.py[0m:55: ModuleNotFoundError

[33mDuring handling of the above exception, another exception occurred:[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f2b9350510>
dual_export = True

    [0m[37m@skip_when_testing_trace_sdk[39;49;00m[90m[39;49;00m
    [37m@pytest[39;49;00m.mark.parametrize([33m"[39;49;00m[33mdual_export[39;49;00m[33m"[39;49;00m, [[94mFalse[39;49;00m, [94mTrue[39;49;00m])[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_metrics_export_with_otlp_trace_export[39;49;00m(monkeypatch, dual_export):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Test metrics export configuration when OTLP is enabled."""[39;49;00m[90m[39;49;00m
        monkeypatch.setenv([33m"[39;49;00m[33mOTEL_EXPORTER_OTLP_TRACES_ENDPOINT[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mhttp://localhost:4317[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv([33m"[39;49;00m[33mOTEL_EXPORTER_OTLP_METRICS_ENDPOINT[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mhttp://localhost:9090[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m dual_export:[90m[39;49;00m
            monkeypatch.setenv(MLFLOW_TRACE_ENABLE_OTLP_DUAL_EXPORT.name, [33m"[39;49;00m[33mtrue[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        mlflow.tracing.reset()[90m[39;49;00m
>       tracer = _get_tracer([33m"[39;49;00m[33mtest[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

dual_export = True
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x70f2b9350510>

[1m[31mtests/tracing/test_provider.py[0m:463: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/tracing/provider.py[0m:335: in _get_tracer
    [0m[94mreturn[39;49;00m provider.get_or_init_tracer(module_name)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        module_name = 'test'
[1m[31mmlflow/tracing/provider.py[0m:100: in get_or_init_tracer
    [0m[96mself[39;49;00m.once.do_once(_initialize_tracer_provider)[90m[39;49;00m
        module_name = 'test'
        self       = <mlflow.tracing.provider._TracerProviderWrapper object at 0x70f38fbc5910>
[1m[31mmlflow/tracing/utils/once.py[0m:23: in do_once
    [0mfunc()[90m[39;49;00m
        func       = <function _initialize_tracer_provider at 0x70f38fbcc7c0>
        self       = <mlflow.tracing.utils.once.Once object at 0x70f38fbc5950>
[1m[31mmlflow/tracing/provider.py[0m:357: in _initialize_tracer_provider
    [0mprocessors = _get_span_processors(disabled=disabled)[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        disabled   = False
[1m[31mmlflow/tracing/provider.py[0m:436: in _get_span_processors
    [0mexporter = get_otlp_exporter()[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        OtelSpanProcessor = <class 'mlflow.tracing.processor.otel.OtelSpanProcessor'>
        disabled   = False
        processors = []
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_otlp_exporter[39;49;00m() -> SpanExporter:[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Get the OTLP exporter based on the configured protocol.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        endpoint = _get_otlp_endpoint()[90m[39;49;00m
        protocol = _get_otlp_protocol()[90m[39;49;00m
        [94mif[39;49;00m protocol == [33m"[39;49;00m[33mgrpc[39;49;00m[33m"[39;49;00m:[90m[39;49;00m
            [94mtry[39;49;00m:[90m[39;49;00m
                [94mfrom[39;49;00m[90m [39;49;00m[04m[96mopentelemetry[39;49;00m[04m[96m.[39;49;00m[04m[96mexporter[39;49;00m[04m[96m.[39;49;00m[04m[96motlp[39;49;00m[04m[96m.[39;49;00m[04m[96mproto[39;49;00m[04m[96m.[39;49;00m[04m[96mgrpc[39;49;00m[04m[96m.[39;49;00m[04m[96mtrace_exporter[39;49;00m[90m [39;49;00m[94mimport[39;49;00m OTLPSpanExporter[90m[39;49;00m
            [94mexcept[39;49;00m [96mImportError[39;49;00m:[90m[39;49;00m
>               [94mraise[39;49;00m MlflowException([90m[39;49;00m
                    [33m"[39;49;00m[33mgRPC OTLP exporter is not available. Please install the required dependency by [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    [33m"[39;49;00m[33mrunning `pip install opentelemetry-exporter-otlp-proto-grpc`.[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    error_code=RESOURCE_DOES_NOT_EXIST,[90m[39;49;00m
                )[90m[39;49;00m
[1m[31mE               mlflow.exceptions.MlflowException: gRPC OTLP exporter is not available. Please install the required dependency by running `pip install opentelemetry-exporter-otlp-proto-grpc`.[0m

endpoint   = 'http://localhost:4317'
protocol   = 'grpc'

[1m[31mmlflow/tracing/utils/otlp.py[0m:57: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 19:47:22 INFO mlflow.tracking.fluent: Active model is cleared
[33m=============================== warnings summary ===============================[0m
tests/tracing/test_assessment.py::test_search_traces_with_assessments[file]
tests/tracing/test_assessment.py::test_search_traces_with_assessments[sqlalchemy]
  /testbed/tests/tracing/test_assessment.py:591: FutureWarning: Parameter 'experiment_ids' is deprecated. Please use 'locations' instead.
    traces = mlflow.search_traces(

tests/tracing/test_fluent.py::test_trace_with_experiment_id
  /testbed/tests/tracing/test_fluent.py:625: FutureWarning: ``mlflow.tracing.destination.MlflowExperiment`` is deprecated since 3.5.0. This method will be removed in a future release. Use ``mlflow.entities.trace_location.MlflowExperimentLocation`` instead.
    @mlflow.trace(trace_destination=MlflowExperiment(exp_1))

tests/tracing/test_fluent.py::test_trace_with_experiment_id_issue_warning_when_not_root_span
  /testbed/tests/tracing/test_fluent.py:652: FutureWarning: ``mlflow.tracing.destination.MlflowExperiment`` is deprecated since 3.5.0. This method will be removed in a future release. Use ``mlflow.entities.trace_location.MlflowExperimentLocation`` instead.
    @mlflow.trace(trace_destination=MlflowExperiment(exp_1))

tests/tracing/test_fluent.py::test_trace_with_experiment_id_issue_warning_when_not_root_span
  /testbed/tests/tracing/test_fluent.py:656: FutureWarning: ``mlflow.tracing.destination.MlflowExperiment`` is deprecated since 3.5.0. This method will be removed in a future release. Use ``mlflow.entities.trace_location.MlflowExperimentLocation`` instead.
    @mlflow.trace(trace_destination=MlflowExperiment(exp_1))

tests/tracing/test_fluent.py: 12 warnings
  /testbed/mlflow/utils/annotations.py:260: FutureWarning: The `extract_fields` parameter is deprecated and will be removed in a future version.
    return func(*args, **kwargs)

tests/tracing/test_fluent.py::test_search_traces[pandas]
tests/tracing/test_fluent.py::test_search_traces[list]
  /testbed/tests/tracing/test_fluent.py:913: FutureWarning: Parameter 'experiment_ids' is deprecated. Please use 'locations' instead.
    traces = mlflow.search_traces(

tests/tracing/test_fluent.py::test_search_traces_with_pagination
  /testbed/tests/tracing/test_fluent.py:974: FutureWarning: Parameter 'experiment_ids' is deprecated. Please use 'locations' instead.
    traces = mlflow.search_traces(experiment_ids=["1"])

tests/tracing/test_fluent.py::test_search_traces_with_run_id
  /testbed/tests/tracing/test_fluent.py:1256: FutureWarning: Parameter 'experiment_ids' is deprecated. Please use 'locations' instead.
    mlflow.search_traces(run_id=run1.info.run_id, experiment_ids=["1"])

tests/tracing/test_fluent.py::test_update_current_trace_should_not_raise_during_model_logging
  /testbed/mlflow/pyfunc/utils/data_validation.py:155: FutureWarning: Model's `predict` method contains invalid parameters: {'model_inputs'}. Only the following parameter names are allowed: context, model_input, and params. Note that invalid parameters will no longer be permitted in future versions.
    param_names = _check_func_signature(func, "predict")

tests/tracing/test_fluent.py::test_update_current_trace_should_not_raise_during_model_logging
tests/tracing/test_fluent.py::test_add_trace_logging_model_from_code
tests/tracing/test_fluent.py::test_add_trace_logging_model_from_code
tests/tracing/test_fluent.py::test_add_trace_logging_model_from_code
  /testbed/mlflow/pyfunc/utils/data_validation.py:186: UserWarning: [33mAdd type hints to the `predict` method to enable data validation and automatic signature inference during model logging. Check https://mlflow.org/docs/latest/model/python_model.html#type-hint-usage-in-pythonmodel for more details.[0m
    color_warning(

tests/tracing/test_fluent.py::test_update_current_trace_should_not_raise_during_model_logging
tests/tracing/test_provider.py::test_disable_enable_tracing
tests/tracing/test_provider.py::test_sampling_ratio
  /testbed/mlflow/store/tracking/sqlalchemy_store.py:2828: SAWarning: Coercing Subquery object into a select() for use in IN(); please pass a select() construct explicitly
    SqlTraceInfo.request_id.in_(

tests/tracing/test_fluent.py::test_update_current_trace_should_not_raise_during_model_logging
tests/tracing/test_fluent.py::test_add_trace_logging_model_from_code
  /testbed/mlflow/types/utils.py:452: UserWarning: Hint: Inferred schema contains integer column(s). Integer columns in Python cannot represent missing values. If your input data contains missing values at inference time, it will be encoded as floats and will cause a schema enforcement error. The best way to avoid this problem is to infer the model schema based on a realistic data sample (training dataset) that includes missing values. Alternatively, you can declare integer columns as doubles (float64) whenever these columns may have missing values. See `Handling Integers With Missing Values <https://www.mlflow.org/docs/latest/models.html#handling-integers-with-missing-values>`_ for more details.
    warnings.warn(

tests/tracing/test_fluent.py: 18 warnings
  /testbed/tests/tracing/test_fluent.py:2149: FutureWarning: ``mlflow.tracing.fluent.log_trace`` is deprecated since 3.6.0. This method will be removed in a future release.
    mlflow.log_trace(

tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-outputs0-inputs0]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-outputs0-Does mlflow support tracing?]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-outputs0-None]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-Yes-inputs0]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-Yes-Does mlflow support tracing?]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-Yes-None]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-None-inputs0]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-None-Does mlflow support tracing?]
tests/tracing/test_fluent.py::test_log_trace_success[intermediate_outputs0-None-None]
  /testbed/tests/tracing/test_fluent.py:2168: FutureWarning: ``mlflow.entities.trace_data.TraceData.intermediate_outputs`` is deprecated since 3.6.0. This method will be removed in a future release. Use ``trace.search_spans(name=...)`` instead.
    assert trace.data.intermediate_outputs == intermediate_outputs

tests/tracing/test_fluent.py::test_set_delete_trace_tag
  /testbed/tests/tracing/test_fluent.py:2190: FutureWarning: Parameter 'request_id' is deprecated. Please use 'trace_id' instead.
    mlflow.set_trace_tag(request_id=trace_id, key="key3", value="value3")

tests/tracing/test_fluent.py::test_set_delete_trace_tag
  /testbed/tests/tracing/test_fluent.py:2191: FutureWarning: Parameter 'request_id' is deprecated. Please use 'trace_id' instead.
    trace = mlflow.get_trace(request_id=trace_id)

tests/tracing/test_fluent.py::test_set_delete_trace_tag
  /testbed/tests/tracing/test_fluent.py:2194: FutureWarning: Parameter 'request_id' is deprecated and will be removed in version 3.0.0. Please use 'trace_id' instead.
    mlflow.delete_trace_tag(request_id=trace_id, key="key3")

tests/tracing/test_fluent.py::test_set_delete_trace_tag
  /testbed/tests/tracing/test_fluent.py:2195: FutureWarning: Parameter 'request_id' is deprecated. Please use 'trace_id' instead.
    trace = mlflow.get_trace(request_id=trace_id)

tests/tracing/test_fluent.py::test_search_traces_with_sql_warehouse_id
  /testbed/mlflow/tracing/fluent.py:807: FutureWarning: The `sql_warehouse_id` parameter is deprecated. Please use the `MLFLOW_TRACING_SQL_WAREHOUSE_ID` environment variable instead.
    warnings.warn(

tests/tracing/test_fluent.py::test_set_destination_in_threads[True]
tests/tracing/test_fluent.py::test_set_destination_in_threads[False]
  /testbed/tests/tracing/test_fluent.py:2294: FutureWarning: ``mlflow.tracing.destination.MlflowExperiment`` is deprecated since 3.5.0. This method will be removed in a future release. Use ``mlflow.entities.trace_location.MlflowExperimentLocation`` instead.
    set_destination(MlflowExperiment(experiment_id1))

tests/tracing/test_fluent.py::test_set_destination_in_threads[True]
tests/tracing/test_fluent.py::test_set_destination_in_threads[False]
  /testbed/tests/tracing/test_fluent.py:2287: FutureWarning: ``mlflow.tracing.destination.MlflowExperiment`` is deprecated since 3.5.0. This method will be removed in a future release. Use ``mlflow.entities.trace_location.MlflowExperimentLocation`` instead.
    set_destination(MlflowExperiment(experiment_id), context_local=True)

tests/tracing/test_fluent.py::test_set_destination_in_async_contexts[True]
tests/tracing/test_fluent.py::test_set_destination_in_async_contexts[False]
  /testbed/tests/tracing/test_fluent.py:2355: FutureWarning: ``mlflow.tracing.destination.MlflowExperiment`` is deprecated since 3.5.0. This method will be removed in a future release. Use ``mlflow.entities.trace_location.MlflowExperimentLocation`` instead.
    set_destination(MlflowExperiment(experiment_id), context_local=True)

tests/tracing/test_provider.py::test_set_destination_databricks
  /testbed/tests/tracing/test_provider.py:104: FutureWarning: ``mlflow.tracing.destination.Databricks`` is deprecated since 3.5.0. This method will be removed in a future release. Use ``mlflow.entities.trace_location.MlflowExperimentLocation`` instead.
    mlflow.tracing.set_destination(destination=Databricks(experiment_id="123"))

tests/tracing/test_tracing_client.py::test_tracing_client_link_prompt_versions_to_trace
  /testbed/tests/tracing/test_tracing_client.py:52: FutureWarning: The `mlflow.register_prompt` API is moved to the `mlflow.genai` namespace. Please use `mlflow.genai.register_prompt` instead. The original API will be removed in the future release.
    prompt_version = mlflow.register_prompt(name="test_prompt", template="Hello, {{name}}!")

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
10.75s call     tests/tracing/export/test_async_export_queue.py::test_async_queue_complete_task_process_finished
6.75s call     tests/tracing/test_fluent.py::test_set_destination_in_async_contexts[True]
6.01s call     tests/tracing/utils/test_timeout.py::test_trace_halted_after_timeout_in_model_serving
5.49s call     tests/tracing/test_fluent.py::test_set_destination_in_async_contexts[False]
4.61s call     tests/tracing/test_fluent.py::test_set_destination_in_threads[False]
4.56s call     tests/tracing/test_fluent.py::test_set_destination_in_threads[True]
3.90s call     tests/tracing/test_fluent.py::test_search_traces_yields_expected_dataframe_contents
3.73s call     tests/tracing/test_fluent.py::test_update_current_trace_should_not_raise_during_model_logging
3.69s call     tests/tracing/test_provider.py::test_sampling_ratio
3.41s call     tests/tracing/utils/test_processor.py::test_span_processors_no_processors_configured

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                                        | Duration | Tests | Min    | Max     | Avg    |
| ---- | ----------------------------------------------------------- | -------- | ----- | ------ | ------- | ------ |
| 1    | `tests/tracing/test_fluent.py`                              | 170.48s  | 112   | 0.001s | 6.753s  | 1.522s |
| 2    | `tests/tracing/test_assessment.py`                          | 32.74s   | 56    | 0.003s | 1.687s  | 0.585s |
| 3    | `tests/tracing/test_provider.py`                            | 27.06s   | 25    | 0.002s | 3.695s  | 1.082s |
| 4    | `tests/tracing/export/test_async_export_queue.py`           | 14.27s   | 4     | 0.004s | 10.754s | 3.567s |
| 5    | `tests/tracing/utils/test_timeout.py`                       | 11.01s   | 4     | 0.000s | 7.004s  | 2.752s |
| 6    | `tests/tracing/utils/test_processor.py`                     | 8.58s    | 9     | 0.002s | 3.413s  | 0.953s |
| 7    | `tests/tracing/test_tracing_client.py`                      | 7.07s    | 9     | 0.002s | 2.002s  | 0.785s |
| 8    | `tests/tracing/test_trace_manager.py`                       | 5.05s    | 10    | 0.001s | 4.012s  | 0.505s |
| 9    | `tests/tracing/export/test_uc_table_exporter.py`            | 3.97s    | 4     | 0.940s | 1.127s  | 0.992s |
| 10   | `tests/tracing/export/test_mlflow_v3_exporter.py`           | 3.89s    | 12    | 0.003s | 1.238s  | 0.324s |
| 11   | `tests/tracing/processor/test_otel_metrics.py`              | 3.27s    | 2     | 1.040s | 2.231s  | 1.636s |
| 12   | `tests/tracing/opentelemetry/test_integration.py`           | 3.22s    | 3     | 1.013s | 1.175s  | 1.074s |
| 13   | `tests/tracing/test_enablement.py`                          | 2.96s    | 8     | 0.001s | 0.993s  | 0.370s |
| 14   | `tests/tracing/processor/test_inference_table_processor.py` | 1.96s    | 6     | 0.002s | 0.983s  | 0.326s |
| 15   | `tests/tracing/utils/test_utils.py`                         | 1.05s    | 24    | 0.001s | 1.009s  | 0.044s |
| 16   | `tests/tracing/processor/test_mlflow_v3_processor.py`       | 1.02s    | 5     | 0.002s | 1.007s  | 0.203s |
| 17   | `tests/tracing/utils/test_warning.py`                       | 1.01s    | 2     | 0.002s | 1.007s  | 0.505s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/tracing/display/test_ipython.py::test_display_is_not_called_without_ipython' 'tests/tracing/display/test_ipython.py::test_ipython_client_clears_display_after_execution' 'tests/tracing/display/test_ipython.py::test_display_is_called_in_correct_functions' 'tests/tracing/display/test_ipython.py::test_display_deduplicates_traces' 'tests/tracing/display/test_ipython.py::test_display_respects_max_limit' 'tests/tracing/display/test_ipython.py::test_enable_and_disable_display' 'tests/tracing/display/test_ipython.py::test_display_in_oss' 'tests/tracing/processor/test_otel_metrics.py::test_metrics_export' 'tests/tracing/test_provider.py::test_metrics_export_with_otlp_trace_export[False]' 'tests/tracing/test_provider.py::test_metrics_export_with_otlp_trace_export[True]'

[33m============================== Remaining threads ===============================[0m
1: <Thread(MLflowTraceLoggingConsumer, started daemon 124189012899392)>
2: <Thread(MlflowTraceLoggingWorker_0, started daemon 124188425705024)>
3: <Thread(MlflowTraceLoggingWorker_1, started daemon 124189029684800)>
4: <Thread(MlflowTraceLoggingWorker_2, started daemon 124188408919616)>
5: <Thread(OtelBatchSpanRecordProcessor, started daemon 124187778737728)>
6: <Thread(OtelBatchSpanRecordProcessor, started daemon 124187751458368)>
[33m========================== Remaining child processes ===========================[0m
1: psutil.Process(pid=1545, name='python3.11', status='sleeping', started='19:43:00')
[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/display/test_ipython.py::[1mtest_display_is_not_called_without_ipython[0m - ModuleNotFoundError: No module named 'IPython'
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/display/test_ipython.py::[1mtest_ipython_client_clears_display_after_execution[0m - ModuleNotFoundError: No module named 'IPython'
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/display/test_ipython.py::[1mtest_display_is_called_in_correct_functions[0m - ModuleNotFoundError: No module named 'IPython'
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/display/test_ipython.py::[1mtest_display_deduplicates_traces[0m - ModuleNotFoundError: No module named 'IPython'
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/display/test_ipython.py::[1mtest_display_respects_max_limit[0m - ModuleNotFoundError: No module named 'IPython'
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/display/test_ipython.py::[1mtest_enable_and_disable_display[0m - ModuleNotFoundError: No module named 'IPython'
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/display/test_ipython.py::[1mtest_display_in_oss[0m - ModuleNotFoundError: No module named 'IPython'
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/processor/test_otel_metrics.py::[1mtest_metrics_export[0m - assert None is not None
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/test_provider.py::[1mtest_metrics_export_with_otlp_trace_export[False][0m - mlflow.exceptions.MlflowException: gRPC OTLP exporter is not available. Ple...
[31mFAILED | MEM 20.1/46.9 GB | DISK 793.0/915.7 GB[0m tests/tracing/test_provider.py::[1mtest_metrics_export_with_otlp_trace_export[True][0m - mlflow.exceptions.MlflowException: gRPC OTLP exporter is not available. Ple...
[31m====== [31m[1m10 failed[0m, [32m464 passed[0m, [33m3 skipped[0m, [33m71 warnings[0m[31m in 299.22s (0:04:59)[0m[31m ======[0m
2026/10/11 19:48:07 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:07 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:07 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:07 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
2026/10/11 19:48:08 INFO mlflow.tracing.export.async_export_queue: Flushing the async trace logging queue before program exit. This may take a while...
```

## 原始行 154 · command_execution

命令：
```
/bin/bash -lc "git status --short; python - <<'PY'
import ast
from pathlib import Path
paths=['mlflow/entities/span.py','mlflow/entities/span_status.py','mlflow/entities/trace_data.py','mlflow/tracing/trace_manager.py','mlflow/tracing/utils/otlp.py','mlflow/tracing/utils/truncation.py','mlflow/tracing/utils/processor.py','mlflow/tracing/processor/base_mlflow.py','mlflow/tracing/config.py']
for p in paths:
 ast.parse(Path(p).read_text())
print('AST parse passed')
PY
python - <<'PY'
from mlflow.entities.span import *
from tests.tracing.helper import create_mock_otel_span
from mlflow.exceptions import MlflowException

live=create_mlflow_span(create_mock_otel_span(1,2), 'tr-x')
print(type(live).__name__, live.span_type)
live.set_span_type('TOOL'); live.set_attribute('complex', {'a':[1]}); live.add_event(__import__('mlflow').entities.SpanEvent('x',attributes={'k':'v'})); live.end(outputs={'ok':True})
imm=live.to_immutable_span()
print(imm.span_type, imm.outputs, imm.events, imm.to_dict())
try: imm._attributes.set('x',1)
except MlflowException as e: print('immutable guarded')
PY"
```

退出码：`0`

输出：
```
 M mlflow/entities/span.py
 M mlflow/entities/span_status.py
 M mlflow/entities/trace_data.py
 M mlflow/tracing/config.py
 M mlflow/tracing/processor/base_mlflow.py
 M mlflow/tracing/trace_manager.py
 M mlflow/tracing/utils/otlp.py
 M mlflow/tracing/utils/processor.py
 M mlflow/tracing/utils/truncation.py
AST parse passed
2026/10/11 19:48:29 WARNING mlflow.entities.span: Failed to end span 0000000000000002: create_mock_otel_span.<locals>._MockOTelSpan.end() got an unexpected keyword argument 'end_time'. For full traceback, set logging level to debug.
LiveSpan None
TOOL {'ok': True} [SpanEvent(name='x', timestamp=1791748109691495, attributes={'k': 'v'})] {'name': 'test_span', 'trace_id': 'AAAAAAAAAAAAAAAAAAAAAQ==', 'span_id': 'AAAAAAAAAAI=', 'parent_span_id': None, 'start_time_unix_nano': 1791748109691441408, 'end_time_unix_nano': None, 'events': [{'name': 'x', 'time_unix_nano': 1791748109691495, 'attributes': {'k': 'v'}}], 'status': {'code': 'STATUS_CODE_OK', 'message': ''}, 'attributes': {'mlflow.traceRequestId': '"tr-x"', 'mlflow.spanType': '"TOOL"', 'complex': '{"a": [1]}', 'mlflow.spanOutputs': '{"ok": true}'}}
immutable guarded
```

## 原始行 158 · command_execution

命令：
```
/bin/bash -lc "grep -n \"OTelProtoStatus\\|OTelStatusCode\\|OTelStatus\" mlflow/entities/span.py; grep -n \"base64\\|Union\" mlflow/entities/span.py"
```

退出码：`0`

输出：
```
8:from opentelemetry.proto.trace.v1.trace_pb2 import Status as OTelProtoStatus
14:from opentelemetry.trace import Status as OTelStatus
15:from opentelemetry.trace import StatusCode as OTelStatusCode
1:import base64
5:from typing import Any, Union
407:            if _is_base64_encoded(data["trace_id"]):
1183:    return base64.b64encode(identifier.to_bytes(width, byteorder="big", signed=False)).decode()
1187:    return int.from_bytes(base64.b64decode(encoded_identifier, validate=True), byteorder="big")
1190:def _is_base64_encoded(value: Any) -> bool:
1194:        decoded = base64.b64decode(value, validate=True)
1195:        return len(decoded) in (8, 16) and base64.b64encode(decoded).decode() == value
1204:) -> Union["Span", "LiveSpan", "NoOpSpan"]:
```

## 原始行 161 · file_change

```
{
  "id": "item_107",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/span.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracing/utils/truncation.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 164 · command_execution

命令：
```
/bin/bash -lc 'black --check mlflow/entities/span.py mlflow/entities/span_status.py mlflow/entities/trace_data.py mlflow/tracing/trace_manager.py mlflow/tracing/utils/otlp.py mlflow/tracing/utils/truncation.py mlflow/tracing/utils/processor.py mlflow/tracing/processor/base_mlflow.py mlflow/tracing/config.py'
```

退出码：`1`

输出：
```
would reformat mlflow/tracing/utils/processor.py
would reformat mlflow/tracing/config.py
would reformat mlflow/entities/trace_data.py
would reformat mlflow/entities/span_status.py
would reformat mlflow/tracing/utils/truncation.py
would reformat mlflow/tracing/processor/base_mlflow.py
would reformat mlflow/tracing/utils/otlp.py
would reformat mlflow/tracing/trace_manager.py
would reformat mlflow/entities/span.py

Oh no! 💥 💔 💥
9 files would be reformatted.
```

## 原始行 167 · command_execution

命令：
```
/bin/bash -lc 'python -m pyflakes mlflow/entities/span.py mlflow/entities/span_status.py mlflow/entities/trace_data.py mlflow/tracing/trace_manager.py mlflow/tracing/utils/otlp.py mlflow/tracing/utils/truncation.py mlflow/tracing/utils/processor.py mlflow/tracing/processor/base_mlflow.py mlflow/tracing/config.py 2>&1 || true; pytest -q tests/tracing/test_trace_manager.py tests/tracing/utils/test_processor.py tests/tracing/utils/test_truncation.py tests/tracing/utils/test_config.py tests/entities/test_span_status.py tests/entities/test_span_event.py'
```

退出码：`0`

输出：
```
/opt/miniconda3/envs/testbed/bin/python: No module named pyflakes
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 71 items

tests/tracing/test_trace_manager.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                           [ 14%][0m
tests/tracing/utils/test_processor.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                          [ 26%][0m
tests/tracing/utils/test_truncation.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m         [ 61%][0m
tests/tracing/utils/test_config.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                               [ 71%][0m
tests/entities/test_span_status.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                       [ 92%][0m
tests/entities/test_span_event.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                  [100%][0m

============================= slowest 10 durations =============================
3.00s call     tests/tracing/test_trace_manager.py::test_traces_buffer_expires_and_log_when_timeout_is_set
2.01s call     tests/tracing/utils/test_processor.py::test_span_processors_no_processors_configured
1.75s call     tests/tracing/utils/test_processor.py::test_apply_span_processors_returns_non_none_warning
1.75s call     tests/tracing/utils/test_processor.py::test_span_processors_single_processor_success
1.68s call     tests/tracing/utils/test_processor.py::test_apply_span_processors_exception_handling
1.68s call     tests/tracing/utils/test_processor.py::test_apply_span_processors_multiple_processors_success
1.00s call     tests/tracing/test_trace_manager.py::test_traces_buffer_expires_after_ttl
1.00s teardown tests/tracing/test_trace_manager.py::test_traces_buffer_expires_and_log_when_timeout_is_set
0.02s call     tests/tracing/test_trace_manager.py::test_add_and_pop_span_thread_safety
0.01s call     tests/tracing/test_trace_manager.py::test_register_prompt

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                    | Duration | Tests | Min    | Max    | Avg    |
| ---- | --------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/tracing/utils/test_processor.py` | 8.89s    | 9     | 0.001s | 2.011s | 0.988s |
| 2    | `tests/tracing/test_trace_manager.py`   | 5.06s    | 10    | 0.002s | 4.005s | 0.506s |

::endgroup::

[32m============================= [32m[1m71 passed[0m[32m in 14.09s[0m[32m ==============================[0m
```

## 原始行 170 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def parse_trace_id_v4\" -A30 mlflow/tracing/utils/__init__.py; grep -R -n \"Span.from_dict\" tests --include='*.py' | head -50; grep -R -n \"parent_span_id\" tests/entities tests/tracing --include='*.py' | head -80"
```

退出码：`0`

输出：
```
631:def parse_trace_id_v4(trace_id: str | None) -> tuple[str | None, str | None]:
632-    """
633-    Parse the trace ID into location and trace ID components.
634-    """
635-    if trace_id is None:
636-        return None, None
637-    if trace_id.startswith(TRACE_ID_V4_PREFIX):
638-        match trace_id.removeprefix(TRACE_ID_V4_PREFIX).split("/"):
639-            case [location, tid] if location and tid:
640-                return location, tid
641-            case _:
642-                raise MlflowException.invalid_parameter_value(
643-                    f"Invalid trace ID format: {trace_id}. "
644-                    f"Expected format: {TRACE_ID_V4_PREFIX}<location>/<trace_id>"
645-                )
646-    return None, trace_id
647-
648-
649-def construct_trace_id_v4(location: str, trace_id: str) -> str:
650-    """
651-    Construct a trace ID for the given location and trace ID.
652-    """
653-    return f"{TRACE_ID_V4_PREFIX}{location}/{trace_id}"
tests/tracking/test_client.py:234:                    Span.from_dict(
tests/entities/test_trace_data.py:46:                "parent_span_id": None,
tests/entities/test_trace_data.py:76:                "parent_span_id": mock.ANY,
tests/entities/test_trace_data.py:99:                "parent_span_id": mock.ANY,
tests/entities/test_trace.py:115:                    "parent_span_id": None,
tests/entities/test_trace.py:135:                    "parent_span_id": mock.ANY,
tests/entities/test_trace.py:521:                    "parent_span_id": "",
```

## 原始行 173 · command_execution

命令：
```
/bin/bash -lc "sed -n '450,545p' tests/entities/test_trace.py; sed -n '210,250p' tests/tracking/test_client.py"
```

退出码：`0`

输出：
```
            spans=[],
        ),
    )

    assert trace.search_assessments() == [assessments[0], assessments[2], assessments[3]]
    assert trace.search_assessments(all=True) == assessments
    assert trace.search_assessments("relevance") == [assessments[0], assessments[2]]
    assert trace.search_assessments("relevance", all=True) == assessments[:3]
    assert trace.search_assessments(span_id="123") == [assessments[2], assessments[3]]
    assert trace.search_assessments(span_id="123", name="relevance") == [assessments[2]]
    assert trace.search_assessments(type="expectation") == [assessments[3]]


def test_trace_to_and_from_proto():
    @mlflow.trace
    def invoke(x):
        return x + 1

    @mlflow.trace
    def test(x):
        return invoke(x)

    test(1)
    trace = mlflow.get_trace(mlflow.get_last_active_trace_id())
    proto_trace = trace.to_proto()
    assert proto_trace.trace_info.trace_id == trace.info.request_id
    assert proto_trace.trace_info.trace_location == trace.info.trace_location.to_proto()
    assert len(proto_trace.spans) == 2
    assert proto_trace.spans[0].name == "test"
    assert proto_trace.spans[1].name == "invoke"

    trace_from_proto = Trace.from_proto(proto_trace)
    assert trace_from_proto.to_dict() == trace.to_dict()


def test_trace_from_dict_load_old_trace():
    trace_dict = {
        "info": {
            "trace_id": "tr-ee17184669c265ffdcf9299b36f6dccc",
            "trace_location": {
                "type": "MLFLOW_EXPERIMENT",
                "mlflow_experiment": {"experiment_id": "0"},
            },
            "request_time": "2025-10-22T04:14:54.524Z",
            "state": "OK",
            "trace_metadata": {
                "mlflow.trace_schema.version": "3",
                "mlflow.traceInputs": '"abc"',
                "mlflow.source.type": "LOCAL",
                "mlflow.source.git.branch": "branch-3.4",
                "mlflow.source.name": "a.py",
                "mlflow.source.git.commit": "78d075062b120597050bf2b3839a426feea5ea4c",
                "mlflow.user": "serena.ruan",
                "mlflow.traceOutputs": '"def"',
                "mlflow.source.git.repoURL": "git@github.com:mlflow/mlflow.git",
                "mlflow.trace.sizeBytes": "1226",
            },
            "tags": {
                "mlflow.artifactLocation": "mlflow-artifacts:/0/traces",
                "mlflow.traceName": "test",
            },
            "request_preview": '"abc"',
            "response_preview": '"def"',
            "execution_duration_ms": 60,
        },
        "data": {
            "spans": [
                {
                    "trace_id": "7hcYRmnCZf/c+SmbNvbczA==",
                    "span_id": "3ElmHER9IVU=",
                    "trace_state": "",
                    "parent_span_id": "",
                    "name": "test",
                    "start_time_unix_nano": 1761106494524157000,
                    "end_time_unix_nano": 1761106494584860000,
                    "attributes": {
                        "mlflow.spanOutputs": '"def"',
                        "mlflow.spanType": '"UNKNOWN"',
                        "mlflow.spanInputs": '"abc"',
                        "mlflow.traceRequestId": '"tr-ee17184669c265ffdcf9299b36f6dccc"',
                        "test": '"test"',
                    },
                    "status": {"message": "", "code": "STATUS_CODE_OK"},
                }
            ]
        },
    }
    trace = Trace.from_dict(trace_dict)
    assert trace.info.trace_id == "tr-ee17184669c265ffdcf9299b36f6dccc"
    assert trace.info.request_time == 1761106494524
    assert trace.info.execution_duration == 60
    assert trace.info.trace_location == TraceLocation.from_experiment_id("0")
    assert len(trace.data.spans) == 1
    assert trace.data.spans[0].name == "test"
    assert trace.data.spans[0].inputs == "abc"
    assert trace.data.spans[0].outputs == "def"
        user_id="unknown",
        start_time=int(mock_time * 1000),
        tags=[],
        run_name="my name",
    )


def test_client_get_trace(mock_store, mock_artifact_repo):
    trace_id = "trace:/catalog.schema/123"
    mock_store.batch_get_traces.return_value = [
        Trace(
            TraceInfo(
                trace_id=trace_id,
                trace_location=TraceLocation(
                    type=TraceLocationType.UC_SCHEMA,
                    uc_schema=UCSchemaLocation(catalog_name="catalog", schema_name="schema"),
                ),
                request_time=123,
                execution_duration=456,
                state=TraceState.OK,
                tags={"mlflow.artifactLocation": "dbfs:/path/to/artifacts"},
            ),
            TraceData(
                spans=[
                    Span.from_dict(
                        {
                            "name": "predict",
                            "context": {
                                "trace_id": "0x123456789",
                                "span_id": "0x12345",
                            },
                            "parent_id": None,
                            "start_time": 123000000,
                            "end_time": 579000000,
                            "status_code": "OK",
                            "status_message": "",
                            "attributes": {
                                "mlflow.traceRequestId": f'"{trace_id}"',
                                "mlflow.spanType": '"LLM"',
                                "mlflow.spanFunctionName": '"predict"',
                                "mlflow.spanInputs": '{"prompt": "What is the meaning of life?"}',
```

## 原始行 175 · command_execution

命令：
```
/bin/bash -lc 'ruff check --config /dev/null --select F,E501 mlflow/entities/span.py mlflow/entities/span_status.py mlflow/entities/trace_data.py mlflow/tracing/trace_manager.py mlflow/tracing/utils/otlp.py mlflow/tracing/utils/truncation.py mlflow/tracing/utils/processor.py mlflow/tracing/processor/base_mlflow.py mlflow/tracing/config.py'
```

退出码：`2`

输出：
```
error: invalid value '/dev/null' for '--config <CONFIG_OPTION>'

  tip: A `--config` flag must either be a path to a `.toml` configuration file
       or a TOML `<KEY> = <VALUE>` pair overriding a specific configuration
       option

For more information, try '--help'.
```

## 原始行 178 · command_execution

命令：
```
/bin/bash -lc "ruff check --config \"required-version = '>=0.12.10'\" --select F,E501 mlflow/entities/span.py mlflow/entities/span_status.py mlflow/entities/trace_data.py mlflow/tracing/trace_manager.py mlflow/tracing/utils/otlp.py mlflow/tracing/utils/truncation.py mlflow/tracing/utils/processor.py mlflow/tracing/processor/base_mlflow.py mlflow/tracing/config.py"
```

退出码：`0`

输出：
```
All checks passed!
```

## 原始行 183 · command_execution

命令：
```
/bin/bash -lc "sed -n '90,155p' mlflow/tracing/export/mlflow_v3.py; sed -n '90,155p' mlflow/tracing/otel/translation/__init__.py 2>/dev/null || true; grep -R -n \"translate_span_when_storing\" mlflow/tracing"
```

退出码：`0`

输出：
```
                )
            else:
                self._log_spans(experiment_id, spans_to_log)

    def _collect_mlflow_spans_for_export(
        self, spans: Sequence[ReadableSpan]
    ) -> dict[str, list[Span]]:
        """
        Collect MLflow spans from ReadableSpans for export, grouped by experiment ID.

        Args:
            spans: Sequence of ReadableSpan objects.

        Returns:
            Dictionary mapping experiment_id to list of MLflow Span objects.
        """
        manager = InMemoryTraceManager.get_instance()
        spans_by_experiment = defaultdict(list)

        for span in spans:
            mlflow_trace_id = manager.get_mlflow_trace_id_from_otel_id(span.context.trace_id)
            experiment_id = get_experiment_id_for_trace(span)
            span_id = encode_span_id(span.context.span_id)
            # we need to fetch the mlflow span from the trace manager because the span
            # may be updated in processor before exporting (e.g. deduplication).
            if mlflow_span := manager.get_span_from_id(mlflow_trace_id, span_id):
                spans_by_experiment[experiment_id].append(mlflow_span)

        return spans_by_experiment

    def _export_traces(self, spans: Sequence[ReadableSpan]) -> None:
        """
        Export full traces for root spans.

        Args:
            spans: Sequence of ReadableSpan objects.
        """
        manager = InMemoryTraceManager.get_instance()
        for span in spans:
            if span._parent is not None:
                continue

            manager_trace = manager.pop_trace(span.context.trace_id)
            if manager_trace is None:
                _logger.debug(f"Trace for root span {span} not found. Skipping full export.")
                continue

            trace = manager_trace.trace
            _set_last_active_trace_id(trace.info.request_id)

            # Store mapping from eval request ID to trace ID so that the evaluation
            # harness can access to the trace using mlflow.get_trace(eval_request_id)
            if eval_request_id := trace.info.tags.get(TraceTagKey.EVAL_REQUEST_ID):
                _EVAL_REQUEST_ID_TO_TRACE_ID[eval_request_id] = trace.info.trace_id

            if not maybe_get_request_id(is_evaluate=True):
                self._display_handler.display_traces([trace])

            if self._should_log_async():
                self._async_queue.put(
                    task=Task(
                        handler=self._log_trace,
                        args=(trace, manager_trace.prompts),
                        error_msg="Failed to log trace to the trace server.",
                    )
                )
            }


def _get_input_value(attributes: dict[str, Any]) -> Any:
    """
    Get input value from various OTEL semantic conventions.

    Args:
        attributes: Dictionary of span attributes

    Returns:
        Input value or None if not found
    """
    for translator in _TRANSLATORS:
        if value := translator.get_input_value(attributes):
            return value


def _get_output_value(attributes: dict[str, Any]) -> Any:
    """
    Get output value from various OTEL semantic conventions.

    Args:
        attributes: Dictionary of span attributes

    Returns:
        Output value or None if not found
    """
    for translator in _TRANSLATORS:
        if value := translator.get_output_value(attributes):
            return value


def translate_span_type_from_otel(attributes: dict[str, Any]) -> str | None:
    """
    Translate OTEL span kind attributes to MLflow span type.

    This function checks for span kind attributes from various OTEL semantic
    conventions (OpenInference, Traceloop) and maps them to MLflow span types.

    Args:
        attributes: Dictionary of span attributes

    Returns:
        MLflow span type string or None if no mapping found
    """
    for translator in _TRANSLATORS:
        if mlflow_type := translator.translate_span_type(attributes):
            return mlflow_type


def translate_loaded_span(span_dict: dict[str, Any]) -> dict[str, Any]:
    """
    Apply attributes translations to a span dictionary when loading.

    Supported translations:
    - OTEL span kind attributes

    Args:
        span_dict: Span dictionary (will be modified in-place)

    Returns:
        Modified span dictionary
    """
    attributes = span_dict.get("attributes", {})

grep: mlflow/tracing/otel/translation/__pycache__/__init__.cpython-311.pyc: binary file matches
mlflow/tracing/otel/translation/__init__.py:33:def translate_span_when_storing(span: Span) -> dict[str, Any]:
```

## 原始行 185 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,90p' mlflow/tracing/otel/translation/__init__.py; grep -R -n \"translate_span_when_storing\" mlflow/store mlflow/tracing/export | head -30"
```

退出码：`0`

输出：
```
"""
Utilities for translating OTEL span attributes to MLflow span format.

This module provides functions to translate span attributes from various
OTEL semantic conventions (OpenInference, Traceloop, GenAI) to MLflow span types.
It uses modular translator classes for each OTEL schema for better organization
and performance.
"""

import json
import logging
from typing import Any

from mlflow.entities.span import Span
from mlflow.tracing.constant import SpanAttributeKey, TokenUsageKey
from mlflow.tracing.otel.translation.base import OtelSchemaTranslator
from mlflow.tracing.otel.translation.genai_semconv import GenAiTranslator
from mlflow.tracing.otel.translation.google_adk import GoogleADKTranslator
from mlflow.tracing.otel.translation.open_inference import OpenInferenceTranslator
from mlflow.tracing.otel.translation.traceloop import TraceloopTranslator
from mlflow.tracing.utils import dump_span_attribute_value

_logger = logging.getLogger(__name__)

_TRANSLATORS: list[OtelSchemaTranslator] = [
    OpenInferenceTranslator(),
    GenAiTranslator(),
    TraceloopTranslator(),
    GoogleADKTranslator(),
]


def translate_span_when_storing(span: Span) -> dict[str, Any]:
    """
    Apply attributes translations to a span's dictionary when storing.

    Supported translations:
    - Token usage attributes from various OTEL schemas
    - Inputs and outputs attributes from various OTEL schemas

    These attributes translation need to happen when storing spans because we need
    to update TraceInfo accordingly.

    Args:
        span: Span object

    Returns:
        Translated span dictionary
    """
    span_dict = span.to_dict()
    attributes = span_dict.get("attributes", {})

    # Translate inputs and outputs
    if SpanAttributeKey.INPUTS not in attributes and (input_value := _get_input_value(attributes)):
        attributes[SpanAttributeKey.INPUTS] = input_value

    if SpanAttributeKey.OUTPUTS not in attributes and (
        output_value := _get_output_value(attributes)
    ):
        attributes[SpanAttributeKey.OUTPUTS] = output_value

    # Translate token usage
    if SpanAttributeKey.CHAT_USAGE not in attributes and (
        token_usage := _get_token_usage(attributes)
    ):
        attributes[SpanAttributeKey.CHAT_USAGE] = dump_span_attribute_value(token_usage)

    span_dict["attributes"] = attributes
    return span_dict


def _get_token_usage(attributes: dict[str, Any]) -> dict[str, Any]:
    """
    Get token usage from various OTEL semantic conventions.
    """
    for translator in _TRANSLATORS:
        input_tokens = translator.get_input_tokens(attributes)
        output_tokens = translator.get_output_tokens(attributes)
        total_tokens = translator.get_total_tokens(attributes)

        # Calculate total tokens if not provided but input/output are available
        if input_tokens and output_tokens and (total_tokens is None):
            total_tokens = int(input_tokens) + int(output_tokens)

        if input_tokens and output_tokens and total_tokens:
            return {
                TokenUsageKey.INPUT_TOKENS: int(input_tokens),
                TokenUsageKey.OUTPUT_TOKENS: int(output_tokens),
                TokenUsageKey.TOTAL_TOKENS: int(total_tokens),
            }
grep: mlflow/store/tracking/__pycache__/sqlalchemy_store.cpython-311.pyc: binary file matches
mlflow/store/tracking/sqlalchemy_store.py:117:    translate_span_when_storing,
mlflow/store/tracking/sqlalchemy_store.py:3411:                span_dict = translate_span_when_storing(span)
```

## 原始行 187 · agent_message

```
Implemented the distributed tracing functionality under `/testbed`, including:

- Live, immutable, and no-op span lifecycle behavior
- v2/v3 dictionary serialization
- OTLP protobuf conversion and AnyValue decoding
- Attribute caching and immutability enforcement
- Trace finalization and preview generation
- Span events, status, exceptions, and custom processors
- Required tracing integration helpers

Validation:

- 71 focused tests passed
- 48 entity/serialization tests passed
- Broad tracing suite: 464 passed; remaining failures were unrelated missing optional IPython/OTLP exporter dependencies
- Targeted Ruff checks passed
- Manual OTLP and dictionary round-trip checks passed
```
