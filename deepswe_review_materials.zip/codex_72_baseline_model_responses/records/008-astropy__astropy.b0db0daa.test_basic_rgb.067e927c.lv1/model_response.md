# Codex baseline: astropy__astropy.b0db0daa.test_basic_rgb.067e927c.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll trace the RGB mapping, interval, and stretch implementations and their visible tests, then patch the smallest coherent set of source files and run targeted tests plus relevant regressions.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "pwd && rg -n \"class RGBImageMapping|class ZScaleInterval|def _prepare|class CompositeStretch|class BaseInterval\" astropy/visualization -g '*.py' && rg -n \"RGBImageMapping|ZScaleInterval|CompositeStretch|_prepare\" astropy/visualization/tests -g '*.py'"
```

退出码：`127`

输出：
```
/testbed
/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
`rg` is unavailable in this environment, so I’m switching to repository-local `find`/`grep` inspection. I’ll keep the scope limited to the visualization code and tests.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "find astropy/visualization -name '*.py' -print | sort | xargs grep -nE 'class RGBImageMapping|class ZScaleInterval|def _prepare|class CompositeStretch|class BaseInterval' ; find astropy/visualization/tests -name '*.py' -print | sort | xargs grep -nE 'RGBImageMapping|ZScaleInterval|CompositeStretch|_prepare'"
```

退出码：`0`

输出：
```
astropy/visualization/basic_rgb.py:18:class RGBImageMapping:
astropy/visualization/interval.py:27:class BaseInterval(BaseTransform):
astropy/visualization/interval.py:267:class ZScaleInterval(BaseInterval):
astropy/visualization/lupton_rgb.py:532:class RGBImageMappingLupton(RGBImageMapping):
astropy/visualization/stretch.py:976:class CompositeStretch(CompositeTransform, BaseStretch):
astropy/visualization/tests/test_interval.py:15:    ZScaleInterval,
astropy/visualization/tests/test_interval.py:128:    interval = ZScaleInterval()
astropy/visualization/tests/test_interval.py:134:    interval = ZScaleInterval()
astropy/visualization/tests/test_interval.py:140:    interval = ZScaleInterval()
astropy/visualization/tests/test_interval.py:148:    Regression test to ensure ZScaleInterval returns the minimum and
astropy/visualization/tests/test_interval.py:154:    interval = ZScaleInterval(min_npixels=5)
astropy/visualization/tests/test_lupton_rgb.py:128:        asinh_map = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:158:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:174:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:189:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:205:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:223:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:308:        map_ = lupton_rgb.RGBImageMappingLupton(
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' astropy/visualization/basic_rgb.py && sed -n '1,390p' astropy/visualization/interval.py && sed -n '1,220p' astropy/visualization/stretch.py && sed -n '900,1040p' astropy/visualization/stretch.py"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Combine 3 images to produce properly-scaled RGB images with arbitrary scaling.

The three images must be aligned and have the same pixel scale and size.
"""

import numpy as np

from astropy.visualization.interval import ManualInterval
from astropy.visualization.stretch import LinearStretch

_OUTPUT_IMAGE_FORMATS = [float, np.float64, np.uint8]

__all__ = ["make_rgb"]


class RGBImageMapping:
    """
    Class to map red, blue, green images into either a normalized float or
    an 8-bit image, by performing optional clipping and applying
    a scaling function to each band independently.

    Parameters
    ----------
    interval : `~astropy.visualization.BaseInterval` subclass instance or array-like, optional
        The interval object to apply to the data (either a single instance or
        an array for R, G, B). Default is
        `~astropy.visualization.ManualInterval`.
    stretch : `~astropy.visualization.BaseStretch` subclass instance, optional
        The stretch object to apply to the data. Default is
        `~astropy.visualization.LinearStretch`.

    """

























































































































def make_rgb(
    image_r,
    image_g,
    image_b,
    interval=ManualInterval(vmin=0, vmax=None),
    stretch=LinearStretch(),
    filename=None,
    output_dtype=np.uint8,
):
    """
    Base class to return a Red/Green/Blue color image from 3 images using
    a specified stretch and interval, for each band *independently*.

    The input images can be int or float, and in any range or bit-depth,
    but must have the same shape (NxM).

    For a more detailed look at the use of this method, see the document
    :ref:`astropy:astropy-visualization-rgb`.

    Parameters
    ----------
    image_r : ndarray
        Image to map to red.
    image_g : ndarray
        Image to map to green.
    image_b : ndarray
        Image to map to blue.
    interval : `~astropy.visualization.BaseInterval` subclass instance or array-like, optional
        The interval object to apply to the data (either a single instance or
        an array for R, G, B). Default is
        `~astropy.visualization.ManualInterval` with vmin=0.
    stretch : `~astropy.visualization.BaseStretch` subclass instance, optional
        The stretch object to apply to the data. Default is
        `~astropy.visualization.LinearStretch`.
    filename : str, optional
        Write the resulting RGB image to a file (file type determined
        from extension).
    output_dtype : numpy scalar type, optional
        Image output data type. Default is np.uint8.

    Returns
    -------
    rgb : ndarray
        RGB (either float or integer with 8-bits per channel) color image
        as an NxMx3 numpy array.

    Notes
    -----
    This procedure of clipping and then scaling is similar to the DS9
    image algorithm (see the DS9 reference guide:
    http://ds9.si.edu/doc/ref/how.html).

    """
    map_ = RGBImageMapping(interval=interval, stretch=stretch)
    rgb = map_.make_rgb_image(image_r, image_g, image_b, output_dtype=output_dtype)

    if filename:
        import matplotlib.image

        matplotlib.image.imsave(filename, rgb, origin="lower")

    return rgb# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
Classes that deal with computing intervals from arrays of values based on
various criteria.
"""

import abc

import numpy as np

from astropy.utils.masked import get_data_and_mask

from .transform import BaseTransform

__all__ = [
    "AsymmetricPercentileInterval",
    "BaseInterval",
    "ManualInterval",
    "MinMaxInterval",
    "PercentileInterval",
    "SymmetricInterval",
    "ZScaleInterval",
]


class BaseInterval(BaseTransform):
    """
    Base class for the interval classes, which, when called with an
    array of values, return an interval computed following different
    algorithms.
    """

    @abc.abstractmethod
    def get_limits(self, values):
        """
        Return the minimum and maximum value in the interval based on
        the values provided.

        Parameters
        ----------
        values : ndarray
            The image values.

        Returns
        -------
        vmin, vmax : float
            The mininium and maximum image value in the interval.
        """
        raise NotImplementedError("Needs to be implemented in a subclass.")


























    def __call__(self, values, clip=True, out=None):
        """
        Transform values using this interval.

        The ``vmin`` and ``vmax`` values are determined by the
        `get_limits` method.

        The following transformation is then applied to the values:

        .. math::

            {\\rm result} = \\frac{{\\rm values} - v_{\\rm min}}
                                   {v_{\\rm max} - v_{\\rm min}}

        If ``clip`` is `True` (default), the result is then clipped to
        the [0:1] range.

        Parameters
        ----------
        values : array-like
            The input values.
        clip : bool, optional
            If `True` (default), values outside the [0:1] range are
            clipped to the [0:1] range.
        out : ndarray, optional
            If specified, the output values will be placed in this array
            (typically used for in-place calculations).

        Returns
        -------
        result : ndarray
            The transformed values.
        """
        vmin, vmax = self.get_limits(values)

        if out is None:
            values = np.subtract(values, float(vmin))
        else:
            if out.dtype.kind != "f":
                raise TypeError(
                    "Can only do in-place scaling for floating-point arrays"
                )
            values = np.subtract(values, float(vmin), out=out)

        if (vmax - vmin) != 0:
            np.true_divide(values, vmax - vmin, out=values)

        if clip:
            np.clip(values, 0.0, 1.0, out=values)

        return values


class ManualInterval(BaseInterval):
    """
    Interval based on user-specified values.

    Parameters
    ----------
    vmin : float, optional
        The minimum value in the scaling.  Defaults to the image
        minimum (ignoring NaNs)
    vmax : float, optional
        The maximum value in the scaling.  Defaults to the image
        maximum (ignoring NaNs)
    """

    def __init__(self, vmin=None, vmax=None):
        self.vmin = vmin
        self.vmax = vmax

    def get_limits(self, values):
        # Avoid overhead of preparing array if both limits have been specified
        # manually, for performance.
        if self.vmin is not None and self.vmax is not None:
            return self.vmin, self.vmax

        values = self._process_values(values)
        vmin = np.min(values) if self.vmin is None else self.vmin
        vmax = np.max(values) if self.vmax is None else self.vmax

        return vmin, vmax


class MinMaxInterval(BaseInterval):
    """
    Interval based on the minimum and maximum values in the data.
    """

    def get_limits(self, values):
        values = self._process_values(values)

        return np.min(values), np.max(values)


class AsymmetricPercentileInterval(BaseInterval):
    """
    Interval based on a keeping a specified fraction of pixels (can be
    asymmetric).

    Parameters
    ----------
    lower_percentile : float or None
        The lower percentile below which to ignore pixels. If None, then
        defaults to 0.
    upper_percentile : float or None
        The upper percentile above which to ignore pixels. If None, then
        defaults to 100.
    n_samples : int, optional
        Maximum number of values to use. If this is specified, and there
        are more values in the dataset as this, then values are randomly
        sampled from the array (with replacement).
    """

    def __init__(self, lower_percentile=None, upper_percentile=None, n_samples=None):
        self.lower_percentile = (
            lower_percentile if lower_percentile is not None else 0.0
        )
        self.upper_percentile = (
            upper_percentile if upper_percentile is not None else 100.0
        )
        self.n_samples = n_samples

    def get_limits(self, values):
        values = self._process_values(values)

        # If needed, limit the number of samples. We sample with replacement
        # since this is much faster.
        if self.n_samples is not None and values.size > self.n_samples:
            values = np.random.choice(values, self.n_samples)

        # Determine values at percentiles
        vmin, vmax = np.percentile(
            values, (self.lower_percentile, self.upper_percentile)
        )

        return vmin, vmax


class PercentileInterval(AsymmetricPercentileInterval):
    """
    Interval based on a keeping a specified fraction of pixels.

    Parameters
    ----------
    percentile : float
        The fraction of pixels to keep. The same fraction of pixels is
        eliminated from both ends.
    n_samples : int, optional
        Maximum number of values to use. If this is specified, and there
        are more values in the dataset as this, then values are randomly
        sampled from the array (with replacement).
    """

    def __init__(self, percentile, n_samples=None):
        lower_percentile = (100 - percentile) * 0.5
        upper_percentile = 100 - lower_percentile
        super().__init__(lower_percentile, upper_percentile, n_samples=n_samples)


class SymmetricInterval(BaseInterval):
    """
    Interval based on a symmetric radius away from a midpoint.

    Parameters
    ----------
    radius : float or None
        The amount the interval extends to either side of the midpoint, so the total
        interval is twice this value. If None, the radius is automatically
        determined such that the resulting interval contains both the image minimum
        and maximum (ignoring NaNs).
    midpoint : float, optional
        The midpoint of the symmetric interval.  Defaults to zero.
    """

    def __init__(self, radius=None, *, midpoint=0):
        self.radius = radius
        self.midpoint = midpoint

    def get_limits(self, values):
        radius = self.radius
        if radius is None:
            values = self._process_values(values)
            radius = np.max(
                [np.max(values) - self.midpoint, self.midpoint - np.min(values)]
            )

        return self.midpoint - radius, self.midpoint + radius


class ZScaleInterval(BaseInterval):
    """
    Interval based on IRAF's zscale.

    Original implementation:
    https://github.com/spacetelescope/stsci.numdisplay/blob/master/lib/stsci/numdisplay/zscale.py

    Licensed under a 3-clause BSD style license (see AURA_LICENSE.rst).

    Parameters
    ----------
    n_samples : int, optional
        The number of points in the array to sample for determining
        scaling factors.  Defaults to 1000.

        .. versionchanged:: 7.0
            ``nsamples`` parameter is removed.

    contrast : float, optional
        The scaling factor (between 0 and 1) for determining the minimum
        and maximum value.  Larger values decrease the difference
        between the minimum and maximum values used for display.
        Defaults to 0.25.
    max_reject : float, optional
        If more than ``max_reject * npixels`` pixels are rejected, then
        the returned values are the minimum and maximum of the data.
        Defaults to 0.5.
    min_npixels : int, optional
        If there are less than ``min_npixels`` pixels remaining after
        the pixel rejection, then the returned values are the minimum
        and maximum of the data.  Defaults to 5.
    krej : float, optional
        The number of sigma used for the rejection. Defaults to 2.5.
    max_iterations : int, optional
        The maximum number of iterations for the rejection. Defaults to
        5.
    """

    def __init__(
        self,
        n_samples=1000,
        contrast=0.25,
        max_reject=0.5,
        min_npixels=5,
        krej=2.5,
        max_iterations=5,
    ):
        self.n_samples = n_samples
        self.contrast = contrast
        self.max_reject = max_reject
        self.min_npixels = min_npixels
        self.krej = krej
        self.max_iterations = max_iterations
















# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
Classes that deal with stretching, i.e. mapping a range of [0:1] values onto
another set of [0:1] values with a transformation.
"""

import numpy as np

from .transform import BaseTransform, CompositeTransform

__all__ = [
    "AsinhStretch",
    "BaseStretch",
    "CompositeStretch",
    "ContrastBiasStretch",
    "HistEqStretch",
    "LinearStretch",
    "LogStretch",
    "PowerDistStretch",
    "PowerStretch",
    "SinhStretch",
    "SqrtStretch",
    "SquaredStretch",
]


def _logn(n, x, out=None):
    """Calculate the log base n of x."""
    # We define this because numpy.emath.logn doesn't support the out
    # keyword.
    if out is None:
        return np.log(x) / np.log(n)
    else:
        np.log(x, out=out)
        np.true_divide(out, np.log(n), out=out)
        return out

















class BaseStretch(BaseTransform):
    """
    Base class for the stretch classes, which when called with an array
    of values in the range [0:1], returns an transformed array of values
    also in the range [0:1].
    """

    @property
    def _supports_invalid_kw(self):
        return False

    def __add__(self, other):
        return CompositeStretch(other, self)

    def __call__(self, values, clip=True, out=None):
        """
        Transform values using this stretch.

        Parameters
        ----------
        values : array-like
            The input values, which should already be normalized to the
            [0:1] range.
        clip : bool, optional
            If `True` (default), values outside the [0:1] range are
            clipped to the [0:1] range.
        out : ndarray, optional
            If specified, the output values will be placed in this array
            (typically used for in-place calculations).

        Returns
        -------
        result : ndarray
            The transformed values.
        """

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""


class LinearStretch(BaseStretch):
    """
    A linear stretch with a slope and offset.

    The stretch is given by:

    .. math::
        y = slope * x + intercept

    Parameters
    ----------
    slope : float, optional
        The ``slope`` parameter used in the above formula.  Default is 1.
    intercept : float, optional
        The ``intercept`` parameter used in the above formula.  Default is 0.

    Examples
    --------
    .. plot::
        :show-source-link:

        import numpy as np
        from astropy.visualization import LinearStretch
        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 5))

        x = np.linspace(0, 1, 100)
        slopes = [1, 0.5, 1.3, 1.4, 2.0]
        intercepts = [0, 0.0, -0.4, 0., 0.2]
        for slope, intercept in zip(slopes, intercepts):
            stretch = LinearStretch(slope, intercept)
            label = f'{slope=}, {intercept=}'
            ax.plot(x, stretch(x, clip=True), label=label)

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='lower right', fontsize=8)
    """

    def __init__(self, slope=1, intercept=0):
        super().__init__()
        self.slope = slope
        self.intercept = intercept

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        if self.slope != 1:
            np.multiply(values, self.slope, out=values)
        if self.intercept != 0:
            np.add(values, self.intercept, out=values)

        if clip:
            np.clip(values, 0, 1, out=values)

        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return LinearStretch(1.0 / self.slope, -self.intercept / self.slope)


class SqrtStretch(BaseStretch):
    r"""
    A square root stretch.

    The stretch is given by:

    .. math::
        y = \sqrt{x}

    Examples
    --------
    .. plot::
        :show-source-link:

        import numpy as np
        from astropy.visualization import SqrtStretch
        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 5))

        x = np.linspace(0, 1, 100)
        stretch = SqrtStretch()
        ax.plot(x, stretch(x, clip=True))

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
    """

    @property
    def _supports_invalid_kw(self):
        return True

    def __call__(self, values, clip=True, out=None, invalid=None):
        """
        Transform values using this stretch.

        Parameters
        ----------
        values : array-like
            The input values, which should already be normalized to the
            [0:1] range.
        clip : bool, optional
            If `True` (default), values outside the [0:1] range are
            clipped to the [0:1] range.
        out : ndarray, optional
            If specified, the output values will be placed in this array
            (typically used for in-place calculations).
        invalid : None or float, optional
            Value to assign NaN values generated by this class.  NaNs in
            the input ``values`` array are not changed.  This option is
            generally used with matplotlib normalization classes, where
            the ``invalid`` value should map to the matplotlib colormap
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='lower right', fontsize=8)
    """

    def __init__(self, contrast, bias):
        super().__init__()
        self.contrast = contrast
        self.bias = bias

    def __call__(self, values, clip=True, out=None):
        # As a special case here, we only clip *after* the
        # transformation since it does not map [0:1] to [0:1]
        values = _prepare(values, clip=False, out=out)

        np.subtract(values, self.bias, out=values)
        np.multiply(values, self.contrast, out=values)
        np.add(values, 0.5, out=values)

        if clip:
            np.clip(values, 0, 1, out=values)

        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return InvertedContrastBiasStretch(self.contrast, self.bias)


class InvertedContrastBiasStretch(BaseStretch):
    r"""
    Inverse transformation for
    `~astropy.visualization.ContrastBiasStretch`.

    The stretch is given by:

    .. math::
        y = \frac{x - 0.5}{{\rm contrast}} + {\rm bias}

    Parameters
    ----------
    contrast : float
        The contrast parameter (see
        `~astropy.visualization.ContrastBiasStretch`).

    bias : float
        The bias parameter (see
        `~astropy.visualization.ContrastBiasStretch`).
    """

    def __init__(self, contrast, bias):
        super().__init__()
        self.contrast = contrast
        self.bias = bias

    def __call__(self, values, clip=True, out=None):
        # As a special case here, we only clip *after* the
        # transformation since it does not map [0:1] to [0:1]
        values = _prepare(values, clip=False, out=out)
        np.subtract(values, 0.5, out=values)
        np.true_divide(values, self.contrast, out=values)
        np.add(values, self.bias, out=values)

        if clip:
            np.clip(values, 0, 1, out=values)

        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return ContrastBiasStretch(self.contrast, self.bias)


class CompositeStretch(CompositeTransform, BaseStretch):
    """
    A combination of two stretches.

    Parameters
    ----------
    stretch_1 : :class:`astropy.visualization.BaseStretch`
        The first stretch to apply.
    stretch_2 : :class:`astropy.visualization.BaseStretch`
        The second stretch to apply.
    """
```

## 原始行 16 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,230p' astropy/visualization/tests/test_basic_rgb.py 2>/dev/null || true; sed -n '1,230p' astropy/visualization/tests/test_interval.py; sed -n '1,330p' astropy/visualization/tests/test_stretch.py; sed -n '960,1040p' astropy/visualization/stretch.py; sed -n '1,180p' astropy/visualization/transform.py; git status --short"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import numpy as np
import pytest
from numpy.testing import assert_allclose

from astropy.utils import NumpyRNGContext
from astropy.utils.masked import Masked
from astropy.visualization.interval import (
    AsymmetricPercentileInterval,
    ManualInterval,
    MinMaxInterval,
    PercentileInterval,
    SymmetricInterval,
    ZScaleInterval,
)


class TestInterval:
    data = np.linspace(-20.0, 60.0, 100)

    def test_manual(self):
        interval = ManualInterval(-10.0, +15.0)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -10.0)
        assert_allclose(vmax, +15.0)

    def test_manual_defaults(self):
        interval = ManualInterval(vmin=-10.0)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -10.0)
        assert_allclose(vmax, np.max(self.data))

        interval = ManualInterval(vmax=15.0)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, np.min(self.data))
        assert_allclose(vmax, 15.0)

    def test_manual_zero_limit(self):
        # Regression test for a bug that caused ManualInterval to compute the
        # limit (min or max) if it was set to zero.
        interval = ManualInterval(vmin=0, vmax=0)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, 0)
        assert_allclose(vmax, 0)

    def test_manual_defaults_with_nan(self):
        interval = ManualInterval()
        data = np.copy(self.data)
        data[0] = np.nan
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -20)
        assert_allclose(vmax, +60)

    def test_minmax(self):
        interval = MinMaxInterval()
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -20.0)
        assert_allclose(vmax, +60.0)

    def test_percentile(self):
        interval = PercentileInterval(62.2)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -4.88)
        assert_allclose(vmax, 44.88)

    def test_asymmetric_percentile(self):
        interval = AsymmetricPercentileInterval(10.5, 70.5)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -11.6)
        assert_allclose(vmax, 36.4)

    def test_asymmetric_percentile_nsamples(self):
        with NumpyRNGContext(12345):
            interval = AsymmetricPercentileInterval(10.5, 70.5, n_samples=20)
            vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -14.367676767676768)
        assert_allclose(vmax, 40.266666666666666)

    def test_symmetric_interval_manual(self):
        interval = SymmetricInterval(radius=40)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -40.0)
        assert_allclose(vmax, +40.0)

        interval = SymmetricInterval(radius=100, midpoint=10)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -90.0)
        assert_allclose(vmax, +110.0)

    def test_symmetric_interval_auto(self):
        interval = SymmetricInterval()
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -60.0)
        assert_allclose(vmax, +60.0)

        interval = SymmetricInterval(midpoint=50)
        vmin, vmax = interval.get_limits(self.data)
        assert_allclose(vmin, -20.0)
        assert_allclose(vmax, +120.0)


class TestIntervalList(TestInterval):
    # Make sure intervals work with lists
    data = np.linspace(-20.0, 60.0, 100).tolist()


class TestInterval2D(TestInterval):
    # Make sure intervals work with 2d arrays
    data = np.linspace(-20.0, 60.0, 100).reshape(100, 1)


class TestIntervalMaskedArray(TestInterval):
    # Make sure intervals work with MaskedArray
    data = np.concatenate((np.linspace(-20.0, 60.0, 100), np.full(100, 1e6)))
    data = np.ma.MaskedArray(data, data > 1000)


class TestIntervalMaskedNDArray(TestInterval):
    # Make sure intervals work with MaskedArray
    data = np.concatenate((np.linspace(-20.0, 60.0, 100), np.full(100, 1e6)))
    data = Masked(data, data > 1000)


def test_zscale():
    np.random.seed(42)
    data = np.random.randn(100, 100) * 5 + 10
    interval = ZScaleInterval()
    vmin, vmax = interval.get_limits(data)
    assert_allclose(vmin, -9.6, atol=0.1)
    assert_allclose(vmax, 25.4, atol=0.1)

    data = list(range(1000)) + [np.nan]
    interval = ZScaleInterval()
    vmin, vmax = interval.get_limits(data)
    assert_allclose(vmin, 0, atol=0.1)
    assert_allclose(vmax, 999, atol=0.1)

    data = list(range(100))
    interval = ZScaleInterval()
    vmin, vmax = interval.get_limits(data)
    assert_allclose(vmin, 0, atol=0.1)
    assert_allclose(vmax, 99, atol=0.1)


def test_zscale_npoints():
    """
    Regression test to ensure ZScaleInterval returns the minimum and
    maximum of the data if the number of data points is less than
    ``min_pixels``.
    """

    data = np.arange(4).reshape((2, 2))
    interval = ZScaleInterval(min_npixels=5)
    vmin, vmax = interval.get_limits(data)
    assert vmin == 0
    assert vmax == 3


def test_integers():
    # Need to make sure integers get cast to float
    interval = MinMaxInterval()
    values = interval([1, 3, 4, 5, 6])
    assert_allclose(values, [0.0, 0.4, 0.6, 0.8, 1.0])

    # Don't accept integer array in output
    out = np.zeros(5, dtype=int)
    with pytest.raises(
        TypeError, match=r"Can only do in-place scaling for floating-point arrays"
    ):
        values = interval([1, 3, 4, 5, 6], out=out)

    # But integer input and floating point output is fine
    out = np.zeros(5, dtype=float)
    interval([1, 3, 4, 5, 6], out=out)
    assert_allclose(out, [0.0, 0.4, 0.6, 0.8, 1.0])


def test_constant_data():
    """Test intervals with constant data (avoiding divide-by-zero)."""
    shape = (10, 10)
    data = np.ones(shape)
    interval = MinMaxInterval()
    limits = interval.get_limits(data)
    values = interval(data)
    assert_allclose(limits, (1.0, 1.0))
    assert_allclose(values, np.zeros(shape))
# Licensed under a 3-clause BSD style license - see LICENSE.rst

import numpy as np
import pytest
from numpy.testing import assert_allclose, assert_equal

from astropy.visualization.stretch import (
    AsinhStretch,
    ContrastBiasStretch,
    HistEqStretch,
    InvertedHistEqStretch,
    InvertedLogStretch,
    InvertedPowerDistStretch,
    LinearStretch,
    LogStretch,
    PowerDistStretch,
    PowerStretch,
    SinhStretch,
    SqrtStretch,
    SquaredStretch,
)

DATA = np.array([0.00, 0.25, 0.50, 0.75, 1.00])

RESULTS = {}
RESULTS[LinearStretch()] = np.array([0.00, 0.25, 0.50, 0.75, 1.00])
RESULTS[LinearStretch(intercept=0.5) + LinearStretch(slope=0.5)] = np.array(
    [0.5, 0.625, 0.75, 0.875, 1.0]
)
RESULTS[SqrtStretch()] = np.array([0.0, 0.5, 0.70710678, 0.8660254, 1.0])
RESULTS[SquaredStretch()] = np.array([0.0, 0.0625, 0.25, 0.5625, 1.0])
RESULTS[PowerStretch(0.5)] = np.array([0.0, 0.5, 0.70710678, 0.8660254, 1.0])
RESULTS[PowerDistStretch()] = np.array([0.0, 0.004628, 0.030653, 0.177005, 1.0])
RESULTS[LogStretch()] = np.array([0.0, 0.799776, 0.899816, 0.958408, 1.0])
RESULTS[AsinhStretch()] = np.array([0.0, 0.549402, 0.77127, 0.904691, 1.0])
RESULTS[SinhStretch()] = np.array([0.0, 0.082085, 0.212548, 0.46828, 1.0])
RESULTS[ContrastBiasStretch(contrast=2.0, bias=0.4)] = np.array(
    [-0.3, 0.2, 0.7, 1.2, 1.7]
)
RESULTS[HistEqStretch(DATA)] = DATA
RESULTS[HistEqStretch(DATA[::-1])] = DATA
RESULTS[HistEqStretch(DATA**0.5)] = np.array([0.0, 0.125, 0.25, 0.5674767, 1.0])


class TestStretch:
    @pytest.mark.parametrize("stretch", RESULTS.keys())
    def test_no_clip(self, stretch):
        np.testing.assert_allclose(
            stretch(DATA, clip=False), RESULTS[stretch], atol=1.0e-6
        )

    @pytest.mark.parametrize("ndim", [2, 3])
    @pytest.mark.parametrize("stretch", RESULTS.keys())
    def test_clip_ndimensional(self, stretch, ndim):
        new_shape = DATA.shape + (1,) * ndim

        np.testing.assert_allclose(
            stretch(DATA.reshape(new_shape), clip=True).ravel(),
            np.clip(RESULTS[stretch], 0.0, 1),
            atol=1.0e-6,
        )

    @pytest.mark.parametrize("stretch", RESULTS.keys())
    def test_clip(self, stretch):
        np.testing.assert_allclose(
            stretch(DATA, clip=True), np.clip(RESULTS[stretch], 0.0, 1), atol=1.0e-6
        )

    @pytest.mark.parametrize("stretch", RESULTS.keys())
    def test_inplace(self, stretch):
        data_in = DATA.copy()
        result = np.zeros(DATA.shape)
        stretch(data_in, out=result, clip=False)
        np.testing.assert_allclose(result, RESULTS[stretch], atol=1.0e-6)
        np.testing.assert_allclose(data_in, DATA)

    @pytest.mark.parametrize("stretch", RESULTS.keys())
    def test_round_trip(self, stretch):
        np.testing.assert_allclose(
            stretch.inverse(stretch(DATA, clip=False), clip=False), DATA
        )

    @pytest.mark.parametrize("stretch", RESULTS.keys())
    def test_inplace_roundtrip(self, stretch):
        result = np.zeros(DATA.shape)
        stretch(DATA, out=result, clip=False)
        stretch.inverse(result, out=result, clip=False)
        np.testing.assert_allclose(result, DATA)

    @pytest.mark.parametrize("stretch", RESULTS.keys())
    def test_double_inverse(self, stretch):
        np.testing.assert_allclose(
            stretch.inverse.inverse(DATA), stretch(DATA), atol=1.0e-6
        )

    def test_inverted(self):
        stretch_1 = SqrtStretch().inverse
        stretch_2 = PowerStretch(2)
        np.testing.assert_allclose(stretch_1(DATA), stretch_2(DATA))

    def test_chaining(self):
        stretch_1 = SqrtStretch() + SqrtStretch()
        stretch_2 = PowerStretch(0.25)
        stretch_3 = PowerStretch(4.0)

        np.testing.assert_allclose(stretch_1(DATA), stretch_2(DATA))

        np.testing.assert_allclose(stretch_1.inverse(DATA), stretch_3(DATA))


def test_clip_invalid():
    stretch = SqrtStretch()

    values = stretch([-1.0, 0.0, 0.5, 1.0, 1.5])
    np.testing.assert_allclose(values, [0.0, 0.0, 0.70710678, 1.0, 1.0])

    values = stretch([-1.0, 0.0, 0.5, 1.0, 1.5], clip=False)
    np.testing.assert_allclose(values, [np.nan, 0.0, 0.70710678, 1.0, 1.2247448])


@pytest.mark.parametrize("a", [-2.0, -1, 0.0, 1.0])
def test_invalid_powerdist_a(a):
    match = "a must be > 0, but cannot be set to 1"
    with pytest.raises(ValueError, match=match):
        PowerDistStretch(a=a)
    with pytest.raises(ValueError, match=match):
        InvertedPowerDistStretch(a=a)


@pytest.mark.parametrize("a", [-2.0, -1, 0.0])
def test_invalid_power_log_a(a):
    match = "a must be > 0"
    with pytest.raises(ValueError, match=match):
        PowerStretch(a=a)
    with pytest.raises(ValueError, match=match):
        LogStretch(a=a)
    with pytest.raises(ValueError, match=match):
        InvertedLogStretch(a=a)


@pytest.mark.parametrize("a", [-2.0, -1, 0.0])
def test_invalid_sinh_a(a):
    match = "a must be > 0"
    with pytest.raises(ValueError, match=match):
        AsinhStretch(a=a)
    with pytest.raises(ValueError, match=match):
        SinhStretch(a=a)


def test_sinh_a():
    a = 0.9
    a_inv = 1.0 / np.arcsinh(1.0 / a)
    z = AsinhStretch(a=a)
    assert_allclose(z.inverse.a, a_inv)


def test_histeqstretch_invalid():
    data = np.array([-np.inf, 0.00, 0.25, 0.50, 0.75, 1.00, np.inf])
    result = np.array([0.0, 0.0, 0.25, 0.5, 0.75, 1.0, 1.0])
    assert_equal(HistEqStretch(data)(data), result)
    assert_equal(InvertedHistEqStretch(data)(data), result)


def test_linearstretch_clip():
    data = np.linspace(0, 1, 100)
    stretch = LinearStretch(slope=2)
    result = stretch(data, clip=True)
    assert np.min(result) >= 0
    assert np.max(result) <= 1
        values = _prepare(values, clip=False, out=out)
        np.subtract(values, 0.5, out=values)
        np.true_divide(values, self.contrast, out=values)
        np.add(values, self.bias, out=values)

        if clip:
            np.clip(values, 0, 1, out=values)

        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return ContrastBiasStretch(self.contrast, self.bias)


class CompositeStretch(CompositeTransform, BaseStretch):
    """
    A combination of two stretches.

    Parameters
    ----------
    stretch_1 : :class:`astropy.visualization.BaseStretch`
        The first stretch to apply.
    stretch_2 : :class:`astropy.visualization.BaseStretch`
        The second stretch to apply.
    """

# Licensed under a 3-clause BSD style license - see LICENSE.rst


__all__ = ["BaseTransform", "CompositeTransform"]


class BaseTransform:
    """
    A transformation object.

    This is used to construct transformations such as scaling, stretching, and
    so on.
    """

    def __add__(self, other):
        return CompositeTransform(other, self)


class CompositeTransform(BaseTransform):
    """
    A combination of two transforms.

    Parameters
    ----------
    transform_1 : :class:`astropy.visualization.BaseTransform`
        The first transform to apply.
    transform_2 : :class:`astropy.visualization.BaseTransform`
        The second transform to apply.
    """

    def __init__(self, transform_1, transform_2):
        super().__init__()
        self.transform_1 = transform_1
        self.transform_2 = transform_2

    def __call__(self, values, clip=True):
        return self.transform_2(self.transform_1(values, clip=clip), clip=clip)

    @property
    def inverse(self):
        return self.__class__(self.transform_2.inverse, self.transform_1.inverse)
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "find astropy/visualization/tests -maxdepth 1 -type f -printf '%f\\n' | sort; grep -R -n \"make_rgb\\|RGBImageMapping\" astropy/visualization/tests astropy/visualization --include='*.py'; grep -R -n \"_process_values\\|def _prepare\" astropy/visualization --include='*.py'; grep -R -n \"output_dtype\" astropy/visualization/tests --include='*.py'"
```

退出码：`1`

输出：
```
__init__.py
test_histogram.py
test_interval.py
test_lupton_rgb.py
test_norm.py
test_stretch.py
test_time.py
test_units.py
astropy/visualization/tests/test_lupton_rgb.py:128:        asinh_map = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:132:        rgb_image = asinh_map.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:158:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:164:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:174:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:181:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:189:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:196:        rgb_image = map_.make_rgb_image(self.image_r, self.image_r, self.image_r)
astropy/visualization/tests/test_lupton_rgb.py:205:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:213:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:223:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:231:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:259:    def test_make_rgb(self, tmp_path):
astropy/visualization/tests/test_lupton_rgb.py:273:    def test_make_rgb_incorrect_min_input(self):
astropy/visualization/tests/test_lupton_rgb.py:284:    def test_make_rgb_saturated_fix(self, tmp_path):
astropy/visualization/tests/test_lupton_rgb.py:308:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:312:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:339:        rgb_image = asinhMap.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/basic_rgb.py:15:__all__ = ["make_rgb"]
astropy/visualization/basic_rgb.py:18:class RGBImageMapping:
astropy/visualization/basic_rgb.py:156:def make_rgb(
astropy/visualization/basic_rgb.py:209:    map_ = RGBImageMapping(interval=interval, stretch=stretch)
astropy/visualization/basic_rgb.py:210:    rgb = map_.make_rgb_image(image_r, image_g, image_b, output_dtype=output_dtype)
astropy/visualization/tests/test_lupton_rgb.py:128:        asinh_map = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:132:        rgb_image = asinh_map.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:158:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:164:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:174:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:181:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:189:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:196:        rgb_image = map_.make_rgb_image(self.image_r, self.image_r, self.image_r)
astropy/visualization/tests/test_lupton_rgb.py:205:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:213:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:223:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:231:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:259:    def test_make_rgb(self, tmp_path):
astropy/visualization/tests/test_lupton_rgb.py:273:    def test_make_rgb_incorrect_min_input(self):
astropy/visualization/tests/test_lupton_rgb.py:284:    def test_make_rgb_saturated_fix(self, tmp_path):
astropy/visualization/tests/test_lupton_rgb.py:308:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:312:        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/tests/test_lupton_rgb.py:339:        rgb_image = asinhMap.make_rgb_image(self.image_r, self.image_g, self.image_b)
astropy/visualization/lupton_rgb.py:17:from .basic_rgb import RGBImageMapping
astropy/visualization/lupton_rgb.py:89:    def make_rgb_image(self, image_r, image_g, image_b):
astropy/visualization/lupton_rgb.py:532:class RGBImageMappingLupton(RGBImageMapping):
astropy/visualization/lupton_rgb.py:747:    lup_map = RGBImageMappingLupton(
astropy/visualization/lupton_rgb.py:751:    rgb = lup_map.make_rgb_image(image_r, image_g, image_b, output_dtype=output_dtype)
astropy/visualization/interval.py:154:        values = self._process_values(values)
astropy/visualization/interval.py:167:        values = self._process_values(values)
astropy/visualization/interval.py:201:        values = self._process_values(values)
astropy/visualization/interval.py:259:            values = self._process_values(values)
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,130p' astropy/visualization/lupton_rgb.py; sed -n '500,790p' astropy/visualization/lupton_rgb.py; sed -n '1,220p' astropy/visualization/__init__.py; grep -R -n \"RGBImageMapping\" docs astropy --exclude='*.pyc' | head -80; grep -R -n \"ZScaleInterval\\|CompositeStretch\" docs --include='*.rst' | head -80"
```

退出码：`0`

输出：
```
# Licensed under a 3-clause BSD style license - see LICENSE.rst
"""
Combine 3 images to produce a properly-scaled RGB image following
Lupton et al. (2004).

The three images must be aligned and have the same pixel scale and size.

For details, see : https://ui.adsabs.harvard.edu/abs/2004PASP..116..133L
"""

import numpy as np

from astropy.visualization.interval import ManualInterval, ZScaleInterval
from astropy.visualization.stretch import BaseStretch


from .basic_rgb import RGBImageMapping

__all__ = [
    "AsinhMapping",
    "AsinhZScaleMapping",
    "LinearMapping",
    "LuptonAsinhStretch",
    "LuptonAsinhZscaleStretch",
    "Mapping",
    "make_lupton_rgb",
]


def compute_intensity(image_r, image_g=None, image_b=None):
    """
    Return a naive total intensity from the red, blue, and green intensities.

    Parameters
    ----------
    image_r : ndarray
        Intensity of image to be mapped to red; or total intensity if
        ``image_g`` and ``image_b`` are None.
    image_g : ndarray, optional
        Intensity of image to be mapped to green.
    image_b : ndarray, optional
        Intensity of image to be mapped to blue.

    Returns
    -------
    intensity : ndarray
        Total intensity from the red, blue and green intensities, or
        ``image_r`` if green and blue images are not provided.

    """
    if image_g is None or image_b is None:
        if not (image_g is None and image_b is None):
            raise ValueError(
                "please specify either a single image or red, green, and blue images."
            )
        return image_r

    intensity = (image_r + image_g + image_b) / 3.0

    # Repack into whatever type was passed to us
    return np.asarray(intensity, dtype=image_r.dtype)


class Mapping:
    """
    Baseclass to map red, blue, green intensities into uint8 values.

    Parameters
    ----------
    minimum : float or sequence(3)
        Intensity that should be mapped to black (a scalar or array for R, G, B).
    image : ndarray, optional
        An image used to calculate some parameters of some mappings.
    """

    def __init__(self, minimum=None, image=None):
        self._uint8Max = float(np.iinfo(np.uint8).max)

        try:
            len(minimum)
        except TypeError:
            minimum = 3 * [minimum]
        if len(minimum) != 3:
            raise ValueError("please provide 1 or 3 values for minimum.")

        self.minimum = minimum
        self._image = np.asarray(image)

    def make_rgb_image(self, image_r, image_g, image_b):
        """
        Convert 3 arrays, image_r, image_g, and image_b into an 8-bit RGB image.

        Parameters
        ----------
        image_r : ndarray
            Image to map to red.
        image_g : ndarray
            Image to map to green.
        image_b : ndarray
            Image to map to blue.

        Returns
        -------
        RGBimage : ndarray
            RGB (integer, 8-bits per channel) color image as an NxNx3 numpy array.
        """
        image_r = np.asarray(image_r)
        image_g = np.asarray(image_g)
        image_b = np.asarray(image_b)

        if (image_r.shape != image_g.shape) or (image_g.shape != image_b.shape):
            msg = "The image shapes must match. r: {}, g: {} b: {}"
            raise ValueError(msg.format(image_r.shape, image_g.shape, image_b.shape))

        return np.dstack(
            self._convert_images_to_uint8(image_r, image_g, image_b)
        ).astype(np.uint8)

    def intensity(self, image_r, image_g, image_b):
        """
        Return the total intensity from the red, blue, and green intensities.
        This is a naive computation, and may be overridden by subclasses.

        Parameters
        ----------
        image_r : ndarray
            Intensity of image to be mapped to red; or total intensity if
            ``image_g`` and ``image_b`` are None.
        image_g : ndarray, optional
            Intensity of image to be mapped to green.
            raise ValueError(
                "Input 'image' must be a single image "
                "or a stack/3xMxN array of 3 images! "
                f"{image.shape=}"
            )

        image = list(image)  # needs to be mutable

        if pedestal is not None:
            try:
                len(pedestal)
            except TypeError:
                pedestal = 3 * [pedestal]

            if len(pedestal) != 3:
                raise ValueError(
                    "pedestal must be 1 or 3 values, matching the image input."
                )
            for i, im in enumerate(image):
                if pedestal[i] != 0.0:
                    image[i] = im - pedestal[i]  # n.b. a copy

        image = compute_intensity(*image)
        zscale_limits = ZScaleInterval().get_limits(image)

        _stretch = zscale_limits[1] - zscale_limits[0]

        self._image = image

        super().__init__(stretch=_stretch, Q=Q)


class RGBImageMappingLupton(RGBImageMapping):
    """
    Class to map red, blue, green images into either a normalized float or
    an 8-bit image, by performing optional clipping and applying
    a scaling function to each band in non-independent manner that depends
    on the other bands, following the scaling scheme presented in
    Lupton et al. 2004.

    Parameters
    ----------
    interval : `~astropy.visualization.BaseInterval` subclass instance or array-like, optional
        The interval object to apply to the data (either a single instance or
        an array for R, G, B). Default is
        `~astropy.visualization.ManualInterval`.
    stretch : `~astropy.visualization.BaseStretch` subclass instance
        The stretch object to apply to the data. The default is
        `~astropy.visualization.AsinhLuptonStretch`.

    """

    def __init__(
        self,
        interval=ManualInterval(vmin=0, vmax=None),
        stretch=LuptonAsinhStretch(stretch=5, Q=8),
    ):
        super().__init__(interval=interval, stretch=stretch)
        self._pixmax = 1.0

    def intensity(self, image_r, image_g, image_b):
        """
        Return the total intensity from the red, blue, and green intensities.
        This is a naive computation, and may be overridden by subclasses.

        Parameters
        ----------
        image_r : ndarray
            Intensity of image to be mapped to red; or total intensity if
            ``image_g`` and ``image_b`` are None.
        image_g : ndarray, optional
            Intensity of image to be mapped to green.
        image_b : ndarray, optional
            Intensity of image to be mapped to blue.

        Returns
        -------
        intensity : ndarray
            Total intensity from the red, blue and green intensities, or
            ``image_r`` if green and blue images are not provided.

        """
        return compute_intensity(image_r, image_g, image_b)

    def apply_mappings(self, image_r, image_g, image_b):
        """
        Apply mapping stretch and intervals to convert images image_r, image_g,
        and image_b to a triplet of normalized images, following the scaling
        scheme presented in Lupton et al. 2004.

        Compared to astropy's ImageNormalize which first normalizes images
        by cropping and linearly mapping onto [0.,1.] and then applies
        a specified stretch algorithm, the Lupton et al. algorithm applies
        stretching to an multi-color intensity and then computes per-band
        scaled images with bound cropping.

        This is modified here by allowing for different minimum values
        for each of the input r, g, b images, and then computing
        the intensity on the subtracted images.

        Parameters
        ----------
        image_r : ndarray
            Intensity of image to be mapped to red
        image_g : ndarray
            Intensity of image to be mapped to green.
        image_b : ndarray
            Intensity of image to be mapped to blue.

        Returns
        -------
        image_rgb : ndarray
            Triplet of mapped images based on the specified (per-band)
            intervals and the stretch function

        Notes
        -----
        The Lupton et al 2004 algorithm is computed with the following steps:

        1. Shift each band with the minimum values
        2. Compute the intensity I and stretched intensity f(I)
        3. Compute the ratio of the stretched intensity to intensity f(I)/I,
        and clip to a lower bound of 0
        4. Compute the scaled band images by multiplying with the ratio f(I)/I
        5. Clip each band to a lower bound of 0
        6. Scale down pixels where max(R,G,B)>1 by the value max(R,G,B)

        """
        image_r = np.array(image_r, copy=True)
        image_g = np.array(image_g, copy=True)
        image_b = np.array(image_b, copy=True)

        # Subtract per-band minima
        image_rgb = [image_r, image_g, image_b]
        for i, img in enumerate(image_rgb):
            vmin, _ = self.intervals[i].get_limits(img)
            image_rgb[i] = np.subtract(img, vmin)

        image_rgb = np.asarray(image_rgb)

        # Determine the intensity and streteched intensity
        Int = self.intensity(*image_rgb)
        fI = self.stretch(Int, clip=False)

        # Get normalized fI, and clip to lower bound of 0:
        fInorm = np.where(Int <= 0, 0, np.true_divide(fI, Int))

        # Compute X = x * f(I) / I for each filter x=(r,g,b)
        np.multiply(image_rgb, fInorm, out=image_rgb)

        # Clip individual bands to minimum of 0, as
        # individual bands can be < 0 even if fI/I isn't.
        image_rgb = np.clip(image_rgb, 0.0, None)

        # Determine the max of all 3 bands at each position
        maxRGB = np.max(image_rgb, axis=0)

        with np.errstate(invalid="ignore", divide="ignore"):
            image_rgb = np.where(
                maxRGB > self._pixmax,
                np.true_divide(image_rgb * self._pixmax, maxRGB),
                image_rgb,
            )

        return np.asarray(image_rgb)


def make_lupton_rgb(
    image_r,
    image_g,
    image_b,
    interval=None,
    stretch_object=None,
    minimum=None,
    stretch=5,
    Q=8,
    filename=None,
    output_dtype=np.uint8,
):
    r"""
    Return a Red/Green/Blue color image from 3 images using interconnected
    band scaling, and an arbitrary stretch function (by default, an asinh stretch).
    The input images can be int or float, and in any range or bit-depth.

    For a more detailed look at the use of this method, see the document
    :ref:`astropy:astropy-visualization-rgb`.

    Parameters
    ----------
    image_r : ndarray
        Image to map to red.
    image_g : ndarray
        Image to map to green.
    image_b : ndarray
        Image to map to blue.
    interval : `~astropy.visualization.BaseInterval` subclass instance or array-like, optional
        The interval object to apply to the data (either a single instance or
        an array for R, G, B). Default is
        `~astropy.visualization.ManualInterval` with vmin=0.
    stretch_object : `~astropy.visualization.BaseStretch` subclass instance, optional
        The stretch object to apply to the data. If set, the input values of
        ``minimum``, ``stretch``, and ``Q`` will be ignored.
        For the Lupton scheme, this would be an instance of
        `~astropy.visualization.LuptonAsinhStretch`, but alternatively
        `~astropy.visualization.LuptonAsinhZscaleStretch` or some other
        stretch can be used.
    minimum : float or array-like, optional
        Deprecated. Intensity that should be mapped to black (a scalar or
        array of R, G, B). If `None`, each image's minimum value is used.
        Default is None.
    stretch : float, optional
        The linear stretch of the image. Default is 5
    Q : float, optional
        The asinh softening parameter. Default is 8.
    filename : str, optional
        Write the resulting RGB image to a file (file type determined
        from extension).
    output_dtype : numpy scalar type, optional
        Image output data type. Default is np.uint8.

    Returns
    -------
    rgb : ndarray
        RGB color image as an NxNx3 numpy array, with the specified
        data type format

    """
    if stretch_object is None:
        stretch_object = LuptonAsinhStretch(stretch=stretch, Q=Q)

    if interval is None:
        # Only use minimum if interval is not specified:
        if minimum is not None:
            # Backwards compatibility:
            try:
                len(minimum)
            except TypeError:
                minimum = 3 * [minimum]
            if len(minimum) != 3:
                raise ValueError("please provide 1 or 3 values for minimum.")
            interval = []
            for i in range(3):
                interval.append(ManualInterval(vmin=minimum[i], vmax=None))
        else:
            # Default option:
            interval = ManualInterval(vmin=0, vmax=None)

    lup_map = RGBImageMappingLupton(
        interval=interval,
        stretch=stretch_object,
    )
    rgb = lup_map.make_rgb_image(image_r, image_g, image_b, output_dtype=output_dtype)

    if filename:
        import matplotlib.image

        matplotlib.image.imsave(filename, rgb, origin="lower")

    return rgb
# Licensed under a 3-clause BSD style license - see LICENSE.rst

from .basic_rgb import *
from .hist import *
from .interval import *
from .lupton_rgb import LuptonAsinhStretch, LuptonAsinhZscaleStretch, make_lupton_rgb
from .mpl_normalize import *
from .mpl_style import *
from .stretch import *
from .time import *
from .transform import *
from .units import *
astropy/visualization/basic_rgb.py:18:class RGBImageMapping:
astropy/visualization/basic_rgb.py:209:    map_ = RGBImageMapping(interval=interval, stretch=stretch)
astropy/visualization/tests/test_lupton_rgb.py:128:        asinh_map = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:158:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:174:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:189:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:205:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:223:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/tests/test_lupton_rgb.py:308:        map_ = lupton_rgb.RGBImageMappingLupton(
astropy/visualization/lupton_rgb.py:17:from .basic_rgb import RGBImageMapping
astropy/visualization/lupton_rgb.py:532:class RGBImageMappingLupton(RGBImageMapping):
astropy/visualization/lupton_rgb.py:747:    lup_map = RGBImageMappingLupton(
docs/visualization/normalization.rst:126::class:`~astropy.visualization.ZScaleInterval`. For these, values in
docs/visualization/normalization.rst:310:The resulting :class:`~astropy.visualization.stretch.CompositeStretch` can be
```

## 原始行 25 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"get_data_and_mask\" astropy --include='*.py' | head -40; grep -n \"def get_data_and_mask\" -n astropy/utils/masked/function_helpers.py astropy/utils/masked/core.py astropy/utils/masked/*.py; sed -n '120,230p' astropy/visualization/tests/test_lupton_rgb.py; sed -n '300,360p' astropy/visualization/tests/test_lupton_rgb.py; grep -n \"def __call__\" astropy/visualization/stretch.py"
```

退出码：`0`

输出：
```
astropy/time/core.py:38:    get_data_and_mask,
astropy/time/core.py:554:        data1, mask1 = get_data_and_mask(val)
astropy/time/core.py:555:        data2, mask2 = get_data_and_mask(val2)
astropy/timeseries/downsample.py:13:from astropy.utils.masked import Masked, get_data_and_mask
astropy/timeseries/downsample.py:26:    unmasked, data_mask = get_data_and_mask(data)
astropy/timeseries/tests/test_downsample.py:20:from astropy.utils.masked import Masked, get_data_and_mask
astropy/timeseries/tests/test_downsample.py:35:    a_data, a_mask = get_data_and_mask(a)
astropy/timeseries/tests/test_downsample.py:36:    b_data, b_mask = get_data_and_mask(b)
astropy/visualization/interval.py:12:from astropy.utils.masked import get_data_and_mask
astropy/utils/masked/core.py:41:    "get_data_and_mask",
astropy/utils/masked/core.py:52:def get_data_and_mask(array):
astropy/utils/masked/core.py:225:        data, data_mask = get_data_and_mask(data)
astropy/utils/masked/core.py:357:            unmasked, mask = get_data_and_mask(value)
astropy/utils/masked/core.py:518:        other_data, other_mask = get_data_and_mask(other)
astropy/utils/masked/core.py:571:            unmasked, mask = get_data_and_mask(value)
astropy/utils/masked/core.py:798:    def _get_data_and_masks(arrays):
astropy/utils/masked/core.py:812:        data_masks = [get_data_and_mask(array) for array in arrays]
astropy/utils/masked/core.py:817:        unmasked, masks = self._get_data_and_masks(inputs)
astropy/utils/masked/core.py:825:            out_unmasked, out_masks = self._get_data_and_masks(out)
astropy/utils/masked/core.py:842:            where_unmasked, where_mask = get_data_and_mask(where)
astropy/utils/masked/core.py:1098:            return self.from_unmasked(*get_data_and_mask(obj))
astropy/utils/masked/core.py:1270:        dmin, mmin = get_data_and_mask(min)
astropy/utils/masked/core.py:1271:        dmax, mmax = get_data_and_mask(max)
astropy/utils/masked/function_helpers.py:200:def _get_data_and_mask_array(array):
astropy/utils/masked/function_helpers.py:201:    """Like get_data_and_mask, but always returns a mask array."""
astropy/utils/masked/function_helpers.py:202:    from .core import get_data_and_mask
astropy/utils/masked/function_helpers.py:204:    data, mask = get_data_and_mask(array)
astropy/utils/masked/function_helpers.py:210:def _get_data_and_mask_arrays(arrays):
astropy/utils/masked/function_helpers.py:215:    return tuple(zip(*[_get_data_and_mask_array(array) for array in arrays]))
astropy/utils/masked/function_helpers.py:258:    data, mask = _get_data_and_mask_array(a)
astropy/utils/masked/function_helpers.py:264:    data, mask = _get_data_and_mask_array(m)
astropy/utils/masked/function_helpers.py:270:    data, mask = _get_data_and_mask_array(v)
astropy/utils/masked/function_helpers.py:276:    data, mask = _get_data_and_mask_array(array)
astropy/utils/masked/function_helpers.py:289:    data, mask = _get_data_and_mask_array(array)
astropy/utils/masked/function_helpers.py:474:    from astropy.utils.masked import Masked, get_data_and_mask
astropy/utils/masked/function_helpers.py:482:        v_data, v_mask = get_data_and_mask(v)
astropy/utils/masked/function_helpers.py:494:    from astropy.utils.masked import Masked, get_data_and_mask
astropy/utils/masked/function_helpers.py:502:        values_data, values_mask = get_data_and_mask(values)
astropy/utils/masked/function_helpers.py:526:    from astropy.utils.masked import Masked, get_data_and_mask
astropy/utils/masked/function_helpers.py:534:        vals_data, vals_mask = get_data_and_mask(vals)
astropy/utils/masked/core.py:52:def get_data_and_mask(array):
astropy/utils/masked/core.py:52:def get_data_and_mask(array):
        psf = Gaussian2DKernel(2.5)
        self.image_r = convolve_with_noise(image_r, psf)
        self.image_g = convolve_with_noise(image_g, psf)
        self.image_b = convolve_with_noise(image_b, psf)

    def test_Asinh(self):
        """Test creating an RGB image using an asinh stretch"""

        asinh_map = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhStretch(self.stretch_, self.Q),
        )
        rgb_image = asinh_map.make_rgb_image(self.image_r, self.image_g, self.image_b)

        if display:
            display_rgb(rgb_image, title=sys._getframe().f_code.co_name)

    def test_Asinh_incorrect_stretch_asserts(self):
        with pytest.raises(ValueError, match=r"Stretch must be non-negative"):
            _ = lupton_rgb.LuptonAsinhStretch(-1.0, self.Q)

    def test_Asinh_incorrect_Q_asserts(self):
        with pytest.raises(ValueError, match=r"Q must be non-negative"):
            _ = lupton_rgb.LuptonAsinhStretch(self.stretch_, -1.0)

    def test_Asinh_Q_machine_floor(self):
        asinh_map = lupton_rgb.LuptonAsinhStretch(self.stretch_, 1.0e-24)
        assert_allclose(asinh_map.Q, 0.1)

    def test_Asinh_Q_ceil(self):
        asinh_map = lupton_rgb.LuptonAsinhStretch(self.stretch_, 1e11)
        assert_allclose(asinh_map.Q, 1e10)

    def test_AsinhZscale(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                [self.image_r, self.image_g, self.image_b], self.Q
            ),
        )
        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)

        if display:
            display_rgb(rgb_image, title=sys._getframe().f_code.co_name)

    def test_AsinhZscaleIntensity(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale on the intensity
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                lupton_rgb.compute_intensity(self.image_r, self.image_g, self.image_b),
                self.Q,
            ),
        )
        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)

        if display:
            display_rgb(rgb_image, title=sys._getframe().f_code.co_name)

    def test_AsinhZscaleIntensityBW(self):
        """Test creating a black-and-white image using an asinh stretch
        estimated using zscale on the intensity"""
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                self.image_r,
                self.Q,
            ),
        )
        rgb_image = map_.make_rgb_image(self.image_r, self.image_r, self.image_r)
        if display:
            display_rgb(rgb_image, title=sys._getframe().f_code.co_name)

    def test_AsinhZscale_pedestal_array(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                [self.image_r, self.image_g, self.image_b],
                self.Q,
                pedestal=[1.0, 1.0, 2.0],
            ),
        )
        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)

        if display:
            display_rgb(rgb_image, title=sys._getframe().f_code.co_name)

    def test_AsinhZscale_pedestal_float(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                [self.image_r, self.image_g, self.image_b],
                self.Q,
                pedestal=1.0,
            ),
        )
            saturated_border_width=1,
            saturated_pixel_value=2000,
            filename=temp,
        )

    def test_linear(self):
        """Test using a specified linear stretch"""

        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=LinearStretch(-8.45, 13.44),
        )
        rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
        if display:
            display_rgb(rgb_image, title=sys._getframe().f_code.co_name)

    def test_saturated(self):
        """Test interpolationolating saturated pixels"""
        pytest.skip("replaceSaturatedPixels is not implemented in astropy yet")

        satValue = 1000.0
        self.image_r = saturate(self.image_r, satValue)
        self.image_g = saturate(self.image_g, satValue)
        self.image_b = saturate(self.image_b, satValue)

        lupton_rgb.replaceSaturatedPixels(
            self.image_r, self.image_g, self.image_b, 1, 2000
        )
        # Check that we replaced those NaNs with some reasonable value
        assert np.isfinite(self.image_r.getImage().getArray()).all()
        assert np.isfinite(self.image_g.getImage().getArray()).all()
        assert np.isfinite(self.image_b.getImage().getArray()).all()

        # Prepare for generating an output file
        self.imagesR = self.imagesR.getImage()
        self.imagesR = self.imagesG.getImage()
        self.imagesR = self.imagesB.getImage()

        asinhMap = lupton_rgb.AsinhMapping(self.min_, self.stretch_, self.Q)
        rgb_image = asinhMap.make_rgb_image(self.image_r, self.image_g, self.image_b)
        if display:
            display_rgb(rgb_image, title=sys._getframe().f_code.co_name)

    def test_different_shapes_asserts(self):
        with pytest.raises(ValueError, match=r"shapes must match"):
            # just swap the dimensions to get a differently-shaped 'r'
            image_r = self.image_r.reshape(self.height, self.width)
            lupton_rgb.make_lupton_rgb(image_r, self.image_g, self.image_b)

    def test_incorrect_input_compute_intensity_asserts(self):
        with pytest.raises(ValueError, match=r"specify either a single image"):
            lupton_rgb.compute_intensity(self.image_r, self.image_g)
69:    def __call__(self, values, clip=True, out=None):
146:    def __call__(self, values, clip=True, out=None):
201:    def __call__(self, values, clip=True, out=None, invalid=None):
303:    def __call__(self, values, clip=True, out=None, invalid=None):
410:    def __call__(self, values, clip=True, out=None):
449:    def __call__(self, values, clip=True, out=None):
562:    def __call__(self, values, clip=True, out=None, invalid=None):
638:    def __call__(self, values, clip=True, out=None):
709:    def __call__(self, values, clip=True, out=None):
777:    def __call__(self, values, clip=True, out=None):
817:    def __call__(self, values, clip=True, out=None):
848:    def __call__(self, values, clip=True, out=None):
911:    def __call__(self, values, clip=True, out=None):
957:    def __call__(self, values, clip=True, out=None):
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "sed -n '45,80p' astropy/utils/masked/core.py; sed -n '180,340p' astropy/visualization/stretch.py; sed -n '390,480p' astropy/visualization/stretch.py; sed -n '540,730p' astropy/visualization/stretch.py; sed -n '760,930p' astropy/visualization/stretch.py"
```

退出码：`0`

输出：
```
get__doc__ = """Masked version of {0.__name__}.

Except for the ability to pass in a ``mask``, parameters are
as for `{0.__module__}.{0.__name__}`.
""".format


def get_data_and_mask(array):
    """Split possibly masked array into unmasked and mask.

    Parameters
    ----------
    array : array-like
        Possibly masked item, judged by whether it has a ``mask`` attribute.
        If so, checks for having an ``unmasked`` attribute (as expected for
        instances of `~astropy.utils.masked.Masked`), or uses the ``_data``
        attribute if the inpuit is an instance of `~numpy.ma.MaskedArray`.

    Returns
    -------
    unmasked, mask : array-like
        If the input array had no mask, this will be ``array, None``.

    Raises
    ------
    AttributeError
        If ``array`` has a ``mask`` but not an ``unmasked`` attribute, and
        is not an instance of `~numpy.ma.MaskedArray`.
    ValueError
        If ``array`` is ``np.ma.masked`` (since it has no data).

    """
    mask = getattr(array, "mask", None)
    if mask is None:
        return array, None

        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 5))

        x = np.linspace(0, 1, 100)
        stretch = SqrtStretch()
        ax.plot(x, stretch(x, clip=True))

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
    """

    @property
    def _supports_invalid_kw(self):
        return True

    def __call__(self, values, clip=True, out=None, invalid=None):
        """
        Transform values using this stretch.

        Parameters
        ----------
        values : array-like
            The input values, which should already be normalized to the
            [0:1] range.
        clip : bool, optional
            If `True` (default), values outside the [0:1] range are
            clipped to the [0:1] range.
        out : ndarray, optional
            If specified, the output values will be placed in this array
            (typically used for in-place calculations).
        invalid : None or float, optional
            Value to assign NaN values generated by this class.  NaNs in
            the input ``values`` array are not changed.  This option is
            generally used with matplotlib normalization classes, where
            the ``invalid`` value should map to the matplotlib colormap
            "under" value (i.e., any finite value < 0).  If `None`, then
            NaN values are not replaced.  This keyword has no effect if
            ``clip=True``.

        Returns
        -------
        result : ndarray
            The transformed values.
        """
        values = _prepare(values, clip=clip, out=out)
        replace_invalid = not clip and invalid is not None
        with np.errstate(invalid="ignore"):
            if replace_invalid:
                idx = values < 0
            np.sqrt(values, out=values)

        if replace_invalid:
            # Assign new NaN (i.e., NaN not in the original input
            # values, but generated by this class) to the invalid value.
            values[idx] = invalid

        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return PowerStretch(2)


class PowerStretch(BaseStretch):
    r"""
    A power stretch.

    The stretch is given by:

    .. math::
        y = x^a

    Parameters
    ----------
    a : float
        The power index (see the above formula). ``a`` must be greater
        than 0.

    Examples
    --------
    .. plot::
        :show-source-link:

        import numpy as np
        from astropy.visualization import PowerStretch
        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 5))

        x = np.linspace(0, 1, 100)
        a_vals = (0.3, 0.5, 0.7, 1, 1.5, 2, 3)
        for a in a_vals:
            stretch = PowerStretch(a)
            label = f'{a=}'
            ax.plot(x, stretch(x, clip=True), label=label)

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='lower right', fontsize=8)
    """

    @property
    def _supports_invalid_kw(self):
        return True

    def __init__(self, a):
        super().__init__()
        if a <= 0:
            raise ValueError("a must be > 0")
        self.a = a

    def __call__(self, values, clip=True, out=None, invalid=None):
        """
        Transform values using this stretch.

        Parameters
        ----------
        values : array-like
            The input values, which should already be normalized to the
            [0:1] range.
        clip : bool, optional
            If `True` (default), values outside the [0:1] range are
            clipped to the [0:1] range.
        out : ndarray, optional
            If specified, the output values will be placed in this array
            (typically used for in-place calculations).
        invalid : None or float, optional
            Value to assign NaN values generated by this class.  NaNs in
            the input ``values`` array are not changed.  This option is
            generally used with matplotlib normalization classes, where
            the ``invalid`` value should map to the matplotlib colormap
            "under" value (i.e., any finite value < 0).  If `None`, then
            NaN values are not replaced.  This keyword has no effect if
            ``clip=True``.

        Returns
        -------
        result : ndarray
            The transformed values.
        """
        values = _prepare(values, clip=clip, out=out)
        replace_invalid = (
            not clip and invalid is not None and ((-1 < self.a < 0) or (0 < self.a < 1))
        )
        with np.errstate(invalid="ignore"):
            if replace_invalid:
                idx = values < 0
            np.power(values, self.a, out=values)

            stretch = PowerDistStretch(a)
            label = f'{a=}'
            ax.plot(x, stretch(x, clip=True), label=label, lw=lw)

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='upper left', fontsize=8)
    """

    def __init__(self, a=1000.0):
        if a <= 0 or a == 1:  # singularity
            raise ValueError("a must be > 0, but cannot be set to 1")
        super().__init__()
        self.a = a

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        np.power(self.a, values, out=values)
        np.subtract(values, 1, out=values)
        np.true_divide(values, self.a - 1.0, out=values)
        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return InvertedPowerDistStretch(a=self.a)


class InvertedPowerDistStretch(BaseStretch):
    r"""
    Inverse transformation for
    `~astropy.visualization.PowerDistStretch`.

    The stretch is given by:

    .. math::
        y = \frac{\log(x (a - 1) + 1)}{\log a}

    Parameters
    ----------
    a : float, optional
        The ``a`` parameter used in the above formula. The stretch
        becomes more linear as ``a`` approaches 1, more logarithmic for
        ``a`` values greater than 1, and more exponential for ``a``
        values less than 1. ``a`` must be greater than 0, but cannot be
        set to 1. Default is 1000.
    """

    def __init__(self, a=1000.0):
        if a <= 0 or a == 1:  # singularity
            raise ValueError("a must be > 0, but cannot be set to 1")
        super().__init__()
        self.a = a

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        np.multiply(values, self.a - 1.0, out=values)
        np.add(values, 1, out=values)
        _logn(self.a, values, out=values)
        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return PowerDistStretch(a=self.a)


class SquaredStretch(PowerStretch):
    r"""
    A convenience class for a power stretch of 2.

    The stretch is given by:

    .. math::
        y = x^2

    Examples
    --------
    .. plot::
        :show-source-link:

        import numpy as np
        from astropy.visualization import SquaredStretch
        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 5))
            ax.plot(x, stretch(x, clip=True), label=label, lw=lw)

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='lower right', fontsize=8)
    """

    @property
    def _supports_invalid_kw(self):
        return True

    def __init__(self, a=1000.0):
        super().__init__()
        if a <= 0:  # singularity
            raise ValueError("a must be > 0")
        self.a = a

    def __call__(self, values, clip=True, out=None, invalid=None):
        """
        Transform values using this stretch.

        Parameters
        ----------
        values : array-like
            The input values, which should already be normalized to the
            [0:1] range.
        clip : bool, optional
            If `True` (default), values outside the [0:1] range are
            clipped to the [0:1] range.
        out : ndarray, optional
            If specified, the output values will be placed in this array
            (typically used for in-place calculations).
        invalid : None or float, optional
            Value to assign NaN values generated by this class.  NaNs in
            the input ``values`` array are not changed.  This option is
            generally used with matplotlib normalization classes, where
            the ``invalid`` value should map to the matplotlib colormap
            "under" value (i.e., any finite value < 0).  If `None`, then
            NaN values are not replaced.  This keyword has no effect if
            ``clip=True``.

        Returns
        -------
        result : ndarray
            The transformed values.
        """
        values = _prepare(values, clip=clip, out=out)
        replace_invalid = not clip and invalid is not None
        with np.errstate(invalid="ignore"):
            if replace_invalid:
                idx = values < 0
            np.multiply(values, self.a, out=values)
            np.add(values, 1.0, out=values)
            np.log(values, out=values)
            np.true_divide(values, np.log(self.a + 1.0), out=values)

        if replace_invalid:
            # Assign new NaN (i.e., NaN not in the original input
            # values, but generated by this class) to the invalid value.
            values[idx] = invalid

        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return InvertedLogStretch(self.a)


class InvertedLogStretch(BaseStretch):
    r"""
    Inverse transformation for `~astropy.visualization.LogStretch`.

    The stretch is given by:

    .. math::
        y = \frac{e^{x \log{a + 1}} - 1}{a} = \frac{(a + 1)^x - 1}{a}

    Parameters
    ----------
    a : float, optional
        The ``a`` parameter used in the above formula. The stretch
        becomes more linear for small ``a`` values and more exponential
        for large ``a`` values. ``a`` must be greater than 0. Default is
        1000.
    """

    def __init__(self, a):
        super().__init__()
        if a <= 0:  # singularity
            raise ValueError("a must be > 0")
        self.a = a

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        np.multiply(values, np.log(self.a + 1.0), out=values)
        np.exp(values, out=values)
        np.subtract(values, 1.0, out=values)
        np.true_divide(values, self.a, out=values)
        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return LogStretch(self.a)


class AsinhStretch(BaseStretch):
    r"""
    An asinh stretch.

    The stretch is given by:

    .. math::
        y = \frac{{\rm asinh}(x / a)}{{\rm asinh}(1 / a)}.

    Parameters
    ----------
    a : float, optional
        The ``a`` parameter used in the above formula. The value of this
        parameter is where the asinh curve transitions from linear to
        logarithmic behavior, expressed as a fraction of the normalized
        image. The stretch becomes more linear for larger ``a`` values
        and more logarithmic for smaller ``a`` values. ``a`` must be
        greater than 0. Default is 0.1.

    Examples
    --------
    .. plot::
        :show-source-link:

        import numpy as np
        from astropy.visualization import AsinhStretch
        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 5))

        x = np.linspace(0, 1, 100)
        a_vals = (0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 0.9, 3.0)
        for a in a_vals:
            if a == 0.1:
                lw = 3
            else:
                lw = 1
            stretch = AsinhStretch(a)
            label = f'{a=}'
            ax.plot(x, stretch(x, clip=True), label=label, lw=lw)

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='lower right', fontsize=8)
    """

    def __init__(self, a=0.1):
        super().__init__()
        if a <= 0:
            raise ValueError("a must be > 0")
        self.a = a

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        np.true_divide(values, self.a, out=values)
        np.arcsinh(values, out=values)
        np.true_divide(values, np.arcsinh(1.0 / self.a), out=values)
        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return SinhStretch(a=1.0 / np.arcsinh(1.0 / self.a))


class SinhStretch(BaseStretch):
    r"""
    A sinh stretch.

    The stretch is given by:

    .. math::
        y = \frac{{\rm sinh}(x / a)}{{\rm sinh}(1 / a)}


        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='upper left', fontsize=8)
    """

    def __init__(self, a=1.0 / 3.0):
        super().__init__()
        if a <= 0:
            raise ValueError("a must be > 0")
        self.a = a

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        np.true_divide(values, self.a, out=values)
        np.sinh(values, out=values)
        np.true_divide(values, np.sinh(1.0 / self.a), out=values)
        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return AsinhStretch(a=1.0 / np.sinh(1.0 / self.a))


class HistEqStretch(BaseStretch):
    """
    A histogram equalization stretch.

    Parameters
    ----------
    data : array-like
        The data defining the equalization.
    values : array-like, optional
        The input image values, which should already be normalized to
        the [0:1] range.
    """

    def __init__(self, data, values=None):
        # Assume data is not necessarily normalized at this point
        self.data = np.sort(data.ravel())
        self.data = self.data[np.isfinite(self.data)]
        vmin = self.data.min()
        vmax = self.data.max()
        self.data = (self.data - vmin) / (vmax - vmin)

        # Compute relative position of each pixel
        if values is None:
            self.values = np.linspace(0.0, 1.0, len(self.data))
        else:
            self.values = values

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        values[:] = np.interp(values, self.data, self.values)
        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return InvertedHistEqStretch(self.data, values=self.values)


class InvertedHistEqStretch(BaseStretch):
    """
    Inverse transformation for `~astropy.visualization.HistEqStretch`.

    Parameters
    ----------
    data : array-like
        The data defining the equalization.
    values : array-like, optional
        The input image values, which should already be normalized to
        the [0:1] range.
    """

    def __init__(self, data, values=None):
        self.data = data[np.isfinite(data)]
        if values is None:
            self.values = np.linspace(0.0, 1.0, len(self.data))
        else:
            self.values = values

    def __call__(self, values, clip=True, out=None):
        values = _prepare(values, clip=clip, out=out)
        values[:] = np.interp(values, self.values, self.data)
        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return HistEqStretch(self.data, values=self.values)


class ContrastBiasStretch(BaseStretch):
    r"""
    A stretch that takes into account contrast and bias.

    The stretch is given by:

    .. math::
        y = (x - {\rm bias}) * {\rm contrast} + 0.5

    and the output values are clipped to the [0:1] range.

    Parameters
    ----------
    contrast : float
        The contrast parameter (see the above formula).

    bias : float
        The bias parameter (see the above formula).

    Examples
    --------
    .. plot::
        :show-source-link:

        import numpy as np
        from astropy.visualization import ContrastBiasStretch
        from matplotlib import pyplot as plt

        fig, ax = plt.subplots(figsize=(5, 5))

        x = np.linspace(0, 1, 100)
        contrasts = [1.0, 2.0, 0.7, 1.0, 1.0, 2.0]
        biases = [0.5, 0.5, 0.5, 0.3, 0.7, 0.3]
        for contrast, bias in zip(contrasts, biases):
            stretch = ContrastBiasStretch(contrast, bias)
            ax.plot(x, stretch(x, clip=True), label=f'{contrast=}, {bias=}')

        ax.axis('equal')
        ax.plot(x, x, ls='dotted', color='k', alpha=0.3)
        ax.set_xlim(0, 1)
        ax.set_ylim(0, 1)
        ax.set_xlabel('Input Value')
        ax.set_ylabel('Output Value')
        ax.set_title(stretch.__class__.__name__)
        ax.legend(loc='lower right', fontsize=8)
    """

    def __init__(self, contrast, bias):
        super().__init__()
        self.contrast = contrast
        self.bias = bias

    def __call__(self, values, clip=True, out=None):
        # As a special case here, we only clip *after* the
        # transformation since it does not map [0:1] to [0:1]
        values = _prepare(values, clip=False, out=out)

        np.subtract(values, self.bias, out=values)
        np.multiply(values, self.contrast, out=values)
        np.add(values, 0.5, out=values)

        if clip:
            np.clip(values, 0, 1, out=values)

        return values

    @property
    def inverse(self):
        """A stretch object that performs the inverse operation."""
        return InvertedContrastBiasStretch(self.contrast, self.bias)
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"n_samples.*ZScale\\|zscale\\|ZScale\" CHANGES.rst docs astropy --exclude='interval.py' --exclude='*.pyc' | head -150; find . -name 'test_basic_rgb*' -o -name '*visualization*rgb*' | head -50; sed -n '70,105p' astropy/utils/masked/core.py"
```

退出码：`0`

输出：
```
CHANGES.rst:681:  - ``AsinhZScaleMapping`` [#17531]
CHANGES.rst:1174:- The deprecated ``nsamples`` parameter of ``ZScaleInterval`` is removed. [#17186]
CHANGES.rst:3685:- Rename number-of-samples keyword ``nsamples`` in ``ZScaleInterval`` to align
CHANGES.rst:7360:- Fix bug in ``ZScaleInterval`` to return the array minimum and
CHANGES.rst:12796:- Add zscale interval based on Numdisplay's implementation. [#4776]
docs/visualization/normalization.rst:126::class:`~astropy.visualization.ZScaleInterval`. For these, values in
astropy/visualization/tests/test_interval.py:15:    ZScaleInterval,
astropy/visualization/tests/test_interval.py:125:def test_zscale():
astropy/visualization/tests/test_interval.py:128:    interval = ZScaleInterval()
astropy/visualization/tests/test_interval.py:134:    interval = ZScaleInterval()
astropy/visualization/tests/test_interval.py:140:    interval = ZScaleInterval()
astropy/visualization/tests/test_interval.py:146:def test_zscale_npoints():
astropy/visualization/tests/test_interval.py:148:    Regression test to ensure ZScaleInterval returns the minimum and
astropy/visualization/tests/test_interval.py:154:    interval = ZScaleInterval(min_npixels=5)
astropy/visualization/tests/test_lupton_rgb.py:156:        using zscale
astropy/visualization/tests/test_lupton_rgb.py:172:        using zscale on the intensity
astropy/visualization/tests/test_lupton_rgb.py:188:        estimated using zscale on the intensity"""
astropy/visualization/tests/test_lupton_rgb.py:203:        using zscale
astropy/visualization/tests/test_lupton_rgb.py:221:        using zscale
astropy/visualization/tests/test_lupton_rgb.py:239:        using zscale
astropy/visualization/lupton_rgb.py:13:from astropy.visualization.interval import ManualInterval, ZScaleInterval
astropy/visualization/lupton_rgb.py:21:    "AsinhZScaleMapping",
astropy/visualization/lupton_rgb.py:298:class AsinhZScaleMapping(AsinhMapping):
astropy/visualization/lupton_rgb.py:300:    A mapping for an asinh stretch, estimating the linear stretch by zscale.
astropy/visualization/lupton_rgb.py:321:    zscale stretch, and added back into Mapping.minimum[]
astropy/visualization/lupton_rgb.py:352:        zscale_limits = ZScaleInterval().get_limits(image)
astropy/visualization/lupton_rgb.py:353:        zscale = LinearMapping(*zscale_limits, image=image)
astropy/visualization/lupton_rgb.py:354:        # zscale.minimum is always a triple
astropy/visualization/lupton_rgb.py:355:        stretch = zscale.maximum - zscale.minimum[0]
astropy/visualization/lupton_rgb.py:356:        minimum = zscale.minimum
astropy/visualization/lupton_rgb.py:460:    zscale.
astropy/visualization/lupton_rgb.py:523:        zscale_limits = ZScaleInterval().get_limits(image)
astropy/visualization/lupton_rgb.py:525:        _stretch = zscale_limits[1] - zscale_limits[0]
astropy/io/fits/hdu/compressed/_tiled_compression.py:352:        zscale_column = np.array(compressed_data["ZSCALE"])
astropy/io/fits/hdu/compressed/_tiled_compression.py:354:        zscale_column = None
astropy/io/fits/hdu/compressed/_tiled_compression.py:460:                        tile_data, zscale_column[row_index], zzero_column[row_index]
    AttributeError
        If ``array`` has a ``mask`` but not an ``unmasked`` attribute, and
        is not an instance of `~numpy.ma.MaskedArray`.
    ValueError
        If ``array`` is ``np.ma.masked`` (since it has no data).

    """
    mask = getattr(array, "mask", None)
    if mask is None:
        return array, None

    try:
        return array.unmasked, mask
    except AttributeError as exc:
        if not isinstance(array, np.ma.MaskedArray):
            raise AttributeError(
                f"'{type(array).__name__}' object has a 'mask' attribute but not an "
                "'unmasked' attribute (and is not an np.ma.MaskedArray instance)."
            ) from None

    if array is np.ma.masked:
        raise ValueError("cannot handle np.ma.masked.")

    # We use the private _data attribute here since MaskedColumn
    # overrides the normal ".data".
    return array._data, mask


def combine_masks(masks, *, out=None, where=True, copy=True):
    """Combine masks, possibly storing it in some output.

    Parameters
    ----------
    masks : tuple of array of bool or False or None
        Input masks.  Any that are `None` or `False` are ignored.
        Should broadcast to each other.  For structured dtype,
```

## 原始行 35 · command_execution

命令：
```
/bin/bash -lc "sed -n '660,700p' CHANGES.rst; sed -n '1155,1185p' CHANGES.rst; sed -n '3665,3700p' CHANGES.rst; sed -n '7345,7370p' CHANGES.rst; grep -n \"RGB\" CHANGES.rst | head -50"
```

退出码：`0`

输出：
````
- Ensure that ``Unit.to`` allows as ``value`` argument all array types that
  follow the array API standard and define ``__array_namespace__``. Furthermore,
  for backwards compatibility, generally pass through arguments that define a
  ``.dtype``, independent of whether that is a numpy data type. [#17469]

- The zebi (Zi, 2^70) and yobi (Yi, 2^80) binary prefixes are now supported. [#17692]

astropy.visualization
^^^^^^^^^^^^^^^^^^^^^

- Fix ``CoordinateHelper.ticklabels``. The getter was incorrectly returning
  the helper's ticks rather than the labels. [#17444]

- The following private classes from ``astropy.visualization.lupton_rgb``, that
  were dropped without deprecation in astropy 7.0.0, were re-introduced following
  a report that they were used downstream. The following classes are now
  considered public:

  - ``Mapping``
  - ``AsinhMapping``
  - ``LinearMapping``
  - ``AsinhZScaleMapping`` [#17531]

Other Changes and Additions
---------------------------

- Update bundled js library datatables to version 2.1.8, which is current at the time of this PR. [#17480]

Version 7.0.0 (2024-11-21)
==========================


New Features
------------

astropy.config
^^^^^^^^^^^^^^

- Added ``get_config_dir_path`` (and ``get_cache_dir_path``) which is equivalent
  to ``get_config_dir`` (respectively ``get_cache_dir``) except that it returns a
  ``pathlib.Path`` object instead of ``str``. [#17118]
  * ``parent_axes``
  * ``parent_map``
  * ``transform``
  * ``coord_index``
  * ``coord_unit``
  * ``coord_type`` (use ``set_coord_type`` instead)
  * ``coord_wrap`` (use ``set_coord_type`` instead)
  * ``frame``
  * ``default_label``

  Accessing or setting the following attributes on ``CoordinateHelper`` has been
  removed (without deprecation, as these were clearly internal variables):

  * ``grid_lines_kwargs``
  * ``grid_lines``
  * ``lblinfo``
  * ``lbl_world``
  * ``minor_frequency`` (there were already public methods to set/get this) [#16685]

- The deprecated ``nsamples`` parameter of ``ZScaleInterval`` is removed. [#17186]

astropy.wcs
^^^^^^^^^^^

- Errors may now occur if a ``BaseLowLevelWCS`` class defines
  ``world_axis_object_components`` which returns values that are not scalars or
  plain Numpy arrays as per APE 14. [#16287]

- ``WCS.pixel_to_world_values``, ``WCS.world_to_pixel_values``,
  ``WCS.pixel_to_world`` and ``WCS.world_to_pixel`` now correctly return NaN values for
  pixel positions that are outside of ``pixel_bounds``. [#16328]
  shared if the quantity has integer ```dtype``` or is structured, or when the
  conversion is through an equivalency. [#13638]

- When ``Quantity`` is constructed from a structured array and ``unit`` is
  ``None``, the default unit is now structured like the input data. [#13676]

astropy.utils
^^^^^^^^^^^^^

- ``astropy.utils.misc.suppress`` has been removed, use ``contextlib.suppress``
  instead. ``astropy.utils.namedtuple_asdict`` has been removed, instead use
  method ``._asdict`` on a ``namedtuple``. ``override__dir__`` has been deprecated
  and will be removed in a future version, see the docstring for the better
  alternative. [#13636]

- ``astropy.utils.misc.possible_filename`` has been removed. [#13661]

astropy.visualization
^^^^^^^^^^^^^^^^^^^^^

- Rename number-of-samples keyword ``nsamples`` in ``ZScaleInterval`` to align
  with the ``n_samples`` keyword used in all other ``Interval`` classes in
  this module. [#13810]


Bug Fixes
---------

astropy.convolution
^^^^^^^^^^^^^^^^^^^

- Fixed convolution Kernels to ensure the that returned kernels
  are normalized to sum to one (e.g., ``Gaussian1DKernel``,
  ``Gaussian2DKernel``). Also fixed the Kernel ``truncation`` calculation. [#13299]

- Fix import error with setuptools v65.6.0 by replacing
- Fixed ``deprecated_renamed_argument`` not passing in user value to
  deprecated keyword when the keyword has no new name. [#9981]

- Fixed ``deprecated_renamed_argument`` not issuing a deprecation warning when
  deprecated keyword without new name is passed in as positional argument.
  [#9985]

- Fixed detection of read-only filesystems in the caching code. [#10007]

astropy.visualization
^^^^^^^^^^^^^^^^^^^^^

- Fixed bug from matplotlib >=3.1 where an empty Quantity array is
  sent for unit conversion as an empty list. [#9848]

- Fix bug in ``ZScaleInterval`` to return the array minimum and
  maximum when there are less then ``min_npixels`` in the input array. [#9913]

- Fix a bug in simplifying axis labels that affected non-rectangular frames.
  [#8004, #9991]


Other Changes and Additions
---------------------------

- Increase minimum asdf version to 2.5.2. [#9996, #9819]
833:  function for creating RGB images with independent scaling on each filter.
````

## 原始行 37 · command_execution

命令：
```
/bin/bash -lc "sed -n '810,850p' CHANGES.rst; grep -R -n \"make_rgb(\" docs --include='*.rst' | head -30; grep -R -n \"output_dtype\" docs --include='*.rst' | head -30"
```

退出码：`0`

输出：
```
  ``np.asfortranarray``) with ``like=Quantity(...)`` . [#17125]

- Added support for calling numpy array constructors (``np.frombuffer``,
  ``np.fromfile``, ``np.fromiter``, ``np.fromstring`` and ``np.fromfunction``)
  with ``like=Quantity(...))`` . [#17128]

- Added support for calling numpy array constructors (``np.require``,
  ``np.identity``, ``np.eye``, ``np.tri``, ``np.genfromtxt`` and ``np.loadtxt``)
  with ``like=Quantity(...))`` . [#17130]

astropy.utils
^^^^^^^^^^^^^

- Added the ``astropy.system_info`` function to help document runtime systems in
  bug reports. [#16335]

- Add support for specifying files as ``pathlib.Path`` objects in ``IERS_A.read``
  and ``IERS_B.read``. [#16931]

astropy.visualization
^^^^^^^^^^^^^^^^^^^^^

- Add ``make_rgb()``, a convenience
  function for creating RGB images with independent scaling on each filter.
  Refactors ``make_lupton_rgb()`` to work with instances of subclasses of
  ``BaseStretch``, including the new Lupton-specific classes
  ``LuptonAsinhStretch`` and ``LuptonAsinhZscaleStretch``. [#15081]

- Add support for custom coordinate frames for ``WCSAxes`` through a context
  manager ``astropy.visualization.wcsaxes.custom_ucd_coord_meta_mapping``. [#16347]

- Added ``get_ticks_position``, ``get_ticklabel_position``, and
  ``get_axislabel_position`` methods on ``CoordinateHelper`` in WCSAxes. [#16686]

- Added the ability to disable the automatic simplification of WCSAxes tick labels
  by specifying ``simplify=False`` to ``set_ticklabel()`` for a coordinate axis. [#16938]

- Added the ability to specify that WCSAxes tick labels always include the sign
  (namely for positive values) by starting the format string with a ``+``
  character. [#16985]

docs/visualization/rgb.rst:159:    rgb = make_rgb(i, r, g, interval=ManualInterval(vmin=0, vmax=maximum),
docs/visualization/rgb.rst:193:    rgb_log = make_rgb(i, r, g, interval=ManualInterval(vmin=0, vmax=maximum),
docs/visualization/rgb.rst:210:    rgb_log = make_rgb(i, r, g, interval=intervals, stretch=LogStretch(a=1000),
docs/visualization/rgb.rst:235:    rgb_sqrt = make_rgb(i, r, g, interval=ManualInterval(vmin=0, vmax=maximum),
```

## 原始行 40 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"apply_mappings\\|RGBImageMapping\" docs -n --exclude='*.png' --exclude='*.jpg'; sed -n '130,255p' docs/visualization/rgb.rst; sed -n '1,130p' astropy/visualization/tests/test_lupton_rgb.py"
```

退出码：`0`

输出：
```
now using a linear scaling.

.. plot::
   :context: reset
   :include-source:
   :align: center

    import numpy as np
    import matplotlib.pyplot as plt
    from astropy.visualization import make_rgb, ManualInterval
    from astropy.io import fits
    from astropy.utils.data import get_pkg_data_filename

    # Read in the three images downloaded from here:
    g_name = get_pkg_data_filename('visualization/reprojected_sdss_g.fits.bz2')
    r_name = get_pkg_data_filename('visualization/reprojected_sdss_r.fits.bz2')
    i_name = get_pkg_data_filename('visualization/reprojected_sdss_i.fits.bz2')
    g = fits.getdata(g_name)
    r = fits.getdata(r_name)
    i = fits.getdata(i_name)

    # Use the maximum value of the 99.5% percentile over all three filters
    # as the maximum value:
    pctl = 99.5
    maximum = 0.
    for img in [i,r,g]:
        val = np.percentile(img,pctl)
        if val > maximum:
            maximum = val
    rgb = make_rgb(i, r, g, interval=ManualInterval(vmin=0, vmax=maximum),
                   filename="ngc6976-linear.jpeg")

    fig, ax = plt.subplots()
    ax.imshow(rgb, origin='lower')



For images with high dynamic range, logarithmic stretches with values
calculated as

.. math::

    y = \frac{\log{(a x + 1)}}{\log{(a + 1)}}

can be beneficial. In this case, the a stretch instance of
:class:`~astropy.visualization.LogStretch` is directly passed:

.. plot::
   :context:
   :include-source:
   :align: center

    from astropy.visualization import LogStretch

    # Use the maximum value of the 99.95% percentile over all three filters
    # as the maximum value:
    pctl = 99.95
    maximum = 0.
    for img in [i,r,g]:
        val = np.percentile(img,pctl)
        if val > maximum:
            maximum = val

    rgb_log = make_rgb(i, r, g, interval=ManualInterval(vmin=0, vmax=maximum),
                       stretch=LogStretch(a=1000), filename="ngc6976-log.jpeg")

    fig, ax = plt.subplots()
    ax.imshow(rgb_log, origin='lower')

By specifying per-filter maximum values, it is possible to emphasize
certain objects, such as the very reddest sources:

.. plot::
   :context:
   :include-source:
   :align: center

    # Increase the red maximum to emphasize the very reddest sources:
    intervals = 3 * [ManualInterval(vmin=0, vmax=maximum)]
    intervals[0] = ManualInterval(vmin=0, vmax=30.)
    rgb_log = make_rgb(i, r, g, interval=intervals, stretch=LogStretch(a=1000),
                       filename="ngc6976-log-alt.jpeg")

    fig, ax = plt.subplots()
    ax.imshow(rgb_log, origin='lower')


Other stretches, such as square root, can also be used:

.. plot::
   :context:
   :include-source:
   :align: center

    from astropy.visualization import SqrtStretch

    # Use the maximum value of the 99.8% percentile over all three filters
    # as the maximum value:
    pctl = 99.8
    maximum = 0.
    for img in [i,r,g]:
        val = np.percentile(img,pctl)
        if val > maximum:
            maximum = val

    rgb_sqrt = make_rgb(i, r, g, interval=ManualInterval(vmin=0, vmax=maximum),
                        stretch=SqrtStretch(), filename="ngc6976-sqrt.jpeg")

    fig, ax = plt.subplots()
    ax.imshow(rgb_sqrt, origin='lower')
# Licensed under a 3-clause BSD style license - see LICENSE.rst

"""
Tests for RGB Images
"""

import sys

import numpy as np
import pytest
from numpy.testing import assert_allclose, assert_equal

from astropy.convolution import Gaussian2DKernel, convolve
from astropy.utils.compat.optional_deps import HAS_MATPLOTLIB
from astropy.visualization import lupton_rgb
from astropy.visualization.interval import ManualInterval
from astropy.visualization.stretch import LinearStretch

# Set display=True to get matplotlib imshow windows to help with debugging.
display = False


def display_rgb(rgb, title=None):
    """Display an rgb image using matplotlib (useful for debugging)"""
    import matplotlib.pyplot as plt

    plt.imshow(rgb, interpolation="nearest", origin="lower")
    if title:
        plt.title(title)
    plt.show()
    return plt


def saturate(image, satValue):
    """
    Return image with all points above satValue set to NaN.

    Simulates saturation on an image, so we can test 'replace_saturated_pixels'
    """
    result = image.copy()
    saturated = image > satValue
    result[saturated] = np.nan
    return result


def random_array(dtype, N=100):
    return np.array(np.random.random(10) * 100, dtype=dtype)


def test_compute_intensity_1_float():
    image_r = random_array(np.float64)
    intensity = lupton_rgb.compute_intensity(image_r)
    assert image_r.dtype == intensity.dtype
    assert_equal(image_r, intensity)


def test_compute_intensity_1_uint():
    image_r = random_array(np.uint8)
    intensity = lupton_rgb.compute_intensity(image_r)
    assert image_r.dtype == intensity.dtype
    assert_equal(image_r, intensity)


def test_compute_intensity_3_float():
    image_r = random_array(np.float64)
    image_g = random_array(np.float64)
    image_b = random_array(np.float64)
    intensity = lupton_rgb.compute_intensity(image_r, image_g, image_b)
    assert image_r.dtype == intensity.dtype
    assert_equal(intensity, (image_r + image_g + image_b) / 3.0)


def test_compute_intensity_3_uint():
    image_r = random_array(np.uint8)
    image_g = random_array(np.uint8)
    image_b = random_array(np.uint8)
    intensity = lupton_rgb.compute_intensity(image_r, image_g, image_b)
    assert image_r.dtype == intensity.dtype
    assert_equal(intensity, (image_r + image_g + image_b) // 3)


class TestLuptonRgb:
    """A test case for Rgb"""

    def setup_method(self, method):
        np.random.seed(1000)  # so we always get the same images.

        self.min_, self.stretch_, self.Q = 0, 5, 20  # asinh

        width, height = 85, 75
        self.width = width
        self.height = height

        shape = (width, height)
        image_r = np.zeros(shape)
        image_g = np.zeros(shape)
        image_b = np.zeros(shape)

        # pixel locations, values and colors
        points = [[15, 15], [50, 45], [30, 30], [45, 15]]
        values = [1000, 5500, 600, 20000]
        g_r = [1.0, -1.0, 1.0, 1.0]
        r_i = [2.0, -0.5, 2.5, 1.0]

        # Put pixels in the images.
        for p, v, gr, ri in zip(points, values, g_r, r_i):
            image_r[p[0], p[1]] = v * pow(10, 0.4 * ri)
            image_g[p[0], p[1]] = v * pow(10, 0.4 * gr)
            image_b[p[0], p[1]] = v

        # convolve the image with a reasonable PSF,
        # and add Gaussian background noise
        def convolve_with_noise(image, psf):
            convolvedImage = convolve(
                image, psf, boundary="extend", normalize_kernel=True
            )
            randomImage = np.random.normal(0, 2, image.shape)
            return randomImage + convolvedImage

        psf = Gaussian2DKernel(2.5)
        self.image_r = convolve_with_noise(image_r, psf)
        self.image_g = convolve_with_noise(image_g, psf)
        self.image_b = convolve_with_noise(image_b, psf)

    def test_Asinh(self):
        """Test creating an RGB image using an asinh stretch"""

        asinh_map = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhStretch(self.stretch_, self.Q),
```

## 原始行 44 · agent_message

```
The source has four intentionally empty implementation regions: RGB mapping methods, interval preprocessing, the ZScale fit, and stretch preparation/composition. The surrounding Lupton mapper depends on the same RGB constructor/converter, so I’m implementing the shared behavior in those base modules, including constant-range and unusable-fit fallbacks.
```

## 原始行 47 · file_change

```
{
  "id": "item_31",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/visualization/basic_rgb.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/visualization/interval.py",
      "kind": "update"
    },
    {
      "path": "/testbed/astropy/visualization/stretch.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 50 · file_change

```
{
  "id": "item_33",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/visualization/stretch.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/visualization/tests/test_interval.py astropy/visualization/tests/test_stretch.py astropy/visualization/tests/test_lupton_rgb.py -q'
```

退出码：`1`

输出：
```
Internet access disabled
........................................................................ [ 36%]
........................................................................ [ 72%]
..................................F....FFFFF...s.s.s..                   [100%]
=================================== FAILURES ===================================
___________________________ TestLuptonRgb.test_Asinh ___________________________

self = <astropy.visualization.tests.test_lupton_rgb.TestLuptonRgb object at 0x7e6624edb0d0>

    def test_Asinh(self):
        """Test creating an RGB image using an asinh stretch"""
    
        asinh_map = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhStretch(self.stretch_, self.Q),
        )
>       rgb_image = asinh_map.make_rgb_image(self.image_r, self.image_g, self.image_b)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/visualization/tests/test_lupton_rgb.py:132: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/visualization/basic_rgb.py:77: in make_rgb_image
    image_rgb = self.apply_mappings(image_r, image_g, image_b)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/visualization/lupton_rgb.py:642: in apply_mappings
    fI = self.stretch(Int, clip=False)
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.visualization.lupton_rgb.LuptonAsinhStretch object at 0x7e6624f9dc10>
values = array([[-1.37078599e+00, -1.39531528e-01, -2.91451582e-01, ...,
         2.11854230e-01, -1.27304489e+00, -1.22939639e....80477533e+00,  1.17374307e+00, ...,
        -1.10009496e+00,  1.50532437e+00, -1.26554708e+00]],
      shape=(85, 75))
clip = False, out = None

    def __call__(self, values, clip=False, out=None):
>       values = _stretch_prepare(values, clip=clip, out=out)
                 ^^^^^^^^^^^^^^^^
E       NameError: name '_stretch_prepare' is not defined

astropy/visualization/lupton_rgb.py:450: NameError
________________________ TestLuptonRgb.test_AsinhZscale ________________________

self = <astropy.visualization.tests.test_lupton_rgb.TestLuptonRgb object at 0x7e6624ee9090>

    def test_AsinhZscale(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                [self.image_r, self.image_g, self.image_b], self.Q
            ),
        )
>       rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/visualization/tests/test_lupton_rgb.py:164: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/visualization/basic_rgb.py:77: in make_rgb_image
    image_rgb = self.apply_mappings(image_r, image_g, image_b)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/visualization/lupton_rgb.py:642: in apply_mappings
    fI = self.stretch(Int, clip=False)
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.visualization.lupton_rgb.LuptonAsinhZscaleStretch object at 0x7e662541dd50>
values = array([[-1.37078599e+00, -1.39531528e-01, -2.91451582e-01, ...,
         2.11854230e-01, -1.27304489e+00, -1.22939639e....80477533e+00,  1.17374307e+00, ...,
        -1.10009496e+00,  1.50532437e+00, -1.26554708e+00]],
      shape=(85, 75))
clip = False, out = None

    def __call__(self, values, clip=False, out=None):
>       values = _stretch_prepare(values, clip=clip, out=out)
                 ^^^^^^^^^^^^^^^^
E       NameError: name '_stretch_prepare' is not defined

astropy/visualization/lupton_rgb.py:450: NameError
___________________ TestLuptonRgb.test_AsinhZscaleIntensity ____________________

self = <astropy.visualization.tests.test_lupton_rgb.TestLuptonRgb object at 0x7e6624ee96d0>

    def test_AsinhZscaleIntensity(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale on the intensity
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                lupton_rgb.compute_intensity(self.image_r, self.image_g, self.image_b),
                self.Q,
            ),
        )
>       rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/visualization/tests/test_lupton_rgb.py:181: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/visualization/basic_rgb.py:77: in make_rgb_image
    image_rgb = self.apply_mappings(image_r, image_g, image_b)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/visualization/lupton_rgb.py:642: in apply_mappings
    fI = self.stretch(Int, clip=False)
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.visualization.lupton_rgb.LuptonAsinhZscaleStretch object at 0x7e6622b49590>
values = array([[-1.37078599e+00, -1.39531528e-01, -2.91451582e-01, ...,
         2.11854230e-01, -1.27304489e+00, -1.22939639e....80477533e+00,  1.17374307e+00, ...,
        -1.10009496e+00,  1.50532437e+00, -1.26554708e+00]],
      shape=(85, 75))
clip = False, out = None

    def __call__(self, values, clip=False, out=None):
>       values = _stretch_prepare(values, clip=clip, out=out)
                 ^^^^^^^^^^^^^^^^
E       NameError: name '_stretch_prepare' is not defined

astropy/visualization/lupton_rgb.py:450: NameError
__________________ TestLuptonRgb.test_AsinhZscaleIntensityBW ___________________

self = <astropy.visualization.tests.test_lupton_rgb.TestLuptonRgb object at 0x7e6624ee9d10>

    def test_AsinhZscaleIntensityBW(self):
        """Test creating a black-and-white image using an asinh stretch
        estimated using zscale on the intensity"""
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                self.image_r,
                self.Q,
            ),
        )
>       rgb_image = map_.make_rgb_image(self.image_r, self.image_r, self.image_r)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/visualization/tests/test_lupton_rgb.py:196: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/visualization/basic_rgb.py:77: in make_rgb_image
    image_rgb = self.apply_mappings(image_r, image_g, image_b)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/visualization/lupton_rgb.py:642: in apply_mappings
    fI = self.stretch(Int, clip=False)
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.visualization.lupton_rgb.LuptonAsinhZscaleStretch object at 0x7e6622b92290>
values = array([[-1.60891661,  0.64186309, -0.05096576, ..., -0.73551156,
        -3.04657598, -1.2695434 ],
       [ 1.9748076...],
       [ 2.23707333,  2.48790533,  0.81289295, ..., -1.36716112,
         0.74022605, -4.03307277]], shape=(85, 75))
clip = False, out = None

    def __call__(self, values, clip=False, out=None):
>       values = _stretch_prepare(values, clip=clip, out=out)
                 ^^^^^^^^^^^^^^^^
E       NameError: name '_stretch_prepare' is not defined

astropy/visualization/lupton_rgb.py:450: NameError
________________ TestLuptonRgb.test_AsinhZscale_pedestal_array _________________

self = <astropy.visualization.tests.test_lupton_rgb.TestLuptonRgb object at 0x7e6624eea350>

    def test_AsinhZscale_pedestal_array(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                [self.image_r, self.image_g, self.image_b],
                self.Q,
                pedestal=[1.0, 1.0, 2.0],
            ),
        )
>       rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/visualization/tests/test_lupton_rgb.py:213: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/visualization/basic_rgb.py:77: in make_rgb_image
    image_rgb = self.apply_mappings(image_r, image_g, image_b)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/visualization/lupton_rgb.py:642: in apply_mappings
    fI = self.stretch(Int, clip=False)
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.visualization.lupton_rgb.LuptonAsinhZscaleStretch object at 0x7e662505a050>
values = array([[-1.37078599e+00, -1.39531528e-01, -2.91451582e-01, ...,
         2.11854230e-01, -1.27304489e+00, -1.22939639e....80477533e+00,  1.17374307e+00, ...,
        -1.10009496e+00,  1.50532437e+00, -1.26554708e+00]],
      shape=(85, 75))
clip = False, out = None

    def __call__(self, values, clip=False, out=None):
>       values = _stretch_prepare(values, clip=clip, out=out)
                 ^^^^^^^^^^^^^^^^
E       NameError: name '_stretch_prepare' is not defined

astropy/visualization/lupton_rgb.py:450: NameError
________________ TestLuptonRgb.test_AsinhZscale_pedestal_float _________________

self = <astropy.visualization.tests.test_lupton_rgb.TestLuptonRgb object at 0x7e6624eea950>

    def test_AsinhZscale_pedestal_float(self):
        """
        Test creating an RGB image using an asinh stretch estimated
        using zscale
        """
        map_ = lupton_rgb.RGBImageMappingLupton(
            interval=ManualInterval(vmin=self.min_, vmax=None),
            stretch=lupton_rgb.LuptonAsinhZscaleStretch(
                [self.image_r, self.image_g, self.image_b],
                self.Q,
                pedestal=1.0,
            ),
        )
>       rgb_image = map_.make_rgb_image(self.image_r, self.image_g, self.image_b)
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

astropy/visualization/tests/test_lupton_rgb.py:231: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
astropy/visualization/basic_rgb.py:77: in make_rgb_image
    image_rgb = self.apply_mappings(image_r, image_g, image_b)
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
astropy/visualization/lupton_rgb.py:642: in apply_mappings
    fI = self.stretch(Int, clip=False)
         ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <astropy.visualization.lupton_rgb.LuptonAsinhZscaleStretch object at 0x7e6622b93f10>
values = array([[-1.37078599e+00, -1.39531528e-01, -2.91451582e-01, ...,
         2.11854230e-01, -1.27304489e+00, -1.22939639e....80477533e+00,  1.17374307e+00, ...,
        -1.10009496e+00,  1.50532437e+00, -1.26554708e+00]],
      shape=(85, 75))
clip = False, out = None

    def __call__(self, values, clip=False, out=None):
>       values = _stretch_prepare(values, clip=clip, out=out)
                 ^^^^^^^^^^^^^^^^
E       NameError: name '_stretch_prepare' is not defined

astropy/visualization/lupton_rgb.py:450: NameError
=========================== short test summary info ============================
FAILED astropy/visualization/tests/test_lupton_rgb.py::TestLuptonRgb::test_Asinh
FAILED astropy/visualization/tests/test_lupton_rgb.py::TestLuptonRgb::test_AsinhZscale
FAILED astropy/visualization/tests/test_lupton_rgb.py::TestLuptonRgb::test_AsinhZscaleIntensity
FAILED astropy/visualization/tests/test_lupton_rgb.py::TestLuptonRgb::test_AsinhZscaleIntensityBW
FAILED astropy/visualization/tests/test_lupton_rgb.py::TestLuptonRgb::test_AsinhZscale_pedestal_array
FAILED astropy/visualization/tests/test_lupton_rgb.py::TestLuptonRgb::test_AsinhZscale_pedestal_float
6 failed, 189 passed, 3 skipped in 0.67s
```

## 原始行 54 · agent_message

```
The core interval and stretch suites now pass. The Lupton regressions exposed one related missing internal import: its custom stretch calls the shared stretch-preparation helper by alias. I’m restoring that link, then I’ll exercise the new RGB interface directly (dtypes, shape errors, immutability, masks, and composite `out`).
```

## 原始行 56 · file_change

```
{
  "id": "item_37",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/visualization/lupton_rgb.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc "python -m pytest astropy/visualization/tests/test_lupton_rgb.py -q && python - <<'PY'
import numpy as np
from astropy.visualization.basic_rgb import RGBImageMapping, make_rgb
from astropy.visualization.interval import ManualInterval, MinMaxInterval, ZScaleInterval
from astropy.visualization.stretch import LinearStretch, SqrtStretch

r = np.array([[0, 1], [2, 3]], dtype=np.int16)
g = r + 1
b = r + 2
originals = [x.copy() for x in (r, g, b)]
mapping = RGBImageMapping(MinMaxInterval(), SqrtStretch())
f = mapping.make_rgb_image(r, g, b, output_dtype=float)
u = mapping.make_rgb_image(r, g, b)
assert f.shape == (2, 2, 3) and f.dtype == np.float64
assert u.shape == (2, 2, 3) and u.dtype == np.uint8
assert all(np.array_equal(x, y) for x, y in zip((r, g, b), originals))
assert mapping.intervals[0] is mapping.intervals[1] is mapping.intervals[2]
try:
    RGBImageMapping([MinMaxInterval()] * 2)
except ValueError:
    pass
else:
    raise AssertionError('bad interval count accepted')
for dtype in (np.float32, int):
    try:
        mapping.make_rgb_image(r, g, b, output_dtype=dtype)
    except ValueError:
        pass
    else:
        raise AssertionError('bad dtype accepted')
out = np.empty(4, dtype=float)
composite = LinearStretch(2) + LinearStretch(0.5)
ret = composite(np.linspace(-1, 2, 4), clip=False, out=out)
assert ret is out and np.allclose(out, np.linspace(-1, 2, 4))
constant = np.ones((2, 2))
assert np.all(make_rgb(constant, constant, constant, interval=MinMaxInterval()) == 0)
print('direct RGB/stretch checks passed')
PY"
```

退出码：`0`

输出：
```
Internet access disabled
.................s.s.s..                                                 [100%]
21 passed, 3 skipped in 0.27s
direct RGB/stretch checks passed
```

## 原始行 61 · command_execution

命令：
```
/bin/bash -lc 'git diff --check && git diff -- astropy/visualization/basic_rgb.py astropy/visualization/interval.py astropy/visualization/stretch.py astropy/visualization/lupton_rgb.py'
```

退出码：`0`

输出：
```
diff --git a/astropy/visualization/basic_rgb.py b/astropy/visualization/basic_rgb.py
index cd8257e..761021c 100644
--- a/astropy/visualization/basic_rgb.py
+++ b/astropy/visualization/basic_rgb.py
@@ -33,6 +33,54 @@ class RGBImageMapping:
 
     """
 
+    def __init__(
+        self,
+        interval=ManualInterval(vmin=0, vmax=None),
+        stretch=LinearStretch(),
+    ):
+        try:
+            len(interval)
+        except TypeError:
+            interval = 3 * [interval]
+
+        if len(interval) != 3:
+            raise ValueError("please provide 1 or 3 intervals.")
+
+        self.intervals = interval
+        self.stretch = stretch
+
+    def apply_mappings(self, image_r, image_g, image_b):
+        """Apply the configured interval and stretch to each image."""
+        image_rgb = [image_r, image_g, image_b]
+
+        for i, image in enumerate(image_rgb):
+            image_rgb[i] = self.intervals[i](image, clip=True)
+            image_rgb[i] = self.stretch(image_rgb[i], clip=True)
+
+        return np.asarray(image_rgb)
+
+    def make_rgb_image(self, image_r, image_g, image_b, output_dtype=np.uint8):
+        """Convert three equally shaped arrays to a normalized RGB image."""
+        if output_dtype not in _OUTPUT_IMAGE_FORMATS:
+            raise ValueError(
+                f"'output_dtype' must be one of {_OUTPUT_IMAGE_FORMATS}!"
+            )
+
+        image_r = np.asarray(image_r)
+        image_g = np.asarray(image_g)
+        image_b = np.asarray(image_b)
+
+        if image_r.shape != image_g.shape or image_g.shape != image_b.shape:
+            msg = "The image shapes must match. r: {}, g: {} b: {}"
+            raise ValueError(msg.format(image_r.shape, image_g.shape, image_b.shape))
+
+        image_rgb = self.apply_mappings(image_r, image_g, image_b)
+
+        if output_dtype == np.uint8:
+            image_rgb = image_rgb * np.iinfo(np.uint8).max
+
+        return np.dstack(image_rgb).astype(output_dtype)
+
 
 
 
@@ -214,4 +262,4 @@ def make_rgb(
 
         matplotlib.image.imsave(filename, rgb, origin="lower")
 
-    return rgb
\ No newline at end of file
+    return rgb
diff --git a/astropy/visualization/interval.py b/astropy/visualization/interval.py
index 6689b2a..8ba6200 100644
--- a/astropy/visualization/interval.py
+++ b/astropy/visualization/interval.py
@@ -73,6 +73,18 @@ class BaseInterval(BaseTransform):
 
 
 
+
+    @staticmethod
+    def _process_values(values):
+        """Return finite, unmasked values as a flat array."""
+        data, mask = get_data_and_mask(values)
+        data = np.asarray(data)
+
+        if mask is not None:
+            data = data[~np.asarray(mask)]
+
+        data = np.asarray(data).ravel()
+        return data[np.isfinite(data)]
 
     def __call__(self, values, clip=True, out=None):
         """
@@ -318,6 +330,56 @@ class ZScaleInterval(BaseInterval):
         self.krej = krej
         self.max_iterations = max_iterations
 
+    def get_limits(self, values):
+        samples = self._process_values(values)
+
+        stride = max(1, samples.size // self.n_samples)
+        samples = samples[::stride][: self.n_samples]
+        samples.sort()
+
+        npix = samples.size
+        vmin = samples[0]
+        vmax = samples[-1]
+        minpix = max(self.min_npixels, int(npix * self.max_reject))
+        ngrow = max(1, int(npix * 0.01))
+
+        x = np.arange(npix)
+        badpix = np.zeros(npix, dtype=bool)
+        ngoodpix = npix
+        last_ngoodpix = npix + 1
+        fit = None
+
+        for _ in range(self.max_iterations):
+            if ngoodpix >= last_ngoodpix or ngoodpix < minpix:
+                break
+
+            last_ngoodpix = ngoodpix
+            goodpix = ~badpix
+            fit = np.polyfit(x[goodpix], samples[goodpix], deg=1)
+            fitted = np.poly1d(fit)(x)
+            flat = samples - fitted
+            threshold = self.krej * flat[goodpix].std()
+
+            badpix[(flat < -threshold) | (flat > threshold)] = True
+            badpix = np.convolve(badpix, np.ones(ngrow, dtype=bool), mode="same")
+            ngoodpix = np.count_nonzero(~badpix)
+
+        if fit is None or ngoodpix < minpix or not np.all(np.isfinite(fit)):
+            return vmin, vmax
+
+        slope = fit[0]
+        if self.contrast > 0:
+            slope /= self.contrast
+
+        center_pixel = (npix - 1) // 2
+        median = np.median(samples)
+        z1 = max(vmin, median - (center_pixel - 1) * slope)
+        z2 = min(vmax, median + (npix - center_pixel) * slope)
+
+        if not np.isfinite(z1) or not np.isfinite(z2) or z1 >= z2:
+            return vmin, vmax
+
+        return z1, z2
 
 
 
diff --git a/astropy/visualization/lupton_rgb.py b/astropy/visualization/lupton_rgb.py
index a8ecc2d..d9aa1b3 100644
--- a/astropy/visualization/lupton_rgb.py
+++ b/astropy/visualization/lupton_rgb.py
@@ -11,7 +11,7 @@ For details, see : https://ui.adsabs.harvard.edu/abs/2004PASP..116..133L
 import numpy as np
 
 from astropy.visualization.interval import ManualInterval, ZScaleInterval
-from astropy.visualization.stretch import BaseStretch
+from astropy.visualization.stretch import BaseStretch, _prepare as _stretch_prepare
 
 
 from .basic_rgb import RGBImageMapping
diff --git a/astropy/visualization/stretch.py b/astropy/visualization/stretch.py
index 502dfb8..627bb77 100644
--- a/astropy/visualization/stretch.py
+++ b/astropy/visualization/stretch.py
@@ -52,6 +52,24 @@ def _logn(n, x, out=None):
 
 
 
+def _prepare(values, clip=True, out=None):
+    """Prepare a writable floating-point array for a stretch operation."""
+    if out is None:
+        values = np.array(values, dtype=float, copy=True)
+    else:
+        if out.dtype.kind != "f":
+            raise TypeError(
+                "Can only do in-place stretching for floating-point arrays"
+            )
+        np.copyto(out, values, casting="unsafe")
+        values = out
+
+    if clip:
+        np.clip(values, 0.0, 1.0, out=values)
+
+    return values
+
+
 class BaseStretch(BaseTransform):
     """
     Base class for the stretch classes, which when called with an array
@@ -985,3 +1003,6 @@ class CompositeStretch(CompositeTransform, BaseStretch):
         The second stretch to apply.
     """
 
+    def __call__(self, values, clip=True, out=None):
+        values = self.transform_1(values, clip=clip, out=out)
+        return self.transform_2(values, clip=clip, out=out)
```

## 原始行 67 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
line='from astropy.visualization.stretch import BaseStretch, _prepare as _stretch_prepare'
print(len(line))
PY
python -m ruff check astropy/visualization/basic_rgb.py astropy/visualization/interval.py astropy/visualization/stretch.py astropy/visualization/lupton_rgb.py"
```

退出码：`1`

输出：
```
83
/opt/miniconda3/envs/testbed/bin/python: No module named ruff
```

## 原始行 70 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest astropy/visualization/tests -q'
```

退出码：`0`

输出：
```
Internet access disabled
sss..................................................................... [ 28%]
...s.s.s...sssssssssssssssssssssssssssssssssssssss...................... [ 57%]
........................................................................ [ 85%]
..........................ssssssssss                                     [100%]
197 passed, 57 skipped in 1.24s
```

## 原始行 75 · command_execution

命令：
```
/bin/bash -lc "nl -ba astropy/visualization/interval.py | sed -n '305,410p'; nl -ba astropy/visualization/basic_rgb.py | sed -n '20,150p'; nl -ba astropy/visualization/stretch.py | sed -n '35,100p'; nl -ba astropy/visualization/stretch.py | tail -70"
```

退出码：`0`

输出：
```
   305	        Defaults to 0.5.
   306	    min_npixels : int, optional
   307	        If there are less than ``min_npixels`` pixels remaining after
   308	        the pixel rejection, then the returned values are the minimum
   309	        and maximum of the data.  Defaults to 5.
   310	    krej : float, optional
   311	        The number of sigma used for the rejection. Defaults to 2.5.
   312	    max_iterations : int, optional
   313	        The maximum number of iterations for the rejection. Defaults to
   314	        5.
   315	    """
   316	
   317	    def __init__(
   318	        self,
   319	        n_samples=1000,
   320	        contrast=0.25,
   321	        max_reject=0.5,
   322	        min_npixels=5,
   323	        krej=2.5,
   324	        max_iterations=5,
   325	    ):
   326	        self.n_samples = n_samples
   327	        self.contrast = contrast
   328	        self.max_reject = max_reject
   329	        self.min_npixels = min_npixels
   330	        self.krej = krej
   331	        self.max_iterations = max_iterations
   332	
   333	    def get_limits(self, values):
   334	        samples = self._process_values(values)
   335	
   336	        stride = max(1, samples.size // self.n_samples)
   337	        samples = samples[::stride][: self.n_samples]
   338	        samples.sort()
   339	
   340	        npix = samples.size
   341	        vmin = samples[0]
   342	        vmax = samples[-1]
   343	        minpix = max(self.min_npixels, int(npix * self.max_reject))
   344	        ngrow = max(1, int(npix * 0.01))
   345	
   346	        x = np.arange(npix)
   347	        badpix = np.zeros(npix, dtype=bool)
   348	        ngoodpix = npix
   349	        last_ngoodpix = npix + 1
   350	        fit = None
   351	
   352	        for _ in range(self.max_iterations):
   353	            if ngoodpix >= last_ngoodpix or ngoodpix < minpix:
   354	                break
   355	
   356	            last_ngoodpix = ngoodpix
   357	            goodpix = ~badpix
   358	            fit = np.polyfit(x[goodpix], samples[goodpix], deg=1)
   359	            fitted = np.poly1d(fit)(x)
   360	            flat = samples - fitted
   361	            threshold = self.krej * flat[goodpix].std()
   362	
   363	            badpix[(flat < -threshold) | (flat > threshold)] = True
   364	            badpix = np.convolve(badpix, np.ones(ngrow, dtype=bool), mode="same")
   365	            ngoodpix = np.count_nonzero(~badpix)
   366	
   367	        if fit is None or ngoodpix < minpix or not np.all(np.isfinite(fit)):
   368	            return vmin, vmax
   369	
   370	        slope = fit[0]
   371	        if self.contrast > 0:
   372	            slope /= self.contrast
   373	
   374	        center_pixel = (npix - 1) // 2
   375	        median = np.median(samples)
   376	        z1 = max(vmin, median - (center_pixel - 1) * slope)
   377	        z2 = min(vmax, median + (npix - center_pixel) * slope)
   378	
   379	        if not np.isfinite(z1) or not np.isfinite(z2) or z1 >= z2:
   380	            return vmin, vmax
   381	
   382	        return z1, z2
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
    20	    Class to map red, blue, green images into either a normalized float or
    21	    an 8-bit image, by performing optional clipping and applying
    22	    a scaling function to each band independently.
    23	
    24	    Parameters
    25	    ----------
    26	    interval : `~astropy.visualization.BaseInterval` subclass instance or array-like, optional
    27	        The interval object to apply to the data (either a single instance or
    28	        an array for R, G, B). Default is
    29	        `~astropy.visualization.ManualInterval`.
    30	    stretch : `~astropy.visualization.BaseStretch` subclass instance, optional
    31	        The stretch object to apply to the data. Default is
    32	        `~astropy.visualization.LinearStretch`.
    33	
    34	    """
    35	
    36	    def __init__(
    37	        self,
    38	        interval=ManualInterval(vmin=0, vmax=None),
    39	        stretch=LinearStretch(),
    40	    ):
    41	        try:
    42	            len(interval)
    43	        except TypeError:
    44	            interval = 3 * [interval]
    45	
    46	        if len(interval) != 3:
    47	            raise ValueError("please provide 1 or 3 intervals.")
    48	
    49	        self.intervals = interval
    50	        self.stretch = stretch
    51	
    52	    def apply_mappings(self, image_r, image_g, image_b):
    53	        """Apply the configured interval and stretch to each image."""
    54	        image_rgb = [image_r, image_g, image_b]
    55	
    56	        for i, image in enumerate(image_rgb):
    57	            image_rgb[i] = self.intervals[i](image, clip=True)
    58	            image_rgb[i] = self.stretch(image_rgb[i], clip=True)
    59	
    60	        return np.asarray(image_rgb)
    61	
    62	    def make_rgb_image(self, image_r, image_g, image_b, output_dtype=np.uint8):
    63	        """Convert three equally shaped arrays to a normalized RGB image."""
    64	        if output_dtype not in _OUTPUT_IMAGE_FORMATS:
    65	            raise ValueError(
    66	                f"'output_dtype' must be one of {_OUTPUT_IMAGE_FORMATS}!"
    67	            )
    68	
    69	        image_r = np.asarray(image_r)
    70	        image_g = np.asarray(image_g)
    71	        image_b = np.asarray(image_b)
    72	
    73	        if image_r.shape != image_g.shape or image_g.shape != image_b.shape:
    74	            msg = "The image shapes must match. r: {}, g: {} b: {}"
    75	            raise ValueError(msg.format(image_r.shape, image_g.shape, image_b.shape))
    76	
    77	        image_rgb = self.apply_mappings(image_r, image_g, image_b)
    78	
    79	        if output_dtype == np.uint8:
    80	            image_rgb = image_rgb * np.iinfo(np.uint8).max
    81	
    82	        return np.dstack(image_rgb).astype(output_dtype)
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
    35	        np.log(x, out=out)
    36	        np.true_divide(out, np.log(n), out=out)
    37	        return out
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	def _prepare(values, clip=True, out=None):
    56	    """Prepare a writable floating-point array for a stretch operation."""
    57	    if out is None:
    58	        values = np.array(values, dtype=float, copy=True)
    59	    else:
    60	        if out.dtype.kind != "f":
    61	            raise TypeError(
    62	                "Can only do in-place stretching for floating-point arrays"
    63	            )
    64	        np.copyto(out, values, casting="unsafe")
    65	        values = out
    66	
    67	    if clip:
    68	        np.clip(values, 0.0, 1.0, out=values)
    69	
    70	    return values
    71	
    72	
    73	class BaseStretch(BaseTransform):
    74	    """
    75	    Base class for the stretch classes, which when called with an array
    76	    of values in the range [0:1], returns an transformed array of values
    77	    also in the range [0:1].
    78	    """
    79	
    80	    @property
    81	    def _supports_invalid_kw(self):
    82	        return False
    83	
    84	    def __add__(self, other):
    85	        return CompositeStretch(other, self)
    86	
    87	    def __call__(self, values, clip=True, out=None):
    88	        """
    89	        Transform values using this stretch.
    90	
    91	        Parameters
    92	        ----------
    93	        values : array-like
    94	            The input values, which should already be normalized to the
    95	            [0:1] range.
    96	        clip : bool, optional
    97	            If `True` (default), values outside the [0:1] range are
    98	            clipped to the [0:1] range.
    99	        out : ndarray, optional
   100	            If specified, the output values will be placed in this array
   939	            np.clip(values, 0, 1, out=values)
   940	
   941	        return values
   942	
   943	    @property
   944	    def inverse(self):
   945	        """A stretch object that performs the inverse operation."""
   946	        return InvertedContrastBiasStretch(self.contrast, self.bias)
   947	
   948	
   949	class InvertedContrastBiasStretch(BaseStretch):
   950	    r"""
   951	    Inverse transformation for
   952	    `~astropy.visualization.ContrastBiasStretch`.
   953	
   954	    The stretch is given by:
   955	
   956	    .. math::
   957	        y = \frac{x - 0.5}{{\rm contrast}} + {\rm bias}
   958	
   959	    Parameters
   960	    ----------
   961	    contrast : float
   962	        The contrast parameter (see
   963	        `~astropy.visualization.ContrastBiasStretch`).
   964	
   965	    bias : float
   966	        The bias parameter (see
   967	        `~astropy.visualization.ContrastBiasStretch`).
   968	    """
   969	
   970	    def __init__(self, contrast, bias):
   971	        super().__init__()
   972	        self.contrast = contrast
   973	        self.bias = bias
   974	
   975	    def __call__(self, values, clip=True, out=None):
   976	        # As a special case here, we only clip *after* the
   977	        # transformation since it does not map [0:1] to [0:1]
   978	        values = _prepare(values, clip=False, out=out)
   979	        np.subtract(values, 0.5, out=values)
   980	        np.true_divide(values, self.contrast, out=values)
   981	        np.add(values, self.bias, out=values)
   982	
   983	        if clip:
   984	            np.clip(values, 0, 1, out=values)
   985	
   986	        return values
   987	
   988	    @property
   989	    def inverse(self):
   990	        """A stretch object that performs the inverse operation."""
   991	        return ContrastBiasStretch(self.contrast, self.bias)
   992	
   993	
   994	class CompositeStretch(CompositeTransform, BaseStretch):
   995	    """
   996	    A combination of two stretches.
   997	
   998	    Parameters
   999	    ----------
  1000	    stretch_1 : :class:`astropy.visualization.BaseStretch`
  1001	        The first stretch to apply.
  1002	    stretch_2 : :class:`astropy.visualization.BaseStretch`
  1003	        The second stretch to apply.
  1004	    """
  1005	
  1006	    def __call__(self, values, clip=True, out=None):
  1007	        values = self.transform_1(values, clip=clip, out=out)
  1008	        return self.transform_2(values, clip=clip, out=out)
```

## 原始行 78 · agent_message

```
All visualization tests pass (`197 passed`). I’m doing a final edge-case audit now, especially ZScale’s sampled fallback and finite/masked preprocessing, because those controls are easy to satisfy on ordinary arrays while mishandling sparse or zero-iteration cases.
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
from astropy.utils.masked import Masked
from astropy.visualization.interval import MinMaxInterval, ZScaleInterval
from astropy.visualization.stretch import LinearStretch, SqrtStretch

raw = np.array([[np.nan, 1.0, 999.0], [2.0, np.inf, 3.0]])
mask = np.array([[False, False, True], [False, False, False]])
for data in (np.ma.array(raw, mask=mask), Masked(raw, mask)):
    processed = MinMaxInterval._process_values(data)
    assert processed.ndim == 1
    assert np.array_equal(processed, [1.0, 2.0, 3.0])

# A zero-iteration fit must use the extrema of the actual sample, not the
# extrema of the full input.
data = np.arange(30.0)
z = ZScaleInterval(n_samples=5, max_iterations=0)
assert z.get_limits(data) == (0.0, 24.0)

# Stretch preparation returns writable copies and respects explicit output.
x = np.array([-1.0, 0.25, 2.0])
y = SqrtStretch()(x)
assert y.flags.writeable and not np.shares_memory(x, y)
assert np.array_equal(x, [-1.0, 0.25, 2.0])
out = np.empty_like(x)
ret = LinearStretch(2)(x, clip=True, out=out)
assert ret is out and np.array_equal(out, [0.0, 0.5, 1.0])
print('edge-case checks passed')
PY
python -m compileall -q astropy/visualization/basic_rgb.py astropy/visualization/interval.py astropy/visualization/stretch.py astropy/visualization/lupton_rgb.py
git diff --check
git status --short"
```

退出码：`0`

输出：
```
edge-case checks passed
 M astropy/visualization/basic_rgb.py
 M astropy/visualization/interval.py
 M astropy/visualization/lupton_rgb.py
 M astropy/visualization/stretch.py
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np
from astropy.utils.masked import Masked, get_data_and_mask
for m in (False, [[False],[True]]):
    try:
      x=Masked(np.arange(6).reshape(2,3),m)
      d,mask=get_data_and_mask(x)
      print(np.shape(mask),mask)
    except Exception as e: print(type(e),e)
PY"
```

退出码：`0`

输出：
```
(2, 3) [[False False False]
 [False False False]]
(2, 3) [[False False False]
 [ True  True  True]]
```

## 原始行 88 · command_execution

命令：
```
/bin/bash -lc "grep -n \"dtype\\|write\\|copy\\|read.only\\|readonly\\|out=\" astropy/visualization/tests/test_stretch.py"
```

退出码：`0`

输出：
```
71:        data_in = DATA.copy()
73:        stretch(data_in, out=result, clip=False)
86:        stretch(DATA, out=result, clip=False)
87:        stretch.inverse(result, out=result, clip=False)
```

## 原始行 94 · file_change

```
{
  "id": "item_66",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/astropy/visualization/stretch.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 96 · command_execution

命令：
```
/bin/bash -lc "python -m pytest astropy/visualization/tests -q && python - <<'PY'
import numpy as np
from astropy.visualization.stretch import LinearStretch
x = np.array([0, 1], dtype=np.float32)
y = LinearStretch()(x)
assert y.dtype == x.dtype and not np.shares_memory(x, y) and y.flags.writeable
out = np.empty(2, dtype=float)
assert LinearStretch()(x, clip=False, out=out) is out
print('stretch copy/output checks passed')
PY
git diff --check"
```

退出码：`0`

输出：
```
Internet access disabled
sss..................................................................... [ 28%]
...s.s.s...sssssssssssssssssssssssssssssssssssssss...................... [ 57%]
........................................................................ [ 85%]
..........................ssssssssss                                     [100%]
197 passed, 57 skipped in 1.21s
stretch copy/output checks passed
```

## 原始行 99 · agent_message

```
Implemented the complete RGB mapping pipeline.

Key fixes:

- Restored `RGBImageMapping` construction, per-channel mapping, shape validation, dtype handling, and uint8 quantization.
- Restored finite/unmasked interval preprocessing and robust `ZScaleInterval`.
- Restored stretch preparation and composite stretch output semantics.
- Reconnected Lupton RGB stretches to the shared preparation helper.

Files changed:

- [basic_rgb.py](/testbed/astropy/visualization/basic_rgb.py)
- [interval.py](/testbed/astropy/visualization/interval.py)
- [stretch.py](/testbed/astropy/visualization/stretch.py)
- [lupton_rgb.py](/testbed/astropy/visualization/lupton_rgb.py)

Validation: `197 passed, 57 skipped` across the visualization test suite.
```
