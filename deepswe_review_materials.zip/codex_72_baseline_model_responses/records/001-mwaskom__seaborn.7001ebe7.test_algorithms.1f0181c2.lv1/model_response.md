# Codex baseline: mwaskom__seaborn.7001ebe7.test_algorithms.1f0181c2.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the current implementation and its tests, then implement the function in place and run the focused test suite plus relevant broader checks.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' seaborn/algorithms.py && rg -n \"bootstrap|_structured_bootstrap\" tests seaborn | head -200"
```

退出码：`0`

输出：
```
"""Algorithms to support fitting routines in seaborn plotting functions."""
import numpy as np
import warnings


/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
The target file is currently just imports, so this is a full implementation rather than a small repair. `rg` is unavailable in this environment; I’m using repository-local `find`/`grep` to map the expected behavior from visible tests and call sites.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "find tests seaborn -type f -maxdepth 4 -print | sort | head -300; grep -RIn --exclude='*.pyc' -E 'bootstrap|structured_bootstrap' tests seaborn | head -300"
```

退出码：`0`

输出：
```
seaborn/__init__.py
seaborn/_base.py
seaborn/_compat.py
seaborn/_core/__init__.py
seaborn/_core/data.py
seaborn/_core/exceptions.py
seaborn/_core/groupby.py
seaborn/_core/moves.py
seaborn/_core/plot.py
seaborn/_core/properties.py
seaborn/_core/rules.py
seaborn/_core/scales.py
seaborn/_core/subplots.py
seaborn/_core/typing.py
seaborn/_docstrings.py
seaborn/_marks/__init__.py
seaborn/_marks/area.py
seaborn/_marks/bar.py
seaborn/_marks/base.py
seaborn/_marks/dot.py
seaborn/_marks/line.py
seaborn/_marks/text.py
seaborn/_statistics.py
seaborn/_stats/__init__.py
seaborn/_stats/aggregation.py
seaborn/_stats/base.py
seaborn/_stats/counting.py
seaborn/_stats/density.py
seaborn/_stats/order.py
seaborn/_stats/regression.py
seaborn/_testing.py
seaborn/algorithms.py
seaborn/axisgrid.py
seaborn/categorical.py
seaborn/cm.py
seaborn/colors/__init__.py
seaborn/colors/crayons.py
seaborn/colors/xkcd_rgb.py
seaborn/distributions.py
seaborn/external/__init__.py
seaborn/external/appdirs.py
seaborn/external/docscrape.py
seaborn/external/husl.py
seaborn/external/kde.py
seaborn/external/version.py
seaborn/matrix.py
seaborn/miscplot.py
seaborn/objects.py
seaborn/palettes.py
seaborn/rcmod.py
seaborn/regression.py
seaborn/relational.py
seaborn/utils.py
seaborn/widgets.py
tests/__init__.py
tests/_core/__init__.py
tests/_core/test_data.py
tests/_core/test_groupby.py
tests/_core/test_moves.py
tests/_core/test_plot.py
tests/_core/test_properties.py
tests/_core/test_rules.py
tests/_core/test_scales.py
tests/_core/test_subplots.py
tests/_marks/__init__.py
tests/_marks/test_area.py
tests/_marks/test_bar.py
tests/_marks/test_base.py
tests/_marks/test_dot.py
tests/_marks/test_line.py
tests/_marks/test_text.py
tests/_stats/__init__.py
tests/_stats/test_aggregation.py
tests/_stats/test_counting.py
tests/_stats/test_density.py
tests/_stats/test_order.py
tests/_stats/test_regression.py
tests/conftest.py
tests/test_axisgrid.py
tests/test_base.py
tests/test_categorical.py
tests/test_distributions.py
tests/test_docstrings.py
tests/test_matrix.py
tests/test_miscplot.py
tests/test_objects.py
tests/test_palettes.py
tests/test_rcmod.py
tests/test_regression.py
tests/test_relational.py
tests/test_statistics.py
tests/test_utils.py
tests/test_regression.py:252:    def test_regress_without_bootstrap(self):
tests/test_regression.py:269:    def test_regress_bootstrap_seed(self):
seaborn/regression.py:178:                    boots = algo.bootstrap(_y,
seaborn/regression.py:250:        beta_boots = algo.bootstrap(X, y,
seaborn/regression.py:268:        yhat_boots = algo.bootstrap(x, y,
seaborn/regression.py:299:        yhat_boots = algo.bootstrap(X, y,
seaborn/regression.py:325:        beta_boots = algo.bootstrap(X, y,
seaborn/regression.py:461:        If ``x_ci`` is given, this estimate will be bootstrapped and a
seaborn/regression.py:478:        ``ci`` parameter. If ``"sd"``, skip bootstrapping and show the
seaborn/regression.py:495:        confidence interval is estimated using a bootstrap; for large
seaborn/regression.py:501:        Number of bootstrap resamples used to estimate the ``ci``. The default
seaborn/regression.py:509:        computing the confidence intervals by performing a multilevel bootstrap
seaborn/regression.py:515:        Seed or random number generator for reproducible bootstrapping.\
seaborn/regression.py:527:        so you may wish to decrease the number of bootstrap resamples
seaborn/regression.py:541:        wish to decrease the number of bootstrap resamples (``n_boot``) or set
seaborn/_statistics.py:473:            Additional keywords are passed to bootstrap when error_method is "ci".
seaborn/_statistics.py:517:            boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
seaborn/_statistics.py:538:            Additional keywords are passed to bootstrap when error_method is "ci".
seaborn/_statistics.py:551:            # But we'll keep things simple for now and limit to (bootstrap) CI.
seaborn/_statistics.py:570:            boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
seaborn/categorical.py:613:        bootstrap = plot_kws.pop("bootstrap", mpl.rcParams["boxplot.bootstrap"])
seaborn/categorical.py:643:                                                         bootstrap=bootstrap))
seaborn/categorical.py:1406:        Number of bootstrap samples used to compute confidence intervals.
seaborn/categorical.py:1408:        Seed or random number generator for reproducible bootstrapping.
seaborn/categorical.py:1411:        perform a multilevel bootstrap and account for repeated measures
seaborn/relational.py:154:    Number of bootstraps to use for computing the confidence interval.
seaborn/relational.py:158:    Seed or random number generator for reproducible bootstrapping.
seaborn/_stats/aggregation.py:78:       Number of bootstrap samples to draw for "ci" errorbars.
seaborn/_stats/aggregation.py:80:        Seed for the PRNG used to draw bootstrap samples.
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "grep -RIn --exclude='*.pyc' -E 'default_rng|RandomState|SeedSequence|random_seed' seaborn tests | head -250; sed -n '130,350p' seaborn/regression.py; sed -n '450,590p' seaborn/_statistics.py; find . -maxdepth 2 -type f \\( -name 'pyproject.toml' -o -name 'setup.cfg' -o -name 'setup.py' -o -name 'tox.ini' \\) -print -exec sed -n '1,180p' {} \\;"
```

退出码：`0`

输出：
```
seaborn/regression.py:514:    seed : int, numpy.random.Generator, or numpy.random.RandomState, optional
seaborn/categorical.py:1407:    seed : int, `numpy.random.Generator`, or `numpy.random.RandomState`
seaborn/_core/moves.py:58:        rng = np.random.default_rng(self.seed)
seaborn/relational.py:157:seed : int, numpy.random.Generator, or numpy.random.RandomState
tests/test_categorical.py:2923:    rs = np.random.RandomState(30)
tests/test_distributions.py:69:    rs = np.random.RandomState(0)
tests/test_matrix.py:34:    rs = np.random.RandomState(sum(map(ord, "heatmap")))
tests/test_matrix.py:500:    rs = np.random.RandomState(sum(map(ord, "dendrogram")))
tests/test_matrix.py:743:    rs = np.random.RandomState(sum(map(ord, "clustermap")))
tests/test_axisgrid.py:25:rs = np.random.RandomState(0)
tests/test_axisgrid.py:727:    rs = np.random.RandomState(sum(map(ord, "PairGrid")))
tests/test_axisgrid.py:1496:    rs = np.random.RandomState(sum(map(ord, "JointGrid")))
tests/test_axisgrid.py:1707:    rs = np.random.RandomState(sum(map(ord, "jointplot")))
tests/test_regression.py:21:rs = np.random.RandomState(0)
tests/test_regression.py:26:    rs = np.random.RandomState(77)
tests/test_regression.py:100:    rs = np.random.RandomState(49)
tests/test_regression.py:462:    rs = np.random.RandomState(56)
tests/conftest.py:15:def random_seed():
tests/conftest.py:23:    return np.random.RandomState(seed)
            self.fit_reg = False

        # Save the range of the x variable for the grid later
        if self.fit_reg:
            self.x_range = self.x.min(), self.x.max()

    @property
    def scatter_data(self):
        """Data where each observation is a point."""
        x_j = self.x_jitter
        if x_j is None:
            x = self.x
        else:
            x = self.x + np.random.uniform(-x_j, x_j, len(self.x))

        y_j = self.y_jitter
        if y_j is None:
            y = self.y
        else:
            y = self.y + np.random.uniform(-y_j, y_j, len(self.y))

        return x, y

    @property
    def estimate_data(self):
        """Data with a point estimate and CI for each discrete x value."""
        x, y = self.x_discrete, self.y
        vals = sorted(np.unique(x))
        points, cis = [], []

        for val in vals:

            # Get the point estimate of the y variable
            _y = y[x == val]
            est = self.x_estimator(_y)
            points.append(est)

            # Compute the confidence interval for this estimate
            if self.x_ci is None:
                cis.append(None)
            else:
                units = None
                if self.x_ci == "sd":
                    sd = np.std(_y)
                    _ci = est - sd, est + sd
                else:
                    if self.units is not None:
                        units = self.units[x == val]
                    boots = algo.bootstrap(_y,
                                           func=self.x_estimator,
                                           n_boot=self.n_boot,
                                           units=units,
                                           seed=self.seed)
                    _ci = utils.ci(boots, self.x_ci)
                cis.append(_ci)

        return vals, points, cis

    def _check_statsmodels(self):
        """Check whether statsmodels is installed if any boolean options require it."""
        options = "logistic", "robust", "lowess"
        err = "`{}=True` requires statsmodels, an optional dependency, to be installed."
        for option in options:
            if getattr(self, option) and not _has_statsmodels:
                raise RuntimeError(err.format(option))

    def fit_regression(self, ax=None, x_range=None, grid=None):
        """Fit the regression model."""
        self._check_statsmodels()

        # Create the grid for the regression
        if grid is None:
            if self.truncate:
                x_min, x_max = self.x_range
            else:
                if ax is None:
                    x_min, x_max = x_range
                else:
                    x_min, x_max = ax.get_xlim()
            grid = np.linspace(x_min, x_max, 100)
        ci = self.ci

        # Fit the regression
        if self.order > 1:
            yhat, yhat_boots = self.fit_poly(grid, self.order)
        elif self.logistic:
            from statsmodels.genmod.generalized_linear_model import GLM
            from statsmodels.genmod.families import Binomial
            yhat, yhat_boots = self.fit_statsmodels(grid, GLM,
                                                    family=Binomial())
        elif self.lowess:
            ci = None
            grid, yhat = self.fit_lowess()
        elif self.robust:
            from statsmodels.robust.robust_linear_model import RLM
            yhat, yhat_boots = self.fit_statsmodels(grid, RLM)
        elif self.logx:
            yhat, yhat_boots = self.fit_logx(grid)
        else:
            yhat, yhat_boots = self.fit_fast(grid)

        # Compute the confidence interval at each grid point
        if ci is None:
            err_bands = None
        else:
            err_bands = utils.ci(yhat_boots, ci, axis=0)

        return grid, yhat, err_bands

    def fit_fast(self, grid):
        """Low-level regression and prediction using linear algebra."""
        def reg_func(_x, _y):
            return np.linalg.pinv(_x).dot(_y)

        X, y = np.c_[np.ones(len(self.x)), self.x], self.y
        grid = np.c_[np.ones(len(grid)), grid]
        yhat = grid.dot(reg_func(X, y))
        if self.ci is None:
            return yhat, None

        beta_boots = algo.bootstrap(X, y,
                                    func=reg_func,
                                    n_boot=self.n_boot,
                                    units=self.units,
                                    seed=self.seed).T
        yhat_boots = grid.dot(beta_boots).T
        return yhat, yhat_boots

    def fit_poly(self, grid, order):
        """Regression using numpy polyfit for higher-order trends."""
        def reg_func(_x, _y):
            return np.polyval(np.polyfit(_x, _y, order), grid)

        x, y = self.x, self.y
        yhat = reg_func(x, y)
        if self.ci is None:
            return yhat, None

        yhat_boots = algo.bootstrap(x, y,
                                    func=reg_func,
                                    n_boot=self.n_boot,
                                    units=self.units,
                                    seed=self.seed)
        return yhat, yhat_boots

    def fit_statsmodels(self, grid, model, **kwargs):
        """More general regression function using statsmodels objects."""
        import statsmodels.tools.sm_exceptions as sme
        X, y = np.c_[np.ones(len(self.x)), self.x], self.y
        grid = np.c_[np.ones(len(grid)), grid]

        def reg_func(_x, _y):
            err_classes = (sme.PerfectSeparationError,)
            try:
                with warnings.catch_warnings():
                    if hasattr(sme, "PerfectSeparationWarning"):
                        # statsmodels>=0.14.0
                        warnings.simplefilter("error", sme.PerfectSeparationWarning)
                        err_classes = (*err_classes, sme.PerfectSeparationWarning)
                    yhat = model(_y, _x, **kwargs).fit().predict(grid)
            except err_classes:
                yhat = np.empty(len(grid))
                yhat.fill(np.nan)
            return yhat

        yhat = reg_func(X, y)
        if self.ci is None:
            return yhat, None

        yhat_boots = algo.bootstrap(X, y,
                                    func=reg_func,
                                    n_boot=self.n_boot,
                                    units=self.units,
                                    seed=self.seed)
        return yhat, yhat_boots

    def fit_lowess(self):
        """Fit a locally-weighted regression, which returns its own grid."""
        from statsmodels.nonparametric.smoothers_lowess import lowess
        grid, yhat = lowess(self.y, self.x).T
        return grid, yhat

    def fit_logx(self, grid):
        """Fit the model in log-space."""
        X, y = np.c_[np.ones(len(self.x)), self.x], self.y
        grid = np.c_[np.ones(len(grid)), np.log(grid)]

        def reg_func(_x, _y):
            _x = np.c_[_x[:, 0], np.log(_x[:, 1])]
            return np.linalg.pinv(_x).dot(_y)

        yhat = grid.dot(reg_func(X, y))
        if self.ci is None:
            return yhat, None

        beta_boots = algo.bootstrap(X, y,
                                    func=reg_func,
                                    n_boot=self.n_boot,
                                    units=self.units,
                                    seed=self.seed).T
        yhat_boots = grid.dot(beta_boots).T
        return yhat, yhat_boots

    def bin_predictor(self, bins):
        """Discretize a predictor by assigning value to closest bin."""
        x = np.asarray(self.x)
        if np.isscalar(bins):
            percentiles = np.linspace(0, 100, bins + 2)[1:-1]
            bins = np.percentile(x, percentiles)
        else:
            bins = np.ravel(bins)

        dist = np.abs(np.subtract.outer(x, bins))
        x_binned = bins[np.argmin(dist, axis=1)].ravel()

        return x_binned, bins

    def regress_out(self, a, b):
        """Regress b from a keeping a's original mean."""
        a_mean = a.mean()
        a = a - a_mean

        if x2 is None:
            return self._eval_univariate(x1, weights)
        else:
            return self._eval_bivariate(x1, x2, weights)


class EstimateAggregator:

    def __init__(self, estimator, errorbar=None, **boot_kws):
        """
        Data aggregator that produces an estimate and error bar interval.

        Parameters
        ----------
        estimator : callable or string
            Function (or method name) that maps a vector to a scalar.
        errorbar : string, (string, number) tuple, or callable
            Name of errorbar method (either "ci", "pi", "se", or "sd"), or a tuple
            with a method name and a level parameter, or a function that maps from a
            vector to a (min, max) interval, or None to hide errorbar. See the
            :doc:`errorbar tutorial </tutorial/error_bars>` for more information.
        boot_kws
            Additional keywords are passed to bootstrap when error_method is "ci".

        """
        self.estimator = estimator

        method, level = _validate_errorbar_arg(errorbar)
        self.error_method = method
        self.error_level = level

        self.boot_kws = boot_kws

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)

        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan

        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)

        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval

        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
            boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
            err_min, err_max = _percentile_interval(boots, self.error_level)

        return pd.Series({var: estimate, f"{var}min": err_min, f"{var}max": err_max})


class WeightedAggregator:

    def __init__(self, estimator, errorbar=None, **boot_kws):
        """
        Data aggregator that produces a weighted estimate and error bar interval.

        Parameters
        ----------
        estimator : string
            Function (or method name) that maps a vector to a scalar. Currently
            supports only "mean".
        errorbar : string or (string, number) tuple
            Name of errorbar method or a tuple with a method name and a level parameter.
            Currently the only supported method is "ci".
        boot_kws
            Additional keywords are passed to bootstrap when error_method is "ci".

        """
        if estimator != "mean":
            # Note that, while other weighted estimators may make sense (e.g. median),
            # I'm not aware of an implementation in our dependencies. We can add one
            # in seaborn later, if there is sufficient interest. For now, limit to mean.
            raise ValueError(f"Weighted estimator must be 'mean', not {estimator!r}.")
        self.estimator = estimator

        method, level = _validate_errorbar_arg(errorbar)
        if method is not None and method != "ci":
            # As with the estimator, weighted 'sd' or 'pi' error bars may make sense.
            # But we'll keep things simple for now and limit to (bootstrap) CI.
            raise ValueError(f"Error bar method must be 'ci', not {method!r}.")
        self.error_method = method
        self.error_level = level

        self.boot_kws = boot_kws

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        weights = data["weight"]

        estimate = np.average(vals, weights=weights)

        if self.error_method == "ci" and len(data) > 1:

            def error_func(x, w):
                return np.average(x, weights=w)

            boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
            err_min, err_max = _percentile_interval(boots, self.error_level)

        else:
            err_min = err_max = np.nan

        return pd.Series({var: estimate, f"{var}min": err_min, f"{var}max": err_max})


class LetterValues:

    def __init__(self, k_depth, outlier_prop, trust_alpha):
        """
        Compute percentiles of a distribution using various tail stopping rules.

        Parameters
        ----------
        k_depth: "tukey", "proportion", "trustworthy", or "full"
            Stopping rule for choosing tail percentiled to show:

            - tukey: Show a similar number of outliers as in a conventional boxplot.
./pyproject.toml
[build-system]
requires = ["flit_core >=3.2,<4"]
build-backend = "flit_core.buildapi"

[project]
name = "seaborn"
description = "Statistical data visualization"
authors = [{name = "Michael Waskom", email = "mwaskom@gmail.com"}]
readme = "README.md"
license = {file = "LICENSE.md"}
dynamic = ["version"]
classifiers = [
    "Intended Audience :: Science/Research",
    "Programming Language :: Python :: 3.8",
    "Programming Language :: Python :: 3.9",
    "Programming Language :: Python :: 3.10",
    "Programming Language :: Python :: 3.11",
    "Programming Language :: Python :: 3.12",
    "License :: OSI Approved :: BSD License",
    "Topic :: Scientific/Engineering :: Visualization",
    "Topic :: Multimedia :: Graphics",
    "Operating System :: OS Independent",
    "Framework :: Matplotlib",
]
requires-python = ">=3.8"
dependencies = [
    "numpy>=1.20,!=1.24.0",
    "pandas>=1.2",
    "matplotlib>=3.4,!=3.6.1",
]

[project.optional-dependencies]
stats = [
    "scipy>=1.7",
    "statsmodels>=0.12",
]
dev = [
    "pytest",
    "pytest-cov",
    "pytest-xdist",
    "flake8",
    "mypy",
    "pandas-stubs",
    "pre-commit",
    "flit",
]
docs = [
    "numpydoc",
    "nbconvert",
    "ipykernel",
    "sphinx<6.0.0",
    "sphinx-copybutton",
    "sphinx-issues",
    "sphinx-design",
    "pyyaml",
    "pydata_sphinx_theme==0.10.0rc2",
]

[project.urls]
Source = "https://github.com/mwaskom/seaborn"
Docs = "http://seaborn.pydata.org"

[tool.flit.sdist]
exclude = ["doc/_static/*.svg"]

[tool.pytest.ini_options]
filterwarnings = [
   "ignore:The --rsyncdir command line argument and rsyncdirs config variable are deprecated.:DeprecationWarning",
   "ignore:\\s*Pyarrow will become a required dependency of pandas:DeprecationWarning",
   "ignore:datetime.datetime.utcfromtimestamp\\(\\) is deprecated:DeprecationWarning",
 ]
./setup.cfg
[flake8]
max-line-length = 88
exclude = seaborn/cm.py,seaborn/external
ignore = E741,F522,W503

[mypy]
# Currently this ignores pandas and matplotlib
# We may want to make custom stub files for the parts we use
# I have found the available third party stubs to be less
# complete than they would need to be useful
ignore_missing_imports = True

[coverage:run]
omit =
    seaborn/widgets.py
    seaborn/external/*
    seaborn/colors/*
    seaborn/cm.py
    seaborn/conftest.py

[coverage:report]
exclude_lines =
    pragma: no cover
    if TYPE_CHECKING:
    raise NotImplementedError
```

## 原始行 17 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,80p' seaborn/__init__.py; grep -RIn --exclude='*.pyc' 'algorithms' tests | head -100; git status --short 2>/dev/null || true; git log -1 --oneline 2>/dev/null || true; python - <<'PY'
import numpy as np
print(np.__version__)
PY"
```

退出码：`0`

输出：
```
# Import seaborn objects
from .rcmod import *  # noqa: F401,F403
from .utils import *  # noqa: F401,F403
from .palettes import *  # noqa: F401,F403
from .relational import *  # noqa: F401,F403
from .regression import *  # noqa: F401,F403
from .categorical import *  # noqa: F401,F403
from .distributions import *  # noqa: F401,F403
from .matrix import *  # noqa: F401,F403
from .miscplot import *  # noqa: F401,F403
from .axisgrid import *  # noqa: F401,F403
from .widgets import *  # noqa: F401,F403
from .colors import xkcd_rgb, crayons  # noqa: F401
from . import cm  # noqa: F401

# Capture the original matplotlib rcParams
import matplotlib as mpl
_orig_rc_params = mpl.rcParams.copy()

# Define the seaborn version
__version__ = "0.14.0.dev0"
33148f1 Initial commit for FeatureBench evaluation
2.1.2
```

## 原始行 21 · agent_message

```
The repository’s consumers require two important details beyond a basic loop: paired arrays must share every sampled index, and hierarchical sampling must preserve that pairing both when clusters and observations are redrawn. I’m implementing those semantics, NumPy’s modern and legacy RNG types, axis-aware statistics, and NaN-function substitution.
```

## 原始行 23 · file_change

```
{
  "id": "item_15",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/algorithms.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 26 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import warnings
import numpy as np
from seaborn.algorithms import bootstrap

x = np.arange(5.)
print('simple', bootstrap(x, n_boot=4, seed=0))
print('repeat', np.array_equal(bootstrap(x, n_boot=4, seed=0), bootstrap(x, n_boot=4, seed=0)))
print('axis', bootstrap(np.arange(12).reshape(6, 2), n_boot=3, axis=0, seed=1).shape)
print('paired', bootstrap(x, x * 2, n_boot=5, func=lambda a, b: np.all(b == 2 * a), seed=2))
u = np.repeat(['a', 'b', 'c'], 2)
print('units', bootstrap(np.arange(6), np.arange(6) * 2, n_boot=5, units=u, func=lambda a, b: np.all(b == 2 * a), seed=3))
print('nan', bootstrap([1., np.nan, 3.], n_boot=4, func='mean', seed=4))
rs1 = np.random.RandomState(5)
rs2 = np.random.RandomState(5)
print('rs', np.array_equal(bootstrap(x, n_boot=4, seed=rs1), bootstrap(x, n_boot=4, seed=rs2)))
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter('always')
    bootstrap(x, n_boot=1, random_seed=1)
    print('deprecated', [(type(w.message).__name__, str(w.message)) for w in caught])
PY
pytest -q tests/test_regression.py -q"
```

退出码：`0`

输出：
```
simple [2.2 0.8 3.2 2.8]
repeat True
axis (3, 2)
paired [ True  True  True  True  True]
units [ True  True  True  True  True]
nan [3. 3. 2. 1.]
rs True
deprecated [('FutureWarning', '`random_seed` has been renamed to `seed` and will be removed')]
................ss....ss.........ssss...................s....            [100%]
```

## 原始行 29 · agent_message

```
Focused regression tests pass, and direct checks confirm deterministic seeds, axis-shaped output, NaN-aware means, and pairing under both resampling modes. I’m now checking compatibility details and running the complete suite to catch downstream assumptions.
```

## 原始行 31 · file_change

```
{
  "id": "item_21",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/algorithms.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 34 · agent_message

```
The full suite is still running. It has reached plotting-heavy tests with a number of failures; I’ll let it finish and separate any bootstrap regressions from pre-existing/environmental image or compatibility failures before changing code.
```

## 原始行 36 · command_execution

命令：
```
/bin/bash -lc 'python -m flake8 seaborn/algorithms.py 2>/dev/null || true
pytest -q'
```

退出码：`1`

输出：
```
seaborn/algorithms.py:59:89: E501 line too long (89 > 88 characters)
....................................s................................... [  3%]
.................................x............x...x................x.x.. [  6%]
........................................................................ [  9%]
........................................................................ [ 12%]
........................................................................ [ 15%]
........................................................................ [ 18%]
.....................................................................x.. [ 21%]
........................................................................ [ 24%]
........................................................................ [ 27%]
.............................FF......................................... [ 30%]
....ss...................................................F.............. [ 33%]
........................................................................ [ 36%]
........................................................................ [ 39%]
........................................................................ [ 42%]
..........................FFFF........FFFF.............................. [ 45%]
........................................................................ [ 48%]
........................................................................ [ 51%]
........................................................................ [ 54%]
........................................................................ [ 57%]
........................................................................ [ 60%]
......FFFFF.FFF.FFFFFF.........................FF......FFF....FF..FF.FFF [ 63%]
FFFFFFFF..FF....FFFFF.FFF.FFFFFF.............FF............FF.FFFFFFFFFF [ 66%]
F..FFFFFF...................................F..F.F...................... [ 69%]
..............................................s......................... [ 72%]
........................................................................ [ 75%]
........................................................................ [ 79%]
........................................................................ [ 82%]
.......sssssssssssssssssssssssssssssssssssssssssssssssssssss..s......... [ 85%]
..................................................s.s................ss. [ 88%]
...ss.........ssss...................s................F........F........ [ 91%]
....FFFFFF......F....FFFF....F..FFFFFF.FFFFFFFFFF....................... [ 94%]
.....................s.....s.....................................s...... [ 97%]
..F....F......................................sss.s..............        [100%]
=================================== FAILURES ===================================
__________________________ TestEst.test_weighted_mean __________________________

self = <tests._stats.test_aggregation.TestEst object at 0x7442c25aef80>
df =       x         y color group    weight
0   4.0 -1.419388     a     y  2.761563
1   5.0 -0.908918     c     y  0.58360...27  3.0  1.647809     c     y  2.076302
28  6.0  0.045453     c     y  4.324342
29  1.0 -0.305246     b     x  1.302940
rng = RandomState(MT19937) at 0x7442C2429440

    def test_weighted_mean(self, df, rng):
    
        weights = rng.uniform(0, 5, len(df))
        gb = self.get_groupby(df[["x", "y"]], "x")
        df = df.assign(weight=weights)
>       res = Est("mean")(df, gb, "x", {})

tests/_stats/test_aggregation.py:123: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/_stats/aggregation.py:115: in __call__
    .apply(data, self._process, var, engine)
seaborn/_core/groupby.py:117: in apply
    parts[key] = func(part_df, *args, **kwargs)
seaborn/_stats/aggregation.py:99: in _process
    res = estimator(data, var)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.WeightedAggregator object at 0x7442c17a2800>
data =       x         y color group    weight
0   4.0 -1.419388     a     y  2.761563
4   4.0  1.399088     b     x  0.49744...18  4.0 -1.474030     b     x  4.051635
22  4.0 -0.871679     b     y  1.726433
25  4.0  0.343388     c     x  1.161663
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        weights = data["weight"]
    
        estimate = np.average(vals, weights=weights)
    
        if self.error_method == "ci" and len(data) > 1:
    
            def error_func(x, w):
                return np.average(x, weights=w)
    
>           boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:570: NameError
______________________________ TestEst.test_seed _______________________________

self = <tests._stats.test_aggregation.TestEst object at 0x7442c25af640>
df =       x         y color group
0   4.0 -1.419388     a     y
1   5.0 -0.908918     c     y
2   1.0 -0.160687     c     ...26  0.0  0.850129     b     x
27  3.0  1.647809     c     y
28  6.0  0.045453     c     y
29  1.0 -0.305246     b     x

    def test_seed(self, df):
    
        ori = "x"
        gb = self.get_groupby(df, ori)
        args = df, gb, ori, {}
>       res1 = Est("mean", "ci", seed=99)(*args)

tests/_stats/test_aggregation.py:134: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/_stats/aggregation.py:115: in __call__
    .apply(data, self._process, var, engine)
seaborn/_core/groupby.py:117: in apply
    parts[key] = func(part_df, *args, **kwargs)
seaborn/_stats/aggregation.py:99: in _process
    res = estimator(data, var)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442c25c5b70>
data =       x         y color group
4   4.0  1.399088     b     x
18  4.0 -1.474030     b     x
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestFacetGrid.test_categorical_warning ____________________

self = <tests.test_axisgrid.TestFacetGrid object at 0x7442c1e9e830>

    def test_categorical_warning(self):
    
        g = ag.FacetGrid(self.df, col="b")
        with pytest.warns(UserWarning):
>           g.map(pointplot, "b", "x")

tests/test_axisgrid.py:649: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/axisgrid.py:758: in map
    self._facet_plot(func, ax, plot_args, kwargs)
seaborn/axisgrid.py:854: in _facet_plot
    func(*plot_args, **plot_kwargs)
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442c114b9d0>
data =            y
0   1.764052
2   0.978738
4   1.867558
6   0.950088
8  -0.103219
10  0.144044
12  0.761038
14  0.443863
1...53
42 -1.706270
44 -0.509652
46 -1.252795
48 -1.613898
50 -0.895467
52 -0.510805
54 -0.028182
56  0.066517
58 -0.634322
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________ TestCategoricalPlotterNew.test_axis_labels[barplot-kwargs4] __________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fdd3f0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function barplot at 0x7442c29669e0>, kwargs = {'x': 'x', 'y': 'a'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bbd56230>
data =        x
0   12.0
1   15.0
4   10.0
13   0.0
14  13.0
15   2.0
18  11.0
22  10.0
23   4.0
26   1.0
27   9.0
30   7.0
3....0
61   4.0
63  12.0
66  12.0
67   5.0
68   2.0
71   5.0
73   5.0
75   5.0
85  17.0
87   5.0
88  11.0
92  12.0
93  12.0
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________ TestCategoricalPlotterNew.test_axis_labels[barplot-kwargs5] __________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fdd5a0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function barplot at 0x7442c29669e0>, kwargs = {'x': 'a', 'y': 'y'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442c1392410>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________ TestCategoricalPlotterNew.test_axis_labels[barplot-kwargs6] __________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fdd540>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function barplot at 0x7442c29669e0>, kwargs = {'x': 'y'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bc2a8a60>
data =            x
0   0.449243
1   0.434942
2   1.429015
3  -0.352296
4  -1.253690
..       ...
95 -1.245018
96 -0.152851
97 -0.912663
98 -1.212684
99  0.073484

[100 rows x 1 columns]
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________ TestCategoricalPlotterNew.test_axis_labels[barplot-kwargs7] __________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fddff0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function barplot at 0x7442c29669e0>, kwargs = {'y': 'x'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bc113fa0>
data =        y
0   12.0
1   15.0
2    3.0
3   18.0
4   10.0
..   ...
95   2.0
96   4.0
97  16.0
98  14.0
99  15.0

[100 rows x 1 columns]
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________ TestCategoricalPlotterNew.test_axis_labels[pointplot-kwargs16] ________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fde920>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function pointplot at 0x7442c2966a70>, kwargs = {'x': 'x', 'y': 'a'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bc099180>
data =        x
0   12.0
1   15.0
4   10.0
13   0.0
14  13.0
15   2.0
18  11.0
22  10.0
23   4.0
26   1.0
27   9.0
30   7.0
3....0
61   4.0
63  12.0
66  12.0
67   5.0
68   2.0
71   5.0
73   5.0
75   5.0
85  17.0
87   5.0
88  11.0
92  12.0
93  12.0
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________ TestCategoricalPlotterNew.test_axis_labels[pointplot-kwargs17] ________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fdc040>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function pointplot at 0x7442c2966a70>, kwargs = {'x': 'a', 'y': 'y'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bcdac880>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________ TestCategoricalPlotterNew.test_axis_labels[pointplot-kwargs18] ________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fdda20>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function pointplot at 0x7442c2966a70>, kwargs = {'x': 'y'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bcfe5a20>
data =            x
0   0.449243
1   0.434942
2   1.429015
3  -0.352296
4  -1.253690
..       ...
95 -1.245018
96 -0.152851
97 -0.912663
98 -1.212684
99  0.073484

[100 rows x 1 columns]
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________ TestCategoricalPlotterNew.test_axis_labels[pointplot-kwargs19] ________

self = <tests.test_categorical.TestCategoricalPlotterNew object at 0x7442c1fdd810>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
func = <function pointplot at 0x7442c2966a70>, kwargs = {'y': 'x'}

    @pytest.mark.parametrize(
        "func,kwargs",
        itertools.product(
            PLOT_FUNCS,
            [
                {"x": "x", "y": "a"},
                {"x": "a", "y": "y"},
                {"x": "y"},
                {"y": "x"},
            ],
        ),
    )
    def test_axis_labels(self, long_df, func, kwargs):
    
>       func(data=long_df, **kwargs)

tests/test_categorical.py:70: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bcfecaf0>
data =        y
0   12.0
1   15.0
2    3.0
3   18.0
4   10.0
..   ...
95   2.0
96   4.0
97  16.0
98  14.0
99  15.0

[100 rows x 1 columns]
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestBarPlot.test_labels_long[x] ________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c25193c0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_labels_long(self, long_df, orient):
    
        depend = {"x": "y", "y": "x"}[orient]
        kws = {orient: "a", depend: "y", "hue": "b"}
    
>       ax = self.func(long_df, **kws)

tests/test_categorical.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b1659840>
data =            y hue
0   0.449243   p
15  1.670946   p
26 -1.993027   p
31 -1.463693   p
32 -1.153562   p
47 -0.853833   p
48  0.510687   p
51 -1.296145   p
53  1.477263   p
55  0.964998   p
63 -0.418434   p
93  0.101402   p
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestBarPlot.test_labels_long[y] ________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c2519180>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_labels_long(self, long_df, orient):
    
        depend = {"x": "y", "y": "x"}[orient]
        kws = {orient: "a", depend: "y", "hue": "b"}
    
>       ax = self.func(long_df, **kws)

tests/test_categorical.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b1415720>
data =            x hue
0   0.449243   p
15  1.670946   p
26 -1.993027   p
31 -1.463693   p
32 -1.153562   p
47 -0.853833   p
48  0.510687   p
51 -1.296145   p
53  1.477263   p
55  0.964998   p
63 -0.418434   p
93  0.101402   p
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________________ TestBarPlot.test_labels_wide _________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24f2260>
wide_df = cols               a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330

    def test_labels_wide(self, wide_df):
    
        wide_df = wide_df.rename_axis("cols", axis=1)
>       ax = self.func(wide_df)

tests/test_categorical.py:151: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b359ada0>
data =            y hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
______________________ TestBarPlot.test_labels_hue_order _______________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c2519cf0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_labels_hue_order(self, long_df):
    
        hue_var = "b"
        hue_order = categorical_order(long_df[hue_var])[::-1]
>       ax = self.func(long_df, x="a", y="y", hue=hue_var, hue_order=hue_order)

tests/test_categorical.py:165: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b389f820>
data =            y hue
4  -1.253690   m
13 -0.588094   m
14 -1.665427   m
18 -1.887821   m
22 -1.142441   m
23 -0.961407   m...
66  0.284743   m
67 -1.941020   m
71 -1.187002   m
73 -0.236192   m
85 -1.047659   m
87  0.180705   m
88 -0.560961   m
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________________ TestBarPlot.test_color ____________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c2519f90>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
common_kws = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0....073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'saturation': 1, 'x': 'a', 'y': 'y'}

    def test_color(self, long_df, common_kws):
        common_kws.update(data=long_df, x="a", y="y")
    
        ax = plt.figure().subplots()
>       self.func(ax=ax, **common_kws)

tests/test_categorical.py:174: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3791780>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestBarPlot.test_redundant_hue_legend _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24f27a0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_redundant_hue_legend(self, long_df):
    
>       ax = self.func(long_df, x="a", y="y", hue="a")

tests/test_categorical.py:199: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b33781c0>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
15  1.670946   b...
73 -0.236192   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
92  0.512806   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestBarPlot.test_log_scale[x] _________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24f2bf0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_log_scale(self, long_df, orient):
    
        depvar = {"x": "y", "y": "x"}[orient]
        variables = {orient: "a", depvar: "z"}
>       ax = self.func(long_df, **variables, log_scale=True)

tests/test_categorical.py:211: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2921ed0>
data =            y
0   0.820325
1   0.412046
4  -0.108566
13  0.397591
14 -0.390247
15 -0.568648
18 -0.029830
22 -0.352084
2...46
68  0.897790
71 -0.381510
73  1.139125
75  0.110125
85  0.746051
87 -0.057316
88 -0.912423
92 -0.437689
93 -0.124632
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestBarPlot.test_log_scale[y] _________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24f2b90>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_log_scale(self, long_df, orient):
    
        depvar = {"x": "y", "y": "x"}[orient]
        variables = {orient: "a", depvar: "z"}
>       ax = self.func(long_df, **variables, log_scale=True)

tests/test_categorical.py:211: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b5d50610>
data =            x
0   0.820325
1   0.412046
4  -0.108566
13  0.397591
14 -0.390247
15 -0.568648
18 -0.029830
22 -0.352084
2...46
68  0.897790
71 -0.381510
73  1.139125
75  0.110125
85  0.746051
87 -0.057316
88 -0.912423
92 -0.437689
93 -0.124632
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestBarPlot.test_single_var[x] ________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c1f33df0>
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_single_var(self, orient):
    
        vals = pd.Series([1, 3, 10])
>       ax = barplot(**{orient: vals})

tests/test_categorical.py:1876: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442c147a950>
data =       x
0   1.0
1   3.0
2  10.0, var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestBarPlot.test_single_var[y] ________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c1f32e30>
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_single_var(self, orient):
    
        vals = pd.Series([1, 3, 10])
>       ax = barplot(**{orient: vals})

tests/test_categorical.py:1876: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b87bc040>
data =       y
0   1.0
1   3.0
2  10.0, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________________ TestBarPlot.test_wide_df[x] __________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c1f33640>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = barplot(wide_df, orient=orient)

tests/test_categorical.py:1884: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b33dd690>
data =            y hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________________ TestBarPlot.test_wide_df[y] __________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c1f31960>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = barplot(wide_df, orient=orient)

tests/test_categorical.py:1884: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2944fd0>
data =            x hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________________ TestBarPlot.test_wide_df[h] __________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c1f31600>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'h'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = barplot(wide_df, orient=orient)

tests/test_categorical.py:1884: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b9566350>
data =            x hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________________ TestBarPlot.test_wide_df[v] __________________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c1f31cc0>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'v'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = barplot(wide_df, orient=orient)

tests/test_categorical.py:1884: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3f9f850>
data =            y hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
______________________ TestBarPlot.test_weighted_estimate ______________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e6dd0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_weighted_estimate(self, long_df):
    
>       ax = barplot(long_df, y="y", weights="x")

tests/test_categorical.py:2146: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.WeightedAggregator object at 0x7442b2de1e70>
data =            y  weight
0   0.449243      12
1   0.434942      15
2   1.429015       3
3  -0.352296      18
4  -1.253690 ...018       2
96 -0.152851       4
97 -0.912663      16
98 -1.212684      14
99  0.073484      15

[100 rows x 2 columns]
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        weights = data["weight"]
    
        estimate = np.average(vals, weights=weights)
    
        if self.error_method == "ci" and len(data) > 1:
    
            def error_func(x, w):
                return np.average(x, weights=w)
    
>           boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:570: NameError
___________________ TestBarPlot.test_estimate_log_transform ____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e6bc0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_estimate_log_transform(self, long_df):
    
        ax = mpl.figure.Figure().subplots()
        ax.set_xscale("log")
>       barplot(x=long_df["z"], ax=ax)

tests/test_categorical.py:2155: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2a49bd0>
data =            x
0   0.820325
1   0.412046
2   0.628582
3   0.606000
4  -0.108566
..       ...
95 -0.139198
96 -0.407996
97  0.151782
98  0.868213
99  0.015504

[100 rows x 1 columns]
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_legend_numeric_auto _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e4520>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_numeric_auto(self, long_df):
    
>       ax = barplot(long_df, x="x", y="y", hue="x")

tests/test_categorical.py:2214: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b7e5f9a0>
data =            y  hue
13 -0.588094    0
20 -1.164349    0
42 -1.275658    0
64 -0.348938    0
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_legend_numeric_full _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e59f0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_numeric_full(self, long_df):
    
>       ax = barplot(long_df, x="x", y="y", hue="x", legend="full")

tests/test_categorical.py:2219: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b35bfca0>
data =            y  hue
13 -0.588094    0
20 -1.164349    0
42 -1.275658    0
64 -0.348938    0
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestBarPlot.test_legend_disabled _______________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c0e72020>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_disabled(self, long_df):
    
>       ax = barplot(long_df, x="x", y="y", hue="b", legend=False)

tests/test_categorical.py:2226: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b19658d0>
data =            y hue
57  0.830906   m
59  1.594413   m, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
______________________ TestBarPlot.test_legend_attributes ______________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c251bf70>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_attributes(self, long_df):
    
        palette = color_palette()
>       ax = barplot(
            long_df, x="a", y="y", hue="c", saturation=1, edgecolor="k", linewidth=3
        )

tests/test_categorical.py:2280: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8ce8f10>
data =            y  hue
0   0.449243    0
13 -0.588094    0
18 -1.887821    0
22 -1.142441    0
23 -0.961407    0
30 -1.0439...761850    0
71 -1.187002    0
73 -0.236192    0
75  0.923673    0
85 -1.047659    0
88 -0.560961    0
93  0.101402    0
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestBarPlot.test_legend_unfilled _______________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c251baf0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_unfilled(self, long_df):
    
        palette = color_palette()
>       ax = barplot(long_df, x="a", y="y", hue="c", fill=False, linewidth=3)

tests/test_categorical.py:2291: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b9564550>
data =            y  hue
0   0.449243    0
13 -0.588094    0
18 -1.887821    0
22 -1.142441    0
23 -0.961407    0
30 -1.0439...761850    0
71 -1.187002    0
73 -0.236192    0
75  0.923673    0
85 -1.047659    0
88 -0.560961    0
93  0.101402    0
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs0] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c1f338e0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':                    a         b         c
wide_index                              
10          1.138955  0.611...7  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085, 'n_boot': 10, 'seed': 0}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8c68910>
data =            y hue
0   1.138955   a
1  -0.444096   a
2  -0.940288   a
3   0.903036   a
4   0.159529   a
5  -0.497166   a...
13  0.570761   a
14  0.340733   a
15  0.221587   a
16  0.982437   a
17  0.437267   a
18  0.137757   a
19  0.900535   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs1] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e4760>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':                    a         b         c
wide_index                              
10          1.138955  0.611...         0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085, 'n_boot': 10, 'orient': 'h', 'seed': 0}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b1417370>
data =            x hue
0   1.138955   a
1  -0.444096   a
2  -0.940288   a
3   0.903036   a
4   0.159529   a
5  -0.497166   a...
13  0.570761   a
14  0.340733   a
15  0.221587   a
16  0.982437   a
17  0.437267   a
18  0.137757   a
19  0.900535   a
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs3] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e7520>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...3484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'n_boot': 10, 'seed': 0, 'x': 'a', ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3dfabc0>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs4] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e7850>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data': None, 'n_boot': 10, 'seed': 0, 'x': 0     b
1     b
2     a
3     a
4     b
     ..
95    a
96    a
97    a
98    a
99    c
Name: a, Length: 100, dtype: object, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2a1c4c0>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs5] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e70d0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'a', 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3baf1f0>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
15  1.670946   b...
73 -0.236192   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
92  0.512806   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs6] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e62f0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data': None, 'hue': 0     b
1     b
2     a
3     a
4     b
     ..
95    a
96    a
97    a
98    a
99    c
Name: a, Length: 100, dtype: object, 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b6347400>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
15  1.670946   b...
73 -0.236192   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
92  0.512806   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs7] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e67a0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'b', 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b7e72080>
data =            y hue
0   0.449243   p
15  1.670946   p
26 -1.993027   p
31 -1.463693   p
32 -1.153562   p
47 -0.853833   p
48  0.510687   p
51 -1.296145   p
53  1.477263   p
55  0.964998   p
63 -0.418434   p
93  0.101402   p
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs8] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e64d0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data': None, 'hue': 0     b
1     b
2     a
3     a
4     b
     ..
95    a
96    a
97    a
98    a
99    c
Name: a, Length: 100, dtype: object, 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b5d6b340>
data =            y hue
0   0.449243   b
1   0.434942   b
14 -1.665427   b
23 -0.961407   b
26 -1.993027   b
27 -0.002220   b
48  0.510687   b
51 -1.296145   b
55  0.964998   b
66  0.284743   b
87  0.180705   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestBarPlot.test_vs_catplot[kwargs9] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e72b0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 's', 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8c09a20>
data =            y  hue
0   0.449243    2
1   0.434942    2
14 -1.665427    2
23 -0.961407    2
26 -1.993027    2
27 -0.002220    2
48  0.510687    2
51 -1.296145    2
55  0.964998    2
66  0.284743    2
87  0.180705    2
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestBarPlot.test_vs_catplot[kwargs10] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e7310>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'n_boot': 10, 'seed': 0, 'units': 'c', ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b9005ae0>
data =            y  units
0   0.449243      0
1   0.434942      1
4  -1.253690      1
13 -0.588094      0
14 -1.665427      ...75  0.923673      0
85 -1.047659      0
87  0.180705      1
88 -0.560961      0
92  0.512806      1
93  0.101402      0
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestBarPlot.test_vs_catplot[kwargs11] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c24e6e00>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b  ...6343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns], 'fill': False, 'gap': 0.1, 'hue': 'a', ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b5d81540>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
18 -1.887821   b...
67 -1.941020   b
71 -1.187002   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestBarPlot.test_vs_catplot[kwargs12] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c251ad70>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...3  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'a', 'n_boot': 10, 'native_scale': True, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3746c20>
data =            y hue
0   0.449243   b
1   0.434942   b
14 -1.665427   b
23 -0.961407   b
26 -1.993027   b
27 -0.002220   b
48  0.510687   b
51 -1.296145   b
55  0.964998   b
66  0.284743   b
87  0.180705   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestBarPlot.test_vs_catplot[kwargs13] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c251b190>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...3  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'a', 'n_boot': 10, 'native_scale': True, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3f9e920>
data =            y hue
0   0.449243   b
4  -1.253690   b
14 -1.665427   b
22 -1.142441   b
23 -0.961407   b
32 -1.153562   b
55  0.964998   b
60  0.221596   b
66  0.284743   b
67 -1.941020   b
88 -0.560961   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestBarPlot.test_vs_catplot[kwargs16] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c251b970>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'capsize': 0.3, 'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886 ...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'err_kws': {'c': 'k'}, 'n_boot': 10, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2b2db10>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestBarPlot.test_vs_catplot[kwargs17] _____________________

self = <tests.test_categorical.TestBarPlot object at 0x7442c251ba30>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'alpha': 0.5, 'color': 'blue', 'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.44...
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'edgecolor': 'green', ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a", gap=.1, fill=False),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", edgecolor="green", alpha=.5),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = barplot(**kwargs)

tests/test_categorical.py:2349: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2cc4340>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
______________________ TestPointPlot.test_labels_long[x] _______________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e66d70>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_labels_long(self, long_df, orient):
    
        depend = {"x": "y", "y": "x"}[orient]
        kws = {orient: "a", depend: "y", "hue": "b"}
    
>       ax = self.func(long_df, **kws)

tests/test_categorical.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8f46200>
data =            y hue
0   0.449243   p
15  1.670946   p
26 -1.993027   p
31 -1.463693   p
32 -1.153562   p
47 -0.853833   p
48  0.510687   p
51 -1.296145   p
53  1.477263   p
55  0.964998   p
63 -0.418434   p
93  0.101402   p
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
______________________ TestPointPlot.test_labels_long[y] _______________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e67ca0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_labels_long(self, long_df, orient):
    
        depend = {"x": "y", "y": "x"}[orient]
        kws = {orient: "a", depend: "y", "hue": "b"}
    
>       ax = self.func(long_df, **kws)

tests/test_categorical.py:128: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442c251b490>
data =            x hue
0   0.449243   p
15  1.670946   p
26 -1.993027   p
31 -1.463693   p
32 -1.153562   p
47 -0.853833   p
48  0.510687   p
51 -1.296145   p
53  1.477263   p
55  0.964998   p
63 -0.418434   p
93  0.101402   p
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestPointPlot.test_labels_wide ________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e67490>
wide_df = cols               a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330

    def test_labels_wide(self, wide_df):
    
        wide_df = wide_df.rename_axis("cols", axis=1)
>       ax = self.func(wide_df)

tests/test_categorical.py:151: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b34b07f0>
data =            y hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestPointPlot.test_labels_hue_order ______________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e67cd0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_labels_hue_order(self, long_df):
    
        hue_var = "b"
        hue_order = categorical_order(long_df[hue_var])[::-1]
>       ax = self.func(long_df, x="a", y="y", hue=hue_var, hue_order=hue_order)

tests/test_categorical.py:165: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b15995d0>
data =            y hue
4  -1.253690   m
13 -0.588094   m
14 -1.665427   m
18 -1.887821   m
22 -1.142441   m
23 -0.961407   m...
66  0.284743   m
67 -1.941020   m
71 -1.187002   m
73 -0.236192   m
85 -1.047659   m
87  0.180705   m
88 -0.560961   m
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________________ TestPointPlot.test_color ___________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e67d30>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
common_kws = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'x': 'a', 'y': 'y'}

    def test_color(self, long_df, common_kws):
        common_kws.update(data=long_df, x="a", y="y")
    
        ax = plt.figure().subplots()
>       self.func(ax=ax, **common_kws)

tests/test_categorical.py:174: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8c0a710>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_redundant_hue_legend ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e654b0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_redundant_hue_legend(self, long_df):
    
>       ax = self.func(long_df, x="a", y="y", hue="a")

tests/test_categorical.py:199: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b6371810>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
15  1.670946   b...
73 -0.236192   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
92  0.512806   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestPointPlot.test_log_scale[x] ________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e64bb0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_log_scale(self, long_df, orient):
    
        depvar = {"x": "y", "y": "x"}[orient]
        variables = {orient: "a", depvar: "z"}
>       ax = self.func(long_df, **variables, log_scale=True)

tests/test_categorical.py:211: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8f722c0>
data =            y
0   0.820325
1   0.412046
4  -0.108566
13  0.397591
14 -0.390247
15 -0.568648
18 -0.029830
22 -0.352084
2...46
68  0.897790
71 -0.381510
73  1.139125
75  0.110125
85  0.746051
87 -0.057316
88 -0.912423
92 -0.437689
93 -0.124632
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestPointPlot.test_log_scale[y] ________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e64af0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_log_scale(self, long_df, orient):
    
        depvar = {"x": "y", "y": "x"}[orient]
        variables = {orient: "a", depvar: "z"}
>       ax = self.func(long_df, **variables, log_scale=True)

tests/test_categorical.py:211: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442c24e7250>
data =            x
0   0.820325
1   0.412046
4  -0.108566
13  0.397591
14 -0.390247
15 -0.568648
18 -0.029830
22 -0.352084
2...46
68  0.897790
71 -0.381510
73  1.139125
75  0.110125
85  0.746051
87 -0.057316
88 -0.912423
92 -0.437689
93 -0.124632
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestPointPlot.test_single_var[x] _______________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f17e0>
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_single_var(self, orient):
    
        vals = pd.Series([1, 3, 10])
>       ax = pointplot(**{orient: vals})

tests/test_categorical.py:2406: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bcf2a860>
data =       x
0   1.0
1   3.0
2  10.0, var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________________ TestPointPlot.test_single_var[y] _______________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f1420>
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y"])
    def test_single_var(self, orient):
    
        vals = pd.Series([1, 3, 10])
>       ax = pointplot(**{orient: vals})

tests/test_categorical.py:2406: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b0c95fc0>
data =       y
0   1.0
1   3.0
2  10.0, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestPointPlot.test_wide_df[x] _________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f2ec0>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'x'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = pointplot(wide_df, orient=orient)

tests/test_categorical.py:2413: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442c2519480>
data =            y hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestPointPlot.test_wide_df[y] _________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f3130>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'y'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = pointplot(wide_df, orient=orient)

tests/test_categorical.py:2413: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b36ecaf0>
data =            x hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestPointPlot.test_wide_df[h] _________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f34c0>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'h'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = pointplot(wide_df, orient=orient)

tests/test_categorical.py:2413: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3204160>
data =            x hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestPointPlot.test_wide_df[v] _________________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f3580>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
orient = 'v'

    @pytest.mark.parametrize("orient", ["x", "y", "h", "v"])
    def test_wide_df(self, wide_df, orient):
    
>       ax = pointplot(wide_df, orient=orient)

tests/test_categorical.py:2413: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b91a4d90>
data =            y hue
0   1.449377   a
1   0.004240   a
2  -2.220108   a
3   0.091650   a
4  -0.838704   a
5   0.128181   a...
13  0.085121   a
14 -0.984643   a
15 -0.203013   a
16  0.850129   a
17 -0.305246   a
18  0.272567   a
19  0.813041   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestPointPlot.test_weighted_estimate _____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f1180>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_weighted_estimate(self, long_df):
    
>       ax = pointplot(long_df, y="y", weights="x")

tests/test_categorical.py:2512: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.WeightedAggregator object at 0x7442b40d1570>
data =            y  weight
0   0.449243      12
1   0.434942      15
2   1.429015       3
3  -0.352296      18
4  -1.253690 ...018       2
96 -0.152851       4
97 -0.912663      16
98 -1.212684      14
99  0.073484      15

[100 rows x 2 columns]
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        weights = data["weight"]
    
        estimate = np.average(vals, weights=weights)
    
        if self.error_method == "ci" and len(data) > 1:
    
            def error_func(x, w):
                return np.average(x, weights=w)
    
>           boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:570: NameError
__________________ TestPointPlot.test_estimate_log_transform ___________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c24f0a00>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_estimate_log_transform(self, long_df):
    
        ax = mpl.figure.Figure().subplots()
        ax.set_xscale("log")
>       pointplot(x=long_df["z"], ax=ax)

tests/test_categorical.py:2521: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b7e78550>
data =            x
0   0.820325
1   0.412046
2   0.628582
3   0.606000
4  -0.108566
..       ...
95 -0.139198
96 -0.407996
97  0.151782
98  0.868213
99  0.015504

[100 rows x 1 columns]
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs0] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c25198a0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':                    a         b         c
wide_index                              
10          1.138955  0.611...7  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085, 'n_boot': 10, 'seed': 0}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b37003a0>
data =            y hue
0   1.138955   a
1  -0.444096   a
2  -0.940288   a
3   0.903036   a
4   0.159529   a
5  -0.497166   a...
13  0.570761   a
14  0.340733   a
15  0.221587   a
16  0.982437   a
17  0.437267   a
18  0.137757   a
19  0.900535   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs1] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e65fc0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':                    a         b         c
wide_index                              
10          1.138955  0.611...         0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085, 'n_boot': 10, 'orient': 'h', 'seed': 0}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b308dcf0>
data =            x hue
0   1.138955   a
1  -0.444096   a
2  -0.940288   a
3   0.903036   a
4   0.159529   a
5  -0.497166   a...
13  0.570761   a
14  0.340733   a
15  0.221587   a
16  0.982437   a
17  0.437267   a
18  0.137757   a
19  0.900535   a
var = 'x'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs3] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e66140>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...3484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'n_boot': 10, 'seed': 0, 'x': 'a', ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2a06bf0>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs4] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e661a0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data': None, 'n_boot': 10, 'seed': 0, 'x': 0     b
1     b
2     a
3     a
4     b
     ..
95    a
96    a
97    a
98    a
99    c
Name: a, Length: 100, dtype: object, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3177550>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs5] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e65cc0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'a', 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3d654b0>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
15  1.670946   b...
73 -0.236192   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
92  0.512806   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs6] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e650c0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data': None, 'hue': 0     b
1     b
2     a
3     a
4     b
     ..
95    a
96    a
97    a
98    a
99    c
Name: a, Length: 100, dtype: object, 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b95679a0>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
15  1.670946   b...
73 -0.236192   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
92  0.512806   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs7] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e652d0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'b', 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b812bb50>
data =            y hue
0   0.449243   p
15  1.670946   p
26 -1.993027   p
31 -1.463693   p
32 -1.153562   p
47 -0.853833   p
48  0.510687   p
51 -1.296145   p
53  1.477263   p
55  0.964998   p
63 -0.418434   p
93  0.101402   p
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs8] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e651e0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data': None, 'hue': 0     b
1     b
2     a
3     a
4     b
     ..
95    a
96    a
97    a
98    a
99    c
Name: a, Length: 100, dtype: object, 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b37ce110>
data =            y hue
0   0.449243   b
1   0.434942   b
14 -1.665427   b
23 -0.961407   b
26 -1.993027   b
27 -0.002220   b
48  0.510687   b
51 -1.296145   b
55  0.964998   b
66  0.284743   b
87  0.180705   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________________ TestPointPlot.test_vs_catplot[kwargs9] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e656f0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 's', 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2906140>
data =            y  hue
0   0.449243    2
1   0.434942    2
14 -1.665427    2
23 -0.961407    2
26 -1.993027    2
27 -0.002220    2
48  0.510687    2
51 -1.296145    2
55  0.964998    2
66  0.284743    2
87  0.180705    2
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs10] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e65750>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'n_boot': 10, 'seed': 0, 'units': 'c', ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8f46380>
data =            y  units
0   0.449243      0
1   0.434942      1
4  -1.253690      1
13 -0.588094      0
14 -1.665427      ...75  0.923673      0
85 -1.047659      0
87  0.180705      1
88 -0.560961      0
92  0.512806      1
93  0.101402      0
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs11] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e66290>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b  ...036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns], 'hue': 'a', 'n_boot': 10, 'seed': 0, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3176380>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
18 -1.887821   b...
67 -1.941020   b
71 -1.187002   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs12] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e65b10>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...3  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'a', 'n_boot': 10, 'native_scale': True, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3d640a0>
data =            y hue
0   0.449243   b
1   0.434942   b
14 -1.665427   b
23 -0.961407   b
26 -1.993027   b
27 -0.002220   b
48  0.510687   b
51 -1.296145   b
55  0.964998   b
66  0.284743   b
87  0.180705   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs13] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e66200>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...3  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'a', 'n_boot': 10, 'native_scale': True, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b1416860>
data =            y hue
0   0.449243   b
4  -1.253690   b
14 -1.665427   b
22 -1.142441   b
23 -0.961407   b
32 -1.153562   b
55  0.964998   b
60  0.221596   b
66  0.284743   b
67 -1.941020   b
88 -0.560961   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs16] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e66b90>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b  ...43    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns], 'dodge': True, 'hue': 'a', 'n_boot': 10, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bbcc6260>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
18 -1.887821   b...
67 -1.941020   b
71 -1.187002   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs17] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e66b30>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b  ...343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns], 'dodge': 0.2, 'hue': 'a', 'n_boot': 10, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b87ef100>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
18 -1.887821   b...
67 -1.941020   b
71 -1.187002   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs18] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e67220>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'capsize': 0.3, 'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886 ...84  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'err_kws': {'c': 'k'}, 'n_boot': 10, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b3821510>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs19] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e64f10>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'color': 'blue', 'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886...  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'marker': 's', 'n_boot': 10, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b308ffd0>
data =            y
0   0.449243
1   0.434942
4  -1.253690
13 -0.588094
14 -1.665427
15  1.670946
18 -1.887821
22 -1.142441
2...20
68 -0.761850
71 -1.187002
73 -0.236192
75  0.923673
85 -1.047659
87  0.180705
88 -0.560961
92  0.512806
93  0.101402
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestPointPlot.test_vs_catplot[kwargs20] ____________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c1e65120>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
wide_df =                    a         b         c
wide_index                              
10          1.138955  0.611984  0.36...         0.437267 -1.171857  0.563007
46          0.137757  0.499660 -1.076471
48          0.900535 -0.792074  0.919085
null_df =        x         y         z    a    b  ...    s    f a_cat  s_cat  s_str
0   12.0  0.449243  6.611886    b    p  ... ...     a      8      8
99  15.0  0.073484  1.036343    c    p  ...  8.0  0.2   NaN      8      8

[100 rows x 13 columns]
flat_series = t
10    2.974006
11   -3.326995
12   -1.100871
13   -2.041894
14    0.514232
15   -1.269216
16   -0.739240
17   -0.310...61541
24    0.657532
25    0.463810
26   -0.969253
27    0.344289
28    2.045099
29   -0.822459
Name: s, dtype: float64
kwargs = {'data':      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0...p  ...  8  0.2     c      8      8

[100 rows x 13 columns], 'hue': 'a', 'markers': ['s', 'd', 'p'], 'n_boot': 10, ...}

    @pytest.mark.parametrize(
        "kwargs",
        [
            dict(data="wide"),
            dict(data="wide", orient="h"),
            dict(data="flat"),
            dict(data="long", x="a", y="y"),
            dict(data=None, x="a", y="y"),
            dict(data="long", x="a", y="y", hue="a"),
            dict(data=None, x="a", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="b"),
            dict(data=None, x="s", y="y", hue="a"),
            dict(data="long", x="a", y="y", hue="s"),
            dict(data="long", x="a", y="y", units="c"),
            dict(data="null", x="a", y="y", hue="a"),
            dict(data="long", x="s", y="y", hue="a", native_scale=True),
            dict(data="long", x="d", y="y", hue="a", native_scale=True),
            dict(data="long", x="a", y="y", errorbar=("pi", 50)),
            dict(data="long", x="a", y="y", errorbar=None),
            dict(data="null", x="a", y="y", hue="a", dodge=True),
            dict(data="null", x="a", y="y", hue="a", dodge=.2),
            dict(data="long", x="a", y="y", capsize=.3, err_kws=dict(c="k")),
            dict(data="long", x="a", y="y", color="blue", marker="s"),
            dict(data="long", x="a", y="y", hue="a", markers=["s", "d", "p"]),
        ]
    )
    def test_vs_catplot(self, long_df, wide_df, null_df, flat_series, kwargs):
    
        kwargs = kwargs.copy()
        kwargs["seed"] = 0
        kwargs["n_boot"] = 10
    
        if kwargs["data"] == "long":
            kwargs["data"] = long_df
        elif kwargs["data"] == "wide":
            kwargs["data"] = wide_df
        elif kwargs["data"] == "flat":
            kwargs["data"] = flat_series
        elif kwargs["data"] == "null":
            kwargs["data"] = null_df
        elif kwargs["data"] is None:
            for var in ["x", "y", "hue"]:
                if var in kwargs:
                    kwargs[var] = long_df[kwargs[var]]
    
>       ax = pointplot(**kwargs)

tests/test_categorical.py:2711: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b8bf2170>
data =            y hue
0   0.449243   b
1   0.434942   b
4  -1.253690   b
13 -0.588094   b
14 -1.665427   b
15  1.670946   b...
73 -0.236192   b
75  0.923673   b
85 -1.047659   b
87  0.180705   b
88 -0.560961   b
92  0.512806   b
93  0.101402   b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
______________________ TestPointPlot.test_legend_disabled ______________________

self = <tests.test_categorical.TestPointPlot object at 0x7442c251a530>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_disabled(self, long_df):
    
>       ax = pointplot(long_df, x="x", y="y", hue="b", legend=False)

tests/test_categorical.py:2718: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2527: in pointplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b0aa2ec0>
data =            y hue
57  0.830906   m
59  1.594413   m, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________________ TestCatPlot.test_plot_elements ________________________

self = <tests.test_categorical.TestCatPlot object at 0x7442c1e87c40>

    def test_plot_elements(self):
    
>       g = cat.catplot(x="g", y="y", data=self.df, kind="point")

tests/test_categorical.py:2962: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:3054: in catplot
    p.plot_points(
seaborn/categorical.py:1217: in plot_points
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b2c5b040>
data =            y
0  -1.581995
1  -1.243114
2  -0.410169
3  -1.055075
4  -1.057312
5  -1.284117
6   0.913126
7  -1.387745
8...33
11 -0.460026
12 -0.173413
13 -0.216655
14 -0.259935
15  0.566293
16  0.990522
17 -0.594763
18  0.343463
19 -2.589323
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________________ TestCatPlot.test_plot_colors _________________________

self = <tests.test_categorical.TestCatPlot object at 0x7442c1e86860>

    def test_plot_colors(self):
    
>       ax = cat.barplot(x="g", y="y", data=self.df)

tests/test_categorical.py:3036: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:2391: in barplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442aed60070>
data =            y
0  -1.581995
1  -1.243114
2  -0.410169
3  -1.055075
4  -1.057312
5  -1.284117
6   0.913126
7  -1.387745
8...33
11 -0.460026
12 -0.173413
13 -0.216655
14 -0.259935
15  0.566293
16  0.990522
17 -0.594763
18  0.343463
19 -2.589323
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________________________ TestCatPlot.test_share_xy ___________________________

self = <tests.test_categorical.TestCatPlot object at 0x7442c1e85000>

    def test_share_xy(self):
    
        # Test default behavior works
        g = cat.catplot(x="g", y="y", col="g", data=self.df, sharex=True)
        for ax in g.axes.flat:
            assert len(ax.collections) == len(self.df.g.unique())
    
        g = cat.catplot(x="y", y="g", col="g", data=self.df, sharey=True)
        for ax in g.axes.flat:
            assert len(ax.collections) == len(self.df.g.unique())
    
        # Test unsharing works
>       g = cat.catplot(
            x="g", y="y", col="g", data=self.df, sharex=False, kind="bar",
        )

tests/test_categorical.py:3096: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/categorical.py:3078: in catplot
    p.plot_bars(
seaborn/categorical.py:1288: in plot_bars
    sub_data
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442bbf10b50>
data =            y col
0  -1.581995   a
1  -1.243114   a
2  -0.410169   a
3  -1.055075   a
4  -1.057312   a
5  -1.284117   a...
13 -0.216655   a
14 -0.259935   a
15  0.566293   a
16  0.990522   a
17 -0.594763   a
18  0.343463   a
19 -2.589323   a
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________________ TestRelationalPlotter.test_relplot_simple ___________________

self = <tests.test_relational.TestRelationalPlotter object at 0x7442c152e0e0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_relplot_simple(self, long_df):
    
        g = relplot(data=long_df, x="x", y="y", kind="scatter")
        x, y = g.ax.collections[0].get_offsets().T
        assert_array_equal(x, long_df["x"])
        assert_array_equal(y, long_df["y"])
    
>       g = relplot(data=long_df, x="x", y="y", kind="line")

tests/test_relational.py:457: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:838: in relplot
    g.map_dataframe(func, **plot_kws)
seaborn/axisgrid.py:825: in map_dataframe
    self._facet_plot(func, ax, args, kwargs)
seaborn/axisgrid.py:854: in _facet_plot
    func(*plot_args, **plot_kwargs)
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a7280eb0>
data =            y
42 -1.275658
20 -1.164349
13 -0.588094
64 -0.348938
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________ TestRelationalPlotter.test_relplot_weighted_estimator _____________

self = <tests.test_relational.TestRelationalPlotter object at 0x7442c25ea7a0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_relplot_weighted_estimator(self, long_df):
    
>       g = relplot(data=long_df, x="a", y="y", weights="x", kind="line")

tests/test_relational.py:583: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:838: in relplot
    g.map_dataframe(func, **plot_kws)
seaborn/axisgrid.py:825: in map_dataframe
    self._facet_plot(func, ax, args, kwargs)
seaborn/axisgrid.py:854: in _facet_plot
    func(*plot_args, **plot_kwargs)
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.WeightedAggregator object at 0x7442ad2da710>
data =            y  weight
26 -1.993027       1
67 -1.941020       5
18 -1.887821      11
61 -1.714509       4
14 -1.665427 ...512806      12
57  0.830906       2
75  0.923673       5
55  0.964998       8
53  1.477263       5
15  1.670946       2
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        weights = data["weight"]
    
        estimate = np.average(vals, weights=weights)
    
        if self.error_method == "ci" and len(data) > 1:
    
            def error_func(x, w):
                return np.average(x, weights=w)
    
>           boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:570: NameError
__________________________ TestLinePlotter.test_color __________________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c0ec0e20>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_color(self, long_df):
    
        ax = plt.figure().subplots()
>       self.func(data=long_df, x="x", y="y", ax=ax)

tests/test_relational.py:75: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a86648e0>
data =            y
42 -1.275658
20 -1.164349
13 -0.588094
64 -0.348938
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestLinePlotter.test_legend_no_semantics ___________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25ea4d0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_no_semantics(self, long_df):
    
>       ax = lineplot(long_df, x="x", y="y")

tests/test_relational.py:750: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a772ab30>
data =            y
42 -1.275658
20 -1.164349
13 -0.588094
64 -0.348938
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________ TestLinePlotter.test_legend_hue_categorical __________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e8580>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
levels = {'a': ['b', 'a', 'c'], 'b': ['p', 'n', 'o', 'm']}

    def test_legend_hue_categorical(self, long_df, levels):
    
>       ax = lineplot(long_df, x="x", y="y", hue="a")

tests/test_relational.py:756: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a7a50820>
data =            y hue
26 -1.993027   b
45 -1.011639   b, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________ TestLinePlotter.test_legend_hue_and_style_same ________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e8af0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
levels = {'a': ['b', 'a', 'c'], 'b': ['p', 'n', 'o', 'm']}

    def test_legend_hue_and_style_same(self, long_df, levels):
    
>       ax = lineplot(long_df, x="x", y="y", hue="a", style="a", markers=True)

tests/test_relational.py:764: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a7a44580>
data =            y hue style
26 -1.993027   b     b
45 -1.011639   b     b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________ TestLinePlotter.test_legend_hue_and_style_diff ________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e98d0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
levels = {'a': ['b', 'a', 'c'], 'b': ['p', 'n', 'o', 'm']}

    def test_legend_hue_and_style_diff(self, long_df, levels):
    
>       ax = lineplot(long_df, x="x", y="y", hue="a", style="b", markers=True)

tests/test_relational.py:774: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a79fb3d0>
data =            y hue style
32 -1.153562   b     p
48  0.510687   b     p
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
________________ TestLinePlotter.test_legend_hue_and_size_same _________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e9510>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
levels = {'a': ['b', 'a', 'c'], 'b': ['p', 'n', 'o', 'm']}

    def test_legend_hue_and_size_same(self, long_df, levels):
    
>       ax = lineplot(long_df, x="x", y="y", hue="a", size="a")

tests/test_relational.py:793: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a7a645b0>
data =            y hue size
26 -1.993027   b    b
45 -1.011639   b    b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestLinePlotter.test_legend_value_error ____________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c152d720>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_value_error(self, long_df):
    
        with pytest.raises(ValueError, match=r"`legend` must be"):
>           lineplot(long_df, x="x", y="y", hue="a", legend="bad_value")

tests/test_relational.py:831: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a6cf3b80>
data =            y hue
26 -1.993027   b
45 -1.011639   b, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
____________ TestLinePlotter.test_legend_binary_numberic_brief[hue] ____________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e84c0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
var = 'hue'

    @pytest.mark.parametrize("var", ["hue", "size"])
    def test_legend_binary_numberic_brief(self, long_df, var):
    
>       ax = lineplot(long_df, x="x", y="y", **{var: "f"}, legend="brief")

tests/test_relational.py:857: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a6e534c0>
data =            y  hue
13 -0.588094  0.2
64 -0.348938  0.2, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________ TestLinePlotter.test_legend_binary_numberic_brief[size] ____________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e8fa0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
var = 'size'

    @pytest.mark.parametrize("var", ["hue", "size"])
    def test_legend_binary_numberic_brief(self, long_df, var):
    
>       ax = lineplot(long_df, x="x", y="y", **{var: "f"}, legend="brief")

tests/test_relational.py:857: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a9fcee00>
data =            y  size
13 -0.588094   0.2
64 -0.348938   0.2, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________________________ TestLinePlotter.test_plot ___________________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e8d90>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
repeated_df =      x         y  a  u
0    0  1.138955  b  0
1    1  0.611984  a  0
2    2  0.362212  a  0
3    3 -0.444096  b  0
4  ...  1
96  46  0.160388  c  1
97  47  0.374262  c  1
98  48  0.262556  a  1
99  49 -0.721693  a  1

[100 rows x 4 columns]

    def test_plot(self, long_df, repeated_df):
    
        f, ax = plt.subplots()
    
        p = _LinePlotter(
            data=long_df,
            variables=dict(x="x", y="y"),
            sort=False,
            estimator=None
        )
        p.plot(ax, {})
        line, = ax.lines
        assert_array_equal(line.get_xdata(), long_df.x.to_numpy())
        assert_array_equal(line.get_ydata(), long_df.y.to_numpy())
    
        ax.clear()
        p.plot(ax, {"color": "k", "label": "test"})
        line, = ax.lines
        assert line.get_color() == "k"
        assert line.get_label() == "test"
    
        p = _LinePlotter(
            data=long_df,
            variables=dict(x="x", y="y"),
            sort=True, estimator=None
        )
    
        ax.clear()
        p.plot(ax, {})
        line, = ax.lines
        sorted_data = long_df.sort_values(["x", "y"])
        assert_array_equal(line.get_xdata(), sorted_data.x.to_numpy())
        assert_array_equal(line.get_ydata(), sorted_data.y.to_numpy())
    
        p = _LinePlotter(
            data=long_df,
            variables=dict(x="x", y="y", hue="a"),
        )
    
        ax.clear()
        p.plot(ax, {})
        assert len(ax.lines) == len(p._hue_map.levels)
        for line, level in zip(ax.lines, p._hue_map.levels):
            assert line.get_color() == p._hue_map(level)
    
        p = _LinePlotter(
            data=long_df,
            variables=dict(x="x", y="y", size="a"),
        )
    
        ax.clear()
        p.plot(ax, {})
        assert len(ax.lines) == len(p._size_map.levels)
        for line, level in zip(ax.lines, p._size_map.levels):
            assert line.get_linewidth() == p._size_map(level)
    
        p = _LinePlotter(
            data=long_df,
            variables=dict(x="x", y="y", hue="a", style="a"),
        )
        p.map_style(markers=True)
    
        ax.clear()
        p.plot(ax, {})
        assert len(ax.lines) == len(p._hue_map.levels)
        assert len(ax.lines) == len(p._style_map.levels)
        for line, level in zip(ax.lines, p._hue_map.levels):
            assert line.get_color() == p._hue_map(level)
            assert line.get_marker() == p._style_map(level, "marker")
    
        p = _LinePlotter(
            data=long_df,
            variables=dict(x="x", y="y", hue="a", style="b"),
        )
        p.map_style(markers=True)
    
        ax.clear()
        p.plot(ax, {})
        levels = product(p._hue_map.levels, p._style_map.levels)
        expected_line_count = len(p._hue_map.levels) * len(p._style_map.levels)
        assert len(ax.lines) == expected_line_count
        for line, (hue, style) in zip(ax.lines, levels):
            assert line.get_color() == p._hue_map(hue)
            assert line.get_marker() == p._style_map(style, "marker")
    
        p = _LinePlotter(
            data=long_df,
            variables=dict(x="x", y="y"),
            estimator="mean", err_style="band", errorbar="sd", sort=True
        )
    
        ax.clear()
        p.plot(ax, {})
        line, = ax.lines
        expected_data = long_df.groupby("x").y.mean()
        assert_array_equal(line.get_xdata(), expected_data.index.to_numpy())
        assert np.allclose(line.get_ydata(), expected_data.to_numpy())
        assert len(ax.collections) == 1
    
        # Test that nans do not propagate to means or CIs
    
        p = _LinePlotter(
            variables=dict(
                x=[1, 1, 1, 2, 2, 2, 3, 3, 3],
                y=[1, 2, 3, 3, np.nan, 5, 4, 5, 6],
            ),
            estimator="mean", err_style="band", errorbar="ci", n_boot=100, sort=True,
        )
        ax.clear()
>       p.plot(ax, {})

tests/test_relational.py:971: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a9089000>
data =      y
0  1.0
1  2.0
2  3.0, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_________________________ TestLinePlotter.test_weights _________________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e86d0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_weights(self, long_df):
    
>       ax = lineplot(long_df, x="a", y="y", weights="x")

tests/test_relational.py:1073: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.WeightedAggregator object at 0x7442a6918280>
data =            y  weight
26 -1.993027       1
67 -1.941020       5
18 -1.887821      11
61 -1.714509       4
14 -1.665427 ...512806      12
57  0.830906       2
75  0.923673       5
55  0.964998       8
53  1.477263       5
15  1.670946       2
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        weights = data["weight"]
    
        estimate = np.average(vals, weights=weights)
    
        if self.error_method == "ci" and len(data) > 1:
    
            def error_func(x, w):
                return np.average(x, weights=w)
    
>           boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:570: NameError
____________________ TestLinePlotter.test_matplotlib_kwargs ____________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c2606800>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_matplotlib_kwargs(self, long_df):
    
        kws = {
            "linestyle": "--",
            "linewidth": 3,
            "color": (1, .5, .2),
            "markeredgecolor": (.2, .5, .2),
            "markeredgewidth": 1,
        }
>       ax = lineplot(data=long_df, x="x", y="y", **kws)

tests/test_relational.py:1169: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442adcd5600>
data =            y
42 -1.275658
20 -1.164349
13 -0.588094
64 -0.348938
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_______________ TestLinePlotter.test_legend_attributes_with_hue ________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c0f67580>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_attributes_with_hue(self, long_df):
    
        kws = {"marker": "o", "linewidth": 3}
>       ax = lineplot(long_df, x="x", y="y", hue="a", **kws)

tests/test_relational.py:1197: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442af304130>
data =            y hue
26 -1.993027   b
45 -1.011639   b, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
______________ TestLinePlotter.test_legend_attributes_with_style _______________

self = <tests.test_relational.TestLinePlotter object at 0x7442c2604190>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_attributes_with_style(self, long_df):
    
        kws = {"color": "r", "marker": "o", "linewidth": 3}
>       ax = lineplot(long_df, x="x", y="y", style="a", **kws)

tests/test_relational.py:1208: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a6e6b3d0>
data =            y style
26 -1.993027     b
45 -1.011639     b, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_legend_attributes_with_hue_and_style ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c2604070>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_legend_attributes_with_hue_and_style(self, long_df):
    
        kws = {"marker": "o", "linewidth": 3}
>       ax = lineplot(long_df, x="x", y="y", hue="a", style="b", **kws)

tests/test_relational.py:1218: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442aa0849d0>
data =            y hue style
32 -1.153562   b     p
48  0.510687   b     p
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics0] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25eb4f0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442b7d39900>
data =            y
42 -1.275658
20 -1.164349
13 -0.588094
64 -0.348938
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics1] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25eaef0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'x': 't', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442afc22ad0>
data =            y
58 -0.295124
84 -0.224638, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics2] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25ea5c0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'x': 'a', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442ad114b80>
data =            y
26 -1.993027
67 -1.941020
18 -1.887821
61 -1.714509
14 -1.665427
31 -1.463693
51 -1.296145
4  -1.253690
7...43
1   0.434942
0   0.449243
48  0.510687
92  0.512806
57  0.830906
75  0.923673
55  0.964998
53  1.477263
15  1.670946
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics4] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25e9690>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'hue': 'a', 'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a7721f60>
data =            y hue
26 -1.993027   b
45 -1.011639   b, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics5] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25eac20>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'size': 'a', 'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a731ac50>
data =            y size
26 -1.993027    b
45 -1.011639    b, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics6] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25eb760>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'style': 'a', 'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a867f640>
data =            y style
26 -1.993027     b
45 -1.011639     b, var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics7] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c25eafe0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'hue': 's', 'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a6bd1870>
data =            y  hue
19 -0.596893    2
36 -0.246471    2
37  0.691292    2
59  1.594413    2
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics8] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c152e890>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'size': 's', 'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442aaebc520>
data =            y  size
19 -0.596893     2
36 -0.246471     2
37  0.691292     2
59  1.594413     2
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics9] ___________

self = <tests.test_relational.TestLinePlotter object at 0x7442c152e020>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'style': 's', 'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a6f329e0>
data =            y  style
19 -0.596893      2
36 -0.246471      2
37  0.691292      2
59  1.594413      2
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics10] __________

self = <tests.test_relational.TestLinePlotter object at 0x7442c152d870>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'hue': 'a', 'style': 'a', 'x': 'x', 'y': 'y'}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442aa80e2f0>
data =            y hue style
26 -1.993027   b     b
45 -1.011639   b     b
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
__________ TestLinePlotter.test_lineplot_vs_relplot[long_semantics11] __________

self = <tests.test_relational.TestLinePlotter object at 0x7442c152ceb0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
long_semantics = {'hue': 'a', 'size': 'b', 'style': 'b', 'x': 'x', ...}

    def test_lineplot_vs_relplot(self, long_df, long_semantics):
    
>       ax = lineplot(data=long_df, legend=False, **long_semantics)

tests/test_relational.py:1227: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a9490a00>
data =            y hue size style
32 -1.153562   b    p     p
48  0.510687   b    p     p
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestLinePlotter.test_lineplot_smoke ______________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c0f64340>
wide_df =                    a         b         c
wide_index                              
10          1.449377  0.547052 -1.23...        -0.305246 -1.329569  0.624981
46          0.272567 -0.936631 -0.986104
48          0.813041 -1.076465  0.829330
wide_array = array([[ 1.44937693,  0.54705238, -1.23849421],
       [ 0.0042397 ,  0.96104443, -0.06555753],
       [-2.22010765,  ...2956902,  0.62498133],
       [ 0.27256657, -0.93663117, -0.9861045 ],
       [ 0.81304077, -1.07646527,  0.82932958]])
wide_list_of_series = [0    -0.462414
1    -0.663266
2     0.272339
3    -0.202488
4    -1.320671
5     2.182511
6     0.416575
7    -0.4067...2296
9    -1.253690
10   -0.611071
11   -0.127162
12    1.658410
13    0.747224
14   -0.571759
Name: b, dtype: float64]
wide_list_of_arrays = [array([-0.46241397, -0.66326575,  0.27233885, -0.20248795, -1.3206712 ,
        2.18251053,  0.41657504, -0.40679557,...94239,  1.42901482, -0.35229582, -1.25368957,
       -0.61107077, -0.12716222,  1.65840991,  0.74722355, -0.57175876])]
wide_list_of_lists = [[-0.4624139668622383, -0.6632657450083369, 0.27233885054394685, -0.2024879527524557, -1.3206712007140675, 2.182510529...64863895, 0.43494239175560634, 1.4290148188482537, -0.3522958175702248, -1.2536895712130631, -0.6110707708089032, ...]]
flat_array = array([ 0.13830514, -0.10108545,  0.35369949, -0.58809377, -1.66542662,
        1.67094557,  0.42036328,  1.78859975, ...010368, -1.14244064, -0.96140692,  0.11880587,
       -0.15018541, -1.99302747, -0.00222044,  0.76400317,  0.12336583])
flat_series = t
10    0.138305
11   -0.101085
12    0.353699
13   -0.588094
14   -1.665427
15    1.670946
16    0.420363
17    1.788...61407
24    0.118806
25   -0.150185
26   -1.993027
27   -0.002220
28    0.764003
29    0.123366
Name: s, dtype: float64
flat_list = [0.13830514195442498, -0.1010854511471884, 0.35369948934987555, -0.5880937734015119, -1.6654266179669477, 1.6709455731532739, ...]
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0    6 -0.853013  0.551712  b  p  ...  2  0.3     b ...  2  0.2     a      2      2
99   1  0.321599  0.274270  c  n  ...  2  0.3     c      2      2

[100 rows x 13 columns]
null_df =        x         y         z  a  b  ...    s    f a_cat  s_cat  s_str
0    6.0 -0.853013  0.551712  b  p  ...  2.0  Na... 0.2     a      2      2
99   1.0  0.321599  0.274270  c  n  ...  2.0  NaN     c      2      2

[100 rows x 13 columns]
object_df =      x         y         z  a  b  ...  s    f a_cat s_cat s_str
0    6 -0.853013  0.551712  b  p  ...  2  0.3     b   ... ...  2  0.2     a     2     2
99   1  0.321599  0.274270  c  n  ...  2  0.3     c     2     2

[100 rows x 13 columns]

    def test_lineplot_smoke(
        self,
        wide_df, wide_array,
        wide_list_of_series, wide_list_of_arrays, wide_list_of_lists,
        flat_array, flat_series, flat_list,
        long_df, null_df, object_df
    ):
    
        f, ax = plt.subplots()
    
        lineplot(x=[], y=[])
        ax.clear()
    
        lineplot(data=wide_df)
        ax.clear()
    
        lineplot(data=wide_array)
        ax.clear()
    
        lineplot(data=wide_list_of_series)
        ax.clear()
    
        lineplot(data=wide_list_of_arrays)
        ax.clear()
    
        lineplot(data=wide_list_of_lists)
        ax.clear()
    
        lineplot(data=flat_series)
        ax.clear()
    
        lineplot(data=flat_array)
        ax.clear()
    
        lineplot(data=flat_list)
        ax.clear()
    
>       lineplot(x="x", y="y", data=long_df)

tests/test_relational.py:1276: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a71399f0>
data =            y
76 -2.100933
92 -1.306422
81 -0.286976
79 -0.060495
33  0.159203
93  0.193702
99  0.321599
55  0.357929
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
_____________________ TestLinePlotter.test_ci_deprecation ______________________

self = <tests.test_relational.TestLinePlotter object at 0x7442c0f67cd0>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_ci_deprecation(self, long_df):
    
        axs = plt.figure().subplots(2)
>       lineplot(data=long_df, x="x", y="y", errorbar=("ci", 95), seed=0, ax=axs[0])

tests/test_relational.py:1333: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/relational.py:515: in lineplot
    p.plot(ax, kwargs)
seaborn/relational.py:295: in plot
    grouped
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1821: in apply
    return self._python_apply_general(f, self._obj_with_exclusions)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1887: in _python_apply_general
    values, mutated = self._grouper.apply_groupwise(f, data, self.axis)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/ops.py:928: in apply_groupwise
    res = f(group)
/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/pandas/core/groupby/groupby.py:1811: in f
    return func(g, *args, **kwargs)
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442a7ac6530>
data =            y
42 -1.275658
20 -1.164349
13 -0.588094
64 -0.348938
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestEstimateAggregator.test_ci_errorbars ___________________

self = <tests.test_statistics.TestEstimateAggregator object at 0x7442c0f65690>
long_df =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]

    def test_ci_errorbars(self, long_df):
    
        agg = EstimateAggregator("mean", "ci", n_boot=100000, seed=0)
>       out = agg(long_df, "y")

tests/test_statistics.py:569: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.EstimateAggregator object at 0x7442afd99d80>
data =      x         y         z  a  b  ...  s    f a_cat  s_cat  s_str
0   12  0.449243  6.611886  b  p  ...  2  0.2     b ...  8  0.3     a      8      8
99  15  0.073484  1.036343  c  p  ...  8  0.2     c      8      8

[100 rows x 13 columns]
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        if callable(self.estimator):
            # You would think we could pass to vals.agg, and yet:
            # https://github.com/mwaskom/seaborn/issues/2943
            estimate = self.estimator(vals)
        else:
            estimate = vals.agg(self.estimator)
    
        # Options that produce no error bars
        if self.error_method is None:
            err_min = err_max = np.nan
        elif len(data) <= 1:
            err_min = err_max = np.nan
    
        # Generic errorbars from user-supplied function
        elif callable(self.error_method):
            err_min, err_max = self.error_method(vals)
    
        # Parametric options
        elif self.error_method == "sd":
            half_interval = vals.std() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
        elif self.error_method == "se":
            half_interval = vals.sem() * self.error_level
            err_min, err_max = estimate - half_interval, estimate + half_interval
    
        # Nonparametric options
        elif self.error_method == "pi":
            err_min, err_max = _percentile_interval(vals, self.error_level)
        elif self.error_method == "ci":
            units = data.get("units", None)
>           boots = bootstrap(vals, units=units, func=self.estimator, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:517: NameError
___________________ TestWeightedAggregator.test_weighted_ci ____________________

self = <tests.test_statistics.TestWeightedAggregator object at 0x7442c14de4a0>
long_df =      x         y         z  a  b  c  ...  s    f  a_cat  s_cat s_str weight
0   12  0.449243  6.611886  b  p  0  ...  ...    8     8     14
99  15  0.073484  1.036343  c  p  0  ...  8  0.2      c      8     8     15

[100 rows x 14 columns]

    def test_weighted_ci(self, long_df):
    
        long_df["weight"] = long_df["x"]
        est = WeightedAggregator("mean", "ci")
>       out = est(long_df, "y")

tests/test_statistics.py:652: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <seaborn._statistics.WeightedAggregator object at 0x7442ad5038e0>
data =      x         y         z  a  b  c  ...  s    f  a_cat  s_cat s_str weight
0   12  0.449243  6.611886  b  p  0  ...  ...    8     8     14
99  15  0.073484  1.036343  c  p  0  ...  8  0.2      c      8     8     15

[100 rows x 14 columns]
var = 'y'

    def __call__(self, data, var):
        """Aggregate over `var` column of `data` with estimate and error interval."""
        vals = data[var]
        weights = data["weight"]
    
        estimate = np.average(vals, weights=weights)
    
        if self.error_method == "ci" and len(data) > 1:
    
            def error_func(x, w):
                return np.average(x, weights=w)
    
>           boots = bootstrap(vals, weights, func=error_func, **self.boot_kws)
E           NameError: name 'bootstrap' is not defined

seaborn/_statistics.py:570: NameError
=========================== short test summary info ============================
FAILED tests/_stats/test_aggregation.py::TestEst::test_weighted_mean - NameEr...
FAILED tests/_stats/test_aggregation.py::TestEst::test_seed - NameError: name...
FAILED tests/test_axisgrid.py::TestFacetGrid::test_categorical_warning - Name...
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[barplot-kwargs4]
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[barplot-kwargs5]
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[barplot-kwargs6]
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[barplot-kwargs7]
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[pointplot-kwargs16]
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[pointplot-kwargs17]
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[pointplot-kwargs18]
FAILED tests/test_categorical.py::TestCategoricalPlotterNew::test_axis_labels[pointplot-kwargs19]
FAILED tests/test_categorical.py::TestBarPlot::test_labels_long[x] - NameErro...
FAILED tests/test_categorical.py::TestBarPlot::test_labels_long[y] - NameErro...
FAILED tests/test_categorical.py::TestBarPlot::test_labels_wide - NameError: ...
FAILED tests/test_categorical.py::TestBarPlot::test_labels_hue_order - NameEr...
FAILED tests/test_categorical.py::TestBarPlot::test_color - NameError: name '...
FAILED tests/test_categorical.py::TestBarPlot::test_redundant_hue_legend - Na...
FAILED tests/test_categorical.py::TestBarPlot::test_log_scale[x] - NameError:...
FAILED tests/test_categorical.py::TestBarPlot::test_log_scale[y] - NameError:...
FAILED tests/test_categorical.py::TestBarPlot::test_single_var[x] - NameError...
FAILED tests/test_categorical.py::TestBarPlot::test_single_var[y] - NameError...
FAILED tests/test_categorical.py::TestBarPlot::test_wide_df[x] - NameError: n...
FAILED tests/test_categorical.py::TestBarPlot::test_wide_df[y] - NameError: n...
FAILED tests/test_categorical.py::TestBarPlot::test_wide_df[h] - NameError: n...
FAILED tests/test_categorical.py::TestBarPlot::test_wide_df[v] - NameError: n...
FAILED tests/test_categorical.py::TestBarPlot::test_weighted_estimate - NameE...
FAILED tests/test_categorical.py::TestBarPlot::test_estimate_log_transform - ...
FAILED tests/test_categorical.py::TestBarPlot::test_legend_numeric_auto - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_legend_numeric_full - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_legend_disabled - NameErr...
FAILED tests/test_categorical.py::TestBarPlot::test_legend_attributes - NameE...
FAILED tests/test_categorical.py::TestBarPlot::test_legend_unfilled - NameErr...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs0] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs1] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs3] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs4] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs5] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs6] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs7] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs8] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs9] - Nam...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs10] - Na...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs11] - Na...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs12] - Na...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs13] - Na...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs16] - Na...
FAILED tests/test_categorical.py::TestBarPlot::test_vs_catplot[kwargs17] - Na...
FAILED tests/test_categorical.py::TestPointPlot::test_labels_long[x] - NameEr...
FAILED tests/test_categorical.py::TestPointPlot::test_labels_long[y] - NameEr...
FAILED tests/test_categorical.py::TestPointPlot::test_labels_wide - NameError...
FAILED tests/test_categorical.py::TestPointPlot::test_labels_hue_order - Name...
FAILED tests/test_categorical.py::TestPointPlot::test_color - NameError: name...
FAILED tests/test_categorical.py::TestPointPlot::test_redundant_hue_legend - ...
FAILED tests/test_categorical.py::TestPointPlot::test_log_scale[x] - NameErro...
FAILED tests/test_categorical.py::TestPointPlot::test_log_scale[y] - NameErro...
FAILED tests/test_categorical.py::TestPointPlot::test_single_var[x] - NameErr...
FAILED tests/test_categorical.py::TestPointPlot::test_single_var[y] - NameErr...
FAILED tests/test_categorical.py::TestPointPlot::test_wide_df[x] - NameError:...
FAILED tests/test_categorical.py::TestPointPlot::test_wide_df[y] - NameError:...
FAILED tests/test_categorical.py::TestPointPlot::test_wide_df[h] - NameError:...
FAILED tests/test_categorical.py::TestPointPlot::test_wide_df[v] - NameError:...
FAILED tests/test_categorical.py::TestPointPlot::test_weighted_estimate - Nam...
FAILED tests/test_categorical.py::TestPointPlot::test_estimate_log_transform
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs0] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs1] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs3] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs4] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs5] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs6] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs7] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs8] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs9] - N...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs10] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs11] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs12] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs13] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs16] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs17] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs18] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs19] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_vs_catplot[kwargs20] - ...
FAILED tests/test_categorical.py::TestPointPlot::test_legend_disabled - NameE...
FAILED tests/test_categorical.py::TestCatPlot::test_plot_elements - NameError...
FAILED tests/test_categorical.py::TestCatPlot::test_plot_colors - NameError: ...
FAILED tests/test_categorical.py::TestCatPlot::test_share_xy - NameError: nam...
FAILED tests/test_relational.py::TestRelationalPlotter::test_relplot_simple
FAILED tests/test_relational.py::TestRelationalPlotter::test_relplot_weighted_estimator
FAILED tests/test_relational.py::TestLinePlotter::test_color - NameError: nam...
FAILED tests/test_relational.py::TestLinePlotter::test_legend_no_semantics - ...
FAILED tests/test_relational.py::TestLinePlotter::test_legend_hue_categorical
FAILED tests/test_relational.py::TestLinePlotter::test_legend_hue_and_style_same
FAILED tests/test_relational.py::TestLinePlotter::test_legend_hue_and_style_diff
FAILED tests/test_relational.py::TestLinePlotter::test_legend_hue_and_size_same
FAILED tests/test_relational.py::TestLinePlotter::test_legend_value_error - N...
FAILED tests/test_relational.py::TestLinePlotter::test_legend_binary_numberic_brief[hue]
FAILED tests/test_relational.py::TestLinePlotter::test_legend_binary_numberic_brief[size]
FAILED tests/test_relational.py::TestLinePlotter::test_plot - NameError: name...
FAILED tests/test_relational.py::TestLinePlotter::test_weights - NameError: n...
FAILED tests/test_relational.py::TestLinePlotter::test_matplotlib_kwargs - Na...
FAILED tests/test_relational.py::TestLinePlotter::test_legend_attributes_with_hue
FAILED tests/test_relational.py::TestLinePlotter::test_legend_attributes_with_style
FAILED tests/test_relational.py::TestLinePlotter::test_legend_attributes_with_hue_and_style
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics0]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics1]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics2]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics4]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics5]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics6]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics7]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics8]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics9]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics10]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_vs_relplot[long_semantics11]
FAILED tests/test_relational.py::TestLinePlotter::test_lineplot_smoke - NameE...
FAILED tests/test_relational.py::TestLinePlotter::test_ci_deprecation - NameE...
FAILED tests/test_statistics.py::TestEstimateAggregator::test_ci_errorbars - ...
FAILED tests/test_statistics.py::TestWeightedAggregator::test_weighted_ci - N...
117 failed, 2170 passed, 76 skipped, 6 xfailed in 164.38s (0:02:44)
```

## 原始行 38 · agent_message

```
The complete run found one genuine integration blocker: all 117 failures have the same cause—`seaborn._statistics` calls `bootstrap` but its import is absent in the masked working tree. That is a required consumer fix, so I’m restoring the local import, fixing the style issue, and rerunning the affected aggregation/categorical/relational paths.
```

## 原始行 40 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,90p' seaborn/_statistics.py; sed -n '1,130p' seaborn/_stats/aggregation.py; grep -RIn --exclude='*.pyc' -E '"'^from .*algorithms|''^import .*algorithms'"' seaborn | head -100; nl -ba seaborn/algorithms.py | sed -n '50,70p'; git diff -- seaborn/algorithms.py seaborn/_statistics.py"
```

退出码：`0`

输出：
```
"""Statistical transformations for visualization.

This module is currently private, but is being written to eventually form part
of the public API.

The classes should behave roughly in the style of scikit-learn.

- All data-independent parameters should be passed to the class constructor.
- Each class should implement a default transformation that is exposed through
  __call__. These are currently written for vector arguments, but I think
  consuming a whole `plot_data` DataFrame and return it with transformed
  variables would make more sense.
- Some class have data-dependent preprocessing that should be cached and used
  multiple times (think defining histogram bins off all data and then counting
  observations within each bin multiple times per data subsets). These currently
  have unique names, but it would be good to have a common name. Not quite
  `fit`, but something similar.
- Alternatively, the transform interface could take some information about grouping
  variables and do a groupby internally.
- Some classes should define alternate transforms that might make the most sense
  with a different function. For example, KDE usually evaluates the distribution
  on a regular grid, but it would be useful for it to transform at the actual
  datapoints. Then again, this could be controlled by a parameter at  the time of
  class instantiation.

"""
from numbers import Number
from statistics import NormalDist
import numpy as np
import pandas as pd
try:
    from scipy.stats import gaussian_kde
    _no_scipy = False
except ImportError:
    from .external.kde import gaussian_kde
    _no_scipy = True


from .utils import _check_argument


class KDE:
    """Univariate and bivariate kernel density estimator."""
    def __init__(
        self, *,
        bw_method=None,
        bw_adjust=1,
        gridsize=200,
        cut=3,
        clip=None,
        cumulative=False,
    ):
        """Initialize the estimator with its parameters.

        Parameters
        ----------
        bw_method : string, scalar, or callable, optional
            Method for determining the smoothing bandwidth to use; passed to
            :class:`scipy.stats.gaussian_kde`.
        bw_adjust : number, optional
            Factor that multiplicatively scales the value chosen using
            ``bw_method``. Increasing will make the curve smoother. See Notes.
        gridsize : int, optional
            Number of points on each dimension of the evaluation grid.
        cut : number, optional
            Factor, multiplied by the smoothing bandwidth, that determines how
            far the evaluation grid extends past the extreme datapoints. When
            set to 0, truncate the curve at the data limits.
        clip : pair of numbers or None, or a pair of such pairs
            Do not evaluate the density outside of these limits.
        cumulative : bool, optional
            If True, estimate a cumulative distribution function. Requires scipy.

        """
        if clip is None:
            clip = None, None

        self.bw_method = bw_method
        self.bw_adjust = bw_adjust
        self.gridsize = gridsize
        self.cut = cut
        self.clip = clip
        self.cumulative = cumulative

        if cumulative and _no_scipy:
            raise RuntimeError("Cumulative KDE evaluation requires scipy")

        self.support = None

    def _define_support_grid(self, x, bw, cut, clip, gridsize):
from __future__ import annotations
from dataclasses import dataclass
from typing import ClassVar, Callable

import pandas as pd
from pandas import DataFrame

from seaborn._core.scales import Scale
from seaborn._core.groupby import GroupBy
from seaborn._stats.base import Stat
from seaborn._statistics import (
    EstimateAggregator,
    WeightedAggregator,
)
from seaborn._core.typing import Vector


@dataclass
class Agg(Stat):
    """
    Aggregate data along the value axis using given method.

    Parameters
    ----------
    func : str or callable
        Name of a :class:`pandas.Series` method or a vector -> scalar function.

    See Also
    --------
    objects.Est : Aggregation with error bars.

    Examples
    --------
    .. include:: ../docstrings/objects.Agg.rst

    """
    func: str | Callable[[Vector], float] = "mean"

    group_by_orient: ClassVar[bool] = True

    def __call__(
        self, data: DataFrame, groupby: GroupBy, orient: str, scales: dict[str, Scale],
    ) -> DataFrame:

        var = {"x": "y", "y": "x"}.get(orient)
        res = (
            groupby
            .agg(data, {var: self.func})
            .dropna(subset=[var])
            .reset_index(drop=True)
        )
        return res


@dataclass
class Est(Stat):
    """
    Calculate a point estimate and error bar interval.

    For more information about the various `errorbar` choices, see the
    :doc:`errorbar tutorial </tutorial/error_bars>`.

    Additional variables:

    - **weight**: When passed to a layer that uses this stat, a weighted estimate
      will be computed. Note that use of weights currently limits the choice of
      function and error bar method  to `"mean"` and `"ci"`, respectively.

    Parameters
    ----------
    func : str or callable
        Name of a :class:`numpy.ndarray` method or a vector -> scalar function.
    errorbar : str, (str, float) tuple, or callable
        Name of errorbar method (one of "ci", "pi", "se" or "sd"), or a tuple
        with a method name and a level parameter, or a function that maps from a
        vector to a (min, max) interval.
    n_boot : int
       Number of bootstrap samples to draw for "ci" errorbars.
    seed : int
        Seed for the PRNG used to draw bootstrap samples.

    Examples
    --------
    .. include:: ../docstrings/objects.Est.rst

    """
    func: str | Callable[[Vector], float] = "mean"
    errorbar: str | tuple[str, float] = ("ci", 95)
    n_boot: int = 1000
    seed: int | None = None

    group_by_orient: ClassVar[bool] = True

    def _process(
        self, data: DataFrame, var: str, estimator: EstimateAggregator
    ) -> DataFrame:
        # Needed because GroupBy.apply assumes func is DataFrame -> DataFrame
        # which we could probably make more general to allow Series return
        res = estimator(data, var)
        return pd.DataFrame([res])

    def __call__(
        self, data: DataFrame, groupby: GroupBy, orient: str, scales: dict[str, Scale],
    ) -> DataFrame:

        boot_kws = {"n_boot": self.n_boot, "seed": self.seed}
        if "weight" in data:
            engine = WeightedAggregator(self.func, self.errorbar, **boot_kws)
        else:
            engine = EstimateAggregator(self.func, self.errorbar, **boot_kws)

        var = {"x": "y", "y": "x"}[orient]
        res = (
            groupby
            .apply(data, self._process, var, engine)
            .dropna(subset=[var])
            .reset_index(drop=True)
        )

        res = res.fillna({f"{var}min": res[var], f"{var}max": res[var]})

        return res


@dataclass
class Rolling(Stat):
    ...

    def __call__(self, data, groupby, orient, scales):
        ...
seaborn/regression.py:18:from . import algorithms as algo
    50	    if len(set(lengths)) > 1:
    51	        raise ValueError("All input arrays must have the same length")
    52	
    53	    args = [np.asarray(a) for a in args]
    54	    n = lengths[0]
    55	
    56	    if units is not None:
    57	        units = np.asarray(units)
    58	        if units.ndim != 1 or len(units) != n:
    59	            raise ValueError("`units` must be a vector with the same length as the data")
    60	
    61	    if isinstance(func, str):
    62	        func = _resolve_bootstrap_func(func, args)
    63	    elif not callable(func):
    64	        raise TypeError("`func` must be a callable or the name of a numpy function")
    65	
    66	    func_kwargs = {} if axis is None else {"axis": axis}
    67	
    68	    # ``default_rng`` accepts integers, SeedSequences, BitGenerators, existing
    69	    # Generators, and None. RandomState is deliberately retained because its
    70	    # sampling stream differs and callers may depend on that stream.
diff --git a/seaborn/algorithms.py b/seaborn/algorithms.py
index 005edcd..0450d9a 100644
--- a/seaborn/algorithms.py
+++ b/seaborn/algorithms.py
@@ -3,3 +3,149 @@ import numpy as np
 import warnings
 
 
+def bootstrap(*args, **kwargs):
+    """Resample one or more arrays with replacement and store aggregate values.
+
+    Parameters
+    ----------
+    *args : array-like
+        Arrays to resample along their first axis. All arrays must have the
+        same length; a single set of indices is used for every array.
+    n_boot : int, optional
+        Number of bootstrap samples. Defaults to 10,000.
+    axis : int, optional
+        Axis passed to ``func``. When omitted, no ``axis`` keyword is passed.
+    units : array-like, optional
+        Sampling-unit labels. When present, units are sampled first and the
+        observations in each selected unit are then sampled independently.
+    func : str or callable, optional
+        Statistic to evaluate on each resample. A string names a NumPy
+        function. Defaults to ``"mean"``.
+    seed : Generator, SeedSequence, RandomState, int, or None, optional
+        Seed or random-number generator used for resampling.
+    random_seed : optional
+        Deprecated alias for ``seed``.
+
+    Returns
+    -------
+    boot_dist : numpy.ndarray
+        Values of the statistic for the bootstrap samples.
+
+    """
+    n_boot = kwargs.get("n_boot", 10000)
+    func = kwargs.get("func", "mean")
+    axis = kwargs.get("axis", None)
+    units = kwargs.get("units", None)
+
+    random_seed = kwargs.get("random_seed", None)
+    if random_seed is not None:
+        msg = "`random_seed` has been renamed to `seed` and will be removed"
+        warnings.warn(msg, UserWarning, stacklevel=2)
+    seed = kwargs.get("seed", random_seed)
+
+    if not args:
+        raise ValueError("bootstrap requires at least one array")
+
+    lengths = [len(a) for a in args]
+    if len(set(lengths)) > 1:
+        raise ValueError("All input arrays must have the same length")
+
+    args = [np.asarray(a) for a in args]
+    n = lengths[0]
+
+    if units is not None:
+        units = np.asarray(units)
+        if units.ndim != 1 or len(units) != n:
+            raise ValueError("`units` must be a vector with the same length as the data")
+
+    if isinstance(func, str):
+        func = _resolve_bootstrap_func(func, args)
+    elif not callable(func):
+        raise TypeError("`func` must be a callable or the name of a numpy function")
+
+    func_kwargs = {} if axis is None else {"axis": axis}
+
+    # ``default_rng`` accepts integers, SeedSequences, BitGenerators, existing
+    # Generators, and None. RandomState is deliberately retained because its
+    # sampling stream differs and callers may depend on that stream.
+    if isinstance(seed, np.random.RandomState):
+        rng = seed
+        integers = rng.randint
+    else:
+        rng = np.random.default_rng(seed)
+        integers = rng.integers
+
+    if units is not None:
+        return _structured_bootstrap(
+            args, n_boot, units, func, func_kwargs, integers,
+        )
+
+    boot_dist = []
+    for _ in range(int(n_boot)):
+        resampler = integers(0, n, n)
+        sample = [a.take(resampler, axis=0) for a in args]
+        boot_dist.append(func(*sample, **func_kwargs))
+
+    return np.asarray(boot_dist)
+
+
+def _resolve_bootstrap_func(name, args):
+    """Resolve a named NumPy statistic, preferring its NaN-aware variant."""
+    func = getattr(np, name)
+
+    if name.startswith("nan") or not _contains_nan(args):
+        return func
+
+    nan_func = getattr(np, f"nan{name}", None)
+    if nan_func is None:
+        msg = f"Data contain NaNs but no nan-aware version of `{name}` was found"
+        warnings.warn(msg, UserWarning, stacklevel=3)
+    else:
+        func = nan_func
+
+    return func
+
+
+def _contains_nan(args):
+    """Return whether any input has a NaN value when that can be determined."""
+    for arg in args:
+        try:
+            if np.isnan(arg).any():
+                return True
+        except TypeError:
+            # Non-numeric arrays cannot generally be consumed by NumPy's
+            # numeric summary functions, but NaN detection should not mask the
+            # error that the requested function itself will produce.
+            continue
+    return False
+
+
+def _structured_bootstrap(args, n_boot, units, func, func_kwargs, integers):
+    """Bootstrap arrays by sampling units and then observations within units."""
+    unique_units = np.unique(units)
+    n_units = len(unique_units)
+
+    # Organize every argument identically so that a unit and observation index
+    # can be shared across all arrays, preserving paired observations.
+    grouped = [
+        [arg[units == unit] for unit in unique_units]
+        for arg in args
+    ]
+
+    boot_dist = []
+    for _ in range(int(n_boot)):
+        unit_resampler = integers(0, n_units, n_units)
+        resampled = [[] for _ in args]
+
+        for unit_index in unit_resampler:
+            unit_n = len(grouped[0][unit_index])
+            obs_resampler = integers(0, unit_n, unit_n)
+            for sample, arg_groups in zip(resampled, grouped):
+                sample.append(
+                    arg_groups[unit_index].take(obs_resampler, axis=0)
+                )
+
+        sample = [np.concatenate(parts, axis=0) for parts in resampled]
+        boot_dist.append(func(*sample, **func_kwargs))
+
+    return np.asarray(boot_dist)
```

## 原始行 43 · file_change

```
{
  "id": "item_30",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/_statistics.py",
      "kind": "update"
    },
    {
      "path": "/testbed/seaborn/algorithms.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 46 · command_execution

命令：
```
/bin/bash -lc 'python -m flake8 seaborn/algorithms.py seaborn/_statistics.py 2>/dev/null || true
pytest -q tests/test_statistics.py tests/_stats/test_aggregation.py tests/test_regression.py tests/test_categorical.py::TestBarPlot::test_weighted_estimate tests/test_categorical.py::TestPointPlot::test_weighted_estimate tests/test_relational.py::TestLinePlotter::test_weights'
```

退出码：`0`

输出：
```
....s.....s.....................................s....................... [ 49%]
..........................ss....ss.........ssss...................s..... [ 98%]
..                                                                       [100%]
134 passed, 12 skipped in 6.68s
```

## 原始行 49 · agent_message

```
The consumer import is restored, and the targeted downstream set now passes: 134 passed, 12 skipped, including weighted aggregation, confidence intervals, regression, and representative categorical/relational plots. I’m aligning warning compatibility and doing the final repository-wide verification.
```

## 原始行 51 · file_change

```
{
  "id": "item_36",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/algorithms.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 53 · agent_message

```
The repository-wide run is past 60% with no failures. The previously failing plotting and aggregation sections are now clean.
```

## 原始行 54 · command_execution

命令：
```
/bin/bash -lc 'pytest -q'
```

退出码：`0`

输出：
```
....................................s................................... [  3%]
.................................x............x...x................x.x.. [  6%]
........................................................................ [  9%]
........................................................................ [ 12%]
........................................................................ [ 15%]
........................................................................ [ 18%]
.....................................................................x.. [ 21%]
........................................................................ [ 24%]
........................................................................ [ 27%]
........................................................................ [ 30%]
....ss.................................................................. [ 33%]
........................................................................ [ 36%]
........................................................................ [ 39%]
........................................................................ [ 42%]
........................................................................ [ 45%]
........................................................................ [ 48%]
........................................................................ [ 51%]
........................................................................ [ 54%]
........................................................................ [ 57%]
........................................................................ [ 60%]
........................................................................ [ 63%]
........................................................................ [ 66%]
........................................................................ [ 69%]
..............................................s......................... [ 72%]
........................................................................ [ 75%]
........................................................................ [ 79%]
........................................................................ [ 82%]
.......sssssssssssssssssssssssssssssssssssssssssssssssssssss..s......... [ 85%]
..................................................s.s................ss. [ 88%]
...ss.........ssss...................s.................................. [ 91%]
........................................................................ [ 94%]
.....................s.....s.....................................s...... [ 97%]
..............................................sss.s..............        [100%]
2287 passed, 76 skipped, 6 xfailed in 166.08s (0:02:46)
```

## 原始行 56 · agent_message

```
The full suite is clean: 2,287 passed, 76 skipped, and 6 expected failures. I’m doing one final diff review to ensure the change set is limited to the implementation and its necessary import.
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc 'git status --short; git diff --check; git diff --stat; git diff -- seaborn/algorithms.py seaborn/_statistics.py'
```

退出码：`0`

输出：
```
 M seaborn/_statistics.py
 M seaborn/algorithms.py
 seaborn/_statistics.py |   1 +
 seaborn/algorithms.py  | 147 +++++++++++++++++++++++++++++++++++++++++++++++++
 2 files changed, 148 insertions(+)
diff --git a/seaborn/_statistics.py b/seaborn/_statistics.py
index 22e7ee3..666e238 100644
--- a/seaborn/_statistics.py
+++ b/seaborn/_statistics.py
@@ -36,6 +36,7 @@ except ImportError:
     _no_scipy = True
 
 
+from .algorithms import bootstrap
 from .utils import _check_argument
 
 
diff --git a/seaborn/algorithms.py b/seaborn/algorithms.py
index 005edcd..d5e9677 100644
--- a/seaborn/algorithms.py
+++ b/seaborn/algorithms.py
@@ -3,3 +3,150 @@ import numpy as np
 import warnings
 
 
+def bootstrap(*args, **kwargs):
+    """Resample one or more arrays with replacement and store aggregate values.
+
+    Parameters
+    ----------
+    *args : array-like
+        Arrays to resample along their first axis. All arrays must have the
+        same length; a single set of indices is used for every array.
+    n_boot : int, optional
+        Number of bootstrap samples. Defaults to 10,000.
+    axis : int, optional
+        Axis passed to ``func``. When omitted, no ``axis`` keyword is passed.
+    units : array-like, optional
+        Sampling-unit labels. When present, units are sampled first and the
+        observations in each selected unit are then sampled independently.
+    func : str or callable, optional
+        Statistic to evaluate on each resample. A string names a NumPy
+        function. Defaults to ``"mean"``.
+    seed : Generator, SeedSequence, RandomState, int, or None, optional
+        Seed or random-number generator used for resampling.
+    random_seed : optional
+        Deprecated alias for ``seed``.
+
+    Returns
+    -------
+    boot_dist : numpy.ndarray
+        Values of the statistic for the bootstrap samples.
+
+    """
+    n_boot = kwargs.get("n_boot", 10000)
+    func = kwargs.get("func", "mean")
+    axis = kwargs.get("axis", None)
+    units = kwargs.get("units", None)
+
+    random_seed = kwargs.get("random_seed", None)
+    if random_seed is not None:
+        msg = "`random_seed` has been renamed to `seed` and will be removed"
+        warnings.warn(msg, UserWarning, stacklevel=2)
+    seed = kwargs.get("seed", random_seed)
+
+    if not args:
+        raise ValueError("bootstrap requires at least one array")
+
+    lengths = [len(a) for a in args]
+    if len(set(lengths)) > 1:
+        raise ValueError("All input arrays must have the same length")
+
+    args = [np.asarray(a) for a in args]
+    n = lengths[0]
+
+    if units is not None:
+        units = np.asarray(units)
+        if units.ndim != 1 or len(units) != n:
+            msg = "`units` must be a vector with the same length as the data"
+            raise ValueError(msg)
+
+    if isinstance(func, str):
+        func = _resolve_bootstrap_func(func, args)
+    elif not callable(func):
+        raise TypeError("`func` must be a callable or the name of a numpy function")
+
+    func_kwargs = {} if axis is None else {"axis": axis}
+
+    # ``default_rng`` accepts integers, SeedSequences, BitGenerators, existing
+    # Generators, and None. RandomState is deliberately retained because its
+    # sampling stream differs and callers may depend on that stream.
+    if isinstance(seed, np.random.RandomState):
+        rng = seed
+        integers = rng.randint
+    else:
+        rng = np.random.default_rng(seed)
+        integers = rng.integers
+
+    if units is not None:
+        return _structured_bootstrap(
+            args, n_boot, units, func, func_kwargs, integers,
+        )
+
+    boot_dist = []
+    for _ in range(int(n_boot)):
+        resampler = integers(0, n, n)
+        sample = [a.take(resampler, axis=0) for a in args]
+        boot_dist.append(func(*sample, **func_kwargs))
+
+    return np.asarray(boot_dist)
+
+
+def _resolve_bootstrap_func(name, args):
+    """Resolve a named NumPy statistic, preferring its NaN-aware variant."""
+    func = getattr(np, name)
+
+    if name.startswith("nan") or not _contains_nan(args):
+        return func
+
+    nan_func = getattr(np, f"nan{name}", None)
+    if nan_func is None:
+        msg = f"Data contain nans but no nan-aware version of `{name}` found"
+        warnings.warn(msg, UserWarning, stacklevel=3)
+    else:
+        func = nan_func
+
+    return func
+
+
+def _contains_nan(args):
+    """Return whether any input has a NaN value when that can be determined."""
+    for arg in args:
+        try:
+            if np.isnan(arg).any():
+                return True
+        except TypeError:
+            # Non-numeric arrays cannot generally be consumed by NumPy's
+            # numeric summary functions, but NaN detection should not mask the
+            # error that the requested function itself will produce.
+            continue
+    return False
+
+
+def _structured_bootstrap(args, n_boot, units, func, func_kwargs, integers):
+    """Bootstrap arrays by sampling units and then observations within units."""
+    unique_units = np.unique(units)
+    n_units = len(unique_units)
+
+    # Organize every argument identically so that a unit and observation index
+    # can be shared across all arrays, preserving paired observations.
+    grouped = [
+        [arg[units == unit] for unit in unique_units]
+        for arg in args
+    ]
+
+    boot_dist = []
+    for _ in range(int(n_boot)):
+        unit_resampler = integers(0, n_units, n_units)
+        resampled = [[] for _ in args]
+
+        for unit_index in unit_resampler:
+            unit_n = len(grouped[0][unit_index])
+            obs_resampler = integers(0, unit_n, unit_n)
+            for sample, arg_groups in zip(resampled, grouped):
+                sample.append(
+                    arg_groups[unit_index].take(obs_resampler, axis=0)
+                )
+
+        sample = [np.concatenate(parts, axis=0) for parts in resampled]
+        boot_dist.append(func(*sample, **func_kwargs))
+
+    return np.asarray(boot_dist)
```

## 原始行 60 · agent_message

```
Implemented bootstrap resampling in [seaborn/algorithms.py](/testbed/seaborn/algorithms.py), including:

- Paired resampling of multiple arrays
- Configurable iterations and axis handling
- String or callable summary functions
- Automatic NaN-aware NumPy functions
- Hierarchical unit-based resampling
- Generator, SeedSequence, RandomState, integer, and `None` seeds
- Deprecated `random_seed` support
- Input dimension validation

Also restored the required integration import in [seaborn/_statistics.py](/testbed/seaborn/_statistics.py).

Validation: `2287 passed, 76 skipped, 6 xfailed`.
```
