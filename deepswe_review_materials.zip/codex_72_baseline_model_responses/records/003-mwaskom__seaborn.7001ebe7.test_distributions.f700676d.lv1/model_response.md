# Codex baseline: mwaskom__seaborn.7001ebe7.test_distributions.f700676d.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the four target modules and their visible tests first, then implement the smallest compatible changes and run focused tests followed by the broader relevant suite.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "pwd && rg -n \"_parse_cubehelix_args|def cubehelix_palette|def get_color_cycle|def get_colormap|class FacetGrid|def axes_dict|def ax\\(\" seaborn tests"
```

退出码：`127`

输出：
```
/testbed
/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
`rg` is not installed in this environment, so I’m switching to targeted `grep`/`find` inspection without changing the repository.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"_parse_cubehelix_args|def cubehelix_palette|def get_color_cycle|def get_colormap|class FacetGrid|def axes_dict|def ax\\(\" seaborn tests 2>/dev/null | head -300"
```

退出码：`0`

输出：
```
seaborn/palettes.py:207:            args, kwargs = _parse_cubehelix_args(palette)
seaborn/palettes.py:665:def cubehelix_palette(n_colors=6, start=0, rot=.4, gamma=1.0, hue=0.8,
seaborn/axisgrid.py:368:class FacetGrid(Grid):
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' seaborn/palettes.py
sed -n '620,760p' seaborn/palettes.py
sed -n '1,180p' seaborn/utils.py
sed -n '1,220p' seaborn/_compat.py
sed -n '1,470p' seaborn/axisgrid.py
find tests -maxdepth 2 -type f -print | sort | head -200"
```

退出码：`0`

输出：
```
import colorsys
from itertools import cycle

import numpy as np
import matplotlib as mpl

from .external import husl

from .utils import desaturate
from .colors import xkcd_rgb, crayons



__all__ = ["color_palette", "hls_palette", "husl_palette", "mpl_palette",
           "dark_palette", "light_palette", "diverging_palette",
           "blend_palette", "xkcd_palette", "crayon_palette",
           "cubehelix_palette", "set_color_codes"]


SEABORN_PALETTES = dict(
    deep=["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3",
          "#937860", "#DA8BC3", "#8C8C8C", "#CCB974", "#64B5CD"],
    deep6=["#4C72B0", "#55A868", "#C44E52",
           "#8172B3", "#CCB974", "#64B5CD"],
    muted=["#4878D0", "#EE854A", "#6ACC64", "#D65F5F", "#956CB4",
           "#8C613C", "#DC7EC0", "#797979", "#D5BB67", "#82C6E2"],
    muted6=["#4878D0", "#6ACC64", "#D65F5F",
            "#956CB4", "#D5BB67", "#82C6E2"],
    pastel=["#A1C9F4", "#FFB482", "#8DE5A1", "#FF9F9B", "#D0BBFF",
            "#DEBB9B", "#FAB0E4", "#CFCFCF", "#FFFEA3", "#B9F2F0"],
    pastel6=["#A1C9F4", "#8DE5A1", "#FF9F9B",
             "#D0BBFF", "#FFFEA3", "#B9F2F0"],
    bright=["#023EFF", "#FF7C00", "#1AC938", "#E8000B", "#8B2BE2",
            "#9F4800", "#F14CC1", "#A3A3A3", "#FFC400", "#00D7FF"],
    bright6=["#023EFF", "#1AC938", "#E8000B",
             "#8B2BE2", "#FFC400", "#00D7FF"],
    dark=["#001C7F", "#B1400D", "#12711C", "#8C0800", "#591E71",
          "#592F0D", "#A23582", "#3C3C3C", "#B8850A", "#006374"],
    dark6=["#001C7F", "#12711C", "#8C0800",
           "#591E71", "#B8850A", "#006374"],
    colorblind=["#0173B2", "#DE8F05", "#029E73", "#D55E00", "#CC78BC",
                "#CA9161", "#FBAFE4", "#949494", "#ECE133", "#56B4E9"],
    colorblind6=["#0173B2", "#029E73", "#D55E00",
                 "#CC78BC", "#ECE133", "#56B4E9"]
)


MPL_QUAL_PALS = {
    "tab10": 10, "tab20": 20, "tab20b": 20, "tab20c": 20,
    "Set1": 9, "Set2": 8, "Set3": 12,
    "Accent": 8, "Paired": 12,
    "Pastel1": 9, "Pastel2": 8, "Dark2": 8,
}


QUAL_PALETTE_SIZES = MPL_QUAL_PALS.copy()
QUAL_PALETTE_SIZES.update({k: len(v) for k, v in SEABORN_PALETTES.items()})
QUAL_PALETTES = list(QUAL_PALETTE_SIZES.keys())


class _ColorPalette(list):
    """Set the color palette in a with statement, otherwise be a list."""
    def __enter__(self):
        """Open the context."""
        from .rcmod import set_palette
        self._orig_palette = color_palette()
        set_palette(self)
        return self

    def __exit__(self, *args):
        """Close the context."""
        from .rcmod import set_palette
        set_palette(self._orig_palette)

    def as_hex(self):
        """Return a color palette with hex codes instead of RGB values."""
        hex = [mpl.colors.rgb2hex(rgb) for rgb in self]
        return _ColorPalette(hex)

    def _repr_html_(self):
        """Rich display of the color palette in an HTML frontend."""
        s = 55
        n = len(self)
        html = f'<svg  width="{n * s}" height="{s}">'
        for i, c in enumerate(self.as_hex()):
            html += (
                f'<rect x="{i * s}" y="0" width="{s}" height="{s}" style="fill:{c};'
                'stroke-width:2;stroke:rgb(255,255,255)"/>'
            )
        html += '</svg>'
        return html


def _patch_colormap_display():
    """Simplify the rich display of matplotlib color maps in a notebook."""
    def _repr_png_(self):
        """Generate a PNG representation of the Colormap."""
        import io
        from PIL import Image
        import numpy as np
        IMAGE_SIZE = (400, 50)
        X = np.tile(np.linspace(0, 1, IMAGE_SIZE[0]), (IMAGE_SIZE[1], 1))
        pixels = self(X, bytes=True)
        png_bytes = io.BytesIO()
        Image.fromarray(pixels).save(png_bytes, format='png')
        return png_bytes.getvalue()

    def _repr_html_(self):
        """Generate an HTML representation of the Colormap."""
        import base64
        png_bytes = self._repr_png_()
        png_base64 = base64.b64encode(png_bytes).decode('ascii')
        return ('<img '
                + 'alt="' + self.name + ' color map" '
                + 'title="' + self.name + '"'
                + 'src="data:image/png;base64,' + png_base64 + '">')

    mpl.colors.Colormap._repr_png_ = _repr_png_
    mpl.colors.Colormap._repr_html_ = _repr_html_


def color_palette(palette=None, n_colors=None, desat=None, as_cmap=False):
    """Return a list of colors or continuous colormap defining a palette.

    Possible ``palette`` values include:
        - Name of a seaborn palette (deep, muted, bright, pastel, dark, colorblind)
        - Name of matplotlib colormap
        - 'husl' or 'hls'
        - 'ch:<cubehelix arguments>'
        - 'light:<color>', 'dark:<color>', 'blend:<color>,<color>',
        - A sequence of colors in any format matplotlib accepts

    Calling this function with ``palette=None`` will return the current
    matplotlib color cycle.

    This function can also be used in a ``with`` statement to temporarily
    set the color cycle for a plot or set of plots.

    See the :ref:`tutorial <palette_tutorial>` for more information.

    Parameters
    ----------
    palette : None, string, or sequence, optional
        Name of palette or None to return current palette. If a sequence, input
        colors are used but possibly cycled and desaturated.
    n_colors : int, optional
        Number of colors in the palette. If ``None``, the default will depend
        on how ``palette`` is specified. Named palettes default to 6 colors,
        but grabbing the current palette or passing in a list of colors will
        not change the number of colors unless this is specified. Asking for
        more colors than exist in the palette will cause it to cycle. Ignored
        when ``as_cmap`` is True.
    desat : float, optional
        Proportion to desaturate each color by.
    as_cmap : bool
        If True, return a :class:`matplotlib.colors.ListedColormap`.

    Returns
    -------
    list of RGB tuples or :class:`matplotlib.colors.ListedColormap`

    See Also
    --------
    set_palette : Set the default color cycle for all plots.
    set_color_codes : Reassign color codes like ``"b"``, ``"g"``, etc. to
                      colors from one of the seaborn palettes.

    Examples
    --------

    .. include:: ../docstrings/color_palette.rst

    """
    if palette is None:
        palette = get_color_cycle()
        if n_colors is None:
            n_colors = len(palette)

    elif not isinstance(palette, str):
        palette = palette
        if n_colors is None:
            n_colors = len(palette)
    else:

        if n_colors is None:
            # Use all colors in a qualitative palette or 6 of another kind
            n_colors = QUAL_PALETTE_SIZES.get(palette, 6)

        if palette in SEABORN_PALETTES:
            # Named "seaborn variant" of matplotlib default color cycle
            palette = SEABORN_PALETTES[palette]

        elif palette == "hls":
            # Evenly spaced colors in cylindrical RGB space
            palette = hls_palette(n_colors, as_cmap=as_cmap)

        elif palette == "husl":
            # Evenly spaced colors in cylindrical Lab space
            palette = husl_palette(n_colors, as_cmap=as_cmap)

        elif palette.lower() == "jet":
            # Paternalism
            raise ValueError("No.")

        elif palette.startswith("ch:"):
            # Cubehelix palette with params specified in string
            args, kwargs = _parse_cubehelix_args(palette)
            palette = cubehelix_palette(n_colors, *args, **kwargs, as_cmap=as_cmap)

        elif palette.startswith("light:"):
            # light palette to color specified in string
            _, color = palette.split(":")
            reverse = color.endswith("_r")
            if reverse:
                color = color[:-2]
            palette = light_palette(color, n_colors, reverse=reverse, as_cmap=as_cmap)

        elif palette.startswith("dark:"):
            # light palette to color specified in string
            _, color = palette.split(":")
            reverse = color.endswith("_r")
            if reverse:
                color = color[:-2]
            palette = dark_palette(color, n_colors, reverse=reverse, as_cmap=as_cmap)

        elif palette.startswith("blend:"):
            # blend palette between colors specified in string
            _, colors = palette.split(":")
            colors = colors.split(",")
            palette = blend_palette(colors, n_colors, as_cmap=as_cmap)

        else:
            try:
                # Perhaps a named matplotlib colormap?
                palette = mpl_palette(palette, n_colors, as_cmap=as_cmap)
            except (ValueError, KeyError):  # Error class changed in mpl36
                raise ValueError(f"{palette!r} is not a valid palette name")

    if desat is not None:
        palette = [desaturate(c, desat) for c in palette]

    if not as_cmap:

        # Always return as many colors as we asked for
        pal_cycle = cycle(palette)
        palette = [next(pal_cycle) for _ in range(n_colors)]

        # Always return in r, g, b tuple format
        try:
            palette = map(mpl.colors.colorConverter.to_rgb, palette)
            palette = _ColorPalette(palette)
        except ValueError:
            raise ValueError(f"Could not generate a palette for {palette}")

    return palette


def hls_palette(n_colors=6, h=.01, l=.6, s=.65, as_cmap=False):  # noqa
    """
    Return hues with constant lightness and saturation in the HLS system.
    ----------
    colors : list of strings
        List of keys in the `seaborn.xkcd_rgb` dictionary.

    Returns
    -------
    palette
        A list of colors as RGB tuples.

    See Also
    --------
    crayon_palette : Make a palette with Crayola crayon colors.

    """
    palette = [xkcd_rgb[name] for name in colors]
    return color_palette(palette, len(palette))


def crayon_palette(colors):
    """Make a palette with color names from Crayola crayons.

    Colors are taken from here:
    https://en.wikipedia.org/wiki/List_of_Crayola_crayon_colors

    This is just a simple wrapper around the `seaborn.crayons` dictionary.

    Parameters
    ----------
    colors : list of strings
        List of keys in the `seaborn.crayons` dictionary.

    Returns
    -------
    palette
        A list of colors as RGB tuples.

    See Also
    --------
    xkcd_palette : Make a palette with named colors from the XKCD color survey.

    """
    palette = [crayons[name] for name in colors]
    return color_palette(palette, len(palette))


def cubehelix_palette(n_colors=6, start=0, rot=.4, gamma=1.0, hue=0.8,
                      light=.85, dark=.15, reverse=False, as_cmap=False):
    """Make a sequential palette from the cubehelix system.

    This produces a colormap with linearly-decreasing (or increasing)
    brightness. That means that information will be preserved if printed to
    black and white or viewed by someone who is colorblind.  "cubehelix" is
    also available as a matplotlib-based palette, but this function gives the
    user more control over the look of the palette and has a different set of
    defaults.

    In addition to using this function, it is also possible to generate a
    cubehelix palette generally in seaborn using a string starting with
    `ch:` and containing other parameters (e.g. `"ch:s=.25,r=-.5"`).

    Parameters
    ----------
    n_colors : int
        Number of colors in the palette.
    start : float, 0 <= start <= 3
        The hue value at the start of the helix.
    rot : float
        Rotations around the hue wheel over the range of the palette.
    gamma : float 0 <= gamma
        Nonlinearity to emphasize dark (gamma < 1) or light (gamma > 1) colors.
    hue : float, 0 <= hue <= 1
        Saturation of the colors.
    dark : float 0 <= dark <= 1
        Intensity of the darkest color in the palette.
    light : float 0 <= light <= 1
        Intensity of the lightest color in the palette.
    reverse : bool
        If True, the palette will go from dark to light.
    as_cmap : bool
        If True, return a :class:`matplotlib.colors.ListedColormap`.

    Returns
    -------
    palette
        list of RGB tuples or :class:`matplotlib.colors.ListedColormap`

    See Also
    --------
    choose_cubehelix_palette : Launch an interactive widget to select cubehelix
                               palette parameters.
    dark_palette : Create a sequential palette with dark low values.
    light_palette : Create a sequential palette with bright low values.

    References
    ----------
    Green, D. A. (2011). "A colour scheme for the display of astronomical
    intensity images". Bulletin of the Astromical Society of India, Vol. 39,
    p. 289-295.

    Examples
    --------
    .. include:: ../docstrings/cubehelix_palette.rst

    """
















    cdict = {
        "red": get_color_function(-0.14861, 1.78277),
        "green": get_color_function(-0.29227, -0.90649),
        "blue": get_color_function(1.97294, 0.0),
    }

    cmap = mpl.colors.LinearSegmentedColormap("cubehelix", cdict)

    x = np.linspace(light, dark, int(n_colors))
    pal = cmap(x)[:, :3].tolist()
    if reverse:
        pal = pal[::-1]

    if as_cmap:
        x_256 = np.linspace(light, dark, 256)
        if reverse:
            x_256 = x_256[::-1]
        pal_256 = cmap(x_256)
        cmap = mpl.colors.ListedColormap(pal_256, "seaborn_cubehelix")
        return cmap
    else:
"""Utility functions, mostly for internal use."""
import os
import inspect
import warnings
import colorsys
from contextlib import contextmanager
from urllib.request import urlopen, urlretrieve
from types import ModuleType

import numpy as np
import pandas as pd
import matplotlib as mpl
from matplotlib.colors import to_rgb
import matplotlib.pyplot as plt
from matplotlib.cbook import normalize_kwargs

from seaborn._core.typing import deprecated
from seaborn.external.version import Version
from seaborn.external.appdirs import user_cache_dir

__all__ = ["desaturate", "saturate", "set_hls_values", "move_legend",
           "despine", "get_dataset_names", "get_data_home", "load_dataset"]

DATASET_SOURCE = "https://raw.githubusercontent.com/mwaskom/seaborn-data/master"
DATASET_NAMES_URL = f"{DATASET_SOURCE}/dataset_names.txt"


def ci_to_errsize(cis, heights):
    """Convert intervals to error arguments relative to plot heights.

    Parameters
    ----------
    cis : 2 x n sequence
        sequence of confidence interval limits
    heights : n sequence
        sequence of plot heights

    Returns
    -------
    errsize : 2 x n array
        sequence of error size relative to height values in correct
        format as argument for plt.bar

    """
    cis = np.atleast_2d(cis).reshape(2, -1)
    heights = np.atleast_1d(heights)
    errsize = []
    for i, (low, high) in enumerate(np.transpose(cis)):
        h = heights[i]
        elow = h - low
        ehigh = high - h
        errsize.append([elow, ehigh])

    errsize = np.asarray(errsize).T
    return errsize



























































































def desaturate(color, prop):
    """Decrease the saturation channel of a color by some percent.

    Parameters
    ----------
    color : matplotlib color
        hex, rgb-tuple, or html color name
    prop : float
        saturation channel of color will be multiplied by this value

    Returns
    -------
    new_color : rgb tuple
        desaturated color code in RGB tuple representation

    """
    # Check inputs
    if not 0 <= prop <= 1:
        raise ValueError("prop must be between 0 and 1")

    # Get rgb tuple rep
    rgb = to_rgb(color)

    # Short circuit to avoid floating point issues
    if prop == 1:
        return rgb

    # Convert to hls
    h, l, s = colorsys.rgb_to_hls(*rgb)

    # Desaturate the saturation channel
    s *= prop

    # Convert back to rgb
from __future__ import annotations
from typing import Literal

import numpy as np
import pandas as pd
import matplotlib as mpl
from matplotlib.figure import Figure
from seaborn.utils import _version_predates


def norm_from_scale(scale, norm):
    """Produce a Normalize object given a Scale and min/max domain limits."""
    # This is an internal maplotlib function that simplifies things to access
    # It is likely to become part of the matplotlib API at some point:
    # https://github.com/matplotlib/matplotlib/issues/20329
    if isinstance(norm, mpl.colors.Normalize):
        return norm

    if scale is None:
        return None

    if norm is None:
        vmin = vmax = None
    else:
        vmin, vmax = norm  # TODO more helpful error if this fails?

    class ScaledNorm(mpl.colors.Normalize):

        def __call__(self, value, clip=None):
            # From github.com/matplotlib/matplotlib/blob/v3.4.2/lib/matplotlib/colors.py
            # See github.com/matplotlib/matplotlib/tree/v3.4.2/LICENSE
            value, is_scalar = self.process_value(value)
            self.autoscale_None(value)
            if self.vmin > self.vmax:
                raise ValueError("vmin must be less or equal to vmax")
            if self.vmin == self.vmax:
                return np.full_like(value, 0)
            if clip is None:
                clip = self.clip
            if clip:
                value = np.clip(value, self.vmin, self.vmax)
            # ***** Seaborn changes start ****
            t_value = self.transform(value).reshape(np.shape(value))
            t_vmin, t_vmax = self.transform([self.vmin, self.vmax])
            # ***** Seaborn changes end *****
            if not np.isfinite([t_vmin, t_vmax]).all():
                raise ValueError("Invalid vmin or vmax")
            t_value -= t_vmin
            t_value /= (t_vmax - t_vmin)
            t_value = np.ma.masked_invalid(t_value, copy=False)
            return t_value[0] if is_scalar else t_value

    new_norm = ScaledNorm(vmin, vmax)
    new_norm.transform = scale.get_transform().transform

    return new_norm










def register_colormap(name, cmap):
    """Handle changes to matplotlib colormap interface in 3.6."""
    try:
        if name not in mpl.colormaps:
            mpl.colormaps.register(cmap, name=name)
    except AttributeError:
        mpl.cm.register_cmap(name, cmap)


def set_layout_engine(
    fig: Figure,
    engine: Literal["constrained", "compressed", "tight", "none"],
) -> None:
    """Handle changes to auto layout engine interface in 3.6"""
    if hasattr(fig, "set_layout_engine"):
        fig.set_layout_engine(engine)
    else:
        # _version_predates(mpl, 3.6)
        if engine == "tight":
            fig.set_tight_layout(True)  # type: ignore  # predates typing
        elif engine == "constrained":
            fig.set_constrained_layout(True)  # type: ignore
        elif engine == "none":
            fig.set_tight_layout(False)  # type: ignore
            fig.set_constrained_layout(False)  # type: ignore


def get_layout_engine(fig: Figure) -> mpl.layout_engine.LayoutEngine | None:
    """Handle changes to auto layout engine interface in 3.6"""
    if hasattr(fig, "get_layout_engine"):
        return fig.get_layout_engine()
    else:
        # _version_predates(mpl, 3.6)
        return None


def share_axis(ax0, ax1, which):
    """Handle changes to post-hoc axis sharing."""
    if _version_predates(mpl, "3.5"):
        group = getattr(ax0, f"get_shared_{which}_axes")()
        group.join(ax1, ax0)
    else:
        getattr(ax1, f"share{which}")(ax0)


def get_legend_handles(legend):
    """Handle legendHandles attribute rename."""
    if _version_predates(mpl, "3.7"):
        return legend.legendHandles
    else:
        return legend.legend_handles


def groupby_apply_include_groups(val):
    if _version_predates(pd, "2.2.0"):
        return {}
    return {"include_groups": val}


def get_converter(axis):
    if _version_predates(mpl, "3.10.0"):
        return axis.converter
    return axis.get_converter()from __future__ import annotations
from itertools import product
from inspect import signature
import warnings
from textwrap import dedent

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt

from ._base import VectorPlotter, variable_type, categorical_order
from ._core.data import handle_data_source
from ._compat import share_axis, get_legend_handles
from . import utils
from .utils import adjust_legend_subtitles, set_hls_values, _check_argument, _disable_autolayout






from .palettes import color_palette, blend_palette
from ._docstrings import (
    DocstringComponents,
    _core_docs,
)

__all__ = ["FacetGrid", "PairGrid", "JointGrid", "pairplot", "jointplot"]


_param_docs = DocstringComponents.from_nested_components(
    core=_core_docs["params"],
)


class _BaseGrid:
    """Base class for grids of subplots."""

    def set(self, **kwargs):
        """Set attributes on each subplot Axes."""
        for ax in self.axes.flat:
            if ax is not None:  # Handle removed axes
                ax.set(**kwargs)
        return self

    @property
    def fig(self):
        """DEPRECATED: prefer the `figure` property."""
        # Grid.figure is preferred because it matches the Axes attribute name.
        # But as the maintanace burden on having this property is minimal,
        # let's be slow about formally deprecating it. For now just note its deprecation
        # in the docstring; add a warning in version 0.13, and eventually remove it.
        return self._figure

    @property
    def figure(self):
        """Access the :class:`matplotlib.figure.Figure` object underlying the grid."""
        return self._figure

    def apply(self, func, *args, **kwargs):
        """
        Pass the grid to a user-supplied function and return self.

        The `func` must accept an object of this type for its first
        positional argument. Additional arguments are passed through.
        The return value of `func` is ignored; this method returns self.
        See the `pipe` method if you want the return value.

        Added in v0.12.0.

        """
        func(self, *args, **kwargs)
        return self

    def pipe(self, func, *args, **kwargs):
        """
        Pass the grid to a user-supplied function and return its value.

        The `func` must accept an object of this type for its first
        positional argument. Additional arguments are passed through.
        The return value of `func` becomes the return value of this method.
        See the `apply` method if you want to return self instead.

        Added in v0.12.0.

        """
        return func(self, *args, **kwargs)

    def savefig(self, *args, **kwargs):
        """
        Save an image of the plot.

        This wraps :meth:`matplotlib.figure.Figure.savefig`, using bbox_inches="tight"
        by default. Parameters are passed through to the matplotlib function.

        """
        kwargs = kwargs.copy()
        kwargs.setdefault("bbox_inches", "tight")
        self.figure.savefig(*args, **kwargs)


class Grid(_BaseGrid):
    """A grid that can have multiple subplots and an external legend."""
    _margin_titles = False
    _legend_out = True

    def __init__(self):

        self._tight_layout_rect = [0, 0, 1, 1]
        self._tight_layout_pad = None

        # This attribute is set externally and is a hack to handle newer functions that
        # don't add proxy artists onto the Axes. We need an overall cleaner approach.
        self._extract_legend_handles = False

    def tight_layout(self, *args, **kwargs):
        """Call fig.tight_layout within rect that exclude the legend."""
        kwargs = kwargs.copy()
        kwargs.setdefault("rect", self._tight_layout_rect)
        if self._tight_layout_pad is not None:
            kwargs.setdefault("pad", self._tight_layout_pad)
        self._figure.tight_layout(*args, **kwargs)
        return self









































































































    def _update_legend_data(self, ax):
        """Extract the legend data from an axes object and save it."""
        data = {}

        # Get data directly from the legend, which is necessary
        # for newer functions that don't add labeled proxy artists
        if ax.legend_ is not None and self._extract_legend_handles:
            handles = get_legend_handles(ax.legend_)
            labels = [t.get_text() for t in ax.legend_.texts]
            data.update({label: handle for handle, label in zip(handles, labels)})

        handles, labels = ax.get_legend_handles_labels()
        data.update({label: handle for handle, label in zip(handles, labels)})

        self._legend_data.update(data)

        # Now clear the legend
        ax.legend_ = None

    def _get_palette(self, data, hue, hue_order, palette):
        """Get a list of colors for the hue variable."""
        if hue is None:
            palette = color_palette(n_colors=1)

        else:
            hue_names = categorical_order(data[hue], hue_order)
            n_colors = len(hue_names)

            # By default use either the current color palette or HUSL
            if palette is None:
                current_palette = utils.get_color_cycle()
                if n_colors > len(current_palette):
                    colors = color_palette("husl", n_colors)
                else:
                    colors = color_palette(n_colors=n_colors)

            # Allow for palette to map from hue variable names
            elif isinstance(palette, dict):
                color_names = [palette[h] for h in hue_names]
                colors = color_palette(color_names, n_colors)

            # Otherwise act as if we just got a list of colors
            else:
                colors = color_palette(palette, n_colors)

            palette = color_palette(colors, n_colors)

        return palette

    @property
    def legend(self):
        """The :class:`matplotlib.legend.Legend` object, if present."""
        try:
            return self._legend
        except AttributeError:
            return None

    def tick_params(self, axis='both', **kwargs):
        """Modify the ticks, tick labels, and gridlines.

        Parameters
        ----------
        axis : {'x', 'y', 'both'}
            The axis on which to apply the formatting.
        kwargs : keyword arguments
            Additional keyword arguments to pass to
            :meth:`matplotlib.axes.Axes.tick_params`.

        Returns
        -------
        self : Grid instance
            Returns self for easy chaining.

        """
        for ax in self.figure.axes:
            ax.tick_params(axis=axis, **kwargs)
        return self


_facet_docs = dict(

    data=dedent("""\
    data : DataFrame
        Tidy ("long-form") dataframe where each column is a variable and each
        row is an observation.\
    """),
    rowcol=dedent("""\
    row, col : vectors or keys in ``data``
        Variables that define subsets to plot on different facets.\
    """),
    rowcol_order=dedent("""\
    {row,col}_order : vector of strings
        Specify the order in which levels of the ``row`` and/or ``col`` variables
        appear in the grid of subplots.\
    """),
    col_wrap=dedent("""\
    col_wrap : int
        "Wrap" the column variable at this width, so that the column facets
        span multiple rows. Incompatible with a ``row`` facet.\
    """),
    share_xy=dedent("""\
    share{x,y} : bool, 'col', or 'row' optional
        If true, the facets will share y axes across columns and/or x axes
        across rows.\
    """),
    height=dedent("""\
    height : scalar
        Height (in inches) of each facet. See also: ``aspect``.\
    """),
    aspect=dedent("""\
    aspect : scalar
        Aspect ratio of each facet, so that ``aspect * height`` gives the width
        of each facet in inches.\
    """),
    palette=dedent("""\
    palette : palette name, list, or dict
        Colors to use for the different levels of the ``hue`` variable. Should
        be something that can be interpreted by :func:`color_palette`, or a
        dictionary mapping hue levels to matplotlib colors.\
    """),
    legend_out=dedent("""\
    legend_out : bool
        If ``True``, the figure size will be extended, and the legend will be
        drawn outside the plot on the center right.\
    """),
    margin_titles=dedent("""\
    margin_titles : bool
        If ``True``, the titles for the row variable are drawn to the right of
        the last column. This option is experimental and may not work in all
        cases.\
    """),
    facet_kws=dedent("""\
    facet_kws : dict
        Additional parameters passed to :class:`FacetGrid`.
    """),
)


class FacetGrid(Grid):
    """Multi-plot grid for plotting conditional relationships."""

    def __init__(
        self, data, *,
        row=None, col=None, hue=None, col_wrap=None,
        sharex=True, sharey=True, height=3, aspect=1, palette=None,
        row_order=None, col_order=None, hue_order=None, hue_kws=None,
        dropna=False, legend_out=True, despine=True,
        margin_titles=False, xlim=None, ylim=None, subplot_kws=None,
        gridspec_kws=None,
    ):

        super().__init__()
        data = handle_data_source(data)

        # Determine the hue facet layer information
        hue_var = hue
        if hue is None:
            hue_names = None
        else:
            hue_names = categorical_order(data[hue], hue_order)

        colors = self._get_palette(data, hue, hue_order, palette)

        # Set up the lists of names for the row and column facet variables
        if row is None:
            row_names = []
        else:
            row_names = categorical_order(data[row], row_order)

        if col is None:
            col_names = []
        else:
            col_names = categorical_order(data[col], col_order)

        # Additional dict of kwarg -> list of values for mapping the hue var
        hue_kws = hue_kws if hue_kws is not None else {}

        # Make a boolean mask that is True anywhere there is an NA
        # value in one of the faceting variables, but only if dropna is True
        none_na = np.zeros(len(data), bool)
        if dropna:
            row_na = none_na if row is None else data[row].isnull()
            col_na = none_na if col is None else data[col].isnull()
            hue_na = none_na if hue is None else data[hue].isnull()
            not_na = ~(row_na | col_na | hue_na)
        else:
            not_na = ~none_na

        # Compute the grid shape
        ncol = 1 if col is None else len(col_names)
        nrow = 1 if row is None else len(row_names)
        self._n_facets = ncol * nrow

        self._col_wrap = col_wrap
        if col_wrap is not None:
            if row is not None:
                err = "Cannot use `row` and `col_wrap` together."
                raise ValueError(err)
            ncol = col_wrap
            nrow = int(np.ceil(len(col_names) / col_wrap))
        self._ncol = ncol
        self._nrow = nrow

        # Calculate the base figure size
        # This can get stretched later by a legend
        # TODO this doesn't account for axis labels
        figsize = (ncol * height * aspect, nrow * height)

        # Validate some inputs
        if col_wrap is not None:
            margin_titles = False

        # Build the subplot keyword dictionary
        subplot_kws = {} if subplot_kws is None else subplot_kws.copy()
        gridspec_kws = {} if gridspec_kws is None else gridspec_kws.copy()
        if xlim is not None:
            subplot_kws["xlim"] = xlim
        if ylim is not None:
            subplot_kws["ylim"] = ylim

        # --- Initialize the subplot grid

        with _disable_autolayout():
            fig = plt.figure(figsize=figsize)

        if col_wrap is None:

            kwargs = dict(squeeze=False,
                          sharex=sharex, sharey=sharey,
                          subplot_kw=subplot_kws,
                          gridspec_kw=gridspec_kws)

            axes = fig.subplots(nrow, ncol, **kwargs)

            if col is None and row is None:
                axes_dict = {}
            elif col is None:
                axes_dict = dict(zip(row_names, axes.flat))
            elif row is None:
                axes_dict = dict(zip(col_names, axes.flat))
            else:
tests/__init__.py
tests/_core/__init__.py
tests/_core/test_data.py
tests/_core/test_groupby.py
tests/_core/test_moves.py
tests/_core/test_plot.py
tests/_core/test_properties.py
tests/_core/test_rules.py
tests/_core/test_scales.py
tests/_core/test_subplots.py
tests/_marks/__init__.py
tests/_marks/test_area.py
tests/_marks/test_bar.py
tests/_marks/test_base.py
tests/_marks/test_dot.py
tests/_marks/test_line.py
tests/_marks/test_text.py
tests/_stats/__init__.py
tests/_stats/test_aggregation.py
tests/_stats/test_counting.py
tests/_stats/test_density.py
tests/_stats/test_order.py
tests/_stats/test_regression.py
tests/conftest.py
tests/test_algorithms.py
tests/test_axisgrid.py
tests/test_base.py
tests/test_categorical.py
tests/test_docstrings.py
tests/test_matrix.py
tests/test_miscplot.py
tests/test_objects.py
tests/test_palettes.py
tests/test_rcmod.py
tests/test_regression.py
tests/test_relational.py
tests/test_statistics.py
tests/test_utils.py
```

## 原始行 16 · command_execution

命令：
```
/bin/bash -lc "git status --short
nl -ba seaborn/palettes.py | sed -n '620,770p'
nl -ba seaborn/axisgrid.py | sed -n '440,620p'
grep -nE \"cubehelix|color_cycle|get_colormap|axes_dict|\\.ax\" tests/test_palettes.py tests/test_utils.py tests/test_axisgrid.py | head -300"
```

退出码：`0`

输出：
```
   620	    ----------
   621	    colors : list of strings
   622	        List of keys in the `seaborn.xkcd_rgb` dictionary.
   623	
   624	    Returns
   625	    -------
   626	    palette
   627	        A list of colors as RGB tuples.
   628	
   629	    See Also
   630	    --------
   631	    crayon_palette : Make a palette with Crayola crayon colors.
   632	
   633	    """
   634	    palette = [xkcd_rgb[name] for name in colors]
   635	    return color_palette(palette, len(palette))
   636	
   637	
   638	def crayon_palette(colors):
   639	    """Make a palette with color names from Crayola crayons.
   640	
   641	    Colors are taken from here:
   642	    https://en.wikipedia.org/wiki/List_of_Crayola_crayon_colors
   643	
   644	    This is just a simple wrapper around the `seaborn.crayons` dictionary.
   645	
   646	    Parameters
   647	    ----------
   648	    colors : list of strings
   649	        List of keys in the `seaborn.crayons` dictionary.
   650	
   651	    Returns
   652	    -------
   653	    palette
   654	        A list of colors as RGB tuples.
   655	
   656	    See Also
   657	    --------
   658	    xkcd_palette : Make a palette with named colors from the XKCD color survey.
   659	
   660	    """
   661	    palette = [crayons[name] for name in colors]
   662	    return color_palette(palette, len(palette))
   663	
   664	
   665	def cubehelix_palette(n_colors=6, start=0, rot=.4, gamma=1.0, hue=0.8,
   666	                      light=.85, dark=.15, reverse=False, as_cmap=False):
   667	    """Make a sequential palette from the cubehelix system.
   668	
   669	    This produces a colormap with linearly-decreasing (or increasing)
   670	    brightness. That means that information will be preserved if printed to
   671	    black and white or viewed by someone who is colorblind.  "cubehelix" is
   672	    also available as a matplotlib-based palette, but this function gives the
   673	    user more control over the look of the palette and has a different set of
   674	    defaults.
   675	
   676	    In addition to using this function, it is also possible to generate a
   677	    cubehelix palette generally in seaborn using a string starting with
   678	    `ch:` and containing other parameters (e.g. `"ch:s=.25,r=-.5"`).
   679	
   680	    Parameters
   681	    ----------
   682	    n_colors : int
   683	        Number of colors in the palette.
   684	    start : float, 0 <= start <= 3
   685	        The hue value at the start of the helix.
   686	    rot : float
   687	        Rotations around the hue wheel over the range of the palette.
   688	    gamma : float 0 <= gamma
   689	        Nonlinearity to emphasize dark (gamma < 1) or light (gamma > 1) colors.
   690	    hue : float, 0 <= hue <= 1
   691	        Saturation of the colors.
   692	    dark : float 0 <= dark <= 1
   693	        Intensity of the darkest color in the palette.
   694	    light : float 0 <= light <= 1
   695	        Intensity of the lightest color in the palette.
   696	    reverse : bool
   697	        If True, the palette will go from dark to light.
   698	    as_cmap : bool
   699	        If True, return a :class:`matplotlib.colors.ListedColormap`.
   700	
   701	    Returns
   702	    -------
   703	    palette
   704	        list of RGB tuples or :class:`matplotlib.colors.ListedColormap`
   705	
   706	    See Also
   707	    --------
   708	    choose_cubehelix_palette : Launch an interactive widget to select cubehelix
   709	                               palette parameters.
   710	    dark_palette : Create a sequential palette with dark low values.
   711	    light_palette : Create a sequential palette with bright low values.
   712	
   713	    References
   714	    ----------
   715	    Green, D. A. (2011). "A colour scheme for the display of astronomical
   716	    intensity images". Bulletin of the Astromical Society of India, Vol. 39,
   717	    p. 289-295.
   718	
   719	    Examples
   720	    --------
   721	    .. include:: ../docstrings/cubehelix_palette.rst
   722	
   723	    """
   724	
   725	
   726	
   727	
   728	
   729	
   730	
   731	
   732	
   733	
   734	
   735	
   736	
   737	
   738	
   739	
   740	    cdict = {
   741	        "red": get_color_function(-0.14861, 1.78277),
   742	        "green": get_color_function(-0.29227, -0.90649),
   743	        "blue": get_color_function(1.97294, 0.0),
   744	    }
   745	
   746	    cmap = mpl.colors.LinearSegmentedColormap("cubehelix", cdict)
   747	
   748	    x = np.linspace(light, dark, int(n_colors))
   749	    pal = cmap(x)[:, :3].tolist()
   750	    if reverse:
   751	        pal = pal[::-1]
   752	
   753	    if as_cmap:
   754	        x_256 = np.linspace(light, dark, 256)
   755	        if reverse:
   756	            x_256 = x_256[::-1]
   757	        pal_256 = cmap(x_256)
   758	        cmap = mpl.colors.ListedColormap(pal_256, "seaborn_cubehelix")
   759	        return cmap
   760	    else:
   761	        return _ColorPalette(pal)
   762	
   763	
   764	
   765	
   766	
   767	
   768	
   769	
   770	
   440	            margin_titles = False
   441	
   442	        # Build the subplot keyword dictionary
   443	        subplot_kws = {} if subplot_kws is None else subplot_kws.copy()
   444	        gridspec_kws = {} if gridspec_kws is None else gridspec_kws.copy()
   445	        if xlim is not None:
   446	            subplot_kws["xlim"] = xlim
   447	        if ylim is not None:
   448	            subplot_kws["ylim"] = ylim
   449	
   450	        # --- Initialize the subplot grid
   451	
   452	        with _disable_autolayout():
   453	            fig = plt.figure(figsize=figsize)
   454	
   455	        if col_wrap is None:
   456	
   457	            kwargs = dict(squeeze=False,
   458	                          sharex=sharex, sharey=sharey,
   459	                          subplot_kw=subplot_kws,
   460	                          gridspec_kw=gridspec_kws)
   461	
   462	            axes = fig.subplots(nrow, ncol, **kwargs)
   463	
   464	            if col is None and row is None:
   465	                axes_dict = {}
   466	            elif col is None:
   467	                axes_dict = dict(zip(row_names, axes.flat))
   468	            elif row is None:
   469	                axes_dict = dict(zip(col_names, axes.flat))
   470	            else:
   471	                facet_product = product(row_names, col_names)
   472	                axes_dict = dict(zip(facet_product, axes.flat))
   473	
   474	        else:
   475	
   476	            # If wrapping the col variable we need to make the grid ourselves
   477	            if gridspec_kws:
   478	                warnings.warn("`gridspec_kws` ignored when using `col_wrap`")
   479	
   480	            n_axes = len(col_names)
   481	            axes = np.empty(n_axes, object)
   482	            axes[0] = fig.add_subplot(nrow, ncol, 1, **subplot_kws)
   483	            if sharex:
   484	                subplot_kws["sharex"] = axes[0]
   485	            if sharey:
   486	                subplot_kws["sharey"] = axes[0]
   487	            for i in range(1, n_axes):
   488	                axes[i] = fig.add_subplot(nrow, ncol, i + 1, **subplot_kws)
   489	
   490	            axes_dict = dict(zip(col_names, axes))
   491	
   492	        # --- Set up the class attributes
   493	
   494	        # Attributes that are part of the public API but accessed through
   495	        # a  property so that Sphinx adds them to the auto class doc
   496	        self._figure = fig
   497	        self._axes = axes
   498	        self._axes_dict = axes_dict
   499	        self._legend = None
   500	
   501	        # Public attributes that aren't explicitly documented
   502	        # (It's not obvious that having them be public was a good idea)
   503	        self.data = data
   504	        self.row_names = row_names
   505	        self.col_names = col_names
   506	        self.hue_names = hue_names
   507	        self.hue_kws = hue_kws
   508	
   509	        # Next the private variables
   510	        self._nrow = nrow
   511	        self._row_var = row
   512	        self._ncol = ncol
   513	        self._col_var = col
   514	
   515	        self._margin_titles = margin_titles
   516	        self._margin_titles_texts = []
   517	        self._col_wrap = col_wrap
   518	        self._hue_var = hue_var
   519	        self._colors = colors
   520	        self._legend_out = legend_out
   521	        self._legend_data = {}
   522	        self._x_var = None
   523	        self._y_var = None
   524	        self._sharex = sharex
   525	        self._sharey = sharey
   526	        self._dropna = dropna
   527	        self._not_na = not_na
   528	
   529	        # --- Make the axes look good
   530	
   531	        self.set_titles()
   532	        self.tight_layout()
   533	
   534	        if despine:
   535	            self.despine()
   536	
   537	        if sharex in [True, 'col']:
   538	            for ax in self._not_bottom_axes:
   539	                for label in ax.get_xticklabels():
   540	                    label.set_visible(False)
   541	                ax.xaxis.offsetText.set_visible(False)
   542	                ax.xaxis.label.set_visible(False)
   543	
   544	        if sharey in [True, 'row']:
   545	            for ax in self._not_left_axes:
   546	                for label in ax.get_yticklabels():
   547	                    label.set_visible(False)
   548	                ax.yaxis.offsetText.set_visible(False)
   549	                ax.yaxis.label.set_visible(False)
   550	
   551	    __init__.__doc__ = dedent("""\
   552	        Initialize the matplotlib figure and FacetGrid object.
   553	
   554	        This class maps a dataset onto multiple axes arrayed in a grid of rows
   555	        and columns that correspond to *levels* of variables in the dataset.
   556	        The plots it produces are often called "lattice", "trellis", or
   557	        "small-multiple" graphics.
   558	
   559	        It can also represent levels of a third variable with the ``hue``
   560	        parameter, which plots different subsets of data in different colors.
   561	        This uses color to resolve elements on a third dimension, but only
   562	        draws subsets on top of each other and will not tailor the ``hue``
   563	        parameter for the specific visualization the way that axes-level
   564	        functions that accept ``hue`` will.
   565	
   566	        The basic workflow is to initialize the :class:`FacetGrid` object with
   567	        the dataset and the variables that are used to structure the grid. Then
   568	        one or more plotting functions can be applied to each subset by calling
   569	        :meth:`FacetGrid.map` or :meth:`FacetGrid.map_dataframe`. Finally, the
   570	        plot can be tweaked with other methods to do things like change the
   571	        axis labels, use different ticks, or add a legend. See the detailed
   572	        code examples below for more information.
   573	
   574	        .. warning::
   575	
   576	            When using seaborn functions that infer semantic mappings from a
   577	            dataset, care must be taken to synchronize those mappings across
   578	            facets (e.g., by defining the ``hue`` mapping with a palette dict or
   579	            setting the data type of the variables to ``category``). In most cases,
   580	            it will be better to use a figure-level function (e.g. :func:`relplot`
   581	            or :func:`catplot`) than to use :class:`FacetGrid` directly.
   582	
   583	        See the :ref:`tutorial <grid_tutorial>` for more information.
   584	
   585	        Parameters
   586	        ----------
   587	        {data}
   588	        row, col, hue : strings
   589	            Variables that define subsets of the data, which will be drawn on
   590	            separate facets in the grid. See the ``{{var}}_order`` parameters to
   591	            control the order of levels of this variable.
   592	        {col_wrap}
   593	        {share_xy}
   594	        {height}
   595	        {aspect}
   596	        {palette}
   597	        {{row,col,hue}}_order : lists
   598	            Order for the levels of the faceting variables. By default, this
   599	            will be the order that the levels appear in ``data`` or, if the
   600	            variables are pandas categoricals, the category order.
   601	        hue_kws : dictionary of param -> list of values mapping
   602	            Other keyword arguments to insert into the plotting call to let
   603	            other plot attributes vary across levels of the hue variable (e.g.
   604	            the markers in a scatterplot).
   605	        {legend_out}
   606	        despine : boolean
   607	            Remove the top and right spines from the plots.
   608	        {margin_titles}
   609	        {{x, y}}lim: tuples
   610	            Limits for each of the axes on each facet (only relevant when
   611	            share{{x, y}} is True).
   612	        subplot_kws : dict
   613	            Dictionary of keyword arguments passed to matplotlib subplot(s)
   614	            methods.
   615	        gridspec_kws : dict
   616	            Dictionary of keyword arguments passed to
   617	            :class:`matplotlib.gridspec.GridSpec`
   618	            (via :meth:`matplotlib.figure.Figure.subplots`).
   619	            Ignored if ``col_wrap`` is not ``None``.
   620	
tests/test_palettes.py:10:from seaborn._compat import get_colormap
tests/test_palettes.py:20:        assert pal == utils.get_color_cycle()
tests/test_palettes.py:29:            assert utils.get_color_cycle() == context_pal
tests/test_palettes.py:31:        assert utils.get_color_cycle() == default_pal
tests/test_palettes.py:40:            assert utils.get_color_cycle() == context_pal
tests/test_palettes.py:42:        assert utils.get_color_cycle() == original_pal
tests/test_palettes.py:99:        cmap1 = get_colormap("Reds")
tests/test_palettes.py:317:    def test_cubehelix_against_matplotlib(self):
tests/test_palettes.py:320:        mpl_pal = mpl.cm.cubehelix(x)[:, :3].tolist()
tests/test_palettes.py:322:        sns_pal = palettes.cubehelix_palette(8, start=0.5, rot=-1.5, hue=1,
tests/test_palettes.py:327:    def test_cubehelix_n_colors(self):
tests/test_palettes.py:330:            pal = palettes.cubehelix_palette(n)
tests/test_palettes.py:333:    def test_cubehelix_reverse(self):
tests/test_palettes.py:335:        pal_forward = palettes.cubehelix_palette()
tests/test_palettes.py:336:        pal_reverse = palettes.cubehelix_palette(reverse=True)
tests/test_palettes.py:339:    def test_cubehelix_cmap(self):
tests/test_palettes.py:341:        cmap = palettes.cubehelix_palette(as_cmap=True)
tests/test_palettes.py:343:        pal = palettes.cubehelix_palette()
tests/test_palettes.py:347:        cmap_rev = palettes.cubehelix_palette(as_cmap=True, reverse=True)
tests/test_palettes.py:353:    def test_cubehelix_code(self):
tests/test_palettes.py:356:        cubehelix_palette = palettes.cubehelix_palette
tests/test_palettes.py:359:        pal2 = color_palette(cubehelix_palette(8))
tests/test_palettes.py:363:        pal2 = color_palette(cubehelix_palette(8, .5, -.25, hue=.5, light=.75))
tests/test_palettes.py:367:        pal2 = color_palette(cubehelix_palette(9, hue=1, rot=.5))
tests/test_palettes.py:371:        pal2 = color_palette(cubehelix_palette(6, reverse=True))
tests/test_palettes.py:375:        pal2 = cubehelix_palette(6, reverse=True, as_cmap=True)
tests/test_utils.py:26:    get_color_cycle,
tests/test_utils.py:298:    assert not utils.axis_ticklabels_overlap(ax.get_xticklabels())
tests/test_utils.py:305:    assert utils.axis_ticklabels_overlap(ax.get_xticklabels())
tests/test_utils.py:307:    x, y = utils.axes_ticklabels_overlap(ax)
tests/test_utils.py:394:    from seaborn.axisgrid import FacetGrid
tests/test_utils.py:548:def test_get_color_cycle(cycler, result):
tests/test_utils.py:550:        assert get_color_cycle() == result
tests/test_axisgrid.py:51:        for ax in g.axes.flat:
tests/test_axisgrid.py:57:        assert g.axes.shape == (1, 1)
tests/test_axisgrid.py:60:        assert g.axes.shape == (3, 1)
tests/test_axisgrid.py:63:        assert g.axes.shape == (1, 2)
tests/test_axisgrid.py:66:        assert g.axes.shape == (1, 1)
tests/test_axisgrid.py:69:        assert g.axes.shape == (3, 2)
tests/test_axisgrid.py:70:        for ax in g.axes.flat:
tests/test_axisgrid.py:76:        assert isinstance(g.ax, plt.Axes)
tests/test_axisgrid.py:80:            g.ax
tests/test_axisgrid.py:84:            g.ax
tests/test_axisgrid.py:88:            g.ax
tests/test_axisgrid.py:95:        assert g.axes.shape == (1, n)
tests/test_axisgrid.py:96:        assert g.facet_axis(0, 8) is g.axes[0, 8]
tests/test_axisgrid.py:99:        assert g_wrap.axes.shape == (n,)
tests/test_axisgrid.py:100:        assert g_wrap.facet_axis(0, 8) is g_wrap.axes[8]
tests/test_axisgrid.py:110:        assert g_missing.axes.shape == (1, n - 1)
tests/test_axisgrid.py:113:        assert g_missing_wrap.axes.shape == (n - 1,)
tests/test_axisgrid.py:123:        npt.assert_array_equal(g._bottom_axes, g.axes.flat)
tests/test_axisgrid.py:125:        npt.assert_array_equal(g._left_axes, g.axes.flat)
tests/test_axisgrid.py:130:        npt.assert_array_equal(g._bottom_axes, g.axes.flat)
tests/test_axisgrid.py:132:        npt.assert_array_equal(g._left_axes, g.axes[:, 0].flat)
tests/test_axisgrid.py:133:        npt.assert_array_equal(g._not_left_axes, g.axes[:, 1:].flat)
tests/test_axisgrid.py:137:        npt.assert_array_equal(g._bottom_axes, g.axes[-1, :].flat)
tests/test_axisgrid.py:138:        npt.assert_array_equal(g._not_bottom_axes, g.axes[:-1, :].flat)
tests/test_axisgrid.py:139:        npt.assert_array_equal(g._left_axes, g.axes.flat)
tests/test_axisgrid.py:144:        npt.assert_array_equal(g._bottom_axes, g.axes[-1, :].flat)
tests/test_axisgrid.py:145:        npt.assert_array_equal(g._not_bottom_axes, g.axes[:-1, :].flat)
tests/test_axisgrid.py:146:        npt.assert_array_equal(g._left_axes, g.axes[:, 0].flat)
tests/test_axisgrid.py:147:        npt.assert_array_equal(g._not_left_axes, g.axes[:, 1:].flat)
tests/test_axisgrid.py:148:        npt.assert_array_equal(g._inner_axes, g.axes[:-1, 1:].flat)
tests/test_axisgrid.py:156:                               g.axes[np.array([1, 2])].flat)
tests/test_axisgrid.py:157:        npt.assert_array_equal(g._not_bottom_axes, g.axes[:1].flat)
tests/test_axisgrid.py:158:        npt.assert_array_equal(g._left_axes, g.axes[np.array([0, 2])].flat)
tests/test_axisgrid.py:159:        npt.assert_array_equal(g._not_left_axes, g.axes[np.array([1])].flat)
tests/test_axisgrid.py:162:    def test_axes_dict(self):
tests/test_axisgrid.py:165:        assert isinstance(g.axes_dict, dict)
tests/test_axisgrid.py:166:        assert not g.axes_dict
tests/test_axisgrid.py:169:        assert list(g.axes_dict.keys()) == g.row_names
tests/test_axisgrid.py:170:        for (name, ax) in zip(g.row_names, g.axes.flat):
tests/test_axisgrid.py:171:            assert g.axes_dict[name] is ax
tests/test_axisgrid.py:174:        assert list(g.axes_dict.keys()) == g.col_names
tests/test_axisgrid.py:175:        for (name, ax) in zip(g.col_names, g.axes.flat):
tests/test_axisgrid.py:176:            assert g.axes_dict[name] is ax
tests/test_axisgrid.py:179:        assert list(g.axes_dict.keys()) == g.col_names
tests/test_axisgrid.py:180:        for (name, ax) in zip(g.col_names, g.axes.flat):
tests/test_axisgrid.py:181:            assert g.axes_dict[name] is ax
tests/test_axisgrid.py:184:        for (row_var, col_var), ax in g.axes_dict.items():
tests/test_axisgrid.py:187:            assert g.axes[i, j] is ax
tests/test_axisgrid.py:290:        handles, labels = g.ax.get_legend_handles_labels()
tests/test_axisgrid.py:323:        axes_right_edge = g.ax.get_window_extent().xmax
tests/test_axisgrid.py:332:        for ax in g.axes.flat:
tests/test_axisgrid.py:341:        for ax in g.axes.flat:
tests/test_axisgrid.py:347:        for (l, m, r) in g.axes:
tests/test_axisgrid.py:403:        lines = g.axes[0, 0].lines
tests/test_axisgrid.py:424:        lines = g.axes[0, 0].lines
tests/test_axisgrid.py:425:        assert len(g.axes[0, 0].lines) == 3
tests/test_axisgrid.py:442:        for ax in g.axes.flat:
tests/test_axisgrid.py:454:        assert g.axes[0, 0].get_title() == "a = a | b = m"
tests/test_axisgrid.py:455:        assert g.axes[0, 1].get_title() == "a = a | b = n"
tests/test_axisgrid.py:456:        assert g.axes[1, 0].get_title() == "a = b | b = m"
tests/test_axisgrid.py:460:        assert g.axes[0, 0].get_title() == "a == a \\/ b == m"
tests/test_axisgrid.py:461:        assert g.axes[0, 1].get_title() == "a == a \\/ b == n"
tests/test_axisgrid.py:462:        assert g.axes[1, 0].get_title() == "a == b \\/ b == m"
tests/test_axisgrid.py:469:        assert g.axes[0, 0].get_title() == "b = m"
tests/test_axisgrid.py:470:        assert g.axes[0, 1].get_title() == "b = n"
tests/test_axisgrid.py:482:        assert g.axes[0, 0].get_title() == "b = m"
tests/test_axisgrid.py:483:        assert g.axes[0, 1].get_title() == "b = n"
tests/test_axisgrid.py:484:        assert g.axes[1, 0].get_title() == ""
tests/test_axisgrid.py:487:        assert g.axes[0, 1].texts[0].get_text() == "a = a"
tests/test_axisgrid.py:488:        assert g.axes[1, 1].texts[0].get_text() == "a = b"
tests/test_axisgrid.py:489:        assert g.axes[0, 1].texts[0] is g._margin_titles_texts[0]
tests/test_axisgrid.py:493:        assert g.axes[0, 0].get_title() == "m"
tests/test_axisgrid.py:494:        assert g.axes[0, 1].get_title() == "n"
tests/test_axisgrid.py:495:        assert g.axes[1, 0].get_title() == ""
tests/test_axisgrid.py:497:        assert len(g.axes[1, 1].texts) == 1
tests/test_axisgrid.py:498:        assert g.axes[1, 1].texts[0].get_text() == "b"
tests/test_axisgrid.py:505:        ax = g.axes[-1, 0]
tests/test_axisgrid.py:511:        got_x = [l.get_text() for l in g.axes[-1, 1].get_xticklabels()]
tests/test_axisgrid.py:512:        got_y = [l.get_text() for l in g.axes[0, 0].get_yticklabels()]
tests/test_axisgrid.py:520:        got_x = [int(l.get_text()) for l in g.axes[0, 0].get_xticklabels()]
tests/test_axisgrid.py:543:        got_x = [ax.get_xlabel() for ax in g.axes[-1, :]]
tests/test_axisgrid.py:544:        got_y = [ax.get_ylabel() for ax in g.axes[:, 0]]
tests/test_axisgrid.py:548:        for ax in g.axes.flat:
tests/test_axisgrid.py:560:        assert g.axes[0, 0].get_xlim() == (0, 4)
tests/test_axisgrid.py:561:        assert g.axes[0, 0].get_ylim() == (-2, 3)
tests/test_axisgrid.py:570:        assert g.axes.shape == (3, 2)
tests/test_axisgrid.py:580:        assert g.axes.shape == (3, 2)
tests/test_axisgrid.py:590:        assert g.axes.shape == (4, 3)
tests/test_axisgrid.py:621:        for line, marker in zip(g.axes[0, 0].lines, kws["marker"]):
tests/test_axisgrid.py:643:        assert g.axes.shape == (len(df['a'].cat.categories),)
tests/test_axisgrid.py:655:        for ax in g.axes.flat:
tests/test_axisgrid.py:662:        for ax in g.axes.flat:
tests/test_axisgrid.py:671:        npt.assert_array_equal(g.axes[0, 0].lines[-1].get_xydata(), vline)
tests/test_axisgrid.py:672:        assert g.axes[0, 0].lines[-1].get_color() == color
tests/test_axisgrid.py:673:        assert g.axes[0, 0].lines[-1].get_linestyle() == linestyle
tests/test_axisgrid.py:704:        for ax in g.axes.flat:
tests/test_axisgrid.py:720:        assert g.axes.shape == (long_df["b"].nunique(), long_df["a"].nunique())
tests/test_axisgrid.py:721:        for ax in g.axes.flat:
tests/test_axisgrid.py:756:        for ax in g.axes.flat:
tests/test_axisgrid.py:762:        assert g.axes.shape == (3, 3)
tests/test_axisgrid.py:771:        assert g.axes.shape == (len(vars), len(vars))
tests/test_axisgrid.py:799:        assert g.axes.shape == (len(y_vars), len(x_vars))
tests/test_axisgrid.py:809:        assert len(g.figure.axes) == corner_size
tests/test_axisgrid.py:812:        assert len(g.figure.axes) == (corner_size + len(plot_vars))
tests/test_axisgrid.py:814:        for ax in np.diag(g.axes):
tests/test_axisgrid.py:820:        assert len(g.figure.axes) == corner_size
tests/test_axisgrid.py:821:        assert g.axes[0, 0].get_ylabel() == "x"
tests/test_axisgrid.py:846:        for i, axes_i in enumerate(g1.axes):
tests/test_axisgrid.py:857:        for i, axes_i in enumerate(g2.axes):
tests/test_axisgrid.py:877:            ax = g.axes[i, 0]
tests/test_axisgrid.py:889:        for i, j in zip(*np.tril_indices_from(g.axes, -1)):
tests/test_axisgrid.py:890:            ax = g.axes[i, j]
tests/test_axisgrid.py:897:        for i, j in zip(*np.triu_indices_from(g.axes)):
tests/test_axisgrid.py:898:            ax = g.axes[i, j]
tests/test_axisgrid.py:907:        for i, j in zip(*np.triu_indices_from(g.axes, 1)):
tests/test_axisgrid.py:908:            ax = g.axes[i, j]
tests/test_axisgrid.py:915:        for i, j in zip(*np.tril_indices_from(g.axes)):
tests/test_axisgrid.py:916:            ax = g.axes[i, j]
tests/test_axisgrid.py:926:        for i, j in zip(*np.triu_indices_from(g.axes, 1)):
tests/test_axisgrid.py:927:            ax = g.axes[i, j]
tests/test_axisgrid.py:973:                ax = g1.axes[i, j]
tests/test_axisgrid.py:1007:                ax = g3.axes[i, j]
tests/test_axisgrid.py:1055:        for i, j in zip(*np.triu_indices_from(g.axes, 1)):
tests/test_axisgrid.py:1056:            ax = g.axes[i, j]
tests/test_axisgrid.py:1063:        for i, j in zip(*np.tril_indices_from(g.axes, -1)):
tests/test_axisgrid.py:1064:            ax = g.axes[i, j]
tests/test_axisgrid.py:1071:        for i, j in zip(*np.diag_indices_from(g.axes)):
tests/test_axisgrid.py:1072:            ax = g.axes[i, j]
tests/test_axisgrid.py:1125:        for line, marker in zip(g.axes[0, 0].lines, kws["marker"]):
tests/test_axisgrid.py:1132:        for line, marker in zip(g.axes[0, 0].lines, kws["marker"]):
tests/test_axisgrid.py:1141:        for line, level in zip(g.axes[1, 0].lines, order):
tests/test_axisgrid.py:1151:        for line, level in zip(g.axes[0, 0].lines, order):
tests/test_axisgrid.py:1161:        for line, level in zip(g.axes[1, 0].lines, order):
tests/test_axisgrid.py:1171:        for line, level in zip(g.axes[0, 1].lines, order):
tests/test_axisgrid.py:1184:        for line, level in zip(g.axes[1, 0].lines, order):
tests/test_axisgrid.py:1194:        for line, level in zip(g.axes[0, 0].lines, order):
tests/test_axisgrid.py:1204:        for line, level in zip(g.axes[1, 0].lines, order):
tests/test_axisgrid.py:1214:        for line, level in zip(g.axes[0, 1].lines, order):
tests/test_axisgrid.py:1225:        ax = g.axes.flat[0]
tests/test_axisgrid.py:1237:        for i, axes_i in enumerate(g1.axes):
tests/test_axisgrid.py:1248:        for i, axes_i in enumerate(g2.axes):
tests/test_axisgrid.py:1271:        for i, axes_i in enumerate(g1.axes):
tests/test_axisgrid.py:1305:        for i, j in zip(*np.triu_indices_from(g.axes, 1)):
tests/test_axisgrid.py:1306:            ax = g.axes[i, j]
tests/test_axisgrid.py:1313:        for i, j in zip(*np.tril_indices_from(g.axes, -1)):
tests/test_axisgrid.py:1314:            ax = g.axes[i, j]
tests/test_axisgrid.py:1321:        for i, j in zip(*np.diag_indices_from(g.axes)):
tests/test_axisgrid.py:1322:            ax = g.axes[i, j]
tests/test_axisgrid.py:1339:        for i, j in zip(*np.triu_indices_from(g.axes, 1)):
tests/test_axisgrid.py:1340:            ax = g.axes[i, j]
tests/test_axisgrid.py:1350:        for i, j in zip(*np.tril_indices_from(g.axes, -1)):
tests/test_axisgrid.py:1351:            ax = g.axes[i, j]
tests/test_axisgrid.py:1361:        for i, j in zip(*np.diag_indices_from(g.axes)):
tests/test_axisgrid.py:1362:            ax = g.axes[i, j]
tests/test_axisgrid.py:1370:        ax = g.axes[-1, 0]
tests/test_axisgrid.py:1387:        for i, j in zip(*np.triu_indices_from(g.axes, 1)):
tests/test_axisgrid.py:1388:            ax = g.axes[i, j]
tests/test_axisgrid.py:1395:        for i, j in zip(*np.tril_indices_from(g.axes, -1)):
tests/test_axisgrid.py:1396:            ax = g.axes[i, j]
tests/test_axisgrid.py:1403:        for i, j in zip(*np.diag_indices_from(g.axes)):
tests/test_axisgrid.py:1404:            ax = g.axes[i, j]
tests/test_axisgrid.py:1413:        ax2 = g.axes[1, 0]
tests/test_axisgrid.py:1423:        ax2 = g.axes[1, 0]
tests/test_axisgrid.py:1451:        assert g.axes[0, 0].spines["top"].get_visible()
tests/test_axisgrid.py:1457:        assert g.axes[-1, 0].get_xlim() == (0, 10)
tests/test_axisgrid.py:1473:        for ax in g.axes.flat:
tests/test_axisgrid.py:1488:        assert g.axes.shape == (3, 3)
tests/test_axisgrid.py:1489:        for ax in g.axes.flat:
tests/test_axisgrid.py:1537:        xlabel, ylabel = g.ax_joint.get_xlabel(), g.ax_joint.get_ylabel()
tests/test_axisgrid.py:1542:        xlabel, ylabel = g.ax_joint.get_xlabel(), g.ax_joint.get_ylabel()
tests/test_axisgrid.py:1559:        assert g.ax_joint.get_xlim() == lim
tests/test_axisgrid.py:1560:        assert g.ax_joint.get_ylim() == lim
tests/test_axisgrid.py:1562:        assert g.ax_marg_x.get_xlim() == lim
tests/test_axisgrid.py:1563:        assert g.ax_marg_y.get_ylim() == lim
tests/test_axisgrid.py:1568:        assert not sum(t.get_visible() for t in g.ax_marg_x.get_yticklabels())
tests/test_axisgrid.py:1569:        assert not sum(t.get_visible() for t in g.ax_marg_y.get_xticklabels())
tests/test_axisgrid.py:1572:        assert sum(t.get_visible() for t in g.ax_marg_x.get_yticklabels())
tests/test_axisgrid.py:1573:        assert sum(t.get_visible() for t in g.ax_marg_y.get_xticklabels())
tests/test_axisgrid.py:1580:        x, y = g.ax_joint.lines[0].get_xydata().T
tests/test_axisgrid.py:1589:        _, y1 = g.ax_marg_x.lines[0].get_xydata().T
tests/test_axisgrid.py:1590:        y2, _ = g.ax_marg_y.lines[0].get_xydata().T
tests/test_axisgrid.py:1599:        assert len(g.ax_marg_x.patches) == bins
tests/test_axisgrid.py:1600:        assert len(g.ax_marg_y.patches) == bins
tests/test_axisgrid.py:1601:        for x, y in zip(g.ax_marg_x.patches, g.ax_marg_y.patches):
tests/test_axisgrid.py:1609:        assert len(g.ax_marg_x.patches) == bins
tests/test_axisgrid.py:1610:        assert len(g.ax_marg_y.patches) == bins
tests/test_axisgrid.py:1617:        x, y = g.ax_joint.lines[0].get_xydata().T
tests/test_axisgrid.py:1621:        _, y1 = g.ax_marg_x.lines[0].get_xydata().T
tests/test_axisgrid.py:1622:        y2, _ = g.ax_marg_y.lines[0].get_xydata().T
tests/test_axisgrid.py:1629:        joint_bounds = g.ax_joint.bbox.bounds
tests/test_axisgrid.py:1630:        marg_x_bounds = g.ax_marg_x.bbox.bounds
tests/test_axisgrid.py:1631:        marg_y_bounds = g.ax_marg_y.bbox.bounds
tests/test_axisgrid.py:1653:        scatterplot(data=long_df, x=x, y=y, hue=hue, ax=g2.ax_joint)
tests/test_axisgrid.py:1654:        histplot(data=long_df, x=x, hue=hue, ax=g2.ax_marg_x)
tests/test_axisgrid.py:1655:        histplot(data=long_df, y=y, hue=hue, ax=g2.ax_marg_y)
tests/test_axisgrid.py:1657:        assert_plots_equal(g.ax_joint, g2.ax_joint)
tests/test_axisgrid.py:1658:        assert_plots_equal(g.ax_marg_x, g2.ax_marg_x, labels=False)
tests/test_axisgrid.py:1659:        assert_plots_equal(g.ax_marg_y, g2.ax_marg_y, labels=False)
tests/test_axisgrid.py:1666:        assert not g.ax_joint.lines and not g.ax_marg_x.lines and not g.ax_marg_y.lines
tests/test_axisgrid.py:1672:        assert not g.ax_joint.lines and not g.ax_marg_x.lines and not g.ax_marg_y.lines
tests/test_axisgrid.py:1675:        assert g.ax_joint.lines[0].get_color() == '.5'
tests/test_axisgrid.py:1676:        assert g.ax_joint.lines[0].get_linestyle() == '--'
tests/test_axisgrid.py:1677:        assert len(g.ax_joint.lines) == 2
tests/test_axisgrid.py:1678:        assert len(g.ax_marg_x.lines) == 1
tests/test_axisgrid.py:1679:        assert len(g.ax_marg_y.lines) == 1
tests/test_axisgrid.py:1680:        npt.assert_array_equal(g.ax_joint.lines[0].get_xydata(), vline)
tests/test_axisgrid.py:1681:        npt.assert_array_equal(g.ax_joint.lines[1].get_xydata(), hline)
tests/test_axisgrid.py:1682:        npt.assert_array_equal(g.ax_marg_x.lines[0].get_xydata(), vline)
tests/test_axisgrid.py:1683:        npt.assert_array_equal(g.ax_marg_y.lines[0].get_xydata(), hline)
tests/test_axisgrid.py:1687:        npt.assert_array_equal(g.ax_joint.lines[-1].get_xydata(), vline)
tests/test_axisgrid.py:1688:        assert g.ax_joint.lines[-1].get_color() == color
tests/test_axisgrid.py:1689:        assert g.ax_joint.lines[-1].get_linestyle() == linestyle
tests/test_axisgrid.py:1690:        assert len(g.ax_marg_x.lines) == len(g.ax_marg_y.lines)
tests/test_axisgrid.py:1693:        npt.assert_array_equal(g.ax_marg_x.lines[-1].get_xydata(), vline)
tests/test_axisgrid.py:1694:        assert len(g.ax_marg_x.lines) == len(g.ax_marg_y.lines) + 1
tests/test_axisgrid.py:1697:        npt.assert_array_equal(g.ax_marg_y.lines[-1].get_xydata(), hline)
tests/test_axisgrid.py:1698:        assert len(g.ax_marg_x.lines) == len(g.ax_marg_y.lines)
tests/test_axisgrid.py:1701:        npt.assert_array_equal(g.ax_joint.lines[-1].get_xydata(), hline)
tests/test_axisgrid.py:1702:        assert len(g.ax_marg_x.lines) == len(g.ax_marg_y.lines)
tests/test_axisgrid.py:1715:        assert len(g.ax_joint.collections) == 1
tests/test_axisgrid.py:1717:        x, y = g.ax_joint.collections[0].get_offsets().T
tests/test_axisgrid.py:1722:            [b.get_x() for b in g.ax_marg_x.patches],
tests/test_axisgrid.py:1727:            [b.get_y() for b in g.ax_marg_y.patches],
tests/test_axisgrid.py:1736:        scatterplot(data=long_df, x="x", y="y", hue="a", ax=g2.ax_joint)
tests/test_axisgrid.py:1737:        kdeplot(data=long_df, x="x", hue="a", ax=g2.ax_marg_x, fill=True)
tests/test_axisgrid.py:1738:        kdeplot(data=long_df, y="y", hue="a", ax=g2.ax_marg_y, fill=True)
tests/test_axisgrid.py:1740:        assert_plots_equal(g1.ax_joint, g2.ax_joint)
tests/test_axisgrid.py:1741:        assert_plots_equal(g1.ax_marg_x, g2.ax_marg_x, labels=False)
tests/test_axisgrid.py:1742:        assert_plots_equal(g1.ax_marg_y, g2.ax_marg_y, labels=False)
tests/test_axisgrid.py:1747:        assert len(g.ax_joint.collections) == 2
tests/test_axisgrid.py:1749:        x, y = g.ax_joint.collections[0].get_offsets().T
tests/test_axisgrid.py:1753:        assert g.ax_marg_x.patches
tests/test_axisgrid.py:1754:        assert g.ax_marg_y.patches
tests/test_axisgrid.py:1756:        assert g.ax_marg_x.lines
tests/test_axisgrid.py:1757:        assert g.ax_marg_y.lines
tests/test_axisgrid.py:1762:        assert g.ax_joint.collections
tests/test_axisgrid.py:1763:        assert g.ax_joint.lines
tests/test_axisgrid.py:1764:        assert not g.ax_marg_x.lines
tests/test_axisgrid.py:1765:        assert not g.ax_marg_y.lines
tests/test_axisgrid.py:1773:        histplot(data=long_df, x="x", y="y", ax=g2.ax_joint, bins=bins)
tests/test_axisgrid.py:1774:        histplot(data=long_df, x="x", ax=g2.ax_marg_x, bins=bins[0])
tests/test_axisgrid.py:1775:        histplot(data=long_df, y="y", ax=g2.ax_marg_y, bins=bins[1])
tests/test_axisgrid.py:1777:        assert_plots_equal(g1.ax_joint, g2.ax_joint)
tests/test_axisgrid.py:1778:        assert_plots_equal(g1.ax_marg_x, g2.ax_marg_x, labels=False)
tests/test_axisgrid.py:1779:        assert_plots_equal(g1.ax_marg_y, g2.ax_marg_y, labels=False)
tests/test_axisgrid.py:1784:        assert g.ax_joint.collections
tests/test_axisgrid.py:1785:        assert g.ax_marg_x.patches
tests/test_axisgrid.py:1786:        assert g.ax_marg_y.patches
tests/test_axisgrid.py:1793:        kdeplot(data=long_df, x="x", y="y", ax=g2.ax_joint)
tests/test_axisgrid.py:1794:        kdeplot(data=long_df, x="x", ax=g2.ax_marg_x)
tests/test_axisgrid.py:1795:        kdeplot(data=long_df, y="y", ax=g2.ax_marg_y)
tests/test_axisgrid.py:1797:        assert_plots_equal(g1.ax_joint, g2.ax_joint)
tests/test_axisgrid.py:1798:        assert_plots_equal(g1.ax_marg_x, g2.ax_marg_x, labels=False)
tests/test_axisgrid.py:1799:        assert_plots_equal(g1.ax_marg_y, g2.ax_marg_y, labels=False)
tests/test_axisgrid.py:1806:        kdeplot(data=long_df, x="x", y="y", hue="a", ax=g2.ax_joint)
tests/test_axisgrid.py:1807:        kdeplot(data=long_df, x="x", hue="a", ax=g2.ax_marg_x)
tests/test_axisgrid.py:1808:        kdeplot(data=long_df, y="y", hue="a", ax=g2.ax_marg_y)
tests/test_axisgrid.py:1810:        assert_plots_equal(g1.ax_joint, g2.ax_joint)
tests/test_axisgrid.py:1811:        assert_plots_equal(g1.ax_marg_x, g2.ax_marg_x, labels=False)
tests/test_axisgrid.py:1812:        assert_plots_equal(g1.ax_marg_y, g2.ax_marg_y, labels=False)
tests/test_axisgrid.py:1818:        scatter_color = g.ax_joint.collections[0].get_facecolor()
tests/test_axisgrid.py:1821:        hist_color = g.ax_marg_x.patches[0].get_facecolor()[:3]
tests/test_axisgrid.py:1831:        scatterplot(x="x", y="y", ax=g2.ax_joint, **kws)
tests/test_axisgrid.py:1832:        kdeplot(x="x", ax=g2.ax_marg_x, fill=True, **kws)
tests/test_axisgrid.py:1833:        kdeplot(y="y", ax=g2.ax_marg_y, fill=True, **kws)
tests/test_axisgrid.py:1835:        assert_plots_equal(g1.ax_joint, g2.ax_joint)
tests/test_axisgrid.py:1836:        assert_plots_equal(g1.ax_marg_x, g2.ax_marg_x, labels=False)
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "nl -ba seaborn/axisgrid.py | sed -n '620,790p'
nl -ba tests/test_palettes.py | sed -n '300,390p'
nl -ba tests/test_utils.py | sed -n '520,565p'
nl -ba tests/test_axisgrid.py | sed -n '35,200p'
grep -RIn \"get_colormap\" seaborn tests | head -100
grep -n \"get_color_cycle\" seaborn/utils.py seaborn/palettes.py"
```

退出码：`0`

输出：
```
   620	
   621	        See Also
   622	        --------
   623	        PairGrid : Subplot grid for plotting pairwise relationships
   624	        relplot : Combine a relational plot and a :class:`FacetGrid`
   625	        displot : Combine a distribution plot and a :class:`FacetGrid`
   626	        catplot : Combine a categorical plot and a :class:`FacetGrid`
   627	        lmplot : Combine a regression plot and a :class:`FacetGrid`
   628	
   629	        Examples
   630	        --------
   631	
   632	        .. note::
   633	
   634	            These examples use seaborn functions to demonstrate some of the
   635	            advanced features of the class, but in most cases you will want
   636	            to use figue-level functions (e.g. :func:`displot`, :func:`relplot`)
   637	            to make the plots shown here.
   638	
   639	        .. include:: ../docstrings/FacetGrid.rst
   640	
   641	        """).format(**_facet_docs)
   642	
   643	    def facet_data(self):
   644	        """Generator for name indices and data subsets for each facet.
   645	
   646	        Yields
   647	        ------
   648	        (i, j, k), data_ijk : tuple of ints, DataFrame
   649	            The ints provide an index into the {row, col, hue}_names attribute,
   650	            and the dataframe contains a subset of the full data corresponding
   651	            to each facet. The generator yields subsets that correspond with
   652	            the self.axes.flat iterator, or self.axes[i, j] when `col_wrap`
   653	            is None.
   654	
   655	        """
   656	        data = self.data
   657	
   658	        # Construct masks for the row variable
   659	        if self.row_names:
   660	            row_masks = [data[self._row_var] == n for n in self.row_names]
   661	        else:
   662	            row_masks = [np.repeat(True, len(self.data))]
   663	
   664	        # Construct masks for the column variable
   665	        if self.col_names:
   666	            col_masks = [data[self._col_var] == n for n in self.col_names]
   667	        else:
   668	            col_masks = [np.repeat(True, len(self.data))]
   669	
   670	        # Construct masks for the hue variable
   671	        if self.hue_names:
   672	            hue_masks = [data[self._hue_var] == n for n in self.hue_names]
   673	        else:
   674	            hue_masks = [np.repeat(True, len(self.data))]
   675	
   676	        # Here is the main generator loop
   677	        for (i, row), (j, col), (k, hue) in product(enumerate(row_masks),
   678	                                                    enumerate(col_masks),
   679	                                                    enumerate(hue_masks)):
   680	            data_ijk = data[row & col & hue & self._not_na]
   681	            yield (i, j, k), data_ijk
   682	
   683	    def map(self, func, *args, **kwargs):
   684	        """Apply a plotting function to each facet's subset of the data.
   685	
   686	        Parameters
   687	        ----------
   688	        func : callable
   689	            A plotting function that takes data and keyword arguments. It
   690	            must plot to the currently active matplotlib Axes and take a
   691	            `color` keyword argument. If faceting on the `hue` dimension,
   692	            it must also take a `label` keyword argument.
   693	        args : strings
   694	            Column names in self.data that identify variables with data to
   695	            plot. The data for each variable is passed to `func` in the
   696	            order the variables are specified in the call.
   697	        kwargs : keyword arguments
   698	            All keyword arguments are passed to the plotting function.
   699	
   700	        Returns
   701	        -------
   702	        self : object
   703	            Returns self.
   704	
   705	        """
   706	        # If color was a keyword argument, grab it here
   707	        kw_color = kwargs.pop("color", None)
   708	
   709	        # How we use the function depends on where it comes from
   710	        func_module = str(getattr(func, "__module__", ""))
   711	
   712	        # Check for categorical plots without order information
   713	        if func_module == "seaborn.categorical":
   714	            if "order" not in kwargs:
   715	                warning = ("Using the {} function without specifying "
   716	                           "`order` is likely to produce an incorrect "
   717	                           "plot.".format(func.__name__))
   718	                warnings.warn(warning)
   719	            if len(args) == 3 and "hue_order" not in kwargs:
   720	                warning = ("Using the {} function without specifying "
   721	                           "`hue_order` is likely to produce an incorrect "
   722	                           "plot.".format(func.__name__))
   723	                warnings.warn(warning)
   724	
   725	        # Iterate over the data subsets
   726	        for (row_i, col_j, hue_k), data_ijk in self.facet_data():
   727	
   728	            # If this subset is null, move on
   729	            if not data_ijk.values.size:
   730	                continue
   731	
   732	            # Get the current axis
   733	            modify_state = not func_module.startswith("seaborn")
   734	            ax = self.facet_axis(row_i, col_j, modify_state)
   735	
   736	            # Decide what color to plot with
   737	            kwargs["color"] = self._facet_color(hue_k, kw_color)
   738	
   739	            # Insert the other hue aesthetics if appropriate
   740	            for kw, val_list in self.hue_kws.items():
   741	                kwargs[kw] = val_list[hue_k]
   742	
   743	            # Insert a label in the keyword arguments for the legend
   744	            if self._hue_var is not None:
   745	                kwargs["label"] = utils.to_utf8(self.hue_names[hue_k])
   746	
   747	            # Get the actual data we are going to plot with
   748	            plot_data = data_ijk[list(args)]
   749	            if self._dropna:
   750	                plot_data = plot_data.dropna()
   751	            plot_args = [v for k, v in plot_data.items()]
   752	
   753	            # Some matplotlib functions don't handle pandas objects correctly
   754	            if func_module.startswith("matplotlib"):
   755	                plot_args = [v.values for v in plot_args]
   756	
   757	            # Draw the plot
   758	            self._facet_plot(func, ax, plot_args, kwargs)
   759	
   760	        # Finalize the annotations and layout
   761	        self._finalize_grid(args[:2])
   762	
   763	        return self
   764	
   765	    def map_dataframe(self, func, *args, **kwargs):
   766	        """Like ``.map`` but passes args as strings and inserts data in kwargs.
   767	
   768	        This method is suitable for plotting with functions that accept a
   769	        long-form DataFrame as a `data` keyword argument and access the
   770	        data in that DataFrame using string variable names.
   771	
   772	        Parameters
   773	        ----------
   774	        func : callable
   775	            A plotting function that takes data and keyword arguments. Unlike
   776	            the `map` method, a function used here must "understand" Pandas
   777	            objects. It also must plot to the currently active matplotlib Axes
   778	            and take a `color` keyword argument. If faceting on the `hue`
   779	            dimension, it must also take a `label` keyword argument.
   780	        args : strings
   781	            Column names in self.data that identify variables with data to
   782	            plot. The data for each variable is passed to `func` in the
   783	            order the variables are specified in the call.
   784	        kwargs : keyword arguments
   785	            All keyword arguments are passed to the plotting function.
   786	
   787	        Returns
   788	        -------
   789	        self : object
   790	            Returns self.
   300	        assert np.mean(pal[int(n / 2)]) > np.mean(pal_dark[int(n / 2)])
   301	
   302	        pal_cmap = palettes.diverging_palette(*args, as_cmap=True)
   303	        assert isinstance(pal_cmap, mpl.colors.LinearSegmentedColormap)
   304	
   305	    def test_blend_palette(self):
   306	
   307	        colors = ["red", "yellow", "white"]
   308	        pal_cmap = palettes.blend_palette(colors, as_cmap=True)
   309	        assert isinstance(pal_cmap, mpl.colors.LinearSegmentedColormap)
   310	
   311	        colors = ["red", "blue"]
   312	        pal = palettes.blend_palette(colors)
   313	        pal_str = "blend:" + ",".join(colors)
   314	        pal_from_str = palettes.color_palette(pal_str)
   315	        assert pal == pal_from_str
   316	
   317	    def test_cubehelix_against_matplotlib(self):
   318	
   319	        x = np.linspace(0, 1, 8)
   320	        mpl_pal = mpl.cm.cubehelix(x)[:, :3].tolist()
   321	
   322	        sns_pal = palettes.cubehelix_palette(8, start=0.5, rot=-1.5, hue=1,
   323	                                             dark=0, light=1, reverse=True)
   324	
   325	        assert sns_pal == mpl_pal
   326	
   327	    def test_cubehelix_n_colors(self):
   328	
   329	        for n in [3, 5, 8]:
   330	            pal = palettes.cubehelix_palette(n)
   331	            assert len(pal) == n
   332	
   333	    def test_cubehelix_reverse(self):
   334	
   335	        pal_forward = palettes.cubehelix_palette()
   336	        pal_reverse = palettes.cubehelix_palette(reverse=True)
   337	        assert pal_forward == pal_reverse[::-1]
   338	
   339	    def test_cubehelix_cmap(self):
   340	
   341	        cmap = palettes.cubehelix_palette(as_cmap=True)
   342	        assert isinstance(cmap, mpl.colors.ListedColormap)
   343	        pal = palettes.cubehelix_palette()
   344	        x = np.linspace(0, 1, 6)
   345	        npt.assert_array_equal(cmap(x)[:, :3], pal)
   346	
   347	        cmap_rev = palettes.cubehelix_palette(as_cmap=True, reverse=True)
   348	        x = np.linspace(0, 1, 6)
   349	        pal_forward = cmap(x).tolist()
   350	        pal_reverse = cmap_rev(x[::-1]).tolist()
   351	        assert pal_forward == pal_reverse
   352	
   353	    def test_cubehelix_code(self):
   354	
   355	        color_palette = palettes.color_palette
   356	        cubehelix_palette = palettes.cubehelix_palette
   357	
   358	        pal1 = color_palette("ch:", 8)
   359	        pal2 = color_palette(cubehelix_palette(8))
   360	        assert pal1 == pal2
   361	
   362	        pal1 = color_palette("ch:.5, -.25,hue = .5,light=.75", 8)
   363	        pal2 = color_palette(cubehelix_palette(8, .5, -.25, hue=.5, light=.75))
   364	        assert pal1 == pal2
   365	
   366	        pal1 = color_palette("ch:h=1,r=.5", 9)
   367	        pal2 = color_palette(cubehelix_palette(9, hue=1, rot=.5))
   368	        assert pal1 == pal2
   369	
   370	        pal1 = color_palette("ch:_r", 6)
   371	        pal2 = color_palette(cubehelix_palette(6, reverse=True))
   372	        assert pal1 == pal2
   373	
   374	        pal1 = color_palette("ch:_r", as_cmap=True)
   375	        pal2 = cubehelix_palette(6, reverse=True, as_cmap=True)
   376	        assert pal1(.5) == pal2(.5)
   377	
   378	    def test_xkcd_palette(self):
   379	
   380	        names = list(xkcd_rgb.keys())[10:15]
   381	        colors = palettes.xkcd_palette(names)
   382	        for name, color in zip(names, colors):
   383	            as_hex = mpl.colors.rgb2hex(color)
   384	            assert as_hex == xkcd_rgb[name]
   385	
   386	    def test_crayon_palette(self):
   387	
   388	        names = list(crayons.keys())[10:15]
   389	        colors = palettes.crayon_palette(names)
   390	        for name, color in zip(names, colors):
   520	    assert out1 == 1
   521	
   522	    out2 = utils.relative_luminance("#000000")
   523	    assert out2 == 0
   524	
   525	    out3 = utils.relative_luminance((.25, .5, .75))
   526	    assert out3 == pytest.approx(0.201624536)
   527	
   528	    rgbs = mpl.cm.RdBu(np.linspace(0, 1, 10))
   529	    lums1 = [utils.relative_luminance(rgb) for rgb in rgbs]
   530	    lums2 = utils.relative_luminance(rgbs)
   531	
   532	    for lum1, lum2 in zip(lums1, lums2):
   533	        assert lum1 == pytest.approx(lum2)
   534	
   535	
   536	@pytest.mark.parametrize(
   537	    "cycler,result",
   538	    [
   539	        (cycler(color=["y"]), ["y"]),
   540	        (cycler(color=["k"]), ["k"]),
   541	        (cycler(color=["k", "y"]), ["k", "y"]),
   542	        (cycler(color=["y", "k"]), ["y", "k"]),
   543	        (cycler(color=["b", "r"]), ["b", "r"]),
   544	        (cycler(color=["r", "b"]), ["r", "b"]),
   545	        (cycler(lw=[1, 2]), [".15"]),  # no color in cycle
   546	    ],
   547	)
   548	def test_get_color_cycle(cycler, result):
   549	    with mpl.rc_context(rc={"axes.prop_cycle": cycler}):
   550	        assert get_color_cycle() == result
   551	
   552	
   553	def test_remove_na():
   554	
   555	    a_array = np.array([1, 2, np.nan, 3])
   556	    a_array_rm = remove_na(a_array)
   557	    assert_array_equal(a_array_rm, np.array([1, 2, 3]))
   558	
   559	    a_series = pd.Series([1, 2, np.nan, 3])
   560	    a_series_rm = remove_na(a_series)
   561	    assert_series_equal(a_series_rm, pd.Series([1., 2, 3], [0, 1, 3]))
   562	
   563	
   564	def test_assign_default_kwargs():
   565	
    35	                           d=np.tile(list("abcdefghijkl"), 5)))
    36	
    37	    def test_self_data(self):
    38	
    39	        g = ag.FacetGrid(self.df)
    40	        assert g.data is self.df
    41	
    42	    def test_self_figure(self):
    43	
    44	        g = ag.FacetGrid(self.df)
    45	        assert isinstance(g.figure, plt.Figure)
    46	        assert g.figure is g._figure
    47	
    48	    def test_self_axes(self):
    49	
    50	        g = ag.FacetGrid(self.df, row="a", col="b", hue="c")
    51	        for ax in g.axes.flat:
    52	            assert isinstance(ax, plt.Axes)
    53	
    54	    def test_axes_array_size(self):
    55	
    56	        g = ag.FacetGrid(self.df)
    57	        assert g.axes.shape == (1, 1)
    58	
    59	        g = ag.FacetGrid(self.df, row="a")
    60	        assert g.axes.shape == (3, 1)
    61	
    62	        g = ag.FacetGrid(self.df, col="b")
    63	        assert g.axes.shape == (1, 2)
    64	
    65	        g = ag.FacetGrid(self.df, hue="c")
    66	        assert g.axes.shape == (1, 1)
    67	
    68	        g = ag.FacetGrid(self.df, row="a", col="b", hue="c")
    69	        assert g.axes.shape == (3, 2)
    70	        for ax in g.axes.flat:
    71	            assert isinstance(ax, plt.Axes)
    72	
    73	    def test_single_axes(self):
    74	
    75	        g = ag.FacetGrid(self.df)
    76	        assert isinstance(g.ax, plt.Axes)
    77	
    78	        g = ag.FacetGrid(self.df, row="a")
    79	        with pytest.raises(AttributeError):
    80	            g.ax
    81	
    82	        g = ag.FacetGrid(self.df, col="a")
    83	        with pytest.raises(AttributeError):
    84	            g.ax
    85	
    86	        g = ag.FacetGrid(self.df, col="a", row="b")
    87	        with pytest.raises(AttributeError):
    88	            g.ax
    89	
    90	    def test_col_wrap(self):
    91	
    92	        n = len(self.df.d.unique())
    93	
    94	        g = ag.FacetGrid(self.df, col="d")
    95	        assert g.axes.shape == (1, n)
    96	        assert g.facet_axis(0, 8) is g.axes[0, 8]
    97	
    98	        g_wrap = ag.FacetGrid(self.df, col="d", col_wrap=4)
    99	        assert g_wrap.axes.shape == (n,)
   100	        assert g_wrap.facet_axis(0, 8) is g_wrap.axes[8]
   101	        assert g_wrap._ncol == 4
   102	        assert g_wrap._nrow == (n / 4)
   103	
   104	        with pytest.raises(ValueError):
   105	            g = ag.FacetGrid(self.df, row="b", col="d", col_wrap=4)
   106	
   107	        df = self.df.copy()
   108	        df.loc[df.d == "j"] = np.nan
   109	        g_missing = ag.FacetGrid(df, col="d")
   110	        assert g_missing.axes.shape == (1, n - 1)
   111	
   112	        g_missing_wrap = ag.FacetGrid(df, col="d", col_wrap=4)
   113	        assert g_missing_wrap.axes.shape == (n - 1,)
   114	
   115	        g = ag.FacetGrid(self.df, col="d", col_wrap=1)
   116	        assert len(list(g.facet_data())) == n
   117	
   118	    def test_normal_axes(self):
   119	
   120	        null = np.empty(0, object).flat
   121	
   122	        g = ag.FacetGrid(self.df)
   123	        npt.assert_array_equal(g._bottom_axes, g.axes.flat)
   124	        npt.assert_array_equal(g._not_bottom_axes, null)
   125	        npt.assert_array_equal(g._left_axes, g.axes.flat)
   126	        npt.assert_array_equal(g._not_left_axes, null)
   127	        npt.assert_array_equal(g._inner_axes, null)
   128	
   129	        g = ag.FacetGrid(self.df, col="c")
   130	        npt.assert_array_equal(g._bottom_axes, g.axes.flat)
   131	        npt.assert_array_equal(g._not_bottom_axes, null)
   132	        npt.assert_array_equal(g._left_axes, g.axes[:, 0].flat)
   133	        npt.assert_array_equal(g._not_left_axes, g.axes[:, 1:].flat)
   134	        npt.assert_array_equal(g._inner_axes, null)
   135	
   136	        g = ag.FacetGrid(self.df, row="c")
   137	        npt.assert_array_equal(g._bottom_axes, g.axes[-1, :].flat)
   138	        npt.assert_array_equal(g._not_bottom_axes, g.axes[:-1, :].flat)
   139	        npt.assert_array_equal(g._left_axes, g.axes.flat)
   140	        npt.assert_array_equal(g._not_left_axes, null)
   141	        npt.assert_array_equal(g._inner_axes, null)
   142	
   143	        g = ag.FacetGrid(self.df, col="a", row="c")
   144	        npt.assert_array_equal(g._bottom_axes, g.axes[-1, :].flat)
   145	        npt.assert_array_equal(g._not_bottom_axes, g.axes[:-1, :].flat)
   146	        npt.assert_array_equal(g._left_axes, g.axes[:, 0].flat)
   147	        npt.assert_array_equal(g._not_left_axes, g.axes[:, 1:].flat)
   148	        npt.assert_array_equal(g._inner_axes, g.axes[:-1, 1:].flat)
   149	
   150	    def test_wrapped_axes(self):
   151	
   152	        null = np.empty(0, object).flat
   153	
   154	        g = ag.FacetGrid(self.df, col="a", col_wrap=2)
   155	        npt.assert_array_equal(g._bottom_axes,
   156	                               g.axes[np.array([1, 2])].flat)
   157	        npt.assert_array_equal(g._not_bottom_axes, g.axes[:1].flat)
   158	        npt.assert_array_equal(g._left_axes, g.axes[np.array([0, 2])].flat)
   159	        npt.assert_array_equal(g._not_left_axes, g.axes[np.array([1])].flat)
   160	        npt.assert_array_equal(g._inner_axes, null)
   161	
   162	    def test_axes_dict(self):
   163	
   164	        g = ag.FacetGrid(self.df)
   165	        assert isinstance(g.axes_dict, dict)
   166	        assert not g.axes_dict
   167	
   168	        g = ag.FacetGrid(self.df, row="c")
   169	        assert list(g.axes_dict.keys()) == g.row_names
   170	        for (name, ax) in zip(g.row_names, g.axes.flat):
   171	            assert g.axes_dict[name] is ax
   172	
   173	        g = ag.FacetGrid(self.df, col="c")
   174	        assert list(g.axes_dict.keys()) == g.col_names
   175	        for (name, ax) in zip(g.col_names, g.axes.flat):
   176	            assert g.axes_dict[name] is ax
   177	
   178	        g = ag.FacetGrid(self.df, col="a", col_wrap=2)
   179	        assert list(g.axes_dict.keys()) == g.col_names
   180	        for (name, ax) in zip(g.col_names, g.axes.flat):
   181	            assert g.axes_dict[name] is ax
   182	
   183	        g = ag.FacetGrid(self.df, row="a", col="c")
   184	        for (row_var, col_var), ax in g.axes_dict.items():
   185	            i = g.row_names.index(row_var)
   186	            j = g.col_names.index(col_var)
   187	            assert g.axes[i, j] is ax
   188	
   189	    def test_figure_size(self):
   190	
   191	        g = ag.FacetGrid(self.df, row="a", col="b")
   192	        npt.assert_array_equal(g.figure.get_size_inches(), (6, 9))
   193	
   194	        g = ag.FacetGrid(self.df, row="a", col="b", height=6)
   195	        npt.assert_array_equal(g.figure.get_size_inches(), (12, 18))
   196	
   197	        g = ag.FacetGrid(self.df, col="c", height=4, aspect=.5)
   198	        npt.assert_array_equal(g.figure.get_size_inches(), (6, 4))
   199	
   200	    def test_figure_size_with_legend(self):
seaborn/matrix.py:217:            self.cmap = get_colormap(cmap)
seaborn/palettes.py:406:        cmap = get_colormap(name)
tests/test_relational.py:25:from seaborn._compat import get_colormap, get_legend_handles
tests/test_relational.py:1661:        cmap = get_colormap("Blues")
tests/test_base.py:12:from seaborn._compat import get_colormap, get_converter
tests/test_base.py:238:        assert_array_equal(m.cmap(vals), get_colormap(palette)(vals))
tests/test_base.py:241:        palette = get_colormap("Greens")
tests/_core/test_properties.py:24:from seaborn._compat import get_colormap
tests/_core/test_properties.py:175:        cmap = get_colormap("viridis")
tests/_core/test_properties.py:193:            Color().get_mapping(Nominal(get_colormap("viridis")), cat_vector)
tests/_core/test_properties.py:232:            (get_colormap("inferno"), "num", Continuous),  # Based on callable
tests/test_categorical.py:22:from seaborn._compat import get_colormap, get_legend_handles
tests/test_categorical.py:242:        cmap = get_colormap("Blues")
tests/test_matrix.py:29:from seaborn._compat import get_colormap
tests/test_matrix.py:247:        cmap = copy.copy(get_colormap("BrBG"))
tests/test_matrix.py:262:        cmap = copy.copy(get_colormap("BrBG"))
tests/test_matrix.py:273:        cmap = copy.copy(get_colormap("BrBG"))
tests/test_palettes.py:10:from seaborn._compat import get_colormap
tests/test_palettes.py:99:        cmap1 = get_colormap("Reds")
seaborn/palettes.py:175:        palette = get_color_cycle()
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc 'grep -nE "''^def |''^    @property|''^    def " seaborn/palettes.py | head -100
grep -nE "''^def get_color_cycle|''^def " seaborn/utils.py | head -120
grep -nE "''^def get_colormap|''^def " seaborn/_compat.py
grep -nE "''^    @property|''^    def axes|''^    def ax" seaborn/axisgrid.py | head -100
sed -n '"'360,430p' seaborn/palettes.py
sed -n '1,45p' tests/test_palettes.py
sed -n '1,45p' tests/test_utils.py"
```

退出码：`0`

输出：
```
63:    def __enter__(self):
70:    def __exit__(self, *args):
75:    def as_hex(self):
80:    def _repr_html_(self):
94:def _patch_colormap_display():
96:    def _repr_png_(self):
108:    def _repr_html_(self):
122:def color_palette(palette=None, n_colors=None, desat=None, as_cmap=False):
258:def hls_palette(n_colors=6, h=.01, l=.6, s=.65, as_cmap=False):  # noqa
312:def husl_palette(n_colors=6, h=.01, s=.9, l=.65, as_cmap=False):  # noqa
366:def mpl_palette(name, n_colors=6, as_cmap=False):
433:def dark_palette(color, n_colors=6, reverse=False, as_cmap=False, input="rgb"):
484:def light_palette(color, n_colors=6, reverse=False, as_cmap=False, input="rgb"):
532:def diverging_palette(h_neg, h_pos, s=75, l=50, sep=1, n=6,  # noqa
581:def blend_palette(colors, n_colors=6, as_cmap=False, input="rgb"):
612:def xkcd_palette(colors):
638:def crayon_palette(colors):
665:def cubehelix_palette(n_colors=6, start=0, rot=.4, gamma=1.0, hue=0.8,
799:def set_color_codes(palette="deep"):
28:def ci_to_errsize(cis, heights):
147:def desaturate(color, prop):
186:def saturate(color):
203:def set_hls_values(color, h=None, l=None, s=None):  # noqa
230:def axlabel(xlabel, ylabel, **kwargs):
277:def despine(fig=None, ax=None, top=True, right=True, left=False,
379:def move_legend(obj, loc, **kwargs):
487:def ci(a, which=95, axis=None):
493:def get_dataset_names():
506:def get_data_home(data_home=None):
524:def load_dataset(name, cache=True, data_home=None, **kws):
632:def axis_ticklabels_overlap(labels):
656:def axes_ticklabels_overlap(ax):
673:def locator_to_legend_entries(locator, limits, dtype):
699:def relative_luminance(color):
721:def to_utf8(obj):
750:def _check_argument(param, options, value, prefix=False):
783:def adjust_legend_subtitles(legend):
803:def _deprecate_ci(errorbar, ci):
836:def _disable_autolayout():
854:def _version_predates(lib: ModuleType, version: str) -> bool:
859:def _scatter_legend_artist(**kws):
883:def _get_patch_legend_artist(fill):
11:def norm_from_scale(scale, norm):
67:def register_colormap(name, cmap):
76:def set_layout_engine(
94:def get_layout_engine(fig: Figure) -> mpl.layout_engine.LayoutEngine | None:
103:def share_axis(ax0, ax1, which):
112:def get_legend_handles(legend):
120:def groupby_apply_include_groups(val):
126:def get_converter(axis):
47:    @property
56:    @property
279:    @property
1071:    @property
1072:    def axes(self):
1100:    @property
1130:    @property
1159:    @property
    if as_cmap:
        return mpl.colors.ListedColormap(palette, "hsl")
    else:
        return _ColorPalette(palette)


def mpl_palette(name, n_colors=6, as_cmap=False):
    """
    Return a palette or colormap from the matplotlib registry.

    For continuous palettes, evenly-spaced discrete samples are chosen while
    excluding the minimum and maximum value in the colormap to provide better
    contrast at the extremes.

    For qualitative palettes (e.g. those from colorbrewer), exact values are
    indexed (rather than interpolated), but fewer than `n_colors` can be returned
    if the palette does not define that many.

    Parameters
    ----------
    name : string
        Name of the palette. This should be a named matplotlib colormap.
    n_colors : int
        Number of discrete colors in the palette.

    Returns
    -------
    list of RGB tuples or :class:`matplotlib.colors.ListedColormap`

    Examples
    --------
    .. include:: ../docstrings/mpl_palette.rst

    """
    if name.endswith("_d"):
        sub_name = name[:-2]
        if sub_name.endswith("_r"):
            reverse = True
            sub_name = sub_name[:-2]
        else:
            reverse = False
        pal = color_palette(sub_name, 2) + ["#333333"]
        if reverse:
            pal = pal[::-1]
        cmap = blend_palette(pal, n_colors, as_cmap=True)
    else:
        cmap = get_colormap(name)

    if name in MPL_QUAL_PALS:
        bins = np.linspace(0, 1, MPL_QUAL_PALS[name])[:n_colors]
    else:
        bins = np.linspace(0, 1, int(n_colors) + 2)[1:-1]
    palette = list(map(tuple, cmap(bins)[:, :3]))

    if as_cmap:
        return cmap
    else:
        return _ColorPalette(palette)













import colorsys
import numpy as np
import matplotlib as mpl

import pytest
import numpy.testing as npt

from seaborn import palettes, utils, rcmod
from seaborn.external import husl
from seaborn._compat import get_colormap
from seaborn.colors import xkcd_rgb, crayons


class TestColorPalettes:

    def test_current_palette(self):

        pal = palettes.color_palette(["red", "blue", "green"])
        rcmod.set_palette(pal)
        assert pal == utils.get_color_cycle()
        rcmod.set()

    def test_palette_context(self):

        default_pal = palettes.color_palette()
        context_pal = palettes.color_palette("muted")

        with palettes.color_palette(context_pal):
            assert utils.get_color_cycle() == context_pal

        assert utils.get_color_cycle() == default_pal

    def test_big_palette_context(self):

        original_pal = palettes.color_palette("deep", n_colors=8)
        context_pal = palettes.color_palette("husl", 10)

        rcmod.set_palette(original_pal)
        with palettes.color_palette(context_pal, 10):
            assert utils.get_color_cycle() == context_pal

        assert utils.get_color_cycle() == original_pal

        # Reset default
        rcmod.set()
"""Tests for seaborn utility functions."""
import re
import tempfile
from types import ModuleType
from urllib.request import urlopen
from http.client import HTTPException

import numpy as np
import pandas as pd
import matplotlib as mpl
import matplotlib.pyplot as plt
from cycler import cycler

import pytest
from numpy.testing import (
    assert_array_equal,
)
from pandas.testing import (
    assert_series_equal,
    assert_frame_equal,
)

from seaborn import utils, rcmod, scatterplot
from seaborn.utils import (
    get_dataset_names,
    get_color_cycle,
    remove_na,
    load_dataset,
    _assign_default_kwargs,
    _check_argument,
    _draw_figure,
    _deprecate_ci,
    _version_predates, DATASET_NAMES_URL,
)
from seaborn._compat import get_legend_handles


a_norm = np.random.randn(100)


def _network(t=None, url="https://github.com"):
    """
    Decorator that will skip a test if `url` is unreachable.

    Parameters
```

## 原始行 25 · command_execution

命令：
```
/bin/bash -lc "nl -ba seaborn/axisgrid.py | sed -n '250,330p'
nl -ba seaborn/axisgrid.py | sed -n '1040,1185p'
nl -ba seaborn/palettes.py | sed -n '1,30p;380,435p;760,825p'
nl -ba seaborn/utils.py | sed -n '120,165p;700,750p'
python - <<'PY'
try:
 import seaborn
 print('import ok', seaborn.__file__)
except Exception as e:
 import traceback; traceback.print_exc()
PY"
```

退出码：`0`

输出：
```
   250	        """Get a list of colors for the hue variable."""
   251	        if hue is None:
   252	            palette = color_palette(n_colors=1)
   253	
   254	        else:
   255	            hue_names = categorical_order(data[hue], hue_order)
   256	            n_colors = len(hue_names)
   257	
   258	            # By default use either the current color palette or HUSL
   259	            if palette is None:
   260	                current_palette = utils.get_color_cycle()
   261	                if n_colors > len(current_palette):
   262	                    colors = color_palette("husl", n_colors)
   263	                else:
   264	                    colors = color_palette(n_colors=n_colors)
   265	
   266	            # Allow for palette to map from hue variable names
   267	            elif isinstance(palette, dict):
   268	                color_names = [palette[h] for h in hue_names]
   269	                colors = color_palette(color_names, n_colors)
   270	
   271	            # Otherwise act as if we just got a list of colors
   272	            else:
   273	                colors = color_palette(palette, n_colors)
   274	
   275	            palette = color_palette(colors, n_colors)
   276	
   277	        return palette
   278	
   279	    @property
   280	    def legend(self):
   281	        """The :class:`matplotlib.legend.Legend` object, if present."""
   282	        try:
   283	            return self._legend
   284	        except AttributeError:
   285	            return None
   286	
   287	    def tick_params(self, axis='both', **kwargs):
   288	        """Modify the ticks, tick labels, and gridlines.
   289	
   290	        Parameters
   291	        ----------
   292	        axis : {'x', 'y', 'both'}
   293	            The axis on which to apply the formatting.
   294	        kwargs : keyword arguments
   295	            Additional keyword arguments to pass to
   296	            :meth:`matplotlib.axes.Axes.tick_params`.
   297	
   298	        Returns
   299	        -------
   300	        self : Grid instance
   301	            Returns self for easy chaining.
   302	
   303	        """
   304	        for ax in self.figure.axes:
   305	            ax.tick_params(axis=axis, **kwargs)
   306	        return self
   307	
   308	
   309	_facet_docs = dict(
   310	
   311	    data=dedent("""\
   312	    data : DataFrame
   313	        Tidy ("long-form") dataframe where each column is a variable and each
   314	        row is an observation.\
   315	    """),
   316	    rowcol=dedent("""\
   317	    row, col : vectors or keys in ``data``
   318	        Variables that define subsets to plot on different facets.\
   319	    """),
   320	    rowcol_order=dedent("""\
   321	    {row,col}_order : vector of strings
   322	        Specify the order in which levels of the ``row`` and/or ``col`` variables
   323	        appear in the grid of subplots.\
   324	    """),
   325	    col_wrap=dedent("""\
   326	    col_wrap : int
   327	        "Wrap" the column variable at this width, so that the column facets
   328	        span multiple rows. Incompatible with a ``row`` facet.\
   329	    """),
   330	    share_xy=dedent("""\
  1040	        x, y : numeric
  1041	            Value(s) to draw the line(s) at.
  1042	        color : :mod:`matplotlib color <matplotlib.colors>`
  1043	            Specifies the color of the reference line(s). Pass ``color=None`` to
  1044	            use ``hue`` mapping.
  1045	        linestyle : str
  1046	            Specifies the style of the reference line(s).
  1047	        line_kws : key, value mappings
  1048	            Other keyword arguments are passed to :meth:`matplotlib.axes.Axes.axvline`
  1049	            when ``x`` is not None and :meth:`matplotlib.axes.Axes.axhline` when ``y``
  1050	            is not None.
  1051	
  1052	        Returns
  1053	        -------
  1054	        :class:`FacetGrid` instance
  1055	            Returns ``self`` for easy method chaining.
  1056	
  1057	        """
  1058	        line_kws['color'] = color
  1059	        line_kws['linestyle'] = linestyle
  1060	
  1061	        if x is not None:
  1062	            self.map(plt.axvline, x=x, **line_kws)
  1063	
  1064	        if y is not None:
  1065	            self.map(plt.axhline, y=y, **line_kws)
  1066	
  1067	        return self
  1068	
  1069	    # ------ Properties that are part of the public API and documented by Sphinx
  1070	
  1071	    @property
  1072	    def axes(self):
  1073	        """An array of the :class:`matplotlib.axes.Axes` objects in the grid."""
  1074	        return self._axes
  1075	
  1076	
  1077	
  1078	
  1079	
  1080	
  1081	
  1082	
  1083	
  1084	
  1085	
  1086	
  1087	
  1088	
  1089	
  1090	
  1091	
  1092	
  1093	
  1094	
  1095	
  1096	
  1097	
  1098	    # ------ Private properties, that require some computation to get
  1099	
  1100	    @property
  1101	    def _inner_axes(self):
  1102	        """Return a flat array of the inner axes."""
  1103	        if self._col_wrap is None:
  1104	            return self.axes[:-1, 1:].flat
  1105	        else:
  1106	            axes = []
  1107	            n_empty = self._nrow * self._ncol - self._n_facets
  1108	            for i, ax in enumerate(self.axes):
  1109	                append = (
  1110	                    i % self._ncol
  1111	                    and i < (self._ncol * (self._nrow - 1))
  1112	                    and i < (self._ncol * (self._nrow - 1) - n_empty)
  1113	                )
  1114	                if append:
  1115	                    axes.append(ax)
  1116	            return np.array(axes, object).flat
  1117	
  1118	
  1119	
  1120	
  1121	
  1122	
  1123	
  1124	
  1125	
  1126	
  1127	
  1128	
  1129	
  1130	    @property
  1131	    def _not_left_axes(self):
  1132	        """Return a flat array of axes that aren't on the left column."""
  1133	        if self._col_wrap is None:
  1134	            return self.axes[:, 1:].flat
  1135	        else:
  1136	            axes = []
  1137	            for i, ax in enumerate(self.axes):
  1138	                if i % self._ncol:
  1139	                    axes.append(ax)
  1140	            return np.array(axes, object).flat
  1141	
  1142	
  1143	
  1144	
  1145	
  1146	
  1147	
  1148	
  1149	
  1150	
  1151	
  1152	
  1153	
  1154	
  1155	
  1156	
  1157	
  1158	
  1159	    @property
  1160	    def _not_bottom_axes(self):
  1161	        """Return a flat array of axes that aren't on the bottom row."""
  1162	        if self._col_wrap is None:
  1163	            return self.axes[:-1, :].flat
  1164	        else:
  1165	            axes = []
  1166	            n_empty = self._nrow * self._ncol - self._n_facets
  1167	            for i, ax in enumerate(self.axes):
  1168	                append = (
  1169	                    i < (self._ncol * (self._nrow - 1))
  1170	                    and i < (self._ncol * (self._nrow - 1) - n_empty)
  1171	                )
  1172	                if append:
  1173	                    axes.append(ax)
  1174	            return np.array(axes, object).flat
  1175	
  1176	
  1177	class PairGrid(Grid):
  1178	    """Subplot grid for plotting pairwise relationships in a dataset.
  1179	
  1180	    This object maps each variable in a dataset onto a column and row in a
  1181	    grid of multiple axes. Different axes-level plotting functions can be
  1182	    used to draw bivariate plots in the upper and lower triangles, and the
  1183	    marginal distribution of each variable can be shown on the diagonal.
  1184	
  1185	    Several different common plots can be generated in a single line using
     1	import colorsys
     2	from itertools import cycle
     3	
     4	import numpy as np
     5	import matplotlib as mpl
     6	
     7	from .external import husl
     8	
     9	from .utils import desaturate
    10	from .colors import xkcd_rgb, crayons
    11	
    12	
    13	
    14	__all__ = ["color_palette", "hls_palette", "husl_palette", "mpl_palette",
    15	           "dark_palette", "light_palette", "diverging_palette",
    16	           "blend_palette", "xkcd_palette", "crayon_palette",
    17	           "cubehelix_palette", "set_color_codes"]
    18	
    19	
    20	SEABORN_PALETTES = dict(
    21	    deep=["#4C72B0", "#DD8452", "#55A868", "#C44E52", "#8172B3",
    22	          "#937860", "#DA8BC3", "#8C8C8C", "#CCB974", "#64B5CD"],
    23	    deep6=["#4C72B0", "#55A868", "#C44E52",
    24	           "#8172B3", "#CCB974", "#64B5CD"],
    25	    muted=["#4878D0", "#EE854A", "#6ACC64", "#D65F5F", "#956CB4",
    26	           "#8C613C", "#DC7EC0", "#797979", "#D5BB67", "#82C6E2"],
    27	    muted6=["#4878D0", "#6ACC64", "#D65F5F",
    28	            "#956CB4", "#D5BB67", "#82C6E2"],
    29	    pastel=["#A1C9F4", "#FFB482", "#8DE5A1", "#FF9F9B", "#D0BBFF",
    30	            "#DEBB9B", "#FAB0E4", "#CFCFCF", "#FFFEA3", "#B9F2F0"],
   380	    name : string
   381	        Name of the palette. This should be a named matplotlib colormap.
   382	    n_colors : int
   383	        Number of discrete colors in the palette.
   384	
   385	    Returns
   386	    -------
   387	    list of RGB tuples or :class:`matplotlib.colors.ListedColormap`
   388	
   389	    Examples
   390	    --------
   391	    .. include:: ../docstrings/mpl_palette.rst
   392	
   393	    """
   394	    if name.endswith("_d"):
   395	        sub_name = name[:-2]
   396	        if sub_name.endswith("_r"):
   397	            reverse = True
   398	            sub_name = sub_name[:-2]
   399	        else:
   400	            reverse = False
   401	        pal = color_palette(sub_name, 2) + ["#333333"]
   402	        if reverse:
   403	            pal = pal[::-1]
   404	        cmap = blend_palette(pal, n_colors, as_cmap=True)
   405	    else:
   406	        cmap = get_colormap(name)
   407	
   408	    if name in MPL_QUAL_PALS:
   409	        bins = np.linspace(0, 1, MPL_QUAL_PALS[name])[:n_colors]
   410	    else:
   411	        bins = np.linspace(0, 1, int(n_colors) + 2)[1:-1]
   412	    palette = list(map(tuple, cmap(bins)[:, :3]))
   413	
   414	    if as_cmap:
   415	        return cmap
   416	    else:
   417	        return _ColorPalette(palette)
   418	
   419	
   420	
   421	
   422	
   423	
   424	
   425	
   426	
   427	
   428	
   429	
   430	
   431	
   432	
   433	def dark_palette(color, n_colors=6, reverse=False, as_cmap=False, input="rgb"):
   434	    """Make a sequential palette that blends from dark to ``color``.
   435	
   760	    else:
   761	        return _ColorPalette(pal)
   762	
   763	
   764	
   765	
   766	
   767	
   768	
   769	
   770	
   771	
   772	
   773	
   774	
   775	
   776	
   777	
   778	
   779	
   780	
   781	
   782	
   783	
   784	
   785	
   786	
   787	
   788	
   789	
   790	
   791	
   792	
   793	
   794	
   795	
   796	
   797	
   798	
   799	def set_color_codes(palette="deep"):
   800	    """Change how matplotlib color shorthands are interpreted.
   801	
   802	    Calling this will change how shorthand codes like "b" or "g"
   803	    are interpreted by matplotlib in subsequent plots.
   804	
   805	    Parameters
   806	    ----------
   807	    palette : {deep, muted, pastel, dark, bright, colorblind}
   808	        Named seaborn palette to use as the source of colors.
   809	
   810	    See Also
   811	    --------
   812	    set : Color codes can be set through the high-level seaborn style
   813	          manager.
   814	    set_palette : Color codes can also be set through the function that
   815	                  sets the matplotlib color cycle.
   816	
   817	    """
   818	    if palette == "reset":
   819	        colors = [
   820	            (0., 0., 1.),
   821	            (0., .5, 0.),
   822	            (1., 0., 0.),
   823	            (.75, 0., .75),
   824	            (.75, .75, 0.),
   825	            (0., .75, .75),
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	def desaturate(color, prop):
   148	    """Decrease the saturation channel of a color by some percent.
   149	
   150	    Parameters
   151	    ----------
   152	    color : matplotlib color
   153	        hex, rgb-tuple, or html color name
   154	    prop : float
   155	        saturation channel of color will be multiplied by this value
   156	
   157	    Returns
   158	    -------
   159	    new_color : rgb tuple
   160	        desaturated color code in RGB tuple representation
   161	
   162	    """
   163	    # Check inputs
   164	    if not 0 <= prop <= 1:
   165	        raise ValueError("prop must be between 0 and 1")
   700	    """Calculate the relative luminance of a color according to W3C standards
   701	
   702	    Parameters
   703	    ----------
   704	    color : matplotlib color or sequence of matplotlib colors
   705	        Hex code, rgb-tuple, or html color name.
   706	
   707	    Returns
   708	    -------
   709	    luminance : float(s) between 0 and 1
   710	
   711	    """
   712	    rgb = mpl.colors.colorConverter.to_rgba_array(color)[:, :3]
   713	    rgb = np.where(rgb <= .03928, rgb / 12.92, ((rgb + .055) / 1.055) ** 2.4)
   714	    lum = rgb.dot([.2126, .7152, .0722])
   715	    try:
   716	        return lum.item()
   717	    except ValueError:
   718	        return lum
   719	
   720	
   721	def to_utf8(obj):
   722	    """Return a string representing a Python object.
   723	
   724	    Strings (i.e. type ``str``) are returned unchanged.
   725	
   726	    Byte strings (i.e. type ``bytes``) are returned as UTF-8-decoded strings.
   727	
   728	    For other objects, the method ``__str__()`` is called, and the result is
   729	    returned as a string.
   730	
   731	    Parameters
   732	    ----------
   733	    obj : object
   734	        Any Python object
   735	
   736	    Returns
   737	    -------
   738	    s : str
   739	        UTF-8-decoded string representation of ``obj``
   740	
   741	    """
   742	    if isinstance(obj, str):
   743	        return obj
   744	    try:
   745	        return obj.decode(encoding="utf-8")
   746	    except AttributeError:  # obj is not bytes-like
   747	        return str(obj)
   748	
   749	
   750	def _check_argument(param, options, value, prefix=False):
import ok /testbed/seaborn/__init__.py
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np, matplotlib as mpl
x=np.linspace(0,1,8)
start=.5;rot=-1.5;gamma=1;hue=1
xg=x**gamma
a=hue*xg*(1-xg)/2
phi=2*np.pi*(start/3+rot*x)
pairs=[(-.14861,1.78277),(-.29227,-.90649),(1.97294,0)]
y=np.array([xg+a*(p0*np.cos(phi)+p1*np.sin(phi)) for p0,p1 in pairs]).T
z=mpl.cm.cubehelix(x)[:,:3]
print(np.max(abs(y-z)))
print(y.tolist()==z.tolist())
for a,b in zip(y[1],z[1]): print(repr(a),repr(b),a==b)
PY"
```

退出码：`0`

输出：
```
0.0035566732281282487
False
np.float64(0.10199050875801596) np.float64(0.10231025194333628) False
np.float64(0.1421167767819158) np.float64(0.13952898866828906) False
np.float64(0.2582829272314924) np.float64(0.2560120319409181) False
```

## 原始行 31 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np, matplotlib as mpl
start=.5;rot=-1.5;gamma=1;hue=1
def f(p0,p1):
 def color(x):
  xg=x**gamma
  a=hue*xg*(1-xg)/2
  phi=2*np.pi*(start/3+rot*x)
  return xg+a*(p0*np.cos(phi)+p1*np.sin(phi))
 return color
cd={'red':f(-.14861,1.78277),'green':f(-.29227,-.90649),'blue':f(1.97294,0)}
c=mpl.colors.LinearSegmentedColormap('cubehelix',cd)
x=np.linspace(0,1,8)
y=c(x)[:,:3].tolist();z=mpl.cm.cubehelix(x)[:,:3].tolist()
print(y==z, np.max(abs(np.array(y)-z)))
PY"
```

退出码：`0`

输出：
```
True 0.0
```

## 原始行 35 · agent_message

```
The masked regions line up with the requested interfaces. I also found two required consumers: `palettes.py` needs the compatibility colormap import, and the cubehelix generator needs its channel-function closure restored for the existing colormap construction. I’m applying those together with the two shape-based `FacetGrid` properties.
```

## 原始行 39 · file_change

```
{
  "id": "item_26",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/_compat.py",
      "kind": "update"
    },
    {
      "path": "/testbed/seaborn/axisgrid.py",
      "kind": "update"
    },
    {
      "path": "/testbed/seaborn/palettes.py",
      "kind": "update"
    },
    {
      "path": "/testbed/seaborn/utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 42 · file_change

```
{
  "id": "item_28",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/palettes.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 45 · command_execution

命令：
```
/bin/bash -lc "python -m compileall -q seaborn
python - <<'PY'
import numpy as np
import matplotlib as mpl
import pandas as pd
from cycler import cycler
from seaborn.palettes import _parse_cubehelix_args, cubehelix_palette, color_palette
from seaborn.utils import get_color_cycle
from seaborn._compat import get_colormap
from seaborn.axisgrid import FacetGrid

cases = [
    (\"ch:\", ([], {\"reverse\": False})),
    (\"ch:_r\", ([], {\"reverse\": True})),
    (\"ch:.5, -.25,hue = .5,light=.75\", ([.5, -.25], {\"hue\": .5, \"light\": .75})),
    (\"ch:s=0.5,r=0.8,l=0.9_r\", ([], {\"start\": .5, \"rot\": .8, \"light\": .9, \"reverse\": True})),
]
for spec, expected in cases:
    got = _parse_cubehelix_args(spec)
    assert got == expected, (spec, got, expected)

x = np.linspace(0, 1, 8)
got = cubehelix_palette(8, start=.5, rot=-1.5, hue=1, dark=0, light=1, reverse=True)
assert got == mpl.cm.cubehelix(x)[:, :3].tolist()
assert len(cubehelix_palette(3)) == 3
assert cubehelix_palette() == cubehelix_palette(reverse=True)[::-1]
cmap = cubehelix_palette(as_cmap=True)
assert isinstance(cmap, mpl.colors.ListedColormap) and cmap.N == 256
assert np.array_equal(cmap(np.linspace(0, 1, 6))[:, :3], cubehelix_palette())
assert color_palette(\"ch:\", 8) == cubehelix_palette(8)
with mpl.rc_context(rc={\"axes.prop_cycle\": cycler(lw=[1, 2])}):
    assert get_color_cycle() == [\".15\"]
assert get_colormap(\"viridis\").name == \"viridis\"

g = FacetGrid(pd.DataFrame({\"x\": [1, 2]}), despine=False)
assert g.ax is g.axes[0, 0]
assert g.axes_dict == {}
g = FacetGrid(pd.DataFrame({\"x\": [1, 2], \"c\": [1, 2]}), col=\"c\", despine=False)
try:
    g.ax
except AttributeError:
    pass
else:
    raise AssertionError(\"g.ax should fail\")
assert list(g.axes_dict) == [1, 2]
print(\"smoke checks passed\")
PY"
```

退出码：`1`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 28, in <module>
AssertionError
```

## 原始行 47 · agent_message

```
The first smoke run exposed one numerical assertion that needs localization; parsing, imports, and compilation completed before that point. I’m checking the exact cubehelix comparison now, including discrete colormap sampling behavior.
```

## 原始行 49 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import numpy as np, matplotlib as mpl
from seaborn.palettes import cubehelix_palette, color_palette
x=np.linspace(0,1,8)
got=cubehelix_palette(8,start=.5,rot=-1.5,hue=1,dark=0,light=1,reverse=True)
print('mpl equality',got == mpl.cm.cubehelix(x)[:,:3].tolist(), np.max(np.abs(np.array(got)-mpl.cm.cubehelix(x)[:,:3])))
print('reverse',cubehelix_palette() == cubehelix_palette(reverse=True)[::-1])
cmap=cubehelix_palette(as_cmap=True)
print(type(cmap),cmap.N)
a=cmap(np.linspace(0,1,6))[:,:3]; b=np.asarray(cubehelix_palette())
print('cmap equality',np.array_equal(a,b),np.max(abs(a-b)))
print(a)
print(b)
print('string equality',color_palette('ch:',8)==cubehelix_palette(8))
PY"
```

退出码：`0`

输出：
```
mpl equality True 0.0
reverse True
<class 'matplotlib.colors.ListedColormap'> 256
cmap equality True 0.0
[[0.93126922 0.82019218 0.7971481 ]
 [0.85595786 0.64189931 0.67541912]
 [0.73973433 0.47652807 0.59596174]
 [0.57916574 0.33934576 0.52190039]
 [0.37894938 0.2224702  0.41140014]
 [0.17508656 0.11840023 0.24215989]]
[[0.93126922 0.82019218 0.7971481 ]
 [0.85595786 0.64189931 0.67541912]
 [0.73973433 0.47652807 0.59596174]
 [0.57916574 0.33934576 0.52190039]
 [0.37894938 0.2224702  0.41140014]
 [0.17508656 0.11840023 0.24215989]]
string equality False
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import pandas as pd
from seaborn.axisgrid import FacetGrid

g = FacetGrid(pd.DataFrame({'x': [1, 2]}), despine=False)
assert g.ax is g.axes[0, 0]
assert g.axes_dict == {}
g = FacetGrid(pd.DataFrame({'x': [1, 2], 'c': [1, 2]}), col='c', despine=False)
try:
    g.ax
except AttributeError:
    pass
else:
    raise AssertionError('g.ax should fail')
assert list(g.axes_dict) == [1, 2]
print('facet smoke checks passed')
PY
pytest -q tests/test_palettes.py::TestColorPalettes::test_cubehelix_against_matplotlib tests/test_palettes.py::TestColorPalettes::test_cubehelix_n_colors tests/test_palettes.py::TestColorPalettes::test_cubehelix_reverse tests/test_palettes.py::TestColorPalettes::test_cubehelix_cmap tests/test_palettes.py::TestColorPalettes::test_cubehelix_code tests/test_utils.py::test_get_color_cycle tests/test_axisgrid.py::TestFacetGrid::test_single_axes tests/test_axisgrid.py::TestFacetGrid::test_axes_dict"
```

退出码：`4`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 4, in <module>
  File "/testbed/seaborn/axisgrid.py", line 391, in __init__
    colors = self._get_palette(data, hue, hue_order, palette)
  File "/testbed/seaborn/axisgrid.py", line 252, in _get_palette
    palette = color_palette(n_colors=1)
  File "/testbed/seaborn/palettes.py", line 212, in color_palette
    palette = get_color_cycle()
NameError: name 'get_color_cycle' is not defined. Did you mean: 'set_color_codes'?

==================================== ERRORS ====================================
_____________________ ERROR collecting tests/test_utils.py _____________________
ImportError while importing test module '/testbed/tests/test_utils.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.10/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
tests/test_utils.py:24: in <module>
    from seaborn.utils import (
E   ImportError: cannot import name 'remove_na' from 'seaborn.utils' (/testbed/seaborn/utils.py)
=========================== short test summary info ============================
ERROR tests/test_utils.py
1 error in 0.53s
ERROR: found no collectors for /testbed/tests/test_utils.py::test_get_color_cycle
```

## 原始行 54 · agent_message

```
The smoke run identified a genuine consumer dependency: `color_palette(None)` calls `get_color_cycle` by local name, so `palettes.py` must import the restored utility. The visible utility test module itself cannot collect because a separate masked, out-of-scope `remove_na` function is absent; I’ll validate `get_color_cycle` directly and run the palette/grid test modules separately.
```

## 原始行 56 · file_change

```
{
  "id": "item_38",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/palettes.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 59 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/test_palettes.py::TestColorPalettes::test_cubehelix_against_matplotlib tests/test_palettes.py::TestColorPalettes::test_cubehelix_n_colors tests/test_palettes.py::TestColorPalettes::test_cubehelix_reverse tests/test_palettes.py::TestColorPalettes::test_cubehelix_cmap tests/test_palettes.py::TestColorPalettes::test_cubehelix_code'
```

退出码：`0`

输出：
```
.....                                                                    [100%]
5 passed in 0.23s
```

## 原始行 61 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/test_axisgrid.py::TestFacetGrid::test_single_axes tests/test_axisgrid.py::TestFacetGrid::test_axes_dict'
```

退出码：`0`

输出：
```
..                                                                       [100%]
2 passed in 1.03s
```

## 原始行 64 · agent_message

```
The requested palette and grid tests now pass. Before the final run, I’m tightening the `FacetGrid.ax` error text to the established public wording and exercising parser edge cases plus both colormap registry paths.
```

## 原始行 66 · file_change

```
{
  "id": "item_45",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/axisgrid.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 69 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from types import SimpleNamespace
from cycler import cycler
import matplotlib as mpl
from seaborn import _compat
from seaborn.palettes import _parse_cubehelix_args
from seaborn.utils import get_color_cycle

assert _parse_cubehelix_args(\"\") == ([], {\"reverse\": False})
assert _parse_cubehelix_args(\"ch:\") == ([], {\"reverse\": False})
assert _parse_cubehelix_args(\"ch:_r\") == ([], {\"reverse\": True})
assert _parse_cubehelix_args(\"ch: 0.2, 0.5, g = 1.2\") == (
    [0.2, 0.5], {\"gamma\": 1.2}
)
assert _parse_cubehelix_args(\"ch:s=.5,r=.8,g=1.2,h=.4,l=.9,d=.1_r\") == (
    [], {\"start\": .5, \"rot\": .8, \"gamma\": 1.2, \"hue\": .4,
         \"light\": .9, \"dark\": .1, \"reverse\": True}
)
with mpl.rc_context(rc={\"axes.prop_cycle\": cycler(color=[\"r\", \"b\"])}):
    assert get_color_cycle() == [\"r\", \"b\"]
with mpl.rc_context(rc={\"axes.prop_cycle\": cycler(lw=[1, 2])}):
    assert get_color_cycle() == [\".15\"]
assert _compat.get_colormap(\"plasma\").name == \"plasma\"
original_mpl = _compat.mpl
try:
    sentinel = object()
    _compat.mpl = SimpleNamespace(cm=SimpleNamespace(get_cmap=lambda name: sentinel))
    assert _compat.get_colormap(\"anything\") is sentinel
finally:
    _compat.mpl = original_mpl
print(\"interface edge checks passed\")
PY
pytest -q tests/test_palettes.py"
```

退出码：`1`

输出：
```
interface edge checks passed
..FF..F.F...F...F..FFFFFFF............                                   [100%]
=================================== FAILURES ===================================
__________________ TestColorPalettes.test_big_palette_context __________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc9447c70>

    def test_big_palette_context(self):
    
        original_pal = palettes.color_palette("deep", n_colors=8)
>       context_pal = palettes.color_palette("husl", 10)

tests/test_palettes.py:36: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:236: in color_palette
    palette = husl_palette(n_colors, as_cmap=as_cmap)
seaborn/palettes.py:396: in husl_palette
    palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

.0 = <iterator object at 0x775cc9447970>

>   palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
E   NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:396: NameError
_____________________ TestColorPalettes.test_palette_size ______________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc9445f30>

    def test_palette_size(self):
    
        pal = palettes.color_palette("deep")
        assert len(pal) == palettes.QUAL_PALETTE_SIZES["deep"]
    
        pal = palettes.color_palette("pastel6")
        assert len(pal) == palettes.QUAL_PALETTE_SIZES["pastel6"]
    
        pal = palettes.color_palette("Set3")
        assert len(pal) == palettes.QUAL_PALETTE_SIZES["Set3"]
    
>       pal = palettes.color_palette("husl")

tests/test_palettes.py:58: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:236: in color_palette
    palette = husl_palette(n_colors, as_cmap=as_cmap)
seaborn/palettes.py:396: in husl_palette
    palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

.0 = <iterator object at 0x775cc937b490>

>   palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
E   NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:396: NameError
_____________________ TestColorPalettes.test_husl_palette ______________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc9444ee0>

    def test_husl_palette(self):
    
>       pal1 = palettes.husl_palette()

tests/test_palettes.py:85: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:396: in husl_palette
    palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

.0 = <iterator object at 0x775cc935e380>

>   palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
E   NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:396: NameError
___________________ TestColorPalettes.test_mpl_dark_palette ____________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc9445fc0>

    def test_mpl_dark_palette(self):
    
>       mpl_pal1 = palettes.mpl_palette("Blues_d")

tests/test_palettes.py:107: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:441: in mpl_palette
    cmap = blend_palette(pal, n_colors, as_cmap=True)
seaborn/palettes.py:640: in blend_palette
    colors = [_color_to_rgb(color, input) for color in colors]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

.0 = <list_iterator object at 0x775cc91cff70>

>   colors = [_color_to_rgb(color, input) for color in colors]
E   NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:640: NameError
_____________________ TestColorPalettes.test_palette_desat _____________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc9445840>

    def test_palette_desat(self):
    
>       pal1 = palettes.husl_palette(6)

tests/test_palettes.py:133: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:396: in husl_palette
    palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

.0 = <iterator object at 0x775cc9379c00>

>   palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
E   NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:396: NameError
______________________ TestColorPalettes.test_husl_values ______________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc92e46a0>

    def test_husl_values(self):
    
>       pal1 = palettes.husl_palette(6, h=0)

tests/test_palettes.py:173: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:396: in husl_palette
    palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

.0 = <iterator object at 0x775cc935d1e0>

>   palette = [_color_to_rgb((h_i, s, l), input="husl") for h_i in hues]
E   NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:396: NameError
_____________________ TestColorPalettes.test_rgb_from_hls ______________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc92e5030>

    def test_rgb_from_hls(self):
    
        color = .5, .8, .4
>       rgb_got = palettes._color_to_rgb(color, "hls")
E       AttributeError: module 'seaborn.palettes' has no attribute '_color_to_rgb'

tests/test_palettes.py:207: AttributeError
_____________________ TestColorPalettes.test_rgb_from_husl _____________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc92e5360>

    def test_rgb_from_husl(self):
    
        color = 120, 50, 40
>       rgb_got = palettes._color_to_rgb(color, "husl")
E       AttributeError: module 'seaborn.palettes' has no attribute '_color_to_rgb'

tests/test_palettes.py:214: AttributeError
_____________________ TestColorPalettes.test_rgb_from_xkcd _____________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc92e5690>

    def test_rgb_from_xkcd(self):
    
        color = "dull red"
>       rgb_got = palettes._color_to_rgb(color, "xkcd")
E       AttributeError: module 'seaborn.palettes' has no attribute '_color_to_rgb'

tests/test_palettes.py:227: AttributeError
_____________________ TestColorPalettes.test_light_palette _____________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc92e59c0>

    def test_light_palette(self):
    
        n = 4
>       pal_forward = palettes.light_palette("red", n)

tests/test_palettes.py:234: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

color = 'red', n_colors = 4, reverse = False, as_cmap = False, input = 'rgb'

    def light_palette(color, n_colors=6, reverse=False, as_cmap=False, input="rgb"):
        """Make a sequential palette that blends from light to ``color``.
    
        The ``color`` parameter can be specified in a number of ways, including
        all options for defining a color in matplotlib and several additional
        color spaces that are handled by seaborn. You can also use the database
        of named colors from the XKCD color survey.
    
        If you are using a Jupyter notebook, you can also choose this palette
        interactively with the :func:`choose_light_palette` function.
    
        Parameters
        ----------
        color : base color for high values
            hex code, html color name, or tuple in `input` space.
        n_colors : int, optional
            number of colors in the palette
        reverse : bool, optional
            if True, reverse the direction of the blend
        as_cmap : bool, optional
            If True, return a :class:`matplotlib.colors.ListedColormap`.
        input : {'rgb', 'hls', 'husl', xkcd'}
            Color space to interpret the input color. The first three options
            apply to tuple inputs and the latter applies to string inputs.
    
        Returns
        -------
        palette
            list of RGB tuples or :class:`matplotlib.colors.ListedColormap`
    
        See Also
        --------
        dark_palette : Create a sequential palette with dark low values.
        diverging_palette : Create a diverging palette with two colors.
    
        Examples
        --------
        .. include:: ../docstrings/light_palette.rst
    
        """
>       rgb = _color_to_rgb(color, input)
E       NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:561: NameError
_____________________ TestColorPalettes.test_dark_palette ______________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc9445a80>

    def test_dark_palette(self):
    
        n = 4
>       pal_forward = palettes.dark_palette("red", n)

tests/test_palettes.py:260: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

color = 'red', n_colors = 4, reverse = False, as_cmap = False, input = 'rgb'

    def dark_palette(color, n_colors=6, reverse=False, as_cmap=False, input="rgb"):
        """Make a sequential palette that blends from dark to ``color``.
    
        This kind of palette is good for data that range between relatively
        uninteresting low values and interesting high values.
    
        The ``color`` parameter can be specified in a number of ways, including
        all options for defining a color in matplotlib and several additional
        color spaces that are handled by seaborn. You can also use the database
        of named colors from the XKCD color survey.
    
        If you are using the IPython notebook, you can also choose this palette
        interactively with the :func:`choose_dark_palette` function.
    
        Parameters
        ----------
        color : base color for high values
            hex, rgb-tuple, or html color name
        n_colors : int, optional
            number of colors in the palette
        reverse : bool, optional
            if True, reverse the direction of the blend
        as_cmap : bool, optional
            If True, return a :class:`matplotlib.colors.ListedColormap`.
        input : {'rgb', 'hls', 'husl', xkcd'}
            Color space to interpret the input color. The first three options
            apply to tuple inputs and the latter applies to string inputs.
    
        Returns
        -------
        palette
            list of RGB tuples or :class:`matplotlib.colors.ListedColormap`
    
        See Also
        --------
        light_palette : Create a sequential palette with bright low values.
        diverging_palette : Create a diverging palette with two colors.
    
        Examples
        --------
        .. include:: ../docstrings/dark_palette.rst
    
        """
>       rgb = _color_to_rgb(color, input)
E       NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:513: NameError
___________________ TestColorPalettes.test_diverging_palette ___________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc9445360>

    def test_diverging_palette(self):
    
        h_neg, h_pos = 100, 200
        sat, lum = 70, 50
        args = h_neg, h_pos, sat, lum
    
        n = 12
>       pal = palettes.diverging_palette(*args, n=n)

tests/test_palettes.py:290: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:610: in diverging_palette
    neg = palfunc((h_neg, s, l), n_half, reverse=True, input="husl")
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

color = (100, 70, 50), n_colors = 128, reverse = True, as_cmap = False
input = 'husl'

    def light_palette(color, n_colors=6, reverse=False, as_cmap=False, input="rgb"):
        """Make a sequential palette that blends from light to ``color``.
    
        The ``color`` parameter can be specified in a number of ways, including
        all options for defining a color in matplotlib and several additional
        color spaces that are handled by seaborn. You can also use the database
        of named colors from the XKCD color survey.
    
        If you are using a Jupyter notebook, you can also choose this palette
        interactively with the :func:`choose_light_palette` function.
    
        Parameters
        ----------
        color : base color for high values
            hex code, html color name, or tuple in `input` space.
        n_colors : int, optional
            number of colors in the palette
        reverse : bool, optional
            if True, reverse the direction of the blend
        as_cmap : bool, optional
            If True, return a :class:`matplotlib.colors.ListedColormap`.
        input : {'rgb', 'hls', 'husl', xkcd'}
            Color space to interpret the input color. The first three options
            apply to tuple inputs and the latter applies to string inputs.
    
        Returns
        -------
        palette
            list of RGB tuples or :class:`matplotlib.colors.ListedColormap`
    
        See Also
        --------
        dark_palette : Create a sequential palette with dark low values.
        diverging_palette : Create a diverging palette with two colors.
    
        Examples
        --------
        .. include:: ../docstrings/light_palette.rst
    
        """
>       rgb = _color_to_rgb(color, input)
E       NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:561: NameError
_____________________ TestColorPalettes.test_blend_palette _____________________

self = <tests.test_palettes.TestColorPalettes object at 0x775cc94456c0>

    def test_blend_palette(self):
    
        colors = ["red", "yellow", "white"]
>       pal_cmap = palettes.blend_palette(colors, as_cmap=True)

tests/test_palettes.py:308: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
seaborn/palettes.py:640: in blend_palette
    colors = [_color_to_rgb(color, input) for color in colors]
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

.0 = <list_iterator object at 0x775cc9447010>

>   colors = [_color_to_rgb(color, input) for color in colors]
E   NameError: name '_color_to_rgb' is not defined

seaborn/palettes.py:640: NameError
=========================== short test summary info ============================
FAILED tests/test_palettes.py::TestColorPalettes::test_big_palette_context - ...
FAILED tests/test_palettes.py::TestColorPalettes::test_palette_size - NameErr...
FAILED tests/test_palettes.py::TestColorPalettes::test_husl_palette - NameErr...
FAILED tests/test_palettes.py::TestColorPalettes::test_mpl_dark_palette - Nam...
FAILED tests/test_palettes.py::TestColorPalettes::test_palette_desat - NameEr...
FAILED tests/test_palettes.py::TestColorPalettes::test_husl_values - NameErro...
FAILED tests/test_palettes.py::TestColorPalettes::test_rgb_from_hls - Attribu...
FAILED tests/test_palettes.py::TestColorPalettes::test_rgb_from_husl - Attrib...
FAILED tests/test_palettes.py::TestColorPalettes::test_rgb_from_xkcd - Attrib...
FAILED tests/test_palettes.py::TestColorPalettes::test_light_palette - NameEr...
FAILED tests/test_palettes.py::TestColorPalettes::test_dark_palette - NameErr...
FAILED tests/test_palettes.py::TestColorPalettes::test_diverging_palette - Na...
FAILED tests/test_palettes.py::TestColorPalettes::test_blend_palette - NameEr...
13 failed, 25 passed in 0.47s
```

## 原始行 72 · command_execution

命令：
```
/bin/bash -lc "git diff --check
git diff -- seaborn/palettes.py seaborn/utils.py seaborn/_compat.py seaborn/axisgrid.py
python - <<'PY'
import matplotlib.pyplot as plt
import pandas as pd
from seaborn.axisgrid import FacetGrid

def close(g):
    plt.close(g.figure)

g = FacetGrid(pd.DataFrame({'facet': [7, 7]}), col='facet', despine=False)
assert g.axes.shape == (1, 1)
assert g.ax is g.axes[0, 0]
assert g.axes_dict[7] is g.ax
close(g)

g = FacetGrid(pd.DataFrame({'facet': [7, 7]}), col='facet', col_wrap=1, despine=False)
assert g.axes.shape == (1,)
try:
    g.ax
except AttributeError:
    pass
else:
    raise AssertionError
close(g)
print('realized-shape checks passed')
PY"
```

退出码：`0`

输出：
```
diff --git a/seaborn/_compat.py b/seaborn/_compat.py
index 3c2803a..a3fa36b 100644
--- a/seaborn/_compat.py
+++ b/seaborn/_compat.py
@@ -64,6 +64,14 @@ def norm_from_scale(scale, norm):
 
 
 
+def get_colormap(name):
+    """Retrieve a matplotlib colormap by name across registry APIs."""
+    try:
+        return mpl.colormaps[name]
+    except AttributeError:
+        return mpl.cm.get_cmap(name)
+
+
 def register_colormap(name, cmap):
     """Handle changes to matplotlib colormap interface in 3.6."""
     try:
@@ -126,4 +134,4 @@ def groupby_apply_include_groups(val):
 def get_converter(axis):
     if _version_predates(mpl, "3.10.0"):
         return axis.converter
-    return axis.get_converter()
\ No newline at end of file
+    return axis.get_converter()
diff --git a/seaborn/axisgrid.py b/seaborn/axisgrid.py
index 0872f3a..ba657e0 100644
--- a/seaborn/axisgrid.py
+++ b/seaborn/axisgrid.py
@@ -1073,6 +1073,20 @@ class FacetGrid(Grid):
         """An array of the :class:`matplotlib.axes.Axes` objects in the grid."""
         return self._axes
 
+    @property
+    def ax(self):
+        """The :class:`matplotlib.axes.Axes` when the grid has shape (1, 1)."""
+        if self.axes.shape == (1, 1):
+            return self.axes[0, 0]
+        raise AttributeError(
+            "Use the `.axes` attribute when facet variables are assigned."
+        )
+
+    @property
+    def axes_dict(self):
+        """A mapping of facet names to the corresponding Axes objects."""
+        return self._axes_dict
+
 
 
 
@@ -2398,4 +2412,4 @@ Examples
     params=_param_docs,
     returns=_core_docs["returns"],
     seealso=_core_docs["seealso"],
-)
\ No newline at end of file
+)
diff --git a/seaborn/palettes.py b/seaborn/palettes.py
index e24df41..0f47514 100644
--- a/seaborn/palettes.py
+++ b/seaborn/palettes.py
@@ -6,7 +6,8 @@ import matplotlib as mpl
 
 from .external import husl
 
-from .utils import desaturate
+from ._compat import get_colormap
+from .utils import desaturate, get_color_cycle
 from .colors import xkcd_rgb, crayons
 
 
@@ -58,6 +59,42 @@ QUAL_PALETTE_SIZES.update({k: len(v) for k, v in SEABORN_PALETTES.items()})
 QUAL_PALETTES = list(QUAL_PALETTE_SIZES.keys())
 
 
+def _parse_cubehelix_args(argstr):
+    """Parse a cubehelix palette specification string."""
+    if argstr.startswith("ch:"):
+        argstr = argstr[3:]
+
+    reverse = argstr.endswith("_r")
+    if reverse:
+        argstr = argstr[:-2]
+
+    if not argstr.strip(" "):
+        return [], {"reverse": reverse}
+
+    aliases = {
+        "s": "start",
+        "r": "rot",
+        "g": "gamma",
+        "h": "hue",
+        "l": "light",
+        "d": "dark",
+    }
+    args = []
+    kwargs = {}
+    for item in argstr.split(","):
+        if "=" in item:
+            key, value = item.split("=", 1)
+            key = key.strip(" ")
+            kwargs[aliases.get(key, key)] = float(value.strip(" "))
+        else:
+            args.append(float(item.strip(" ")))
+
+    if reverse:
+        kwargs["reverse"] = True
+
+    return args, kwargs
+
+
 class _ColorPalette(list):
     """Set the color palette in a with statement, otherwise be a list."""
     def __enter__(self):
@@ -737,6 +774,14 @@ def cubehelix_palette(n_colors=6, start=0, rot=.4, gamma=1.0, hue=0.8,
 
 
 
+    def get_color_function(p0, p1):
+        def color(x):
+            xg = x ** gamma
+            a = hue * xg * (1 - xg) / 2
+            phi = 2 * np.pi * (start / 3 + rot * x)
+            return xg + a * (p0 * np.cos(phi) + p1 * np.sin(phi))
+        return color
+
     cdict = {
         "red": get_color_function(-0.14861, 1.78277),
         "green": get_color_function(-0.29227, -0.90649),
@@ -838,4 +883,4 @@ def set_color_codes(palette="deep"):
 
     for code, color in zip("bgrmyck", colors):
         rgb = mpl.colors.colorConverter.to_rgb(color)
-        mpl.colors.colorConverter.colors[code] = rgb
\ No newline at end of file
+        mpl.colors.colorConverter.colors[code] = rgb
diff --git a/seaborn/utils.py b/seaborn/utils.py
index 5c118ed..64aafbb 100644
--- a/seaborn/utils.py
+++ b/seaborn/utils.py
@@ -55,6 +55,12 @@ def ci_to_errsize(cis, heights):
     return errsize
 
 
+def get_color_cycle():
+    """Return the list of colors in the current matplotlib color cycle."""
+    cycler = mpl.rcParams["axes.prop_cycle"]
+    return cycler.by_key().get("color", [".15"])
+
+
 
 
 
@@ -894,4 +900,4 @@ def _get_patch_legend_artist(fill):
 
         return mpl.patches.Rectangle((0, 0), 0, 0, **kws)
 
-    return legend_artist
\ No newline at end of file
+    return legend_artist
realized-shape checks passed
```

## 原始行 76 · command_execution

命令：
```
/bin/bash -lc 'grep -nE "def test_.*(palette|color)|get_color_cycle" tests/test_rcmod.py | head -80
pytest -q tests/test_palettes.py::TestColorPalettes::test_current_palette tests/test_palettes.py::TestColorPalettes::test_palette_context tests/test_palettes.py::TestColorPalettes::test_mpl_palette tests/test_axisgrid.py::TestFacetGrid::test_axes_array_size tests/test_axisgrid.py::TestFacetGrid::test_single_axes tests/test_axisgrid.py::TestFacetGrid::test_axes_dict'
```

退出码：`0`

输出：
```
134:    def test_set_with_palette(self):
139:        assert utils.get_color_cycle() == palettes.color_palette("deep", 10)
143:        assert utils.get_color_cycle() == palettes.color_palette("deep", 10)
148:        assert utils.get_color_cycle() == palettes.color_palette("deep", 10)
152:        assert utils.get_color_cycle() == palettes.color_palette("deep", 10)
254:    def test_set_palette(self):
257:        assert utils.get_color_cycle() == palettes.color_palette("deep", 10)
260:        assert utils.get_color_cycle() == palettes.color_palette("pastel6", 6)
263:        assert utils.get_color_cycle() == palettes.color_palette("dark", 4)
266:        assert utils.get_color_cycle() == palettes.color_palette("Set2", 8)
......                                                                   [100%]
6 passed in 1.45s
```

## 原始行 79 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/test_rcmod.py::TestSet::test_set_with_palette tests/test_rcmod.py::TestPalette::test_set_palette'
```

退出码：`4`

输出：
```
ERROR: not found: /testbed/tests/test_rcmod.py::TestSet::test_set_with_palette
(no match in any of [<Module test_rcmod.py>])


no tests ran in 0.22s
```

## 原始行 81 · agent_message

```
All requested behaviors are now validated: cubehelix generation/parser tests pass, the colormap registry and legacy fallback both work, color-cycle fallback is correct, and `FacetGrid.ax` follows the realized axes shape (including one-level and wrapped cases). I’m doing one final repository status check for scope.
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc 'git status --short
git diff --stat
python -m compileall -q seaborn'
```

退出码：`0`

输出：
```
 M seaborn/_compat.py
 M seaborn/axisgrid.py
 M seaborn/palettes.py
 M seaborn/utils.py
 seaborn/_compat.py  | 10 +++++++++-
 seaborn/axisgrid.py | 16 +++++++++++++++-
 seaborn/palettes.py | 49 +++++++++++++++++++++++++++++++++++++++++++++++--
 seaborn/utils.py    |  8 +++++++-
 4 files changed, 78 insertions(+), 5 deletions(-)
```

## 原始行 85 · agent_message

```
Implemented the requested restorations:

- Cubehelix parser and palette generator in [palettes.py](/testbed/seaborn/palettes.py)
- Matplotlib color-cycle retrieval in [utils.py](/testbed/seaborn/utils.py)
- Colormap compatibility lookup in [_compat.py](/testbed/seaborn/_compat.py)
- `FacetGrid.ax` and `FacetGrid.axes_dict` in [axisgrid.py](/testbed/seaborn/axisgrid.py)

Validation:

- Cubehelix focused tests: 5 passed
- FacetGrid accessor tests: 2 passed
- Additional palette/grid integration tests: 6 passed
- Parser, fallback, and realized-shape edge checks passed
- `compileall` passed

Broader visible tests still encounter unrelated pre-existing masked functions such as `remove_na` and `_color_to_rgb`; those were outside this task’s scope.
```
