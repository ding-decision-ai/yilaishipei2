# Codex baseline: mlflow__mlflow.93dab383.test_client_webhooks.75e39b52.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll trace the existing webhook entities, lower-level registry client, and visible tests first, then implement the smallest compatible restoration and run the focused test set.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "rg -n \"def (create_webhook|get_webhook|list_webhooks|update_webhook|delete_webhook)|class Webhook(Event)?|WebhookStatus|WebhookEventStr\" mlflow tests --glob '*.py'"
```

退出码：`127`

输出：
```
/bin/bash: line 1: rg: command not found
```

## 原始行 8 · agent_message

```
`rg` isn’t installed in this environment, so I’m switching to repository-local `find`/`grep` inspection and keeping the search scoped to `/testbed`.
```

## 原始行 10 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"def (create_webhook|get_webhook|list_webhooks|update_webhook|delete_webhook)|class Webhook(Event)?|WebhookStatus|WebhookEventStr\" mlflow tests --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/server/handlers.py:43:from mlflow.entities.webhook import WebhookAction, WebhookEntity, WebhookEvent, WebhookStatus
mlflow/server/handlers.py:2589:        status=WebhookStatus.from_proto(request_message.status) if request_message.status else None,
mlflow/server/handlers.py:2649:        status=WebhookStatus.from_proto(request_message.status) if request_message.status else None,
mlflow/tracking/client.py:53:    WebhookEventStr,
mlflow/tracking/client.py:54:    WebhookStatus,
mlflow/tracking/client.py:6438:        self, webhook_id: str, event: WebhookEventStr | WebhookEvent | None = None
mlflow/tracking/_model_registry/client.py:22:    WebhookEventStr,
mlflow/tracking/_model_registry/client.py:23:    WebhookStatus,
mlflow/tracking/_model_registry/client.py:899:        self, webhook_id: str, event: WebhookEventStr | WebhookEvent | None = None
mlflow/protos/webhooks_pb2.py:23:  DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0ewebhooks.proto\x12\x06mlflow\x1a\x10\x64\x61tabricks.proto\x1a\x15scalapb/scalapb.proto\"h\n\x0cWebhookEvent\x12+\n\x06\x65ntity\x18\x01 \x01(\x0e\x32\x15.mlflow.WebhookEntityB\x04\xf8\x86\x19\x01\x12+\n\x06\x61\x63tion\x18\x02 \x01(\x0e\x32\x15.mlflow.WebhookActionB\x04\xf8\x86\x19\x01\"\xd6\x01\n\x07Webhook\x12\x12\n\nwebhook_id\x18\x01 \x01(\t\x12\x0c\n\x04name\x18\x02 \x01(\t\x12\x13\n\x0b\x64\x65scription\x18\x03 \x01(\t\x12\x0b\n\x03url\x18\x04 \x01(\t\x12$\n\x06\x65vents\x18\x05 \x03(\x0b\x32\x14.mlflow.WebhookEvent\x12%\n\x06status\x18\x06 \x01(\x0e\x32\x15.mlflow.WebhookStatus\x12\x1a\n\x12\x63reation_timestamp\x18\x07 \x01(\x03\x12\x1e\n\x16last_updated_timestamp\x18\x08 \x01(\x03\"k\n\x11WebhookTestResult\x12\x0f\n\x07success\x18\x01 \x01(\x08\x12\x17\n\x0fresponse_status\x18\x02 \x01(\x05\x12\x15\n\rresponse_body\x18\x03 \x01(\t\x12\x15\n\rerror_message\x18\x04 \x01(\t\"\x89\x02\n\rCreateWebhook\x12\x12\n\x04name\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x12\x13\n\x0b\x64\x65scription\x18\x02 \x01(\t\x12\x11\n\x03url\x18\x03 \x01(\tB\x04\xf8\x86\x19\x01\x12*\n\x06\x65vents\x18\x04 \x03(\x0b\x32\x14.mlflow.WebhookEventB\x04\xf8\x86\x19\x01\x12\x0e\n\x06secret\x18\x05 \x01(\t\x12%\n\x06status\x18\x06 \x01(\x0e\x32\x15.mlflow.WebhookStatus\x1a,\n\x08Response\x12 \n\x07webhook\x18\x01 \x01(\x0b\x32\x0f.mlflow.Webhook:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\xb1\x01\n\x0cListWebhooks\x12\x18\n\x0bmax_results\x18\x01 \x01(\x05:\x03\x31\x30\x30\x12\x12\n\npage_token\x18\x02 \x01(\t\x1a\x46\n\x08Response\x12!\n\x08webhooks\x18\x01 \x03(\x0b\x32\x0f.mlflow.Webhook\x12\x17\n\x0fnext_page_token\x18\x02 \x01(\t:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\x81\x01\n\nGetWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x1a,\n\x08Response\x12 \n\x07webhook\x18\x01 \x01(\x0b\x32\x0f.mlflow.Webhook:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\x91\x02\n\rUpdateWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x12\x0c\n\x04name\x18\x02 \x01(\t\x12\x13\n\x0b\x64\x65scription\x18\x03 \x01(\t\x12\x0b\n\x03url\x18\x04 \x01(\t\x12$\n\x06\x65vents\x18\x05 \x03(\x0b\x32\x14.mlflow.WebhookEvent\x12\x0e\n\x06secret\x18\x06 \x01(\t\x12%\n\x06status\x18\x07 \x01(\x0e\x32\x15.mlflow.WebhookStatus\x1a,\n\x08Response\x12 \n\x07webhook\x18\x01 \x01(\x0b\x32\x0f.mlflow.Webhook:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"b\n\rDeleteWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x1a\n\n\x08Response:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\xb0\x01\n\x0bTestWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x12#\n\x05\x65vent\x18\x02 \x01(\x0b\x32\x14.mlflow.WebhookEvent\x1a\x35\n\x08Response\x12)\n\x06result\x18\x01 \x01(\x0b\x32\x19.mlflow.WebhookTestResult:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]*)\n\rWebhookStatus\x12\n\n\x06\x41\x43TIVE\x10\x01\x12\x0c\n\x08\x44ISABLED\x10\x02*\xda\x01\n\rWebhookEntity\x12\x16\n\x12\x45NTITY_UNSPECIFIED\x10\x00\x12\x14\n\x10REGISTERED_MODEL\x10\x01\x12\x11\n\rMODEL_VERSION\x10\x02\x12\x15\n\x11MODEL_VERSION_TAG\x10\x03\x12\x17\n\x13MODEL_VERSION_ALIAS\x10\x04\x12\n\n\x06PROMPT\x10\x05\x12\x12\n\x0ePROMPT_VERSION\x10\x06\x12\x0e\n\nPROMPT_TAG\x10\x07\x12\x16\n\x12PROMPT_VERSION_TAG\x10\x08\x12\x10\n\x0cPROMPT_ALIAS\x10\t*W\n\rWebhookAction\x12\x16\n\x12\x41\x43TION_UNSPECIFIED\x10\x00\x12\x0b\n\x07\x43REATED\x10\x01\x12\x0b\n\x07UPDATED\x10\x02\x12\x0b\n\x07\x44\x45LETED\x10\x03\x12\x07\n\x03SET\x10\x04\x32\xb5\x06\n\x0eWebhookService\x12~\n\rcreateWebhook\x12\x15.mlflow.CreateWebhook\x1a\x1e.mlflow.CreateWebhook.Response\"6\xf2\x86\x19\x32\n\x1e\n\x04POST\x12\x10/mlflow/webhooks\x1a\x04\x08\x02\x10\x00\x10\x01*\x0e\x43reate Webhook\x12y\n\x0clistWebhooks\x12\x14.mlflow.ListWebhooks\x1a\x1d.mlflow.ListWebhooks.Response\"4\xf2\x86\x19\x30\n\x1d\n\x03GET\x12\x10/mlflow/webhooks\x1a\x04\x08\x02\x10\x00\x10\x01*\rList Webhooks\x12~\n\ngetWebhook\x12\x12.mlflow.GetWebhook\x1a\x1b.mlflow.GetWebhook.Response\"?\xf2\x86\x19;\n*\n\x03GET\x12\x1d/mlflow/webhooks/{webhook_id}\x1a\x04\x08\x02\x10\x00\x10\x01*\x0bGet Webhook\x12\x8c\x01\n\rupdateWebhook\x12\x15.mlflow.UpdateWebhook\x1a\x1e.mlflow.UpdateWebhook.Response\"D\xf2\x86\x19@\n,\n\x05PATCH\x12\x1d/mlflow/webhooks/{webhook_id}\x1a\x04\x08\x02\x10\x00\x10\x01*\x0eUpdate Webhook\x12\x8d\x01\n\rdeleteWebhook\x12\x15.mlflow.DeleteWebhook\x1a\x1e.mlflow.DeleteWebhook.Response\"E\xf2\x86\x19\x41\n-\n\x06\x44\x45LETE\x12\x1d/mlflow/webhooks/{webhook_id}\x1a\x04\x08\x02\x10\x00\x10\x01*\x0e\x44\x65lete Webhook\x12\x88\x01\n\x0btestWebhook\x12\x13.mlflow.TestWebhook\x1a\x1c.mlflow.TestWebhook.Response\"F\xf2\x86\x19\x42\n0\n\x04POST\x12\"/mlflow/webhooks/{webhook_id}/test\x1a\x04\x08\x02\x10\x00\x10\x01*\x0cTest WebhookB!\n\x14org.mlflow.api.proto\x90\x01\x01\xa0\x01\x01\xe2?\x02\x10\x01')
mlflow/protos/webhooks_pb2.py:136:  DESCRIPTOR = _descriptor_pool.Default().AddSerializedFile(b'\n\x0ewebhooks.proto\x12\x06mlflow\x1a\x10\x64\x61tabricks.proto\x1a\x15scalapb/scalapb.proto\"h\n\x0cWebhookEvent\x12+\n\x06\x65ntity\x18\x01 \x01(\x0e\x32\x15.mlflow.WebhookEntityB\x04\xf8\x86\x19\x01\x12+\n\x06\x61\x63tion\x18\x02 \x01(\x0e\x32\x15.mlflow.WebhookActionB\x04\xf8\x86\x19\x01\"\xd6\x01\n\x07Webhook\x12\x12\n\nwebhook_id\x18\x01 \x01(\t\x12\x0c\n\x04name\x18\x02 \x01(\t\x12\x13\n\x0b\x64\x65scription\x18\x03 \x01(\t\x12\x0b\n\x03url\x18\x04 \x01(\t\x12$\n\x06\x65vents\x18\x05 \x03(\x0b\x32\x14.mlflow.WebhookEvent\x12%\n\x06status\x18\x06 \x01(\x0e\x32\x15.mlflow.WebhookStatus\x12\x1a\n\x12\x63reation_timestamp\x18\x07 \x01(\x03\x12\x1e\n\x16last_updated_timestamp\x18\x08 \x01(\x03\"k\n\x11WebhookTestResult\x12\x0f\n\x07success\x18\x01 \x01(\x08\x12\x17\n\x0fresponse_status\x18\x02 \x01(\x05\x12\x15\n\rresponse_body\x18\x03 \x01(\t\x12\x15\n\rerror_message\x18\x04 \x01(\t\"\x89\x02\n\rCreateWebhook\x12\x12\n\x04name\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x12\x13\n\x0b\x64\x65scription\x18\x02 \x01(\t\x12\x11\n\x03url\x18\x03 \x01(\tB\x04\xf8\x86\x19\x01\x12*\n\x06\x65vents\x18\x04 \x03(\x0b\x32\x14.mlflow.WebhookEventB\x04\xf8\x86\x19\x01\x12\x0e\n\x06secret\x18\x05 \x01(\t\x12%\n\x06status\x18\x06 \x01(\x0e\x32\x15.mlflow.WebhookStatus\x1a,\n\x08Response\x12 \n\x07webhook\x18\x01 \x01(\x0b\x32\x0f.mlflow.Webhook:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\xb1\x01\n\x0cListWebhooks\x12\x18\n\x0bmax_results\x18\x01 \x01(\x05:\x03\x31\x30\x30\x12\x12\n\npage_token\x18\x02 \x01(\t\x1a\x46\n\x08Response\x12!\n\x08webhooks\x18\x01 \x03(\x0b\x32\x0f.mlflow.Webhook\x12\x17\n\x0fnext_page_token\x18\x02 \x01(\t:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\x81\x01\n\nGetWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x1a,\n\x08Response\x12 \n\x07webhook\x18\x01 \x01(\x0b\x32\x0f.mlflow.Webhook:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\x91\x02\n\rUpdateWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x12\x0c\n\x04name\x18\x02 \x01(\t\x12\x13\n\x0b\x64\x65scription\x18\x03 \x01(\t\x12\x0b\n\x03url\x18\x04 \x01(\t\x12$\n\x06\x65vents\x18\x05 \x03(\x0b\x32\x14.mlflow.WebhookEvent\x12\x0e\n\x06secret\x18\x06 \x01(\t\x12%\n\x06status\x18\x07 \x01(\x0e\x32\x15.mlflow.WebhookStatus\x1a,\n\x08Response\x12 \n\x07webhook\x18\x01 \x01(\x0b\x32\x0f.mlflow.Webhook:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"b\n\rDeleteWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x1a\n\n\x08Response:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]\"\xb0\x01\n\x0bTestWebhook\x12\x18\n\nwebhook_id\x18\x01 \x01(\tB\x04\xf8\x86\x19\x01\x12#\n\x05\x65vent\x18\x02 \x01(\x0b\x32\x14.mlflow.WebhookEvent\x1a\x35\n\x08Response\x12)\n\x06result\x18\x01 \x01(\x0b\x32\x19.mlflow.WebhookTestResult:+\xe2?(\n&com.databricks.rpc.RPC[$this.Response]*)\n\rWebhookStatus\x12\n\n\x06\x41\x43TIVE\x10\x01\x12\x0c\n\x08\x44ISABLED\x10\x02*\xda\x01\n\rWebhookEntity\x12\x16\n\x12\x45NTITY_UNSPECIFIED\x10\x00\x12\x14\n\x10REGISTERED_MODEL\x10\x01\x12\x11\n\rMODEL_VERSION\x10\x02\x12\x15\n\x11MODEL_VERSION_TAG\x10\x03\x12\x17\n\x13MODEL_VERSION_ALIAS\x10\x04\x12\n\n\x06PROMPT\x10\x05\x12\x12\n\x0ePROMPT_VERSION\x10\x06\x12\x0e\n\nPROMPT_TAG\x10\x07\x12\x16\n\x12PROMPT_VERSION_TAG\x10\x08\x12\x10\n\x0cPROMPT_ALIAS\x10\t*W\n\rWebhookAction\x12\x16\n\x12\x41\x43TION_UNSPECIFIED\x10\x00\x12\x0b\n\x07\x43REATED\x10\x01\x12\x0b\n\x07UPDATED\x10\x02\x12\x0b\n\x07\x44\x45LETED\x10\x03\x12\x07\n\x03SET\x10\x04\x32\xb5\x06\n\x0eWebhookService\x12~\n\rcreateWebhook\x12\x15.mlflow.CreateWebhook\x1a\x1e.mlflow.CreateWebhook.Response\"6\xf2\x86\x19\x32\n\x1e\n\x04POST\x12\x10/mlflow/webhooks\x1a\x04\x08\x02\x10\x00\x10\x01*\x0e\x43reate Webhook\x12y\n\x0clistWebhooks\x12\x14.mlflow.ListWebhooks\x1a\x1d.mlflow.ListWebhooks.Response\"4\xf2\x86\x19\x30\n\x1d\n\x03GET\x12\x10/mlflow/webhooks\x1a\x04\x08\x02\x10\x00\x10\x01*\rList Webhooks\x12~\n\ngetWebhook\x12\x12.mlflow.GetWebhook\x1a\x1b.mlflow.GetWebhook.Response\"?\xf2\x86\x19;\n*\n\x03GET\x12\x1d/mlflow/webhooks/{webhook_id}\x1a\x04\x08\x02\x10\x00\x10\x01*\x0bGet Webhook\x12\x8c\x01\n\rupdateWebhook\x12\x15.mlflow.UpdateWebhook\x1a\x1e.mlflow.UpdateWebhook.Response\"D\xf2\x86\x19@\n,\n\x05PATCH\x12\x1d/mlflow/webhooks/{webhook_id}\x1a\x04\x08\x02\x10\x00\x10\x01*\x0eUpdate Webhook\x12\x8d\x01\n\rdeleteWebhook\x12\x15.mlflow.DeleteWebhook\x1a\x1e.mlflow.DeleteWebhook.Response\"E\xf2\x86\x19\x41\n-\n\x06\x44\x45LETE\x12\x1d/mlflow/webhooks/{webhook_id}\x1a\x04\x08\x02\x10\x00\x10\x01*\x0e\x44\x65lete Webhook\x12\x88\x01\n\x0btestWebhook\x12\x13.mlflow.TestWebhook\x1a\x1c.mlflow.TestWebhook.Response\"F\xf2\x86\x19\x42\n0\n\x04POST\x12\"/mlflow/webhooks/{webhook_id}/test\x1a\x04\x08\x02\x10\x00\x10\x01*\x0cTest WebhookB!\n\x14org.mlflow.api.proto\x90\x01\x01\xa0\x01\x01\xe2?\x02\x10\x01')
mlflow/protos/webhooks_pb2.py:138:  _WEBHOOKSTATUS = DESCRIPTOR.enum_types_by_name['WebhookStatus']
mlflow/protos/webhooks_pb2.py:139:  WebhookStatus = enum_type_wrapper.EnumTypeWrapper(_WEBHOOKSTATUS)
mlflow/entities/webhook.py:11:from mlflow.protos.webhooks_pb2 import WebhookStatus as ProtoWebhookStatus
mlflow/entities/webhook.py:15:class WebhookStatus(str, Enum):
mlflow/entities/webhook.py:24:        proto_name = ProtoWebhookStatus.Name(proto)
mlflow/entities/webhook.py:31:        return ProtoWebhookStatus.Value(self.value)
mlflow/entities/webhook.py:34:        return self == WebhookStatus.ACTIVE
mlflow/entities/webhook.py:37:class WebhookEntity(str, Enum):
mlflow/entities/webhook.py:62:class WebhookAction(str, Enum):
mlflow/entities/webhook.py:87:WebhookEventStr: TypeAlias = Literal[
mlflow/entities/webhook.py:141:class WebhookEvent:
mlflow/entities/webhook.py:203:    def from_str(cls, event_str: WebhookEventStr) -> Self:
mlflow/entities/webhook.py:250:class Webhook:
mlflow/entities/webhook.py:264:        status: str | WebhookStatus = WebhookStatus.ACTIVE,
mlflow/entities/webhook.py:289:        self._status = WebhookStatus(status) if isinstance(status, str) else status
mlflow/entities/webhook.py:315:    def status(self) -> WebhookStatus:
mlflow/entities/webhook.py:338:            status=WebhookStatus.from_proto(proto.status),
mlflow/entities/webhook.py:370:class WebhookTestResult:
mlflow/entities/__init__.py:62:    WebhookStatus,
mlflow/entities/__init__.py:126:    "WebhookStatus",
mlflow/store/model_registry/sqlalchemy_store.py:19:from mlflow.entities.webhook import Webhook, WebhookEvent, WebhookStatus
mlflow/store/model_registry/sqlalchemy_store.py:1316:    def create_webhook(
mlflow/store/model_registry/sqlalchemy_store.py:1323:        status: WebhookStatus | None = None,
mlflow/store/model_registry/sqlalchemy_store.py:1338:                status=(status or WebhookStatus.ACTIVE).value,
mlflow/store/model_registry/sqlalchemy_store.py:1350:    def get_webhook(self, webhook_id: str) -> Webhook:
mlflow/store/model_registry/sqlalchemy_store.py:1355:    def list_webhooks(
mlflow/store/model_registry/sqlalchemy_store.py:1389:    def list_webhooks_by_event(
mlflow/store/model_registry/sqlalchemy_store.py:1428:    def update_webhook(
mlflow/store/model_registry/sqlalchemy_store.py:1436:        status: WebhookStatus | None = None,
mlflow/store/model_registry/sqlalchemy_store.py:1475:    def delete_webhook(self, webhook_id: str) -> None:
mlflow/store/model_registry/abstract_store.py:16:from mlflow.entities.webhook import Webhook, WebhookEvent, WebhookStatus, WebhookTestResult
mlflow/store/model_registry/abstract_store.py:1055:    def create_webhook(
mlflow/store/model_registry/abstract_store.py:1062:        status: WebhookStatus | None = None,
mlflow/store/model_registry/abstract_store.py:1081:    def get_webhook(self, webhook_id: str) -> Webhook:
mlflow/store/model_registry/abstract_store.py:1093:    def list_webhooks(
mlflow/store/model_registry/abstract_store.py:1110:    def list_webhooks_by_event(
mlflow/store/model_registry/abstract_store.py:1132:    def update_webhook(
mlflow/store/model_registry/abstract_store.py:1140:        status: WebhookStatus | None = None,
mlflow/store/model_registry/abstract_store.py:1159:    def delete_webhook(self, webhook_id: str) -> None:
mlflow/store/model_registry/rest_store.py:4:from mlflow.entities.webhook import Webhook, WebhookEvent, WebhookStatus, WebhookTestResult
mlflow/store/model_registry/rest_store.py:510:    def create_webhook(
mlflow/store/model_registry/rest_store.py:517:        status: WebhookStatus | None = None,
mlflow/store/model_registry/rest_store.py:532:    def get_webhook(self, webhook_id: str) -> Webhook:
mlflow/store/model_registry/rest_store.py:536:    def list_webhooks(
mlflow/store/model_registry/rest_store.py:546:    def update_webhook(
mlflow/store/model_registry/rest_store.py:554:        status: WebhookStatus | None = None,
mlflow/store/model_registry/rest_store.py:569:    def delete_webhook(self, webhook_id: str) -> None:
mlflow/store/model_registry/dbmodels/models.py:30:    WebhookStatus,
mlflow/store/model_registry/dbmodels/models.py:281:            status=WebhookStatus(self.status),
tests/webhooks/test_e2e.py:23:class WebhookLogEntry:
tests/entities/test_webhook.py:8:    WebhookStatus,
tests/entities/test_webhook.py:14:from mlflow.protos.webhooks_pb2 import WebhookStatus as ProtoWebhookStatus
tests/entities/test_webhook.py:20:        (ProtoWebhookStatus.ACTIVE, WebhookStatus.ACTIVE),
tests/entities/test_webhook.py:21:        (ProtoWebhookStatus.DISABLED, WebhookStatus.DISABLED),
tests/entities/test_webhook.py:25:    assert WebhookStatus.from_proto(proto_status) == status_enum
tests/entities/test_webhook.py:129:        status=WebhookStatus.ACTIVE,
tests/entities/test_webhook.py:156:        status=WebhookStatus.ACTIVE,
tests/store/model_registry/test_rest_store_webhooks.py:12:from mlflow.entities.webhook import WebhookAction, WebhookEntity, WebhookEvent, WebhookStatus
tests/store/model_registry/test_rest_store_webhooks.py:154:        status=WebhookStatus.DISABLED,
tests/store/model_registry/test_rest_store_webhooks.py:161:    assert updated_webhook.status == WebhookStatus.DISABLED
tests/store/model_registry/test_sqlalchemy_store.py:16:from mlflow.entities.webhook import WebhookAction, WebhookEntity, WebhookEvent, WebhookStatus
tests/store/model_registry/test_sqlalchemy_store.py:1976:        status=WebhookStatus.ACTIVE,
tests/store/model_registry/test_sqlalchemy_store.py:1983:    assert webhook.status == WebhookStatus.ACTIVE
tests/store/model_registry/test_sqlalchemy_store.py:2171:        status=WebhookStatus.DISABLED,
tests/store/model_registry/test_sqlalchemy_store.py:2179:    assert updated_webhook.status == WebhookStatus.DISABLED
tests/store/model_registry/test_sqlalchemy_store.py:2287:        status=WebhookStatus.ACTIVE,
tests/store/model_registry/test_sqlalchemy_store.py:2289:    assert webhook.status == WebhookStatus.ACTIVE
tests/store/model_registry/test_sqlalchemy_store.py:2293:        webhook_id=webhook.webhook_id, status=WebhookStatus.DISABLED
tests/store/model_registry/test_sqlalchemy_store.py:2295:    assert updated_webhook.status == WebhookStatus.DISABLED
tests/store/model_registry/test_sqlalchemy_store.py:2299:        webhook_id=webhook.webhook_id, status=WebhookStatus.ACTIVE
tests/store/model_registry/test_sqlalchemy_store.py:2301:    assert updated_webhook.status == WebhookStatus.ACTIVE
```

## 原始行 13 · command_execution

命令：
```
/bin/bash -lc "sed -n '820,940p' mlflow/tracking/_model_registry/client.py && sed -n '480,590p' mlflow/store/model_registry/rest_store.py"
```

退出码：`0`

输出：
```













































































    @experimental(version="3.3.0")
    def test_webhook(
        self, webhook_id: str, event: WebhookEventStr | WebhookEvent | None = None
    ) -> WebhookTestResult:
        """
        Test a webhook by sending a test payload.

        Args:
            webhook_id: The ID of the webhook to test.
            event: Optional event type to test. Can be a WebhookEvent object or a string in
                "entity.action" format (e.g., "model_version.created"). If not specified, uses
                the first event from webhook.

        Returns:
            A :py:class:`mlflow.entities.webhook.WebhookTestResult` indicating success/failure and
            response details.
        """
        # Convert string to WebhookEvent if needed
        if isinstance(event, str):
            event = WebhookEvent.from_str(event)
        return self.store.test_webhook(webhook_id, event)    def delete_registered_model_alias(self, name, alias):
        """
        Delete an alias associated with a registered model.

        Args:
            name: Registered model name.
            alias: Name of the alias.

        Returns:
            None
        """
        req_body = message_to_json(DeleteRegisteredModelAlias(name=name, alias=alias))
        self._call_endpoint(DeleteRegisteredModelAlias, req_body)

    def get_model_version_by_alias(self, name, alias):
        """
        Get the model version instance by name and alias.

        Args:
            name: Registered model name.
            alias: Name of the alias.

        Returns:
            A single :py:class:`mlflow.entities.model_registry.ModelVersion` object.
        """
        req_body = message_to_json(GetModelVersionByAlias(name=name, alias=alias))
        response_proto = self._call_endpoint(GetModelVersionByAlias, req_body)
        return ModelVersion.from_proto(response_proto.model_version)

    # Webhook APIs
    def create_webhook(
        self,
        name: str,
        url: str,
        events: list[WebhookEvent],
        description: str | None = None,
        secret: str | None = None,
        status: WebhookStatus | None = None,
    ) -> Webhook:
        req_body = message_to_json(
            CreateWebhook(
                name=name,
                url=url,
                events=[e.to_proto() for e in events],
                description=description,
                secret=secret,
                status=status.to_proto() if status else None,
            )
        )
        response_proto = self._call_webhook_endpoint(CreateWebhook, req_body)
        return Webhook.from_proto(response_proto.webhook)

    def get_webhook(self, webhook_id: str) -> Webhook:
        response_proto = self._call_webhook_endpoint(GetWebhook, webhook_id=webhook_id)
        return Webhook.from_proto(response_proto.webhook)

    def list_webhooks(
        self,
        max_results: int | None = None,
        page_token: str | None = None,
    ) -> PagedList[Webhook]:
        req_body = message_to_json(ListWebhooks(max_results=max_results, page_token=page_token))
        response_proto = self._call_webhook_endpoint(ListWebhooks, req_body)
        webhooks = [Webhook.from_proto(webhook) for webhook in response_proto.webhooks]
        return PagedList(webhooks, response_proto.next_page_token)

    def update_webhook(
        self,
        webhook_id: str,
        name: str | None = None,
        description: str | None = None,
        url: str | None = None,
        events: list[WebhookEvent] | None = None,
        secret: str | None = None,
        status: WebhookStatus | None = None,
    ) -> Webhook:
        req_body = message_to_json(
            UpdateWebhook(
                name=name,
                description=description,
                url=url,
                events=[e.to_proto() for e in events] if events else None,
                secret=secret,
                status=status.to_proto() if status else None,
            )
        )
        response_proto = self._call_webhook_endpoint(UpdateWebhook, req_body, webhook_id=webhook_id)
        return Webhook.from_proto(response_proto.webhook)

    def delete_webhook(self, webhook_id: str) -> None:
        self._call_webhook_endpoint(DeleteWebhook, webhook_id=webhook_id)

    def test_webhook(self, webhook_id: str, event: WebhookEvent | None = None) -> WebhookTestResult:
        """
        Test the webhook by sending a test event to the specified URL.

        Args:
            webhook_id: The ID of the webhook to test.
            event: Optional event type to test. If not specified, uses the first event from webhook.

        Returns:
            WebhookTestResult indicating success/failure and response details
        """
        req_body = message_to_json(TestWebhook(event=event.to_proto() if event else None))
        response_proto = self._call_webhook_endpoint(TestWebhook, req_body, webhook_id=webhook_id)
        return WebhookTestResult.from_proto(response_proto.result)
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "sed -n '6100,6510p' mlflow/tracking/client.py"
```

退出码：`0`

输出：
```

    @experimental(version="3.4.0")
    @_disable_in_databricks()
    def get_dataset(self, dataset_id: str) -> EvaluationDataset:
        """
        Get a dataset by ID.

        Args:
            dataset_id: The ID of the dataset to retrieve.

        Returns:
            The EvaluationDataset object.

        .. code-block:: python

            from mlflow import MlflowClient

            client = MlflowClient()

            # Get a dataset by ID (assuming it exists)
            dataset = client.get_dataset("dataset_123")

            # Access records (lazy loaded)
            df = dataset.to_df()
        """
        return self._tracking_client.get_dataset(dataset_id)

    @experimental(version="3.4.0")
    @_disable_in_databricks()
    def delete_dataset(self, dataset_id: str) -> None:
        """
        Delete a dataset and all its records.

        Args:
            dataset_id: The ID of the dataset to delete.

        .. code-block:: python

            from mlflow import MlflowClient

            client = MlflowClient()

            # Delete a dataset
            client.delete_dataset("dataset_123")
        """
        self._tracking_client.delete_dataset(dataset_id)

    @experimental(version="3.4.0")
    @_disable_in_databricks(use_uc_message=True)
    def search_datasets(
        self,
        experiment_ids: list[str] | None = None,
        filter_string: str | None = None,
        max_results: int = SEARCH_EVALUATION_DATASETS_MAX_RESULTS,
        order_by: list[str] | None = None,
        page_token: str | None = None,
    ) -> PagedList[EvaluationDataset]:
        """
        Search for datasets.

        Args:
            experiment_ids: List of experiment IDs to filter by.
            filter_string: A filter string to apply to the search.
            max_results: Maximum number of results to return. Defaults to 50.
            order_by: List of columns to order by.
            page_token: Token for the next page of results.

        Returns:
            A PagedList of EvaluationDataset objects.

        .. code-block:: python

            from mlflow import MlflowClient

            client = MlflowClient()

            # Search for datasets in specific experiments
            datasets = client.search_datasets(
                experiment_ids=["exp1", "exp2"], filter_string="name LIKE 'qa_%'", max_results=10
            )

            # Get next page if available
            if datasets.token:
                next_page = client.search_datasets(
                    experiment_ids=["exp1", "exp2"], page_token=datasets.token
                )
        """
        return self._tracking_client.search_datasets(
            experiment_ids=experiment_ids,
            filter_string=filter_string,
            max_results=max_results,
            order_by=order_by,
            page_token=page_token,
        )

    @experimental(version="3.4.0")
    @_disable_in_databricks(use_uc_message=True)
    def set_dataset_tags(self, dataset_id: str, tags: dict[str, Any]) -> None:
        """
        Set tags for a dataset.

        This implements an upsert operation - existing tags are merged with new tags.
        To remove a tag, set its value to None.

        Args:
            dataset_id: The ID of the dataset to update.
            tags: Dictionary of tags to update. Setting a value to None removes the tag.

        .. code-block:: python

            from mlflow import MlflowClient

            client = MlflowClient()

            # Set tags for a dataset
            client.set_dataset_tags(
                dataset_id="dataset123",
                tags={
                    "environment": "production",
                    "version": "2.0",
                    "deprecated": None,  # This removes the 'deprecated' tag
                },
            )
        """
        self._tracking_client.set_dataset_tags(dataset_id=dataset_id, tags=tags)

    @experimental(version="3.4.0")
    @_disable_in_databricks(use_uc_message=True)
    def delete_dataset_tag(self, dataset_id: str, key: str) -> None:
        """
        Delete a tag from a dataset.

        Args:
            dataset_id: The ID of the dataset.
            key: The tag key to delete.

        .. code-block:: python

            from mlflow import MlflowClient

            client = MlflowClient()

            # Delete a tag
            client.delete_dataset_tag(dataset_id="dataset123", key="deprecated")
        """
        self._tracking_client.delete_dataset_tag(dataset_id=dataset_id, key=key)

    @experimental(version="3.4.0")
    @_disable_in_databricks()
    def add_dataset_to_experiments(
        self, dataset_id: str, experiment_ids: list[str]
    ) -> EvaluationDataset:
        """
        Add a dataset to additional experiments.

        This allows reusing datasets across multiple experiments for evaluation purposes.

        Args:
            dataset_id: The ID of the dataset to update.
            experiment_ids: List of experiment IDs to associate with the dataset.

        Returns:
            The updated EvaluationDataset with new experiment associations.

        .. code-block:: python

            from mlflow import MlflowClient

            client = MlflowClient()

            # Add dataset to new experiments
            dataset = client.add_dataset_to_experiments(
                dataset_id="d-abc123", experiment_ids=["1", "2", "3"]
            )
            print(f"Dataset now associated with {len(dataset.experiment_ids)} experiments")
        """
        return self._tracking_client.add_dataset_to_experiments(dataset_id, experiment_ids)

    @experimental(version="3.4.0")
    @_disable_in_databricks()
    def remove_dataset_from_experiments(
        self, dataset_id: str, experiment_ids: list[str]
    ) -> EvaluationDataset:
        """
        Remove a dataset from experiments.

        This operation is idempotent - removing non-existent associations will not raise errors.

        Args:
            dataset_id: The ID of the dataset to update.
            experiment_ids: List of experiment IDs to remove association from.

        Returns:
            The updated EvaluationDataset with removed experiment associations.

        .. code-block:: python

            from mlflow import MlflowClient

            client = MlflowClient()

            # Remove dataset from experiments
            dataset = client.remove_dataset_from_experiments(
                dataset_id="d-abc123", experiment_ids=["2", "3"]
            )
            print(f"Dataset now associated with {len(dataset.experiment_ids)} experiments")
        """
        return self._tracking_client.remove_dataset_from_experiments(dataset_id, experiment_ids)

    # Webhook APIs






























































































































    @experimental(version="3.3.0")
    def test_webhook(
        self, webhook_id: str, event: WebhookEventStr | WebhookEvent | None = None
    ) -> WebhookTestResult:
        """
        Test a webhook by sending a test payload.

        Args:
            webhook_id: Webhook ID to test.
            event: Optional event type to test. Can be a WebhookEvent object or a string in
                "entity.action" format (e.g., "model_version.created"). If not specified, uses
                the first event from webhook.

        Returns:
            WebhookTestResult indicating success/failure and response details.
        """
        return self._get_registry_client().test_webhook(webhook_id, event)
```

## 原始行 17 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,390p' mlflow/entities/webhook.py"
```

退出码：`0`

输出：
```
from enum import Enum
from typing import Literal, TypeAlias

from typing_extensions import Self

from mlflow.exceptions import MlflowException
from mlflow.protos.webhooks_pb2 import Webhook as ProtoWebhook
from mlflow.protos.webhooks_pb2 import WebhookAction as ProtoWebhookAction
from mlflow.protos.webhooks_pb2 import WebhookEntity as ProtoWebhookEntity
from mlflow.protos.webhooks_pb2 import WebhookEvent as ProtoWebhookEvent
from mlflow.protos.webhooks_pb2 import WebhookStatus as ProtoWebhookStatus
from mlflow.protos.webhooks_pb2 import WebhookTestResult as ProtoWebhookTestResult


class WebhookStatus(str, Enum):
    ACTIVE = "ACTIVE"
    DISABLED = "DISABLED"

    def __str__(self) -> str:
        return self.value

    @classmethod
    def from_proto(cls, proto: int) -> Self:
        proto_name = ProtoWebhookStatus.Name(proto)
        try:
            return cls(proto_name)
        except ValueError:
            raise ValueError(f"Unknown proto status: {proto_name}")

    def to_proto(self) -> int:
        return ProtoWebhookStatus.Value(self.value)

    def is_active(self) -> bool:
        return self == WebhookStatus.ACTIVE


class WebhookEntity(str, Enum):
    REGISTERED_MODEL = "registered_model"
    MODEL_VERSION = "model_version"
    MODEL_VERSION_TAG = "model_version_tag"
    MODEL_VERSION_ALIAS = "model_version_alias"
    PROMPT = "prompt"
    PROMPT_VERSION = "prompt_version"
    PROMPT_TAG = "prompt_tag"
    PROMPT_VERSION_TAG = "prompt_version_tag"
    PROMPT_ALIAS = "prompt_alias"

    def __str__(self) -> str:
        return self.value

    @classmethod
    def from_proto(cls, proto: int) -> Self:
        proto_name = ProtoWebhookEntity.Name(proto)
        entity_value = proto_name.lower()
        return cls(entity_value)

    def to_proto(self) -> int:
        proto_name = self.value.upper()
        return ProtoWebhookEntity.Value(proto_name)


class WebhookAction(str, Enum):
    CREATED = "created"
    UPDATED = "updated"
    DELETED = "deleted"
    SET = "set"

    def __str__(self) -> str:
        return self.value

    @classmethod
    def from_proto(cls, proto: int) -> Self:
        proto_name = ProtoWebhookAction.Name(proto)
        # Convert UPPER_CASE to lowercase
        action_value = proto_name.lower()
        try:
            return cls(action_value)
        except ValueError:
            raise ValueError(f"Unknown proto action: {proto_name}")

    def to_proto(self) -> int:
        # Convert lowercase to UPPER_CASE
        proto_name = self.value.upper()
        return ProtoWebhookAction.Value(proto_name)


WebhookEventStr: TypeAlias = Literal[
    "registered_model.created",
    "model_version.created",
    "model_version_tag.set",
    "model_version_tag.deleted",
    "model_version_alias.created",
    "model_version_alias.deleted",
    "prompt.created",
    "prompt_version.created",
    "prompt_tag.set",
    "prompt_tag.deleted",
    "prompt_version_tag.set",
    "prompt_version_tag.deleted",
    "prompt_alias.created",
    "prompt_alias.deleted",
]

# Valid actions for each entity type
VALID_ENTITY_ACTIONS: dict[WebhookEntity, set[WebhookAction]] = {
    WebhookEntity.REGISTERED_MODEL: {
        WebhookAction.CREATED,
    },
    WebhookEntity.MODEL_VERSION: {
        WebhookAction.CREATED,
    },
    WebhookEntity.MODEL_VERSION_TAG: {
        WebhookAction.SET,
        WebhookAction.DELETED,
    },
    WebhookEntity.MODEL_VERSION_ALIAS: {
        WebhookAction.CREATED,
        WebhookAction.DELETED,
    },
    WebhookEntity.PROMPT: {
        WebhookAction.CREATED,
    },
    WebhookEntity.PROMPT_VERSION: {
        WebhookAction.CREATED,
    },
    WebhookEntity.PROMPT_TAG: {
        WebhookAction.SET,
        WebhookAction.DELETED,
    },
    WebhookEntity.PROMPT_VERSION_TAG: {
        WebhookAction.SET,
        WebhookAction.DELETED,
    },
    WebhookEntity.PROMPT_ALIAS: {
        WebhookAction.CREATED,
        WebhookAction.DELETED,
    },
}


class WebhookEvent:
    """
    Represents a webhook event with a resource and action.
    """

    def __init__(
        self,
        entity: str | WebhookEntity,
        action: str | WebhookAction,
    ):
        """
        Initialize a WebhookEvent.

        Args:
            entity: The entity type (string or WebhookEntity enum)
            action: The action type (string or WebhookAction enum)

        Raises:
            MlflowException: If the entity/action combination is invalid
        """
        self._entity = WebhookEntity(entity) if isinstance(entity, str) else entity
        self._action = WebhookAction(action) if isinstance(action, str) else action

        # Validate entity/action combination
        if not self._is_valid_combination(self._entity, self._action):
            valid_actions = VALID_ENTITY_ACTIONS.get(self._entity, set())
            raise MlflowException.invalid_parameter_value(
                f"Invalid action '{self._action}' for entity '{self._entity}'. "
                f"Valid actions are: {sorted([a.value for a in valid_actions])}"
            )

    @property
    def entity(self) -> WebhookEntity:
        return self._entity

    @property
    def action(self) -> WebhookAction:
        return self._action

    @staticmethod
    def _is_valid_combination(entity: WebhookEntity, action: WebhookAction) -> bool:
        """
        Check if an entity/action combination is valid.

        Args:
            entity: The webhook entity
            action: The webhook action

        Returns:
            True if the combination is valid, False otherwise
        """
        valid_actions = VALID_ENTITY_ACTIONS.get(entity, set())
        return action in valid_actions

    @classmethod
    def from_proto(cls, proto: ProtoWebhookEvent) -> Self:
        return cls(
            entity=WebhookEntity.from_proto(proto.entity),
            action=WebhookAction.from_proto(proto.action),
        )

    @classmethod
    def from_str(cls, event_str: WebhookEventStr) -> Self:
        """
        Create a WebhookEvent from a dot-separated string representation.

        Args:
            event_str: Valid webhook event string (e.g., "registered_model.created")

        Returns:
            A WebhookEvent instance
        """
        match event_str.split("."):
            case [entity_str, action_str]:
                try:
                    entity = WebhookEntity(entity_str)
                    action = WebhookAction(action_str)
                    return cls(entity=entity, action=action)
                except ValueError as e:
                    raise MlflowException.invalid_parameter_value(
                        f"Invalid entity or action in event string: {event_str}. Error: {e}"
                    )
            case _:
                raise MlflowException.invalid_parameter_value(
                    f"Invalid event string format: {event_str}. "
                    "Expected format: 'entity.action' (e.g., 'registered_model.created')"
                )

    def to_proto(self) -> ProtoWebhookEvent:
        event = ProtoWebhookEvent()
        event.entity = self.entity.to_proto()
        event.action = self.action.to_proto()
        return event

    def __str__(self) -> str:
        return f"{self.entity.value}.{self.action.value}"






    def __hash__(self) -> int:
        return hash((self.entity, self.action))

    def __repr__(self) -> str:
        return f"WebhookEvent(entity={self.entity}, action={self.action})"


class Webhook:
    """
    MLflow entity for Webhook.
    """

    def __init__(
        self,
        webhook_id: str,
        name: str,
        url: str,
        events: list[WebhookEvent],
        creation_timestamp: int,
        last_updated_timestamp: int,
        description: str | None = None,
        status: str | WebhookStatus = WebhookStatus.ACTIVE,
        secret: str | None = None,
    ):
        """
        Initialize a Webhook entity.

        Args:
            webhook_id: Unique webhook identifier
            name: Human-readable webhook name
            url: Webhook endpoint URL
            events: List of WebhookEvent objects that trigger this webhook
            creation_timestamp: Creation timestamp in milliseconds since Unix epoch
            last_updated_timestamp: Last update timestamp in milliseconds since Unix epoch
            description: Optional webhook description
            status: Webhook status (ACTIVE or DISABLED)
            secret: Optional secret key for HMAC signature verification
        """
        super().__init__()
        self._webhook_id = webhook_id
        self._name = name
        self._url = url
        if not events:
            raise MlflowException.invalid_parameter_value("Webhook events cannot be empty")
        self._events = events
        self._description = description
        self._status = WebhookStatus(status) if isinstance(status, str) else status
        self._secret = secret
        self._creation_timestamp = creation_timestamp
        self._last_updated_timestamp = last_updated_timestamp

    @property
    def webhook_id(self) -> str:
        return self._webhook_id

    @property
    def name(self) -> str:
        return self._name

    @property
    def url(self) -> str:
        return self._url

    @property
    def events(self) -> list[WebhookEvent]:
        return self._events

    @property
    def description(self) -> str | None:
        return self._description

    @property
    def status(self) -> WebhookStatus:
        return self._status





    @property
    def creation_timestamp(self) -> int:
        return self._creation_timestamp

    @property
    def last_updated_timestamp(self) -> int:
        return self._last_updated_timestamp

    @classmethod
    def from_proto(cls, proto: ProtoWebhook) -> Self:
        return cls(
            webhook_id=proto.webhook_id,
            name=proto.name,
            url=proto.url,
            events=[WebhookEvent.from_proto(e) for e in proto.events],
            description=proto.description or None,
            status=WebhookStatus.from_proto(proto.status),
            creation_timestamp=proto.creation_timestamp,
            last_updated_timestamp=proto.last_updated_timestamp,
        )

    def to_proto(self):
        webhook = ProtoWebhook()
        webhook.webhook_id = self.webhook_id
        webhook.name = self.name
        webhook.url = self.url
        webhook.events.extend([event.to_proto() for event in self.events])
        if self.description:
            webhook.description = self.description
        webhook.status = self.status.to_proto()
        webhook.creation_timestamp = self.creation_timestamp
        webhook.last_updated_timestamp = self.last_updated_timestamp
        return webhook

    def __repr__(self) -> str:
        return (
            f"Webhook("
            f"webhook_id='{self.webhook_id}', "
            f"name='{self.name}', "
            f"url='{self.url}', "
            f"status='{self.status}', "
            f"events={self.events}, "
            f"creation_timestamp={self.creation_timestamp}, "
            f"last_updated_timestamp={self.last_updated_timestamp}"
            f")"
        )


class WebhookTestResult:
    """
    MLflow entity for WebhookTestResult.
    """

    def __init__(
        self,
        success: bool,
        response_status: int | None = None,
        response_body: str | None = None,
        error_message: str | None = None,
    ):
        """
        Initialize a WebhookTestResult entity.

        Args:
            success: Whether the test succeeded
            response_status: HTTP response status code if available
            response_body: Response body if available
            error_message: Error message if test failed
        """
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "git status --short && find tests -type f -iname '*webhook*' -print"
```

退出码：`0`

输出：
```
tests/entities/test_webhook.py
tests/store/model_registry/test_rest_store_webhooks.py
```

## 原始行 22 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/tracking/_model_registry/client.py | sed -n '1,45p;760,930p'"
```

退出码：`0`

输出：
```
     1	"""
     2	Internal package providing a Python CRUD interface to MLflow models and versions.
     3	This is a lower level API than the :py:mod:`mlflow.tracking.fluent` module, and is
     4	exposed in the :py:mod:`mlflow.tracking` module.
     5	"""
     6	
     7	import logging
     8	from typing import Any
     9	
    10	from pydantic import BaseModel
    11	
    12	from mlflow.entities.model_registry import (
    13	    ModelVersionTag,
    14	    Prompt,
    15	    PromptVersion,
    16	    RegisteredModelTag,
    17	)
    18	from mlflow.entities.model_registry.prompt import Prompt
    19	from mlflow.entities.webhook import (
    20	    Webhook,
    21	    WebhookEvent,
    22	    WebhookEventStr,
    23	    WebhookStatus,
    24	    WebhookTestResult,
    25	)
    26	from mlflow.exceptions import MlflowException
    27	from mlflow.prompt.registry_utils import (
    28	    add_prompt_filter_string,
    29	    is_prompt_supported_registry,
    30	)
    31	from mlflow.store.entities.paged_list import PagedList
    32	from mlflow.store.model_registry import (
    33	    SEARCH_MODEL_VERSION_MAX_RESULTS_DEFAULT,
    34	    SEARCH_REGISTERED_MODEL_MAX_RESULTS_DEFAULT,
    35	)
    36	from mlflow.telemetry.events import (
    37	    CreateModelVersionEvent,
    38	    CreatePromptEvent,
    39	    CreateRegisteredModelEvent,
    40	    CreateWebhookEvent,
    41	)
    42	from mlflow.telemetry.track import record_usage_event
    43	from mlflow.tracking._model_registry import DEFAULT_AWAIT_MAX_SLEEP_SECONDS, utils
    44	from mlflow.utils.annotations import experimental
    45	from mlflow.utils.arguments_utils import _get_arg_names
   760	        return self.store.link_prompts_to_trace(prompt_versions=prompt_versions, trace_id=trace_id)
   761	
   762	    def set_prompt_version_tag(self, name: str, version: str, key: str, value: str) -> None:
   763	        """
   764	        Set a tag on a prompt version.
   765	
   766	        This method delegates directly to the store, providing full Unity Catalog support
   767	        when used with Unity Catalog registries.
   768	
   769	        Args:
   770	            name: Name of the prompt.
   771	            version: Version number of the prompt.
   772	            key: Tag key.
   773	            value: Tag value.
   774	
   775	        Returns:
   776	            None
   777	        """
   778	        self.store.set_prompt_version_tag(name, version, key, value)
   779	
   780	    def delete_prompt_version_tag(self, name: str, version: str, key: str) -> None:
   781	        """
   782	        Delete a tag from a prompt version.
   783	
   784	        This method delegates directly to the store, providing full Unity Catalog support
   785	        when used with Unity Catalog registries.
   786	
   787	        Args:
   788	            name: Name of the prompt.
   789	            version: Version number of the prompt.
   790	            key: Tag key to delete.
   791	
   792	        Returns:
   793	            None
   794	        """
   795	        self.store.delete_prompt_version_tag(name, version, key)
   796	
   797	    # Webhook APIs
   798	
   799	
   800	
   801	
   802	
   803	
   804	
   805	
   806	
   807	
   808	
   809	
   810	
   811	
   812	
   813	
   814	
   815	
   816	
   817	
   818	
   819	
   820	
   821	
   822	
   823	
   824	
   825	
   826	
   827	
   828	
   829	
   830	
   831	
   832	
   833	
   834	
   835	
   836	
   837	
   838	
   839	
   840	
   841	
   842	
   843	
   844	
   845	
   846	
   847	
   848	
   849	
   850	
   851	
   852	
   853	
   854	
   855	
   856	
   857	
   858	
   859	
   860	
   861	
   862	
   863	
   864	
   865	
   866	
   867	
   868	
   869	
   870	
   871	
   872	
   873	
   874	
   875	
   876	
   877	
   878	
   879	
   880	
   881	
   882	
   883	
   884	
   885	
   886	
   887	
   888	
   889	
   890	
   891	
   892	
   893	
   894	
   895	
   896	
   897	    @experimental(version="3.3.0")
   898	    def test_webhook(
   899	        self, webhook_id: str, event: WebhookEventStr | WebhookEvent | None = None
   900	    ) -> WebhookTestResult:
   901	        """
   902	        Test a webhook by sending a test payload.
   903	
   904	        Args:
   905	            webhook_id: The ID of the webhook to test.
   906	            event: Optional event type to test. Can be a WebhookEvent object or a string in
   907	                "entity.action" format (e.g., "model_version.created"). If not specified, uses
   908	                the first event from webhook.
   909	
   910	        Returns:
   911	            A :py:class:`mlflow.entities.webhook.WebhookTestResult` indicating success/failure and
   912	            response details.
   913	        """
   914	        # Convert string to WebhookEvent if needed
   915	        if isinstance(event, str):
   916	            event = WebhookEvent.from_str(event)
   917	        return self.store.test_webhook(webhook_id, event)
```

## 原始行 24 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/tracking/client.py | sed -n '1,90p;6280,6470p'"
```

退出码：`0`

输出：
```
     1	"""
     2	Internal package providing a Python CRUD interface to MLflow experiments, runs, registered models,
     3	and model versions. This is a lower level API than the :py:mod:`mlflow.tracking.fluent` module,
     4	and is exposed in the :py:mod:`mlflow.tracking` module.
     5	"""
     6	
     7	import contextlib
     8	import functools
     9	import json
    10	import logging
    11	import os
    12	import posixpath
    13	import random
    14	import re
    15	import string
    16	import sys
    17	import tempfile
    18	import urllib
    19	import uuid
    20	import warnings
    21	from typing import TYPE_CHECKING, Any, Literal, Sequence, Union
    22	
    23	import yaml
    24	from pydantic import BaseModel
    25	
    26	import mlflow
    27	from mlflow.entities import (
    28	    DatasetInput,
    29	    EvaluationDataset,
    30	    Experiment,
    31	    FileInfo,
    32	    LoggedModel,
    33	    LoggedModelInput,
    34	    LoggedModelOutput,
    35	    LoggedModelStatus,
    36	    Metric,
    37	    Param,
    38	    Run,
    39	    RunTag,
    40	    Span,
    41	    SpanStatus,
    42	    SpanType,
    43	    Trace,
    44	    ViewType,
    45	)
    46	from mlflow.entities.model_registry import ModelVersion, Prompt, PromptVersion, RegisteredModel
    47	from mlflow.entities.model_registry.model_version_stages import ALL_STAGES
    48	from mlflow.entities.span import NO_OP_SPAN_TRACE_ID, NoOpSpan
    49	from mlflow.entities.trace_status import TraceStatus
    50	from mlflow.entities.webhook import (
    51	    Webhook,
    52	    WebhookEvent,
    53	    WebhookEventStr,
    54	    WebhookStatus,
    55	    WebhookTestResult,
    56	)
    57	from mlflow.environment_variables import MLFLOW_ENABLE_ASYNC_LOGGING
    58	from mlflow.exceptions import MlflowException
    59	from mlflow.prompt.constants import (
    60	    IS_PROMPT_TAG_KEY,
    61	    PROMPT_ASSOCIATED_RUN_IDS_TAG_KEY,
    62	    PROMPT_TEXT_TAG_KEY,
    63	    PROMPT_TYPE_CHAT,
    64	    PROMPT_TYPE_TAG_KEY,
    65	    PROMPT_TYPE_TEXT,
    66	    RESPONSE_FORMAT_TAG_KEY,
    67	)
    68	from mlflow.prompt.registry_utils import (
    69	    has_prompt_tag,
    70	    model_version_to_prompt_version,
    71	    parse_prompt_name_or_uri,
    72	    require_prompt_registry,
    73	    translate_prompt_exception,
    74	    validate_prompt_name,
    75	)
    76	from mlflow.protos.databricks_pb2 import (
    77	    BAD_REQUEST,
    78	    FEATURE_DISABLED,
    79	    INVALID_PARAMETER_VALUE,
    80	    NOT_FOUND,
    81	    RESOURCE_DOES_NOT_EXIST,
    82	    ErrorCode,
    83	)
    84	from mlflow.store.artifact.utils.models import (
    85	    _parse_model_uri,
    86	    get_model_name_and_version,
    87	)
    88	from mlflow.store.entities.paged_list import PagedList
    89	from mlflow.store.model_registry import (
    90	    SEARCH_MODEL_VERSION_MAX_RESULTS_DEFAULT,
  6280	    def remove_dataset_from_experiments(
  6281	        self, dataset_id: str, experiment_ids: list[str]
  6282	    ) -> EvaluationDataset:
  6283	        """
  6284	        Remove a dataset from experiments.
  6285	
  6286	        This operation is idempotent - removing non-existent associations will not raise errors.
  6287	
  6288	        Args:
  6289	            dataset_id: The ID of the dataset to update.
  6290	            experiment_ids: List of experiment IDs to remove association from.
  6291	
  6292	        Returns:
  6293	            The updated EvaluationDataset with removed experiment associations.
  6294	
  6295	        .. code-block:: python
  6296	
  6297	            from mlflow import MlflowClient
  6298	
  6299	            client = MlflowClient()
  6300	
  6301	            # Remove dataset from experiments
  6302	            dataset = client.remove_dataset_from_experiments(
  6303	                dataset_id="d-abc123", experiment_ids=["2", "3"]
  6304	            )
  6305	            print(f"Dataset now associated with {len(dataset.experiment_ids)} experiments")
  6306	        """
  6307	        return self._tracking_client.remove_dataset_from_experiments(dataset_id, experiment_ids)
  6308	
  6309	    # Webhook APIs
  6310	
  6311	
  6312	
  6313	
  6314	
  6315	
  6316	
  6317	
  6318	
  6319	
  6320	
  6321	
  6322	
  6323	
  6324	
  6325	
  6326	
  6327	
  6328	
  6329	
  6330	
  6331	
  6332	
  6333	
  6334	
  6335	
  6336	
  6337	
  6338	
  6339	
  6340	
  6341	
  6342	
  6343	
  6344	
  6345	
  6346	
  6347	
  6348	
  6349	
  6350	
  6351	
  6352	
  6353	
  6354	
  6355	
  6356	
  6357	
  6358	
  6359	
  6360	
  6361	
  6362	
  6363	
  6364	
  6365	
  6366	
  6367	
  6368	
  6369	
  6370	
  6371	
  6372	
  6373	
  6374	
  6375	
  6376	
  6377	
  6378	
  6379	
  6380	
  6381	
  6382	
  6383	
  6384	
  6385	
  6386	
  6387	
  6388	
  6389	
  6390	
  6391	
  6392	
  6393	
  6394	
  6395	
  6396	
  6397	
  6398	
  6399	
  6400	
  6401	
  6402	
  6403	
  6404	
  6405	
  6406	
  6407	
  6408	
  6409	
  6410	
  6411	
  6412	
  6413	
  6414	
  6415	
  6416	
  6417	
  6418	
  6419	
  6420	
  6421	
  6422	
  6423	
  6424	
  6425	
  6426	
  6427	
  6428	
  6429	
  6430	
  6431	
  6432	
  6433	
  6434	
  6435	
  6436	    @experimental(version="3.3.0")
  6437	    def test_webhook(
  6438	        self, webhook_id: str, event: WebhookEventStr | WebhookEvent | None = None
  6439	    ) -> WebhookTestResult:
  6440	        """
  6441	        Test a webhook by sending a test payload.
  6442	
  6443	        Args:
  6444	            webhook_id: Webhook ID to test.
  6445	            event: Optional event type to test. Can be a WebhookEvent object or a string in
  6446	                "entity.action" format (e.g., "model_version.created"). If not specified, uses
  6447	                the first event from webhook.
  6448	
  6449	        Returns:
  6450	            WebhookTestResult indicating success/failure and response details.
  6451	        """
  6452	        return self._get_registry_client().test_webhook(webhook_id, event)
```

## 原始行 26 · command_execution

命令：
```
/bin/bash -lc "nl -ba tests/entities/test_webhook.py | sed -n '1,230p'; find tests/tracking -type f -name '*.py' -print | xargs grep -n \"webhook\" 2>/dev/null"
```

退出码：`123`

输出：
```
     1	import pytest
     2	
     3	from mlflow.entities.webhook import (
     4	    Webhook,
     5	    WebhookAction,
     6	    WebhookEntity,
     7	    WebhookEvent,
     8	    WebhookStatus,
     9	    WebhookTestResult,
    10	)
    11	from mlflow.exceptions import MlflowException
    12	from mlflow.protos.webhooks_pb2 import WebhookAction as ProtoWebhookAction
    13	from mlflow.protos.webhooks_pb2 import WebhookEntity as ProtoWebhookEntity
    14	from mlflow.protos.webhooks_pb2 import WebhookStatus as ProtoWebhookStatus
    15	
    16	
    17	@pytest.mark.parametrize(
    18	    ("proto_status", "status_enum"),
    19	    [
    20	        (ProtoWebhookStatus.ACTIVE, WebhookStatus.ACTIVE),
    21	        (ProtoWebhookStatus.DISABLED, WebhookStatus.DISABLED),
    22	    ],
    23	)
    24	def test_webhook_status_proto_conversion(proto_status, status_enum):
    25	    assert WebhookStatus.from_proto(proto_status) == status_enum
    26	    assert status_enum.to_proto() == proto_status
    27	
    28	
    29	@pytest.mark.parametrize(
    30	    ("entity_enum", "proto_entity"),
    31	    [
    32	        (WebhookEntity.REGISTERED_MODEL, ProtoWebhookEntity.REGISTERED_MODEL),
    33	        (WebhookEntity.MODEL_VERSION, ProtoWebhookEntity.MODEL_VERSION),
    34	        (WebhookEntity.MODEL_VERSION_TAG, ProtoWebhookEntity.MODEL_VERSION_TAG),
    35	        (WebhookEntity.MODEL_VERSION_ALIAS, ProtoWebhookEntity.MODEL_VERSION_ALIAS),
    36	    ],
    37	)
    38	def test_webhook_entity_proto_conversion(entity_enum, proto_entity):
    39	    assert WebhookEntity.from_proto(proto_entity) == entity_enum
    40	    assert entity_enum.to_proto() == proto_entity
    41	
    42	
    43	@pytest.mark.parametrize(
    44	    ("action_enum", "proto_action"),
    45	    [
    46	        (WebhookAction.CREATED, ProtoWebhookAction.CREATED),
    47	        (WebhookAction.UPDATED, ProtoWebhookAction.UPDATED),
    48	        (WebhookAction.DELETED, ProtoWebhookAction.DELETED),
    49	        (WebhookAction.SET, ProtoWebhookAction.SET),
    50	    ],
    51	)
    52	def test_webhook_action_proto_conversion(action_enum, proto_action):
    53	    assert WebhookAction.from_proto(proto_action) == action_enum
    54	    assert action_enum.to_proto() == proto_action
    55	
    56	
    57	def test_webhook_event_creation():
    58	    event = WebhookEvent(WebhookEntity.REGISTERED_MODEL, WebhookAction.CREATED)
    59	    assert event.entity == WebhookEntity.REGISTERED_MODEL
    60	    assert event.action == WebhookAction.CREATED
    61	
    62	
    63	def test_webhook_event_from_string():
    64	    event = WebhookEvent("registered_model", "created")
    65	    assert event.entity == WebhookEntity.REGISTERED_MODEL
    66	    assert event.action == WebhookAction.CREATED
    67	
    68	
    69	def test_webhook_event_invalid_combination():
    70	    with pytest.raises(
    71	        MlflowException, match="Invalid action 'updated' for entity 'model_version_tag'"
    72	    ):
    73	        WebhookEvent(WebhookEntity.MODEL_VERSION_TAG, WebhookAction.UPDATED)
    74	
    75	
    76	def test_webhook_event_from_str():
    77	    event = WebhookEvent.from_str("registered_model.created")
    78	    assert event.entity == WebhookEntity.REGISTERED_MODEL
    79	    assert event.action == WebhookAction.CREATED
    80	
    81	
    82	def test_webhook_event_from_str_invalid_format():
    83	    with pytest.raises(MlflowException, match="Invalid event string format"):
    84	        WebhookEvent.from_str("invalid_format")
    85	
    86	
    87	def test_webhook_event_to_str():
    88	    event = WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)
    89	    assert str(event) == "model_version.created"
    90	
    91	
    92	def test_webhook_event_proto_conversion():
    93	    event = WebhookEvent(WebhookEntity.REGISTERED_MODEL, WebhookAction.CREATED)
    94	    proto_event = event.to_proto()
    95	    event_from_proto = WebhookEvent.from_proto(proto_event)
    96	    assert event_from_proto.entity == event.entity
    97	    assert event_from_proto.action == event.action
    98	
    99	
   100	def test_webhook_event_equality():
   101	    event1 = WebhookEvent(WebhookEntity.REGISTERED_MODEL, WebhookAction.CREATED)
   102	    event2 = WebhookEvent(WebhookEntity.REGISTERED_MODEL, WebhookAction.CREATED)
   103	    event3 = WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)
   104	
   105	    assert event1 == event2
   106	    assert event1 != event3
   107	    assert hash(event1) == hash(event2)
   108	    assert hash(event1) != hash(event3)
   109	
   110	
   111	def test_webhook_event_invalid_entity_action_combination():
   112	    with pytest.raises(
   113	        MlflowException, match="Invalid action 'deleted' for entity 'registered_model'"
   114	    ):
   115	        WebhookEvent(WebhookEntity.REGISTERED_MODEL, WebhookAction.DELETED)
   116	
   117	
   118	def test_webhook_proto_conversion():
   119	    events = [
   120	        WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED),
   121	        WebhookEvent(WebhookEntity.MODEL_VERSION_ALIAS, WebhookAction.CREATED),
   122	    ]
   123	    webhook = Webhook(
   124	        webhook_id="webhook123",
   125	        name="Test Webhook",
   126	        url="https://example.com/webhook",
   127	        events=events,
   128	        description="Test webhook description",
   129	        status=WebhookStatus.ACTIVE,
   130	        secret="my-secret",
   131	        creation_timestamp=1234567890,
   132	        last_updated_timestamp=1234567900,
   133	    )
   134	    proto_webhook = webhook.to_proto()
   135	    webhook_from_proto = Webhook.from_proto(proto_webhook)
   136	    assert webhook_from_proto.webhook_id == webhook.webhook_id
   137	    assert webhook_from_proto.name == webhook.name
   138	    assert webhook_from_proto.url == webhook.url
   139	    assert webhook_from_proto.events == webhook.events
   140	    assert webhook_from_proto.description == webhook.description
   141	    assert webhook_from_proto.status == webhook.status
   142	    assert webhook_from_proto.creation_timestamp == webhook.creation_timestamp
   143	    assert webhook_from_proto.last_updated_timestamp == webhook.last_updated_timestamp
   144	
   145	
   146	def test_webhook_no_secret_in_repr():
   147	    events = [WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)]
   148	    webhook = Webhook(
   149	        webhook_id="webhook123",
   150	        name="Test Webhook",
   151	        url="https://example.com/webhook",
   152	        events=events,
   153	        creation_timestamp=1234567890,
   154	        last_updated_timestamp=1234567900,
   155	        description="Test webhook description",
   156	        status=WebhookStatus.ACTIVE,
   157	        secret="my-secret",
   158	    )
   159	    assert "my-secret" not in repr(webhook)
   160	
   161	
   162	def test_webhook_invalid_events():
   163	    with pytest.raises(MlflowException, match="Webhook events cannot be empty"):
   164	        Webhook(
   165	            webhook_id="webhook123",
   166	            name="Test Webhook",
   167	            url="https://example.com/webhook",
   168	            events=[],
   169	            creation_timestamp=1234567890,
   170	            last_updated_timestamp=1234567900,
   171	        )
   172	
   173	
   174	def test_webhook_test_result():
   175	    # Test successful result
   176	    result = WebhookTestResult(
   177	        success=True,
   178	        response_status=200,
   179	        response_body='{"status": "ok"}',
   180	    )
   181	    assert result.success is True
   182	    assert result.response_status == 200
   183	    assert result.response_body == '{"status": "ok"}'
   184	    assert result.error_message is None
   185	
   186	    # Test failed result
   187	    result = WebhookTestResult(
   188	        success=False,
   189	        response_status=500,
   190	        error_message="Internal server error",
   191	    )
   192	    assert result.success is False
   193	    assert result.response_status == 500
   194	    assert result.error_message == "Internal server error"
   195	    assert result.response_body is None
```

## 原始行 28 · command_execution

命令：
```
/bin/bash -lc 'git diff -- mlflow/entities/webhook.py mlflow/tracking/client.py mlflow/tracking/_model_registry/client.py && git status --porcelain=v1'
```

退出码：`0`

输出：
```

```

## 原始行 30 · agent_message

```
The masking removed both public wrappers and the internal registry-client CRUD methods they must call. I’m checking adjacent client conventions (normalization, telemetry decoration, pagination pass-through) so the restored path works end to end, not only under a mocked public client.
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "grep -n \"return self._get_registry_client().*list\\|def list_.*max_results.*page_token\\|Webhook APIs\" mlflow/tracking/client.py | tail -80"
```

退出码：`0`

输出：
```
6309:    # Webhook APIs
```

## 原始行 35 · command_execution

命令：
```
/bin/bash -lc "grep -n \"record_usage_event\\|CreateWebhookEvent\\|def create_.*(\" mlflow/tracking/_model_registry/client.py | head -80"
```

退出码：`0`

输出：
```
40:    CreateWebhookEvent,
42:from mlflow.telemetry.track import record_usage_event
75:    @record_usage_event(CreateRegisteredModelEvent)
76:    def create_registered_model(self, name, tags=None, description=None, deployment_job_id=None):
224:    @record_usage_event(CreateModelVersionEvent)
225:    def create_model_version(
476:    @record_usage_event(CreatePromptEvent)
477:    def create_prompt(
560:    def create_prompt_version(
```

## 原始行 36 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,210p' tests/store/model_registry/test_rest_store_webhooks.py; sed -n '1,100p' mlflow/telemetry/events.py | grep -n -A10 -B5 Webhook"
```

退出码：`1`

输出：
```
"""
This test file verifies webhook CRUD operations with the REST client,
testing both server handlers and the REST client together.
"""

from pathlib import Path
from typing import Iterator

import pytest
from cryptography.fernet import Fernet

from mlflow.entities.webhook import WebhookAction, WebhookEntity, WebhookEvent, WebhookStatus
from mlflow.environment_variables import MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY
from mlflow.exceptions import MlflowException
from mlflow.server import handlers
from mlflow.server.fastapi_app import app
from mlflow.server.handlers import initialize_backend_stores
from mlflow.store.model_registry.rest_store import RestStore
from mlflow.utils.rest_utils import MlflowHostCreds

from tests.helper_functions import get_safe_port
from tests.tracking.integration_test_utils import ServerThread


@pytest.fixture
def store(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:
    """Set up a local MLflow server with proper webhook encryption key support."""
    # Set up encryption key for webhooks using monkeypatch
    encryption_key = Fernet.generate_key().decode("utf-8")
    monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)

    # Configure backend stores
    backend_uri = f"sqlite:///{tmp_path / 'mlflow.db'}"
    default_artifact_root = tmp_path.as_uri()

    # Force-reset backend stores before each test
    handlers._tracking_store = None
    handlers._model_registry_store = None
    initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)

    # Start server and return RestStore
    with ServerThread(app, get_safe_port()) as url:
        yield RestStore(lambda: MlflowHostCreds(url))


def test_create_webhook(store: RestStore):
    webhook = store.create_webhook(
        name="test_webhook",
        url="https://example.com/webhook",
        events=[WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)],
    )
    assert webhook.name == "test_webhook"
    assert webhook.url == "https://example.com/webhook"
    assert webhook.secret is None
    assert webhook.events == [WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)]

    webhook = store.get_webhook(webhook.webhook_id)
    assert webhook.name == "test_webhook"
    assert webhook.url == "https://example.com/webhook"
    assert webhook.secret is None

    # With secret
    webhook_with_secret = store.create_webhook(
        name="test_webhook_with_secret",
        url="https://example.com/webhook_with_secret",
        events=[WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)],
        secret="my_secret",
    )
    assert webhook_with_secret.name == "test_webhook_with_secret"
    assert webhook_with_secret.url == "https://example.com/webhook_with_secret"
    assert webhook_with_secret.secret is None
    assert webhook_with_secret.events == [
        WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)
    ]

    # Multiple events
    webhook_multiple_events = store.create_webhook(
        name="test_webhook_multiple_events",
        url="https://example.com/webhook_multiple_events",
        events=[
            WebhookEvent(WebhookEntity.MODEL_VERSION_ALIAS, WebhookAction.CREATED),
            WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED),
        ],
    )
    assert webhook_multiple_events.name == "test_webhook_multiple_events"
    assert webhook_multiple_events.url == "https://example.com/webhook_multiple_events"
    assert sorted(
        webhook_multiple_events.events, key=lambda e: (e.entity.value, e.action.value)
    ) == [
        WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED),
        WebhookEvent(WebhookEntity.MODEL_VERSION_ALIAS, WebhookAction.CREATED),
    ]
    assert webhook_multiple_events.secret is None


def test_get_webhook(store: RestStore):
    events = [WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)]
    created_webhook = store.create_webhook(
        name="test_webhook", url="https://example.com/webhook", events=events
    )
    retrieved_webhook = store.get_webhook(created_webhook.webhook_id)
    assert retrieved_webhook.webhook_id == created_webhook.webhook_id
    assert retrieved_webhook.name == "test_webhook"
    assert retrieved_webhook.url == "https://example.com/webhook"
    assert retrieved_webhook.events == events


def test_get_webhook_not_found(store: RestStore):
    with pytest.raises(MlflowException, match="Webhook with ID nonexistent not found"):
        store.get_webhook("nonexistent")


def test_list_webhooks(store: RestStore):
    # Create more webhooks than max_results
    created_webhooks = []
    for i in range(5):
        webhook = store.create_webhook(
            name=f"webhook{i}",
            url=f"https://example.com/{i}",
            events=[WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)],
        )
        created_webhooks.append(webhook)
    # Test pagination with max_results=2
    webhooks_page = store.list_webhooks(max_results=2)
    assert len(webhooks_page) == 2
    assert webhooks_page.token is not None
    # Get next page
    next_webhooks_page = store.list_webhooks(max_results=2, page_token=webhooks_page.token)
    assert len(next_webhooks_page) == 2
    assert next_webhooks_page.token is not None
    # Verify we don't get duplicates
    first_page_ids = {w.webhook_id for w in webhooks_page}
    second_page_ids = {w.webhook_id for w in next_webhooks_page}
    assert first_page_ids.isdisjoint(second_page_ids)


def test_update_webhook(store: RestStore):
    events = [WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)]
    webhook = store.create_webhook(
        name="original_name", url="https://example.com/original", events=events
    )
    # Update webhook
    new_events = [
        WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED),
        WebhookEvent(WebhookEntity.REGISTERED_MODEL, WebhookAction.CREATED),
    ]
    updated_webhook = store.update_webhook(
        webhook_id=webhook.webhook_id,
        name="updated_name",
        url="https://example.com/updated",
        events=new_events,
        description="Updated description",
        secret="new_secret",
        status=WebhookStatus.DISABLED,
    )
    assert updated_webhook.webhook_id == webhook.webhook_id
    assert updated_webhook.name == "updated_name"
    assert updated_webhook.url == "https://example.com/updated"
    assert updated_webhook.events == new_events
    assert updated_webhook.description == "Updated description"
    assert updated_webhook.status == WebhookStatus.DISABLED
    assert updated_webhook.last_updated_timestamp > webhook.last_updated_timestamp


def test_update_webhook_partial(store: RestStore):
    events = [WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)]
    webhook = store.create_webhook(
        name="original_name",
        url="https://example.com/original",
        events=events,
        description="Original description",
    )
    # Update only the name
    updated_webhook = store.update_webhook(
        webhook_id=webhook.webhook_id,
        name="updated_name",
    )
    assert updated_webhook.name == "updated_name"
    assert updated_webhook.url == "https://example.com/original"
    assert updated_webhook.events == events
    assert updated_webhook.description == "Original description"


def test_update_webhook_not_found(store: RestStore):
    with pytest.raises(MlflowException, match="Webhook with ID nonexistent not found"):
        store.update_webhook(webhook_id="nonexistent", name="new_name")


@pytest.mark.parametrize(
    ("invalid_url", "expected_match"),
    [
        ("   ", r"Webhook URL cannot be empty or just whitespace"),
        ("ftp://example.com", r"Invalid webhook URL scheme"),
        ("http://[invalid", r"Invalid webhook URL"),
    ],
)
def test_update_webhook_invalid_urls(store, invalid_url, expected_match):
    # Create a valid webhook first
    webhook = store.create_webhook(
        name="test_webhook",
        url="https://example.com/webhook",
        events=[WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)],
    )
    with pytest.raises(MlflowException, match=expected_match):
        store.update_webhook(webhook_id=webhook.webhook_id, url=invalid_url)


def test_delete_webhook(store: RestStore):
    events = [WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)]
    webhook = store.create_webhook(
```

## 原始行 38 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"create_webhook(\" tests --include='*.py'; grep -RIn \"_get_registry_client\" tests/tracking --include='*.py' | head -50"
```

退出码：`0`

输出：
```
tests/webhooks/test_e2e.py:178:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:199:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:226:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:255:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:287:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:314:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:342:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:371:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:397:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:419:    webhook = mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:449:    webhook = mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:483:    webhook = mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:517:    webhook = mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:535:    webhook = mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:560:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:596:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:629:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:652:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:685:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:713:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:739:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:770:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:800:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:829:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:863:    mlflow_client.create_webhook(
tests/webhooks/test_e2e.py:927:    webhook = mlflow_client.create_webhook(
tests/telemetry/test_tracked_events.py:341:def test_create_webhook(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:343:    client.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:46:def test_create_webhook(store: RestStore):
tests/store/model_registry/test_rest_store_webhooks.py:47:    webhook = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:63:    webhook_with_secret = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:77:    webhook_multiple_events = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:98:    created_webhook = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:117:        webhook = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:139:    webhook = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:167:    webhook = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:199:    webhook = store.create_webhook(
tests/store/model_registry/test_rest_store_webhooks.py:210:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:1965:def test_create_webhook(store):
tests/store/model_registry/test_sqlalchemy_store.py:1970:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2029:        store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2038:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2059:        store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2069:        store.create_webhook(name="test", url="https://example.com", events=[])
tests/store/model_registry/test_sqlalchemy_store.py:2073:        store.create_webhook(name="test", url="https://example.com", events=())
tests/store/model_registry/test_sqlalchemy_store.py:2077:        store.create_webhook(name="test", url="https://example.com", events=[1, 2, 3])
tests/store/model_registry/test_sqlalchemy_store.py:2082:    created_webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2101:    webhook1 = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2106:    webhook2 = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2125:        webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2155:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2185:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2206:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2227:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2247:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2259:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2283:    webhook = store.create_webhook(
tests/store/model_registry/test_sqlalchemy_store.py:2305:    store.create_webhook(
```

## 原始行 41 · command_execution

命令：
```
/bin/bash -lc "sed -n '320,365p' tests/telemetry/test_tracked_events.py; grep -n -A12 -B4 \"class CreateWebhookEvent\" mlflow/telemetry/events.py"
```

退出码：`0`

输出：
```
        LogAssessmentEvent.name,
        {"type": "expectation", "source_type": "HUMAN"},
    )
    mlflow.log_expectation(trace_id=span.trace_id, value="MLflow", name="expected_answer")
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        LogAssessmentEvent.name,
        {"type": "expectation", "source_type": "HUMAN"},
    )


def test_evaluate(mock_requests, mock_telemetry_client: TelemetryClient):
    mlflow.models.evaluate(
        data=pd.DataFrame({"x": [1, 2, 3], "y": [4, 5, 6]}),
        model=lambda x: x["x"] * 2,
        extra_metrics=[mlflow.metrics.latency()],
    )
    validate_telemetry_record(mock_telemetry_client, mock_requests, EvaluateEvent.name)


def test_create_webhook(mock_requests, mock_telemetry_client: TelemetryClient):
    client = MlflowClient()
    client.create_webhook(
        name="test_webhook",
        url="https://example.com/webhook",
        events=[WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)],
    )
    expected_params = {"events": ["model_version.created"]}
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, CreateWebhookEvent.name, expected_params
    )


def test_genai_evaluate(mock_requests, mock_telemetry_client: TelemetryClient):
    @mlflow.genai.scorer
    def sample_scorer(inputs, outputs, expectations):
        return 1.0

    model = TestModel()
    data = [
        {
            "inputs": {"model_input": ["What is the capital of France?"]},
            "outputs": "The capital of France is Paris.",
        }
    ]
182-        return False
183-    return tags.get(IS_PROMPT_TAG_KEY, "false").lower() == "true"
184-
185-
186:class CreateWebhookEvent(Event):
187-    name: str = "create_webhook"
188-
189-    @classmethod
190-    def parse(cls, arguments: dict[str, Any]) -> dict[str, Any] | None:
191-        events = arguments.get("events") or []
192-        return {"events": [str(event) for event in events]}
193-
194-
195-class PromptOptimizationEvent(Event):
196-    name: str = "prompt_optimization"
197-
198-    @classmethod
```

## 原始行 43 · command_execution

命令：
```
/bin/bash -lc "sed -n '50,105p' mlflow/tracking/_model_registry/client.py; sed -n '450,510p' mlflow/tracking/_model_registry/client.py; sed -n '1,120p' mlflow/store/entities/paged_list.py"
```

退出码：`0`

输出：
```
class ModelRegistryClient:
    """
    Client of an MLflow Model Registry Server that creates and manages registered
    models and model versions.
    """

    def __init__(self, registry_uri, tracking_uri):
        """
        Args:
            registry_uri: Address of local or remote model registry server.
            tracking_uri: Address of local or remote tracking server.
        """
        self.registry_uri = registry_uri
        self.tracking_uri = tracking_uri
        # NB: Fetch the tracking store (`self.store`) upon client initialization to ensure that
        # the tracking URI is valid and the store can be properly resolved. We define `store` as a
        # property method to ensure that the client is serializable, even if the store is not
        self.store

    @property
    def store(self):
        return utils._get_store(self.registry_uri, self.tracking_uri)

    # Registered Model Methods

    @record_usage_event(CreateRegisteredModelEvent)
    def create_registered_model(self, name, tags=None, description=None, deployment_job_id=None):
        """Create a new registered model in backend store.

        Args:
            name: Name of the new model. This is expected to be unique in the backend store.
            tags: A dictionary of key-value pairs that are converted into
                :py:class:`mlflow.entities.model_registry.RegisteredModelTag` objects.
            description: Description of the model.
            deployment_job_id: Optional deployment job ID.

        Returns:
            A single object of :py:class:`mlflow.entities.model_registry.RegisteredModel`
            created by backend.

        """
        # TODO: Do we want to validate the name is legit here - non-empty without "/" and ":" ?
        #       Those are constraints applicable to any backend, given the model URI format.
        tags = tags if tags else {}
        tags = [RegisteredModelTag(key, str(value)) for key, value in tags.items()]
        return self.store.create_registered_model(name, tags, description, deployment_job_id)

    def update_registered_model(self, name, description, deployment_job_id=None):
        """Updates description for RegisteredModel entity.

        Backend raises exception if a registered model with given name does not exist.

        Args:
            name: Name of the registered model to update.
            description: New description.
            deployment_job_id: Optional deployment job ID.

    def delete_registered_model_alias(self, name, alias):
        """Delete an alias associated with a registered model.

        Args:
            name: Registered model name.
            alias: Name of the alias.

        Returns:
            None
        """
        self.store.delete_registered_model_alias(name, alias)

    def get_model_version_by_alias(self, name, alias):
        """Get the model version instance by name and alias.

        Args:
            name: Registered model name.
            alias: Name of the alias.

        Returns:
            A single :py:class:`mlflow.entities.model_registry.ModelVersion` object.

        """
        return self.store.get_model_version_by_alias(name, alias)

    @record_usage_event(CreatePromptEvent)
    def create_prompt(
        self,
        name: str,
        description: str | None = None,
        tags: dict[str, str] | None = None,
    ) -> Prompt:
        """
        Create a new prompt in the registry.

        This method delegates directly to the store, providing full Unity Catalog support
        when used with Unity Catalog registries.

        Args:
            name: Name of the prompt.
            description: Optional description of the prompt.
            tags: Optional dictionary of prompt tags.

        Returns:
            A PromptInfo object for Unity Catalog stores.
        """
        return self.store.create_prompt(name, description, tags)

    def get_prompt(self, name: str) -> Prompt | None:
        """
        Get prompt metadata by name.

        This method delegates directly to the store, providing full Unity Catalog support
        when used with Unity Catalog registries.

        Args:
            name: Registered prompt name.

        Returns:
            A Prompt object with prompt metadata, or None if not found.
from typing import TypeVar

T = TypeVar("T")


class PagedList(list[T]):
    """
    Wrapper class around the base Python `List` type. Contains an additional `token`  string
    attribute that can be passed to the pagination API that returned this list to fetch additional
    elements, if any are available
    """

    def __init__(self, items: list[T], token):
        super().__init__(items)
        self.token = token

    def to_list(self):
        return list(self)
```

## 原始行 45 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def _get_registry_client\\|def __init__\" mlflow/tracking/client.py | head -10; grep -n \"class ModelRegistryClient\\|def __init__\" mlflow/tracking/_model_registry/client.py | head -10"
```

退出码：`0`

输出：
```
205:    def __init__(self, tracking_uri: str | None = None, registry_uri: str | None = None):
50:class ModelRegistryClient:
56:    def __init__(self, registry_uri, tracking_uri):
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"MlflowClient.*list_webhooks\\|mock.*create_webhook\\|test_.*webhook\" tests/tracking tests --include='*.py' | grep -v 'store/model_registry\\|webhooks/test_e2e\\|entities/test_webhook' | head -100"
```

退出码：`0`

输出：
```
tests/webhooks/test_delivery.py:34:def test_deliver_webhook_exits_early_for_file_store(
tests/webhooks/test_delivery.py:48:def test_deliver_webhook_calls_impl_for_sql_store(
tests/webhooks/test_delivery.py:66:def test_deliver_webhook_handles_exception_for_sql_store(
tests/webhooks/test_delivery.py:85:def test_deliver_webhook_no_exception_for_file_store(
tests/server/test_handlers.py:1900:def test_list_webhooks_empty_page_token(mock_get_request_message, mock_model_registry_store):
tests/telemetry/test_tracked_events.py:341:def test_create_webhook(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:344:        name="test_webhook",
```

## 原始行 50 · command_execution

命令：
```
/bin/bash -lc "sed -n '360,470p' mlflow/entities/webhook.py; grep -RIn \"ModelRegistryClient\" tests/tracking tests --include='*.py' | head -40; find tests -path '*model_registry*client*' -type f -print"
```

退出码：`0`

输出：
```
            f"name='{self.name}', "
            f"url='{self.url}', "
            f"status='{self.status}', "
            f"events={self.events}, "
            f"creation_timestamp={self.creation_timestamp}, "
            f"last_updated_timestamp={self.last_updated_timestamp}"
            f")"
        )


class WebhookTestResult:
    """
    MLflow entity for WebhookTestResult.
    """

    def __init__(
        self,
        success: bool,
        response_status: int | None = None,
        response_body: str | None = None,
        error_message: str | None = None,
    ):
        """
        Initialize a WebhookTestResult entity.

        Args:
            success: Whether the test succeeded
            response_status: HTTP response status code if available
            response_body: Response body if available
            error_message: Error message if test failed
        """
        self._success = success
        self._response_status = response_status
        self._response_body = response_body
        self._error_message = error_message

    @property
    def success(self) -> bool:
        return self._success

    @property
    def response_status(self) -> int | None:
        return self._response_status

    @property
    def response_body(self) -> str | None:
        return self._response_body

    @property
    def error_message(self) -> str | None:
        return self._error_message

    @classmethod
    def from_proto(cls, proto: ProtoWebhookTestResult) -> Self:
        return cls(
            success=proto.success,
            response_status=proto.response_status or None,
            response_body=proto.response_body or None,
            error_message=proto.error_message or None,
        )

    def to_proto(self) -> ProtoWebhookTestResult:
        return ProtoWebhookTestResult(
            success=self.success,
            response_status=self.response_status,
            response_body=self.response_body,
            error_message=self.error_message,
        )

    def __repr__(self) -> str:
        return (
            f"WebhookTestResult("
            f"success={self.success!r}, "
            f"response_status={self.response_status!r}, "
            f"response_body={self.response_body!r}, "
            f"error_message={self.error_message!r}"
            f")"
        )tests/tracking/_model_registry/test_model_registry_client.py:2:Simple unit tests to confirm that ModelRegistryClient properly calls the registry Store methods
tests/tracking/_model_registry/test_model_registry_client.py:24:from mlflow.tracking._model_registry.client import ModelRegistryClient
tests/tracking/_model_registry/test_model_registry_client.py:35:def newModelRegistryClient(registry_uri="uri:/fake"):
tests/tracking/_model_registry/test_model_registry_client.py:36:    return ModelRegistryClient(registry_uri, "uri:/fake")
tests/tracking/_model_registry/test_model_registry_client.py:65:    result = newModelRegistryClient().create_registered_model("Model 1", tags_dict, description)
tests/tracking/_model_registry/test_model_registry_client.py:79:    result = newModelRegistryClient().update_registered_model(
tests/tracking/_model_registry/test_model_registry_client.py:90:    result = newModelRegistryClient().update_registered_model(
tests/tracking/_model_registry/test_model_registry_client.py:103:    result = newModelRegistryClient().rename_registered_model(name=name, new_name=new_name)
tests/tracking/_model_registry/test_model_registry_client.py:108:    result = newModelRegistryClient().rename_registered_model(name=name, new_name="New Name 2")
tests/tracking/_model_registry/test_model_registry_client.py:115:        newModelRegistryClient().rename_registered_model("Model 1", " ")
tests/tracking/_model_registry/test_model_registry_client.py:119:    newModelRegistryClient().delete_registered_model("Model 1")
tests/tracking/_model_registry/test_model_registry_client.py:127:    result = newModelRegistryClient().search_registered_models(filter_string="test filter")
tests/tracking/_model_registry/test_model_registry_client.py:135:    result = newModelRegistryClient().search_registered_models(
tests/tracking/_model_registry/test_model_registry_client.py:151:    result = newModelRegistryClient().search_registered_models(max_results=5)
tests/tracking/_model_registry/test_model_registry_client.py:163:    result = newModelRegistryClient(
tests/tracking/_model_registry/test_model_registry_client.py:182:    newModelRegistryClient("sqlite:///path/to/db").search_registered_models(
tests/tracking/_model_registry/test_model_registry_client.py:209:    result = newModelRegistryClient().get_registered_model(name)
tests/tracking/_model_registry/test_model_registry_client.py:222:    result = newModelRegistryClient().get_latest_versions("Model 1", ["Stage1", "Stage2"])
tests/tracking/_model_registry/test_model_registry_client.py:228:    newModelRegistryClient().set_registered_model_tag("Model 1", "key", "value")
tests/tracking/_model_registry/test_model_registry_client.py:233:    newModelRegistryClient().delete_registered_model_tag("Model 1", "key")
tests/tracking/_model_registry/test_model_registry_client.py:251:    newModelRegistryClient().create_model_version(
tests/tracking/_model_registry/test_model_registry_client.py:268:    result = newModelRegistryClient().create_model_version(
tests/tracking/_model_registry/test_model_registry_client.py:271:    result = newModelRegistryClient().create_model_version(
tests/tracking/_model_registry/test_model_registry_client.py:296:    result = newModelRegistryClient().create_model_version(
tests/tracking/_model_registry/test_model_registry_client.py:330:    result = newModelRegistryClient().create_model_version(
tests/tracking/_model_registry/test_model_registry_client.py:349:    actual_result = newModelRegistryClient().update_model_version(name, version, "new description")
tests/tracking/_model_registry/test_model_registry_client.py:362:    actual_result = newModelRegistryClient().transition_model_version_stage(name, version, stage)
tests/tracking/_model_registry/test_model_registry_client.py:371:        newModelRegistryClient().transition_model_version_stage("Model 1", "12", stage=" ")
tests/tracking/_model_registry/test_model_registry_client.py:375:    newModelRegistryClient().delete_model_version("Model 1", 12)
tests/tracking/_model_registry/test_model_registry_client.py:384:    result = newModelRegistryClient().get_model_version("Model 1", "12")
tests/tracking/_model_registry/test_model_registry_client.py:392:    result = newModelRegistryClient().get_model_version_download_uri("Model 1", 12)
tests/tracking/_model_registry/test_model_registry_client.py:410:    result = newModelRegistryClient().search_model_versions("name=Model 1")
tests/tracking/_model_registry/test_model_registry_client.py:418:    result = newModelRegistryClient().search_model_versions(
tests/tracking/_model_registry/test_model_registry_client.py:428:    result = newModelRegistryClient().get_model_version_stages("Model 1", 1)
tests/tracking/_model_registry/test_model_registry_client.py:436:    newModelRegistryClient().set_model_version_tag("Model 1", "1", "key", "value")
tests/tracking/_model_registry/test_model_registry_client.py:441:    newModelRegistryClient().delete_model_version_tag("Model 1", "1", "key")
tests/tracking/_model_registry/test_model_registry_client.py:446:    newModelRegistryClient().set_registered_model_alias("Model 1", "test_alias", "1")
tests/tracking/_model_registry/test_model_registry_client.py:451:    newModelRegistryClient().delete_registered_model_alias("Model 1", "test_alias")
tests/tracking/_model_registry/test_model_registry_client.py:459:    result = newModelRegistryClient().get_model_version_by_alias("Model 1", "test_alias")
tests/tracking/_model_registry/test_model_registry_client.py:472:    client = newModelRegistryClient()
tests/tracking/_model_registry/test_model_registry_client.py
```

## 原始行 53 · command_execution

命令：
```
/bin/bash -lc "sed -n '450,620p' tests/tracking/_model_registry/test_model_registry_client.py; grep -RIn \"create_webhook\" tests/tracking --include='*.py'"
```

退出码：`1`

输出：
```
def test_delete_registered_model_alias(mock_store):
    newModelRegistryClient().delete_registered_model_alias("Model 1", "test_alias")
    mock_store.delete_registered_model_alias.assert_called_once()


def test_get_model_version_by_alias(mock_store):
    mock_store.get_model_version_by_alias.return_value = _model_version(
        "Model 1", "12", "Production", aliases=["test_alias"]
    )
    result = newModelRegistryClient().get_model_version_by_alias("Model 1", "test_alias")
    mock_store.get_model_version_by_alias.assert_called_once()
    assert result.name == "Model 1"
    assert result.aliases == ["test_alias"]


def test_search_registered_models_excludes_chat_prompts(mock_store):
    """Test that search_registered_models excludes chat prompts correctly."""
    # This test ensures the prompt filter logic works with new prompt types
    mock_store.search_registered_models.return_value = PagedList(
        [RegisteredModel("Model 1"), RegisteredModel("Model 2")], ""
    )

    client = newModelRegistryClient()
    client.search_registered_models(filter_string="test filter")

    prompt_filter = "tag.`mlflow.prompt.is_prompt` != 'true'"
    mock_store.search_registered_models.assert_called_with(
        f"test filter AND {prompt_filter}",
        SEARCH_REGISTERED_MODEL_MAX_RESULTS_DEFAULT,
        None,
        None,
    )


def test_search_registered_models_excludes_text_prompts(mock_store):
    """Test that search_registered_models excludes text prompts correctly."""
    mock_store.search_registered_models.return_value = PagedList([RegisteredModel("Model 1")], "")

    client = newModelRegistryClient()
    client.search_registered_models()

    prompt_filter = "tag.`mlflow.prompt.is_prompt` != 'true'"
    mock_store.search_registered_models.assert_called_with(
        prompt_filter, SEARCH_REGISTERED_MODEL_MAX_RESULTS_DEFAULT, None, None
    )


def test_search_registered_models_excludes_prompts_with_response_format(mock_store):
    mock_store.search_registered_models.return_value = PagedList([RegisteredModel("Model 1")], "")

    client = newModelRegistryClient()
    client.search_registered_models(filter_string="name='test'")

    prompt_filter = "tag.`mlflow.prompt.is_prompt` != 'true'"
    mock_store.search_registered_models.assert_called_with(
        f"name='test' AND {prompt_filter}",
        SEARCH_REGISTERED_MODEL_MAX_RESULTS_DEFAULT,
        None,
        None,
    )


def test_search_registered_models_preserves_existing_prompt_filter(mock_store):
    mock_store.search_registered_models.return_value = PagedList([RegisteredModel("Model 1")], "")

    client = newModelRegistryClient()
    # Test with existing prompt filter
    client.search_registered_models(filter_string="tag.`mlflow.prompt.is_prompt` != 'true'")

    # Should not add duplicate filter
    mock_store.search_registered_models.assert_called_with(
        "tag.`mlflow.prompt.is_prompt` != 'true'",
        SEARCH_REGISTERED_MODEL_MAX_RESULTS_DEFAULT,
        None,
        None,
    )


def test_search_registered_models_with_complex_filter(mock_store):
    """Test that search_registered_models works with complex filter strings."""
    mock_store.search_registered_models.return_value = PagedList([RegisteredModel("Model 1")], "")

    client = newModelRegistryClient()
    complex_filter = "name LIKE 'test%' AND tag.environment = 'prod'"
    client.search_registered_models(filter_string=complex_filter)

    prompt_filter = "tag.`mlflow.prompt.is_prompt` != 'true'"
    expected_filter = f"{complex_filter} AND {prompt_filter}"
    mock_store.search_registered_models.assert_called_with(
        expected_filter, SEARCH_REGISTERED_MODEL_MAX_RESULTS_DEFAULT, None, None
    )


def test_search_registered_models_with_pagination(mock_store):
    """Test that search_registered_models works with pagination parameters."""
    mock_store.search_registered_models.return_value = PagedList(
        [RegisteredModel("Model 1")], "next_token"
    )

    client = newModelRegistryClient()
    client.search_registered_models(
        filter_string="name='test'",
        max_results=10,
        order_by=["name"],
        page_token="prev_token",
    )

    prompt_filter = "tag.`mlflow.prompt.is_prompt` != 'true'"
    mock_store.search_registered_models.assert_called_with(
        f"name='test' AND {prompt_filter}", 10, ["name"], "prev_token"
    )
```

## 原始行 55 · agent_message

```
I found two important compatibility details: creation telemetry is expected on the internal registry client, and empty update-event lists must remain distinguishable from `None`. I’m preserving both while adding normalization at the public boundary and defensively in the internal client.
```

## 原始行 58 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def __eq__\\|def secret\\|def create_webhook\" mlflow/entities/webhook.py mlflow/tracking/_model_registry/client.py mlflow/tracking/client.py"
```

退出码：`1`

输出：
```

```

## 原始行 61 · file_change

```
{
  "id": "item_36",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/webhook.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 64 · file_change

```
{
  "id": "item_38",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracking/_model_registry/client.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracking/client.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 67 · command_execution

命令：
```
/bin/bash -lc 'python -m compileall -q mlflow/entities/webhook.py mlflow/tracking/client.py mlflow/tracking/_model_registry/client.py && git diff --check && git diff --stat'
```

退出码：`0`

输出：
```
 mlflow/entities/webhook.py                | 17 ++++---
 mlflow/tracking/_model_registry/client.py | 64 ++++++++++++++++++++++++-
 mlflow/tracking/client.py                 | 77 ++++++++++++++++++++++++++++++-
 3 files changed, 147 insertions(+), 11 deletions(-)
```

## 原始行 70 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from mlflow.tracking.client import MlflowClient
from mlflow.entities.webhook import Webhook, WebhookAction, WebhookEntity, WebhookEvent
for name in ('create_webhook', 'get_webhook', 'list_webhooks', 'update_webhook', 'delete_webhook'):
    print(name, inspect.signature(getattr(MlflowClient, name)))
e = WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)
w = Webhook('id', 'name', 'https://example.com', [e], 1, 2, secret='secret')
print(e == WebhookEvent('model_version', 'created'), e == object(), w.secret)
PY"
```

退出码：`0`

输出：
```
create_webhook (self, name: str, url: str, events: list[typing.Union[typing.Literal['registered_model.created', 'model_version.created', 'model_version_tag.set', 'model_version_tag.deleted', 'model_version_alias.created', 'model_version_alias.deleted', 'prompt.created', 'prompt_version.created', 'prompt_tag.set', 'prompt_tag.deleted', 'prompt_version_tag.set', 'prompt_version_tag.deleted', 'prompt_alias.created', 'prompt_alias.deleted'], mlflow.entities.webhook.WebhookEvent]], description: str | None = None, secret: str | None = None, status: str | mlflow.entities.webhook.WebhookStatus | None = None) -> mlflow.entities.webhook.Webhook
get_webhook (self, webhook_id: str) -> mlflow.entities.webhook.Webhook
list_webhooks (self, max_results: int | None = None, page_token: str | None = None) -> mlflow.store.entities.paged_list.PagedList[mlflow.entities.webhook.Webhook]
update_webhook (self, webhook_id: str, name: str | None = None, description: str | None = None, url: str | None = None, events: list[typing.Union[typing.Literal['registered_model.created', 'model_version.created', 'model_version_tag.set', 'model_version_tag.deleted', 'model_version_alias.created', 'model_version_alias.deleted', 'prompt.created', 'prompt_version.created', 'prompt_tag.set', 'prompt_tag.deleted', 'prompt_version_tag.set', 'prompt_version_tag.deleted', 'prompt_alias.created', 'prompt_alias.deleted'], mlflow.entities.webhook.WebhookEvent]] | None = None, secret: str | None = None, status: str | mlflow.entities.webhook.WebhookStatus | None = None) -> mlflow.entities.webhook.Webhook
delete_webhook (self, webhook_id: str) -> None
True False secret
```

## 原始行 71 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/entities/test_webhook.py tests/tracking/_model_registry/test_model_registry_client.py -q'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 62 items

tests/entities/test_webhook.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                   [ 37%][0m
tests/tracking/_model_registry/test_model_registry_client.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 54%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                             [100%][0m

============================= slowest 10 durations =============================

(10 durations < 0.005s hidden.  Use -vv to show these durations.)
[32m============================== [32m[1m62 passed[0m[32m in 0.47s[0m[32m ==============================[0m
```

## 原始行 73 · agent_message

```
The entity and registry-client unit suites pass (62 tests), and all required signatures match. I’m now exercising the real REST-backed CRUD path and telemetry because those catch protocol serialization and delegation issues that unit mocks can miss.
```

## 原始行 79 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/store/model_registry/test_rest_store_webhooks.py tests/telemetry/test_tracked_events.py::test_create_webhook -q'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 13 items

tests/store/model_registry/test_rest_store_webhooks.py [31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31mE[0m[31m      [ 92%][0m
tests/telemetry/test_tracked_events.py [31mF[0m[31m                                 [100%][0m

==================================== ERRORS ====================================
[31m[1m____________________ ERROR at setup of test_create_webhook _____________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_create_webhook0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbee040c350>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_create_webhook0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_create_webhook0'
encryption_key = 'YYoR30mndEdFkAHzfh5epcUCHQOHYMwLzlYt6Z_x4H8='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbee040c350>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_create_webhook0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_create_webhook0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_create_webhook0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:35 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:35 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:35 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:35 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:35 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:35 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:36 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:37 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m______________________ ERROR at setup of test_get_webhook ______________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_get_webhook0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedcba6a90>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_get_webhook0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_get_webhook0'
encryption_key = 'i6t3-wJzxhz53zgo4zONWK9bsBo3LWrv0AJKV9a-pzo='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedcba6a90>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_get_webhook0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_get_webhook0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_get_webhook0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:38 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:38 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:38 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:38 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:38 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:38 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:39 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:40 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m_________________ ERROR at setup of test_get_webhook_not_found _________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_get_webhook_not_found0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc82eed0>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_get_webhook_not_found0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_get_webhook_not_found0'
encryption_key = '8JW8ZEujBRp0x8GF3wAN74fpQdMoCvwfwKMCaV3IqqM='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc82eed0>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_get_webhook_not_found0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_get_webhook_not_found0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_get_webhook_not_found0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:40 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:41 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:41 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:41 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:41 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:41 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:42 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m_____________________ ERROR at setup of test_list_webhooks _____________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_list_webhooks0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedcbd2e90>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_list_webhooks0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_list_webhooks0'
encryption_key = '3isNk0kba9HyDUgI38UG3-ffBGfmmucNKktJm1FP0hg='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedcbd2e90>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_list_webhooks0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_list_webhooks0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_list_webhooks0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:43 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:43 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:43 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:43 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:43 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:43 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:44 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m____________________ ERROR at setup of test_update_webhook _____________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedcaa7550>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook0'
encryption_key = 'xXaG4h127-l8OGdPTSjQhi7Lksrk43od33jcPBPOXtY='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedcaa7550>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:45 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:45 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:45 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:45 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:45 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:45 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:46 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:47 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m________________ ERROR at setup of test_update_webhook_partial _________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_partial0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc8a40d0>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_partial0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_partial0'
encryption_key = 'rF5CMaPBT-7OsJzWCnQhS4jChMB5-xGhaRcW4dSbgq4='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc8a40d0>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_partial0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_partial0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_partial0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:48 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:48 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:48 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:48 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:48 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:48 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:49 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:50 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m_______________ ERROR at setup of test_update_webhook_not_found ________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_not_found0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc4df250>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_not_found0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_not_found0'
encryption_key = 'Y9A6kR_TdvbisOf2c3bWdycyfFZqpfOH21D0D0zd5s0='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc4df250>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_not_found0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_not_found0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_not_found0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:50 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:51 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:51 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:51 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:51 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:51 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:52 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m_ ERROR at setup of test_update_webhook_invalid_urls[   -Webhook URL cannot be empty or just whitespace] _[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedbd03a50>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur0'
encryption_key = '7ljFC0_u7eSCid1Z_N1V6RepZ6Sr2JXYq78n_R3TPPA='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedbd03a50>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:53 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:53 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:53 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:53 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:53 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:53 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:54 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m_ ERROR at setup of test_update_webhook_invalid_urls[ftp://example.com-Invalid webhook URL scheme] _[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur1')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedbd03950>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur1/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur1'
encryption_key = 'kmD_OdCi14gzXuD-seNZ9Qj96K5Sv_SeAc5kjlsBOgo='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedbd03950>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur1')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur1/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur1'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:55 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:55 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:55 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:56 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:56 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:56 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:56 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:05:57 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m_ ERROR at setup of test_update_webhook_invalid_urls[http://[invalid-Invalid webhook URL] _[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur2')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedb5879d0>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur2/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur2'
encryption_key = 'M7wPc2WdNtclXxr9j9Fbamyp7PBtID8_q1p5avx-Y5A='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedb5879d0>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur2')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur2/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_update_webhook_invalid_ur2'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:05:58 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:05:58 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:05:58 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:05:59 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:05:59 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:05:59 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:05:59 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:06:00 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m____________________ ERROR at setup of test_delete_webhook _____________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_delete_webhook0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc5a7e10>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_delete_webhook0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_delete_webhook0'
encryption_key = '-ujH4B7k18BW3Vq8Yn6J4BNzPJBMlW2zF6wnff2cjSw='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedc5a7e10>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_delete_webhook0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_delete_webhook0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_delete_webhook0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:06:01 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:06:01 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:06:01 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:06:01 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:06:01 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:06:02 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:06:02 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:06:03 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
[31m[1m_______________ ERROR at setup of test_delete_webhook_not_found ________________[0m

tmp_path = PosixPath('/tmp/pytest-of-root/pytest-1/test_delete_webhook_not_found0')
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedb3faa90>

    [0m[37m@pytest[39;49;00m.fixture[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mstore[39;49;00m(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Iterator[RestStore]:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Set up a local MLflow server with proper webhook encryption key support."""[39;49;00m[90m[39;49;00m
        [90m# Set up encryption key for webhooks using monkeypatch[39;49;00m[90m[39;49;00m
        encryption_key = Fernet.generate_key().decode([33m"[39;49;00m[33mutf-8[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name, encryption_key)[90m[39;49;00m
    [90m[39;49;00m
        [90m# Configure backend stores[39;49;00m[90m[39;49;00m
        backend_uri = [33mf[39;49;00m[33m"[39;49;00m[33msqlite:///[39;49;00m[33m{[39;49;00mtmp_path[90m [39;49;00m/[90m [39;49;00m[33m'[39;49;00m[33mmlflow.db[39;49;00m[33m'[39;49;00m[33m}[39;49;00m[33m"[39;49;00m[90m[39;49;00m
        default_artifact_root = tmp_path.as_uri()[90m[39;49;00m
    [90m[39;49;00m
        [90m# Force-reset backend stores before each test[39;49;00m[90m[39;49;00m
        handlers._tracking_store = [94mNone[39;49;00m[90m[39;49;00m
        handlers._model_registry_store = [94mNone[39;49;00m[90m[39;49;00m
>       initialize_backend_stores(backend_uri, default_artifact_root=default_artifact_root)[90m[39;49;00m

backend_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_delete_webhook_not_found0/mlflow.db'
default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_delete_webhook_not_found0'
encryption_key = 'kbsw68oqwQvTC5ZHAcyvb_GWw-ulFsqS-T32lF8T13s='
monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x7bbedb3faa90>
tmp_path   = PosixPath('/tmp/pytest-of-root/pytest-1/test_delete_webhook_not_found0')

[1m[31mtests/store/model_registry/test_rest_store_webhooks.py[0m:39: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/server/handlers.py[0m:519: in initialize_backend_stores
    [0m_get_model_registry_store(registry_store_uri)[90m[39;49;00m
        backend_store_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_delete_webhook_not_found0/mlflow.db'
        default_artifact_root = 'file:///tmp/pytest-of-root/pytest-1/test_delete_webhook_not_found0'
        registry_store_uri = None
[1m[31mmlflow/server/handlers.py[0m:479: in _get_model_registry_store
    [0m_model_registry_store = _model_registry_store_registry.get_store(store_uri)[90m[39;49;00m
                            ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        BACKEND_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_FILE_STORE'
        REGISTRY_STORE_URI_ENV_VAR = '_MLFLOW_SERVER_REGISTRY_STORE'
        registry_store_uri = None
        store_uri  = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri = None, tracking_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mget_store[39;49;00m([96mself[39;49;00m, store_uri=[94mNone[39;49;00m, tracking_uri=[94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Get a store from the registry based on the scheme of store_uri[39;49;00m
    [33m[39;49;00m
    [33m    Args:[39;49;00m
    [33m        store_uri: The store URI. If None, it will be inferred from the environment. This URI[39;49;00m
    [33m            is used to select which tracking store implementation to instantiate and[39;49;00m
    [33m            is passed to the constructor of the implementation.[39;49;00m
    [33m        tracking_uri: The optional string tracking URI to use for any MLflow tracking-related[39;49;00m
    [33m            operations in the registry client, e.g. downloading source run[39;49;00m
    [33m            artifacts in order to re-upload them to the model registry location.[39;49;00m
    [33m[39;49;00m
    [33m    Returns:[39;49;00m
    [33m        An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the[39;49;00m
    [33m        store URI requirements.[39;49;00m
    [33m[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mtracking[39;49;00m[04m[96m.[39;49;00m[04m[96m_tracking_service[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m _resolve_tracking_uri[90m[39;49;00m
    [90m[39;49;00m
>       resolved_store_uri = _resolve_registry_uri(store_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       NameError: name '_resolve_registry_uri' is not defined[0m

_resolve_tracking_uri = <function _resolve_tracking_uri at 0x7bbf4810da80>
self       = <mlflow.server.handlers.ModelRegistryStoreRegistryWrapper object at 0x7bbee18ca810>
store_uri  = None
tracking_uri = None

[1m[31mmlflow/tracking/_model_registry/registry.py[0m:47: NameError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 05:06:04 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:06:04 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:06:04 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:06:04 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:06:04 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:06:04 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:06:05 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:06:06 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:06:06 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:06:06 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:06:06 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:06:06 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:06:06 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
=================================== FAILURES ===================================
[31m[1m_____________________________ test_create_webhook ______________________________[0m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7bbedb6db350>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_create_webhook[39;49;00m(mock_requests, mock_telemetry_client: TelemetryClient):[90m[39;49;00m
>       client = MlflowClient()[90m[39;49;00m
                 ^^^^^^^^^^^^^^[90m[39;49;00m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7bbedb6db350>

[1m[31mtests/telemetry/test_tracked_events.py[0m:342: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.tracking.client.MlflowClient object at 0x7bbedb841c10>
tracking_uri = None, registry_uri = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m__init__[39;49;00m([96mself[39;49;00m, tracking_uri: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m, registry_uri: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Args:[39;49;00m
    [33m        tracking_uri: Address of local or remote tracking server. If not provided, defaults[39;49;00m
    [33m            to the service set by ``mlflow.tracking.set_tracking_uri``. See[39;49;00m
    [33m            `Where Runs Get Recorded <../tracking.html#where-runs-get-recorded>`_[39;49;00m
    [33m            for more info.[39;49;00m
    [33m        registry_uri: Address of local or remote model registry server. If not provided,[39;49;00m
    [33m            defaults to the service set by ``mlflow.tracking.set_registry_uri``. If[39;49;00m
    [33m            no such service was set, defaults to the tracking uri of the client.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        final_tracking_uri = utils._resolve_tracking_uri(tracking_uri)[90m[39;49;00m
>       [96mself[39;49;00m._registry_uri = registry_utils._resolve_registry_uri(registry_uri, tracking_uri)[90m[39;49;00m
                             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       AttributeError: module 'mlflow.tracking._model_registry.utils' has no attribute '_resolve_registry_uri'[0m

final_tracking_uri = 'sqlite:////tmp/pytest-of-root/pytest-1/test_create_webhook1/047d6c4e9a0648a09f73fe47e07a2526.sqlite'
registry_uri = None
self       = <mlflow.tracking.client.MlflowClient object at 0x7bbedb841c10>
tracking_uri = None

[1m[31mmlflow/tracking/client.py[0m:217: AttributeError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 05:06:06 INFO mlflow.tracking.fluent: Active model is cleared
[33m=============================== warnings summary ===============================[0m
../opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/middleware/wsgi.py:15
  /opt/miniconda3/envs/testbed/lib/python3.11/site-packages/starlette/middleware/wsgi.py:15: DeprecationWarning: starlette.middleware.wsgi is deprecated and will be removed in a future release. Please refer to https://github.com/abersheeran/a2wsgi as a replacement.
    warnings.warn(

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
3.10s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_create_webhook
3.09s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_update_webhook_invalid_urls[ftp://example.com-Invalid webhook URL scheme]
2.81s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_update_webhook
2.72s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_update_webhook_invalid_urls[http://[invalid-Invalid webhook URL]
2.63s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_get_webhook
2.52s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_update_webhook_invalid_urls[   -Webhook URL cannot be empty or just whitespace]
2.45s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_list_webhooks
2.30s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_delete_webhook
2.26s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_update_webhook_partial
2.19s setup    tests/store/model_registry/test_rest_store_webhooks.py::test_update_webhook_not_found

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                                     | Duration | Tests | Min    | Max    | Avg    |
| ---- | -------------------------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/store/model_registry/test_rest_store_webhooks.py` | 31.40s   | 12    | 2.074s | 3.293s | 2.616s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/telemetry/test_tracked_events.py::test_create_webhook'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 24.3/33.7 GB | DISK 796.0/915.7 GB[0m tests/telemetry/test_tracked_events.py::[1mtest_create_webhook[0m - AttributeError: module 'mlflow.tracking._model_registry.utils' has no attri...
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_create_webhook[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_get_webhook[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_get_webhook_not_found[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_list_webhooks[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_update_webhook[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_update_webhook_partial[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_update_webhook_not_found[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_update_webhook_invalid_urls[   -Webhook URL cannot be empty or just whitespace][0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_update_webhook_invalid_urls[ftp://example.com-Invalid webhook URL scheme][0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_update_webhook_invalid_urls[http://[invalid-Invalid webhook URL][0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_delete_webhook[0m - NameError: name '_resolve_registry_uri' is not defined
[31mERROR[0m tests/store/model_registry/test_rest_store_webhooks.py::[1mtest_delete_webhook_not_found[0m - NameError: name '_resolve_registry_uri' is not defined
[31m=================== [31m[1m1 failed[0m, [33m1 warning[0m, [31m[1m12 errors[0m[31m in 33.08s[0m[31m ===================[0m
```

## 原始行 81 · agent_message

```
The REST and telemetry checks exposed a repository blocker outside the seven interfaces: `_resolve_registry_uri` is missing from the current masked tree, so `MlflowClient()` and registry-store setup fail before webhook code runs. This helper is required by the restored client path, so I’m reconstructing it from its local callers and URI-setting tests.
```

## 原始行 84 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' mlflow/tracking/_model_registry/utils.py; sed -n '1,100p' mlflow/tracking/_model_registry/registry.py"
```

退出码：`0`

输出：
```
from functools import partial

from mlflow.environment_variables import MLFLOW_REGISTRY_URI
from mlflow.store.db.db_types import DATABASE_ENGINES
from mlflow.store.model_registry.databricks_workspace_model_registry_rest_store import (
    DatabricksWorkspaceModelRegistryRestStore,
)
from mlflow.store.model_registry.file_store import FileStore
from mlflow.store.model_registry.rest_store import RestStore
from mlflow.tracking._model_registry.registry import ModelRegistryStoreRegistry
from mlflow.tracking._tracking_service.utils import (
    _resolve_tracking_uri,
)
from mlflow.utils._spark_utils import _get_active_spark_session

from mlflow.utils.databricks_utils import (
    is_in_databricks_serverless_runtime,
    warn_on_deprecated_cross_workspace_registry_uri,
)
from mlflow.utils.uri import (
    _DATABRICKS_UNITY_CATALOG_SCHEME,
    _OSS_UNITY_CATALOG_SCHEME,
    construct_db_uc_uri_from_profile,
    get_db_info_from_uri,
    is_databricks_uri,
)

# NOTE: in contrast to tracking, we do not support the following ways to specify
# the model registry URI:
#  - via environment variables like MLFLOW_TRACKING_URI, MLFLOW_TRACKING_USERNAME, ...
# We do support specifying it
#  - via the ``model_registry_uri`` parameter when creating an ``MlflowClient`` or
#    ``ModelRegistryClient``.
#  - via a utility method ``mlflow.set_registry_uri``
#  - by not specifying anything: in this case we assume the model registry store URI is
#    the same as the tracking store URI. This means Tracking and Model Registry are
#    backed by the same backend DB/Rest server. However, note that we access them via
#    different ``Store`` classes (e.g. ``mlflow.store.tracking.SQLAlchemyStore`` &
#    ``mlflow.store.model_registry.SQLAlchemyStore``).
# This means the following combinations are not supported:
#  - Tracking RestStore & Model Registry RestStore that use different credentials.

_registry_uri = None


def set_registry_uri(uri: str) -> None:
    """Set the registry server URI. This method is especially useful if you have a registry server
    that's different from the tracking server.

    Args:
        uri: An empty string, or a local file path, prefixed with ``file:/``. Data is stored
            locally at the provided file (or ``./mlruns`` if empty). An HTTP URI like
            ``https://my-tracking-server:5000`` or ``http://my-oss-uc-server:8080``. A Databricks
            workspace, provided as the string "databricks" or, to use a Databricks CLI
            `profile <https://github.com/databricks/databricks-cli#installation>`_,
            "databricks://<profileName>".

    .. code-block:: python
        :caption: Example

        import mflow

        # Set model registry uri, fetch the set uri, and compare
        # it with the tracking uri. They should be different
        mlflow.set_registry_uri("sqlite:////tmp/registry.db")
        mr_uri = mlflow.get_registry_uri()
        print(f"Current registry uri: {mr_uri}")
        tracking_uri = mlflow.get_tracking_uri()
        print(f"Current tracking uri: {tracking_uri}")

        # They should be different
        assert tracking_uri != mr_uri

    .. code-block:: text
        :caption: Output

        Current registry uri: sqlite:////tmp/registry.db
        Current tracking uri: file:///.../mlruns

    """
    global _registry_uri
    _registry_uri = uri
    if uri:
        # Set 'MLFLOW_REGISTRY_URI' environment variable
        # so that subprocess can inherit it.
        MLFLOW_REGISTRY_URI.set(_registry_uri)


































































def get_registry_uri() -> str:
    """Get the current registry URI. If none has been specified, defaults to the tracking URI.

    Returns:
        The registry URI.

    .. code-block:: python

        # Get the current model registry uri
        mr_uri = mlflow.get_registry_uri()
        print(f"Current model registry uri: {mr_uri}")

        # Get the current tracking uri
        tracking_uri = mlflow.get_tracking_uri()
        print(f"Current tracking uri: {tracking_uri}")

        # They should be the same
        assert mr_uri == tracking_uri

    .. code-block:: text

        Current model registry uri: file:///.../mlruns
        Current tracking uri: file:///.../mlruns

    """
    return _resolve_registry_uri()


import inspect
import threading
from functools import lru_cache

from mlflow.tracking.registry import StoreRegistry

_building_store_lock = threading.Lock()


class ModelRegistryStoreRegistry(StoreRegistry):
    """Scheme-based registry for model registry store implementations

    This class allows the registration of a function or class to provide an
    implementation for a given scheme of `store_uri` through the `register`
    methods. Implementations declared though the entrypoints
    `mlflow.registry_store` group can be automatically registered through the
    `register_entrypoints` method.

    When instantiating a store through the `get_store` method, the scheme of
    the store URI provided (or inferred from environment) will be used to
    select which implementation to instantiate, which will be called with same
    arguments passed to the `get_store` method.
    """

    def __init__(self):
        super().__init__("mlflow.model_registry_store")

    def get_store(self, store_uri=None, tracking_uri=None):
        """Get a store from the registry based on the scheme of store_uri

        Args:
            store_uri: The store URI. If None, it will be inferred from the environment. This URI
                is used to select which tracking store implementation to instantiate and
                is passed to the constructor of the implementation.
            tracking_uri: The optional string tracking URI to use for any MLflow tracking-related
                operations in the registry client, e.g. downloading source run
                artifacts in order to re-upload them to the model registry location.

        Returns:
            An instance of `mlflow.store.model_registry.AbstractStore` that fulfills the
            store URI requirements.

        """

        from mlflow.tracking._tracking_service.utils import _resolve_tracking_uri

        resolved_store_uri = _resolve_registry_uri(store_uri)
        resolved_tracking_uri = _resolve_tracking_uri(tracking_uri)
        return self._get_store_with_resolved_uri(resolved_store_uri, resolved_tracking_uri)

    @lru_cache(maxsize=100)
    def _get_store_with_resolved_uri(self, resolved_store_uri, resolved_tracking_uri):
        """
        Retrieve the store associated with a resolved (non-None) store URI and an artifact URI.
        Caching is done on resolved URIs because the meaning of an unresolved (None) URI may change
        depending on external configuration, such as environment variables
        """
        with _building_store_lock:
            builder = self.get_store_builder(resolved_store_uri)
            builder_param_names = set(inspect.signature(builder).parameters.keys())
            if "store_uri" in builder_param_names and "tracking_uri" in builder_param_names:
                return builder(store_uri=resolved_store_uri, tracking_uri=resolved_tracking_uri)
            else:
                # Not all model registry stores accept a tracking_uri parameter
                # (e.g. old plugins may not recognize it), so we fall back to
                # passing just the registry URI
                return builder(store_uri=resolved_store_uri)
```

## 原始行 85 · command_execution

命令：
```
/bin/bash -lc "sed -n '180,230p' mlflow/tracking/client.py; grep -n \"MLFLOW_REGISTRY_URI\" mlflow/tracking/_model_registry/utils.py mlflow/environment_variables.py"
```

退出码：`0`

输出：
```
            # Early return with appropriate error message
            message_suffix = (
                "Use Unity Catalog functionality instead."
                if use_uc_message
                else "Use the fluent API instead (e.g., mlflow.genai.datasets.create_dataset)."
            )
            message = (
                f"Dataset operation '{func.__name__}' is not supported when tracking "
                f"URI is 'databricks'. {message_suffix}"
            )
            raise MlflowException(message, error_code=INVALID_PARAMETER_VALUE)

        return wrapper

    return decorator


class MlflowClient:
    """
    Client of an MLflow Tracking Server that creates and manages experiments and runs, and of an
    MLflow Registry Server that creates and manages registered models and model versions. It's a
    thin wrapper around TrackingServiceClient and RegistryClient so there is a unified API but we
    can keep the implementation of the tracking and registry clients independent from each other.
    """

    def __init__(self, tracking_uri: str | None = None, registry_uri: str | None = None):
        """
        Args:
            tracking_uri: Address of local or remote tracking server. If not provided, defaults
                to the service set by ``mlflow.tracking.set_tracking_uri``. See
                `Where Runs Get Recorded <../tracking.html#where-runs-get-recorded>`_
                for more info.
            registry_uri: Address of local or remote model registry server. If not provided,
                defaults to the service set by ``mlflow.tracking.set_registry_uri``. If
                no such service was set, defaults to the tracking uri of the client.
        """
        final_tracking_uri = utils._resolve_tracking_uri(tracking_uri)
        self._registry_uri = registry_utils._resolve_registry_uri(registry_uri, tracking_uri)
        self._tracking_client = TrackingServiceClient(final_tracking_uri)
        self._tracing_client = TracingClient(tracking_uri)

        # `MlflowClient` also references a `ModelRegistryClient` instance that is provided by the
        # `MlflowClient._get_registry_client()` method. This `ModelRegistryClient` is not explicitly
        # defined as an instance variable in the `MlflowClient` constructor; an instance variable
        # is assigned lazily by `MlflowClient._get_registry_client()` and should not be referenced
        # outside of the `MlflowClient._get_registry_client()` method





mlflow/tracking/_model_registry/utils.py:3:from mlflow.environment_variables import MLFLOW_REGISTRY_URI
mlflow/tracking/_model_registry/utils.py:84:        # Set 'MLFLOW_REGISTRY_URI' environment variable
mlflow/tracking/_model_registry/utils.py:86:        MLFLOW_REGISTRY_URI.set(_registry_uri)
mlflow/environment_variables.py:107:MLFLOW_REGISTRY_URI = _EnvironmentVariable("MLFLOW_REGISTRY_URI", str, None)
```

## 原始行 88 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"resolve_registry\" tests --include='*.py'; grep -RIn \"registry_uri\" tests/tracking --include='*.py' | head -100"
```

退出码：`0`

输出：
```
tests/tracking/_model_registry/test_utils.py:14:    _resolve_registry_uri,
tests/tracking/_model_registry/test_utils.py:208:def test_resolve_registry_uri_consistency_with_get_registry_uri(
tests/tracking/_model_registry/test_utils.py:211:    """Test that _resolve_registry_uri behaves consistently with get_registry_uri"""
tests/tracking/_model_registry/test_utils.py:218:        result = _resolve_registry_uri(registry_uri_param, tracking_uri)
tests/tracking/_model_registry/test_utils.py:224:def test_resolve_registry_uri_with_environment_variable():
tests/tracking/_model_registry/test_utils.py:240:        result = _resolve_registry_uri(None, tracking_uri)
tests/tracking/_model_registry/test_utils.py:244:def test_resolve_registry_uri_with_spark_session():
tests/tracking/_model_registry/test_utils.py:261:        result = _resolve_registry_uri(None, tracking_uri)
tests/tracking/test_client.py:63:from mlflow.tracking import set_registry_uri
tests/tracking/test_client.py:86:def reset_registry_uri():
tests/tracking/test_client.py:88:    set_registry_uri(None)
tests/tracking/test_client.py:1387:    res = MlflowClient(registry_uri="sqlite:///somedb.db").update_registered_model(
tests/tracking/test_client.py:1402:    res = MlflowClient(registry_uri="sqlite:///somedb.db").create_model_version(
tests/tracking/test_client.py:1423:    res = MlflowClient(registry_uri="sqlite:///somedb.db").update_model_version(
tests/tracking/test_client.py:1439:    actual_result = MlflowClient(registry_uri="sqlite:///somedb.db").transition_model_version_stage(
tests/tracking/test_client.py:1448:def test_registry_uri_set_as_param():
tests/tracking/test_client.py:1450:    client = MlflowClient(tracking_uri="databricks://tracking", registry_uri=uri)
tests/tracking/test_client.py:1451:    assert client._registry_uri == uri
tests/tracking/test_client.py:1454:def test_registry_uri_from_set_registry_uri():
tests/tracking/test_client.py:1456:    set_registry_uri(uri)
tests/tracking/test_client.py:1458:    assert client._registry_uri == uri
tests/tracking/test_client.py:1459:    set_registry_uri(None)
tests/tracking/test_client.py:1462:def test_registry_uri_from_tracking_uri_param():
tests/tracking/test_client.py:1470:        assert client._registry_uri == "databricks-uc://tracking_vhawoierj"
tests/tracking/test_client.py:1473:def test_registry_uri_from_implicit_tracking_uri():
tests/tracking/test_client.py:1481:        assert client._registry_uri == "databricks-uc://tracking_wierojasdf"
tests/tracking/test_client.py:1544:        client = MlflowClient(tracking_uri="databricks", registry_uri="otherplace")
tests/tracking/test_client.py:1572:        client = MlflowClient(tracking_uri="databricks", registry_uri="otherplace")
tests/tracking/test_client.py:1634:        client = MlflowClient(tracking_uri="databricks", registry_uri="databricks-uc")
tests/tracking/test_client.py:1679:        client = MlflowClient(tracking_uri="http://10.123.1231.11", registry_uri="databricks-uc")
tests/tracking/test_client.py:1697:    client = MlflowClient(tracking_uri="databricks", registry_uri="databricks-uc")
tests/tracking/test_client.py:1754:        client = MlflowClient(tracking_uri="databricks", registry_uri="otherplace")
tests/tracking/test_client.py:1775:        registry_uri="databricks://registry:workspace",
tests/tracking/test_client.py:1795:        tracking_uri="https://tracking", registry_uri="databricks://registry:workspace"
tests/tracking/test_client.py:1813:        registry_uri="databricks://registry:workspace",
tests/tracking/test_client.py:1827:    client = MlflowClient(tracking_uri="databricks://tracking", registry_uri="https://registry")
tests/tracking/test_client.py:2058:def registry_uri(request, tmp_path):
tests/tracking/test_client.py:2063:    original_registry_uri = mlflow.get_registry_uri()
tests/tracking/test_client.py:2076:    mlflow.set_tracking_uri(original_registry_uri)
tests/tracking/test_client.py:2278:@pytest.mark.parametrize("registry_uri", ["databricks"])
tests/tracking/test_client.py:2279:def test_crud_prompt_on_unsupported_registry(registry_uri):
tests/tracking/test_client.py:2280:    client = MlflowClient(registry_uri=registry_uri)
tests/tracking/test_client.py:2546:@pytest.mark.parametrize("registry_uri", ["databricks-uc"])
tests/tracking/test_client.py:2547:def test_delete_prompt_with_versions_unity_catalog_error(registry_uri):
tests/tracking/test_client.py:2551:    client = MlflowClient(registry_uri=registry_uri)
tests/tracking/test_client.py:2559:        patch.object(client, "_registry_uri", registry_uri),
tests/tracking/fluent/test_fluent.py:1584:def spark_session_with_registry_uri(request):
tests/tracking/fluent/test_fluent.py:1594:def test_registry_uri_from_spark_conf(
tests/tracking/fluent/test_fluent.py:1595:    spark_session_with_registry_uri, monkeypatch: pytest.MonkeyPatch
tests/tracking/fluent/test_fluent.py:1597:    assert mlflow.get_registry_uri() == "http://custom.uri"
tests/tracking/fluent/test_fluent.py:1601:    assert mlflow.get_registry_uri() == "something-else"
tests/tracking/fluent/test_fluent.py:1759:def test_subprocess_inherit_registry_uri(tmp_path):
tests/tracking/fluent/test_fluent.py:1761:    mlflow.set_registry_uri(sqlite_uri)
tests/tracking/fluent/test_fluent.py:1767:            "import mlflow; print(mlflow.get_registry_uri())",
tests/tracking/_model_registry/test_model_registry_fluent.py:122:    orig_registry_uri = mlflow.get_registry_uri()
tests/tracking/_model_registry/test_model_registry_fluent.py:123:    mlflow.set_registry_uri("databricks-uc")
tests/tracking/_model_registry/test_model_registry_fluent.py:173:    mlflow.set_registry_uri(orig_registry_uri)
tests/tracking/_model_registry/test_model_registry_client.py:35:def newModelRegistryClient(registry_uri="uri:/fake"):
tests/tracking/_model_registry/test_model_registry_client.py:36:    return ModelRegistryClient(registry_uri, "uri:/fake")
tests/tracking/_model_registry/test_utils.py:14:    _resolve_registry_uri,
tests/tracking/_model_registry/test_utils.py:15:    get_registry_uri,
tests/tracking/_model_registry/test_utils.py:16:    set_registry_uri,
tests/tracking/_model_registry/test_utils.py:29:def reset_registry_uri():
tests/tracking/_model_registry/test_utils.py:31:    set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:34:def test_set_get_registry_uri():
tests/tracking/_model_registry/test_utils.py:40:        set_registry_uri(uri)
tests/tracking/_model_registry/test_utils.py:41:        assert get_registry_uri() == uri
tests/tracking/_model_registry/test_utils.py:42:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:45:def test_set_get_empty_registry_uri():
tests/tracking/_model_registry/test_utils.py:50:        set_registry_uri("")
tests/tracking/_model_registry/test_utils.py:51:        assert get_registry_uri() is None
tests/tracking/_model_registry/test_utils.py:52:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:55:def test_default_get_registry_uri_no_tracking_uri():
tests/tracking/_model_registry/test_utils.py:60:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:61:        assert get_registry_uri() is None
tests/tracking/_model_registry/test_utils.py:64:def test_default_get_registry_uri_with_databricks_tracking_uri_defaults_to_uc():
tests/tracking/_model_registry/test_utils.py:70:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:73:        assert get_registry_uri() == "databricks-uc://tracking_werohoz"
tests/tracking/_model_registry/test_utils.py:86:def test_default_registry_uri_non_databricks_tracking_uri(tracking_uri):
tests/tracking/_model_registry/test_utils.py:92:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:94:        assert get_registry_uri() == tracking_uri
tests/tracking/_model_registry/test_utils.py:98:    ("tracking_uri", "expected_registry_uri"),
tests/tracking/_model_registry/test_utils.py:110:def test_databricks_tracking_uri_variations_default_to_uc(tracking_uri, expected_registry_uri):
tests/tracking/_model_registry/test_utils.py:116:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:118:        registry_uri = get_registry_uri()
tests/tracking/_model_registry/test_utils.py:119:        assert registry_uri == expected_registry_uri
tests/tracking/_model_registry/test_utils.py:122:def test_explicit_registry_uri_overrides_databricks_default():
tests/tracking/_model_registry/test_utils.py:125:    explicit_registry_uri = "databricks://different_workspace"
tests/tracking/_model_registry/test_utils.py:131:        set_registry_uri(explicit_registry_uri)
tests/tracking/_model_registry/test_utils.py:133:        assert get_registry_uri() == explicit_registry_uri
tests/tracking/_model_registry/test_utils.py:134:        set_registry_uri(None)  # Reset for other tests
tests/tracking/_model_registry/test_utils.py:137:def test_registry_uri_from_environment_overrides_databricks_default():
tests/tracking/_model_registry/test_utils.py:142:    env_registry_uri = "http://env-registry-server:5000"
tests/tracking/_model_registry/test_utils.py:148:        mock.patch.object(MLFLOW_REGISTRY_URI, "get", return_value=env_registry_uri),
tests/tracking/_model_registry/test_utils.py:151:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:153:        assert get_registry_uri() == env_registry_uri
tests/tracking/_model_registry/test_utils.py:156:def test_registry_uri_from_spark_session_overrides_databricks_default():
tests/tracking/_model_registry/test_utils.py:158:    spark_registry_uri = "databricks-uc://spark_profile"
tests/tracking/_model_registry/test_utils.py:165:            "mlflow.tracking._model_registry.utils._get_registry_uri_from_spark_session"
tests/tracking/_model_registry/test_utils.py:169:        get_spark_uri_mock.return_value = spark_registry_uri
tests/tracking/_model_registry/test_utils.py:170:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:172:        assert get_registry_uri() == spark_registry_uri
tests/tracking/_model_registry/test_utils.py:188:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:189:        result = get_registry_uri()
tests/tracking/_model_registry/test_utils.py:197:    ("tracking_uri", "registry_uri_param", "expected_result"),
tests/tracking/_model_registry/test_utils.py:199:        # (tracking_uri, registry_uri_param, expected_result)
tests/tracking/_model_registry/test_utils.py:208:def test_resolve_registry_uri_consistency_with_get_registry_uri(
tests/tracking/_model_registry/test_utils.py:209:    tracking_uri, registry_uri_param, expected_result
```

## 原始行 89 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"_resolve_registry_uri\\|get_registry_uri\\|set_registry_uri\" mlflow tests --include='*.py' | head -150"
```

退出码：`0`

输出：
```
mlflow/server/handlers.py:480:        registry_utils.set_registry_uri(store_uri)
mlflow/tracking/client.py:213:                defaults to the service set by ``mlflow.tracking.set_registry_uri``. If
mlflow/tracking/client.py:217:        self._registry_uri = registry_utils._resolve_registry_uri(registry_uri, tracking_uri)
mlflow/tracking/client.py:6028:            if client.get_registry_uri().startswith("databricks-uc"):
mlflow/tracking/_tracking_service/utils.py:177:        f"mlflow.set_registry_uri('{_DATABRICKS_UNITY_CATALOG_SCHEME}') or "
mlflow/tracking/_tracking_service/utils.py:178:        f"mlflow.set_registry_uri('{_DATABRICKS_UNITY_CATALOG_SCHEME}://profile_name') where "
mlflow/tracking/_tracking_service/utils.py:181:        f"mlflow.set_registry_uri('{_OSS_UNITY_CATALOG_SCHEME}:http://localhost:8080')."
mlflow/tracking/_model_registry/fluent.py:245:    registry_uri = mlflow.get_registry_uri()
mlflow/tracking/_model_registry/utils.py:34:#  - via a utility method ``mlflow.set_registry_uri``
mlflow/tracking/_model_registry/utils.py:46:def set_registry_uri(uri: str) -> None:
mlflow/tracking/_model_registry/utils.py:65:        mlflow.set_registry_uri("sqlite:////tmp/registry.db")
mlflow/tracking/_model_registry/utils.py:66:        mr_uri = mlflow.get_registry_uri()
mlflow/tracking/_model_registry/utils.py:153:def get_registry_uri() -> str:
mlflow/tracking/_model_registry/utils.py:162:        mr_uri = mlflow.get_registry_uri()
mlflow/tracking/_model_registry/utils.py:178:    return _resolve_registry_uri()
mlflow/tracking/_model_registry/registry.py:47:        resolved_store_uri = _resolve_registry_uri(store_uri)
mlflow/tracking/__init__.py:29:        get_registry_uri,
mlflow/tracking/__init__.py:30:        set_registry_uri,
mlflow/tracking/__init__.py:36:        "get_registry_uri",
mlflow/tracking/__init__.py:37:        "set_registry_uri",
mlflow/utils/doctor.py:80:        ("Registry URI", mlflow.get_registry_uri()),
mlflow/config/__init__.py:12:    get_registry_uri,
mlflow/config/__init__.py:15:    set_registry_uri,
mlflow/config/__init__.py:48:    "get_registry_uri",
mlflow/config/__init__.py:51:    "set_registry_uri",
mlflow/prompt/registry_utils.py:110:    registry_uri = registry_uri or mlflow.get_registry_uri()
mlflow/prompt/registry_utils.py:136:            registry_uri = mlflow.get_registry_uri()
mlflow/models/utils.py:1594:        get_databricks_profile_uri_from_artifact_uri(model_uri) or mlflow.get_registry_uri()
mlflow/models/wheeled_model.py:42:            get_databricks_profile_uri_from_artifact_uri(model_uri) or mlflow.get_registry_uri()
mlflow/__init__.py:246:        get_registry_uri,
mlflow/__init__.py:247:        set_registry_uri,
mlflow/__init__.py:352:        "get_registry_uri",
mlflow/__init__.py:388:        "set_registry_uri",
mlflow/store/artifact/unity_catalog_oss_models_artifact_repo.py:72:                f"mlflow.set_registry_uri('{_OSS_UNITY_CATALOG_SCHEME}') if using the "
mlflow/store/artifact/unity_catalog_models_artifact_repo.py:66:                f"mlflow.set_registry_uri('{_DATABRICKS_UNITY_CATALOG_SCHEME}') if using the "
mlflow/store/artifact/utils/models.py:20:        or mlflow.get_registry_uri()
mlflow/store/artifact/databricks_models_artifact_repo.py:70:            or mlflow.get_registry_uri()
mlflow/store/artifact/models_artifact_repo.py:50:        registry_uri = registry_uri or mlflow.get_registry_uri()
mlflow/store/artifact/models_artifact_repo.py:133:            get_databricks_profile_uri_from_artifact_uri(uri) or mlflow.get_registry_uri()
mlflow/store/model_registry/databricks_workspace_model_registry_rest_store.py:66:        f"mlflow.set_registry_uri('databricks-uc') before accessing models.",
tests/test_cli.py:231:    mlflow.set_registry_uri(None)
tests/test_cli.py:269:    mlflow.set_registry_uri(None)
tests/spark/test_spark_model_export.py:440:        mock.patch("mlflow.get_registry_uri", return_value=registry_uri),
tests/tracking/test_client.py:63:from mlflow.tracking import set_registry_uri
tests/tracking/test_client.py:86:def reset_registry_uri():
tests/tracking/test_client.py:88:    set_registry_uri(None)
tests/tracking/test_client.py:1454:def test_registry_uri_from_set_registry_uri():
tests/tracking/test_client.py:1456:    set_registry_uri(uri)
tests/tracking/test_client.py:1459:    set_registry_uri(None)
tests/tracking/test_client.py:2063:    original_registry_uri = mlflow.get_registry_uri()
tests/tracking/fluent/test_fluent.py:1597:    assert mlflow.get_registry_uri() == "http://custom.uri"
tests/tracking/fluent/test_fluent.py:1601:    assert mlflow.get_registry_uri() == "something-else"
tests/tracking/fluent/test_fluent.py:1761:    mlflow.set_registry_uri(sqlite_uri)
tests/tracking/fluent/test_fluent.py:1767:            "import mlflow; print(mlflow.get_registry_uri())",
tests/tracking/_model_registry/test_model_registry_fluent.py:122:    orig_registry_uri = mlflow.get_registry_uri()
tests/tracking/_model_registry/test_model_registry_fluent.py:123:    mlflow.set_registry_uri("databricks-uc")
tests/tracking/_model_registry/test_model_registry_fluent.py:173:    mlflow.set_registry_uri(orig_registry_uri)
tests/tracking/_model_registry/test_utils.py:14:    _resolve_registry_uri,
tests/tracking/_model_registry/test_utils.py:15:    get_registry_uri,
tests/tracking/_model_registry/test_utils.py:16:    set_registry_uri,
tests/tracking/_model_registry/test_utils.py:29:def reset_registry_uri():
tests/tracking/_model_registry/test_utils.py:31:    set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:34:def test_set_get_registry_uri():
tests/tracking/_model_registry/test_utils.py:40:        set_registry_uri(uri)
tests/tracking/_model_registry/test_utils.py:41:        assert get_registry_uri() == uri
tests/tracking/_model_registry/test_utils.py:42:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:50:        set_registry_uri("")
tests/tracking/_model_registry/test_utils.py:51:        assert get_registry_uri() is None
tests/tracking/_model_registry/test_utils.py:52:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:55:def test_default_get_registry_uri_no_tracking_uri():
tests/tracking/_model_registry/test_utils.py:60:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:61:        assert get_registry_uri() is None
tests/tracking/_model_registry/test_utils.py:64:def test_default_get_registry_uri_with_databricks_tracking_uri_defaults_to_uc():
tests/tracking/_model_registry/test_utils.py:70:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:73:        assert get_registry_uri() == "databricks-uc://tracking_werohoz"
tests/tracking/_model_registry/test_utils.py:92:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:94:        assert get_registry_uri() == tracking_uri
tests/tracking/_model_registry/test_utils.py:116:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:118:        registry_uri = get_registry_uri()
tests/tracking/_model_registry/test_utils.py:131:        set_registry_uri(explicit_registry_uri)
tests/tracking/_model_registry/test_utils.py:133:        assert get_registry_uri() == explicit_registry_uri
tests/tracking/_model_registry/test_utils.py:134:        set_registry_uri(None)  # Reset for other tests
tests/tracking/_model_registry/test_utils.py:151:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:153:        assert get_registry_uri() == env_registry_uri
tests/tracking/_model_registry/test_utils.py:165:            "mlflow.tracking._model_registry.utils._get_registry_uri_from_spark_session"
tests/tracking/_model_registry/test_utils.py:170:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:172:        assert get_registry_uri() == spark_registry_uri
tests/tracking/_model_registry/test_utils.py:188:        set_registry_uri(None)
tests/tracking/_model_registry/test_utils.py:189:        result = get_registry_uri()
tests/tracking/_model_registry/test_utils.py:208:def test_resolve_registry_uri_consistency_with_get_registry_uri(
tests/tracking/_model_registry/test_utils.py:211:    """Test that _resolve_registry_uri behaves consistently with get_registry_uri"""
tests/tracking/_model_registry/test_utils.py:216:        set_registry_uri(None)  # Clear context
tests/tracking/_model_registry/test_utils.py:218:        result = _resolve_registry_uri(registry_uri_param, tracking_uri)
tests/tracking/_model_registry/test_utils.py:224:def test_resolve_registry_uri_with_environment_variable():
tests/tracking/_model_registry/test_utils.py:237:        set_registry_uri(None)  # Clear explicit setting
tests/tracking/_model_registry/test_utils.py:240:        result = _resolve_registry_uri(None, tracking_uri)
tests/tracking/_model_registry/test_utils.py:244:def test_resolve_registry_uri_with_spark_session():
tests/tracking/_model_registry/test_utils.py:253:            "mlflow.tracking._model_registry.utils._get_registry_uri_from_spark_session"
tests/tracking/_model_registry/test_utils.py:258:        set_registry_uri(None)  # Clear explicit setting
tests/tracking/_model_registry/test_utils.py:261:        result = _resolve_registry_uri(None, tracking_uri)
tests/uc_oss/test_uc_oss_integration.py:43:            mlflow.set_registry_uri(uc_oss_url)
tests/conftest.py:566:            from mlflow.tracking import set_registry_uri
tests/conftest.py:569:            set_registry_uri(None)
tests/store/lineage/test_downstream_lineage.py:104:        mock.patch("mlflow.get_registry_uri", return_value="databricks-uc"),
tests/store/artifact/test_models_artifact_repo.py:68:            "mlflow.store.artifact.utils.models.mlflow.get_registry_uri",
tests/store/artifact/test_models_artifact_repo.py:89:        mock.patch("mlflow.get_registry_uri", return_value=uc_registry_uri),
tests/store/artifact/test_models_artifact_repo.py:106:        mock.patch("mlflow.get_registry_uri", return_value=uc_registry_uri),
tests/store/artifact/test_models_artifact_repo.py:126:            "mlflow.store.artifact.utils.models.mlflow.get_registry_uri",
tests/store/artifact/test_databricks_models_artifact_repo.py:99:            "mlflow.store.artifact.utils.models.mlflow.get_registry_uri",
tests/store/artifact/test_databricks_models_artifact_repo.py:102:        mock.patch("mlflow.tracking.get_registry_uri", return_value=MOCK_PROFILE),
tests/store/artifact/test_databricks_models_artifact_repo.py:133:            "mlflow.store.artifact.utils.models.mlflow.get_registry_uri",
tests/store/artifact/test_databricks_models_artifact_repo.py:136:        mock.patch("mlflow.tracking.get_registry_uri", return_value=MOCK_PROFILE),
tests/store/artifact/test_databricks_models_artifact_repo.py:150:    # Mock for `is_using_databricks_registry` fail when calling `get_registry_uri`
tests/store/artifact/test_databricks_models_artifact_repo.py:152:        "mlflow.store.artifact.utils.models.mlflow.get_registry_uri",
tests/store/model_registry/test_file_store.py:1564:    mlflow.set_registry_uri(path_to_local_file_uri(store.root_directory))
tests/store/_unity_catalog/conftest.py:47:        orig_registry_uri = mlflow.get_registry_uri()
tests/store/_unity_catalog/conftest.py:48:        mlflow.set_registry_uri("databricks-uc")
tests/store/_unity_catalog/conftest.py:50:        mlflow.set_registry_uri(orig_registry_uri)
```

## 原始行 92 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,290p' tests/tracking/_model_registry/test_utils.py"
```

退出码：`0`

输出：
```
import io
import pickle
from unittest import mock

import pytest

from mlflow.environment_variables import MLFLOW_TRACKING_URI
from mlflow.store._unity_catalog.registry.rest_store import UcModelRegistryStore
from mlflow.store.db.db_types import DATABASE_ENGINES
from mlflow.store.model_registry.rest_store import RestStore
from mlflow.store.model_registry.sqlalchemy_store import SqlAlchemyStore
from mlflow.tracking._model_registry.utils import (
    _get_store,
    _resolve_registry_uri,
    get_registry_uri,
    set_registry_uri,
)
from mlflow.tracking.registry import UnsupportedModelRegistryStoreURIException

# Disable mocking tracking URI here, as we want to test setting the tracking URI via
# environment variable. See
# http://doc.pytest.org/en/latest/skipping.html#skip-all-test-functions-of-a-class-or-module
# and https://github.com/mlflow/mlflow/blob/master/CONTRIBUTING.md#writing-python-tests
# for more information.
pytestmark = pytest.mark.notrackingurimock


@pytest.fixture
def reset_registry_uri():
    yield
    set_registry_uri(None)


def test_set_get_registry_uri():
    with mock.patch(
        "mlflow.tracking._model_registry.utils._resolve_tracking_uri"
    ) as get_tracking_uri_mock:
        get_tracking_uri_mock.return_value = "databricks://tracking_sldkfj"
        uri = "databricks://registry/path"
        set_registry_uri(uri)
        assert get_registry_uri() == uri
        set_registry_uri(None)


def test_set_get_empty_registry_uri():
    with mock.patch(
        "mlflow.tracking._model_registry.utils._resolve_tracking_uri"
    ) as get_tracking_uri_mock:
        get_tracking_uri_mock.return_value = None
        set_registry_uri("")
        assert get_registry_uri() is None
        set_registry_uri(None)


def test_default_get_registry_uri_no_tracking_uri():
    with mock.patch(
        "mlflow.tracking._model_registry.utils._resolve_tracking_uri"
    ) as get_tracking_uri_mock:
        get_tracking_uri_mock.return_value = None
        set_registry_uri(None)
        assert get_registry_uri() is None


def test_default_get_registry_uri_with_databricks_tracking_uri_defaults_to_uc():
    tracking_uri = "databricks://tracking_werohoz"
    with mock.patch(
        "mlflow.tracking._model_registry.utils._resolve_tracking_uri"
    ) as resolve_tracking_uri_mock:
        resolve_tracking_uri_mock.return_value = tracking_uri
        set_registry_uri(None)
        # Should default to Unity Catalog when tracking URI starts with 'databricks'
        # and include the profile when present
        assert get_registry_uri() == "databricks-uc://tracking_werohoz"


@pytest.mark.parametrize(
    "tracking_uri",
    [
        "http://localhost:5000",
        "https://remote-server.com",
        "sqlite:///path/to/db.sqlite",
        "postgresql://user:pass@localhost/db",
        "file:///local/path",
    ],
)
def test_default_registry_uri_non_databricks_tracking_uri(tracking_uri):
    """Test that non-databricks tracking URIs are used directly as registry URI"""
    with mock.patch(
        "mlflow.tracking._tracking_service.utils.get_tracking_uri"
    ) as get_tracking_uri_mock:
        get_tracking_uri_mock.return_value = tracking_uri
        set_registry_uri(None)
        # Non-databricks URIs should be used directly as registry URI
        assert get_registry_uri() == tracking_uri


@pytest.mark.parametrize(
    ("tracking_uri", "expected_registry_uri"),
    [
        ("databricks", "databricks-uc"),
        ("databricks://profile", "databricks-uc://profile"),
        ("databricks://profile_name", "databricks-uc://profile_name"),
        ("databricks://workspace_url", "databricks-uc://workspace_url"),
        (
            "databricks://some.databricks.workspace.com",
            "databricks-uc://some.databricks.workspace.com",
        ),
    ],
)
def test_databricks_tracking_uri_variations_default_to_uc(tracking_uri, expected_registry_uri):
    """Test that various databricks tracking URI formats default to databricks-uc"""
    with mock.patch(
        "mlflow.tracking._tracking_service.utils.get_tracking_uri"
    ) as get_tracking_uri_mock:
        get_tracking_uri_mock.return_value = tracking_uri
        set_registry_uri(None)
        # All databricks tracking URIs should default to Unity Catalog
        registry_uri = get_registry_uri()
        assert registry_uri == expected_registry_uri


def test_explicit_registry_uri_overrides_databricks_default():
    """Test that explicitly set registry URI takes precedence over databricks default"""
    tracking_uri = "databricks://workspace"
    explicit_registry_uri = "databricks://different_workspace"

    with mock.patch(
        "mlflow.tracking._tracking_service.utils.get_tracking_uri"
    ) as get_tracking_uri_mock:
        get_tracking_uri_mock.return_value = tracking_uri
        set_registry_uri(explicit_registry_uri)
        # Explicit registry URI should override the databricks-uc default
        assert get_registry_uri() == explicit_registry_uri
        set_registry_uri(None)  # Reset for other tests


def test_registry_uri_from_environment_overrides_databricks_default():
    """Test that registry URI from environment variable overrides databricks default"""
    from mlflow.environment_variables import MLFLOW_REGISTRY_URI

    tracking_uri = "databricks://workspace"
    env_registry_uri = "http://env-registry-server:5000"

    with (
        mock.patch(
            "mlflow.tracking._tracking_service.utils.get_tracking_uri"
        ) as get_tracking_uri_mock,
        mock.patch.object(MLFLOW_REGISTRY_URI, "get", return_value=env_registry_uri),
    ):
        get_tracking_uri_mock.return_value = tracking_uri
        set_registry_uri(None)
        # Environment variable should override the databricks-uc default
        assert get_registry_uri() == env_registry_uri


def test_registry_uri_from_spark_session_overrides_databricks_default():
    tracking_uri = "databricks://workspace"
    spark_registry_uri = "databricks-uc://spark_profile"

    with (
        mock.patch(
            "mlflow.tracking._tracking_service.utils.get_tracking_uri"
        ) as get_tracking_uri_mock,
        mock.patch(
            "mlflow.tracking._model_registry.utils._get_registry_uri_from_spark_session"
        ) as get_spark_uri_mock,
    ):
        get_tracking_uri_mock.return_value = tracking_uri
        get_spark_uri_mock.return_value = spark_registry_uri
        set_registry_uri(None)
        # Spark session URI should override the databricks-uc default
        assert get_registry_uri() == spark_registry_uri


@pytest.mark.parametrize(
    ("tracking_uri", "expected_result"),
    [
        ("mydatabricks://custom", None),  # Should not match partial
        ("databricks", "databricks-uc"),  # Should match exact
        ("", None),  # Empty string should return None
    ],
)
def test_edge_cases_for_databricks_uri_detection(tracking_uri, expected_result):
    with mock.patch(
        "mlflow.tracking._tracking_service.utils.get_tracking_uri"
    ) as get_tracking_uri_mock:
        get_tracking_uri_mock.return_value = tracking_uri
        set_registry_uri(None)
        result = get_registry_uri()
        if expected_result is None:
            assert result == tracking_uri  # Should fallback to tracking URI
        else:
            assert result == expected_result


@pytest.mark.parametrize(
    ("tracking_uri", "registry_uri_param", "expected_result"),
    [
        # (tracking_uri, registry_uri_param, expected_result)
        ("databricks://workspace", None, "databricks-uc://workspace"),
        ("databricks", None, "databricks-uc"),
        ("http://localhost:5000", None, "http://localhost:5000"),
        ("databricks://workspace", "explicit://registry", "explicit://registry"),
        (None, None, None),
        ("", None, ""),
    ],
)
def test_resolve_registry_uri_consistency_with_get_registry_uri(
    tracking_uri, registry_uri_param, expected_result
):
    """Test that _resolve_registry_uri behaves consistently with get_registry_uri"""
    with mock.patch(
        "mlflow.tracking._model_registry.utils._resolve_tracking_uri"
    ) as mock_resolve_tracking:
        mock_resolve_tracking.return_value = tracking_uri
        set_registry_uri(None)  # Clear context

        result = _resolve_registry_uri(registry_uri_param, tracking_uri)
        assert result == expected_result, (
            f"Failed for tracking_uri={tracking_uri}, registry_uri={registry_uri_param}"
        )


def test_resolve_registry_uri_with_environment_variable():
    from mlflow.environment_variables import MLFLOW_REGISTRY_URI

    env_registry_uri = "http://env-registry:5000"
    tracking_uri = "databricks://workspace"

    with (
        mock.patch(
            "mlflow.tracking._model_registry.utils._resolve_tracking_uri"
        ) as mock_resolve_tracking,
        mock.patch.object(MLFLOW_REGISTRY_URI, "get", return_value=env_registry_uri),
    ):
        mock_resolve_tracking.return_value = tracking_uri
        set_registry_uri(None)  # Clear explicit setting

        # Environment variable should override databricks default
        result = _resolve_registry_uri(None, tracking_uri)
        assert result == env_registry_uri


def test_resolve_registry_uri_with_spark_session():
    spark_registry_uri = "databricks-uc://spark_profile"
    tracking_uri = "databricks://workspace"

    with (
        mock.patch(
            "mlflow.tracking._model_registry.utils._resolve_tracking_uri"
        ) as mock_resolve_tracking,
        mock.patch(
            "mlflow.tracking._model_registry.utils._get_registry_uri_from_spark_session"
        ) as mock_spark_uri,
    ):
        mock_resolve_tracking.return_value = tracking_uri
        mock_spark_uri.return_value = spark_registry_uri
        set_registry_uri(None)  # Clear explicit setting

        # Spark session URI should override databricks default
        result = _resolve_registry_uri(None, tracking_uri)
        assert result == spark_registry_uri


def test_get_store_rest_store_from_arg(monkeypatch):
    monkeypatch.setenv(MLFLOW_TRACKING_URI.name, "https://my-tracking-server:5050")
    store = _get_store("http://some/path")
    assert isinstance(store, RestStore)
    assert store.get_host_creds().host == "http://some/path"


def test_fallback_to_tracking_store(monkeypatch):
    monkeypatch.setenv(MLFLOW_TRACKING_URI.name, "https://my-tracking-server:5050")
    store = _get_store()
    assert isinstance(store, RestStore)
    assert store.get_host_creds().host == "https://my-tracking-server:5050"
    assert store.get_host_creds().token is None


@pytest.mark.parametrize("db_type", DATABASE_ENGINES)
def test_get_store_sqlalchemy_store(db_type, monkeypatch):
    uri = f"{db_type}://hostname/database"
    monkeypatch.setenv(MLFLOW_TRACKING_URI.name, uri)
    monkeypatch.delenv("MLFLOW_SQLALCHEMYSTORE_POOLCLASS", raising=False)
    with (
        mock.patch("sqlalchemy.create_engine") as mock_create_engine,
        mock.patch("sqlalchemy.event.listens_for"),
        mock.patch("mlflow.store.db.utils._initialize_tables"),
        mock.patch(
            "mlflow.store.model_registry.sqlalchemy_store.SqlAlchemyStore."
```

## 原始行 94 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' mlflow/tracking/_tracking_service/utils.py"
```

退出码：`0`

输出：
```
import logging
import os
from collections import OrderedDict
from contextlib import contextmanager
from functools import lru_cache, partial
from pathlib import Path
from typing import Generator

from mlflow.environment_variables import MLFLOW_TRACKING_URI
from mlflow.store.db.db_types import DATABASE_ENGINES
from mlflow.store.tracking import DEFAULT_LOCAL_FILE_AND_ARTIFACT_PATH
from mlflow.store.tracking.databricks_rest_store import DatabricksTracingRestStore
from mlflow.store.tracking.rest_store import RestStore
from mlflow.tracing.provider import reset
from mlflow.tracking._tracking_service.registry import TrackingStoreRegistry

from mlflow.utils.databricks_utils import get_databricks_host_creds
from mlflow.utils.file_utils import path_to_local_file_uri
from mlflow.utils.uri import (
    _DATABRICKS_UNITY_CATALOG_SCHEME,
    _OSS_UNITY_CATALOG_SCHEME,
    get_uri_scheme,
)

_logger = logging.getLogger(__name__)
_tracking_uri = None


def is_tracking_uri_set():
    """Returns True if the tracking URI has been set, False otherwise."""
    if _tracking_uri or MLFLOW_TRACKING_URI.get():
        return True
    return False


def set_tracking_uri(uri: str | Path) -> None:
    """
    Set the tracking server URI. This does not affect the
    currently active run (if one exists), but takes effect for successive runs.

    Args:
        uri:

            - An empty string, or a local file path, prefixed with ``file:/``. Data is stored
              locally at the provided file (or ``./mlruns`` if empty).
            - An HTTP URI like ``https://my-tracking-server:5000``.
            - A Databricks workspace, provided as the string "databricks" or, to use a Databricks
              CLI `profile <https://github.com/databricks/databricks-cli#installation>`_,
              "databricks://<profileName>".
            - A :py:class:`pathlib.Path` instance

    .. code-block:: python
        :test:
        :caption: Example

        import mlflow

        mlflow.set_tracking_uri("file:///tmp/my_tracking")
        tracking_uri = mlflow.get_tracking_uri()
        print(f"Current tracking uri: {tracking_uri}")

    .. code-block:: text
        :caption: Output

        Current tracking uri: file:///tmp/my_tracking
    """
    if isinstance(uri, Path):
        # On Windows with Python3.8 (https://bugs.python.org/issue38671)
        # .resolve() doesn't return the absolute path if the directory doesn't exist
        # so we're calling .absolute() first to get the absolute path on Windows,
        # then .resolve() to clean the path
        uri = uri.absolute().resolve().as_uri()
    global _tracking_uri

    if _tracking_uri != uri:
        _tracking_uri = uri
        if _tracking_uri is not None:
            # Set 'MLFLOW_TRACKING_URI' environment variable
            # so that subprocess can inherit it.
            MLFLOW_TRACKING_URI.set(_tracking_uri)
        else:
            MLFLOW_TRACKING_URI.unset()

        # Tracer provider uses tracking URI to determine where to export traces.
        # Tracer provider stores the URI as its state so we need to reset
        # it explicitly when the global tracking URI changes.
        reset()


@contextmanager
def _use_tracking_uri(uri: str) -> Generator[None, None, None]:
    """Temporarily use the specified tracking URI.

    Args:
        uri: The tracking URI to use.

    """
    old_tracking_uri = _tracking_uri
    try:
        set_tracking_uri(uri)
        yield
    finally:
        set_tracking_uri(old_tracking_uri)


def _resolve_tracking_uri(tracking_uri=None):
    return tracking_uri or get_tracking_uri()


def get_tracking_uri() -> str:
    """Get the current tracking URI. This may not correspond to the tracking URI of
    the currently active run, since the tracking URI can be updated via ``set_tracking_uri``.

    Returns:
        The tracking URI.

    .. code-block:: python

        import mlflow

        # Get the current tracking uri
        tracking_uri = mlflow.get_tracking_uri()
        print(f"Current tracking uri: {tracking_uri}")

    .. code-block:: text

        Current tracking uri: file:///.../mlruns
    """
    if _tracking_uri is not None:
        return _tracking_uri
    elif uri := MLFLOW_TRACKING_URI.get():
        return uri
    else:
        return path_to_local_file_uri(os.path.abspath(DEFAULT_LOCAL_FILE_AND_ARTIFACT_PATH))


def _get_file_store(store_uri, **_):
    from mlflow.store.tracking.file_store import FileStore

    return FileStore(store_uri, store_uri)


def _get_sqlalchemy_store(store_uri, artifact_uri):
    from mlflow.store.tracking.sqlalchemy_store import SqlAlchemyStore

    if artifact_uri is None:
        artifact_uri = DEFAULT_LOCAL_FILE_AND_ARTIFACT_PATH
    return SqlAlchemyStore(store_uri, artifact_uri)


def _get_rest_store(store_uri, **_):
    return RestStore(partial(get_default_host_creds, store_uri))


def _get_databricks_rest_store(store_uri, **_):
    return DatabricksTracingRestStore(partial(get_databricks_host_creds, store_uri))


def _get_databricks_uc_rest_store(store_uri, **_):
    from mlflow.exceptions import MlflowException
    from mlflow.version import VERSION

    supported_schemes = [
        scheme
        for scheme in _tracking_store_registry._registry
        if scheme not in {_DATABRICKS_UNITY_CATALOG_SCHEME, _OSS_UNITY_CATALOG_SCHEME}
    ]
    raise MlflowException(
        f"Detected Unity Catalog tracking URI '{store_uri}'. "
        "Setting the tracking URI to a Unity Catalog backend is not supported in the current "
        f"version of the MLflow client ({VERSION}). "
        "Please specify a different tracking URI via mlflow.set_tracking_uri, with "
        "one of the supported schemes: "
        f"{supported_schemes}. If you're trying to access models in the Unity "
        "Catalog, please upgrade to the latest version of the MLflow Python "
        "client, then specify a Unity Catalog model registry URI via "
        f"mlflow.set_registry_uri('{_DATABRICKS_UNITY_CATALOG_SCHEME}') or "
        f"mlflow.set_registry_uri('{_DATABRICKS_UNITY_CATALOG_SCHEME}://profile_name') where "
        "'profile_name' is the name of the Databricks CLI profile to use for "
        "authentication. A OSS Unity Catalog model registry URI can also be specified via "
        f"mlflow.set_registry_uri('{_OSS_UNITY_CATALOG_SCHEME}:http://localhost:8080')."
        "Be sure to leave the registry URI configured to use one of the supported"
        "schemes listed above."
    )


_tracking_store_registry = TrackingStoreRegistry()


def _register_tracking_stores():
    _tracking_store_registry.register("", _get_file_store)
    _tracking_store_registry.register("file", _get_file_store)
    _tracking_store_registry.register("databricks", _get_databricks_rest_store)
    _tracking_store_registry.register(
        _DATABRICKS_UNITY_CATALOG_SCHEME, _get_databricks_uc_rest_store
    )
    _tracking_store_registry.register(_OSS_UNITY_CATALOG_SCHEME, _get_databricks_uc_rest_store)

    for scheme in ["http", "https"]:
        _tracking_store_registry.register(scheme, _get_rest_store)

    for scheme in DATABASE_ENGINES:
        _tracking_store_registry.register(scheme, _get_sqlalchemy_store)

    _tracking_store_registry.register_entrypoints()


def _register(scheme, builder):
    _tracking_store_registry.register(scheme, builder)


_register_tracking_stores()


def _get_store(store_uri=None, artifact_uri=None):
    return _tracking_store_registry.get_store(store_uri, artifact_uri)


def _get_tracking_scheme(store_uri=None) -> str:
    resolved_store_uri = _resolve_tracking_uri(store_uri)
    return _get_tracking_scheme_with_resolved_uri(resolved_store_uri)


@lru_cache(maxsize=100)
def _get_tracking_scheme_with_resolved_uri(resolved_store_uri: str) -> str:
    scheme = (
        resolved_store_uri
        if resolved_store_uri in {"databricks", "databricks-uc", "uc"}
        else get_uri_scheme(resolved_store_uri)
    )
    builder = _tracking_store_registry._registry.get(scheme)
    if builder is None:
        return "None"
    if builder.__module__.split(".", 1)[0] != "mlflow":
        return "custom_scheme"
    return scheme


_artifact_repos_cache = OrderedDict()
```

## 原始行 96 · command_execution

命令：
```
/bin/bash -lc "sed -n '1435,1490p' tests/tracking/test_client.py; sed -n '1575,1610p' tests/tracking/fluent/test_fluent.py"
```

退出码：`0`

输出：
```
    version = "12"
    stage = "Production"
    expected_result = ModelVersion(name, version, creation_timestamp=123, current_stage=stage)
    mock_registry_store.transition_model_version_stage.return_value = expected_result
    actual_result = MlflowClient(registry_uri="sqlite:///somedb.db").transition_model_version_stage(
        name, version, stage
    )
    mock_registry_store.transition_model_version_stage.assert_called_once_with(
        name=name, version=version, stage=stage, archive_existing_versions=False
    )
    assert expected_result == actual_result


def test_registry_uri_set_as_param():
    uri = "sqlite:///somedb.db"
    client = MlflowClient(tracking_uri="databricks://tracking", registry_uri=uri)
    assert client._registry_uri == uri


def test_registry_uri_from_set_registry_uri():
    uri = "sqlite:///somedb.db"
    set_registry_uri(uri)
    client = MlflowClient(tracking_uri="databricks://tracking")
    assert client._registry_uri == uri
    set_registry_uri(None)


def test_registry_uri_from_tracking_uri_param():
    tracking_uri = "databricks://tracking_vhawoierj"
    with mock.patch(
        "mlflow.tracking._tracking_service.utils.get_tracking_uri",
        return_value=tracking_uri,
    ):
        client = MlflowClient(tracking_uri=tracking_uri)
        # For databricks tracking URIs, registry URI defaults to Unity Catalog with profile
        assert client._registry_uri == "databricks-uc://tracking_vhawoierj"


def test_registry_uri_from_implicit_tracking_uri():
    tracking_uri = "databricks://tracking_wierojasdf"
    with mock.patch(
        "mlflow.tracking._tracking_service.utils.get_tracking_uri",
        return_value=tracking_uri,
    ):
        client = MlflowClient()
        # For databricks tracking URIs, registry URI defaults to Unity Catalog with profile
        assert client._registry_uri == "databricks-uc://tracking_wierojasdf"


def test_create_model_version_nondatabricks_source_no_runlink(mock_registry_store):
    run_id = "runid"
    client = MlflowClient(tracking_uri="http://10.123.1231.11")
    mock_registry_store.create_model_version.return_value = ModelVersion(
        "name",
        1,
        0,
        run_operation.wait()
    parent_run = mlflow.get_run(parent.info.run_id)
    assert parent_run.info.run_id == parent.info.run_id
    assert parent_run.data.tags["async single tag"] == "1"
    for num in range(100):
        assert parent_run.data.tags[f"async batch tag {num}"] == str(num)


@pytest.fixture
def spark_session_with_registry_uri(request):
    with mock.patch(
        "mlflow.tracking._model_registry.utils._get_active_spark_session"
    ) as spark_session_getter:
        spark = mock.MagicMock()
        spark_session_getter.return_value = spark
        spark.conf.get.side_effect = lambda key, _: "http://custom.uri"
        yield spark


def test_registry_uri_from_spark_conf(
    spark_session_with_registry_uri, monkeypatch: pytest.MonkeyPatch
):
    assert mlflow.get_registry_uri() == "http://custom.uri"
    # The MLFLOW_REGISTRY_URI environment variable should still take precedence over the
    # spark conf if present
    monkeypatch.setenv(MLFLOW_REGISTRY_URI.name, "something-else")
    assert mlflow.get_registry_uri() == "something-else"


def test_set_experiment_thread_safety(tmp_path):
    sqlite_uri = "sqlite:///{}".format(tmp_path.joinpath("test.db"))
    mlflow.set_tracking_uri(sqlite_uri)

    origin_create_experiment = MlflowClient.create_experiment

    def patched_create_experiment(self, *args, **kwargs):
```

## 原始行 98 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"_get_.*_from_spark_session\\|spark.mlflow.modelRegistryUri\\|modelRegistryUri\" mlflow tests --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/utils/_spark_utils.py:40:def _get_spark_scala_version_from_spark_session(spark):
mlflow/utils/_spark_utils.py:50:        scala_version = _get_spark_scala_version_from_spark_session(spark_session)
mlflow/utils/_spark_utils.py:61:        return _get_spark_scala_version_from_spark_session(spark)
tests/tracking/_model_registry/test_utils.py:165:            "mlflow.tracking._model_registry.utils._get_registry_uri_from_spark_session"
tests/tracking/_model_registry/test_utils.py:253:            "mlflow.tracking._model_registry.utils._get_registry_uri_from_spark_session"
```

## 原始行 101 · command_execution

命令：
```
/bin/bash -lc "grep -n \"def construct_db_uc_uri_from_profile\\|def is_databricks_uri\" mlflow/utils/uri.py; grep -n \"def warn_on_deprecated_cross_workspace_registry_uri\\|def is_in_databricks_serverless_runtime\" mlflow/utils/databricks_utils.py"
```

退出码：`0`

输出：
```
82:def is_databricks_uri(uri):
141:def construct_db_uc_uri_from_profile(profile):
262:def is_in_databricks_serverless_runtime():
630:def warn_on_deprecated_cross_workspace_registry_uri(registry_uri):
```

## 原始行 104 · command_execution

命令：
```
/bin/bash -lc "sed -n '260,430p' tests/tracking/_model_registry/test_utils.py"
```

退出码：`0`

输出：
```
        # Spark session URI should override databricks default
        result = _resolve_registry_uri(None, tracking_uri)
        assert result == spark_registry_uri


def test_get_store_rest_store_from_arg(monkeypatch):
    monkeypatch.setenv(MLFLOW_TRACKING_URI.name, "https://my-tracking-server:5050")
    store = _get_store("http://some/path")
    assert isinstance(store, RestStore)
    assert store.get_host_creds().host == "http://some/path"


def test_fallback_to_tracking_store(monkeypatch):
    monkeypatch.setenv(MLFLOW_TRACKING_URI.name, "https://my-tracking-server:5050")
    store = _get_store()
    assert isinstance(store, RestStore)
    assert store.get_host_creds().host == "https://my-tracking-server:5050"
    assert store.get_host_creds().token is None


@pytest.mark.parametrize("db_type", DATABASE_ENGINES)
def test_get_store_sqlalchemy_store(db_type, monkeypatch):
    uri = f"{db_type}://hostname/database"
    monkeypatch.setenv(MLFLOW_TRACKING_URI.name, uri)
    monkeypatch.delenv("MLFLOW_SQLALCHEMYSTORE_POOLCLASS", raising=False)
    with (
        mock.patch("sqlalchemy.create_engine") as mock_create_engine,
        mock.patch("sqlalchemy.event.listens_for"),
        mock.patch("mlflow.store.db.utils._initialize_tables"),
        mock.patch(
            "mlflow.store.model_registry.sqlalchemy_store.SqlAlchemyStore."
            "_verify_registry_tables_exist"
        ),
    ):
        store = _get_store()
        assert isinstance(store, SqlAlchemyStore)
        assert store.db_uri == uri

    mock_create_engine.assert_called_once_with(uri, pool_pre_ping=True)


@pytest.mark.parametrize("bad_uri", ["badsql://imfake", "yoursql://hi"])
def test_get_store_bad_uris(bad_uri, monkeypatch):
    monkeypatch.setenv(MLFLOW_TRACKING_URI.name, bad_uri)
    with pytest.raises(
        UnsupportedModelRegistryStoreURIException,
        match="Model registry functionality is unavailable",
    ):
        _get_store()


def test_get_store_caches_on_store_uri(tmp_path):
    store_uri_1 = f"sqlite:///{tmp_path.joinpath('store1.db')}"
    store_uri_2 = f"sqlite:///{tmp_path.joinpath('store2.db')}"

    store1 = _get_store(store_uri_1)
    store2 = _get_store(store_uri_1)
    assert store1 is store2

    store3 = _get_store(store_uri_2)
    store4 = _get_store(store_uri_2)
    assert store3 is store4

    assert store1 is not store3


@pytest.mark.parametrize("store_uri", ["databricks-uc", "databricks-uc://profile"])
def test_get_store_uc_registry_uri(store_uri):
    assert isinstance(_get_store(store_uri), UcModelRegistryStore)


def test_store_object_can_be_serialized_by_pickle():
    """
    This test ensures a store object generated by `_get_store` can be serialized by pickle
    to prevent issues such as https://github.com/mlflow/mlflow/issues/2954
    """
    pickle.dump(_get_store("https://example.com"), io.BytesIO())
    pickle.dump(_get_store("databricks"), io.BytesIO())
    # pickle.dump(_get_store(f"sqlite:///{tmpdir.strpath}/mlflow.db"), io.BytesIO())
    # This throws `AttributeError: Can't pickle local object 'create_engine.<locals>.connect'`
```

## 原始行 105 · command_execution

命令：
```
/bin/bash -lc "sed -n '80,150p' mlflow/utils/uri.py; grep -n -A45 -B5 \"def warn_on_deprecated_cross_workspace_registry_uri\" mlflow/utils/databricks_utils.py; grep -n -A25 -B5 \"def is_in_databricks_serverless_runtime\" mlflow/utils/databricks_utils.py"
```

退出码：`0`

输出：
```


def is_databricks_uri(uri):
    """
    Databricks URIs look like 'databricks' (default profile) or 'databricks://profile'
    or 'databricks://secret_scope:secret_key_prefix'.
    """
    scheme = urllib.parse.urlparse(uri).scheme
    return scheme == "databricks" or uri == "databricks"


def is_fuse_or_uc_volumes_uri(uri):
    """
    Validates whether a provided URI is directed to a FUSE mount point or a UC volumes mount point.
    Multiple directory paths are collapsed into a single designator for root path validation.
    For example, "////Volumes/" will resolve to "/Volumes/" for validation purposes.
    """
    resolved_uri = re.sub("/+", "/", uri).lower()
    return any(
        resolved_uri.startswith(x.lower())
        for x in [
            _DBFS_FUSE_PREFIX,
            _DBFS_HDFS_URI_PREFIX,
            _uc_volume_URI_PREFIX,
            _uc_model_URI_PREFIX,
            _UC_DBFS_SYMLINK_PREFIX,
        ]
    )


def _is_uc_volumes_path(path: str) -> bool:
    return re.match(r"^/[vV]olumes?/", path) is not None


def is_uc_volumes_uri(uri: str) -> bool:
    parsed_uri = urllib.parse.urlparse(uri)
    return parsed_uri.scheme == "dbfs" and _is_uc_volumes_path(parsed_uri.path)


def is_valid_uc_volumes_uri(uri: str) -> bool:
    parsed_uri = urllib.parse.urlparse(uri)
    return parsed_uri.scheme == "dbfs" and bool(
        re.match(r"^/[vV]olumes?/[^/]+/[^/]+/[^/]+/[^/]+", parsed_uri.path)
    )


def is_databricks_unity_catalog_uri(uri):
    scheme = urllib.parse.urlparse(uri).scheme
    return _DATABRICKS_UNITY_CATALOG_SCHEME in (scheme, uri)


def is_oss_unity_catalog_uri(uri):
    scheme = urllib.parse.urlparse(uri).scheme
    return scheme == "uc"


def construct_db_uri_from_profile(profile):
    if profile:
        return "databricks://" + profile


def construct_db_uc_uri_from_profile(profile):
    """
    Construct a databricks-uc URI from a profile.

    Args:
        profile: The profile name, optionally with key_prefix (e.g., "profile" or "scope:key")

    Returns:
        A databricks-uc URI string, or the scheme alone if no profile is provided
    """
625-    if url := _get_workspace_url():
626-        return f"https://{url}" if not url.startswith("https://") else url
627-    return None
628-
629-
630:def warn_on_deprecated_cross_workspace_registry_uri(registry_uri):
631-    workspace_host, workspace_id = get_workspace_info_from_databricks_secrets(
632-        tracking_uri=registry_uri
633-    )
634-    if workspace_host is not None or workspace_id is not None:
635-        _logger.warning(
636-            "Accessing remote workspace model registries using registry URIs of the form "
637-            "'databricks://scope:prefix', or by loading models via URIs of the form "
638-            "'models://scope:prefix@databricks/model-name/stage-or-version', is deprecated. "
639-            "Use Models in Unity Catalog instead for easy cross-workspace model access, with "
640-            "granular per-user audit logging and no extra setup required. See "
641-            "https://docs.databricks.com/machine-learning/manage-model-lifecycle/index.html "
642-            "for more details."
643-        )
644-
645-
646-def get_workspace_info_from_databricks_secrets(tracking_uri):
647-    profile, key_prefix = get_db_info_from_uri(tracking_uri)
648-    if key_prefix:
649-        dbutils = _get_dbutils()
650-        if dbutils:
651-            workspace_id = dbutils.secrets.get(scope=profile, key=key_prefix + "-workspace-id")
652-            workspace_host = dbutils.secrets.get(scope=profile, key=key_prefix + "-host")
653-            return workspace_host, workspace_id
654-    return None, None
655-
656-
657-def _fail_malformed_databricks_auth(uri):
658-    if uri and uri.startswith(_DATABRICKS_UNITY_CATALOG_SCHEME):
659-        uri_name = "registry URI"
660-        uri_scheme = _DATABRICKS_UNITY_CATALOG_SCHEME
661-    else:
662-        uri_name = "tracking URI"
663-        uri_scheme = "databricks"
664-    if is_in_databricks_model_serving_environment():
665-        raise MlflowException(
666-            f"Reading Databricks credential configuration in model serving failed. "
667-            f"Most commonly, this happens because the model currently "
668-            f"being served was logged without Databricks resource dependencies "
669-            f"properly specified. Re-log your model, specifying resource dependencies as "
670-            f"described in "
671-            f"https://docs.databricks.com/en/generative-ai/agent-framework/log-agent.html"
672-            f"#specify-resources-for-pyfunc-or-langchain-agent "
673-            f"and then register and attempt to serve it again. Alternatively, you can explicitly "
674-            f"configure authentication by setting environment variables as described in "
675-            f"https://docs.databricks.com/en/generative-ai/agent-framework/deploy-agent.html"
257-
258-def is_in_databricks_runtime():
259-    return get_databricks_runtime_version() is not None
260-
261-
262:def is_in_databricks_serverless_runtime():
263-    dbr_version = get_databricks_runtime_version()
264-    return dbr_version and dbr_version.startswith("client.")
265-
266-
267-def is_in_databricks_shared_cluster_runtime():
268-    from mlflow.utils.spark_utils import is_spark_connect_mode
269-
270-    return (
271-        is_in_databricks_runtime()
272-        and is_spark_connect_mode()
273-        and not is_in_databricks_serverless_runtime()
274-    )
275-
276-
277-def is_databricks_connect(spark=None):
278-    """
279-    Return True if current Spark-connect client connects to Databricks cluster.
280-    """
281-    from mlflow.utils.spark_utils import is_spark_connect_mode
282-
283-    if is_in_databricks_serverless_runtime() or is_in_databricks_shared_cluster_runtime():
284-        return True
285-
286-    spark = spark or _get_active_spark_session()
287-    if spark is None:
```

## 原始行 107 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"construct_db_uc_uri_from_profile\\|warn_on_deprecated_cross_workspace_registry_uri\\|is_in_databricks_serverless_runtime\" mlflow --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/langchain/model.py:71:    is_in_databricks_serverless_runtime,
mlflow/langchain/model.py:391:                if needs_databricks_auth and is_in_databricks_serverless_runtime()
mlflow/spark/__init__.py:323:        or databricks_utils.is_in_databricks_serverless_runtime()
mlflow/spark/__init__.py:521:        databricks_utils.is_in_databricks_serverless_runtime()
mlflow/spark/__init__.py:691:        databricks_utils.is_in_databricks_serverless_runtime()
mlflow/spark/__init__.py:874:        databricks_utils.is_in_databricks_serverless_runtime()
mlflow/spark/__init__.py:1238:        databricks_utils.is_in_databricks_serverless_runtime()
mlflow/pyfunc/model.py:62:    is_in_databricks_serverless_runtime,
mlflow/pyfunc/model.py:1210:                if is_in_databricks_serverless_runtime()
mlflow/pyfunc/__init__.py:554:    is_in_databricks_serverless_runtime,
mlflow/pyfunc/__init__.py:3721:                if is_in_databricks_serverless_runtime()
mlflow/tracking/_model_registry/utils.py:17:    is_in_databricks_serverless_runtime,
mlflow/tracking/_model_registry/utils.py:18:    warn_on_deprecated_cross_workspace_registry_uri,
mlflow/tracking/_model_registry/utils.py:23:    construct_db_uc_uri_from_profile,
mlflow/tracking/_model_registry/utils.py:205:    warn_on_deprecated_cross_workspace_registry_uri(registry_uri=store_uri)
mlflow/utils/uri.py:141:def construct_db_uc_uri_from_profile(profile):
mlflow/utils/nfs_on_spark.py:10:    is_in_databricks_serverless_runtime,
mlflow/utils/nfs_on_spark.py:31:        if is_in_databricks_serverless_runtime():
mlflow/utils/databricks_utils.py:262:def is_in_databricks_serverless_runtime():
mlflow/utils/databricks_utils.py:273:        and not is_in_databricks_serverless_runtime()
mlflow/utils/databricks_utils.py:283:    if is_in_databricks_serverless_runtime() or is_in_databricks_shared_cluster_runtime():
mlflow/utils/databricks_utils.py:630:def warn_on_deprecated_cross_workspace_registry_uri(registry_uri):
mlflow/store/artifact/databricks_models_artifact_repo.py:21:    warn_on_deprecated_cross_workspace_registry_uri,
mlflow/store/artifact/databricks_models_artifact_repo.py:72:        warn_on_deprecated_cross_workspace_registry_uri(self.databricks_profile_uri)
```

## 原始行 110 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/tracking/_model_registry/utils.py | sed -n '80,260p'; sed -n '135,165p' mlflow/utils/uri.py"
```

退出码：`0`

输出：
```
    80	    """
    81	    global _registry_uri
    82	    _registry_uri = uri
    83	    if uri:
    84	        # Set 'MLFLOW_REGISTRY_URI' environment variable
    85	        # so that subprocess can inherit it.
    86	        MLFLOW_REGISTRY_URI.set(_registry_uri)
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	def get_registry_uri() -> str:
   154	    """Get the current registry URI. If none has been specified, defaults to the tracking URI.
   155	
   156	    Returns:
   157	        The registry URI.
   158	
   159	    .. code-block:: python
   160	
   161	        # Get the current model registry uri
   162	        mr_uri = mlflow.get_registry_uri()
   163	        print(f"Current model registry uri: {mr_uri}")
   164	
   165	        # Get the current tracking uri
   166	        tracking_uri = mlflow.get_tracking_uri()
   167	        print(f"Current tracking uri: {tracking_uri}")
   168	
   169	        # They should be the same
   170	        assert mr_uri == tracking_uri
   171	
   172	    .. code-block:: text
   173	
   174	        Current model registry uri: file:///.../mlruns
   175	        Current tracking uri: file:///.../mlruns
   176	
   177	    """
   178	    return _resolve_registry_uri()
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	def _get_sqlalchemy_store(store_uri):
   195	    from mlflow.store.model_registry.sqlalchemy_store import SqlAlchemyStore
   196	
   197	    return SqlAlchemyStore(store_uri)
   198	
   199	
   200	
   201	
   202	
   203	
   204	def _get_databricks_rest_store(store_uri, tracking_uri, **_):
   205	    warn_on_deprecated_cross_workspace_registry_uri(registry_uri=store_uri)
   206	    return DatabricksWorkspaceModelRegistryRestStore(store_uri, tracking_uri)
   207	
   208	
   209	# We define the global variable as `None` so that instantiating the store does not lead to circular
   210	# dependency issues.
   211	_model_registry_store_registry = None
   212	
   213	
   214	def _get_file_store(store_uri, **_):
   215	    return FileStore(store_uri)
   216	
   217	
   218	
   219	
   220	
   221	
   222	
   223	
   224	
   225	
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	def _get_store(store_uri=None, tracking_uri=None):
   247	    return _get_store_registry().get_store(store_uri, tracking_uri)

def construct_db_uri_from_profile(profile):
    if profile:
        return "databricks://" + profile


def construct_db_uc_uri_from_profile(profile):
    """
    Construct a databricks-uc URI from a profile.

    Args:
        profile: The profile name, optionally with key_prefix (e.g., "profile" or "scope:key")

    Returns:
        A databricks-uc URI string, or the scheme alone if no profile is provided
    """
    if profile:
        return f"{_DATABRICKS_UNITY_CATALOG_SCHEME}://{profile}"
    else:
        return _DATABRICKS_UNITY_CATALOG_SCHEME


# Both scope and key_prefix should not contain special chars for URIs, like '/'
# and ':'.
def validate_db_scope_prefix_info(scope, prefix):
    for c in ["/", ":", " "]:
        if c in scope:
            raise MlflowException(
                f"Unsupported Databricks profile name: {scope}. Profile names cannot contain '{c}'."
            )
        if prefix and c in prefix:
```

## 原始行 113 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,80p' mlflow/store/model_registry/rest_store.py; sed -n '1,100p' mlflow/store/_unity_catalog/registry/rest_store.py"
```

退出码：`0`

输出：
```
import logging

from mlflow.entities.model_registry import ModelVersion, RegisteredModel
from mlflow.entities.webhook import Webhook, WebhookEvent, WebhookStatus, WebhookTestResult
from mlflow.protos.model_registry_pb2 import (
    CreateModelVersion,
    CreateRegisteredModel,
    DeleteModelVersion,
    DeleteModelVersionTag,
    DeleteRegisteredModel,
    DeleteRegisteredModelAlias,
    DeleteRegisteredModelTag,
    GetLatestVersions,
    GetModelVersion,
    GetModelVersionByAlias,
    GetModelVersionDownloadUri,
    GetRegisteredModel,
    ModelRegistryService,
    RenameRegisteredModel,
    SearchModelVersions,
    SearchRegisteredModels,
    SetModelVersionTag,
    SetRegisteredModelAlias,
    SetRegisteredModelTag,
    TransitionModelVersionStage,
    UpdateModelVersion,
    UpdateRegisteredModel,
)
from mlflow.protos.webhooks_pb2 import (
    CreateWebhook,
    DeleteWebhook,
    GetWebhook,
    ListWebhooks,
    TestWebhook,
    UpdateWebhook,
    WebhookService,
)
from mlflow.store.entities.paged_list import PagedList
from mlflow.store.model_registry.base_rest_store import BaseRestStore

from mlflow.utils.rest_utils import _REST_API_PATH_PREFIX, extract_all_api_info_for_service, extract_api_info_for_service






_METHOD_TO_INFO = extract_api_info_for_service(ModelRegistryService, _REST_API_PATH_PREFIX)
_METHOD_TO_ALL_INFO = extract_all_api_info_for_service(ModelRegistryService, _REST_API_PATH_PREFIX)
_WEBHOOK_METHOD_TO_INFO = extract_api_info_for_service(WebhookService, _REST_API_PATH_PREFIX)

_logger = logging.getLogger(__name__)


class RestStore(BaseRestStore):
    """
    Client for a remote model registry server accessed via REST API calls

    Args:
        get_host_creds: Method to be invoked prior to every REST request to get the
            :py:class:`mlflow.rest_utils.MlflowHostCreds` for the request. Note that this
            is a function so that we can obtain fresh credentials in the case of expiry.
    """

    def _get_response_from_method(self, method):
        return method.Response()

    def _get_endpoint_from_method(self, method):
        return _METHOD_TO_INFO[method]

    def _get_all_endpoints_from_method(self, method):
        return _METHOD_TO_ALL_INFO[method]

    def _get_webhook_endpoint_from_method(self, method):
        return _WEBHOOK_METHOD_TO_INFO[method]

    def _call_webhook_endpoint(
        self,
        api,
        json_body: str | None = None,
import base64
import functools
import json
import logging
import os
import re
import shutil
from contextlib import contextmanager
from dataclasses import dataclass
from typing import Any

import google.protobuf.empty_pb2
from pydantic import BaseModel

import mlflow
from mlflow.entities import Run
from mlflow.entities.logged_model import LoggedModel
from mlflow.entities.model_registry.prompt import Prompt
from mlflow.entities.model_registry.prompt_version import PromptVersion
from mlflow.exceptions import MlflowException, RestException
from mlflow.prompt.constants import (
    PROMPT_TYPE_CHAT,
    PROMPT_TYPE_TAG_KEY,
    PROMPT_TYPE_TEXT,
    RESPONSE_FORMAT_TAG_KEY,
)
from mlflow.protos.databricks_pb2 import (
    INTERNAL_ERROR,
    INVALID_PARAMETER_VALUE,
    RESOURCE_DOES_NOT_EXIST,
    ErrorCode,
)
from mlflow.protos.databricks_uc_registry_messages_pb2 import (
    MODEL_VERSION_OPERATION_READ_WRITE,
    CreateModelVersionRequest,
    CreateModelVersionResponse,
    CreateRegisteredModelRequest,
    CreateRegisteredModelResponse,
    DeleteModelVersionRequest,
    DeleteModelVersionResponse,
    DeleteModelVersionTagRequest,
    DeleteModelVersionTagResponse,
    DeleteRegisteredModelAliasRequest,
    DeleteRegisteredModelAliasResponse,
    DeleteRegisteredModelRequest,
    DeleteRegisteredModelResponse,
    DeleteRegisteredModelTagRequest,
    DeleteRegisteredModelTagResponse,
    Entity,
    FinalizeModelVersionRequest,
    FinalizeModelVersionResponse,
    GenerateTemporaryModelVersionCredentialsRequest,
    GenerateTemporaryModelVersionCredentialsResponse,
    GetModelVersionByAliasRequest,
    GetModelVersionByAliasResponse,
    GetModelVersionDownloadUriRequest,
    GetModelVersionDownloadUriResponse,
    GetModelVersionRequest,
    GetModelVersionResponse,
    GetRegisteredModelRequest,
    GetRegisteredModelResponse,
    Job,
    Lineage,
    LineageHeaderInfo,
    Notebook,
    SearchModelVersionsRequest,
    SearchModelVersionsResponse,
    SearchRegisteredModelsRequest,
    SearchRegisteredModelsResponse,
    Securable,
    SetModelVersionTagRequest,
    SetModelVersionTagResponse,
    SetRegisteredModelAliasRequest,
    SetRegisteredModelAliasResponse,
    SetRegisteredModelTagRequest,
    SetRegisteredModelTagResponse,
    StorageMode,
    Table,
    TemporaryCredentials,
    UpdateModelVersionRequest,
    UpdateModelVersionResponse,
    UpdateRegisteredModelRequest,
    UpdateRegisteredModelResponse,
)
from mlflow.protos.databricks_uc_registry_service_pb2 import UcModelRegistryService
from mlflow.protos.service_pb2 import GetRun, MlflowService
from mlflow.protos.unity_catalog_prompt_messages_pb2 import (
    CreatePromptRequest,
    CreatePromptVersionRequest,
    DeletePromptAliasRequest,
    DeletePromptRequest,
    DeletePromptTagRequest,
    DeletePromptVersionRequest,
    DeletePromptVersionTagRequest,
    GetPromptRequest,
    GetPromptVersionByAliasRequest,
    GetPromptVersionRequest,
    LinkPromptsToTracesRequest,
    LinkPromptVersionsToModelsRequest,
    LinkPromptVersionsToRunsRequest,
```

## 原始行 115 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"partial.*get_default_host_creds\\|RestStore(partial\" mlflow --include='*.py' | head -30; grep -n \"get_default_host_creds\" mlflow/tracking/_model_registry/utils.py mlflow/utils/rest_utils.py"
```

退出码：`1`

输出：
```
mlflow/server/handlers.py:266:        return DatabricksTracingRestStore(partial(get_databricks_host_creds, store_uri))
mlflow/server/handlers.py:295:        return ModelRegistryRestStore(partial(get_databricks_host_creds, store_uri))
mlflow/tracking/_tracking_service/utils.py:152:    return RestStore(partial(get_default_host_creds, store_uri))
mlflow/tracking/_tracking_service/utils.py:156:    return DatabricksTracingRestStore(partial(get_databricks_host_creds, store_uri))
```

## 原始行 117 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"ModelRegistryStoreRegistry()\\|register_entrypoints()\" mlflow/tracking --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/tracking/context/registry.py:63:_run_context_provider_registry.register_entrypoints()
mlflow/tracking/_tracking_service/utils.py:205:    _tracking_store_registry.register_entrypoints()
mlflow/tracking/request_header/registry.py:43:_request_header_provider_registry.register_entrypoints()
mlflow/tracking/request_auth/registry.py:32:_request_auth_provider_registry.register_entrypoints()
mlflow/tracking/default_experiment/registry.py:55:_default_experiment_provider_registry.register_entrypoints()
```

## 原始行 119 · command_execution

命令：
```
/bin/bash -lc 'git status --short; git diff -- mlflow/tracking/_model_registry/utils.py mlflow/tracking/_model_registry/registry.py'
```

退出码：`0`

输出：
```
 M mlflow/entities/webhook.py
 M mlflow/tracking/_model_registry/client.py
 M mlflow/tracking/client.py
```

## 原始行 122 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,80p' mlflow/store/model_registry/base_rest_store.py; grep -n \"def get_default_host_creds\\|def get_databricks_host_creds\" mlflow/utils/rest_utils.py mlflow/utils/databricks_utils.py; grep -RIn \"UcModelRegistryStore\" mlflow/tracking mlflow/server --include='*.py'"
```

退出码：`0`

输出：
```
from abc import ABCMeta, abstractmethod

from mlflow.store.model_registry.abstract_store import AbstractStore
from mlflow.utils.rest_utils import call_endpoints





class BaseRestStore(AbstractStore):
    """
    Base class client for a remote model registry server accessed via REST API calls
    """

    __metaclass__ = ABCMeta

    def __init__(self, get_host_creds):
        super().__init__()
        self.get_host_creds = get_host_creds

    @abstractmethod
    def _get_all_endpoints_from_method(self, method):
        pass

    @abstractmethod
    def _get_endpoint_from_method(self, method):
        pass

    @abstractmethod
    def _get_response_from_method(self, method):
        pass

    def _call_endpoint(self, api, json_body, call_all_endpoints=False, extra_headers=None):
        response_proto = self._get_response_from_method(api)
        if call_all_endpoints:
            endpoints = self._get_all_endpoints_from_method(api)
            return call_endpoints(
                self.get_host_creds(), endpoints, json_body, response_proto, extra_headers
            )
        else:
            endpoint, method = self._get_endpoint_from_method(api)
            return call_endpoint(
                self.get_host_creds(), endpoint, method, json_body, response_proto, extra_headers
            )
mlflow/utils/databricks_utils.py:744:def get_databricks_host_creds(server_uri=None):
mlflow/server/handlers.py:300:        from mlflow.store._unity_catalog.registry.rest_store import UcModelRegistryStore
mlflow/server/handlers.py:304:        return UcModelRegistryStore(store_uri, tracking_uri)
```

## 原始行 125 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"def get_default_host_creds\" mlflow --include='*.py'; sed -n '240,315p' mlflow/server/handlers.py"
```

退出码：`0`

输出：
```

class TrackingStoreRegistryWrapper(TrackingStoreRegistry):
    def __init__(self):
        super().__init__()
        self.register("", self._get_file_store)
        self.register("file", self._get_file_store)
        for scheme in DATABASE_ENGINES:
            self.register(scheme, self._get_sqlalchemy_store)
        # Add support for Databricks tracking store
        self.register("databricks", self._get_databricks_rest_store)
        self.register_entrypoints()

    @classmethod
    def _get_file_store(cls, store_uri, artifact_uri):
        from mlflow.store.tracking.file_store import FileStore

        return FileStore(store_uri, artifact_uri)

    @classmethod
    def _get_sqlalchemy_store(cls, store_uri, artifact_uri):
        from mlflow.store.tracking.sqlalchemy_store import SqlAlchemyStore

        return SqlAlchemyStore(store_uri, artifact_uri)

    @classmethod
    def _get_databricks_rest_store(cls, store_uri, artifact_uri):
        return DatabricksTracingRestStore(partial(get_databricks_host_creds, store_uri))


class ModelRegistryStoreRegistryWrapper(ModelRegistryStoreRegistry):
    def __init__(self):
        super().__init__()
        self.register("", self._get_file_store)
        self.register("file", self._get_file_store)
        for scheme in DATABASE_ENGINES:
            self.register(scheme, self._get_sqlalchemy_store)
        # Add support for Databricks registries
        self.register("databricks", self._get_databricks_rest_store)
        self.register("databricks-uc", self._get_databricks_uc_rest_store)
        self.register_entrypoints()

    @classmethod
    def _get_file_store(cls, store_uri):
        from mlflow.store.model_registry.file_store import FileStore

        return FileStore(store_uri)

    @classmethod
    def _get_sqlalchemy_store(cls, store_uri):
        from mlflow.store.model_registry.sqlalchemy_store import SqlAlchemyStore

        return SqlAlchemyStore(store_uri)

    @classmethod
    def _get_databricks_rest_store(cls, store_uri):
        return ModelRegistryRestStore(partial(get_databricks_host_creds, store_uri))

    @classmethod
    def _get_databricks_uc_rest_store(cls, store_uri):
        from mlflow.environment_variables import MLFLOW_TRACKING_URI
        from mlflow.store._unity_catalog.registry.rest_store import UcModelRegistryStore

        # Get tracking URI from environment or use "databricks-uc" as default
        tracking_uri = MLFLOW_TRACKING_URI.get() or "databricks-uc"
        return UcModelRegistryStore(store_uri, tracking_uri)


_tracking_store_registry = TrackingStoreRegistryWrapper()
_model_registry_store_registry = ModelRegistryStoreRegistryWrapper()


def _get_artifact_repo_mlflow_artifacts():
    """
    Get an artifact repository specified by ``--artifacts-destination`` option for ``mlflow server``
    command.
    """
```

## 原始行 128 · command_execution

命令：
```
/bin/bash -lc "grep -n \"host_creds\" mlflow/tracking/_tracking_service/utils.py | head -20; grep -RIn \"get_default_host_creds\" . --exclude-dir='.git' --include='*.py' | head -20"
```

退出码：`0`

输出：
```
17:from mlflow.utils.databricks_utils import get_databricks_host_creds
152:    return RestStore(partial(get_default_host_creds, store_uri))
156:    return DatabricksTracingRestStore(partial(get_databricks_host_creds, store_uri))
./mlflow/server/auth/client.py:17:from mlflow.utils.credentials import get_default_host_creds
./mlflow/server/auth/client.py:36:        host_creds = get_default_host_creds(self.tracking_uri)
./mlflow/tracking/_tracking_service/utils.py:152:    return RestStore(partial(get_default_host_creds, store_uri))
./mlflow/deployments/mlflow/__init__.py:22:from mlflow.utils.credentials import get_default_host_creds
./mlflow/deployments/mlflow/__init__.py:130:            host_creds=get_default_host_creds(self.target_uri),
./mlflow/store/artifact/azure_blob_artifact_repo.py:67:                connection_verify=get_default_host_creds(artifact_uri).verify,
./mlflow/store/artifact/azure_blob_artifact_repo.py:74:                connection_verify=get_default_host_creds(artifact_uri).verify,
./mlflow/store/artifact/azure_blob_artifact_repo.py:89:                connection_verify=get_default_host_creds(artifact_uri).verify,
./mlflow/store/artifact/http_artifact_repo.py:40:        return get_default_host_creds(self.artifact_uri)
./mlflow/store/artifact/http_artifact_repo.py:87:        host_creds = get_default_host_creds(url)
./mlflow/store/artifact/http_artifact_repo.py:130:        host_creds = get_default_host_creds(uri)
./mlflow/store/artifact/http_artifact_repo.py:143:        host_creds = get_default_host_creds(uri)
./mlflow/store/artifact/http_artifact_repo.py:156:        host_creds = get_default_host_creds(uri)
./tests/store/artifact/test_mlflow_artifact_repo.py:10:from mlflow.utils.credentials import get_default_host_creds
./tests/store/artifact/test_mlflow_artifact_repo.py:214:            get_default_host_creds(url),
./tests/store/artifact/test_http_artifact_repo.py:25:from mlflow.utils.credentials import get_default_host_creds
./tests/store/artifact/test_http_artifact_repo.py:211:            get_default_host_creds(url),
./tests/store/artifact/test_http_artifact_repo.py:441:            get_default_host_creds(url),
./tests/store/artifact/test_http_artifact_repo.py:469:            get_default_host_creds(url),
```

## 原始行 131 · command_execution

命令：
```
/bin/bash -lc "grep -n -A18 \"def get_db_info_from_uri\" mlflow/utils/uri.py; grep -RIn \"serverless.*registry\\|registry.*serverless\" tests --include='*.py' | head -30; grep -RIn \"_get_store_registry\" tests/tracking/_model_registry/test_utils.py mlflow --include='*.py' | head -30"
```

退出码：`0`

输出：
```
176:def get_db_info_from_uri(uri):
177-    """
178-    Get the Databricks profile specified by the tracking URI (if any), otherwise
179-    returns None.
180-    """
181-    parsed_uri = urllib.parse.urlparse(uri)
182-    if parsed_uri.scheme in ("databricks", _DATABRICKS_UNITY_CATALOG_SCHEME):
183-        # netloc should not be an empty string unless URI is formatted incorrectly.
184-        if parsed_uri.netloc == "":
185-            raise MlflowException(
186-                f"URI is formatted incorrectly: no netloc in URI '{uri}'."
187-                " This may be the case if there is only one slash in the URI."
188-            )
189-        profile_tokens = parsed_uri.netloc.split(":")
190-        parsed_scope = profile_tokens[0]
191-        if len(profile_tokens) == 1:
192-            parsed_key_prefix = None
193-        elif len(profile_tokens) == 2:
194-            parsed_key_prefix = profile_tokens[1]
mlflow/tracking/_model_registry/utils.py:247:    return _get_store_registry().get_store(store_uri, tracking_uri)
```

## 原始行 135 · file_change

```
{
  "id": "item_83",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracking/_model_registry/registry.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/tracking/_model_registry/utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 138 · file_change

```
{
  "id": "item_85",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracking/_model_registry/utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 141 · command_execution

命令：
```
/bin/bash -lc 'git diff --check && python -m compileall -q mlflow/entities/webhook.py mlflow/tracking/client.py mlflow/tracking/_model_registry/client.py mlflow/tracking/_model_registry/utils.py mlflow/tracking/_model_registry/registry.py'
```

退出码：`0`

输出：
```

```

## 原始行 144 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/telemetry/test_tracked_events.py::test_create_webhook -q'
```

退出码：`4`

输出：
```
ImportError while loading conftest '/testbed/tests/conftest.py'.
tests/__init__.py:1: in <module>
    from mlflow.utils.logging_utils import _configure_mlflow_loggers
mlflow/__init__.py:44: in <module>
    from mlflow import (
mlflow/artifacts/__init__.py:14: in <module>
    from mlflow.tracking import _get_store
mlflow/tracking/__init__.py:28: in <module>
    from mlflow.tracking._model_registry.utils import (
mlflow/tracking/_model_registry/utils.py:20: in <module>
    from mlflow.utils.credentials import get_default_host_creds
E   ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils.credentials' (/testbed/mlflow/utils/credentials.py)
```

## 原始行 145 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/tracking/_model_registry/test_utils.py -q'
```

退出码：`4`

输出：
```
ImportError while loading conftest '/testbed/tests/conftest.py'.
tests/__init__.py:1: in <module>
    from mlflow.utils.logging_utils import _configure_mlflow_loggers
mlflow/__init__.py:44: in <module>
    from mlflow import (
mlflow/artifacts/__init__.py:14: in <module>
    from mlflow.tracking import _get_store
mlflow/tracking/__init__.py:28: in <module>
    from mlflow.tracking._model_registry.utils import (
mlflow/tracking/_model_registry/utils.py:20: in <module>
    from mlflow.utils.credentials import get_default_host_creds
E   ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils.credentials' (/testbed/mlflow/utils/credentials.py)
```

## 原始行 148 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,180p' mlflow/utils/credentials.py; grep -RIn \"MlflowHostCreds(\" mlflow --include='*.py' | head -30"
```

退出码：`0`

输出：
```
import configparser
import getpass
import logging
import os
from typing import NamedTuple

from mlflow.environment_variables import (
    MLFLOW_TRACKING_AUTH,
    MLFLOW_TRACKING_AWS_SIGV4,
    MLFLOW_TRACKING_CLIENT_CERT_PATH,
    MLFLOW_TRACKING_INSECURE_TLS,
    MLFLOW_TRACKING_PASSWORD,
    MLFLOW_TRACKING_SERVER_CERT_PATH,
    MLFLOW_TRACKING_TOKEN,
    MLFLOW_TRACKING_USERNAME,
)
from mlflow.exceptions import MlflowException
from mlflow.utils.rest_utils import MlflowHostCreds

_logger = logging.getLogger(__name__)


class MlflowCreds(NamedTuple):
    username: str | None
    password: str | None


def _get_credentials_path() -> str:
    return os.path.expanduser("~/.mlflow/credentials")


def _read_mlflow_creds_from_file() -> tuple[str | None, str | None]:
    path = _get_credentials_path()
    if not os.path.exists(path):
        return None, None

    config = configparser.ConfigParser()
    config.read(path)
    if "mlflow" not in config:
        return None, None

    mlflow_cfg = config["mlflow"]
    username_key = MLFLOW_TRACKING_USERNAME.name.lower()
    password_key = MLFLOW_TRACKING_PASSWORD.name.lower()
    return mlflow_cfg.get(username_key), mlflow_cfg.get(password_key)


def _read_mlflow_creds_from_env() -> tuple[str | None, str | None]:
    return MLFLOW_TRACKING_USERNAME.get(), MLFLOW_TRACKING_PASSWORD.get()


def read_mlflow_creds() -> MlflowCreds:
    username_file, password_file = _read_mlflow_creds_from_file()
    username_env, password_env = _read_mlflow_creds_from_env()
    return MlflowCreds(
        username=username_env or username_file,
        password=password_env or password_file,
    )

















def login(backend: str = "databricks", interactive: bool = True) -> None:
    """Configure MLflow server authentication and connect MLflow to tracking server.

    This method provides a simple way to connect MLflow to its tracking server. Currently only
    Databricks tracking server is supported. Users will be prompted to enter the credentials if no
    existing Databricks profile is found, and the credentials will be saved to `~/.databrickscfg`.

    Args:
        backend: string, the backend of the tracking server. Currently only "databricks" is
            supported.

        interactive: bool, controls request for user input on missing credentials. If true, user
            input will be requested if no credentials are found, otherwise an exception will be
            raised if no credentials are found.

    .. code-block:: python
        :caption: Example

        import mlflow

        mlflow.login()
        with mlflow.start_run():
            mlflow.log_param("p", 0)
    """
    from mlflow.tracking import set_tracking_uri

    if backend == "databricks":
        _databricks_login(interactive)
        set_tracking_uri("databricks")
    else:
        raise MlflowException(
            f"Currently only 'databricks' backend is supported, received `backend={backend}`."
        )


def _validate_databricks_auth():
    # Check if databricks credentials are valid.
    try:
        from databricks.sdk import WorkspaceClient
    except ImportError:
        raise ImportError(
            "Databricks SDK is not installed. To use `mlflow.login()`, please install "
            "databricks-sdk by `pip install databricks-sdk`."
        )

    try:
        w = WorkspaceClient()
        if "community" in w.config.host:
            # Databricks community edition cannot use `w.current_user.me()` for auth validation.
            w.clusters.list_zones()
        else:
            # If credentials are invalid, `w.current_user.me()` will throw an error.
            w.current_user.me()
        _logger.info(
            f"Successfully connected to MLflow hosted tracking server! Host: {w.config.host}."
        )
    except Exception as e:
        raise MlflowException(f"Failed to validate databricks credentials: {e}")


def _overwrite_or_create_databricks_profile(
    file_name,
    profile,
    profile_name="DEFAULT",
):
    """Overwrite or create a profile in the databricks config file.

    Args:
        file_name: string, the file name of the databricks config file, usually `~/.databrickscfg`.
        profile: dict, contains the authentiacation profile information.
        profile_name: string, the name of the profile to be overwritten or created.
    """
    profile_name = f"[{profile_name}]"
    lines = []
    # Read `file_name` if the file exists, otherwise `lines=[]`.
    if os.path.exists(file_name):
        with open(file_name) as file:
            lines = file.readlines()
    start_index = -1
    end_index = -1
    # Find the start and end indices of the profile to overwrite.
    for i in range(len(lines)):
        if lines[i].strip() == profile_name:
            start_index = i
            break

    if start_index != -1:
        for i in range(start_index + 1, len(lines)):
            # Reach an empty line or a new profile.
            if lines[i].strip() == "" or lines[i].startswith("["):
                end_index = i
                break
        end_index = end_index if end_index != -1 else len(lines)
        del lines[start_index : end_index + 1]

    # Write the new profile to the top of the file.
    new_profile = []
    new_profile.append(profile_name + "\n")
    new_profile.append(f"host = {profile['host']}\n")
    if "token" in profile:
        new_profile.append(f"token = {profile['token']}\n")
    else:
        new_profile.append(f"username = {profile['username']}\n")
        new_profile.append(f"password = {profile['password']}\n")
    new_profile.append("\n")
mlflow/utils/databricks_utils.py:777:                return MlflowHostCreds(
mlflow/utils/databricks_utils.py:824:    return MlflowHostCreds(
mlflow/utils/oss_registry_utils.py:29:    return MlflowHostCreds(host=parsed_uri.path, token=MLFLOW_UC_OSS_TOKEN.get())
mlflow/pyspark/ml/__init__.py:84:        host_creds = MlflowHostCreds(
```

## 原始行 151 · file_change

```
{
  "id": "item_93",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracking/_model_registry/utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 155 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/tracking/_model_registry/test_utils.py -q'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 40 items

tests/tracking/_model_registry/test_utils.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 67%]
[0m[32m.[0m[31mF[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[31m                                                            [100%][0m

=================================== FAILURES ===================================
[31m[1m______________________ test_get_store_rest_store_from_arg ______________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x726b35c7ef50>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_get_store_rest_store_from_arg[39;49;00m(monkeypatch):[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_TRACKING_URI.name, [33m"[39;49;00m[33mhttps://my-tracking-server:5050[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>       store = _get_store([33m"[39;49;00m[33mhttp://some/path[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
                ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x726b35c7ef50>

[1m[31mtests/tracking/_model_registry/test_utils.py[0m:267: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/tracking/_model_registry/utils.py[0m:303: in _get_store
    [0m[94mreturn[39;49;00m _get_store_registry().get_store(store_uri, tracking_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        store_uri  = 'http://some/path'
        tracking_uri = None
[1m[31mmlflow/tracking/_model_registry/registry.py[0m:50: in get_store
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._get_store_with_resolved_uri(resolved_store_uri, resolved_tracking_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        _resolve_registry_uri = <function _resolve_registry_uri at 0x726b6feee480>
        _resolve_tracking_uri = <function _resolve_tracking_uri at 0x726b70021a80>
        resolved_store_uri = 'http://some/path'
        resolved_tracking_uri = 'https://my-tracking-server:5050'
        self       = <mlflow.tracking._model_registry.registry.ModelRegistryStoreRegistry object at 0x726b35c7f790>
        store_uri  = 'http://some/path'
        tracking_uri = None
[1m[31mmlflow/tracking/_model_registry/registry.py[0m:68: in _get_store_with_resolved_uri
    [0m[94mreturn[39;49;00m builder(store_uri=resolved_store_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        builder    = <function _get_rest_store at 0x726b6fef8e00>
        builder_param_names = {'_', 'store_uri'}
        resolved_store_uri = 'http://some/path'
        resolved_tracking_uri = 'https://my-tracking-server:5050'
        self       = <mlflow.tracking._model_registry.registry.ModelRegistryStoreRegistry object at 0x726b35c7f790>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

store_uri = 'http://some/path', _ = {}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_get_rest_store[39;49;00m(store_uri, **_):[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[04m[96m.[39;49;00m[04m[96mcredentials[39;49;00m[90m [39;49;00m[94mimport[39;49;00m get_default_host_creds[90m[39;49;00m
[1m[31mE       ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils.credentials' (/testbed/mlflow/utils/credentials.py)[0m

_          = {}
store_uri  = 'http://some/path'

[1m[31mmlflow/tracking/_model_registry/utils.py[0m:231: ImportError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 05:07:58 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________ test_fallback_to_tracking_store ________________________[0m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x726b35c8aa50>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_fallback_to_tracking_store[39;49;00m(monkeypatch):[90m[39;49;00m
        monkeypatch.setenv(MLFLOW_TRACKING_URI.name, [33m"[39;49;00m[33mhttps://my-tracking-server:5050[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
>       store = _get_store()[90m[39;49;00m
                ^^^^^^^^^^^^[90m[39;49;00m

monkeypatch = <_pytest.monkeypatch.MonkeyPatch object at 0x726b35c8aa50>

[1m[31mtests/tracking/_model_registry/test_utils.py[0m:274: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/tracking/_model_registry/utils.py[0m:303: in _get_store
    [0m[94mreturn[39;49;00m _get_store_registry().get_store(store_uri, tracking_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        store_uri  = None
        tracking_uri = None
[1m[31mmlflow/tracking/_model_registry/registry.py[0m:50: in get_store
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._get_store_with_resolved_uri(resolved_store_uri, resolved_tracking_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        _resolve_registry_uri = <function _resolve_registry_uri at 0x726b6feee480>
        _resolve_tracking_uri = <function _resolve_tracking_uri at 0x726b70021a80>
        resolved_store_uri = 'https://my-tracking-server:5050'
        resolved_tracking_uri = 'https://my-tracking-server:5050'
        self       = <mlflow.tracking._model_registry.registry.ModelRegistryStoreRegistry object at 0x726b35c7f790>
        store_uri  = None
        tracking_uri = None
[1m[31mmlflow/tracking/_model_registry/registry.py[0m:68: in _get_store_with_resolved_uri
    [0m[94mreturn[39;49;00m builder(store_uri=resolved_store_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        builder    = <function _get_rest_store at 0x726b6fef8e00>
        builder_param_names = {'_', 'store_uri'}
        resolved_store_uri = 'https://my-tracking-server:5050'
        resolved_tracking_uri = 'https://my-tracking-server:5050'
        self       = <mlflow.tracking._model_registry.registry.ModelRegistryStoreRegistry object at 0x726b35c7f790>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

store_uri = 'https://my-tracking-server:5050', _ = {}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_get_rest_store[39;49;00m(store_uri, **_):[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[04m[96m.[39;49;00m[04m[96mcredentials[39;49;00m[90m [39;49;00m[94mimport[39;49;00m get_default_host_creds[90m[39;49;00m
[1m[31mE       ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils.credentials' (/testbed/mlflow/utils/credentials.py)[0m

_          = {}
store_uri  = 'https://my-tracking-server:5050'

[1m[31mmlflow/tracking/_model_registry/utils.py[0m:231: ImportError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 05:07:58 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m________________ test_store_object_can_be_serialized_by_pickle _________________[0m

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_store_object_can_be_serialized_by_pickle[39;49;00m():[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    This test ensures a store object generated by `_get_store` can be serialized by pickle[39;49;00m
    [33m    to prevent issues such as https://github.com/mlflow/mlflow/issues/2954[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
>       pickle.dump(_get_store([33m"[39;49;00m[33mhttps://example.com[39;49;00m[33m"[39;49;00m), io.BytesIO())[90m[39;49;00m
                    ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m


[1m[31mtests/tracking/_model_registry/test_utils.py[0m:336: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/tracking/_model_registry/utils.py[0m:303: in _get_store
    [0m[94mreturn[39;49;00m _get_store_registry().get_store(store_uri, tracking_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        store_uri  = 'https://example.com'
        tracking_uri = None
[1m[31mmlflow/tracking/_model_registry/registry.py[0m:50: in get_store
    [0m[94mreturn[39;49;00m [96mself[39;49;00m._get_store_with_resolved_uri(resolved_store_uri, resolved_tracking_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        _resolve_registry_uri = <function _resolve_registry_uri at 0x726b6feee480>
        _resolve_tracking_uri = <function _resolve_tracking_uri at 0x726b70021a80>
        resolved_store_uri = 'https://example.com'
        resolved_tracking_uri = 'file:///testbed/mlruns'
        self       = <mlflow.tracking._model_registry.registry.ModelRegistryStoreRegistry object at 0x726b35c7f790>
        store_uri  = 'https://example.com'
        tracking_uri = None
[1m[31mmlflow/tracking/_model_registry/registry.py[0m:68: in _get_store_with_resolved_uri
    [0m[94mreturn[39;49;00m builder(store_uri=resolved_store_uri)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        builder    = <function _get_rest_store at 0x726b6fef8e00>
        builder_param_names = {'_', 'store_uri'}
        resolved_store_uri = 'https://example.com'
        resolved_tracking_uri = 'file:///testbed/mlruns'
        self       = <mlflow.tracking._model_registry.registry.ModelRegistryStoreRegistry object at 0x726b35c7f790>
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

store_uri = 'https://example.com', _ = {}

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_get_rest_store[39;49;00m(store_uri, **_):[90m[39;49;00m
>       [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[04m[96m.[39;49;00m[04m[96mcredentials[39;49;00m[90m [39;49;00m[94mimport[39;49;00m get_default_host_creds[90m[39;49;00m
[1m[31mE       ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils.credentials' (/testbed/mlflow/utils/credentials.py)[0m

_          = {}
store_uri  = 'https://example.com'

[1m[31mmlflow/tracking/_model_registry/utils.py[0m:231: ImportError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 05:08:02 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
4.51s call     tests/tracking/_model_registry/test_utils.py::test_get_store_caches_on_store_uri

(9 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                           | Duration | Tests | Min    | Max    | Avg    |
| ---- | ---------------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/tracking/_model_registry/test_utils.py` | 4.65s    | 40    | 0.001s | 4.508s | 0.116s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/tracking/_model_registry/test_utils.py::test_get_store_rest_store_from_arg' 'tests/tracking/_model_registry/test_utils.py::test_fallback_to_tracking_store' 'tests/tracking/_model_registry/test_utils.py::test_store_object_can_be_serialized_by_pickle'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 23.2/33.7 GB | DISK 793.2/915.7 GB[0m tests/tracking/_model_registry/test_utils.py::[1mtest_get_store_rest_store_from_arg[0m - ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils...
[31mFAILED | MEM 23.2/33.7 GB | DISK 793.2/915.7 GB[0m tests/tracking/_model_registry/test_utils.py::[1mtest_fallback_to_tracking_store[0m - ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils...
[31mFAILED | MEM 23.2/33.7 GB | DISK 793.2/915.7 GB[0m tests/tracking/_model_registry/test_utils.py::[1mtest_store_object_can_be_serialized_by_pickle[0m - ImportError: cannot import name 'get_default_host_creds' from 'mlflow.utils...
[31m========================= [31m[1m3 failed[0m, [32m37 passed[0m[31m in 4.99s[0m[31m =========================[0m
```

## 原始行 156 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/telemetry/test_tracked_events.py::test_create_webhook -q'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 1 item

tests/telemetry/test_tracked_events.py [31mF[0m[31m                                 [100%][0m

=================================== FAILURES ===================================
[31m[1m_____________________________ test_create_webhook ______________________________[0m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7dc6876a1cd0>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_create_webhook[39;49;00m(mock_requests, mock_telemetry_client: TelemetryClient):[90m[39;49;00m
        client = MlflowClient()[90m[39;49;00m
>       client.create_webhook([90m[39;49;00m
            name=[33m"[39;49;00m[33mtest_webhook[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            url=[33m"[39;49;00m[33mhttps://example.com/webhook[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
            events=[WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)],[90m[39;49;00m
        )[90m[39;49;00m

client     = <mlflow.tracking.client.MlflowClient object at 0x7dc6876a35d0>
mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7dc6876a1cd0>

[1m[31mtests/telemetry/test_tracked_events.py[0m:343: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

self = <mlflow.tracking.client.MlflowClient object at 0x7dc6876a35d0>
name = 'test_webhook', url = 'https://example.com/webhook'
events = [WebhookEvent(entity=model_version, action=created)]
description = None, secret = None, status = None

    [0m[37m@experimental[39;49;00m(version=[33m"[39;49;00m[33m3.3.0[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mcreate_webhook[39;49;00m([90m[39;49;00m
        [96mself[39;49;00m,[90m[39;49;00m
        name: [96mstr[39;49;00m,[90m[39;49;00m
        url: [96mstr[39;49;00m,[90m[39;49;00m
        events: [96mlist[39;49;00m[WebhookEventStr | WebhookEvent],[90m[39;49;00m
        description: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        secret: [96mstr[39;49;00m | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
        status: [96mstr[39;49;00m | WebhookStatus | [94mNone[39;49;00m = [94mNone[39;49;00m,[90m[39;49;00m
    ) -> Webhook:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Create a webhook for the specified events."""[39;49;00m[90m[39;49;00m
        events = [[90m[39;49;00m
            WebhookEvent.from_str(event) [94mif[39;49;00m [96misinstance[39;49;00m(event, [96mstr[39;49;00m) [94melse[39;49;00m event [94mfor[39;49;00m event [95min[39;49;00m events[90m[39;49;00m
        ][90m[39;49;00m
        [94mif[39;49;00m [96misinstance[39;49;00m(status, [96mstr[39;49;00m):[90m[39;49;00m
            status = WebhookStatus(status)[90m[39;49;00m
>       [94mreturn[39;49;00m [96mself[39;49;00m._get_registry_client().create_webhook([90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
            name=name,[90m[39;49;00m
            url=url,[90m[39;49;00m
            events=events,[90m[39;49;00m
            description=description,[90m[39;49;00m
            secret=secret,[90m[39;49;00m
            status=status,[90m[39;49;00m
        )[90m[39;49;00m
[1m[31mE       AttributeError: 'MlflowClient' object has no attribute '_get_registry_client'[0m

description = None
events     = [WebhookEvent(entity=model_version, action=created)]
name       = 'test_webhook'
secret     = None
self       = <mlflow.tracking.client.MlflowClient object at 0x7dc6876a35d0>
status     = None
url        = 'https://example.com/webhook'

[1m[31mmlflow/tracking/client.py[0m:6452: AttributeError
----------------------------- Captured stderr call -----------------------------
2026/10/11 05:07:58 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:07:58 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:07:58 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:07:58 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:07:58 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:07:58 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:07:58 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:07:58 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:07:58 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:07:59 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:07:59 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:07:59 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:07:59 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:08:00 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:08:01 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:08:01 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:08:01 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:08:01 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:08:01 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:08:01 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 05:08:02 INFO mlflow.tracking.fluent: Active model is cleared
============================= slowest 10 durations =============================
3.00s call     tests/telemetry/test_tracked_events.py::test_create_webhook
1.00s teardown tests/telemetry/test_tracked_events.py::test_create_webhook

(1 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                     | Duration | Tests | Min    | Max    | Avg    |
| ---- | ---------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/telemetry/test_tracked_events.py` | 4.12s    | 1     | 4.115s | 4.115s | 4.115s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/telemetry/test_tracked_events.py::test_create_webhook'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 23.2/33.7 GB | DISK 793.2/915.7 GB[0m tests/telemetry/test_tracked_events.py::[1mtest_create_webhook[0m - AttributeError: 'MlflowClient' object has no attribute '_get_registry_client'
[31m============================== [31m[1m1 failed[0m[31m in 4.84s[0m[31m ===============================[0m
```

## 原始行 159 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/tracking/client.py | sed -n '205,290p'; grep -n \"_get_registry_client\" mlflow/tracking/client.py | head -20; grep -RIn \"def _get_registry_client\" tests mlflow --include='*.py'"
```

退出码：`1`

输出：
```
   205	    def __init__(self, tracking_uri: str | None = None, registry_uri: str | None = None):
   206	        """
   207	        Args:
   208	            tracking_uri: Address of local or remote tracking server. If not provided, defaults
   209	                to the service set by ``mlflow.tracking.set_tracking_uri``. See
   210	                `Where Runs Get Recorded <../tracking.html#where-runs-get-recorded>`_
   211	                for more info.
   212	            registry_uri: Address of local or remote model registry server. If not provided,
   213	                defaults to the service set by ``mlflow.tracking.set_registry_uri``. If
   214	                no such service was set, defaults to the tracking uri of the client.
   215	        """
   216	        final_tracking_uri = utils._resolve_tracking_uri(tracking_uri)
   217	        self._registry_uri = registry_utils._resolve_registry_uri(registry_uri, tracking_uri)
   218	        self._tracking_client = TrackingServiceClient(final_tracking_uri)
   219	        self._tracing_client = TracingClient(tracking_uri)
   220	
   221	        # `MlflowClient` also references a `ModelRegistryClient` instance that is provided by the
   222	        # `MlflowClient._get_registry_client()` method. This `ModelRegistryClient` is not explicitly
   223	        # defined as an instance variable in the `MlflowClient` constructor; an instance variable
   224	        # is assigned lazily by `MlflowClient._get_registry_client()` and should not be referenced
   225	        # outside of the `MlflowClient._get_registry_client()` method
   226	
   227	
   228	
   229	
   230	
   231	
   232	
   233	
   234	
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	    # Tracking API
   267	
   268	    def get_run(self, run_id: str) -> Run:
   269	        """
   270	        Fetch the run from backend store. The resulting :py:class:`Run <mlflow.entities.Run>`
   271	        contains a collection of run metadata -- :py:class:`RunInfo <mlflow.entities.RunInfo>`,
   272	        as well as a collection of run parameters, tags, and metrics --
   273	        :py:class:`RunData <mlflow.entities.RunData>`. It also contains a collection of run
   274	        inputs (experimental), including information about datasets used by the run --
   275	        :py:class:`RunInputs <mlflow.entities.RunInputs>`. In the case where multiple metrics with
   276	        the same key are logged for the run, the :py:class:`RunData <mlflow.entities.RunData>`
   277	        contains the most recently logged value at the largest step for each metric.
   278	
   279	        Args:
   280	            run_id: Unique identifier for the run.
   281	
   282	        Returns:
   283	            A single :py:class:`mlflow.entities.Run` object, if the run exists. Otherwise,
   284	            raises an exception.
   285	
   286	
   287	        .. code-block:: python
   288	            :caption: Example
   289	
   290	            import mlflow
222:        # `MlflowClient._get_registry_client()` method. This `ModelRegistryClient` is not explicitly
224:        # is assigned lazily by `MlflowClient._get_registry_client()` and should not be referenced
225:        # outside of the `MlflowClient._get_registry_client()` method
575:        registry_client = self._get_registry_client()
715:        registry_client = self._get_registry_client()
761:            registry_client = self._get_registry_client()
797:        self._get_registry_client().link_prompt_version_to_run(
810:        return self._get_registry_client().link_prompt_version_to_model(
843:        return self._get_registry_client().link_prompt_versions_to_trace(
926:            self._get_registry_client().set_model_version_tag(
930:            self._get_registry_client().delete_model_version_tag(
970:        self._get_registry_client().set_prompt_alias(name, alias, version)
982:        self._get_registry_client().delete_prompt_alias(name, alias)
997:        self._get_registry_client().set_prompt_version_tag(name, version, key, value)
1011:        self._get_registry_client().delete_prompt_version_tag(name, version, key)
1014:        registry_client = self._get_registry_client()
3716:        return self._get_registry_client().create_registered_model(
3771:        self._get_registry_client().rename_registered_model(name, new_name)
3824:        return self._get_registry_client().update_registered_model(
3884:        self._get_registry_client().delete_registered_model(name)
```

## 原始行 162 · command_execution

命令：
```
/bin/bash -lc "grep -n \"ModelRegistryClient\" mlflow/tracking/client.py | head; sed -n '85,135p' mlflow/tracking/client.py; grep -RIn \"_registry_client\" tests/tracking/test_client.py | head -30"
```

退出码：`0`

输出：
```
106:from mlflow.tracking._model_registry.client import ModelRegistryClient
221:        # `MlflowClient` also references a `ModelRegistryClient` instance that is provided by the
222:        # `MlflowClient._get_registry_client()` method. This `ModelRegistryClient` is not explicitly
    _parse_model_uri,
    get_model_name_and_version,
)
from mlflow.store.entities.paged_list import PagedList
from mlflow.store.model_registry import (
    SEARCH_MODEL_VERSION_MAX_RESULTS_DEFAULT,
    SEARCH_REGISTERED_MODEL_MAX_RESULTS_DEFAULT,
)
from mlflow.store.tracking import (
    SEARCH_EVALUATION_DATASETS_MAX_RESULTS,
    SEARCH_MAX_RESULTS_DEFAULT,
    SEARCH_TRACES_DEFAULT_MAX_RESULTS,
)
from mlflow.tracing.client import TracingClient
from mlflow.tracing.constant import TRACE_REQUEST_ID_PREFIX
from mlflow.tracing.display import get_display_handler
from mlflow.tracing.fluent import start_span_no_context
from mlflow.tracing.trace_manager import InMemoryTraceManager
from mlflow.tracing.utils.copy import copy_trace_to_experiment
from mlflow.tracking._model_registry import DEFAULT_AWAIT_MAX_SLEEP_SECONDS
from mlflow.tracking._model_registry import utils as registry_utils
from mlflow.tracking._model_registry.client import ModelRegistryClient
from mlflow.tracking._tracking_service import utils
from mlflow.tracking._tracking_service.client import TrackingServiceClient
from mlflow.tracking.artifact_utils import _upload_artifacts_to_databricks
from mlflow.tracking.multimedia import Image, compress_image_size, convert_to_pil_image
from mlflow.tracking.registry import UnsupportedModelRegistryStoreURIException
from mlflow.utils import is_uuid
from mlflow.utils.annotations import deprecated, deprecated_parameter, experimental
from mlflow.utils.async_logging.run_operations import RunOperations
from mlflow.utils.databricks_utils import (
    get_databricks_run_url,
    is_in_databricks_runtime,
)
from mlflow.utils.logging_utils import eprint
from mlflow.utils.mlflow_tags import (
    MLFLOW_LOGGED_ARTIFACTS,
    MLFLOW_LOGGED_IMAGES,
    MLFLOW_PARENT_RUN_ID,
)
from mlflow.utils.time import get_current_time_millis
from mlflow.utils.uri import is_databricks_unity_catalog_uri, is_databricks_uri
from mlflow.utils.validation import (
    _validate_list_param,
    _validate_model_alias_name,
    _validate_model_name,
    _validate_model_version,
    _validate_model_version_or_stage_exists,
)

if TYPE_CHECKING:
```

## 原始行 165 · command_execution

命令：
```
/bin/bash -lc "grep -n \"class TrackingServiceClient\\|def __init__\\|tracking_uri\" mlflow/tracking/_tracking_service/client.py | head -25; grep -RIn \"_registry_client\" tests --include='*.py' | head -30"
```

退出码：`0`

输出：
```
81:class TrackingServiceClient:
86:    def __init__(self, tracking_uri):
89:            tracking_uri: Address of local or remote tracking server.
91:        self.tracking_uri = tracking_uri
100:        return utils._get_store(self.tracking_uri)
648:                artifact_location, self.tracking_uri
715:        return list_artifacts(run_id=run_id, artifact_path=path, tracking_uri=self.tracking_uri)
750:            run_id=run_id, artifact_path=path, dst_path=dst_path, tracking_uri=self.tracking_uri
773:        if is_databricks_uri(self.tracking_uri):
```

## 原始行 168 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"Model Registry features are not supported\\|registry functionality is unavailable\\|UnsupportedModelRegistryStoreURIException\" tests/tracking/test_client.py mlflow/tracking/client.py | head -60"
```

退出码：`0`

输出：
```
mlflow/tracking/client.py:111:from mlflow.tracking.registry import UnsupportedModelRegistryStoreURIException
```

## 原始行 171 · command_execution

命令：
```
/bin/bash -lc "grep -RIn \"UnsupportedModelRegistryStoreURIException\" mlflow tests --include='*.py'"
```

退出码：`0`

输出：
```
mlflow/server/handlers.py:200:from mlflow.tracking.registry import UnsupportedModelRegistryStoreURIException
mlflow/server/handlers.py:520:    except UnsupportedModelRegistryStoreURIException:
mlflow/tracking/client.py:111:from mlflow.tracking.registry import UnsupportedModelRegistryStoreURIException
mlflow/tracking/registry.py:10:class UnsupportedModelRegistryStoreURIException(MlflowException):
mlflow/tracking/registry.py:83:            raise UnsupportedModelRegistryStoreURIException(
tests/tracking/_tracking_service/test_utils.py:34:from mlflow.tracking.registry import UnsupportedModelRegistryStoreURIException
tests/tracking/_tracking_service/test_utils.py:346:        UnsupportedModelRegistryStoreURIException,
tests/tracking/_model_registry/test_utils.py:18:from mlflow.tracking.registry import UnsupportedModelRegistryStoreURIException
tests/tracking/_model_registry/test_utils.py:305:        UnsupportedModelRegistryStoreURIException,
```

## 原始行 174 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,100p' mlflow/tracking/registry.py; sed -n '510,530p' mlflow/server/handlers.py"
```

退出码：`0`

输出：
```
import warnings
from abc import ABCMeta

from mlflow.exceptions import MlflowException
from mlflow.protos.databricks_pb2 import INVALID_PARAMETER_VALUE
from mlflow.utils.plugins import get_entry_points
from mlflow.utils.uri import get_uri_scheme


class UnsupportedModelRegistryStoreURIException(MlflowException):
    """Exception thrown when building a model registry store with an unsupported URI"""

    def __init__(self, unsupported_uri, supported_uri_schemes):
        message = (
            " Model registry functionality is unavailable; got unsupported URI"
            f" '{unsupported_uri}' for model registry data storage. Supported URI schemes are:"
            f" {supported_uri_schemes}."
            " See https://www.mlflow.org/docs/latest/tracking.html#storage for how to run"
            " an MLflow server against one of the supported backend storage locations."
        )
        super().__init__(message, error_code=INVALID_PARAMETER_VALUE)
        self.supported_uri_schemes = supported_uri_schemes


class StoreRegistry:
    """
    Abstract class defining a scheme-based registry for store implementations.

    This class allows the registration of a function or class to provide an
    implementation for a given scheme of `store_uri` through the `register`
    methods. Implementations declared though the entrypoints can be automatically
    registered through the `register_entrypoints` method.

    When instantiating a store through the `get_store` method, the scheme of
    the store URI provided (or inferred from environment) will be used to
    select which implementation to instantiate, which will be called with same
    arguments passed to the `get_store` method.
    """

    __metaclass__ = ABCMeta

    def __init__(self, group_name):
        self._registry = {}
        self.group_name = group_name

    def register(self, scheme, store_builder):
        self._registry[scheme] = store_builder

    def register_entrypoints(self):
        """Register tracking stores provided by other packages"""
        for entrypoint in get_entry_points(self.group_name):
            try:
                self.register(entrypoint.name, entrypoint.load())
            except (AttributeError, ImportError) as exc:
                warnings.warn(
                    'Failure attempting to register store for scheme "{}": {}'.format(
                        entrypoint.name, str(exc)
                    ),
                    stacklevel=2,
                )

    def get_store_builder(self, store_uri):
        """Get a store from the registry based on the scheme of store_uri

        Args:
            store_uri: The store URI. If None, it will be inferred from the environment. This
                URI is used to select which tracking store implementation to instantiate
                and is passed to the constructor of the implementation.

        Returns:
            A function that returns an instance of
            ``mlflow.store.{tracking|model_registry}.AbstractStore`` that fulfills the store
            URI requirements.
        """
        scheme = (
            store_uri
            if store_uri in {"databricks", "databricks-uc", "uc"}
            else get_uri_scheme(store_uri)
        )
        try:
            store_builder = self._registry[scheme]
        except KeyError:
            raise UnsupportedModelRegistryStoreURIException(
                unsupported_uri=store_uri, supported_uri_schemes=list(self._registry.keys())
            )
        return store_builder


def initialize_backend_stores(
    backend_store_uri: str | None = None,
    registry_store_uri: str | None = None,
    default_artifact_root: str | None = None,
) -> None:
    _get_tracking_store(backend_store_uri, default_artifact_root)
    try:
        _get_model_registry_store(registry_store_uri)
    except UnsupportedModelRegistryStoreURIException:
        pass


def _assert_string(x):
    assert isinstance(x, str)


def _assert_intlike(x):
    try:
        x = int(x)
```

## 原始行 176 · agent_message

```
The blocker audit found one more masked consumer: `MlflowClient._get_registry_client`, which every registry API uses, is absent. I’m restoring its lazy construction now; without it, the requested CRUD methods cannot execute even though their own implementations are correct.
```

## 原始行 178 · file_change

```
{
  "id": "item_111",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/tracking/client.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 181 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/telemetry/test_tracked_events.py::test_create_webhook -q'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 1 item

tests/telemetry/test_tracked_events.py [32m.[0m[32m                                 [100%][0m

============================= slowest 10 durations =============================
1.88s call     tests/telemetry/test_tracked_events.py::test_create_webhook
1.00s teardown tests/telemetry/test_tracked_events.py::test_create_webhook

(1 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                     | Duration | Tests | Min    | Max    | Avg    |
| ---- | ---------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/telemetry/test_tracked_events.py` | 2.88s    | 1     | 2.883s | 2.883s | 2.883s |

::endgroup::

[32m============================== [32m[1m1 passed[0m[32m in 3.38s[0m[32m ===============================[0m
```

## 原始行 184 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os
import tempfile
from cryptography.fernet import Fernet
from mlflow import MlflowClient
from mlflow.environment_variables import MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY

with tempfile.NamedTemporaryFile(suffix='.db') as f:
    os.environ[MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name] = Fernet.generate_key().decode()
    uri = f'sqlite:///{f.name}'
    client = MlflowClient(tracking_uri=uri, registry_uri=uri)
    created = client.create_webhook(
        'name', 'https://example.com/hook', ['model_version.created'], secret='secret', status='ACTIVE'
    )
    assert created.secret is None
    page = client.list_webhooks(max_results=1)
    assert type(page).__name__ == 'PagedList' and page[0].webhook_id == created.webhook_id
    fetched = client.get_webhook(created.webhook_id)
    assert fetched.events == created.events
    updated = client.update_webhook(
        created.webhook_id, events=['registered_model.created'], status='DISABLED'
    )
    assert str(updated.events[0]) == 'registered_model.created' and str(updated.status) == 'DISABLED'
    client.delete_webhook(created.webhook_id)
print('public sqlite webhook CRUD passed')
PY"
```

退出码：`1`

输出：
```
2026/10/11 05:08:46 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:08:47 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:08:47 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:08:47 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:08:47 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:08:47 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 05:08:48 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:08:48 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:08:48 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
Traceback (most recent call last):
  File "<stdin>", line 14, in <module>
AssertionError
```

## 原始行 187 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os,tempfile
from cryptography.fernet import Fernet
from mlflow import MlflowClient
from mlflow.environment_variables import MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY
with tempfile.NamedTemporaryFile(suffix='.db') as f:
 os.environ[MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name]=Fernet.generate_key().decode(); u=f'sqlite:///{f.name}'; c=MlflowClient(u,u)
 w=c.create_webhook('n','https://example.com',['model_version.created'],secret='s',status='ACTIVE')
 print('created',w,w.secret,type(w.secret)); p=c.list_webhooks(max_results=1); print(type(p),len(p),p.token,p[0].webhook_id,w.webhook_id)
PY"
```

退出码：`0`

输出：
```
2026/10/11 05:08:55 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:08:55 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:08:55 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:08:55 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:08:55 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:08:55 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:08:56 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:08:57 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:08:57 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:08:57 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:08:57 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 05:08:57 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:08:57 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:08:57 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:08:57 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
created Webhook(webhook_id='8b136137-258d-4d64-aff8-70ecc3010852', name='n', url='https://example.com', status='ACTIVE', events=[WebhookEvent(entity=model_version, action=created)], creation_timestamp=1791695337122, last_updated_timestamp=1791695337122) s <class 'str'>
<class 'mlflow.store.entities.paged_list.PagedList'> 1 None 8b136137-258d-4d64-aff8-70ecc3010852 8b136137-258d-4d64-aff8-70ecc3010852
```

## 原始行 190 · command_execution

命令：
```
/bin/bash -lc "sed -n '1300,1360p' mlflow/store/model_registry/sqlalchemy_store.py; sed -n '250,295p' mlflow/store/model_registry/dbmodels/models.py"
```

退出码：`0`

输出：
```
                )
                return self._populate_model_version_aliases(
                    session, name, sql_model_version.to_mlflow_entity()
                )
            else:
                raise MlflowException(
                    f"Registered model alias {alias} not found.", INVALID_PARAMETER_VALUE
                )

    def _await_model_version_creation(self, mv, await_creation_for):
        """
        Does not wait for the model version to become READY as a successful creation will
        immediately place the model version in a READY state.
        """

    # Webhook CRUD operations
    def create_webhook(
        self,
        name: str,
        url: str,
        events: list[WebhookEvent],
        description: str | None = None,
        secret: str | None = None,
        status: WebhookStatus | None = None,
    ) -> Webhook:
        _validate_webhook_name(name)
        _validate_webhook_url(url)
        _validate_webhook_events(events)

        with self.ManagedSessionMaker() as session:
            webhook_id = str(uuid.uuid4())
            creation_time = get_current_time_millis()
            webhook = SqlWebhook(
                webhook_id=webhook_id,
                name=name,
                url=url,
                description=description,
                secret=secret,
                status=(status or WebhookStatus.ACTIVE).value,
                creation_timestamp=creation_time,
                last_updated_timestamp=creation_time,
            )
            session.add(webhook)
            session.add_all(
                SqlWebhookEvent(webhook_id=webhook_id, entity=e.entity.value, action=e.action.value)
                for e in events
            )
            session.flush()
            return webhook.to_mlflow_entity()

    def get_webhook(self, webhook_id: str) -> Webhook:
        with self.ManagedSessionMaker() as session:
            webhook = self._get_webhook_by_id(session, webhook_id)
            return webhook.to_mlflow_entity()

    def list_webhooks(
        self,
        max_results: int | None = None,
        page_token: str | None = None,
    ) -> PagedList[Webhook]:
        max_results = max_results or 100
    webhook_id = Column(String(256), nullable=False)
    name = Column(String(256), nullable=False)
    description = Column(String(1000), nullable=True)
    url = Column(String(500), nullable=False)
    status = Column(String(20), nullable=False, default="ACTIVE")
    secret = Column(EncryptedString(), nullable=True)  # Encrypted storage for HMAC secret
    creation_timestamp = Column(BigInteger, default=get_current_time_millis)
    last_updated_timestamp = Column(BigInteger, nullable=True, default=None)
    deleted_timestamp = Column(BigInteger, nullable=True, default=None)  # For soft deletes

    __table_args__ = (
        PrimaryKeyConstraint("webhook_id", name="webhook_pk"),
        Index("idx_webhooks_status", "status"),
        Index("idx_webhooks_name", "name"),
    )

    def __repr__(self):
        return (
            f"<SqlWebhook ({self.webhook_id}, {self.name}, {self.url}, "
            f"{self.status}, {self.creation_timestamp})>"
        )

    def to_mlflow_entity(self):
        return Webhook(
            webhook_id=self.webhook_id,
            name=self.name,
            url=self.url,
            events=[we.to_mlflow_entity() for we in self.webhook_events],
            creation_timestamp=self.creation_timestamp,
            last_updated_timestamp=self.last_updated_timestamp,
            description=self.description,
            status=WebhookStatus(self.status),
            secret=self.secret,
        )


class SqlWebhookEvent(Base):
    __tablename__ = "webhook_events"

    webhook_id = Column(String(256), ForeignKey("webhooks.webhook_id", ondelete="cascade"))
    entity = Column(String(50), nullable=False)
    action = Column(String(50), nullable=False)

    # Relationship
    webhook = relationship(
        "SqlWebhook", backref=backref("webhook_events", cascade="all, delete-orphan")
```

## 原始行 193 · command_execution

命令：
```
/bin/bash -lc "grep -n \"MLFLOW_TRACKING_\\(USERNAME\\|PASSWORD\\|TOKEN\\|INSECURE_TLS\\|SERVER_CERT_PATH\\|CLIENT_CERT_PATH\\|AWS_SIGV4\\|AUTH\\)\" mlflow/environment_variables.py; grep -n \"class MlflowHostCreds\" -A90 mlflow/utils/rest_utils.py; grep -RIn \"get_default_host_creds\" tests --include='*.py'"
```

退出码：`0`

输出：
```
174:MLFLOW_TRACKING_AWS_SIGV4 = _BooleanEnvironmentVariable("MLFLOW_TRACKING_AWS_SIGV4", False)
178:MLFLOW_TRACKING_AUTH = _EnvironmentVariable("MLFLOW_TRACKING_AUTH", str, None)
369:MLFLOW_TRACKING_USERNAME = _EnvironmentVariable("MLFLOW_TRACKING_USERNAME", str, None)
373:MLFLOW_TRACKING_PASSWORD = _EnvironmentVariable("MLFLOW_TRACKING_PASSWORD", str, None)
377:MLFLOW_TRACKING_TOKEN = _EnvironmentVariable("MLFLOW_TRACKING_TOKEN", str, None)
382:MLFLOW_TRACKING_INSECURE_TLS = _BooleanEnvironmentVariable("MLFLOW_TRACKING_INSECURE_TLS", False)
387:MLFLOW_TRACKING_SERVER_CERT_PATH = _EnvironmentVariable(
388:    "MLFLOW_TRACKING_SERVER_CERT_PATH", str, None
394:MLFLOW_TRACKING_CLIENT_CERT_PATH = _EnvironmentVariable(
395:    "MLFLOW_TRACKING_CLIENT_CERT_PATH", str, None
623:class MlflowHostCreds:
624-    """
625-    Provides a hostname and optional authentication for talking to an MLflow tracking server.
626-
627-    Args:
628-        host: Hostname (e.g., http://localhost:5000) to MLflow server. Required.
629-        username: Username to use with Basic authentication when talking to server.
630-            If this is specified, password must also be specified.
631-        password: Password to use with Basic authentication when talking to server.
632-            If this is specified, username must also be specified.
633-        token: Token to use with Bearer authentication when talking to server.
634-            If provided, user/password authentication will be ignored.
635-        aws_sigv4: If true, we will create a signature V4 to be added for any outgoing request.
636-            Keys for signing the request can be passed via ENV variables,
637-            or will be fetched via boto3 session.
638-        auth: If set, the auth will be added for any outgoing request.
639-            Keys for signing the request can be passed via ENV variables,
640-        ignore_tls_verification: If true, we will not verify the server's hostname or TLS
641-            certificate. This is useful for certain testing situations, but should never be
642-            true in production.
643-            If this is set to true ``server_cert_path`` must not be set.
644-        client_cert_path: Path to ssl client cert file (.pem).
645-            Sets the cert param of the ``requests.request``
646-            function (see https://requests.readthedocs.io/en/master/api/).
647-        server_cert_path: Path to a CA bundle to use.
648-            Sets the verify param of the ``requests.request``
649-            function (see https://requests.readthedocs.io/en/master/api/).
650-            If this is set ``ignore_tls_verification`` must be false.
651-        use_databricks_sdk: A boolean value represent whether using Databricks SDK for
652-            authentication.
653-        databricks_auth_profile: The name of the profile used by Databricks SDK for
654-            authentication.
655-        client_id: The client ID used by Databricks OAuth
656-        client_secret: The client secret used by Databricks OAuth
657-    """
658-
659-
660-
661-
662-
663-
664-
665-
666-
667-
668-
669-
670-
671-
672-
673-
674-
675-
676-
677-
678-
679-
680-
681-
682-
683-
684-
685-
686-
687-
688-
689-
690-
691-
692-
693-
694-
695-
696-
697-
698-
699-
700-
701-
702-
703-
704-
705-
706-
707-    def __eq__(self, other):
708-        if isinstance(other, self.__class__):
709-            return self.__dict__ == other.__dict__
710-        return NotImplemented
711-
712-    def __hash__(self):
713-        return hash(frozenset(self.__dict__.items()))
tests/store/artifact/test_mlflow_artifact_repo.py:10:from mlflow.utils.credentials import get_default_host_creds
tests/store/artifact/test_mlflow_artifact_repo.py:214:            get_default_host_creds(url),
tests/store/artifact/test_http_artifact_repo.py:25:from mlflow.utils.credentials import get_default_host_creds
tests/store/artifact/test_http_artifact_repo.py:211:            get_default_host_creds(url),
tests/store/artifact/test_http_artifact_repo.py:441:            get_default_host_creds(url),
tests/store/artifact/test_http_artifact_repo.py:469:            get_default_host_creds(url),
```

## 原始行 195 · agent_message

```
The restored public path now passes telemetry and reaches the SQL registry successfully. The broader REST-store suite is still blocked by unrelated masked credential primitives (`get_default_host_creds` and `MlflowHostCreds.__init__`), so I’m not expanding into those separate interfaces; I’m finishing verification against the SQL backend and focused webhook tests.
```

## 原始行 197 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import os
import tempfile
from cryptography.fernet import Fernet
from mlflow import MlflowClient
from mlflow.environment_variables import MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY
from mlflow.store.entities.paged_list import PagedList

with tempfile.NamedTemporaryFile(suffix='.db') as f:
    os.environ[MLFLOW_WEBHOOK_SECRET_ENCRYPTION_KEY.name] = Fernet.generate_key().decode()
    uri = f'sqlite:///{f.name}'
    client = MlflowClient(tracking_uri=uri, registry_uri=uri)
    created = client.create_webhook(
        'name', 'https://example.com/hook', ['model_version.created'], status='ACTIVE'
    )
    page = client.list_webhooks(max_results=1)
    assert isinstance(page, PagedList) and page[0].webhook_id == created.webhook_id
    assert client.get_webhook(created.webhook_id).events == created.events
    updated = client.update_webhook(
        created.webhook_id, events=['registered_model.created'], status='DISABLED'
    )
    assert str(updated.events[0]) == 'registered_model.created'
    assert str(updated.status) == 'DISABLED'
    client.delete_webhook(created.webhook_id)
print('public sqlite webhook CRUD passed')
PY"
```

退出码：`0`

输出：
```
2026/10/11 05:09:18 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:09:18 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 05:09:18 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 05:09:18 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 05:09:18 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 05:09:18 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 05:09:19 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 05:09:20 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 05:09:20 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 05:09:20 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 05:09:20 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:09:20 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026/10/11 05:09:20 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 05:09:20 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 05:09:20 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 05:09:20 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
public sqlite webhook CRUD passed
```

## 原始行 200 · command_execution

命令：
```
/bin/bash -lc 'ruff check mlflow/entities/webhook.py mlflow/tracking/client.py mlflow/tracking/_model_registry/client.py mlflow/tracking/_model_registry/utils.py mlflow/tracking/_model_registry/registry.py'
```

退出码：`2`

输出：
```
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 202 · command_execution

命令：
```
/bin/bash -lc 'ruff format --check mlflow/entities/webhook.py mlflow/tracking/client.py mlflow/tracking/_model_registry/client.py mlflow/tracking/_model_registry/utils.py mlflow/tracking/_model_registry/registry.py'
```

退出码：`2`

输出：
```
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 204 · command_execution

命令：
```
/bin/bash -lc "git diff --check; git status --short; git diff --stat; git diff -- mlflow/entities/webhook.py mlflow/tracking/_model_registry/client.py mlflow/tracking/client.py | sed -n '1,320p'"
```

退出码：`0`

输出：
```
 M mlflow/entities/webhook.py
 M mlflow/tracking/_model_registry/client.py
 M mlflow/tracking/_model_registry/registry.py
 M mlflow/tracking/_model_registry/utils.py
 M mlflow/tracking/client.py
 mlflow/entities/webhook.py                  | 17 +++---
 mlflow/tracking/_model_registry/client.py   | 64 ++++++++++++++++++-
 mlflow/tracking/_model_registry/registry.py |  1 +
 mlflow/tracking/_model_registry/utils.py    | 58 +++++++++++++++++-
 mlflow/tracking/client.py                   | 95 ++++++++++++++++++++++++++++-
 5 files changed, 223 insertions(+), 12 deletions(-)
diff --git a/mlflow/entities/webhook.py b/mlflow/entities/webhook.py
index dfffba3..c046188 100644
--- a/mlflow/entities/webhook.py
+++ b/mlflow/entities/webhook.py
@@ -235,11 +235,10 @@ class WebhookEvent:
     def __str__(self) -> str:
         return f"{self.entity.value}.{self.action.value}"
 
-
-
-
-
-
+    def __eq__(self, other: object) -> bool:
+        if not isinstance(other, WebhookEvent):
+            return False
+        return self.entity == other.entity and self.action == other.action
     def __hash__(self) -> int:
         return hash((self.entity, self.action))
 
@@ -315,9 +314,9 @@ class Webhook:
     def status(self) -> WebhookStatus:
         return self._status
 
-
-
-
+    @property
+    def secret(self) -> str | None:
+        return self._secret
 
     @property
     def creation_timestamp(self) -> int:
@@ -434,4 +433,4 @@ class WebhookTestResult:
             f"response_body={self.response_body!r}, "
             f"error_message={self.error_message!r}"
             f")"
-        )
\ No newline at end of file
+        )
diff --git a/mlflow/tracking/_model_registry/client.py b/mlflow/tracking/_model_registry/client.py
index 64e3b49..3a421fe 100644
--- a/mlflow/tracking/_model_registry/client.py
+++ b/mlflow/tracking/_model_registry/client.py
@@ -893,6 +893,68 @@ class ModelRegistryClient:
 
 
 
+
+    @experimental(version="3.3.0")
+    @record_usage_event(CreateWebhookEvent)
+    def create_webhook(
+        self,
+        name: str,
+        url: str,
+        events: list[WebhookEventStr | WebhookEvent],
+        description: str | None = None,
+        secret: str | None = None,
+        status: str | WebhookStatus | None = None,
+    ) -> Webhook:
+        events = [
+            WebhookEvent.from_str(event) if isinstance(event, str) else event for event in events
+        ]
+        if isinstance(status, str):
+            status = WebhookStatus(status)
+        return self.store.create_webhook(name, url, events, description, secret, status)
+
+    @experimental(version="3.3.0")
+    def get_webhook(self, webhook_id: str) -> Webhook:
+        return self.store.get_webhook(webhook_id)
+
+    @experimental(version="3.3.0")
+    def list_webhooks(
+        self,
+        max_results: int | None = None,
+        page_token: str | None = None,
+    ) -> PagedList[Webhook]:
+        return self.store.list_webhooks(max_results=max_results, page_token=page_token)
+
+    @experimental(version="3.3.0")
+    def update_webhook(
+        self,
+        webhook_id: str,
+        name: str | None = None,
+        description: str | None = None,
+        url: str | None = None,
+        events: list[WebhookEventStr | WebhookEvent] | None = None,
+        secret: str | None = None,
+        status: str | WebhookStatus | None = None,
+    ) -> Webhook:
+        if events is not None:
+            events = [
+                WebhookEvent.from_str(event) if isinstance(event, str) else event
+                for event in events
+            ]
+        if isinstance(status, str):
+            status = WebhookStatus(status)
+        return self.store.update_webhook(
+            webhook_id=webhook_id,
+            name=name,
+            description=description,
+            url=url,
+            events=events,
+            secret=secret,
+            status=status,
+        )
+
+    @experimental(version="3.3.0")
+    def delete_webhook(self, webhook_id: str) -> None:
+        self.store.delete_webhook(webhook_id)
 
     @experimental(version="3.3.0")
     def test_webhook(
@@ -914,4 +976,4 @@ class ModelRegistryClient:
         # Convert string to WebhookEvent if needed
         if isinstance(event, str):
             event = WebhookEvent.from_str(event)
-        return self.store.test_webhook(webhook_id, event)
\ No newline at end of file
+        return self.store.test_webhook(webhook_id, event)
diff --git a/mlflow/tracking/client.py b/mlflow/tracking/client.py
index cdb0c83..27471af 100644
--- a/mlflow/tracking/client.py
+++ b/mlflow/tracking/client.py
@@ -262,6 +262,24 @@ class MlflowClient:
 
 
 
+
+    def _get_registry_client(self) -> ModelRegistryClient:
+        """Create and cache the registry client on first use."""
+        try:
+            return self._registry_client
+        except AttributeError:
+            try:
+                registry_client = ModelRegistryClient(
+                    self._registry_uri, self._tracking_client.tracking_uri
+                )
+            except UnsupportedModelRegistryStoreURIException as exc:
+                raise MlflowException(
+                    "Model Registry features are not supported by the store with URI: "
+                    f"'{self._registry_uri}'. Stores with the following URI schemes are supported: "
+                    f"{exc.supported_uri_schemes}."
+                ) from exc
+            self._registry_client = registry_client
+            return registry_client
 
     # Tracking API
 
@@ -6432,6 +6450,81 @@ class MlflowClient:
 
 
 
+
+    @experimental(version="3.3.0")
+    def create_webhook(
+        self,
+        name: str,
+        url: str,
+        events: list[WebhookEventStr | WebhookEvent],
+        description: str | None = None,
+        secret: str | None = None,
+        status: str | WebhookStatus | None = None,
+    ) -> Webhook:
+        """Create a webhook for the specified events."""
+        events = [
+            WebhookEvent.from_str(event) if isinstance(event, str) else event for event in events
+        ]
+        if isinstance(status, str):
+            status = WebhookStatus(status)
+        return self._get_registry_client().create_webhook(
+            name=name,
+            url=url,
+            events=events,
+            description=description,
+            secret=secret,
+            status=status,
+        )
+
+    @experimental(version="3.3.0")
+    def delete_webhook(self, webhook_id: str) -> None:
+        """Delete a webhook by ID."""
+        self._get_registry_client().delete_webhook(webhook_id)
+
+    @experimental(version="3.3.0")
+    def get_webhook(self, webhook_id: str) -> Webhook:
+        """Get a webhook by ID."""
+        return self._get_registry_client().get_webhook(webhook_id)
+
+    @experimental(version="3.3.0")
+    def list_webhooks(
+        self,
+        max_results: int | None = None,
+        page_token: str | None = None,
+    ) -> PagedList[Webhook]:
+        """List webhooks, preserving the page token on the returned result."""
+        return self._get_registry_client().list_webhooks(
+            max_results=max_results, page_token=page_token
+        )
+
+    @experimental(version="3.3.0")
+    def update_webhook(
+        self,
+        webhook_id: str,
+        name: str | None = None,
+        description: str | None = None,
+        url: str | None = None,
+        events: list[WebhookEventStr | WebhookEvent] | None = None,
+        secret: str | None = None,
+        status: str | WebhookStatus | None = None,
+    ) -> Webhook:
+        """Update the supplied fields of an existing webhook."""
+        if events is not None:
+            events = [
+                WebhookEvent.from_str(event) if isinstance(event, str) else event
+                for event in events
+            ]
+        if isinstance(status, str):
+            status = WebhookStatus(status)
+        return self._get_registry_client().update_webhook(
+            webhook_id=webhook_id,
+            name=name,
+            description=description,
+            url=url,
+            events=events,
+            secret=secret,
+            status=status,
+        )
 
     @experimental(version="3.3.0")
     def test_webhook(
@@ -6449,4 +6542,4 @@ class MlflowClient:
         Returns:
             WebhookTestResult indicating success/failure and response details.
         """
-        return self._get_registry_client().test_webhook(webhook_id, event)
\ No newline at end of file
+        return self._get_registry_client().test_webhook(webhook_id, event)
```

## 原始行 207 · file_change

```
{
  "id": "item_130",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/entities/webhook.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 210 · command_execution

命令：
```
/bin/bash -lc "sed -n '50,95p' mlflow/store/model_registry/rest_store.py; grep -n \"def call_endpoint\" mlflow/utils/rest_utils.py | head"
```

退出码：`0`

输出：
```
_WEBHOOK_METHOD_TO_INFO = extract_api_info_for_service(WebhookService, _REST_API_PATH_PREFIX)

_logger = logging.getLogger(__name__)


class RestStore(BaseRestStore):
    """
    Client for a remote model registry server accessed via REST API calls

    Args:
        get_host_creds: Method to be invoked prior to every REST request to get the
            :py:class:`mlflow.rest_utils.MlflowHostCreds` for the request. Note that this
            is a function so that we can obtain fresh credentials in the case of expiry.
    """

    def _get_response_from_method(self, method):
        return method.Response()

    def _get_endpoint_from_method(self, method):
        return _METHOD_TO_INFO[method]

    def _get_all_endpoints_from_method(self, method):
        return _METHOD_TO_ALL_INFO[method]

    def _get_webhook_endpoint_from_method(self, method):
        return _WEBHOOK_METHOD_TO_INFO[method]

    def _call_webhook_endpoint(
        self,
        api,
        json_body: str | None = None,
        webhook_id: str | None = None,
    ):
        endpoint, method = self._get_webhook_endpoint_from_method(api)
        if webhook_id:
            endpoint = endpoint.format(webhook_id=webhook_id)
        response_proto = self._get_response_from_method(api)
        return call_endpoint(self.get_host_creds(), endpoint, method, json_body, response_proto)

    # CRUD API for RegisteredModel objects

    def create_registered_model(self, name, tags=None, description=None, deployment_job_id=None):
        """
        Create a new registered model in backend store.

        Args:
610:def call_endpoints(host_creds, endpoints, json_body, response_proto, extra_headers=None):
```

## 原始行 213 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from mlflow.utils.rest_utils import MlflowHostCreds
print(inspect.signature(MlflowHostCreds))
try: print(MlflowHostCreds('http://x'))
except Exception as e: print(type(e).__name__, e)
PY"
```

退出码：`0`

输出：
```
()
TypeError MlflowHostCreds() takes no arguments
```

## 原始行 216 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from unittest.mock import MagicMock
from mlflow.entities.webhook import WebhookEvent, WebhookEntity, WebhookAction, WebhookStatus
from mlflow.store.entities.paged_list import PagedList
from mlflow.tracking.client import MlflowClient

client = object.__new__(MlflowClient)
registry = MagicMock()
client._registry_client = registry
client._registry_uri = 'unused'
client.create_webhook('n', 'u', ['model_version.created'], status='ACTIVE')
kwargs = registry.create_webhook.call_args.kwargs
assert kwargs['events'] == [WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)]
assert kwargs['status'] is WebhookStatus.ACTIVE
page = PagedList([], 'next')
registry.list_webhooks.return_value = page
assert client.list_webhooks(2, 'previous') is page
client.update_webhook('id', events=[], status='DISABLED')
kwargs = registry.update_webhook.call_args.kwargs
assert kwargs['events'] == [] and kwargs['status'] is WebhookStatus.DISABLED
client.delete_webhook('id')
registry.delete_webhook.assert_called_once_with('id')
print('mocked public client behavior passed')
PY
python -m pytest tests/entities/test_webhook.py tests/tracking/_model_registry/test_model_registry_client.py tests/telemetry/test_tracked_events.py::test_create_webhook -q"
```

退出码：`0`

输出：
```
mocked public client behavior passed
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 63 items

tests/entities/test_webhook.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                   [ 36%][0m
tests/tracking/_model_registry/test_model_registry_client.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m [ 53%]
[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                             [ 98%][0m
tests/telemetry/test_tracked_events.py [32m.[0m[32m                                 [100%][0m

============================= slowest 10 durations =============================
1.95s call     tests/telemetry/test_tracked_events.py::test_create_webhook
1.00s teardown tests/telemetry/test_tracked_events.py::test_create_webhook

(8 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                     | Duration | Tests | Min    | Max    | Avg    |
| ---- | ---------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/telemetry/test_tracked_events.py` | 2.95s    | 1     | 2.954s | 2.954s | 2.954s |

::endgroup::

[32m============================== [32m[1m63 passed[0m[32m in 4.03s[0m[32m ==============================[0m
```

## 原始行 219 · command_execution

命令：
```
/bin/bash -lc 'git diff -- mlflow/tracking/_model_registry/utils.py mlflow/tracking/_model_registry/registry.py; git diff --check; python -m compileall -q mlflow/entities/webhook.py mlflow/tracking/client.py mlflow/tracking/_model_registry/client.py mlflow/tracking/_model_registry/utils.py mlflow/tracking/_model_registry/registry.py; git status --short'
```

退出码：`0`

输出：
```
diff --git a/mlflow/tracking/_model_registry/registry.py b/mlflow/tracking/_model_registry/registry.py
index 6d5b2ba..dd98198 100644
--- a/mlflow/tracking/_model_registry/registry.py
+++ b/mlflow/tracking/_model_registry/registry.py
@@ -42,6 +42,7 @@ class ModelRegistryStoreRegistry(StoreRegistry):
 
         """
 
+        from mlflow.tracking._model_registry.utils import _resolve_registry_uri
         from mlflow.tracking._tracking_service.utils import _resolve_tracking_uri
 
         resolved_store_uri = _resolve_registry_uri(store_uri)
diff --git a/mlflow/tracking/_model_registry/utils.py b/mlflow/tracking/_model_registry/utils.py
index 4c4e79c..2e11c3f 100644
--- a/mlflow/tracking/_model_registry/utils.py
+++ b/mlflow/tracking/_model_registry/utils.py
@@ -148,6 +148,32 @@ def set_registry_uri(uri: str) -> None:
 
 
 
+
+
+def _get_registry_uri_from_spark_session() -> str | None:
+    if spark_session := _get_active_spark_session():
+        return spark_session.conf.get("spark.mlflow.modelRegistryUri", None)
+    return None
+
+
+def _resolve_registry_uri(registry_uri=None, tracking_uri=None):
+    if registry_uri is not None:
+        return registry_uri
+    if _registry_uri is not None:
+        return _registry_uri or None
+    if uri := MLFLOW_REGISTRY_URI.get():
+        return uri
+    if uri := _get_registry_uri_from_spark_session():
+        return uri
+    if is_in_databricks_serverless_runtime():
+        return _DATABRICKS_UNITY_CATALOG_SCHEME
+
+    tracking_uri = _resolve_tracking_uri(tracking_uri)
+    if is_databricks_uri(tracking_uri):
+        profile, key_prefix = get_db_info_from_uri(tracking_uri)
+        profile = f"{profile}:{key_prefix}" if key_prefix else profile
+        return construct_db_uc_uri_from_profile(profile)
+    return tracking_uri
 
 
 def get_registry_uri() -> str:
@@ -201,6 +227,12 @@ def _get_sqlalchemy_store(store_uri):
 
 
 
+def _get_rest_store(store_uri, **_):
+    from mlflow.utils.credentials import get_default_host_creds
+
+    return RestStore(partial(get_default_host_creds, store_uri))
+
+
 def _get_databricks_rest_store(store_uri, tracking_uri, **_):
     warn_on_deprecated_cross_workspace_registry_uri(registry_uri=store_uri)
     return DatabricksWorkspaceModelRegistryRestStore(store_uri, tracking_uri)
@@ -241,7 +273,31 @@ def _get_file_store(store_uri, **_):
 
 
 
+
+
+def _get_databricks_uc_rest_store(store_uri, tracking_uri, **_):
+    from mlflow.store._unity_catalog.registry.rest_store import UcModelRegistryStore
+
+    return UcModelRegistryStore(store_uri, tracking_uri)
+
+
+def _get_store_registry():
+    global _model_registry_store_registry
+    if _model_registry_store_registry is None:
+        registry = ModelRegistryStoreRegistry()
+        registry.register("", _get_file_store)
+        registry.register("file", _get_file_store)
+        for scheme in DATABASE_ENGINES:
+            registry.register(scheme, _get_sqlalchemy_store)
+        for scheme in ("http", "https"):
+            registry.register(scheme, _get_rest_store)
+        registry.register("databricks", _get_databricks_rest_store)
+        registry.register(_DATABRICKS_UNITY_CATALOG_SCHEME, _get_databricks_uc_rest_store)
+        registry.register(_OSS_UNITY_CATALOG_SCHEME, _get_databricks_uc_rest_store)
+        registry.register_entrypoints()
+        _model_registry_store_registry = registry
+    return _model_registry_store_registry
 
 
 def _get_store(store_uri=None, tracking_uri=None):
-    return _get_store_registry().get_store(store_uri, tracking_uri)
\ No newline at end of file
+    return _get_store_registry().get_store(store_uri, tracking_uri)
 M mlflow/entities/webhook.py
 M mlflow/tracking/_model_registry/client.py
 M mlflow/tracking/_model_registry/registry.py
 M mlflow/tracking/_model_registry/utils.py
 M mlflow/tracking/client.py
```

## 原始行 222 · command_execution

命令：
```
/bin/bash -lc "awk 'length("'$0) > 100 {print FNR ":" length($0) ":" $0}'"' mlflow/entities/webhook.py mlflow/tracking/client.py mlflow/tracking/_model_registry/client.py mlflow/tracking/_model_registry/utils.py mlflow/tracking/_model_registry/registry.py | tail -30"
```

退出码：`0`

输出：
```

```

## 原始行 224 · agent_message

```
Implemented webhook CRUD restoration and entity accessors.

Changes include:

- Restored `MlflowClient` webhook create/get/list/update/delete methods.
- Added string event and status normalization.
- Preserved `PagedList` pagination tokens.
- Restored internal registry-client delegation and required URI/store helpers.
- Added `Webhook.secret`.
- Added `WebhookEvent.__eq__`.

Validation:

- 63 focused tests passed.
- Public SQLite webhook CRUD passed end to end.
- Mocked normalization, pagination identity, and empty-event update behavior passed.
- Compilation and `git diff --check` passed.

Modified files include [client.py](/testbed/mlflow/tracking/client.py), [webhook.py](/testbed/mlflow/entities/webhook.py), and internal registry support files.
```
