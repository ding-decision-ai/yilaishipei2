# Codex baseline: mlflow__mlflow.93dab383.test_client.42de781c.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 3 · agent_message

```
I’ll inspect the telemetry implementation and its focused tests first, then patch the lifecycle, batching, filtering, and shutdown behavior and run the relevant pytest subset.
```

## 原始行 5 · command_execution

命令：
```
/bin/bash -lc "pwd && rg --files mlflow/telemetry tests | sed -n '1,240p'"
```

退出码：`0`

输出：
```
/testbed
/bin/bash: line 1: rg: command not found
```

## 原始行 8 · command_execution

命令：
```
/bin/bash -lc "find mlflow/telemetry tests -type f | sort | sed -n '1,260p'"
```

退出码：`0`

输出：
```
mlflow/telemetry/__init__.py
mlflow/telemetry/client.py
mlflow/telemetry/constant.py
mlflow/telemetry/events.py
mlflow/telemetry/schemas.py
mlflow/telemetry/track.py
mlflow/telemetry/utils.py
tests/__init__.py
tests/ag2/__init__.py
tests/ag2/test_ag2_autolog.py
tests/agno/__init__.py
tests/agno/conftest.py
tests/agno/test_agno_tracing.py
tests/ai_commands/__init__.py
tests/ai_commands/test_ai_command_utils.py
tests/anthropic/__init__.py
tests/anthropic/test_anthropic_autolog.py
tests/artifacts/__init__.py
tests/artifacts/test_artifacts.py
tests/autogen/__init__.py
tests/autogen/test_autogen_autolog.py
tests/autologging/__init__.py
tests/autologging/async_helper.py
tests/autologging/fixtures.py
tests/autologging/test_autologging_behaviors_integration.py
tests/autologging/test_autologging_behaviors_unit.py
tests/autologging/test_autologging_client.py
tests/autologging/test_autologging_safety_unit.py
tests/autologging/test_autologging_utils.py
tests/autologging/test_training_session.py
tests/bedrock/__init__.py
tests/bedrock/test_bedrock_autolog.py
tests/catboost/__init__.py
tests/catboost/test_catboost_model_export.py
tests/check_mlflow_lazily_imports_ml_packages.py
tests/claude_code/__init__.py
tests/claude_code/test_autolog.py
tests/claude_code/test_cli.py
tests/claude_code/test_config.py
tests/claude_code/test_tracing.py
tests/cli/__init__.py
tests/cli/test_ai_commands.py
tests/cli/test_eval.py
tests/cli/test_genai_eval_utils.py
tests/cli/test_scorers.py
tests/cli/test_traces.py
tests/conftest.py
tests/crewai/__init__.py
tests/crewai/test_crewai_autolog.py
tests/data/__init__.py
tests/data/test_artifact_dataset_sources.py
tests/data/test_code_dataset_source.py
tests/data/test_dataset.py
tests/data/test_dataset_registry.py
tests/data/test_dataset_source.py
tests/data/test_dataset_source_registry.py
tests/data/test_delta_dataset_source.py
tests/data/test_http_dataset_source.py
tests/data/test_huggingface_dataset_and_source.py
tests/data/test_meta_dataset.py
tests/data/test_numpy_dataset.py
tests/data/test_pandas_dataset.py
tests/data/test_polars_dataset.py
tests/data/test_spark_dataset.py
tests/data/test_spark_dataset_source.py
tests/data/test_tensorflow_dataset.py
tests/datasets/apollo11_launch.wav
tests/datasets/cat.png
tests/datasets/cat_image.jpg
tests/datasets/tiger_cat.jpg
tests/datasets/uci-autos-imports-85.data
tests/datasets/winequality-red.csv
tests/datasets/winequality-white.csv
tests/db/.dockerignore
tests/db/.gitignore
tests/db/Dockerfile
tests/db/Dockerfile.mssql
tests/db/README.md
tests/db/__init__.py
tests/db/check_migration.py
tests/db/check_migration.sh
tests/db/compose.sh
tests/db/compose.yml
tests/db/conftest.py
tests/db/entrypoint.sh
tests/db/init-mssql-db.sh
tests/db/init-mssql-db.sql
tests/db/schemas/mssql.sql
tests/db/schemas/mysql.sql
tests/db/schemas/postgresql.sql
tests/db/schemas/sqlite.sql
tests/db/test_schema.py
tests/db/test_tracking_operations.py
tests/db/update_schemas.sh
tests/deployments/__init__.py
tests/deployments/databricks/__init__.py
tests/deployments/databricks/test_databricks.py
tests/deployments/mlflow/__init__.py
tests/deployments/mlflow/test_mlflow.py
tests/deployments/openai/__init__.py
tests/deployments/openai/test_openai.py
tests/deployments/test_cli.py
tests/deployments/test_deployments.py
tests/deployments/test_interface.py
tests/deployments/test_utils.py
tests/dev/__init__.py
tests/dev/test_check_function_signatures.py
tests/dev/test_check_init_py.py
tests/dev/test_remove_experimental_decorators.py
tests/dev/test_update_mlflow_versions.py
tests/diviner/__init__.py
tests/diviner/test_diviner_model_export.py
tests/dspy/__init__.py
tests/dspy/conftest.py
tests/dspy/test_dspy_autolog.py
tests/dspy/test_dspy_evaluate.py
tests/dspy/test_dspy_util.py
tests/dspy/test_save.py
tests/entities/__init__.py
tests/entities/conftest.py
tests/entities/model_registry/__init__.py
tests/entities/model_registry/test_model_version.py
tests/entities/model_registry/test_registered_model.py
tests/entities/test_assessment.py
tests/entities/test_assessment_source.py
tests/entities/test_dataset.py
tests/entities/test_dataset_input.py
tests/entities/test_dataset_record.py
tests/entities/test_dataset_record_source.py
tests/entities/test_evaluation_dataset.py
tests/entities/test_experiment.py
tests/entities/test_file_info.py
tests/entities/test_input_tag.py
tests/entities/test_metric.py
tests/entities/test_param.py
tests/entities/test_prompt.py
tests/entities/test_run.py
tests/entities/test_run_data.py
tests/entities/test_run_info.py
tests/entities/test_run_inputs.py
tests/entities/test_run_status.py
tests/entities/test_span.py
tests/entities/test_span_event.py
tests/entities/test_span_status.py
tests/entities/test_trace.py
tests/entities/test_trace_data.py
tests/entities/test_trace_info.py
tests/entities/test_trace_info_v2.py
tests/entities/test_trace_location.py
tests/entities/test_trace_state.py
tests/entities/test_trace_status.py
tests/entities/test_view_type.py
tests/entities/test_webhook.py
tests/evaluate/__init__.py
tests/evaluate/logging/__init__.py
tests/evaluate/logging/test_assessment.py
tests/evaluate/logging/test_assessment_entity.py
tests/evaluate/logging/test_evaluation.py
tests/evaluate/logging/test_evaluation_entity.py
tests/evaluate/logging/test_evaluation_tag.py
tests/evaluate/logging/test_fluent.py
tests/evaluate/logging/test_utils.py
tests/evaluate/logging/utils.py
tests/evaluate/test_default_evaluator.py
tests/evaluate/test_default_evaluator_delta.py
tests/evaluate/test_deprecated.py
tests/evaluate/test_evaluation.py
tests/evaluate/test_validation.py
tests/examples/README.md
tests/examples/__init__.py
tests/examples/test_examples.py
tests/gateway/__init__.py
tests/gateway/providers/__init__.py
tests/gateway/providers/test_ai21labs.py
tests/gateway/providers/test_anthropic.py
tests/gateway/providers/test_bedrock.py
tests/gateway/providers/test_cohere.py
tests/gateway/providers/test_gemini.py
tests/gateway/providers/test_huggingface.py
tests/gateway/providers/test_mistral.py
tests/gateway/providers/test_mlflow.py
tests/gateway/providers/test_mosaicml.py
tests/gateway/providers/test_openai.py
tests/gateway/providers/test_openai_uc_functions.py
tests/gateway/providers/test_palm.py
tests/gateway/providers/test_provider_utils.py
tests/gateway/providers/test_togetherai.py
tests/gateway/providers/test_traffic_route_provider.py
tests/gateway/schemas/__init__.py
tests/gateway/schemas/test_chat.py
tests/gateway/schemas/test_completions.py
tests/gateway/schemas/test_embeddings.py
tests/gateway/test_cli.py
tests/gateway/test_gateway_app.py
tests/gateway/test_gateway_config_parsing.py
tests/gateway/test_openai_compatibility.py
tests/gateway/test_runner.py
tests/gateway/test_utils.py
tests/gateway/tools.py
tests/gemini/__init__.py
tests/gemini/test_gemini_autolog.py
tests/gemini/test_legacy_gemini_autolog.py
tests/genai/__init__.py
tests/genai/conftest.py
tests/genai/datasets/__init__.py
tests/genai/datasets/test_databricks_evaluation_dataset_source.py
tests/genai/datasets/test_evaluation_dataset.py
tests/genai/datasets/test_fluent.py
tests/genai/evaluate/__init__.py
tests/genai/evaluate/test_context.py
tests/genai/evaluate/test_evaluation.py
tests/genai/evaluate/test_telemetry.py
tests/genai/evaluate/test_to_predict_fn.py
tests/genai/evaluate/test_utils.py
tests/genai/judges/__init__.py
tests/genai/judges/adapters/__init__.py
tests/genai/judges/adapters/test_databricks_adapter.py
tests/genai/judges/adapters/test_litellm_adapter.py
tests/genai/judges/optimizers/__init__.py
tests/genai/judges/optimizers/conftest.py
tests/genai/judges/optimizers/test_dspy_base.py
tests/genai/judges/optimizers/test_dspy_utils.py
tests/genai/judges/optimizers/test_simba.py
tests/genai/judges/test_alignment_optimizer.py
tests/genai/judges/test_builtin.py
tests/genai/judges/test_custom_prompt_judge.py
tests/genai/judges/test_judge_base.py
tests/genai/judges/test_judge_tool_get_root_span.py
tests/genai/judges/test_judge_tool_get_span.py
tests/genai/judges/test_judge_tool_get_span_performance_and_timing_report.py
tests/genai/judges/test_judge_tool_get_trace_info.py
tests/genai/judges/test_judge_tool_get_traces_in_session.py
tests/genai/judges/test_judge_tool_list_spans.py
tests/genai/judges/test_judge_tool_registry.py
tests/genai/judges/test_judge_tool_search_traces.py
tests/genai/judges/test_make_judge.py
tests/genai/judges/test_search_trace_regex_tool.py
tests/genai/judges/utils/__init__.py
tests/genai/judges/utils/test_invocation_utils.py
tests/genai/judges/utils/test_parsing_utils.py
tests/genai/judges/utils/test_prompt_utils.py
tests/genai/judges/utils/test_tool_calling_utils.py
tests/genai/label_schemas/__init__.py
tests/genai/label_schemas/test_label_schemas.py
tests/genai/labeling/__init__.py
tests/genai/labeling/test_labeling.py
tests/genai/optimize/__init__.py
tests/genai/optimize/optimizers/__init__.py
tests/genai/optimize/optimizers/test_gepa_optimizer.py
tests/genai/optimize/test_optimize.py
tests/genai/optimize/test_util.py
tests/genai/prompts/__init__.py
tests/genai/prompts/test_prompts.py
tests/genai/scorers/__init__.py
tests/genai/scorers/test_aggregation.py
tests/genai/scorers/test_builtin_scorers.py
tests/genai/scorers/test_builtin_scorers_registration.py
tests/genai/scorers/test_registered_scorers_scheduling.py
tests/genai/scorers/test_scorer.py
tests/genai/scorers/test_scorer_CRUD.py
```

## 原始行 11 · command_execution

命令：
```
/bin/bash -lc "find tests -type f -iname '*telemetry*' -o -path '*/telemetry/*' | sort && sed -n '1,320p' mlflow/telemetry/client.py && sed -n '1,260p' mlflow/telemetry/track.py"
```

退出码：`0`

输出：
```
tests/genai/evaluate/test_telemetry.py
tests/telemetry/__init__.py
tests/telemetry/conftest.py
tests/telemetry/helper_functions.py
tests/telemetry/test_events.py
tests/telemetry/test_track.py
tests/telemetry/test_tracked_events.py
tests/telemetry/test_utils.py
import atexit
import random
import sys
import threading
import time
import uuid
import warnings
from dataclasses import asdict
from queue import Empty, Full, Queue

import requests

from mlflow.environment_variables import _MLFLOW_TELEMETRY_SESSION_ID
from mlflow.telemetry.constant import (
    BATCH_SIZE,
    BATCH_TIME_INTERVAL_SECONDS,
    MAX_QUEUE_SIZE,
    MAX_WORKERS,
    RETRYABLE_ERRORS,
    UNRECOVERABLE_ERRORS,
)
from mlflow.telemetry.schemas import Record, TelemetryConfig, TelemetryInfo, get_source_sdk
from mlflow.telemetry.utils import _log_error, is_telemetry_disabled
from mlflow.utils.logging_utils import should_suppress_logs_in_thread


class TelemetryClient:




















































































































    def _process_records(self, records: list[Record], request_timeout: float = 1):
        """Process a batch of telemetry records."""
        try:
            self._update_backend_store()
            if self.info["tracking_uri_scheme"] in ["databricks", "databricks-uc", "uc"]:
                self._is_stopped = True
                # set config to None to allow consumer thread drop records in the queue
                self.config = None
                self.is_active = False
                _set_telemetry_client(None)
                return

            records = [
                {
                    "data": self.info | record.to_dict(),
                    # use random uuid as partition key to make sure records are
                    # distributed evenly across shards
                    "partition-key": uuid.uuid4().hex,
                }
                for record in records
            ]
            # changing this value can affect total time for processing records
            # the total time = request_timeout * max_attempts + sleep_time * (max_attempts - 1)
            max_attempts = 3
            sleep_time = 1
            for i in range(max_attempts):
                should_retry = False
                response = None
                try:
                    response = requests.post(
                        self.config.ingestion_url,
                        json={"records": records},
                        headers={"Content-Type": "application/json"},
                        timeout=request_timeout,
                    )
                    should_retry = response.status_code in RETRYABLE_ERRORS
                except (ConnectionError, TimeoutError):
                    should_retry = True
                # NB: DO NOT retry when terminating
                # otherwise this increases shutdown overhead significantly
                if self._is_stopped:
                    return
                if i < max_attempts - 1 and should_retry:
                    # we do not use exponential backoff to avoid increasing
                    # the processing time significantly
                    time.sleep(sleep_time)
                elif response and response.status_code in UNRECOVERABLE_ERRORS:
                    self._is_stopped = True
                    self.is_active = False
                    # this is executed in the consumer thread, so
                    # we cannot join the thread here, but this should
                    # be enough to stop the telemetry collection
                    return
                else:
                    return
        except Exception as e:
            _log_error(f"Failed to send telemetry records: {e}")

    def _consumer(self) -> None:
        """Individual consumer that processes records from the queue."""
        # suppress logs in the consumer thread to avoid emitting any irrelevant
        # logs during telemetry collection.
        should_suppress_logs_in_thread.set(True)

        while not self._is_config_fetched:
            time.sleep(0.1)

        while self.config and not self._is_stopped:
            try:
                records = self._queue.get(timeout=1)
            except Empty:
                # check if batch time interval has passed and send data if needed
                if time.time() - self._last_batch_time >= self._batch_time_interval:
                    self._last_batch_time = time.time()
                    with self._batch_lock:
                        if self._pending_records:
                            self._send_batch()
                continue

            self._process_records(records)
            self._queue.task_done()

        # clear the queue if config is None
        while self.config is None and not self._queue.empty():
            try:
                self._queue.get_nowait()
                self._queue.task_done()
            except Empty:
                break
        # drop remaining records when terminating to avoid
        # causing any overhead





















    @property
    def is_active(self) -> bool:
        return self._is_active

    @is_active.setter
    def is_active(self, value: bool) -> None:
        self._is_active = value






















































    def _update_backend_store(self):
        """
        Backend store might be changed after mlflow is imported, we should use this
        method to update the backend store info at sending telemetry step.
import functools
import inspect
import logging
import time
from typing import Any, Callable, ParamSpec, TypeVar

from mlflow.environment_variables import MLFLOW_EXPERIMENT_ID
from mlflow.telemetry.client import get_telemetry_client
from mlflow.telemetry.events import Event
from mlflow.telemetry.schemas import Record, Status
from mlflow.telemetry.utils import _log_error, is_telemetry_disabled

P = ParamSpec("P")
R = TypeVar("R")

_logger = logging.getLogger(__name__)


def record_usage_event(event: type[Event]) -> Callable[[Callable[P, R]], Callable[P, R]]:
    def decorator(func: Callable[P, R]) -> Callable[P, R]:
        @functools.wraps(func)
        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
            if is_telemetry_disabled() or _is_telemetry_disabled_for_event(event):
                return func(*args, **kwargs)

            success = True
            result = None
            start_time = time.time()
            try:
                result = func(*args, **kwargs)
                return result  # noqa: RET504
            except Exception:
                success = False
                raise
            finally:
                try:
                    duration_ms = int((time.time() - start_time) * 1000)
                    _add_telemetry_record(func, args, kwargs, success, duration_ms, event, result)
                except Exception as e:
                    _log_error(f"Failed to record telemetry event {event.name}: {e}")

        return wrapper

    return decorator


def _add_telemetry_record(
    func: Callable[..., Any],
    args: tuple[Any, ...],
    kwargs: dict[str, Any],
    success: bool,
    duration_ms: int,
    event: type[Event],
    result: Any,
) -> None:
    try:
        if client := get_telemetry_client():
            signature = inspect.signature(func)
            bound_args = signature.bind(*args, **kwargs)
            bound_args.apply_defaults()

            arguments = dict(bound_args.arguments)
            arguments.pop("self", None)

            params = list(arguments.keys())
            if params and params[0] == "cls" and isinstance(arguments["cls"], type):
                del arguments["cls"]

            record_params = event.parse(arguments) or {}
            if hasattr(event, "parse_result"):
                record_params.update(event.parse_result(result))
            if experiment_id := MLFLOW_EXPERIMENT_ID.get():
                record_params["mlflow_experiment_id"] = experiment_id
            record = Record(
                event_name=event.name,
                timestamp_ns=time.time_ns(),
                params=record_params or None,
                status=Status.SUCCESS if success else Status.FAILURE,
                duration_ms=duration_ms,
            )
            client.add_record(record)
    except Exception as e:
        _log_error(f"Failed to generate telemetry record for event {event.name}: {e}")


def _record_event(event: type[Event], params: dict[str, Any] | None = None) -> None:
    try:
        if client := get_telemetry_client():
            if experiment_id := MLFLOW_EXPERIMENT_ID.get():
                params["mlflow_experiment_id"] = experiment_id
            client.add_record(
                Record(
                    event_name=event.name,
                    params=params,
                    timestamp_ns=time.time_ns(),
                    status=Status.SUCCESS,
                    duration_ms=0,
                )
            )
    except Exception as e:
        _log_error(f"Failed to record telemetry event {event.name}: {e}")
```

## 原始行 14 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/telemetry/client.py | sed -n '1,520p'; nl -ba mlflow/telemetry/track.py | sed -n '1,260p'; find tests/telemetry -maxdepth 1 -type f -print -exec sh -c 'echo FILE:"'$1; sed -n "1,360p" "$1"'"' _ {} \\;"
```

退出码：`0`

输出：
```
     1	import atexit
     2	import random
     3	import sys
     4	import threading
     5	import time
     6	import uuid
     7	import warnings
     8	from dataclasses import asdict
     9	from queue import Empty, Full, Queue
    10	
    11	import requests
    12	
    13	from mlflow.environment_variables import _MLFLOW_TELEMETRY_SESSION_ID
    14	from mlflow.telemetry.constant import (
    15	    BATCH_SIZE,
    16	    BATCH_TIME_INTERVAL_SECONDS,
    17	    MAX_QUEUE_SIZE,
    18	    MAX_WORKERS,
    19	    RETRYABLE_ERRORS,
    20	    UNRECOVERABLE_ERRORS,
    21	)
    22	from mlflow.telemetry.schemas import Record, TelemetryConfig, TelemetryInfo, get_source_sdk
    23	from mlflow.telemetry.utils import _log_error, is_telemetry_disabled
    24	from mlflow.utils.logging_utils import should_suppress_logs_in_thread
    25	
    26	
    27	class TelemetryClient:
    28	
    29	
    30	
    31	
    32	
    33	
    34	
    35	
    36	
    37	
    38	
    39	
    40	
    41	
    42	
    43	
    44	
    45	
    46	
    47	
    48	
    49	
    50	
    51	
    52	
    53	
    54	
    55	
    56	
    57	
    58	
    59	
    60	
    61	
    62	
    63	
    64	
    65	
    66	
    67	
    68	
    69	
    70	
    71	
    72	
    73	
    74	
    75	
    76	
    77	
    78	
    79	
    80	
    81	
    82	
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	
   103	
   104	
   105	
   106	
   107	
   108	
   109	
   110	
   111	
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	    def _process_records(self, records: list[Record], request_timeout: float = 1):
   145	        """Process a batch of telemetry records."""
   146	        try:
   147	            self._update_backend_store()
   148	            if self.info["tracking_uri_scheme"] in ["databricks", "databricks-uc", "uc"]:
   149	                self._is_stopped = True
   150	                # set config to None to allow consumer thread drop records in the queue
   151	                self.config = None
   152	                self.is_active = False
   153	                _set_telemetry_client(None)
   154	                return
   155	
   156	            records = [
   157	                {
   158	                    "data": self.info | record.to_dict(),
   159	                    # use random uuid as partition key to make sure records are
   160	                    # distributed evenly across shards
   161	                    "partition-key": uuid.uuid4().hex,
   162	                }
   163	                for record in records
   164	            ]
   165	            # changing this value can affect total time for processing records
   166	            # the total time = request_timeout * max_attempts + sleep_time * (max_attempts - 1)
   167	            max_attempts = 3
   168	            sleep_time = 1
   169	            for i in range(max_attempts):
   170	                should_retry = False
   171	                response = None
   172	                try:
   173	                    response = requests.post(
   174	                        self.config.ingestion_url,
   175	                        json={"records": records},
   176	                        headers={"Content-Type": "application/json"},
   177	                        timeout=request_timeout,
   178	                    )
   179	                    should_retry = response.status_code in RETRYABLE_ERRORS
   180	                except (ConnectionError, TimeoutError):
   181	                    should_retry = True
   182	                # NB: DO NOT retry when terminating
   183	                # otherwise this increases shutdown overhead significantly
   184	                if self._is_stopped:
   185	                    return
   186	                if i < max_attempts - 1 and should_retry:
   187	                    # we do not use exponential backoff to avoid increasing
   188	                    # the processing time significantly
   189	                    time.sleep(sleep_time)
   190	                elif response and response.status_code in UNRECOVERABLE_ERRORS:
   191	                    self._is_stopped = True
   192	                    self.is_active = False
   193	                    # this is executed in the consumer thread, so
   194	                    # we cannot join the thread here, but this should
   195	                    # be enough to stop the telemetry collection
   196	                    return
   197	                else:
   198	                    return
   199	        except Exception as e:
   200	            _log_error(f"Failed to send telemetry records: {e}")
   201	
   202	    def _consumer(self) -> None:
   203	        """Individual consumer that processes records from the queue."""
   204	        # suppress logs in the consumer thread to avoid emitting any irrelevant
   205	        # logs during telemetry collection.
   206	        should_suppress_logs_in_thread.set(True)
   207	
   208	        while not self._is_config_fetched:
   209	            time.sleep(0.1)
   210	
   211	        while self.config and not self._is_stopped:
   212	            try:
   213	                records = self._queue.get(timeout=1)
   214	            except Empty:
   215	                # check if batch time interval has passed and send data if needed
   216	                if time.time() - self._last_batch_time >= self._batch_time_interval:
   217	                    self._last_batch_time = time.time()
   218	                    with self._batch_lock:
   219	                        if self._pending_records:
   220	                            self._send_batch()
   221	                continue
   222	
   223	            self._process_records(records)
   224	            self._queue.task_done()
   225	
   226	        # clear the queue if config is None
   227	        while self.config is None and not self._queue.empty():
   228	            try:
   229	                self._queue.get_nowait()
   230	                self._queue.task_done()
   231	            except Empty:
   232	                break
   233	        # drop remaining records when terminating to avoid
   234	        # causing any overhead
   235	
   236	
   237	
   238	
   239	
   240	
   241	
   242	
   243	
   244	
   245	
   246	
   247	
   248	
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	    @property
   257	    def is_active(self) -> bool:
   258	        return self._is_active
   259	
   260	    @is_active.setter
   261	    def is_active(self, value: bool) -> None:
   262	        self._is_active = value
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	
   303	
   304	
   305	
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	    def _update_backend_store(self):
   318	        """
   319	        Backend store might be changed after mlflow is imported, we should use this
   320	        method to update the backend store info at sending telemetry step.
   321	        """
   322	        try:
   323	            # import here to avoid circular import
   324	            from mlflow.tracking._tracking_service.utils import _get_tracking_scheme
   325	
   326	            self.info["tracking_uri_scheme"] = _get_tracking_scheme()
   327	        except Exception as e:
   328	            _log_error(f"Failed to update backend store: {e}")
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	_MLFLOW_TELEMETRY_CLIENT = None
   339	_client_lock = threading.Lock()
   340	
   341	
   342	def set_telemetry_client():
   343	    if is_telemetry_disabled():
   344	        # set to None again so this function can be used to
   345	        # re-initialize the telemetry client
   346	        _set_telemetry_client(None)
   347	    else:
   348	        try:
   349	            _set_telemetry_client(TelemetryClient())
   350	        except Exception as e:
   351	            _log_error(f"Failed to set telemetry client: {e}")
   352	            _set_telemetry_client(None)
   353	
   354	
   355	def _set_telemetry_client(value: TelemetryClient | None):
   356	    global _MLFLOW_TELEMETRY_CLIENT
   357	    with _client_lock:
   358	        _MLFLOW_TELEMETRY_CLIENT = value
   359	        if value:
   360	            _MLFLOW_TELEMETRY_SESSION_ID.set(value.info["session_id"])
   361	        else:
   362	            _MLFLOW_TELEMETRY_SESSION_ID.unset()
   363	
   364	
   365	def get_telemetry_client() -> TelemetryClient | None:
   366	    with _client_lock:
   367	        return _MLFLOW_TELEMETRY_CLIENT
     1	import functools
     2	import inspect
     3	import logging
     4	import time
     5	from typing import Any, Callable, ParamSpec, TypeVar
     6	
     7	from mlflow.environment_variables import MLFLOW_EXPERIMENT_ID
     8	from mlflow.telemetry.client import get_telemetry_client
     9	from mlflow.telemetry.events import Event
    10	from mlflow.telemetry.schemas import Record, Status
    11	from mlflow.telemetry.utils import _log_error, is_telemetry_disabled
    12	
    13	P = ParamSpec("P")
    14	R = TypeVar("R")
    15	
    16	_logger = logging.getLogger(__name__)
    17	
    18	
    19	def record_usage_event(event: type[Event]) -> Callable[[Callable[P, R]], Callable[P, R]]:
    20	    def decorator(func: Callable[P, R]) -> Callable[P, R]:
    21	        @functools.wraps(func)
    22	        def wrapper(*args: P.args, **kwargs: P.kwargs) -> R:
    23	            if is_telemetry_disabled() or _is_telemetry_disabled_for_event(event):
    24	                return func(*args, **kwargs)
    25	
    26	            success = True
    27	            result = None
    28	            start_time = time.time()
    29	            try:
    30	                result = func(*args, **kwargs)
    31	                return result  # noqa: RET504
    32	            except Exception:
    33	                success = False
    34	                raise
    35	            finally:
    36	                try:
    37	                    duration_ms = int((time.time() - start_time) * 1000)
    38	                    _add_telemetry_record(func, args, kwargs, success, duration_ms, event, result)
    39	                except Exception as e:
    40	                    _log_error(f"Failed to record telemetry event {event.name}: {e}")
    41	
    42	        return wrapper
    43	
    44	    return decorator
    45	
    46	
    47	def _add_telemetry_record(
    48	    func: Callable[..., Any],
    49	    args: tuple[Any, ...],
    50	    kwargs: dict[str, Any],
    51	    success: bool,
    52	    duration_ms: int,
    53	    event: type[Event],
    54	    result: Any,
    55	) -> None:
    56	    try:
    57	        if client := get_telemetry_client():
    58	            signature = inspect.signature(func)
    59	            bound_args = signature.bind(*args, **kwargs)
    60	            bound_args.apply_defaults()
    61	
    62	            arguments = dict(bound_args.arguments)
    63	            arguments.pop("self", None)
    64	
    65	            params = list(arguments.keys())
    66	            if params and params[0] == "cls" and isinstance(arguments["cls"], type):
    67	                del arguments["cls"]
    68	
    69	            record_params = event.parse(arguments) or {}
    70	            if hasattr(event, "parse_result"):
    71	                record_params.update(event.parse_result(result))
    72	            if experiment_id := MLFLOW_EXPERIMENT_ID.get():
    73	                record_params["mlflow_experiment_id"] = experiment_id
    74	            record = Record(
    75	                event_name=event.name,
    76	                timestamp_ns=time.time_ns(),
    77	                params=record_params or None,
    78	                status=Status.SUCCESS if success else Status.FAILURE,
    79	                duration_ms=duration_ms,
    80	            )
    81	            client.add_record(record)
    82	    except Exception as e:
    83	        _log_error(f"Failed to generate telemetry record for event {event.name}: {e}")
    84	
    85	
    86	def _record_event(event: type[Event], params: dict[str, Any] | None = None) -> None:
    87	    try:
    88	        if client := get_telemetry_client():
    89	            if experiment_id := MLFLOW_EXPERIMENT_ID.get():
    90	                params["mlflow_experiment_id"] = experiment_id
    91	            client.add_record(
    92	                Record(
    93	                    event_name=event.name,
    94	                    params=params,
    95	                    timestamp_ns=time.time_ns(),
    96	                    status=Status.SUCCESS,
    97	                    duration_ms=0,
    98	                )
    99	            )
   100	    except Exception as e:
   101	        _log_error(f"Failed to record telemetry event {event.name}: {e}")
   102	
   103	
tests/telemetry/test_events.py
FILE:tests/telemetry/test_events.py
from unittest.mock import Mock

import pytest

from mlflow.prompt.constants import IS_PROMPT_TAG_KEY
from mlflow.telemetry.events import (
    AiCommandRunEvent,
    AlignJudgeEvent,
    CreateDatasetEvent,
    CreateExperimentEvent,
    CreateLoggedModelEvent,
    CreateModelVersionEvent,
    CreatePromptEvent,
    CreateRegisteredModelEvent,
    CreateRunEvent,
    EvaluateEvent,
    LogAssessmentEvent,
    MakeJudgeEvent,
    MergeRecordsEvent,
    PromptOptimizationEvent,
    StartTraceEvent,
)


@pytest.mark.parametrize(
    ("arguments", "expected_params"),
    [
        (
            {"flavor": "mlflow.pyfunc"},
            {"flavor": "pyfunc"},
        ),
        (
            {"flavor": "sklearn"},
            {"flavor": "sklearn"},
        ),
        (
            {
                "flavor": None,
            },
            None,
        ),
        ({}, None),
    ],
)
def test_logged_model_parse_params(arguments, expected_params):
    assert CreateLoggedModelEvent.name == "create_logged_model"
    assert CreateLoggedModelEvent.parse(arguments) == expected_params


@pytest.mark.parametrize(
    ("arguments", "expected_params"),
    [
        ({"tags": None}, {"is_prompt": False}),
        ({"tags": {}}, {"is_prompt": False}),
        ({"tags": {IS_PROMPT_TAG_KEY: "true"}}, {"is_prompt": True}),
        ({"tags": {IS_PROMPT_TAG_KEY: "false"}}, {"is_prompt": False}),
        ({}, {"is_prompt": False}),
    ],
)
def test_registered_model_parse_params(arguments, expected_params):
    assert CreateRegisteredModelEvent.name == "create_registered_model"
    assert CreateRegisteredModelEvent.parse(arguments) == expected_params


@pytest.mark.parametrize(
    ("arguments", "expected_params"),
    [
        ({"tags": None}, {"is_prompt": False}),
        ({"tags": {}}, {"is_prompt": False}),
        ({"tags": {IS_PROMPT_TAG_KEY: "true"}}, {"is_prompt": True}),
        ({"tags": {IS_PROMPT_TAG_KEY: "false"}}, {"is_prompt": False}),
        ({}, {"is_prompt": False}),
    ],
)
def test_create_model_version_parse_params(arguments, expected_params):
    assert CreateModelVersionEvent.name == "create_model_version"
    assert CreateModelVersionEvent.parse(arguments) == expected_params


def test_event_name():
    assert AiCommandRunEvent.name == "ai_command_run"
    assert CreatePromptEvent.name == "create_prompt"
    assert CreateLoggedModelEvent.name == "create_logged_model"
    assert CreateRegisteredModelEvent.name == "create_registered_model"
    assert CreateModelVersionEvent.name == "create_model_version"
    assert CreateRunEvent.name == "create_run"
    assert CreateExperimentEvent.name == "create_experiment"
    assert LogAssessmentEvent.name == "log_assessment"
    assert StartTraceEvent.name == "start_trace"
    assert EvaluateEvent.name == "evaluate"
    assert CreateDatasetEvent.name == "create_dataset"
    assert MergeRecordsEvent.name == "merge_records"
    assert MakeJudgeEvent.name == "make_judge"
    assert AlignJudgeEvent.name == "align_judge"
    assert PromptOptimizationEvent.name == "prompt_optimization"


@pytest.mark.parametrize(
    ("arguments", "expected_params"),
    [
        ({"records": [{"test": "data"}]}, {"record_count": 1, "input_type": "list[dict]"}),
        ({"records": [{"a": 1}, {"b": 2}]}, {"record_count": 2, "input_type": "list[dict]"}),
        ({"records": []}, None),
        ({"records": None}, None),
        ({}, None),
        (None, None),
        ({"records": object()}, None),
    ],
)
def test_merge_records_parse_params(arguments, expected_params):
    assert MergeRecordsEvent.parse(arguments) == expected_params


@pytest.mark.parametrize(
    ("arguments", "expected_params"),
    [
        ({"model": "openai:/gpt-4"}, {"model_provider": "openai"}),
        ({"model": "databricks:/dbrx"}, {"model_provider": "databricks"}),
        ({"model": "custom"}, {"model_provider": None}),
        ({"model": None}, {"model_provider": None}),
        ({}, {"model_provider": None}),
    ],
)
def test_make_judge_parse_params(arguments, expected_params):
    assert MakeJudgeEvent.parse(arguments) == expected_params


@pytest.mark.parametrize(
    ("arguments", "expected_params"),
    [
        ({"traces": [{}, {}], "optimizer": None}, {"trace_count": 2, "optimizer_type": "default"}),
        (
            {"traces": [{}], "optimizer": type("MockOptimizer", (), {})()},
            {"trace_count": 1, "optimizer_type": "MockOptimizer"},
        ),
        ({"traces": [], "optimizer": None}, {"trace_count": 0, "optimizer_type": "default"}),
        ({"traces": None, "optimizer": None}, {"optimizer_type": "default"}),
        ({}, {"optimizer_type": "default"}),
    ],
)
def test_align_judge_parse_params(arguments, expected_params):
    assert AlignJudgeEvent.parse(arguments) == expected_params


@pytest.mark.parametrize(
    ("arguments", "expected_params"),
    [
        # Normal case with optimizer and prompt URIs
        (
            {
                "optimizer": type("MockOptimizer", (), {})(),
                "prompt_uris": ["prompts:/test/1"],
                "scorers": None,
                "aggregation": None,
            },
            {
                "optimizer_type": "MockOptimizer",
                "prompt_count": 1,
                "scorer_count": None,
                "custom_aggregation": False,
            },
        ),
        # Multiple prompt URIs with custom scorers
        (
            {
                "optimizer": type("CustomAdapter", (), {})(),
                "prompt_uris": ["prompts:/test/1", "prompts:/test/2"],
                "scorers": [Mock()],
                "aggregation": None,
            },
            {
                "optimizer_type": "CustomAdapter",
                "prompt_count": 2,
                "scorer_count": 1,
                "custom_aggregation": False,
            },
        ),
        # Custom objective with multiple scorers
        (
            {
                "optimizer": type("TestAdapter", (), {})(),
                "prompt_uris": ["prompts:/test/1"],
                "scorers": [Mock(), Mock(), Mock()],
                "aggregation": lambda scores: sum(scores.values()),
            },
            {
                "optimizer_type": "TestAdapter",
                "prompt_count": 1,
                "scorer_count": 3,
                "custom_aggregation": True,
            },
        ),
        # No optimizer provided - optimizer_type should be None
        (
            {
                "optimizer": None,
                "prompt_uris": ["prompts:/test/1"],
                "scorers": None,
                "aggregation": None,
            },
            {
                "optimizer_type": None,
                "prompt_count": 1,
                "scorer_count": None,
                "custom_aggregation": False,
            },
        ),
    ],
)
def test_prompt_optimization_parse_params(arguments, expected_params):
    assert PromptOptimizationEvent.parse(arguments) == expected_params
tests/telemetry/helper_functions.py
FILE:tests/telemetry/helper_functions.py
import json
from typing import Any


def validate_telemetry_record(
    mock_telemetry_client,
    mock_requests,
    event_name: str,
    params=None,
    *,
    status="success",
    search_index=True,
    check_params=True,
) -> dict[str, Any]:
    """
    Validate the telemetry record at the given index.
    """
    mock_telemetry_client.flush()

    if search_index:
        event_names = [record["data"]["event_name"] for record in mock_requests]
        idx = event_names.index(event_name)
    else:
        idx = 0

    record = mock_requests[idx]
    data = record["data"]
    assert data["event_name"] == event_name
    if check_params:
        if params:
            assert data["params"] == json.dumps(params)
        else:
            assert data["params"] is None
    assert data["status"] == status
    assert data["duration_ms"] is not None
    mock_requests.clear()
    return data
tests/telemetry/test_track.py
FILE:tests/telemetry/test_track.py
import time
from unittest import mock

import pytest

from mlflow.environment_variables import MLFLOW_DISABLE_TELEMETRY
from mlflow.telemetry.client import (
    TelemetryClient,
    get_telemetry_client,
    set_telemetry_client,
)
from mlflow.telemetry.events import CreateLoggedModelEvent, Event
from mlflow.telemetry.schemas import Status
from mlflow.telemetry.track import _is_telemetry_disabled_for_event, record_usage_event
from mlflow.telemetry.utils import is_telemetry_disabled
from mlflow.tracking._tracking_service.utils import _use_tracking_uri
from mlflow.version import VERSION


class TestEvent(Event):
    name = "test_event"


def test_record_usage_event(mock_requests, mock_telemetry_client: TelemetryClient):
    @record_usage_event(TestEvent)
    def succeed_func():
        # sleep to make sure duration_ms > 0
        time.sleep(0.01)
        return True

    @record_usage_event(TestEvent)
    def fail_func():
        time.sleep(0.01)
        raise ValueError("test")

    with mock.patch(
        "mlflow.telemetry.track.get_telemetry_client", return_value=mock_telemetry_client
    ):
        succeed_func()
        with pytest.raises(ValueError, match="test"):
            fail_func()

    mock_telemetry_client.flush()

    records = [
        record["data"] for record in mock_requests if record["data"]["event_name"] == TestEvent.name
    ]
    assert len(records) == 2
    succeed_record = records[0]
    assert succeed_record["schema_version"] == 1
    assert succeed_record["event_name"] == TestEvent.name
    assert succeed_record["status"] == Status.SUCCESS.value
    assert succeed_record["params"] is None
    assert succeed_record["duration_ms"] > 0

    fail_record = records[1]
    assert fail_record["schema_version"] == 1
    assert fail_record["event_name"] == TestEvent.name
    assert fail_record["status"] == Status.FAILURE.value
    assert fail_record["params"] is None
    assert fail_record["duration_ms"] > 0

    telemetry_info = mock_telemetry_client.info
    assert telemetry_info.items() <= succeed_record.items()
    assert telemetry_info.items() <= fail_record.items()


def test_backend_store_info(tmp_path, mock_telemetry_client: TelemetryClient):
    sqlite_uri = f"sqlite:///{tmp_path.joinpath('test.db')}"
    with _use_tracking_uri(sqlite_uri):
        mock_telemetry_client._update_backend_store()
    assert mock_telemetry_client.info["tracking_uri_scheme"] == "sqlite"

    with _use_tracking_uri(tmp_path):
        mock_telemetry_client._update_backend_store()
    assert mock_telemetry_client.info["tracking_uri_scheme"] == "file"


@pytest.mark.parametrize(
    ("env_var", "value", "expected_result"),
    [
        (MLFLOW_DISABLE_TELEMETRY.name, "true", None),
        (MLFLOW_DISABLE_TELEMETRY.name, "false", TelemetryClient),
        ("DO_NOT_TRACK", "true", None),
        ("DO_NOT_TRACK", "false", TelemetryClient),
    ],
)
def test_record_usage_event_respect_env_var(
    monkeypatch, env_var, value, expected_result, bypass_env_check
):
    monkeypatch.setenv(env_var, value)
    # mimic the behavior of `import mlflow`
    set_telemetry_client()
    telemetry_client = get_telemetry_client()
    if expected_result is None:
        assert is_telemetry_disabled() is True
        assert telemetry_client is None
    else:
        assert isinstance(telemetry_client, expected_result)
        telemetry_client._clean_up()


def test_record_usage_event_update_env_var_after_import(
    monkeypatch, mock_requests, mock_telemetry_client
):
    assert isinstance(mock_telemetry_client, TelemetryClient)

    @record_usage_event(TestEvent)
    def test_func():
        pass

    with mock.patch(
        "mlflow.telemetry.track.get_telemetry_client", return_value=mock_telemetry_client
    ):
        test_func()

        mock_telemetry_client.flush()
        events = {record["data"]["event_name"] for record in mock_requests}
        assert TestEvent.name in events
        mock_requests.clear()

        monkeypatch.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
        test_func()
        # no new record should be added
        assert len(mock_requests) == 0


@pytest.mark.no_mock_requests_get
def test_is_telemetry_disabled_for_event():
    def mock_requests_get(*args, **kwargs):
        time.sleep(1)
        return mock.Mock(
            status_code=200,
            json=mock.Mock(
                return_value={
                    "mlflow_version": VERSION,
                    "disable_telemetry": False,
                    "ingestion_url": "http://localhost:9999",
                    "rollout_percentage": 100,
                    "disable_events": ["test_event"],
                }
            ),
        )

    with mock.patch("mlflow.telemetry.client.requests.get", side_effect=mock_requests_get):
        client = TelemetryClient()
        assert client is not None
        client.activate()
        assert client.config is None
        with mock.patch("mlflow.telemetry.track.get_telemetry_client", return_value=client):
            # do not skip when config is not fetched yet
            assert _is_telemetry_disabled_for_event(TestEvent) is False
            assert _is_telemetry_disabled_for_event(TestEvent) is False
            time.sleep(2)
            assert client._is_config_fetched is True
            assert client.config is not None
            # event not in disable_events, do not skip
            assert _is_telemetry_disabled_for_event(CreateLoggedModelEvent) is False
            # event in disable_events, skip
            assert _is_telemetry_disabled_for_event(TestEvent) is True
        # clean up
        client._clean_up()

    # test telemetry disabled after config is fetched
    def mock_requests_get(*args, **kwargs):
        time.sleep(1)
        return mock.Mock(status_code=403)

    with mock.patch("mlflow.telemetry.client.requests.get", side_effect=mock_requests_get):
        client = TelemetryClient()
        assert client is not None
        client.activate()
        assert client.config is None
        with (
            mock.patch("mlflow.telemetry.track.get_telemetry_client", return_value=client),
            mock.patch(
                "mlflow.telemetry.client._set_telemetry_client"
            ) as mock_set_telemetry_client,
        ):
            # do not skip when config is not fetched yet
            assert _is_telemetry_disabled_for_event(CreateLoggedModelEvent) is False
            assert _is_telemetry_disabled_for_event(TestEvent) is False
            time.sleep(2)
            assert client._is_config_fetched is True
            assert client.config is None
            # global telemetry client is set to None when telemetry is disabled
            mock_set_telemetry_client.assert_called_once_with(None)
        # clean up
        client._clean_up()
tests/telemetry/test_tracked_events.py
FILE:tests/telemetry/test_tracked_events.py
import json
import time
from unittest import mock

import pandas as pd
import pytest
import sklearn.neighbors as knn
from click.testing import CliRunner

import mlflow
from mlflow import MlflowClient
from mlflow.entities import EvaluationDataset, Expectation, Feedback, Metric, Param, RunTag
from mlflow.entities.trace import Trace
from mlflow.entities.webhook import WebhookAction, WebhookEntity, WebhookEvent
from mlflow.genai.datasets import create_dataset
from mlflow.genai.judges import make_judge
from mlflow.genai.judges.base import AlignmentOptimizer
from mlflow.genai.scorers.builtin_scorers import RelevanceToQuery
from mlflow.pyfunc.model import ResponsesAgent, ResponsesAgentRequest, ResponsesAgentResponse
from mlflow.telemetry.client import TelemetryClient
from mlflow.telemetry.events import (
    AiCommandRunEvent,
    AlignJudgeEvent,
    AutologgingEvent,
    CreateDatasetEvent,
    CreateExperimentEvent,
    CreateLoggedModelEvent,
    CreateModelVersionEvent,
    CreatePromptEvent,
    CreateRegisteredModelEvent,
    CreateRunEvent,
    CreateWebhookEvent,
    EvaluateEvent,
    GenAIEvaluateEvent,
    GetLoggedModelEvent,
    GitModelVersioningEvent,
    InvokeCustomJudgeModelEvent,
    LoadPromptEvent,
    LogAssessmentEvent,
    LogBatchEvent,
    LogDatasetEvent,
    LogMetricEvent,
    LogParamEvent,
    MakeJudgeEvent,
    McpRunEvent,
    MergeRecordsEvent,
    PromptOptimizationEvent,
    StartTraceEvent,
)
from mlflow.tracking.fluent import _create_dataset_input, _initialize_logged_model

from tests.telemetry.helper_functions import validate_telemetry_record


class TestModel(mlflow.pyfunc.PythonModel):
    def predict(self, model_input: list[str]) -> str:
        return "test"


@pytest.fixture
def mlflow_client():
    return MlflowClient()


@pytest.fixture(autouse=True)
def mock_get_telemetry_client(mock_telemetry_client: TelemetryClient):
    with mock.patch(
        "mlflow.telemetry.track.get_telemetry_client", return_value=mock_telemetry_client
    ):
        yield


def test_create_logged_model(mock_requests, mock_telemetry_client: TelemetryClient):
    event_name = CreateLoggedModelEvent.name
    mlflow.create_external_model(name="model")
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, {"flavor": "external"}
    )

    mlflow.initialize_logged_model(name="model", tags={"key": "value"})
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, {"flavor": "initialize"}
    )

    _initialize_logged_model(name="model", flavor="keras")
    validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, {"flavor": "keras"})

    mlflow.pyfunc.log_model(
        name="model",
        python_model=TestModel(),
    )
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, {"flavor": "pyfunc.CustomPythonModel"}
    )

    mlflow.sklearn.log_model(
        knn.KNeighborsClassifier(),
        name="model",
    )
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, {"flavor": "sklearn"}
    )

    class SimpleResponsesAgent(ResponsesAgent):
        def predict(self, request: ResponsesAgentRequest) -> ResponsesAgentResponse:
            mock_response = {
                "output": [
                    {
                        "type": "message",
                        "id": "1234",
                        "status": "completed",
                        "role": "assistant",
                        "content": [
                            {
                                "type": "output_text",
                                "text": request.input[0].content,
                            }
                        ],
                    }
                ],
            }
            return ResponsesAgentResponse(**mock_response)

    mlflow.pyfunc.log_model(
        name="model",
        python_model=SimpleResponsesAgent(),
    )
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, {"flavor": "pyfunc.ResponsesAgent"}
    )


def test_create_experiment(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
    event_name = CreateExperimentEvent.name
    exp_id = mlflow.create_experiment(name="test_experiment")
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, {"experiment_id": exp_id}
    )

    exp_id = mlflow_client.create_experiment(name="test_experiment1")
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, {"experiment_id": exp_id}
    )


def test_create_run(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
    event_name = CreateRunEvent.name
    exp_id = mlflow.create_experiment(name="test_experiment")
    with mlflow.start_run(experiment_id=exp_id):
        record = validate_telemetry_record(
            mock_telemetry_client, mock_requests, event_name, check_params=False
        )
        assert json.loads(record["params"])["experiment_id"] == exp_id

    mlflow_client.create_run(experiment_id=exp_id)
    validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, check_params=False)

    exp_id = mlflow.create_experiment(name="test_experiment2")
    mlflow.set_experiment(experiment_id=exp_id)
    with mlflow.start_run():
        record = validate_telemetry_record(
            mock_telemetry_client, mock_requests, event_name, check_params=False
        )
        params = json.loads(record["params"])
        assert params["mlflow_experiment_id"] == exp_id


def test_create_run_with_imports(mock_requests, mock_telemetry_client: TelemetryClient):
    event_name = CreateRunEvent.name
    import pyspark.ml  # noqa: F401

    with mlflow.start_run():
        data = validate_telemetry_record(
            mock_telemetry_client, mock_requests, event_name, check_params=False
        )
        assert "pyspark.ml" in json.loads(data["params"])["imports"]


def test_create_registered_model(
    mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient
):
    event_name = CreateRegisteredModelEvent.name
    mlflow_client.create_registered_model(name="test_model1")
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        event_name,
        {"is_prompt": False},
    )

    mlflow.pyfunc.log_model(
        name="model",
        python_model=TestModel(),
        registered_model_name="test_model",
    )
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        event_name,
        {"is_prompt": False},
    )


def test_create_model_version(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
    event_name = CreateModelVersionEvent.name
    mlflow_client.create_registered_model(name="test_model")
    mlflow_client.create_model_version(
        name="test_model", source="test_source", run_id="test_run_id"
    )
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        event_name,
        {"is_prompt": False},
    )

    mlflow.pyfunc.log_model(
        name="model",
        python_model=TestModel(),
        registered_model_name="test_model",
    )
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        event_name,
        {"is_prompt": False},
    )

    mlflow.genai.register_prompt(
        name="ai_assistant_prompt",
        template="Respond to the user's message as a {{style}} AI. {{greeting}}",
        commit_message="Initial version of AI assistant",
    )
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        event_name,
        {"is_prompt": True},
    )


def test_start_trace(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
    event_name = StartTraceEvent.name
    with mlflow.start_span(name="test_span"):
        pass
    validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, check_params=False)

    @mlflow.trace
    def test_func():
        pass

    test_func()
    validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, check_params=False)

    trace_id = mlflow_client.start_trace(name="test_trace").trace_id
    mlflow_client.end_trace(trace_id=trace_id)
    validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, check_params=False)

    import openai  # noqa: F401

    test_func()
    data = validate_telemetry_record(
        mock_telemetry_client, mock_requests, event_name, check_params=False
    )
    assert "openai" in json.loads(data["params"])["imports"]


def test_create_prompt(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
    mlflow_client.create_prompt(name="test_prompt")
    validate_telemetry_record(mock_telemetry_client, mock_requests, CreatePromptEvent.name)

    # OSS prompt registry uses create_registered_model with a special tag
    mlflow.genai.register_prompt(
        name="greeting_prompt",
        template="Respond to the user's message as a {{style}} AI. {{greeting}}",
    )
    expected_params = {"is_prompt": True}
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        CreateRegisteredModelEvent.name,
        expected_params,
    )


def test_log_assessment(mock_requests, mock_telemetry_client: TelemetryClient):
    with mlflow.start_span(name="test_span") as span:
        feedback = Feedback(
            name="faithfulness",
            value=0.9,
            rationale="The model is faithful to the input.",
            metadata={"model": "gpt-4o-mini"},
        )

        mlflow.log_assessment(trace_id=span.trace_id, assessment=feedback)
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        LogAssessmentEvent.name,
        {"type": "feedback", "source_type": "CODE"},
    )
    mlflow.log_feedback(trace_id=span.trace_id, value=0.9, name="faithfulness")
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        LogAssessmentEvent.name,
        {"type": "feedback", "source_type": "CODE"},
    )

    with mlflow.start_span(name="test_span2") as span:
        expectation = Expectation(
            name="expected_answer",
            value="MLflow",
        )

        mlflow.log_assessment(trace_id=span.trace_id, assessment=expectation)
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        LogAssessmentEvent.name,
        {"type": "expectation", "source_type": "HUMAN"},
    )
    mlflow.log_expectation(trace_id=span.trace_id, value="MLflow", name="expected_answer")
    validate_telemetry_record(
        mock_telemetry_client,
        mock_requests,
        LogAssessmentEvent.name,
        {"type": "expectation", "source_type": "HUMAN"},
    )


def test_evaluate(mock_requests, mock_telemetry_client: TelemetryClient):
    mlflow.models.evaluate(
        data=pd.DataFrame({"x": [1, 2, 3], "y": [4, 5, 6]}),
        model=lambda x: x["x"] * 2,
        extra_metrics=[mlflow.metrics.latency()],
    )
    validate_telemetry_record(mock_telemetry_client, mock_requests, EvaluateEvent.name)


def test_create_webhook(mock_requests, mock_telemetry_client: TelemetryClient):
    client = MlflowClient()
    client.create_webhook(
        name="test_webhook",
        url="https://example.com/webhook",
        events=[WebhookEvent(WebhookEntity.MODEL_VERSION, WebhookAction.CREATED)],
    )
    expected_params = {"events": ["model_version.created"]}
    validate_telemetry_record(
        mock_telemetry_client, mock_requests, CreateWebhookEvent.name, expected_params
    )


def test_genai_evaluate(mock_requests, mock_telemetry_client: TelemetryClient):
    @mlflow.genai.scorer
    def sample_scorer(inputs, outputs, expectations):
        return 1.0

    model = TestModel()
    data = [
tests/telemetry/test_utils.py
FILE:tests/telemetry/test_utils.py
from mlflow.telemetry.constant import CONFIG_STAGING_URL, CONFIG_URL
from mlflow.telemetry.utils import (
    _get_config_url,
    is_telemetry_disabled,
)


def test_is_telemetry_disabled(monkeypatch, bypass_env_check):
    assert is_telemetry_disabled() is False

    with monkeypatch.context() as m:
        m.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
        assert is_telemetry_disabled() is True

    assert is_telemetry_disabled() is False

    with monkeypatch.context() as m:
        m.setenv("DO_NOT_TRACK", "true")
        assert is_telemetry_disabled() is True


def test_get_config_url(bypass_env_check):
    assert _get_config_url("1.0.0") == f"{CONFIG_URL}/1.0.0.json"
    assert _get_config_url("1.0.0.rc0") == f"{CONFIG_URL}/1.0.0.rc0.json"
    assert _get_config_url("1.0.0.dev0") == f"{CONFIG_STAGING_URL}/1.0.0.dev0.json"
    assert _get_config_url("1.0.0+abc") is None
tests/telemetry/__init__.py
FILE:tests/telemetry/__init__.py
tests/telemetry/conftest.py
FILE:tests/telemetry/conftest.py
from unittest.mock import Mock, patch

import pytest

import mlflow
import mlflow.telemetry.utils
from mlflow.telemetry.client import TelemetryClient, _set_telemetry_client, get_telemetry_client
from mlflow.version import VERSION


@pytest.fixture(autouse=True)
def terminate_telemetry_client():
    yield
    client = get_telemetry_client()
    if client:
        client._clean_up()
        # set to None to avoid side effect in other tests
        _set_telemetry_client(None)


@pytest.fixture
def mock_requests():
    """Fixture to mock requests.post and capture telemetry records."""
    captured_records = []

    url_status_code_map = {
        "http://127.0.0.1:9999/nonexistent": 404,
        "http://127.0.0.1:9999/unauthorized": 401,
        "http://127.0.0.1:9999/forbidden": 403,
        "http://127.0.0.1:9999/bad_request": 400,
    }

    def mock_post(url, json=None, **kwargs):
        if url in url_status_code_map:
            mock_response = Mock()
            mock_response.status_code = url_status_code_map[url]
            return mock_response
        if url == "http://localhost:9999":
            if json and "records" in json:
                captured_records.extend(json["records"])
            mock_response = Mock()
            mock_response.status_code = 200
            mock_response.json.return_value = {
                "status": "success",
                "count": len(json.get("records", [])) if json else 0,
            }
            return mock_response
        return Mock(status_code=404)

    with patch("requests.post", side_effect=mock_post):
        yield captured_records


@pytest.fixture(autouse=True)
def mock_requests_get(request):
    if request.node.get_closest_marker("no_mock_requests_get"):
        yield
        return

    with patch("mlflow.telemetry.client.requests.get") as mock_get:
        mock_get.return_value = Mock(
            status_code=200,
            json=Mock(
                return_value={
                    "mlflow_version": VERSION,
                    "disable_telemetry": False,
                    "ingestion_url": "http://localhost:9999",
                    "rollout_percentage": 100,
                    "disable_events": [],
                    "disable_sdks": [],
                }
            ),
        )
        yield


@pytest.fixture
def mock_telemetry_client(mock_requests_get, mock_requests):
    with TelemetryClient() as client:
        client.activate()
        # ensure config is fetched before the test
        client._config_thread.join(timeout=1)
        yield client


@pytest.fixture(autouse=True)
def is_mlflow_testing(monkeypatch):
    # enable telemetry by default when running tests in local with dev version
    monkeypatch.setattr(mlflow.telemetry.utils, "_IS_MLFLOW_TESTING_TELEMETRY", True)


@pytest.fixture
def bypass_env_check(monkeypatch):
    monkeypatch.setattr(mlflow.telemetry.utils, "_IS_MLFLOW_TESTING_TELEMETRY", False)
    monkeypatch.setattr(mlflow.telemetry.utils, "_IS_IN_CI_ENV_OR_TESTING", False)
    monkeypatch.setattr(mlflow.telemetry.utils, "_IS_MLFLOW_DEV_VERSION", False)
```

## 原始行 16 · agent_message

```
The source is deliberately incomplete in several large regions of `TelemetryClient`, not just the named methods. I’m mapping the visible tests and adjacent schemas/constants so the replacement preserves the repository’s expected attributes and helper methods, including `_send_batch` and `_clean_up`.
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "git status --short; sed -n '1,360p' tests/telemetry/test_track.py; sed -n '1,300p' mlflow/telemetry/schemas.py; sed -n '1,240p' mlflow/telemetry/constant.py; sed -n '1,320p' mlflow/telemetry/utils.py; sed -n '1,220p' tests/telemetry/helper_functions.py; sed -n '1,160p' mlflow/telemetry/__init__.py"
```

退出码：`0`

输出：
```
import time
from unittest import mock

import pytest

from mlflow.environment_variables import MLFLOW_DISABLE_TELEMETRY
from mlflow.telemetry.client import (
    TelemetryClient,
    get_telemetry_client,
    set_telemetry_client,
)
from mlflow.telemetry.events import CreateLoggedModelEvent, Event
from mlflow.telemetry.schemas import Status
from mlflow.telemetry.track import _is_telemetry_disabled_for_event, record_usage_event
from mlflow.telemetry.utils import is_telemetry_disabled
from mlflow.tracking._tracking_service.utils import _use_tracking_uri
from mlflow.version import VERSION


class TestEvent(Event):
    name = "test_event"


def test_record_usage_event(mock_requests, mock_telemetry_client: TelemetryClient):
    @record_usage_event(TestEvent)
    def succeed_func():
        # sleep to make sure duration_ms > 0
        time.sleep(0.01)
        return True

    @record_usage_event(TestEvent)
    def fail_func():
        time.sleep(0.01)
        raise ValueError("test")

    with mock.patch(
        "mlflow.telemetry.track.get_telemetry_client", return_value=mock_telemetry_client
    ):
        succeed_func()
        with pytest.raises(ValueError, match="test"):
            fail_func()

    mock_telemetry_client.flush()

    records = [
        record["data"] for record in mock_requests if record["data"]["event_name"] == TestEvent.name
    ]
    assert len(records) == 2
    succeed_record = records[0]
    assert succeed_record["schema_version"] == 1
    assert succeed_record["event_name"] == TestEvent.name
    assert succeed_record["status"] == Status.SUCCESS.value
    assert succeed_record["params"] is None
    assert succeed_record["duration_ms"] > 0

    fail_record = records[1]
    assert fail_record["schema_version"] == 1
    assert fail_record["event_name"] == TestEvent.name
    assert fail_record["status"] == Status.FAILURE.value
    assert fail_record["params"] is None
    assert fail_record["duration_ms"] > 0

    telemetry_info = mock_telemetry_client.info
    assert telemetry_info.items() <= succeed_record.items()
    assert telemetry_info.items() <= fail_record.items()


def test_backend_store_info(tmp_path, mock_telemetry_client: TelemetryClient):
    sqlite_uri = f"sqlite:///{tmp_path.joinpath('test.db')}"
    with _use_tracking_uri(sqlite_uri):
        mock_telemetry_client._update_backend_store()
    assert mock_telemetry_client.info["tracking_uri_scheme"] == "sqlite"

    with _use_tracking_uri(tmp_path):
        mock_telemetry_client._update_backend_store()
    assert mock_telemetry_client.info["tracking_uri_scheme"] == "file"


@pytest.mark.parametrize(
    ("env_var", "value", "expected_result"),
    [
        (MLFLOW_DISABLE_TELEMETRY.name, "true", None),
        (MLFLOW_DISABLE_TELEMETRY.name, "false", TelemetryClient),
        ("DO_NOT_TRACK", "true", None),
        ("DO_NOT_TRACK", "false", TelemetryClient),
    ],
)
def test_record_usage_event_respect_env_var(
    monkeypatch, env_var, value, expected_result, bypass_env_check
):
    monkeypatch.setenv(env_var, value)
    # mimic the behavior of `import mlflow`
    set_telemetry_client()
    telemetry_client = get_telemetry_client()
    if expected_result is None:
        assert is_telemetry_disabled() is True
        assert telemetry_client is None
    else:
        assert isinstance(telemetry_client, expected_result)
        telemetry_client._clean_up()


def test_record_usage_event_update_env_var_after_import(
    monkeypatch, mock_requests, mock_telemetry_client
):
    assert isinstance(mock_telemetry_client, TelemetryClient)

    @record_usage_event(TestEvent)
    def test_func():
        pass

    with mock.patch(
        "mlflow.telemetry.track.get_telemetry_client", return_value=mock_telemetry_client
    ):
        test_func()

        mock_telemetry_client.flush()
        events = {record["data"]["event_name"] for record in mock_requests}
        assert TestEvent.name in events
        mock_requests.clear()

        monkeypatch.setenv("MLFLOW_DISABLE_TELEMETRY", "true")
        test_func()
        # no new record should be added
        assert len(mock_requests) == 0


@pytest.mark.no_mock_requests_get
def test_is_telemetry_disabled_for_event():
    def mock_requests_get(*args, **kwargs):
        time.sleep(1)
        return mock.Mock(
            status_code=200,
            json=mock.Mock(
                return_value={
                    "mlflow_version": VERSION,
                    "disable_telemetry": False,
                    "ingestion_url": "http://localhost:9999",
                    "rollout_percentage": 100,
                    "disable_events": ["test_event"],
                }
            ),
        )

    with mock.patch("mlflow.telemetry.client.requests.get", side_effect=mock_requests_get):
        client = TelemetryClient()
        assert client is not None
        client.activate()
        assert client.config is None
        with mock.patch("mlflow.telemetry.track.get_telemetry_client", return_value=client):
            # do not skip when config is not fetched yet
            assert _is_telemetry_disabled_for_event(TestEvent) is False
            assert _is_telemetry_disabled_for_event(TestEvent) is False
            time.sleep(2)
            assert client._is_config_fetched is True
            assert client.config is not None
            # event not in disable_events, do not skip
            assert _is_telemetry_disabled_for_event(CreateLoggedModelEvent) is False
            # event in disable_events, skip
            assert _is_telemetry_disabled_for_event(TestEvent) is True
        # clean up
        client._clean_up()

    # test telemetry disabled after config is fetched
    def mock_requests_get(*args, **kwargs):
        time.sleep(1)
        return mock.Mock(status_code=403)

    with mock.patch("mlflow.telemetry.client.requests.get", side_effect=mock_requests_get):
        client = TelemetryClient()
        assert client is not None
        client.activate()
        assert client.config is None
        with (
            mock.patch("mlflow.telemetry.track.get_telemetry_client", return_value=client),
            mock.patch(
                "mlflow.telemetry.client._set_telemetry_client"
            ) as mock_set_telemetry_client,
        ):
            # do not skip when config is not fetched yet
            assert _is_telemetry_disabled_for_event(CreateLoggedModelEvent) is False
            assert _is_telemetry_disabled_for_event(TestEvent) is False
            time.sleep(2)
            assert client._is_config_fetched is True
            assert client.config is None
            # global telemetry client is set to None when telemetry is disabled
            mock_set_telemetry_client.assert_called_once_with(None)
        # clean up
        client._clean_up()
import json
import platform
import sys
from dataclasses import dataclass
from enum import Enum
from typing import Any

from mlflow.version import IS_MLFLOW_SKINNY, IS_TRACING_SDK_ONLY, VERSION


class Status(str, Enum):
    UNKNOWN = "unknown"
    SUCCESS = "success"
    FAILURE = "failure"


@dataclass
class Record:
    event_name: str
    timestamp_ns: int
    params: dict[str, Any] | None = None
    status: Status = Status.UNKNOWN
    duration_ms: int | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp_ns": self.timestamp_ns,
            "event_name": self.event_name,
            # dump params to string so we can parse them easily in ETL pipeline
            "params": json.dumps(self.params) if self.params else None,
            "status": self.status.value,
            "duration_ms": self.duration_ms,
        }


class SourceSDK(str, Enum):
    MLFLOW_TRACING = "mlflow-tracing"
    MLFLOW = "mlflow"
    MLFLOW_SKINNY = "mlflow-skinny"


def get_source_sdk() -> SourceSDK:
    if IS_TRACING_SDK_ONLY:
        return SourceSDK.MLFLOW_TRACING
    elif IS_MLFLOW_SKINNY:
        return SourceSDK.MLFLOW_SKINNY
    else:
        return SourceSDK.MLFLOW


@dataclass
class TelemetryInfo:
    session_id: str
    source_sdk: str = get_source_sdk().value
    mlflow_version: str = VERSION
    schema_version: int = 1
    python_version: str = (
        f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    )
    operating_system: str = platform.platform()
    tracking_uri_scheme: str | None = None


@dataclass
class TelemetryConfig:
    ingestion_url: str
    disable_events: set[str]
from mlflow.ml_package_versions import GENAI_FLAVOR_TO_MODULE_NAME, NON_GENAI_FLAVOR_TO_MODULE_NAME

# NB: Kinesis PutRecords API has a limit of 500 records per request
BATCH_SIZE = 500
BATCH_TIME_INTERVAL_SECONDS = 10
MAX_QUEUE_SIZE = 1000
MAX_WORKERS = 1
CONFIG_STAGING_URL = "https://config-staging.mlflow-telemetry.io"
CONFIG_URL = "https://config.mlflow-telemetry.io"
RETRYABLE_ERRORS = [
    429,  # Throttled
    500,  # Interval Server Error
]
UNRECOVERABLE_ERRORS = [
    400,  # Bad Request
    401,  # Unauthorized
    403,  # Forbidden
    404,  # Not Found
]

GENAI_MODULES = {
    "agno",
    "anthropic",
    "autogen",
    "chromadb",
    "crewai",
    "dspy",
    "faiss",
    "google.genai",  # gemini
    "groq",
    "haystack",
    "langchain",
    "langgraph",
    "langsmith",
    "litellm",
    "llama_cpp",
    "llama_index.core",
    "milvus",
    "mistralai",
    "openai",
    "pinecone",
    "pydantic_ai",
    "qdrant",
    "ragas",
    "semantic_kernel",
    "smolagents",
    "vllm",
    "weaviate",
} | set(GENAI_FLAVOR_TO_MODULE_NAME.values())

NON_GENAI_MODULES = {
    # Classic ML
    "catboost",
    "diviner",
    "h2o",
    "lightgbm",
    "optuna",
    "prophet",
    "pyspark.ml",
    "sklearn",
    "spacy",
    "statsmodels",
    "xgboost",
    # Deep Learning
    "accelerate",
    "bitsandbytes",
    "deepspeed",
    "diffusers",
    "fastai",
    "flash_attn",
    "flax",
    "jax",
    "keras",
    "lightning",
    "mxnet",
    "paddle",
    "peft",
    "sentence_transformers",
    "tensorflow",
    "timm",
    "torch",
    "transformers",
} | set(NON_GENAI_FLAVOR_TO_MODULE_NAME.values()) - {"pyspark"}

MODULES_TO_CHECK_IMPORT = GENAI_MODULES | NON_GENAI_MODULES
import logging
import os

from packaging.version import Version

from mlflow.environment_variables import (
    _MLFLOW_TELEMETRY_LOGGING,
    _MLFLOW_TESTING_TELEMETRY,
    MLFLOW_DISABLE_TELEMETRY,
)
from mlflow.telemetry.constant import CONFIG_STAGING_URL, CONFIG_URL
from mlflow.version import VERSION

_logger = logging.getLogger(__name__)


def _is_ci_env_or_testing() -> bool:
    """
    Check if the current environment is a CI environment.
    If so, we should not track telemetry.
    """
    env_vars = {
        "PYTEST_CURRENT_TEST",  # https://docs.pytest.org/en/stable/example/simple.html#pytest-current-test-environment-variable
        "GITHUB_ACTIONS",  # https://docs.github.com/en/actions/reference/variables-reference?utm_source=chatgpt.com#default-environment-variables
        "CI",  # set by many CI providers
        "CIRCLECI",  # https://circleci.com/docs/variables/#built-in-environment-variables
        "GITLAB_CI",  # https://docs.gitlab.com/ci/variables/predefined_variables/#predefined-variables
        "JENKINS_URL",  # https://www.jenkins.io/doc/book/pipeline/jenkinsfile/#using-environment-variables
        "TRAVIS",  # https://docs.travis-ci.com/user/environment-variables/#default-environment-variables
        "TF_BUILD",  # https://learn.microsoft.com/en-us/azure/devops/pipelines/build/variables?view=azure-devops&tabs=yaml#system-variables
        "BITBUCKET_BUILD_NUMBER",  # https://support.atlassian.com/bitbucket-cloud/docs/variables-and-secrets/
        "CODEBUILD_BUILD_ARN",  # https://docs.aws.amazon.com/codebuild/latest/userguide/build-env-ref-env-vars.html
        "BUILDKITE",  # https://buildkite.com/docs/pipelines/configure/environment-variables
        "TEAMCITY_VERSION",  # https://www.jetbrains.com/help/teamcity/predefined-build-parameters.html#Predefined+Server+Build+Parameters
        "CLOUD_RUN_EXECUTION",  # https://cloud.google.com/run/docs/reference/container-contract#env-vars
        # runbots
        "RUNBOT_HOST_URL",
        "RUNBOT_BUILD_NAME",
        "RUNBOT_WORKER_ID",
    }
    # For most of the cases, the env var existing means we are in CI
    for var in env_vars:
        if var in os.environ:
            return True
    return False


# NB: implement the function here to avoid unnecessary imports inside databricks_utils
def _is_in_databricks() -> bool:
    # check if in databricks runtime
    if "DATABRICKS_RUNTIME_VERSION" in os.environ:
        return True
    if os.path.exists("/databricks/DBR_VERSION"):
        return True

    # check if in databricks model serving environment
    if os.environ.get("IS_IN_DB_MODEL_SERVING_ENV", "false").lower() == "true":
        return True

    return False


_IS_MLFLOW_DEV_VERSION = Version(VERSION).is_devrelease
_IS_IN_CI_ENV_OR_TESTING = _is_ci_env_or_testing()
_IS_IN_DATABRICKS = _is_in_databricks()
_IS_MLFLOW_TESTING_TELEMETRY = _MLFLOW_TESTING_TELEMETRY.get()


def is_telemetry_disabled() -> bool:
    try:
        if _IS_MLFLOW_TESTING_TELEMETRY:
            return False
        return (
            MLFLOW_DISABLE_TELEMETRY.get()
            or os.environ.get("DO_NOT_TRACK", "false").lower() == "true"
            or _IS_IN_CI_ENV_OR_TESTING
            or _IS_IN_DATABRICKS
            or _IS_MLFLOW_DEV_VERSION
        )
    except Exception as e:
        _log_error(f"Failed to check telemetry disabled status: {e}")
        return True



















def _log_error(message: str) -> None:
    if _MLFLOW_TELEMETRY_LOGGING.get():
        _logger.error(message, exc_info=True)import json
from typing import Any


def validate_telemetry_record(
    mock_telemetry_client,
    mock_requests,
    event_name: str,
    params=None,
    *,
    status="success",
    search_index=True,
    check_params=True,
) -> dict[str, Any]:
    """
    Validate the telemetry record at the given index.
    """
    mock_telemetry_client.flush()

    if search_index:
        event_names = [record["data"]["event_name"] for record in mock_requests]
        idx = event_names.index(event_name)
    else:
        idx = 0

    record = mock_requests[idx]
    data = record["data"]
    assert data["event_name"] == event_name
    if check_params:
        if params:
            assert data["params"] == json.dumps(params)
        else:
            assert data["params"] is None
    assert data["status"] == status
    assert data["duration_ms"] is not None
    mock_requests.clear()
    return data
from mlflow.telemetry.client import get_telemetry_client, set_telemetry_client

__all__ = ["get_telemetry_client", "set_telemetry_client"]
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "grep -R \"_clean_up\\|_send_batch\\|_is_config_fetched\\|_pending_records\\|_batch_size\\|_batch_time_interval\\|_config_thread\\|_consumer_threads\\|_get_config_url\" -n --exclude-dir=.git . | head -300"
```

退出码：`0`

输出：
```
./examples/pytorch/torchscript/MNIST/mnist_torchscript.py:158:    test_kwargs = {"batch_size": args.test_batch_size}
./examples/pytorch/mnist_tensorboard_artifact.py:97:    batch_size=args.test_batch_size,
./examples/transformers/MLFlow_X_HuggingFace_Finetune_a_text_classification_model.ipynb:489:    "    per_device_train_batch_size=8,\n",
./examples/transformers/MLFlow_X_HuggingFace_Finetune_a_text_classification_model.ipynb:490:    "    per_device_eval_batch_size=8,\n",
./dev/build.py:67:    paths_to_clean_up = ["build"]
./dev/build.py:69:        paths_to_clean_up += [
./dev/build.py:73:    for path in map(Path, paths_to_clean_up):
./mlflow/optuna/storage.py:82:        self._batch_size_threshold = batch_size_threshold
./mlflow/optuna/storage.py:193:            if batch_size >= self._batch_size_threshold:
./mlflow/tensorflow/__init__.py:1263:                    training_data, "_batch_size"
./mlflow/tensorflow/__init__.py:1265:                    batch_size = training_data._batch_size.numpy()
./mlflow/genai/judges/optimizers/simba.py:76:    def _get_batch_size(self) -> int:
./mlflow/genai/judges/optimizers/simba.py:106:            optimizer = dspy.SIMBA(metric=metric_fn, bsize=self._get_batch_size())
./mlflow/genai/utils/trace_utils.py:582:    run_id: str | None, eval_results: list["EvalResult"], max_batch_size: int = 100
./mlflow/genai/utils/trace_utils.py:590:        max_batch_size: Maximum number of traces to link per batch call
./mlflow/genai/utils/trace_utils.py:594:    for i in range(0, len(trace_ids), max_batch_size):
./mlflow/genai/utils/trace_utils.py:595:        batch = trace_ids[i : i + max_batch_size]
./mlflow/tracking/_tracking_service/client.py:557:            metrics_batch_size = min(
./mlflow/tracking/_tracking_service/client.py:561:            metrics_batch_size = max(metrics_batch_size, 0)
./mlflow/tracking/_tracking_service/client.py:562:            metrics_batch = metrics[:metrics_batch_size]
./mlflow/tracking/_tracking_service/client.py:563:            metrics = metrics[metrics_batch_size:]
./mlflow/llama_index/tracer.py:304:            "embed_batch_size": instance.embed_batch_size,
./mlflow/paddle/__init__.py:584:            "eval_batch_size": 6.0,
./mlflow/utils/autologging_utils/client.py:348:            metrics_batch_size = min(
./mlflow/utils/autologging_utils/client.py:352:            metrics_batch_size = max(metrics_batch_size, 0)
./mlflow/utils/autologging_utils/client.py:353:            metrics_batch = pending_operations.metrics_queue[:metrics_batch_size]
./mlflow/utils/autologging_utils/client.py:354:            pending_operations.metrics_queue = pending_operations.metrics_queue[metrics_batch_size:]
./mlflow/telemetry/client.py:208:        while not self._is_config_fetched:
./mlflow/telemetry/client.py:216:                if time.time() - self._last_batch_time >= self._batch_time_interval:
./mlflow/telemetry/client.py:219:                        if self._pending_records:
./mlflow/telemetry/client.py:220:                            self._send_batch()
./mlflow/keras/autologging.py:204:        batch_size, args, kwargs = _infer_batch_size(inst, *args, **kwargs)
./mlflow/keras/autologging.py:255:def _infer_batch_size(inst, *args, **kwargs):
./mlflow/keras/autologging.py:261:        if _batch_size := getattr(training_data, "batch_size", None):
./mlflow/keras/autologging.py:262:            batch_size = _batch_size
./mlflow/keras/autologging.py:263:        elif _batch_size := getattr(training_data, "_batch_size", None):
./mlflow/keras/autologging.py:264:            batch_size = _batch_size if isinstance(_batch_size, int) else _batch_size.numpy()
./mlflow/store/tracking/rest_store.py:917:            initial_batch_size = _MLFLOW_CREATE_LOGGED_MODEL_PARAMS_BATCH_SIZE.get()
./mlflow/store/tracking/rest_store.py:918:            initial_params = params[:initial_batch_size]
./mlflow/store/tracking/rest_store.py:919:            remaining_params = params[initial_batch_size:]
./docs/docs/classic-ml/deep-learning/sentence-transformers/guide/index.mdx:1053:                "optimal_batch_size": optimal_batch["batch_size"],
./docs/docs/classic-ml/deep-learning/transformers/tutorials/fine-tuning/transformers-peft.ipynb:788:    "    per_device_train_batch_size=2,\n",
./docs/docs/classic-ml/deep-learning/transformers/tutorials/fine-tuning/transformers-fine-tuning.ipynb:333:    "    per_device_train_batch_size=8,\n",
./docs/docs/classic-ml/deep-learning/transformers/tutorials/fine-tuning/transformers-fine-tuning.ipynb:334:    "    per_device_eval_batch_size=8,\n",
./tests/tensorflow/test_tensorflow2_autolog.py:492:def test_tf_keras_autolog_implicit_batch_size_works(generate_data, batch_size):
./tests/tensorflow/test_tensorflow2_autolog.py:566:def test_tf_keras_autolog_implicit_batch_size_works_multi_input(generate_data, batch_size):
./tests/tensorflow/test_tensorflow2_autolog.py:605:def test_tf_keras_autolog_implicit_batch_size_for_generator_dataset_without_side_effects(
./tests/tensorflow/test_tensorflow2_autolog.py:634:def test_tf_keras_autolog_succeeds_for_tf_datasets_lacking_batch_size_info():
./tests/tensorflow/test_tensorflow2_autolog.py:641:    assert not hasattr(train_ds, "_batch_size")
./tests/llama_index/sample_code/query_engine_with_reranker.py:18:    choice_batch_size=5,
./tests/paddle/test_paddle_autolog.py:52:    for metric_key in ["batch_size", "loss", "step", "eval_batch_size", "eval_loss", "eval_step"]:
./tests/openai/test_openai_model_export.py:525:def test_embeddings_batch_size_azure(tmp_path, monkeypatch):
./tests/telemetry/test_track.py:100:        telemetry_client._clean_up()
./tests/telemetry/test_track.py:155:            assert client._is_config_fetched is True
./tests/telemetry/test_track.py:162:        client._clean_up()
./tests/telemetry/test_track.py:184:            assert client._is_config_fetched is True
./tests/telemetry/test_track.py:189:        client._clean_up()
./tests/telemetry/test_utils.py:3:    _get_config_url,
./tests/telemetry/test_utils.py:22:def test_get_config_url(bypass_env_check):
./tests/telemetry/test_utils.py:23:    assert _get_config_url("1.0.0") == f"{CONFIG_URL}/1.0.0.json"
./tests/telemetry/test_utils.py:24:    assert _get_config_url("1.0.0.rc0") == f"{CONFIG_URL}/1.0.0.rc0.json"
./tests/telemetry/test_utils.py:25:    assert _get_config_url("1.0.0.dev0") == f"{CONFIG_STAGING_URL}/1.0.0.dev0.json"
./tests/telemetry/test_utils.py:26:    assert _get_config_url("1.0.0+abc") is None
./tests/telemetry/conftest.py:16:        client._clean_up()
./tests/telemetry/conftest.py:82:        client._config_thread.join(timeout=1)
./tests/transformers/test_transformers_autolog.py:113:        per_device_train_batch_size=4,
./tests/transformers/test_transformers_autolog.py:166:            per_device_train_batch_size=4,
./tests/transformers/test_transformers_autolog.py:189:        per_device_train_batch_size=4,
./tests/transformers/test_transformers_autolog.py:242:        per_device_train_batch_size=4,
./tests/transformers/test_transformers_autolog.py:274:        per_device_train_batch_size=4,
./tests/transformers/test_transformers_model_export.py:3664:        per_device_train_batch_size=4,
./tests/conftest.py:869:        client._clean_up()
./tests/store/tracking/test_rest_store.py:1354:    ("params_count", "expected_call_count", "create_batch_size", "log_batch_size"),
./tests/store/tracking/test_rest_store.py:1389:    monkeypatch, params_count, expected_call_count, create_batch_size, log_batch_size
./tests/store/tracking/test_rest_store.py:1392:    monkeypatch.setenv(_MLFLOW_CREATE_LOGGED_MODEL_PARAMS_BATCH_SIZE.name, str(create_batch_size))
./tests/store/tracking/test_rest_store.py:1393:    monkeypatch.setenv(_MLFLOW_LOG_LOGGED_MODEL_PARAMS_BATCH_SIZE.name, str(log_batch_size))
./tests/store/tracking/test_rest_store.py:1423:        initial_params = [p.to_proto() for p in params[:create_batch_size]] if params else None
./tests/store/tracking/test_rest_store.py:1434:        # If params > create_batch_size, additional calls should be made
./tests/store/tracking/test_rest_store.py:1435:        if params_count and params_count > create_batch_size:
./tests/store/tracking/test_rest_store.py:1437:            remaining_params = params[create_batch_size:]
./tests/store/tracking/test_rest_store.py:1438:            for i in range(0, len(remaining_params), log_batch_size):
./tests/store/tracking/test_rest_store.py:1439:                batch = remaining_params[i : i + log_batch_size]
```

## 原始行 24 · command_execution

命令：
```
/bin/bash -lc "grep -R \"disable_sdks\\|disable_events\\|rollout_percentage\\|disable_os\\|disabled_os\\|operating_systems\" -n . --exclude-dir=.git --exclude='*.ipynb' | head -200; grep -R \"telemetry.*flush\\|TelemetryClient\" -n tests --exclude='test_track.py' --exclude='conftest.py' | head -200; grep -n \"class _MLFLOW_TELEMETRY_SESSION_ID\\|_MLFLOW_TELEMETRY_SESSION_ID\" mlflow/environment_variables.py"
```

退出码：`0`

输出：
```
./mlflow/telemetry/schemas.py:67:    disable_events: set[str]
./tests/telemetry/test_track.py:139:                    "rollout_percentage": 100,
./tests/telemetry/test_track.py:140:                    "disable_events": ["test_event"],
./tests/telemetry/test_track.py:157:            # event not in disable_events, do not skip
./tests/telemetry/test_track.py:159:            # event in disable_events, skip
./tests/telemetry/conftest.py:68:                    "rollout_percentage": 100,
./tests/telemetry/conftest.py:69:                    "disable_events": [],
./tests/telemetry/conftest.py:70:                    "disable_sdks": [],
tests/telemetry/helper_functions.py:18:    mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:20:from mlflow.telemetry.client import TelemetryClient
tests/telemetry/test_tracked_events.py:66:def mock_get_telemetry_client(mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:73:def test_create_logged_model(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:133:def test_create_experiment(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:146:def test_create_run(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:168:def test_create_run_with_imports(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:180:    mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient
tests/telemetry/test_tracked_events.py:204:def test_create_model_version(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:242:def test_start_trace(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:268:def test_create_prompt(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:286:def test_log_assessment(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:332:def test_evaluate(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:341:def test_create_webhook(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:354:def test_genai_evaluate(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:376:def test_prompt_optimization(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:426:def test_create_dataset(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:438:def test_merge_records(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:465:def test_log_dataset(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:479:def test_log_metric(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:516:def test_log_param(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:542:def test_log_batch(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:608:def test_get_logged_model(mock_requests, mock_telemetry_client: TelemetryClient, tmp_path):
tests/telemetry/test_tracked_events.py:613:    mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:642:    mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:651:    mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:659:def test_mcp_run(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:667:    mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:671:def test_ai_command_run(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:680:    mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:695:    mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:710:    mock_telemetry_client: TelemetryClient,
tests/telemetry/test_tracked_events.py:790:def test_make_judge(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:813:def test_align_judge(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:839:def test_autologging(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:844:        mock_telemetry_client.flush()
tests/telemetry/test_tracked_events.py:856:def test_load_prompt(mock_requests, mock_telemetry_client: TelemetryClient):
tests/telemetry/test_tracked_events.py:862:    mock_telemetry_client.flush()
1071:_MLFLOW_TELEMETRY_SESSION_ID = _EnvironmentVariable("_MLFLOW_TELEMETRY_SESSION_ID", str, None)
```

## 原始行 29 · command_execution

命令：
```
/bin/bash -lc 'grep -R "_record_event(" -n mlflow | head -100; python -m pytest tests/telemetry/test_utils.py tests/telemetry/test_track.py -q'
```

退出码：`2`

输出：
```
mlflow/dspy/autolog.py:114:    _record_event(
mlflow/litellm/__init__.py:59:    _record_event(
mlflow/autogen/__init__.py:109:    _record_event(
mlflow/langchain/autolog.py:73:    _record_event(
mlflow/mistral/__init__.py:42:    _record_event(
mlflow/ag2/__init__.py:59:    _record_event(
mlflow/tracking/fluent.py:3345:    _record_event(AutologgingEvent, {"flavor": "all", "log_traces": log_traces, "disable": disable})
mlflow/llama_index/autolog.py:56:    _record_event(
mlflow/strands/__init__.py:29:    _record_event(
mlflow/openai/autolog.py:99:    _record_event(
mlflow/crewai/__init__.py:84:    _record_event(
mlflow/telemetry/track.py:86:def _record_event(event: type[Event], params: dict[str, Any] | None = None) -> None:
mlflow/gemini/__init__.py:96:    _record_event(
mlflow/smolagents/__init__.py:70:    _record_event(
mlflow/pydantic_ai/__init__.py:70:    _record_event(
mlflow/groq/__init__.py:44:    _record_event(
mlflow/bedrock/__init__.py:47:    _record_event(
mlflow/semantic_kernel/__init__.py:62:    _record_event(
mlflow/mcp/server.py:103:                _record_event(AiCommandRunEvent, {"command_key": cmd_key, "context": "mcp"})
mlflow/ai_commands/__init__.py:56:        _record_event(AiCommandRunEvent, {"command_key": key, "context": "cli"})
mlflow/agno/__init__.py:82:    _record_event(
mlflow/anthropic/__init__.py:63:    _record_event(
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 0 items / 2 errors

==================================== ERRORS ====================================
[31m[1m________________ ERROR collecting tests/telemetry/test_utils.py ________________[0m
[31mImportError while importing test module '/testbed/tests/telemetry/test_utils.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
tests/telemetry/test_utils.py:2: in <module>
    from mlflow.telemetry.utils import (
E   ImportError: cannot import name '_get_config_url' from 'mlflow.telemetry.utils' (/testbed/mlflow/telemetry/utils.py)[0m
[31m[1m________________ ERROR collecting tests/telemetry/test_track.py ________________[0m
[31mImportError while importing test module '/testbed/tests/telemetry/test_track.py'.
Hint: make sure your test modules/packages have valid Python names.
Traceback:
/opt/miniconda3/envs/testbed/lib/python3.11/importlib/__init__.py:126: in import_module
    return _bootstrap._gcd_import(name[level:], package, level)
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
tests/telemetry/test_track.py:14: in <module>
    from mlflow.telemetry.track import _is_telemetry_disabled_for_event, record_usage_event
E   ImportError: cannot import name '_is_telemetry_disabled_for_event' from 'mlflow.telemetry.track' (/testbed/mlflow/telemetry/track.py)[0m
[36m[1m=========================== short test summary info ============================[0m
[31mERROR[0m tests/telemetry/test_utils.py
[31mERROR[0m tests/telemetry/test_track.py
!!!!!!!!!!!!!!!!!!! Interrupted: 2 errors during collection !!!!!!!!!!!!!!!!!!!!
[31m============================== [31m[1m2 errors[0m[31m in 0.12s[0m[31m ===============================[0m
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "grep -R \"Queue(MAX_QUEUE_SIZE\\|def _consumer(self).*queue\\|_consumer_threads\\|daemon=True\" -n mlflow | head -200"
```

退出码：`0`

输出：
```
mlflow/optuna/storage.py:95:            daemon=True,
mlflow/pyfunc/__init__.py:2694:                    daemon=True,
mlflow/tracing/utils/timeout.py:182:            target=self._expire_check_loop, daemon=True, name="TTLCacheExpireLoop"
mlflow/tracing/export/async_export_queue.py:150:                daemon=True,
mlflow/server/jobs/_job_subproc_entry.py:22:        daemon=True,
mlflow/server/jobs/_huey_consumer.py:32:    daemon=True,
mlflow/server/jobs/utils.py:350:    t = threading.Thread(target=watcher, daemon=True, name="job-runner-watcher")
mlflow/utils/async_logging/async_artifacts_logging_queue.py:228:                daemon=True,
mlflow/utils/async_logging/async_logging_queue.py:335:                daemon=True,
mlflow/system_metrics/system_metrics_monitor.py:110:                daemon=True,
```

## 原始行 38 · file_change

```
{
  "id": "item_25",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/telemetry/client.py",
      "kind": "delete"
    }
  ],
  "status": "completed"
}
```

## 原始行 41 · command_execution

命令：
```
/bin/bash -lc 'test -f mlflow/telemetry/client.py; echo $?; nl -ba mlflow/telemetry/utils.py | tail -80'
```

退出码：`0`

输出：
```
1
    25	        "CI",  # set by many CI providers
    26	        "CIRCLECI",  # https://circleci.com/docs/variables/#built-in-environment-variables
    27	        "GITLAB_CI",  # https://docs.gitlab.com/ci/variables/predefined_variables/#predefined-variables
    28	        "JENKINS_URL",  # https://www.jenkins.io/doc/book/pipeline/jenkinsfile/#using-environment-variables
    29	        "TRAVIS",  # https://docs.travis-ci.com/user/environment-variables/#default-environment-variables
    30	        "TF_BUILD",  # https://learn.microsoft.com/en-us/azure/devops/pipelines/build/variables?view=azure-devops&tabs=yaml#system-variables
    31	        "BITBUCKET_BUILD_NUMBER",  # https://support.atlassian.com/bitbucket-cloud/docs/variables-and-secrets/
    32	        "CODEBUILD_BUILD_ARN",  # https://docs.aws.amazon.com/codebuild/latest/userguide/build-env-ref-env-vars.html
    33	        "BUILDKITE",  # https://buildkite.com/docs/pipelines/configure/environment-variables
    34	        "TEAMCITY_VERSION",  # https://www.jetbrains.com/help/teamcity/predefined-build-parameters.html#Predefined+Server+Build+Parameters
    35	        "CLOUD_RUN_EXECUTION",  # https://cloud.google.com/run/docs/reference/container-contract#env-vars
    36	        # runbots
    37	        "RUNBOT_HOST_URL",
    38	        "RUNBOT_BUILD_NAME",
    39	        "RUNBOT_WORKER_ID",
    40	    }
    41	    # For most of the cases, the env var existing means we are in CI
    42	    for var in env_vars:
    43	        if var in os.environ:
    44	            return True
    45	    return False
    46	
    47	
    48	# NB: implement the function here to avoid unnecessary imports inside databricks_utils
    49	def _is_in_databricks() -> bool:
    50	    # check if in databricks runtime
    51	    if "DATABRICKS_RUNTIME_VERSION" in os.environ:
    52	        return True
    53	    if os.path.exists("/databricks/DBR_VERSION"):
    54	        return True
    55	
    56	    # check if in databricks model serving environment
    57	    if os.environ.get("IS_IN_DB_MODEL_SERVING_ENV", "false").lower() == "true":
    58	        return True
    59	
    60	    return False
    61	
    62	
    63	_IS_MLFLOW_DEV_VERSION = Version(VERSION).is_devrelease
    64	_IS_IN_CI_ENV_OR_TESTING = _is_ci_env_or_testing()
    65	_IS_IN_DATABRICKS = _is_in_databricks()
    66	_IS_MLFLOW_TESTING_TELEMETRY = _MLFLOW_TESTING_TELEMETRY.get()
    67	
    68	
    69	def is_telemetry_disabled() -> bool:
    70	    try:
    71	        if _IS_MLFLOW_TESTING_TELEMETRY:
    72	            return False
    73	        return (
    74	            MLFLOW_DISABLE_TELEMETRY.get()
    75	            or os.environ.get("DO_NOT_TRACK", "false").lower() == "true"
    76	            or _IS_IN_CI_ENV_OR_TESTING
    77	            or _IS_IN_DATABRICKS
    78	            or _IS_MLFLOW_DEV_VERSION
    79	        )
    80	    except Exception as e:
    81	        _log_error(f"Failed to check telemetry disabled status: {e}")
    82	        return True
    83	
    84	
    85	
    86	
    87	
    88	
    89	
    90	
    91	
    92	
    93	
    94	
    95	
    96	
    97	
    98	
    99	
   100	
   101	
   102	def _log_error(message: str) -> None:
   103	    if _MLFLOW_TELEMETRY_LOGGING.get():
   104	        _logger.error(message, exc_info=True)
```

## 原始行 43 · file_change

```
{
  "id": "item_28",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/telemetry/client.py",
      "kind": "add"
    }
  ],
  "status": "completed"
}
```

## 原始行 46 · file_change

```
{
  "id": "item_30",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/telemetry/track.py",
      "kind": "update"
    },
    {
      "path": "/testbed/mlflow/telemetry/utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 47 · agent_message

```
The missing implementation is now in place, including bounded batching, daemon workers, lazy configuration, retry/drop behavior, fast terminating shutdown, and fail-safe event filtering. I’ve also restored the missing version-to-config URL helper that prevented the telemetry tests from even collecting. I’m running the focused suite now and will adjust any behavioral mismatches.
```

## 原始行 49 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/telemetry/test_utils.py tests/telemetry/test_track.py -q'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 10 items

tests/telemetry/test_utils.py [32m.[0m[32m.[0m[32m                                         [ 20%][0m
tests/telemetry/test_track.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                   [100%][0m

============================= slowest 10 durations =============================
4.00s call     tests/telemetry/test_track.py::test_is_telemetry_disabled_for_event
1.00s teardown tests/telemetry/test_track.py::test_record_usage_event
1.00s teardown tests/telemetry/test_track.py::test_record_usage_event_update_env_var_after_import
0.10s call     tests/telemetry/test_track.py::test_record_usage_event_update_env_var_after_import
0.10s call     tests/telemetry/test_track.py::test_record_usage_event
0.10s teardown tests/telemetry/test_track.py::test_backend_store_info

(4 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                            | Duration | Tests | Min    | Max    | Avg    |
| ---- | ------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/telemetry/test_track.py` | 6.32s    | 8     | 0.002s | 4.005s | 0.790s |

::endgroup::

[32m============================== [32m[1m10 passed[0m[32m in 6.34s[0m[32m ==============================[0m
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/telemetry -q'
```

退出码：`1`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 77 items

tests/telemetry/test_events.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m      [ 46%][0m
tests/telemetry/test_track.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                   [ 57%][0m
tests/telemetry/test_tracked_events.py [32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[31mF[0m[32m.[0m[32m.[0m[31mF[0m[32m.[0m[31m   [ 97%][0m
tests/telemetry/test_utils.py [32m.[0m[32m.[0m[31m                                         [100%][0m

=================================== FAILURES ===================================
[31m[1m_________________________ test_create_run_with_imports _________________________[0m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117e226a3d0>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_create_run_with_imports[39;49;00m(mock_requests, mock_telemetry_client: TelemetryClient):[90m[39;49;00m
        event_name = CreateRunEvent.name[90m[39;49;00m
>       [94mimport[39;49;00m[90m [39;49;00m[04m[96mpyspark[39;49;00m[04m[96m.[39;49;00m[04m[96mml[39;49;00m  [90m# noqa: F401[39;49;00m[90m[39;49;00m
        ^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'pyspark'[0m

event_name = 'create_run'
mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117e226a3d0>

[1m[31mtests/telemetry/test_tracked_events.py[0m:170: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:03:53 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________________ test_start_trace _______________________________[0m

mock_requests = []
mlflow_client = <mlflow.tracking.client.MlflowClient object at 0x7117e17e2510>
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117e17d4390>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_start_trace[39;49;00m(mock_requests, mlflow_client, mock_telemetry_client: TelemetryClient):[90m[39;49;00m
        event_name = StartTraceEvent.name[90m[39;49;00m
        [94mwith[39;49;00m mlflow.start_span(name=[33m"[39;49;00m[33mtest_span[39;49;00m[33m"[39;49;00m):[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
        validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, check_params=[94mFalse[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [37m@mlflow[39;49;00m.trace[90m[39;49;00m
        [94mdef[39;49;00m[90m [39;49;00m[92mtest_func[39;49;00m():[90m[39;49;00m
            [94mpass[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        test_func()[90m[39;49;00m
        validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, check_params=[94mFalse[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        trace_id = mlflow_client.start_trace(name=[33m"[39;49;00m[33mtest_trace[39;49;00m[33m"[39;49;00m).trace_id[90m[39;49;00m
        mlflow_client.end_trace(trace_id=trace_id)[90m[39;49;00m
        validate_telemetry_record(mock_telemetry_client, mock_requests, event_name, check_params=[94mFalse[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
>       [94mimport[39;49;00m[90m [39;49;00m[04m[96mopenai[39;49;00m  [90m# noqa: F401[39;49;00m[90m[39;49;00m
        ^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'openai'[0m

event_name = 'start_trace'
mlflow_client = <mlflow.tracking.client.MlflowClient object at 0x7117e17e2510>
mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117e17d4390>
test_func  = <function test_start_trace.<locals>.test_func at 0x7117e168cd60>
trace_id   = 'tr-6dbbbacbb3335a2ece6cb38ae206701f'

[1m[31mtests/telemetry/test_tracked_events.py[0m:259: ModuleNotFoundError
---------------------------- Captured stderr setup -----------------------------
2026/10/11 03:04:03 INFO mlflow.store.db.utils: Creating initial MLflow database tables...
2026/10/11 03:04:03 INFO mlflow.store.db.utils: Updating database tables
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade  -> 451aebb31d03, add metric step
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 451aebb31d03 -> 90e64c465722, migrate user column to tags
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 90e64c465722 -> 181f10493468, allow nulls for metric values
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 181f10493468 -> df50e92ffc5e, Add Experiment Tags Table
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade df50e92ffc5e -> 7ac759974ad8, Update run tags with larger limit
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 7ac759974ad8 -> 89d4b8295536, create latest metrics table
2026-10-11 03:04:03 INFO  [89d4b8295536_create_latest_metrics_table_py] Migration complete!
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 89d4b8295536 -> 2b4d017a5e9b, add model registry tables to db
2026-10-11 03:04:03 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Adding registered_models and model_versions tables to database.
2026-10-11 03:04:03 INFO  [2b4d017a5e9b_add_model_registry_tables_to_db_py] Migration complete!
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 2b4d017a5e9b -> cfd24bdc0731, Update run status constraint with killed
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade cfd24bdc0731 -> 0a8213491aaa, drop_duplicate_killed_constraint
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 0a8213491aaa -> 728d730b5ebd, add registered model tags table
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 728d730b5ebd -> 27a6a02d2cf1, add model version tags table
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 27a6a02d2cf1 -> 84291f40a231, add run_link to model_version
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 84291f40a231 -> a8c4a736bde6, allow nulls for run_id
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade a8c4a736bde6 -> 39d1c3be5f05, add_is_nan_constraint_for_metrics_tables_if_necessary
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 39d1c3be5f05 -> c48cb773bb87, reset_default_value_for_is_nan_in_metrics_table_for_mysql
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade c48cb773bb87 -> bd07f7e963c5, create index on run_uuid
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade bd07f7e963c5 -> 0c779009ac13, add deleted_time field to runs table
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 0c779009ac13 -> cc1f77228345, change param value length to 500
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade cc1f77228345 -> 97727af70f4d, Add creation_time and last_update_time to experiments table
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 97727af70f4d -> 3500859a5d39, Add Model Aliases table
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 3500859a5d39 -> 7f2a7d5fae7d, add datasets inputs input_tags tables
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 7f2a7d5fae7d -> 2d6e25af4d3e, increase max param val length from 500 to 8000
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 2d6e25af4d3e -> acf3f17fdcc7, add storage location field to model versions
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade acf3f17fdcc7 -> 867495a8f9d4, add trace tables
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 867495a8f9d4 -> 5b0e9adcef9c, add cascade deletion to trace tables foreign keys
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 5b0e9adcef9c -> 4465047574b1, increase max dataset schema size
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade 4465047574b1 -> f5a4f2784254, increase run tag value limit to 8000
2026-10-11 03:04:03 INFO  [alembic.runtime.migration] Running upgrade f5a4f2784254 -> 0584bdc529eb, add cascading deletion to datasets from experiments
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 0584bdc529eb -> 400f98739977, add logged model tables
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 400f98739977 -> 6953534de441, add step to inputs table
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 6953534de441 -> bda7b8c39065, increase_model_version_tag_value_limit
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade bda7b8c39065 -> cbc13b556ace, add V3 trace schema columns
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade cbc13b556ace -> 770bee3ae1dd, add assessments table
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 770bee3ae1dd -> a1b2c3d4e5f6, add spans table
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade a1b2c3d4e5f6 -> de4033877273, create entity_associations table
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade de4033877273 -> 1a0cddfcaa16, Add webhooks and webhook_events tables
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 1a0cddfcaa16 -> 534353b11cbc, add scorer tables
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 534353b11cbc -> 71994744cf8e, add evaluation datasets
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 71994744cf8e -> 3da73c924c2f, add outputs to dataset record
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Running upgrade 3da73c924c2f -> bf29a5ff90ea, add jobs table
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Context impl SQLiteImpl.
2026-10-11 03:04:04 INFO  [alembic.runtime.migration] Will assume non-transactional DDL.
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:04:05 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m____ test_invoke_custom_judge_model[openai:/gpt-4o-mini-openai-True-False] _____[0m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117dab96950>
model_uri = 'openai:/gpt-4o-mini', expected_provider = 'openai'
litellm_available = True, use_native_provider = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        ([33m"[39;49;00m[33mmodel_uri[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mexpected_provider[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mlitellm_available[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33muse_native_provider[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        [[90m[39;49;00m
            ([33m"[39;49;00m[33mdatabricks:/llama-3.1-70b[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mdatabricks[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
            ([33m"[39;49;00m[33mopenai:/gpt-4o-mini[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mopenai[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
            ([33m"[39;49;00m[33mendpoints:/my-endpoint[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mendpoints[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
            ([33m"[39;49;00m[33manthropic:/claude-3-opus[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33manthropic[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_invoke_custom_judge_model[39;49;00m([90m[39;49;00m
        mock_requests,[90m[39;49;00m
        mock_telemetry_client: TelemetryClient,[90m[39;49;00m
        model_uri,[90m[39;49;00m
        expected_provider,[90m[39;49;00m
        litellm_available,[90m[39;49;00m
        use_native_provider,[90m[39;49;00m
    ):[90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mgenai[39;49;00m[04m[96m.[39;49;00m[04m[96mjudges[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m invoke_judge_model[90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[04m[96m.[39;49;00m[04m[96mrest_utils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m MlflowHostCreds[90m[39;49;00m
    [90m[39;49;00m
        mock_response = json.dumps({[33m"[39;49;00m[33mresult[39;49;00m[33m"[39;49;00m: [94m0.8[39;49;00m, [33m"[39;49;00m[33mrationale[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mTest rationale[39;49;00m[33m"[39;49;00m})[90m[39;49;00m
    [90m[39;49;00m
        [90m# Mock Databricks credentials for databricks:// URIs[39;49;00m[90m[39;49;00m
        mock_creds = MlflowHostCreds(host=[33m"[39;49;00m[33mhttps://test.databricks.com[39;49;00m[33m"[39;49;00m, token=[33m"[39;49;00m[33mtest-token[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mwith[39;49;00m ([90m[39;49;00m
            mock.patch([90m[39;49;00m
                [33m"[39;49;00m[33mmlflow.genai.judges.utils._is_litellm_available[39;49;00m[33m"[39;49;00m, return_value=litellm_available[90m[39;49;00m
            ),[90m[39;49;00m
            mock.patch([90m[39;49;00m
                [33m"[39;49;00m[33mmlflow.utils.databricks_utils.get_databricks_host_creds[39;49;00m[33m"[39;49;00m, return_value=mock_creds[90m[39;49;00m
            ),[90m[39;49;00m
        ):[90m[39;49;00m
            [94mif[39;49;00m use_native_provider:[90m[39;49;00m
                [94mwith[39;49;00m ([90m[39;49;00m
                    mock.patch.object([90m[39;49;00m
                        [96m__import__[39;49;00m([90m[39;49;00m
                            [33m"[39;49;00m[33mmlflow.metrics.genai.model_utils[39;49;00m[33m"[39;49;00m, fromlist=[[33m"[39;49;00m[33mscore_model_on_payload[39;49;00m[33m"[39;49;00m][90m[39;49;00m
                        ),[90m[39;49;00m
                        [33m"[39;49;00m[33mscore_model_on_payload[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        return_value=mock_response,[90m[39;49;00m
                    ),[90m[39;49;00m
                    mock.patch.object([90m[39;49;00m
                        [96m__import__[39;49;00m([33m"[39;49;00m[33mmlflow.metrics.genai.model_utils[39;49;00m[33m"[39;49;00m, fromlist=[[33m"[39;49;00m[33mget_endpoint_type[39;49;00m[33m"[39;49;00m]),[90m[39;49;00m
                        [33m"[39;49;00m[33mget_endpoint_type[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        return_value=[33m"[39;49;00m[33mllm/v1/chat[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    ),[90m[39;49;00m
                ):[90m[39;49;00m
                    invoke_judge_model([90m[39;49;00m
                        model_uri=model_uri,[90m[39;49;00m
                        prompt=[33m"[39;49;00m[33mTest prompt[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        assessment_name=[33m"[39;49;00m[33mtest_assessment[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                [94mwith[39;49;00m ([90m[39;49;00m
                    mock.patch([90m[39;49;00m
                        [33m"[39;49;00m[33mmlflow.genai.judges.utils.invocation_utils._invoke_litellm_and_handle_tools[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        return_value=(mock_response, [94m10[39;49;00m),[90m[39;49;00m
                    ),[90m[39;49;00m
                    mock.patch([90m[39;49;00m
                        [33m"[39;49;00m[33mmlflow.genai.judges.adapters.databricks_serving_endpoint_adapter._invoke_databricks_serving_endpoint[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    ) [94mas[39;49;00m mock_databricks,[90m[39;49;00m
                ):[90m[39;49;00m
                    [90m# For databricks provider, mock the databricks model invocation[39;49;00m[90m[39;49;00m
                    [94mif[39;49;00m expected_provider [95min[39;49;00m [[33m"[39;49;00m[33mdatabricks[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mendpoints[39;49;00m[33m"[39;49;00m]:[90m[39;49;00m
                        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mgenai[39;49;00m[04m[96m.[39;49;00m[04m[96mjudges[39;49;00m[04m[96m.[39;49;00m[04m[96madapters[39;49;00m[04m[96m.[39;49;00m[04m[96mdatabricks_serving_endpoint_adapter[39;49;00m[90m [39;49;00m[94mimport[39;49;00m ([90m[39;49;00m
                            InvokeDatabricksModelOutput,[90m[39;49;00m
                        )[90m[39;49;00m
    [90m[39;49;00m
                        mock_databricks.return_value = InvokeDatabricksModelOutput([90m[39;49;00m
                            response=mock_response,[90m[39;49;00m
                            request_id=[33m"[39;49;00m[33mtest-request-id[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                            num_prompt_tokens=[94m10[39;49;00m,[90m[39;49;00m
                            num_completion_tokens=[94m20[39;49;00m,[90m[39;49;00m
                        )[90m[39;49;00m
    [90m[39;49;00m
>                   invoke_judge_model([90m[39;49;00m
                        model_uri=model_uri,[90m[39;49;00m
                        prompt=[33m"[39;49;00m[33mTest prompt[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        assessment_name=[33m"[39;49;00m[33mtest_assessment[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m

MlflowHostCreds = <class 'mlflow.utils.rest_utils.MlflowHostCreds'>
expected_provider = 'openai'
invoke_judge_model = <function invoke_judge_model at 0x71181ab04360>
litellm_available = True
mock_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x7117dab98b10>
mock_databricks = <MagicMock name='_invoke_databricks_serving_endpoint' id='124347267715536'>
mock_requests = []
mock_response = '{"result": 0.8, "rationale": "Test rationale"}'
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117dab96950>
model_uri  = 'openai:/gpt-4o-mini'
use_native_provider = False

[1m[31mtests/telemetry/test_tracked_events.py[0m:775: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/telemetry/track.py[0m:45: in wrapper
    [0mresult = func(*args, **kwargs)[90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ()
        duration_ms = 53
        event      = <class 'mlflow.telemetry.events.InvokeCustomJudgeModelEvent'>
        func       = <function invoke_judge_model at 0x71181ab04220>
        kwargs     = {'assessment_name': 'test_assessment', 'model_uri': 'openai:/gpt-4o-mini', 'prompt': 'Test prompt'}
        result     = None
        start_time = 1791687892.6688871
        success    = False
[1m[31mmlflow/genai/judges/utils/invocation_utils.py[0m:190: in invoke_judge_model
    [0mresponse = _invoke_via_gateway(model_uri, model_provider, prompt)[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        ChatMessage = <class 'mlflow.types.llm.ChatMessage'>
        _parse_model_uri = <function _parse_model_uri at 0x7117e0eb9300>
        assessment_name = 'test_assessment'
        in_databricks = False
        messages   = [ChatMessage(role='user', content='Test prompt', refusal=None, name=None, tool_calls=None, tool_call_id=None)]
        model_name = 'gpt-4o-mini'
        model_provider = 'openai'
        model_uri  = 'openai:/gpt-4o-mini'
        num_retries = 10
        prompt     = 'Test prompt'
        response_format = None
        total_cost = None
        trace      = None
[1m[31mmlflow/genai/judges/adapters/gateway_adapter.py[0m:38: in _invoke_via_gateway
    [0m[94mreturn[39;49;00m score_model_on_payload([90m[39;49;00m
        get_endpoint_type = <function get_endpoint_type at 0x7117e0eb91c0>
        model_uri  = 'openai:/gpt-4o-mini'
        prompt     = 'Test prompt'
        provider   = 'openai'
        score_model_on_payload = <function score_model_on_payload at 0x7117e0eb9260>
[1m[31mmlflow/metrics/genai/model_utils.py[0m:70: in score_model_on_payload
    [0m[94mreturn[39;49;00m _call_llm_provider_api([90m[39;49;00m
        endpoint_type = 'llm/v1/chat'
        eval_parameters = {}
        extra_headers = {}
        get_deploy_client = <function get_deploy_client at 0x7117ea97a0c0>
        is_supported_provider = <function is_supported_provider at 0x7117dab67e20>
        model_uri  = 'openai:/gpt-4o-mini'
        payload    = 'Test prompt'
        prefix     = 'openai'
        proxy_url  = None
        suffix     = 'gpt-4o-mini'
[1m[31mmlflow/metrics/genai/model_utils.py[0m:134: in _call_llm_provider_api
    [0mprovider = _get_provider_instance(provider_name, model)[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        Provider   = <enum 'Provider'>
        chat       = <module 'mlflow.gateway.schemas.chat' from '/testbed/mlflow/gateway/schemas/chat.py'>
        eval_parameters = {}
        extra_headers = {}
        input_data = 'Test prompt'
        model      = 'gpt-4o-mini'
        provider_name = 'openai'
        proxy_url  = None
[1m[31mmlflow/metrics/genai/model_utils.py[0m:204: in _get_provider_instance
    [0mapi_config = _get_api_config()[90m[39;49;00m
                 ^^^^^^^^^^^^^^^^^[90m[39;49;00m
        EndpointConfig = <class 'mlflow.gateway.config.EndpointConfig'>
        OpenAIConfig = <class 'mlflow.gateway.config.OpenAIConfig'>
        OpenAIProvider = <class 'mlflow.gateway.providers.openai.OpenAIProvider'>
        Provider   = <enum 'Provider'>
        _OAITokenHolder = <class 'mlflow.utils.openai_utils._OAITokenHolder'>
        _get_api_config = <function _get_api_config at 0x7117daa336a0>
        _get_route_config = <function _get_provider_instance.<locals>._get_route_config at 0x7117dab65ee0>
        model      = 'gpt-4o-mini'
        provider   = 'openai'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_get_api_config[39;49;00m() -> _OpenAIApiConfig:[90m[39;49;00m
    [90m    [39;49;00m[33m"""Gets the parameters and configuration of the OpenAI API connected to."""[39;49;00m[90m[39;49;00m
>       [94mimport[39;49;00m[90m [39;49;00m[04m[96mopenai[39;49;00m[90m[39;49;00m
[1m[31mE       ModuleNotFoundError: No module named 'openai'[0m


[1m[31mmlflow/openai/model.py[0m:153: ModuleNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:04:52 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_ test_invoke_custom_judge_model[anthropic:/claude-3-opus-anthropic-True-False] _[0m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117daba66d0>
model_uri = 'anthropic:/claude-3-opus', expected_provider = 'anthropic'
litellm_available = True, use_native_provider = False

    [0m[37m@pytest[39;49;00m.mark.parametrize([90m[39;49;00m
        ([33m"[39;49;00m[33mmodel_uri[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mexpected_provider[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mlitellm_available[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33muse_native_provider[39;49;00m[33m"[39;49;00m),[90m[39;49;00m
        [[90m[39;49;00m
            ([33m"[39;49;00m[33mdatabricks:/llama-3.1-70b[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mdatabricks[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
            ([33m"[39;49;00m[33mopenai:/gpt-4o-mini[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mopenai[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
            ([33m"[39;49;00m[33mendpoints:/my-endpoint[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mendpoints[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
            ([33m"[39;49;00m[33manthropic:/claude-3-opus[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33manthropic[39;49;00m[33m"[39;49;00m, [94mTrue[39;49;00m, [94mFalse[39;49;00m),[90m[39;49;00m
        ],[90m[39;49;00m
    )[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mtest_invoke_custom_judge_model[39;49;00m([90m[39;49;00m
        mock_requests,[90m[39;49;00m
        mock_telemetry_client: TelemetryClient,[90m[39;49;00m
        model_uri,[90m[39;49;00m
        expected_provider,[90m[39;49;00m
        litellm_available,[90m[39;49;00m
        use_native_provider,[90m[39;49;00m
    ):[90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mgenai[39;49;00m[04m[96m.[39;49;00m[04m[96mjudges[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m invoke_judge_model[90m[39;49;00m
        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mutils[39;49;00m[04m[96m.[39;49;00m[04m[96mrest_utils[39;49;00m[90m [39;49;00m[94mimport[39;49;00m MlflowHostCreds[90m[39;49;00m
    [90m[39;49;00m
        mock_response = json.dumps({[33m"[39;49;00m[33mresult[39;49;00m[33m"[39;49;00m: [94m0.8[39;49;00m, [33m"[39;49;00m[33mrationale[39;49;00m[33m"[39;49;00m: [33m"[39;49;00m[33mTest rationale[39;49;00m[33m"[39;49;00m})[90m[39;49;00m
    [90m[39;49;00m
        [90m# Mock Databricks credentials for databricks:// URIs[39;49;00m[90m[39;49;00m
        mock_creds = MlflowHostCreds(host=[33m"[39;49;00m[33mhttps://test.databricks.com[39;49;00m[33m"[39;49;00m, token=[33m"[39;49;00m[33mtest-token[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
    [90m[39;49;00m
        [94mwith[39;49;00m ([90m[39;49;00m
            mock.patch([90m[39;49;00m
                [33m"[39;49;00m[33mmlflow.genai.judges.utils._is_litellm_available[39;49;00m[33m"[39;49;00m, return_value=litellm_available[90m[39;49;00m
            ),[90m[39;49;00m
            mock.patch([90m[39;49;00m
                [33m"[39;49;00m[33mmlflow.utils.databricks_utils.get_databricks_host_creds[39;49;00m[33m"[39;49;00m, return_value=mock_creds[90m[39;49;00m
            ),[90m[39;49;00m
        ):[90m[39;49;00m
            [94mif[39;49;00m use_native_provider:[90m[39;49;00m
                [94mwith[39;49;00m ([90m[39;49;00m
                    mock.patch.object([90m[39;49;00m
                        [96m__import__[39;49;00m([90m[39;49;00m
                            [33m"[39;49;00m[33mmlflow.metrics.genai.model_utils[39;49;00m[33m"[39;49;00m, fromlist=[[33m"[39;49;00m[33mscore_model_on_payload[39;49;00m[33m"[39;49;00m][90m[39;49;00m
                        ),[90m[39;49;00m
                        [33m"[39;49;00m[33mscore_model_on_payload[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        return_value=mock_response,[90m[39;49;00m
                    ),[90m[39;49;00m
                    mock.patch.object([90m[39;49;00m
                        [96m__import__[39;49;00m([33m"[39;49;00m[33mmlflow.metrics.genai.model_utils[39;49;00m[33m"[39;49;00m, fromlist=[[33m"[39;49;00m[33mget_endpoint_type[39;49;00m[33m"[39;49;00m]),[90m[39;49;00m
                        [33m"[39;49;00m[33mget_endpoint_type[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        return_value=[33m"[39;49;00m[33mllm/v1/chat[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    ),[90m[39;49;00m
                ):[90m[39;49;00m
                    invoke_judge_model([90m[39;49;00m
                        model_uri=model_uri,[90m[39;49;00m
                        prompt=[33m"[39;49;00m[33mTest prompt[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        assessment_name=[33m"[39;49;00m[33mtest_assessment[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m
            [94melse[39;49;00m:[90m[39;49;00m
                [94mwith[39;49;00m ([90m[39;49;00m
                    mock.patch([90m[39;49;00m
                        [33m"[39;49;00m[33mmlflow.genai.judges.utils.invocation_utils._invoke_litellm_and_handle_tools[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        return_value=(mock_response, [94m10[39;49;00m),[90m[39;49;00m
                    ),[90m[39;49;00m
                    mock.patch([90m[39;49;00m
                        [33m"[39;49;00m[33mmlflow.genai.judges.adapters.databricks_serving_endpoint_adapter._invoke_databricks_serving_endpoint[39;49;00m[33m"[39;49;00m[90m[39;49;00m
                    ) [94mas[39;49;00m mock_databricks,[90m[39;49;00m
                ):[90m[39;49;00m
                    [90m# For databricks provider, mock the databricks model invocation[39;49;00m[90m[39;49;00m
                    [94mif[39;49;00m expected_provider [95min[39;49;00m [[33m"[39;49;00m[33mdatabricks[39;49;00m[33m"[39;49;00m, [33m"[39;49;00m[33mendpoints[39;49;00m[33m"[39;49;00m]:[90m[39;49;00m
                        [94mfrom[39;49;00m[90m [39;49;00m[04m[96mmlflow[39;49;00m[04m[96m.[39;49;00m[04m[96mgenai[39;49;00m[04m[96m.[39;49;00m[04m[96mjudges[39;49;00m[04m[96m.[39;49;00m[04m[96madapters[39;49;00m[04m[96m.[39;49;00m[04m[96mdatabricks_serving_endpoint_adapter[39;49;00m[90m [39;49;00m[94mimport[39;49;00m ([90m[39;49;00m
                            InvokeDatabricksModelOutput,[90m[39;49;00m
                        )[90m[39;49;00m
    [90m[39;49;00m
                        mock_databricks.return_value = InvokeDatabricksModelOutput([90m[39;49;00m
                            response=mock_response,[90m[39;49;00m
                            request_id=[33m"[39;49;00m[33mtest-request-id[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                            num_prompt_tokens=[94m10[39;49;00m,[90m[39;49;00m
                            num_completion_tokens=[94m20[39;49;00m,[90m[39;49;00m
                        )[90m[39;49;00m
    [90m[39;49;00m
>                   invoke_judge_model([90m[39;49;00m
                        model_uri=model_uri,[90m[39;49;00m
                        prompt=[33m"[39;49;00m[33mTest prompt[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                        assessment_name=[33m"[39;49;00m[33mtest_assessment[39;49;00m[33m"[39;49;00m,[90m[39;49;00m
                    )[90m[39;49;00m

MlflowHostCreds = <class 'mlflow.utils.rest_utils.MlflowHostCreds'>
expected_provider = 'anthropic'
invoke_judge_model = <function invoke_judge_model at 0x71181ab04360>
litellm_available = True
mock_creds = <mlflow.utils.rest_utils.MlflowHostCreds object at 0x7117daa68ad0>
mock_databricks = <MagicMock name='_invoke_databricks_serving_endpoint' id='124347266526352'>
mock_requests = []
mock_response = '{"result": 0.8, "rationale": "Test rationale"}'
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117daba66d0>
model_uri  = 'anthropic:/claude-3-opus'
use_native_provider = False

[1m[31mtests/telemetry/test_tracked_events.py[0m:775: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/telemetry/track.py[0m:45: in wrapper
    [0mresult = func(*args, **kwargs)[90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        args       = ()
        duration_ms = 0
        event      = <class 'mlflow.telemetry.events.InvokeCustomJudgeModelEvent'>
        func       = <function invoke_judge_model at 0x71181ab04220>
        kwargs     = {'assessment_name': 'test_assessment', 'model_uri': 'anthropic:/claude-3-opus', 'prompt': 'Test prompt'}
        result     = None
        start_time = 1791687893.8745556
        success    = False
[1m[31mmlflow/genai/judges/utils/invocation_utils.py[0m:190: in invoke_judge_model
    [0mresponse = _invoke_via_gateway(model_uri, model_provider, prompt)[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        ChatMessage = <class 'mlflow.types.llm.ChatMessage'>
        _parse_model_uri = <function _parse_model_uri at 0x7117e0eb9300>
        assessment_name = 'test_assessment'
        in_databricks = False
        messages   = [ChatMessage(role='user', content='Test prompt', refusal=None, name=None, tool_calls=None, tool_call_id=None)]
        model_name = 'claude-3-opus'
        model_provider = 'anthropic'
        model_uri  = 'anthropic:/claude-3-opus'
        num_retries = 10
        prompt     = 'Test prompt'
        response_format = None
        total_cost = None
        trace      = None
[1m[31mmlflow/genai/judges/adapters/gateway_adapter.py[0m:38: in _invoke_via_gateway
    [0m[94mreturn[39;49;00m score_model_on_payload([90m[39;49;00m
        get_endpoint_type = <function get_endpoint_type at 0x7117e0eb91c0>
        model_uri  = 'anthropic:/claude-3-opus'
        prompt     = 'Test prompt'
        provider   = 'anthropic'
        score_model_on_payload = <function score_model_on_payload at 0x7117e0eb9260>
[1m[31mmlflow/metrics/genai/model_utils.py[0m:70: in score_model_on_payload
    [0m[94mreturn[39;49;00m _call_llm_provider_api([90m[39;49;00m
        endpoint_type = 'llm/v1/chat'
        eval_parameters = {}
        extra_headers = {}
        get_deploy_client = <function get_deploy_client at 0x7117ea97a0c0>
        is_supported_provider = <function is_supported_provider at 0x7117dab67e20>
        model_uri  = 'anthropic:/claude-3-opus'
        payload    = 'Test prompt'
        prefix     = 'anthropic'
        proxy_url  = None
        suffix     = 'claude-3-opus'
[1m[31mmlflow/metrics/genai/model_utils.py[0m:134: in _call_llm_provider_api
    [0mprovider = _get_provider_instance(provider_name, model)[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        Provider   = <enum 'Provider'>
        chat       = <module 'mlflow.gateway.schemas.chat' from '/testbed/mlflow/gateway/schemas/chat.py'>
        eval_parameters = {}
        extra_headers = {}
        input_data = 'Test prompt'
        model      = 'claude-3-opus'
        provider_name = 'anthropic'
        proxy_url  = None
[1m[31mmlflow/metrics/genai/model_utils.py[0m:221: in _get_provider_instance
    [0mconfig = AnthropicConfig(anthropic_api_key=os.environ.get([33m"[39;49;00m[33mANTHROPIC_API_KEY[39;49;00m[33m"[39;49;00m))[90m[39;49;00m
             ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        AnthropicConfig = <class 'mlflow.gateway.config.AnthropicConfig'>
        AnthropicProvider = <class 'mlflow.gateway.providers.anthropic.AnthropicProvider'>
        EndpointConfig = <class 'mlflow.gateway.config.EndpointConfig'>
        Provider   = <enum 'Provider'>
        _get_route_config = <function _get_provider_instance.<locals>._get_route_config at 0x7117daa79da0>
        model      = 'claude-3-opus'
        provider   = 'anthropic'
[1m[31mmlflow/gateway/config.py[0m:173: in validate_anthropic_api_key
    [0m[94mreturn[39;49;00m _resolve_api_key_from_input(value)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        cls        = <class 'mlflow.gateway.config.AnthropicConfig'>
        value      = None
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

api_key_input = None

    [0m[94mdef[39;49;00m[90m [39;49;00m[92m_resolve_api_key_from_input[39;49;00m(api_key_input):[90m[39;49;00m
    [90m    [39;49;00m[33m"""[39;49;00m
    [33m    Resolves the provided API key.[39;49;00m
    [33m[39;49;00m
    [33m    Input formats accepted:[39;49;00m
    [33m[39;49;00m
    [33m    - Path to a file as a string which will have the key loaded from it[39;49;00m
    [33m    - environment variable name that stores the api key[39;49;00m
    [33m    - the api key itself[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
    [90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m [96misinstance[39;49;00m(api_key_input, [96mstr[39;49;00m):[90m[39;49;00m
>           [94mraise[39;49;00m MlflowException.invalid_parameter_value([90m[39;49;00m
                [33m"[39;49;00m[33mThe api key provided is not a string. Please provide either an environment [39;49;00m[33m"[39;49;00m[90m[39;49;00m
                [33m"[39;49;00m[33mvariable key, a path to a file containing the api key, or the api key itself[39;49;00m[33m"[39;49;00m[90m[39;49;00m
            )[90m[39;49;00m
[1m[31mE           mlflow.exceptions.MlflowException: The api key provided is not a string. Please provide either an environment variable key, a path to a file containing the api key, or the api key itself[0m

api_key_input = None

[1m[31mmlflow/gateway/config.py[0m:249: MlflowException
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:04:53 INFO mlflow.tracking.fluent: Active model is cleared
[31m[1m_______________________________ test_autologging _______________________________[0m

cls = <class 'importlib.metadata.Distribution'>, name = 'openai'

    [0m[37m@classmethod[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mfrom_name[39;49;00m([96mcls[39;49;00m, name: [96mstr[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Return the Distribution for the given package name.[39;49;00m
    [33m[39;49;00m
    [33m    :param name: The name of the distribution package to search for.[39;49;00m
    [33m    :return: The Distribution instance (or subclass thereof) for the named[39;49;00m
    [33m        package, if found.[39;49;00m
    [33m    :raises PackageNotFoundError: When the named package's distribution[39;49;00m
    [33m        metadata cannot be found.[39;49;00m
    [33m    :raises ValueError: When an invalid value is supplied for name.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m name:[90m[39;49;00m
            [94mraise[39;49;00m [96mValueError[39;49;00m([33m"[39;49;00m[33mA distribution name is required.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           [94mreturn[39;49;00m [96mnext[39;49;00m([96mcls[39;49;00m.discover(name=name))[90m[39;49;00m
                   ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
[1m[31mE           StopIteration[0m

cls        = <class 'importlib.metadata.Distribution'>
name       = 'openai'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/importlib/metadata/__init__.py[0m:563: StopIteration

[33mDuring handling of the above exception, another exception occurred:[0m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117daa76cd0>

    [0m[94mdef[39;49;00m[90m [39;49;00m[92mtest_autologging[39;49;00m(mock_requests, mock_telemetry_client: TelemetryClient):[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
>           mlflow.openai.autolog()[90m[39;49;00m

mock_requests = []
mock_telemetry_client = <mlflow.telemetry.client.TelemetryClient object at 0x7117daa76cd0>

[1m[31mtests/telemetry/test_tracked_events.py[0m:841: 
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 
[1m[31mmlflow/openai/autolog.py[0m:62: in autolog
    [0m[94mif[39;49;00m Version(importlib.metadata.version([33m"[39;49;00m[33mopenai[39;49;00m[33m"[39;49;00m)).major < [94m1[39;49;00m:[90m[39;49;00m
               ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        disable    = False
        disable_for_unsupported_versions = False
        exclusive  = False
        log_traces = True
        silent     = False
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/importlib/metadata/__init__.py[0m:1009: in version
    [0m[94mreturn[39;49;00m distribution(distribution_name).version[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        distribution_name = 'openai'
[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/importlib/metadata/__init__.py[0m:982: in distribution
    [0m[94mreturn[39;49;00m Distribution.from_name(distribution_name)[90m[39;49;00m
           ^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^[90m[39;49;00m
        distribution_name = 'openai'
_ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ _ 

cls = <class 'importlib.metadata.Distribution'>, name = 'openai'

    [0m[37m@classmethod[39;49;00m[90m[39;49;00m
    [94mdef[39;49;00m[90m [39;49;00m[92mfrom_name[39;49;00m([96mcls[39;49;00m, name: [96mstr[39;49;00m):[90m[39;49;00m
    [90m    [39;49;00m[33m"""Return the Distribution for the given package name.[39;49;00m
    [33m[39;49;00m
    [33m    :param name: The name of the distribution package to search for.[39;49;00m
    [33m    :return: The Distribution instance (or subclass thereof) for the named[39;49;00m
    [33m        package, if found.[39;49;00m
    [33m    :raises PackageNotFoundError: When the named package's distribution[39;49;00m
    [33m        metadata cannot be found.[39;49;00m
    [33m    :raises ValueError: When an invalid value is supplied for name.[39;49;00m
    [33m    """[39;49;00m[90m[39;49;00m
        [94mif[39;49;00m [95mnot[39;49;00m name:[90m[39;49;00m
            [94mraise[39;49;00m [96mValueError[39;49;00m([33m"[39;49;00m[33mA distribution name is required.[39;49;00m[33m"[39;49;00m)[90m[39;49;00m
        [94mtry[39;49;00m:[90m[39;49;00m
            [94mreturn[39;49;00m [96mnext[39;49;00m([96mcls[39;49;00m.discover(name=name))[90m[39;49;00m
        [94mexcept[39;49;00m [96mStopIteration[39;49;00m:[90m[39;49;00m
>           [94mraise[39;49;00m PackageNotFoundError(name)[90m[39;49;00m
[1m[31mE           importlib.metadata.PackageNotFoundError: No package metadata was found for openai[0m

cls        = <class 'importlib.metadata.Distribution'>
name       = 'openai'

[1m[31m/opt/miniconda3/envs/testbed/lib/python3.11/importlib/metadata/__init__.py[0m:565: PackageNotFoundError
--------------------------- Captured stderr teardown ---------------------------
2026/10/11 03:04:56 INFO mlflow.tracking.fluent: Active model is cleared
[33m=============================== warnings summary ===============================[0m
tests/telemetry/test_tracked_events.py::test_evaluate
  /testbed/tests/telemetry/test_tracked_events.py:336: FutureWarning: ``mlflow.metrics.latency`` is deprecated since 3.4.0. Use the new GenAI evaluation functionality instead. See https://mlflow.org/docs/latest/genai/eval-monitor/legacy-llm-evaluation/ for the migration guide.
    extra_metrics=[mlflow.metrics.latency()],

tests/telemetry/test_tracked_events.py::test_evaluate
tests/telemetry/test_tracked_events.py::test_log_dataset
  /testbed/mlflow/types/utils.py:452: UserWarning: Hint: Inferred schema contains integer column(s). Integer columns in Python cannot represent missing values. If your input data contains missing values at inference time, it will be encoded as floats and will cause a schema enforcement error. The best way to avoid this problem is to infer the model schema based on a realistic data sample (training dataset) that includes missing values. Alternatively, you can declare integer columns as doubles (float64) whenever these columns may have missing values. See `Handling Integers With Missing Values <https://www.mlflow.org/docs/latest/models.html#handling-integers-with-missing-values>`_ for more details.
    warnings.warn(

tests/telemetry/test_tracked_events.py::test_prompt_optimization
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: Failed to determine whether UCVolumeDatasetSource can resolve source information for 'prompt_optimization_train_data'. Exception: 
    return _dataset_source_registry.resolve(

tests/telemetry/test_tracked_events.py::test_prompt_optimization
  /testbed/mlflow/data/dataset_source_registry.py:148: UserWarning: The specified dataset source can be interpreted in multiple ways: LocalArtifactDatasetSource, LocalArtifactDatasetSource. MLflow will assume that this is a LocalArtifactDatasetSource source.
    return _dataset_source_registry.resolve(

tests/telemetry/test_tracked_events.py::test_invoke_custom_judge_model[endpoints:/my-endpoint-endpoints-True-False]
  /testbed/mlflow/telemetry/track.py:45: FutureWarning: The legacy provider 'endpoints' is deprecated and will be removed in a futurerelease. Please update your code to use the 'databricks' provider instead.
    result = func(*args, **kwargs)

-- Docs: https://docs.pytest.org/en/stable/how-to/capture-warnings.html
============================= slowest 10 durations =============================
6.96s call     tests/telemetry/test_tracked_events.py::test_create_logged_model
4.31s call     tests/telemetry/test_tracked_events.py::test_get_logged_model
4.00s call     tests/telemetry/test_track.py::test_is_telemetry_disabled_for_event
3.37s call     tests/telemetry/test_tracked_events.py::test_evaluate
2.94s call     tests/telemetry/test_tracked_events.py::test_log_metric
2.68s call     tests/telemetry/test_tracked_events.py::test_log_batch
2.63s call     tests/telemetry/test_tracked_events.py::test_log_param
2.05s call     tests/telemetry/test_tracked_events.py::test_create_registered_model
2.00s call     tests/telemetry/test_tracked_events.py::test_load_prompt
2.00s call     tests/telemetry/test_tracked_events.py::test_create_model_version

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                                     | Duration | Tests | Min    | Max    | Avg    |
| ---- | ---------------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/telemetry/test_tracked_events.py` | 78.89s   | 31    | 0.102s | 7.962s | 2.545s |
| 2    | `tests/telemetry/test_track.py`          | 6.32s    | 8     | 0.002s | 4.005s | 0.790s |

::endgroup::

========================= command to run failed tests ==========================
pytest 'tests/telemetry/test_tracked_events.py::test_create_run_with_imports' 'tests/telemetry/test_tracked_events.py::test_start_trace' 'tests/telemetry/test_tracked_events.py::test_invoke_custom_judge_model[openai:/gpt-4o-mini-openai-True-False]' 'tests/telemetry/test_tracked_events.py::test_invoke_custom_judge_model[anthropic:/claude-3-opus-anthropic-True-False]' 'tests/telemetry/test_tracked_events.py::test_autologging'

[36m[1m=========================== short test summary info ============================[0m
[31mFAILED | MEM 22.6/33.7 GB | DISK 796.3/915.7 GB[0m tests/telemetry/test_tracked_events.py::[1mtest_create_run_with_imports[0m - ModuleNotFoundError: No module named 'pyspark'
[31mFAILED | MEM 22.6/33.7 GB | DISK 796.3/915.7 GB[0m tests/telemetry/test_tracked_events.py::[1mtest_start_trace[0m - ModuleNotFoundError: No module named 'openai'
[31mFAILED | MEM 22.6/33.7 GB | DISK 796.3/915.7 GB[0m tests/telemetry/test_tracked_events.py::[1mtest_invoke_custom_judge_model[openai:/gpt-4o-mini-openai-True-False][0m - ModuleNotFoundError: No module named 'openai'
[31mFAILED | MEM 22.6/33.7 GB | DISK 796.3/915.7 GB[0m tests/telemetry/test_tracked_events.py::[1mtest_invoke_custom_judge_model[anthropic:/claude-3-opus-anthropic-True-False][0m - mlflow.exceptions.MlflowException: The api key provided is not a string. Pl...
[31mFAILED | MEM 22.6/33.7 GB | DISK 796.3/915.7 GB[0m tests/telemetry/test_tracked_events.py::[1mtest_autologging[0m - importlib.metadata.PackageNotFoundError: No package metadata was found for ...
[31m============= [31m[1m5 failed[0m, [32m72 passed[0m, [33m6 warnings[0m[31m in 86.05s (0:01:26)[0m[31m ==============[0m
```

## 原始行 57 · command_execution

命令：
```
/bin/bash -lc "sed -n '35,115p' mlflow/openai/autolog.py; sed -n '3300,3370p' mlflow/tracking/fluent.py; git diff --stat && git diff --check && python -m compileall -q mlflow/telemetry"
```

退出码：`0`

输出：
```
def autolog(
    disable=False,
    exclusive=False,
    disable_for_unsupported_versions=False,
    silent=False,
    log_traces=True,
):
    """
    Enables (or disables) and configures autologging from OpenAI to MLflow.
    Raises :py:class:`MlflowException <mlflow.exceptions.MlflowException>`
    if the OpenAI version < 1.0.

    Args:
        disable: If ``True``, disables the OpenAI autologging integration. If ``False``,
            enables the OpenAI autologging integration.
        exclusive: If ``True``, autologged content is not logged to user-created fluent runs.
            If ``False``, autologged content is logged to the active fluent run,
            which may be user-created.
        disable_for_unsupported_versions: If ``True``, disable autologging for versions of
            OpenAI that have not been tested against this version of the MLflow
            client or are incompatible.
        silent: If ``True``, suppress all event logs and warnings from MLflow during OpenAI
            autologging. If ``False``, show all events and warnings during OpenAI
            autologging.
        log_traces: If ``True``, traces are logged for OpenAI models. If ``False``, no traces are
            collected during inference. Default to ``True``.
    """
    if Version(importlib.metadata.version("openai")).major < 1:
        raise MlflowException("OpenAI autologging is only supported for openai >= 1.0.0")

    # This needs to be called before doing any safe-patching (otherwise safe-patch will be no-op).
    # TODO: since this implementation is inconsistent, explore a universal way to solve the issue.
    _autolog(
        disable=disable,
        exclusive=exclusive,
        disable_for_unsupported_versions=disable_for_unsupported_versions,
        silent=silent,
        log_traces=log_traces,
    )

    # Tracing OpenAI Agent SDK. This has to be done outside the function annotated with
    # `@autologging_integration` because the function is not executed when `disable=True`.
    try:
        from agents.run import AgentRunner

        from mlflow.openai._agent_tracer import _patched_agent_run

        # NB: The OpenAI's built-in tracer does not capture inputs/outputs of the
        # root span, which is not inconvenient. Therefore, we add a patch for the
        # runner.run() method instead.
        safe_patch(FLAVOR_NAME, AgentRunner, "run", _patched_agent_run)

        from mlflow.openai._agent_tracer import (
            add_mlflow_trace_processor,
            remove_mlflow_trace_processor,
        )

        if log_traces and not disable:
            add_mlflow_trace_processor()
        else:
            remove_mlflow_trace_processor()
    except ImportError:
        pass

    _record_event(
        AutologgingEvent, {"flavor": FLAVOR_NAME, "log_traces": log_traces, "disable": disable}
    )


# This is required by mlflow.autolog()
autolog.integration_name = FLAVOR_NAME


# NB: The @autologging_integration annotation must be applied here, and the callback injection
# needs to happen outside the annotated function. This is because the annotated function is NOT
# executed when disable=True is passed. This prevents us from removing our callback and patching
# when autologging is turned off.
@autologging_integration(FLAVOR_NAME)
def _autolog(
    disable=False,
    exclusive=False,
            ):
                return

            autologging_params = get_autologging_params(autolog_fn)
            autolog_fn(**autologging_params)
            AUTOLOGGING_INTEGRATIONS[autolog_fn.integration_name][
                AUTOLOGGING_CONF_KEY_IS_GLOBALLY_CONFIGURED
            ] = True
            if not autologging_is_disabled(
                autolog_fn.integration_name
            ) and not autologging_params.get("silent", False):
                _logger.info("Autologging successfully enabled for %s.", module.__name__)
        except Exception as e:
            if is_testing():
                # Raise unexpected exceptions in test mode in order to detect
                # errors within dependent autologging integrations
                raise
            elif autologging_params is None or not autologging_params.get("silent", False):
                _logger.warning(
                    "Exception raised while enabling autologging for %s: %s",
                    module.__name__,
                    str(e),
                )

    # for each autolog library (except pyspark), register a post-import hook.
    # this way, we do not send any errors to the user until we know they are using the library.
    # the post-import hook also retroactively activates for previously-imported libraries.
    for library in sorted(set(target_library_and_module) - {"pyspark", "pyspark.ml"}):
        register_post_import_hook(setup_autologging, library, overwrite=True)

    if is_in_databricks_runtime():
        # for pyspark, we activate autologging immediately, without waiting for a module import.
        # this is because on Databricks a SparkSession already exists and the user can directly
        #   interact with it, and this activity should be logged.
        import pyspark as pyspark_module
        import pyspark.ml as pyspark_ml_module

        setup_autologging(pyspark_module)
        setup_autologging(pyspark_ml_module)
    else:
        if "pyspark" in target_library_and_module:
            register_post_import_hook(setup_autologging, "pyspark", overwrite=True)
        if "pyspark.ml" in target_library_and_module:
            register_post_import_hook(setup_autologging, "pyspark.ml", overwrite=True)

    _record_event(AutologgingEvent, {"flavor": "all", "log_traces": log_traces, "disable": disable})


_active_model_id_env_lock = threading.Lock()


class ActiveModelContext:
    """
    The context of the active model.

    Args:
        model_id: The ID of the active model.
        set_by_user: Whether the active model was set by the user or not.
    """

    def __init__(self, model_id: str | None = None, set_by_user: bool = False):
        # use active model ID from environment variables as the default value for model_id
        # so that for subprocesses the default _ACTIVE_MODEL_CONTEXT.model_id
        # is still valid, and we don't need to read from env var.
        self._set_by_user = set_by_user
        if is_in_databricks_model_serving_environment():
            # In Databricks, we set the active model ID to the environment variable
            # so that it can be used in the main process, since databricks serving
            # loads model from threads.
            with _active_model_id_env_lock:
                self._model_id = model_id or _get_active_model_id_from_env()
 mlflow/telemetry/client.py | 400 +++++++++++++++++++--------------------------
 mlflow/telemetry/track.py  |  16 +-
 mlflow/telemetry/utils.py  |  15 +-
 3 files changed, 197 insertions(+), 234 deletions(-)
```

## 原始行 62 · file_change

```
{
  "id": "item_42",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/telemetry/client.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc 'ruff check mlflow/telemetry/client.py mlflow/telemetry/track.py mlflow/telemetry/utils.py && ruff format --check mlflow/telemetry/client.py mlflow/telemetry/track.py mlflow/telemetry/utils.py'
```

退出码：`2`

输出：
```
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 69 · command_execution

命令：
```
/bin/bash -lc "sed -n '110,190p' mlflow/tracing/export/async_export_queue.py; sed -n '200,260p' mlflow/utils/async_logging/async_artifacts_logging_queue.py; grep -R \"for thread in self._.*threads\" -n mlflow | head -30"
```

退出码：`0`

输出：
```
        try:
            future = self._worker_threadpool.submit(_handle, task)
            self._active_tasks.add(future)
        except Exception as e:
            # In case it fails to submit the task to the worker thread pool
            # such as interpreter shutdown, handle the task in this thread
            _logger.debug(
                f"Failed to submit task to worker thread pool. Error: {e}",
                exc_info=True,
            )
            _handle(task)

    def activate(self) -> None:
        """Activate the async queue to accept and handle incoming tasks."""
        with self._lock:
            if self._is_active:
                return

            self._set_up_threads()

            # Callback to ensure remaining tasks are processed before program exit
            if not self._atexit_callback_registered:
                atexit.register(self._at_exit_callback)
                self._atexit_callback_registered = True

            self._is_active = True

    def is_active(self) -> bool:
        return self._is_active

    def _set_up_threads(self) -> None:
        """Set up the consumer and worker threads."""
        with self._lock:
            self._worker_threadpool = ThreadPoolExecutor(
                max_workers=self._max_workers,
                thread_name_prefix="MlflowTraceLoggingWorker",
            )
            self._consumer_thread = threading.Thread(
                target=self._consumer_loop,
                name="MLflowTraceLoggingConsumer",
                daemon=True,
            )
            self._consumer_thread.start()

    def _at_exit_callback(self) -> None:
        """Callback function executed when the program is exiting."""
        try:
            _logger.info(
                "Flushing the async trace logging queue before program exit. "
                "This may take a while..."
            )
            self.flush(terminate=True)
        except Exception as e:
            _logger.error(f"Error while finishing trace export requests: {e}")

    def flush(self, terminate=False) -> None:
        """
        Flush the async logging queue.

        Args:
            terminate: If True, shut down the logging threads after flushing.
        """
        if not self.is_active():
            return

        self._stop_event.set()
        self._consumer_thread.join()

        # Wait for all tasks to be processed
        self._queue.join()

        self._worker_threadpool.shutdown(wait=True)
        self._is_active = False
        # Restart threads to listen to incoming requests after flushing, if not terminating
        if not terminate:
            self._stop_event.clear()
            self.activate()
        from mlflow import MlflowException

        if not self._is_activated:
            raise MlflowException("AsyncArtifactsLoggingQueue is not activated.")
        artifact = RunArtifact(
            filename=filename,
            artifact_path=artifact_path,
            artifact=artifact,
            completion_event=threading.Event(),
        )
        self._queue.put(artifact)
        operation_future = self._artifact_status_check_threadpool.submit(
            self._wait_for_artifact, artifact
        )
        return RunOperations(operation_futures=[operation_future])

    def is_active(self) -> bool:
        return self._is_activated

    def _set_up_logging_thread(self) -> None:
        """Sets up the logging thread.

        If the logging thread is already set up, this method does nothing.
        """
        with self._lock:
            self._artifact_logging_thread = threading.Thread(
                target=self._logging_loop,
                name="MLflowAsyncArtifactsLoggingLoop",
                daemon=True,
            )
            self._artifact_logging_worker_threadpool = ThreadPoolExecutor(
                max_workers=5,
                thread_name_prefix="MLflowArtifactsLoggingWorkerPool",
            )

            self._artifact_status_check_threadpool = ThreadPoolExecutor(
                max_workers=5,
                thread_name_prefix="MLflowAsyncArtifactsLoggingStatusCheck",
            )
            self._artifact_logging_thread.start()

    def activate(self) -> None:
        """Activates the async logging queue

        1. Initializes queue draining thread.
        2. Initializes threads for checking the status of logged artifact.
        3. Registering an atexit callback to ensure that any remaining log data
            is flushed before the program exits.

        If the queue is already activated, this method does nothing.
        """
        with self._lock:
            if self._is_activated:
                return

            self._set_up_logging_thread()
            atexit.register(self._at_exit_callback)

            self._is_activated = True
mlflow/telemetry/client.py:36:        for thread in self._consumer_threads:
mlflow/telemetry/client.py:126:            for thread in self._consumer_threads:
```

## 原始行 71 · agent_message

```
The focused telemetry interfaces pass. The broader telemetry suite has 72 passing tests; its five failures are missing optional packages (`openai`/`pyspark`) or provider credentials, not telemetry behavior. I’m doing a final concurrency/shutdown review and running the other telemetry-specific integration test before wrapping up.
```

## 原始行 73 · command_execution

命令：
```
/bin/bash -lc 'python -m pytest tests/genai/evaluate/test_telemetry.py -q'
```

退出码：`5`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 0 items / 1 skipped

[33m============================== [33m[1m1 skipped[0m[33m in 0.02s[0m[33m ==============================[0m
```

## 原始行 77 · file_change

```
{
  "id": "item_53",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/telemetry/client.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import sys
from unittest import mock
from mlflow.telemetry.client import TelemetryClient
from mlflow.telemetry.schemas import Record, Status
from mlflow.version import VERSION

base = {
    'mlflow_version': VERSION,
    'disable_telemetry': False,
    'ingestion_url': 'http://example.test',
    'rollout_percentage': 100,
    'disable_events': ['blocked'],
    'disable_sdks': [],
    'disable_os': [],
}
with mock.patch('mlflow.telemetry.client.requests.get', return_value=mock.Mock(status_code=200, json=lambda: base)):
    client = TelemetryClient()
    client.activate()
    client._config_thread.join(1)
    assert client.config and client.is_active
    client._batch_size = 2
    record = Record('event', 1, status=Status.SUCCESS)
    with mock.patch('mlflow.telemetry.client.requests.post', return_value=mock.Mock(status_code=200)) as post:
        client.add_record(record)
        client.add_record(record)
        client.flush()
        assert post.call_count == 1
    client._clean_up()

with mock.patch('mlflow.telemetry.client.requests.get', side_effect=ConnectionError):
    client = TelemetryClient()
    client.activate()
    client._config_thread.join(1)
    assert client._is_config_fetched and client.config is None and client._is_stopped
    client._clean_up()
print('telemetry lifecycle smoke checks passed', sys.platform)
PY
python -m pytest tests/telemetry/test_utils.py tests/telemetry/test_track.py -q"
```

退出码：`0`

输出：
```
telemetry lifecycle smoke checks passed linux
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 10 items

tests/telemetry/test_utils.py [32m.[0m[32m.[0m[32m                                         [ 20%][0m
tests/telemetry/test_track.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                   [100%][0m

============================= slowest 10 durations =============================
4.00s call     tests/telemetry/test_track.py::test_is_telemetry_disabled_for_event
1.00s teardown tests/telemetry/test_track.py::test_record_usage_event
1.00s teardown tests/telemetry/test_track.py::test_record_usage_event_update_env_var_after_import
0.10s call     tests/telemetry/test_track.py::test_record_usage_event
0.10s call     tests/telemetry/test_track.py::test_record_usage_event_update_env_var_after_import
0.10s teardown tests/telemetry/test_track.py::test_backend_store_info
0.01s setup    tests/telemetry/test_utils.py::test_is_telemetry_disabled

(3 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                            | Duration | Tests | Min    | Max    | Avg    |
| ---- | ------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/telemetry/test_track.py` | 6.32s    | 8     | 0.002s | 4.005s | 0.790s |

::endgroup::

[32m============================== [32m[1m10 passed[0m[32m in 6.35s[0m[32m ==============================[0m
```

## 原始行 83 · command_execution

命令：
```
/bin/bash -lc "git diff --check; git status --short; git diff -- mlflow/telemetry/client.py mlflow/telemetry/track.py mlflow/telemetry/utils.py | sed -n '1,520p'"
```

退出码：`0`

输出：
```
 M mlflow/telemetry/client.py
 M mlflow/telemetry/track.py
 M mlflow/telemetry/utils.py
diff --git a/mlflow/telemetry/client.py b/mlflow/telemetry/client.py
index 92630f7..2b8d84c 100644
--- a/mlflow/telemetry/client.py
+++ b/mlflow/telemetry/client.py
@@ -20,150 +20,192 @@ from mlflow.telemetry.constant import (
     UNRECOVERABLE_ERRORS,
 )
 from mlflow.telemetry.schemas import Record, TelemetryConfig, TelemetryInfo, get_source_sdk
-from mlflow.telemetry.utils import _log_error, is_telemetry_disabled
+from mlflow.telemetry.utils import _get_config_url, _log_error, is_telemetry_disabled
 from mlflow.utils.logging_utils import should_suppress_logs_in_thread
+from mlflow.version import VERSION
 
 
 class TelemetryClient:
+    """A bounded, asynchronous client for MLflow usage telemetry."""
+
+    def __enter__(self):
+        return self
+
+    def __exit__(self, exc_type, exc_value, traceback):
+        self.flush(terminate=True)
+        for thread in self._consumer_threads:
+            if thread.is_alive():
+                thread.join(timeout=1)
+
+    def __init__(self):
+        session_id = _MLFLOW_TELEMETRY_SESSION_ID.get() or uuid.uuid4().hex
+        self.info = asdict(TelemetryInfo(session_id=session_id))
+        self.config: TelemetryConfig | None = None
+        self._is_config_fetched = False
+        self._is_active = False
+        self._is_stopped = False
+        self._queue: Queue[list[Record]] = Queue(maxsize=MAX_QUEUE_SIZE)
+        self._pending_records: list[Record] = []
+        self._batch_size = BATCH_SIZE
+        self._batch_time_interval = BATCH_TIME_INTERVAL_SECONDS
+        self._max_workers = MAX_WORKERS
+        self._last_batch_time = time.time()
+        self._batch_lock = threading.Lock()
+        self._activation_lock = threading.Lock()
+        self._consumer_threads: list[threading.Thread] = []
+        self._threads = self._consumer_threads
+        self._config_thread: threading.Thread | None = None
+        self._atexit_registered = False
+
+    def _at_exit_callback(self) -> None:
+        try:
+            with warnings.catch_warnings():
+                warnings.simplefilter("ignore")
+                should_suppress_logs_in_thread.set(True)
+                self.flush(terminate=True)
+        except Exception as e:
+            _log_error(f"Failed to clean up telemetry client: {e}")
 
+    def _get_config(self):
+        try:
+            config_url = _get_config_url(VERSION)
+            if config_url is None:
+                return
+            response = requests.get(config_url, timeout=1)
+            if response.status_code != 200:
+                return
+            config = response.json()
+            if config.get("mlflow_version") != VERSION:
+                return
+            if config.get("disable_telemetry", False):
+                return
+            ingestion_url = config.get("ingestion_url")
+            if not ingestion_url:
+                return
+            source_sdk = get_source_sdk()
+            source_sdk = getattr(source_sdk, "value", source_sdk)
+            if source_sdk in config.get("disable_sdks", []):
+                return
+            if sys.platform in config.get("disable_os", []):
+                return
+            rollout_percentage = config.get("rollout_percentage", 100)
+            if not isinstance(rollout_percentage, (int, float)):
+                return
+            if rollout_percentage <= 0 or random.random() * 100 > rollout_percentage:
+                return
+            self.config = TelemetryConfig(
+                ingestion_url=ingestion_url,
+                disable_events=set(config.get("disable_events", [])),
+            )
+        except (requests.exceptions.RequestException, ConnectionError, TimeoutError):
+            return
+        except Exception as e:
+            _log_error(f"Failed to fetch telemetry config: {e}")
 
+    def _fetch_config(self) -> None:
+        try:
+            self._get_config()
+        finally:
+            self._is_config_fetched = True
+            if self.config is None:
+                self._is_stopped = True
+                self.is_active = False
+                _set_telemetry_client(None)
 
+    def activate(self) -> None:
+        with self._activation_lock:
+            if self.is_active or self._is_stopped:
+                return
+            self.is_active = True
+            self._consumer_threads.extend(
+                threading.Thread(
+                    target=self._consumer,
+                    name=f"mlflow-telemetry-consumer-{index}",
+                    daemon=True,
+                )
+                for index in range(self._max_workers)
+            )
+            for thread in self._consumer_threads:
+                thread.start()
+            self._config_thread = threading.Thread(
+                target=self._fetch_config,
+                name="mlflow-telemetry-config",
+                daemon=True,
+            )
+            self._config_thread.start()
+            atexit.register(self._at_exit_callback)
+            self._atexit_registered = True
+
+    def add_record(self, record: Record):
+        if self._is_stopped:
+            return
+        if not self.is_active:
+            self.activate()
+        if self._is_stopped:
+            return
+        with self._batch_lock:
+            if self._is_stopped:
+                return
+            self._pending_records.append(record)
+            if len(self._pending_records) >= self._batch_size:
+                self._send_batch()
+
+    def _send_batch(self) -> None:
+        """Enqueue the current batch, retaining it when the queue is full."""
+        if not self._pending_records:
+            return
+        try:
+            self._queue.put_nowait(self._pending_records)
+            self._pending_records = []
+            self._last_batch_time = time.time()
+        except Full:
+            _log_error("Failed to add telemetry records to queue: the queue is full")
+
+    def flush(self, terminate=False) -> None:
+        if not self.is_active:
+            return
+        if terminate:
+            self._is_stopped = True
+            self.is_active = False
+            return
+        if self._config_thread is not None and self._config_thread.is_alive():
+            self._config_thread.join(timeout=1)
+        if self.config is not None and not self._is_stopped:
+            with self._batch_lock:
+                self._send_batch()
+        try:
+            self._queue.join()
+        except Exception as e:
+            _log_error(f"Failed to flush telemetry records: {e}")
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+    def _clean_up(self) -> None:
+        self.__exit__(None, None, None)
+        if self._atexit_registered:
+            try:
+                atexit.unregister(self._at_exit_callback)
+            except Exception:
+                pass
+            self._atexit_registered = False
 
     def _process_records(self, records: list[Record], request_timeout: float = 1):
         """Process a batch of telemetry records."""
         try:
+            if self._is_stopped:
+                return
             self._update_backend_store()
             if self.info["tracking_uri_scheme"] in ["databricks", "databricks-uc", "uc"]:
                 self._is_stopped = True
-                # set config to None to allow consumer thread drop records in the queue
                 self.config = None
                 self.is_active = False
                 _set_telemetry_client(None)
                 return
-
             records = [
                 {
                     "data": self.info | record.to_dict(),
-                    # use random uuid as partition key to make sure records are
-                    # distributed evenly across shards
                     "partition-key": uuid.uuid4().hex,
                 }
                 for record in records
             ]
-            # changing this value can affect total time for processing records
-            # the total time = request_timeout * max_attempts + sleep_time * (max_attempts - 1)
             max_attempts = 3
             sleep_time = 1
             for i in range(max_attempts):
@@ -177,22 +219,20 @@ class TelemetryClient:
                         timeout=request_timeout,
                     )
                     should_retry = response.status_code in RETRYABLE_ERRORS
-                except (ConnectionError, TimeoutError):
+                except (
+                    requests.exceptions.ConnectionError,
+                    requests.exceptions.Timeout,
+                    ConnectionError,
+                    TimeoutError,
+                ):
                     should_retry = True
-                # NB: DO NOT retry when terminating
-                # otherwise this increases shutdown overhead significantly
                 if self._is_stopped:
                     return
                 if i < max_attempts - 1 and should_retry:
-                    # we do not use exponential backoff to avoid increasing
-                    # the processing time significantly
                     time.sleep(sleep_time)
-                elif response and response.status_code in UNRECOVERABLE_ERRORS:
+                elif response is not None and response.status_code in UNRECOVERABLE_ERRORS:
                     self._is_stopped = True
                     self.is_active = False
-                    # this is executed in the consumer thread, so
-                    # we cannot join the thread here, but this should
-                    # be enough to stop the telemetry collection
                     return
                 else:
                     return
@@ -200,58 +240,30 @@ class TelemetryClient:
             _log_error(f"Failed to send telemetry records: {e}")
 
     def _consumer(self) -> None:
-        """Individual consumer that processes records from the queue."""
-        # suppress logs in the consumer thread to avoid emitting any irrelevant
-        # logs during telemetry collection.
+        """Consume and deliver batches until configuration fails or shutdown begins."""
         should_suppress_logs_in_thread.set(True)
-
-        while not self._is_config_fetched:
+        while not self._is_config_fetched and not self._is_stopped:
             time.sleep(0.1)
-
-        while self.config and not self._is_stopped:
+        while self.config is not None and not self._is_stopped:
             try:
                 records = self._queue.get(timeout=1)
             except Empty:
-                # check if batch time interval has passed and send data if needed
                 if time.time() - self._last_batch_time >= self._batch_time_interval:
-                    self._last_batch_time = time.time()
                     with self._batch_lock:
                         if self._pending_records:
                             self._send_batch()
                 continue
-
-            self._process_records(records)
-            self._queue.task_done()
-
-        # clear the queue if config is None
-        while self.config is None and not self._queue.empty():
+            try:
+                if not self._is_stopped:
+                    self._process_records(records)
+            finally:
+                self._queue.task_done()
+        while not self._queue.empty():
             try:
                 self._queue.get_nowait()
                 self._queue.task_done()
             except Empty:
                 break
-        # drop remaining records when terminating to avoid
-        # causing any overhead
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
 
     @property
     def is_active(self) -> bool:
@@ -261,66 +273,9 @@ class TelemetryClient:
     def is_active(self, value: bool) -> None:
         self._is_active = value
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
     def _update_backend_store(self):
-        """
-        Backend store might be changed after mlflow is imported, we should use this
-        method to update the backend store info at sending telemetry step.
-        """
+        """Update backend information because the tracking URI can change after import."""
         try:
-            # import here to avoid circular import
             from mlflow.tracking._tracking_service.utils import _get_tracking_scheme
 
             self.info["tracking_uri_scheme"] = _get_tracking_scheme()
@@ -328,21 +283,12 @@ class TelemetryClient:
             _log_error(f"Failed to update backend store: {e}")
 
 
-
-
-
-
-
-
-
 _MLFLOW_TELEMETRY_CLIENT = None
 _client_lock = threading.Lock()
 
 
 def set_telemetry_client():
     if is_telemetry_disabled():
-        # set to None again so this function can be used to
-        # re-initialize the telemetry client
         _set_telemetry_client(None)
     else:
         try:
@@ -364,4 +310,4 @@ def _set_telemetry_client(value: TelemetryClient | None):
 
 def get_telemetry_client() -> TelemetryClient | None:
     with _client_lock:
-        return _MLFLOW_TELEMETRY_CLIENT
\ No newline at end of file
+        return _MLFLOW_TELEMETRY_CLIENT
diff --git a/mlflow/telemetry/track.py b/mlflow/telemetry/track.py
index 1482c07..88fa52c 100644
--- a/mlflow/telemetry/track.py
+++ b/mlflow/telemetry/track.py
@@ -16,6 +16,21 @@ R = TypeVar("R")
 _logger = logging.getLogger(__name__)
 
 
+def _is_telemetry_disabled_for_event(event: type[Event]) -> bool:
+    try:
```

## 原始行 86 · file_change

```
{
  "id": "item_59",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/telemetry/client.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 90 · command_execution

命令：
```
/bin/bash -lc 'python -m compileall -q mlflow/telemetry && git diff --check && python -m pytest tests/telemetry/test_utils.py tests/telemetry/test_track.py -q'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 10 items

tests/telemetry/test_utils.py [32m.[0m[32m.[0m[32m                                         [ 20%][0m
tests/telemetry/test_track.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                   [100%][0m

============================= slowest 10 durations =============================
4.00s call     tests/telemetry/test_track.py::test_is_telemetry_disabled_for_event
1.00s teardown tests/telemetry/test_track.py::test_record_usage_event
1.00s teardown tests/telemetry/test_track.py::test_record_usage_event_update_env_var_after_import
0.10s call     tests/telemetry/test_track.py::test_record_usage_event
0.10s call     tests/telemetry/test_track.py::test_record_usage_event_update_env_var_after_import
0.10s teardown tests/telemetry/test_track.py::test_backend_store_info

(4 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                            | Duration | Tests | Min    | Max    | Avg    |
| ---- | ------------------------------- | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/telemetry/test_track.py` | 6.32s    | 8     | 0.002s | 4.005s | 0.790s |

::endgroup::

[32m============================== [32m[1m10 passed[0m[32m in 6.34s[0m[32m ==============================[0m
```

## 原始行 92 · agent_message

```
Implemented the telemetry system across:

- [client.py](/testbed/mlflow/telemetry/client.py)
- [track.py](/testbed/mlflow/telemetry/track.py)
- [utils.py](/testbed/mlflow/telemetry/utils.py)

Key functionality includes thread-safe batching, asynchronous transmission, retries, lazy configuration, event filtering, context-manager cleanup, and fast terminating flushes.

Validation:

- Focused telemetry tests: **10 passed**
- Broader telemetry suite: **72 passed, 5 unrelated failures** caused by unavailable optional `openai`/`pyspark` dependencies and provider credentials.
- Compilation and `git diff --check`: passed.
```
