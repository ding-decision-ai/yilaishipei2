# Codex baseline: mlflow__mlflow.93dab383.test_genai_eval_utils.2d5441f2.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 3 · agent_message

```
I’ll inspect the target module, its related models/APIs, and the visible tests first, then implement the three interfaces and run focused tests.
```

## 原始行 5 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,260p' mlflow/cli/genai_eval_utils.py && rg -n \"extract_assessments_from_results|format_table_output|resolve_scorers|class EvalResult|class TableOutput|class Assessment\" . --glob '"'!tests/**/.pytest_cache/**'"'"
```

退出码：`127`

输出：
```
"""
Utility functions for trace evaluation output formatting.
"""

from dataclasses import dataclass
from typing import Any

import click
import pandas as pd

from mlflow.exceptions import MlflowException
from mlflow.genai.scorers import Scorer, get_all_scorers, get_scorer
from mlflow.tracing.constant import AssessmentMetadataKey

# Represents the absence of a value for an assessment
NA_VALUE = "N/A"


@dataclass
class Assessment:
    """
    Structured assessment data for a trace evaluation.
    """

    name: str | None
    """The name of the assessment"""

    result: Any | None = None
    """The result value from the assessment"""

    rationale: str | None = None
    """The rationale text explaining the assessment"""

    error: str | None = None
    """Error message if the assessment failed"""


@dataclass
class Cell:
    """
    Structured cell data for table display with metadata.
    """

    value: str
    """The formatted display value for the cell"""

    assessment: Assessment | None = None
    """The assessment data for this cell, if it represents an assessment"""


@dataclass
class EvalResult:
    """
    Container for evaluation results for a single trace.

    This dataclass provides structured access to trace evaluation data,
    replacing dict-based access for better type safety.
    """

    trace_id: str
    """The trace ID"""

    assessments: list[Assessment]
    """List of Assessment objects for this trace"""


@dataclass
class TableOutput:
    """Container for formatted table data."""

    headers: list[str]
    rows: list[list[Cell]]


def _format_assessment_cell(assessment: Assessment | None) -> Cell:
    """
    Format a single assessment cell for table display.

    Args:
        assessment: Assessment object with result, rationale, and error fields

    Returns:
        Cell object with formatted value and assessment metadata
    """
    if not assessment:
        return Cell(value=NA_VALUE)

    if assessment.error:
        display_value = f"error: {assessment.error}"
    elif assessment.result is not None and assessment.rationale:
        display_value = f"value: {assessment.result}, rationale: {assessment.rationale}"
    elif assessment.result is not None:
        display_value = f"value: {assessment.result}"
    elif assessment.rationale:
        display_value = f"rationale: {assessment.rationale}"
    else:
        display_value = NA_VALUE

    return Cell(value=display_value, assessment=assessment)
























/bin/bash: line 1: rg: command not found
```

## 原始行 7 · agent_message

```
The target types and cell formatter already exist; the three public functions are absent. Since `rg` is unavailable here, I’m using scoped `find`/`grep` searches within `/testbed` only.
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"extract_assessments_from_results|format_table_output|resolve_scorers|genai_eval_utils\" tests mlflow 2>/dev/null | head -300
sed -n '1,260p' mlflow/genai/scorers/__init__.py
grep -R -n \"def get_all_scorers\\|def get_scorer\\|class .*Scorer\" mlflow/genai/scorers mlflow | head -200
grep -R -n \"SOURCE_RUN_ID\" tests mlflow | head -200"
```

退出码：`0`

输出：
```
mlflow/cli/eval.py:12:from mlflow.cli.genai_eval_utils import (
mlflow/cli/eval.py:13:    extract_assessments_from_results,
mlflow/cli/eval.py:14:    format_table_output,
mlflow/cli/eval.py:15:    resolve_scorers,
mlflow/cli/eval.py:82:    resolved_scorers = resolve_scorers(scorer_names, experiment_id)
mlflow/cli/eval.py:99:    output_data = extract_assessments_from_results(results_df, evaluation_run_id)
mlflow/cli/eval.py:123:        table_output = format_table_output(output_data)
from typing import TYPE_CHECKING

from mlflow.genai.scorers.base import Scorer, ScorerSamplingConfig, scorer
from mlflow.genai.scorers.registry import delete_scorer, get_scorer, list_scorers

# NB: We use lazy imports for builtin_scorers to avoid a circular dependency issue.
#
# The circular dependency chain:
# 1. scorers/__init__.py imports from builtin_scorers (if done eagerly)
# 2. builtin_scorers.py has `class BuiltInScorer(Judge)` which imports Judge from judges.base
# 3. judges.base.py has `class Judge(Scorer)` which imports Scorer from scorers.base
# 4. When importing scorers.base, Python first initializes the scorers package (__init__.py)
# 5. This would try to import builtin_scorers, creating a circular import
#
# Solution:
# - We use Python's __getattr__ mechanism to defer the import of builtin_scorers until
#   the specific scorer classes are actually accessed at runtime
# - The TYPE_CHECKING block provides type hints for IDEs and static analysis tools
#   without actually importing the modules at runtime (TYPE_CHECKING is only True
#   during static analysis, never during actual execution)
# - This allows Sphinx autodoc and IDEs to understand the module structure while
#   avoiding the circular import at runtime


# Define the attributes that should be lazily loaded
_LAZY_IMPORTS = {
    "Correctness",
    "ExpectationsGuidelines",
    "Guidelines",
    "Equivalence",
    "RelevanceToQuery",
    "RetrievalGroundedness",
    "RetrievalRelevance",
    "RetrievalSufficiency",
    "Safety",
    "get_all_scorers",
}


def __getattr__(name):
    """Lazily import builtin scorers to avoid circular dependency."""
    if name in _LAZY_IMPORTS:
        # Import the module when first accessed
        from mlflow.genai.scorers import builtin_scorers

        return getattr(builtin_scorers, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


def __dir__():
    """Return the list of attributes available in this module.

    This is necessary for Sphinx autodoc and other introspection tools
    to discover the lazily-loaded scorer classes.
    """
    # Get the default module attributes
    module_attrs = list(globals().keys())
    # Add the lazy imports
    return sorted(set(module_attrs) | _LAZY_IMPORTS)


# The TYPE_CHECKING block below is for static analysis tools only.
# TYPE_CHECKING is False at runtime, so these imports never execute during normal operation.
# This gives us the best of both worlds: type hints without circular imports.
if TYPE_CHECKING:
    from mlflow.genai.scorers.builtin_scorers import (
        Correctness,
        Equivalence,
        ExpectationsGuidelines,
        Guidelines,
        RelevanceToQuery,
        RetrievalGroundedness,
        RetrievalRelevance,
        RetrievalSufficiency,
        Safety,
        get_all_scorers,
    )

__all__ = [
    "Correctness",
    "ExpectationsGuidelines",
    "Guidelines",
    "Equivalence",
    "RelevanceToQuery",
    "RetrievalGroundedness",
    "RetrievalRelevance",
    "RetrievalSufficiency",
    "Safety",
    "Scorer",
    "scorer",
    "ScorerSamplingConfig",
    "get_all_scorers",
    "get_scorer",
    "list_scorers",
    "delete_scorer",
]
mlflow/genai/scorers/base.py:29:class ScorerKind(Enum):
mlflow/genai/scorers/base.py:38:class ScorerStatus(Enum):
mlflow/genai/scorers/base.py:51:class ScorerSamplingConfig:
mlflow/genai/scorers/base.py:62:class SerializedScorer:
mlflow/genai/scorers/base.py:64:    Dataclass defining the serialization schema for Scorer objects.
mlflow/genai/scorers/base.py:111:class Scorer(BaseModel):
mlflow/genai/scorers/base.py:493:                class NotEmpty(BaseScorer):
mlflow/genai/scorers/base.py:500:                class ExactMatch(BaseScorer):
mlflow/genai/scorers/base.py:507:                class NumToolCalls(BaseScorer):
mlflow/genai/scorers/base.py:999:    class CustomScorer(Scorer):
mlflow/genai/scorers/builtin_scorers.py:259:class BuiltInScorer(Judge):
mlflow/genai/scorers/builtin_scorers.py:335:class RetrievalRelevance(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:464:class RetrievalSufficiency(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:590:class RetrievalGroundedness(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:685:class Guidelines(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:826:class ExpectationsGuidelines(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:980:class RelevanceToQuery(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1094:class Safety(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1196:class Correctness(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1380:class Equivalence(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1567:def get_all_scorers() -> list[BuiltInScorer]:
mlflow/genai/scorers/registry.py:21:class UnsupportedScorerStoreURIException(MlflowException):
mlflow/genai/scorers/registry.py:34:class AbstractScorerStore(metaclass=ABCMeta):
mlflow/genai/scorers/registry.py:68:    def get_scorer(self, experiment_id, name, version=None) -> "Scorer":
mlflow/genai/scorers/registry.py:116:class ScorerStoreRegistry:
mlflow/genai/scorers/registry.py:182:class MlflowTrackingStore(AbstractScorerStore):
mlflow/genai/scorers/registry.py:212:    def get_scorer(self, experiment_id, name, version=None) -> "Scorer":
mlflow/genai/scorers/registry.py:252:class DatabricksStore(AbstractScorerStore):
mlflow/genai/scorers/registry.py:378:    def get_scorer(self, experiment_id, name, version=None) -> "Scorer":
mlflow/genai/scorers/registry.py:518:def get_scorer(
mlflow/genai/scorers/__init__.py:10:# 2. builtin_scorers.py has `class BuiltInScorer(Judge)` which imports Judge from judges.base
mlflow/genai/scorers/__init__.py:11:# 3. judges.base.py has `class Judge(Scorer)` which imports Scorer from scorers.base
mlflow/genai/scheduled_scorers.py:14:class ScorerScheduleConfig:
mlflow/genai/judges/base.py:53:class Judge(Scorer):
mlflow/genai/judges/builtin_judges.py:7:class BuiltinJudge(BuiltInScorer, Judge):
mlflow/genai/scorers/base.py:29:class ScorerKind(Enum):
mlflow/genai/scorers/base.py:38:class ScorerStatus(Enum):
mlflow/genai/scorers/base.py:51:class ScorerSamplingConfig:
mlflow/genai/scorers/base.py:62:class SerializedScorer:
mlflow/genai/scorers/base.py:64:    Dataclass defining the serialization schema for Scorer objects.
mlflow/genai/scorers/base.py:111:class Scorer(BaseModel):
mlflow/genai/scorers/base.py:493:                class NotEmpty(BaseScorer):
mlflow/genai/scorers/base.py:500:                class ExactMatch(BaseScorer):
mlflow/genai/scorers/base.py:507:                class NumToolCalls(BaseScorer):
mlflow/genai/scorers/base.py:999:    class CustomScorer(Scorer):
mlflow/genai/scorers/builtin_scorers.py:259:class BuiltInScorer(Judge):
mlflow/genai/scorers/builtin_scorers.py:335:class RetrievalRelevance(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:464:class RetrievalSufficiency(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:590:class RetrievalGroundedness(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:685:class Guidelines(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:826:class ExpectationsGuidelines(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:980:class RelevanceToQuery(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1094:class Safety(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1196:class Correctness(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1380:class Equivalence(BuiltInScorer):
mlflow/genai/scorers/builtin_scorers.py:1567:def get_all_scorers() -> list[BuiltInScorer]:
mlflow/genai/scorers/registry.py:21:class UnsupportedScorerStoreURIException(MlflowException):
mlflow/genai/scorers/registry.py:34:class AbstractScorerStore(metaclass=ABCMeta):
mlflow/genai/scorers/registry.py:68:    def get_scorer(self, experiment_id, name, version=None) -> "Scorer":
mlflow/genai/scorers/registry.py:116:class ScorerStoreRegistry:
mlflow/genai/scorers/registry.py:182:class MlflowTrackingStore(AbstractScorerStore):
mlflow/genai/scorers/registry.py:212:    def get_scorer(self, experiment_id, name, version=None) -> "Scorer":
mlflow/genai/scorers/registry.py:252:class DatabricksStore(AbstractScorerStore):
mlflow/genai/scorers/registry.py:378:    def get_scorer(self, experiment_id, name, version=None) -> "Scorer":
mlflow/genai/scorers/registry.py:518:def get_scorer(
mlflow/genai/scorers/__init__.py:10:# 2. builtin_scorers.py has `class BuiltInScorer(Judge)` which imports Judge from judges.base
mlflow/genai/scorers/__init__.py:11:# 3. judges.base.py has `class Judge(Scorer)` which imports Scorer from scorers.base
mlflow/protos/service_pb2.pyi:1523:class RegisterScorer(_message.Message):
mlflow/protos/service_pb2.pyi:1548:class ListScorers(_message.Message):
mlflow/protos/service_pb2.pyi:1559:class ListScorerVersions(_message.Message):
mlflow/protos/service_pb2.pyi:1572:class GetScorer(_message.Message):
mlflow/protos/service_pb2.pyi:1587:class DeleteScorer(_message.Message):
mlflow/protos/service_pb2.pyi:1600:class Scorer(_message.Message):
mlflow/entities/scorer.py:8:class ScorerVersion(_MlflowObject):
mlflow/entities/scorer.py:147:        This class method is used internally by MLflow to reconstruct ScorerVersion
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:176113:  public static final class RegisterScorer extends
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:178784:  public static final class ListScorers extends
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:180380:  public static final class ListScorerVersions extends
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:182196:  public static final class GetScorer extends
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:183911:  public static final class DeleteScorer extends
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:185427:  public static final class Scorer extends
mlflow/store/tracking/sqlalchemy_store.py:2146:    def get_scorer(self, experiment_id, name, version=None) -> ScorerVersion:
mlflow/store/tracking/abstract_store.py:1317:    def get_scorer(self, experiment_id, name, version=None) -> ScorerVersion:
mlflow/store/tracking/rest_store.py:1230:    def get_scorer(
mlflow/store/tracking/dbmodels/models.py:1845:class SqlScorer(Base):
mlflow/store/tracking/dbmodels/models.py:1886:class SqlScorerVersion(Base):
tests/genai/evaluate/test_evaluation.py:99:        assert a_exact_match.metadata[AssessmentMetadataKey.SOURCE_RUN_ID] is not None
tests/genai/evaluate/test_evaluation.py:104:        assert a_is_concise.metadata[AssessmentMetadataKey.SOURCE_RUN_ID] is not None
tests/genai/evaluate/test_evaluation.py:109:        assert a_has_trace.metadata[AssessmentMetadataKey.SOURCE_RUN_ID] is not None
tests/genai/evaluate/test_evaluation.py:117:        assert a_relevance.metadata[AssessmentMetadataKey.SOURCE_RUN_ID] is not None
tests/genai/evaluate/test_evaluation.py:124:        assert a_expected_response.metadata[AssessmentMetadataKey.SOURCE_RUN_ID] is not None
tests/genai/evaluate/test_evaluation.py:130:        assert a_max_length.metadata[AssessmentMetadataKey.SOURCE_RUN_ID] is not None
tests/entities/test_assessment.py:420:        ({AssessmentMetadataKey.SOURCE_RUN_ID: "run123"}, None, "run123"),
mlflow/tracing/constant.py:81:    SOURCE_RUN_ID = "mlflow.assessment.sourceRunId"
mlflow/genai/utils/trace_utils.py:541:            (source_run_id := a.get("metadata", {}).get(AssessmentMetadataKey.SOURCE_RUN_ID))
mlflow/genai/evaluation/harness.py:278:                AssessmentMetadataKey.SOURCE_RUN_ID: run_id,
mlflow/server/js/src/shared/web-shared/model-trace-explorer/constants.ts:7:export const MLFLOW_ASSESSMENT_SOURCE_RUN_ID = 'mlflow.assessment.sourceRunId';
mlflow/server/js/src/shared/web-shared/genai-traces-table/utils/TraceUtils.ts:14:  MLFLOW_ASSESSMENT_SOURCE_RUN_ID,
mlflow/server/js/src/shared/web-shared/genai-traces-table/utils/TraceUtils.ts:97:      const sourceRunId = assessment.metadata?.[MLFLOW_ASSESSMENT_SOURCE_RUN_ID];
mlflow/server/js/src/experiment-tracking/pages/prompts/api.ts:4:import { IS_PROMPT_TAG_NAME, IS_PROMPT_TAG_VALUE, REGISTERED_PROMPT_SOURCE_RUN_IDS } from './utils';
mlflow/server/js/src/experiment-tracking/pages/prompts/api.ts:157:      `tags.\`${IS_PROMPT_TAG_NAME}\` = '${IS_PROMPT_TAG_VALUE}' AND tags.\`${REGISTERED_PROMPT_SOURCE_RUN_IDS}\` ILIKE "%${runUuid}%"`,
mlflow/server/js/src/experiment-tracking/pages/prompts/test-utils.ts:3:import { REGISTERED_PROMPT_CONTENT_TAG_KEY, REGISTERED_PROMPT_SOURCE_RUN_ID } from './utils';
mlflow/server/js/src/experiment-tracking/pages/prompts/components/PromptVersionMetadata.tsx:9:import { REGISTERED_PROMPT_SOURCE_RUN_IDS } from '../utils';
mlflow/server/js/src/experiment-tracking/pages/prompts/components/PromptVersionMetadata.tsx:38:    const tagValue = registeredPromptVersion?.tags?.find((tag) => tag.key === REGISTERED_PROMPT_SOURCE_RUN_IDS)?.value;
mlflow/server/js/src/experiment-tracking/pages/prompts/utils.ts:8:export const REGISTERED_PROMPT_SOURCE_RUN_ID = 'mlflow.prompt.run_id';
mlflow/server/js/src/experiment-tracking/pages/prompts/utils.ts:10:export const REGISTERED_PROMPT_SOURCE_RUN_IDS = 'mlflow.prompt.run_ids';
mlflow/protos/service_pb2.pyi:1128:    SOURCE_RUN_ID_FIELD_NUMBER: _ClassVar[int]
mlflow/protos/service_pb2.pyi:1286:    SOURCE_RUN_ID_FIELD_NUMBER: _ClassVar[int]
mlflow/entities/assessment.py:113:            and AssessmentMetadataKey.SOURCE_RUN_ID in self.metadata
mlflow/entities/assessment.py:115:            self.run_id = self.metadata[AssessmentMetadataKey.SOURCE_RUN_ID]
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:126145:    public static final int SOURCE_RUN_ID_FIELD_NUMBER = 4;
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:126449:        hash = (37 * hash) + SOURCE_RUN_ID_FIELD_NUMBER;
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:146710:    public static final int SOURCE_RUN_ID_FIELD_NUMBER = 10;
mlflow/java/client/src/main/java/org/mlflow/api/proto/Service.java:147186:        hash = (37 * hash) + SOURCE_RUN_ID_FIELD_NUMBER;
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,210p' mlflow/cli/eval.py
sed -n '1540,1605p' mlflow/genai/scorers/builtin_scorers.py
sed -n '500,570p' mlflow/genai/scorers/registry.py
grep -R -n -E \"camel.*snake|snake.*case|class_name\" mlflow/utils mlflow | head -120
find tests -type f -iname '*eval*utils*' -o -iname '*cli*eval*' | sort"
```

退出码：`0`

输出：
```
"""
CLI commands for evaluating traces with scorers.
"""

import json
from typing import Literal

import click
import pandas as pd

import mlflow
from mlflow.cli.genai_eval_utils import (
    extract_assessments_from_results,
    format_table_output,
    resolve_scorers,
)
from mlflow.entities import Trace
from mlflow.genai.evaluation import evaluate
from mlflow.tracking import MlflowClient
from mlflow.utils.string_utils import _create_table


def _gather_traces(trace_ids: str, experiment_id: str) -> list[Trace]:
    """
    Gather and validate traces from the tracking store.

    Args:
        trace_ids: Comma-separated list of trace IDs to gather
        experiment_id: Expected experiment ID for all traces

    Returns:
        List of Trace objects

    Raises:
        click.UsageError: If any trace is not found or belongs to wrong experiment
    """
    trace_id_list = [tid.strip() for tid in trace_ids.split(",")]
    client = MlflowClient()
    traces = []

    for trace_id in trace_id_list:
        try:
            trace = client.get_trace(trace_id, display=False)
        except Exception as e:
            raise click.UsageError(f"Failed to get trace '{trace_id}': {e}")

        if trace is None:
            raise click.UsageError(f"Trace with ID '{trace_id}' not found")

        if trace.info.experiment_id != experiment_id:
            raise click.UsageError(
                f"Trace '{trace_id}' belongs to experiment '{trace.info.experiment_id}', "
                f"not the specified experiment '{experiment_id}'"
            )

        traces.append(trace)

    return traces


def evaluate_traces(
    experiment_id: str,
    trace_ids: str,
    scorers: str,
    output_format: Literal["table", "json"] = "table",
) -> None:
    """
    Evaluate traces with specified scorers and output results.

    Args:
        experiment_id: The experiment ID to use for evaluation
        trace_ids: Comma-separated list of trace IDs to evaluate
        scorers: Comma-separated list of scorer names
        output_format: Output format ('table' or 'json')
    """
    mlflow.set_experiment(experiment_id=experiment_id)

    traces = _gather_traces(trace_ids, experiment_id)
    traces_df = pd.DataFrame([{"trace_id": t.info.trace_id, "trace": t} for t in traces])

    scorer_names = [name.strip() for name in scorers.split(",")]
    resolved_scorers = resolve_scorers(scorer_names, experiment_id)

    trace_count = len(traces)
    scorers_list = ", ".join(scorer_names)
    if trace_count == 1:
        trace_id = traces[0].info.trace_id
        click.echo(f"Evaluating trace {trace_id} with scorers: {scorers_list}...")
    else:
        click.echo(f"Evaluating {trace_count} traces with scorers: {scorers_list}...")

    try:
        results = evaluate(data=traces_df, scorers=resolved_scorers)
        evaluation_run_id = results.run_id
    except Exception as e:
        raise click.UsageError(f"Evaluation failed: {e}")

    results_df = results.tables["eval_results"]
    output_data = extract_assessments_from_results(results_df, evaluation_run_id)

    if output_format == "json":
        # Convert EvalResult objects to dicts for JSON serialization
        json_data = [
            {
                "trace_id": result.trace_id,
                "assessments": [
                    {
                        "name": assessment.name,
                        "result": assessment.result,
                        "rationale": assessment.rationale,
                        "error": assessment.error,
                    }
                    for assessment in result.assessments
                ],
            }
            for result in output_data
        ]
        if len(json_data) == 1:
            click.echo(json.dumps(json_data[0], indent=2))
        else:
            click.echo(json.dumps(json_data, indent=2))
    else:
        table_output = format_table_output(output_data)
        # Extract string values from Cell objects for table display
        table_data = [[cell.value for cell in row] for row in table_output.rows]
        # Add new line in the output before the final result.
        click.echo("")
        click.echo(_create_table(table_data, headers=table_output.headers))

        # Convert to strings for comparison
        outputs_str = str(actual_output)
        expectations_str = str(expected_output)

        # Use exact match first
        if outputs_str == expectations_str:
            return Feedback(
                name=self.name,
                value=CategoricalRating.YES,
                rationale="Exact string match",
            )

        # Use LLM judge for semantic equivalence

        model = self.model or get_default_model()
        assessment_name = self.name or EQUIVALENCE_FEEDBACK_NAME

        prompt = get_prompt(
            output=outputs_str,
            expected_output=expectations_str,
        )
        feedback = invoke_judge_model(model, prompt, assessment_name=assessment_name)

        return _sanitize_feedback(feedback)


def get_all_scorers() -> list[BuiltInScorer]:
    """
    Returns a list of all built-in scorers.

    Example:

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import get_all_scorers

        data = [
            {
                "inputs": {"question": "What is the capital of France?"},
                "outputs": "The capital of France is Paris.",
                "expectations": {"expected_response": "Paris is the capital city of France."},
            }
        ]
        result = mlflow.genai.evaluate(data=data, scorers=get_all_scorers())
    """
    scorers = [
        ExpectationsGuidelines(),
        Correctness(),
        RelevanceToQuery(),
        RetrievalSufficiency(),
        RetrievalGroundedness(),
        Equivalence(),
    ]
    if is_databricks_uri(mlflow.get_tracking_uri()):
        scorers.extend([Safety(), RetrievalRelevance()])
    return scorers


class MissingColumnsException(MlflowException):
    def __init__(self, scorer: str, missing_columns: set[str]):
        self.scorer = scorer
        self.missing_columns = list(missing_columns)
        super().__init__(
            f"The following columns are required for the scorer {scorer}: {missing_columns}"
            :func:`mlflow.get_experiment_by_name` or :func:`mlflow.set_experiment`.

    Returns:
        list[tuple[Scorer, int | None]]: A list of tuples, where each tuple contains:
            - A Scorer object representing the scorer at that specific version
            - An integer representing the version number (1, 2, 3, etc.), for Databricks backend,
              the version number is `None`.
            The list may be empty if no versions of the scorer exist.

    Raises:
        mlflow.MlflowException: If the scorer with the specified name is not found in
            the experiment, if the experiment doesn't exist, or if there are issues with the backend
            store.
    """
    store = _get_scorer_store()
    return store.list_scorer_versions(experiment_id, name)


def get_scorer(
    *, name: str, experiment_id: str | None = None, version: int | None = None
) -> Scorer:
    """
    Retrieve a specific registered scorer by name and optional version.

    This function retrieves a single Scorer instance from the specified experiment. If no
    version is specified, it returns the latest (highest version number) scorer with the
    given name.

    Args:
        name (str): The name of the registered scorer to retrieve. This must match exactly
            with the name used during scorer registration.
        experiment_id (str, optional): The ID of the MLflow experiment containing the scorer.
            If None, uses the currently active experiment as determined by
            :func:`mlflow.get_experiment_by_name` or :func:`mlflow.set_experiment`.
        version (int, optional): The specific version of the scorer to retrieve. If None,
            returns the scorer with the highest version number (latest version).

    Returns:
        Scorer: A Scorer object representing the requested scorer.

    Raises:
        mlflow.MlflowException: If the scorer with the specified name is not found in the
            experiment, if the specified version doesn't exist, if the experiment doesn't exist,
            or if there are issues with the backend store connection.

    Example:
        .. code-block:: python

            from mlflow.genai.scorers import get_scorer

            # Get the latest version of a scorer
            latest_scorer = get_scorer(name="accuracy_scorer")

            # Get a specific version of a scorer
            v2_scorer = get_scorer(name="safety_scorer", version=2)

            # Get a scorer from a specific experiment
            scorer = get_scorer(name="relevance_scorer", experiment_id="123")

    Note:
        - When no version is specified, the function automatically returns the latest version
        - This function works with both OSS MLflow tracking backend and Databricks backend.
        - For Databricks backend, versioning is not supported, so the version parameter
          should be None.
    """

    store = _get_scorer_store()
    return store.get_scorer(experiment_id, name, version)


def delete_scorer(
mlflow/utils/proto_json_utils.py:113:    """Converts a message to JSON, using snake_case for field names."""
mlflow/utils/__init__.py:112:def _get_fully_qualified_class_name(obj):
mlflow/utils/class_utils.py:4:def _get_class_from_string(fully_qualified_class_name):
mlflow/utils/class_utils.py:5:    module, class_name = fully_qualified_class_name.rsplit(".", maxsplit=1)
mlflow/utils/class_utils.py:6:    return getattr(importlib.import_module(module), class_name)
mlflow/dspy/callback.py:22:from mlflow.utils import _get_fully_qualified_class_name
mlflow/dspy/callback.py:102:        if _get_fully_qualified_class_name(instance) == "dspy.retrieve.databricks_rm.DatabricksRM":
mlflow/langchain/databricks_dependencies.py:186:    object: Any, class_name: str, from_modules: list[str]
mlflow/langchain/databricks_dependencies.py:196:        class_name: The name of the class to check
mlflow/langchain/databricks_dependencies.py:206:                cls = getattr(module, class_name)
mlflow/langchain/utils/logging.py:202:    class_name_to_loader_arg = {
mlflow/langchain/utils/logging.py:210:        class_name_to_loader_arg["langchain_experimental.sql.SQLDatabaseChain"] = "database"
mlflow/langchain/utils/logging.py:220:    for class_name, loader_arg in class_name_to_loader_arg.items():
mlflow/langchain/utils/logging.py:222:            cls = _get_class_from_string(class_name)
mlflow/langchain/utils/logging.py:228:                class_name,
mlflow/langchain/utils/logging.py:239:    def try_adding_llm(module, class_name):
mlflow/langchain/utils/logging.py:240:        if cls := getattr(module, class_name, None):
mlflow/langchain/utils/logging.py:243:    def safe_import_and_add(module_name, class_name):
mlflow/langchain/utils/logging.py:247:            try_adding_llm(module, class_name)
mlflow/spark/__init__.py:43:from mlflow.utils import _get_fully_qualified_class_name, databricks_utils
mlflow/spark/__init__.py:594:        model_class=_get_fully_qualified_class_name(spark_model),
mlflow/metrics/genai/metric_definitions.py:65:    class_name = f"mlflow.metrics.genai.prompts.{metric_version}.AnswerSimilarityMetric"
mlflow/metrics/genai/metric_definitions.py:67:        answer_similarity_class_module = _get_class_from_string(class_name)
mlflow/metrics/genai/metric_definitions.py:158:    class_name = f"mlflow.metrics.genai.prompts.{metric_version}.AnswerCorrectnessMetric"
mlflow/metrics/genai/metric_definitions.py:160:        answer_correctness_class_module = _get_class_from_string(class_name)
mlflow/metrics/genai/metric_definitions.py:246:    class_name = f"mlflow.metrics.genai.prompts.{metric_version}.FaithfulnessMetric"
mlflow/metrics/genai/metric_definitions.py:248:        faithfulness_class_module = _get_class_from_string(class_name)
mlflow/metrics/genai/metric_definitions.py:331:    class_name = f"mlflow.metrics.genai.prompts.{metric_version}.AnswerRelevanceMetric"
mlflow/metrics/genai/metric_definitions.py:333:        answer_relevance_class_module = _get_class_from_string(class_name)
mlflow/metrics/genai/metric_definitions.py:421:    class_name = f"mlflow.metrics.genai.prompts.{metric_version}.RelevanceMetric"
mlflow/metrics/genai/metric_definitions.py:423:        relevance_class_module = _get_class_from_string(class_name)
mlflow/metrics/genai/genai_metric.py:542:    class_name = f"mlflow.metrics.genai.prompts.{version}.EvaluationModel"
mlflow/metrics/genai/genai_metric.py:544:        evaluation_model_class_module = _get_class_from_string(class_name)
mlflow/server/js/src/experiment-tracking/components/runs-charts/components/RunsCharts.stories-common.tsx:40:const animalNames = ["aardvark","albatross","alligator","alpaca","ant","anteater","antelope","ape","armadillo","donkey","baboon","badger","barracuda","bat","bear","beaver","bee","bison","boar","buffalo","butterfly","camel","capybara","caribou","cassowary","cat","caterpillar","cattle","chamois","cheetah","chicken","chimpanzee","chinchilla","chough","clam","cobra","cockroach","cod","cormorant","coyote","crab","crane","crocodile","crow","curlew","deer","dinosaur","dog","dogfish","dolphin","dotterel","dove","dragonfly","duck","dugong","dunlin","eagle","echidna","eel","eland","elephant","elk","emu","falcon","ferret","finch","fish","flamingo","fly","fox","frog","gaur","gazelle","gerbil","giraffe","gnat","gnu","goat","goldfinch","goldfish","goose","gorilla","goshawk","grasshopper","grouse","guanaco","gull","hamster","hare","hawk","hedgehog","heron","herring","hippopotamus","hornet","horse","human","hummingbird","hyena","ibex","ibis","jackal","jaguar","jay","jellyfish","kangaroo","kingfisher","koala","kookabura","kouprey","kudu","lapwing","lark","lemur","leopard","lion","llama","lobster","locust","loris","louse","lyrebird","magpie","mallard","manatee","mandrill","mantis","marten","meerkat","mink","mole","mongoose","monkey","moose","mosquito","mouse","mule","narwhal","newt","nightingale","octopus","okapi","opossum","oryx","ostrich","otter","owl","oyster","panther","parrot","partridge","peafowl","pelican","penguin","pheasant","pig","pigeon","pony","porcupine","porpoise","quail","quelea","quetzal","rabbit","raccoon","rail","ram","rat","raven","red deer","red panda","reindeer","rhinoceros","rook","salamander","salmon","sand dollar","sandpiper","sardine","scorpion","seahorse","seal","shark","sheep","shrew","skunk","snail","snake","sparrow","spider","spoonbill","squid","squirrel","starling","stingray","stinkbug","stork","swallow","swan","tapir","tarsier","termite","tiger","toad","trout","turkey","turtle","viper","vulture","wallaby","walrus","wasp","weasel","whale","wildcat","wolf","wolverine","wombat","woodcock","woodpecker","worm","wren","yak","zebra"];
mlflow/server/js/yarn.lock:12589:    snake-case: "npm:^3.0.4"
mlflow/server/js/yarn.lock:31333:"snake-case@npm:^3.0.4":
mlflow/server/js/yarn.lock:31335:  resolution: "snake-case@npm:3.0.4"
mlflow/llama_index/tracer.py:84:    dsp.span_handlers = [h for h in dsp.span_handlers if h.class_name() != "MlflowSpanHandler"]
mlflow/llama_index/tracer.py:85:    dsp.event_handlers = [h for h in dsp.event_handlers if h.class_name() != "MlflowEventHandler"]
mlflow/llama_index/tracer.py:137:    def class_name(cls) -> str:
mlflow/llama_index/tracer.py:336:    def class_name(cls) -> str:
mlflow/llama_index/serialize_objects.py:20:    class_name = o.__qualname__
mlflow/llama_index/serialize_objects.py:24:    if not hasattr(module, class_name):
mlflow/llama_index/serialize_objects.py:25:        raise ValueError(f"Module {module} does not have {class_name}")
mlflow/llama_index/serialize_objects.py:27:    return f"{module_name}.{class_name}"
mlflow/llama_index/serialize_objects.py:57:            o_state_as_dict.pop("class_name")
mlflow/llama_index/serialize_objects.py:98:    import_path, class_name = constructor_str.rsplit(".", 1)
mlflow/llama_index/serialize_objects.py:104:        object_class = getattr(module, class_name)
mlflow/lightgbm/__init__.py:48:from mlflow.utils import _get_fully_qualified_class_name
mlflow/lightgbm/__init__.py:201:    lgb_model_class = _get_fully_qualified_class_name(lgb_model)
mlflow/openai/autolog.py:225:        case [class_name, _]:
mlflow/openai/autolog.py:226:            return class_name in {"Responses", "AsyncResponses"}
mlflow/utils/proto_json_utils.py:113:    """Converts a message to JSON, using snake_case for field names."""
mlflow/utils/__init__.py:112:def _get_fully_qualified_class_name(obj):
mlflow/utils/class_utils.py:4:def _get_class_from_string(fully_qualified_class_name):
mlflow/utils/class_utils.py:5:    module, class_name = fully_qualified_class_name.rsplit(".", maxsplit=1)
mlflow/utils/class_utils.py:6:    return getattr(importlib.import_module(module), class_name)
mlflow/crewai/__init__.py:70:            *module_parts, class_name = class_path.rsplit(".", 1)
mlflow/crewai/__init__.py:73:            cls = getattr(module, class_name)
mlflow/transformers/model_io.py:206:    class_name = config.architectures[0]
mlflow/transformers/model_io.py:210:    if hasattr(transformers, class_name):
mlflow/transformers/model_io.py:211:        cls = getattr(transformers, class_name)
mlflow/transformers/model_io.py:221:            if module.split(".")[-1] == class_name
mlflow/transformers/model_io.py:225:            raise MlflowException(f"Couldn't find a loader class for {class_name}")
mlflow/xgboost/__init__.py:49:from mlflow.utils import _get_fully_qualified_class_name
mlflow/xgboost/__init__.py:172:    xgb_model_class = _get_fully_qualified_class_name(xgb_model)
mlflow/pyspark/ml/__init__.py:24:    _get_fully_qualified_class_name,
mlflow/pyspark/ml/__init__.py:152:    class_name = _get_fully_qualified_class_name(spark_model)
mlflow/pyspark/ml/__init__.py:153:    should_log = class_name in _log_model_allowlist
mlflow/pyspark/ml/__init__.py:157:            if name.endswith("*") and class_name.startswith(name[:-1]):
mlflow/pyspark/ml/__init__.py:161:        if class_name == "pyspark.ml.classification.OneVsRestModel":
mlflow/pyspark/ml/__init__.py:163:        elif class_name == "pyspark.ml.pipeline.PipelineModel":
mlflow/pyspark/ml/__init__.py:188:        "estimator_class": _get_fully_qualified_class_name(estimator),
mlflow/pyspark/ml/__init__.py:246:        class_name = child.__class__.__name__
mlflow/pyspark/ml/__init__.py:247:        counter[class_name] += 1
mlflow/pyspark/ml/__init__.py:248:        uid_to_classname_and_count[child.uid] = (class_name, counter[class_name])
mlflow/pyspark/ml/__init__.py:250:        uid: f"{class_name}_{count}" if counter[class_name] > 1 else class_name
mlflow/pyspark/ml/__init__.py:251:        for uid, (class_name, count) in uid_to_classname_and_count.items()
mlflow/pyspark/ml/__init__.py:299:         mapped to a fixed name. The naming rule is using `{class_name}` if the
mlflow/pyspark/ml/__init__.py:300:         instance type occurs once, or `{class_name}_{index}` if the instance type occurs
mlflow/pyspark/ml/__init__.py:468:        + f"{_get_fully_qualified_class_name(estimator)}.fit with a list of params,"
mlflow/pyspark/ml/__init__.py:698:        class_name = _get_fully_qualified_class_name(evaluator)
mlflow/pyspark/ml/__init__.py:702:        return {"evaluator_class": class_name, "params": param_map}
mlflow/pyspark/ml/__init__.py:1137:        if _get_fully_qualified_class_name(self).startswith("pyspark.ml.feature."):
mlflow/sklearn/__init__.py:119:    excluded_class_names = [
mlflow/sklearn/__init__.py:128:            or (estimator.__module__ + "." + estimator.__name__) in excluded_class_names
mlflow/sklearn/__init__.py:1131:          "{model_class_name}_score".
mlflow/cli/traces.py:859:    Available built-in scorers (use either PascalCase or snake_case):
mlflow/models/evaluation/base.py:35:from mlflow.utils import _get_fully_qualified_class_name
mlflow/models/evaluation/base.py:627:            ArtifactCls = _get_class_from_string(meta["class_name"])
mlflow/models/evaluation/base.py:644:                "class_name": _get_fully_qualified_class_name(artifact),
mlflow/smolagents/__init__.py:56:        for class_name, methods in class_method_map.items():
mlflow/smolagents/__init__.py:57:            cls = getattr(smolagents, class_name)
mlflow/data/dataset_source_registry.py:75:            source_class_names_str = ", ".join([source.__name__ for source in matching_sources])
mlflow/data/dataset_source_registry.py:78:                f" {source_class_names_str}. MLflow will assume that this is a"
mlflow/pydantic_ai/__init__.py:45:        module_name, class_name = cls_path.rsplit(".", 1)
mlflow/pydantic_ai/__init__.py:47:            module = __import__(module_name, fromlist=[class_name])
mlflow/pydantic_ai/__init__.py:48:            cls = getattr(module, class_name)
mlflow/ai_commands/genai/analyze_experiment.md:130:- Use snake_case names as assessment keys (e.g., `overly_verbose`, `tool_failure`, `rate_limited`, `slow_response`)
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "sed -n '780,910p' mlflow/cli/traces.py
grep -R -n \"Available built-in scorers\" mlflow tests | head -50
grep -R -n \"relevance_to_query\\|retrieval_groundedness\" tests/cli tests 2>/dev/null | head -100
find tests -type f | grep -E '/cli/|genai.*eval' | sort | head -200"
```

退出码：`0`

输出：
```
            value=parsed_value if value else existing.value,
            metadata=parsed_metadata if metadata else existing.metadata,
        )

    client.update_assessment(trace_id, assessment_id, updated_assessment)
    click.echo(f"Updated assessment {assessment_id} in trace {trace_id}.")


@commands.command("delete-assessment")
@TRACE_ID
@click.option("--assessment-id", type=click.STRING, required=True, help="Assessment ID to delete")
def delete_assessment(trace_id: str, assessment_id: str) -> None:
    """
    Delete an assessment from a trace.

    \b
    Example:
    mlflow traces delete-assessment --trace-id tr-abc123 --assessment-id asmt-def456
    """
    client = TracingClient()
    client.delete_assessment(trace_id, assessment_id)
    click.echo(f"Deleted assessment {assessment_id} from trace {trace_id}.")


@commands.command("evaluate")
@EXPERIMENT_ID
@click.option(
    "--trace-ids",
    type=click.STRING,
    required=True,
    help="Comma-separated list of trace IDs to evaluate.",
)
@click.option(
    "--scorers",
    type=click.STRING,
    required=True,
    help="Comma-separated list of scorer names. Can be built-in scorers "
    "(e.g., Correctness, Safety, RelevanceToQuery) or registered custom scorers.",
)
@click.option(
    "--output",
    "output_format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format: 'table' for formatted table (default) or 'json' for JSON format",
)
def evaluate_traces(
    experiment_id: str,
    trace_ids: str,
    scorers: str,
    output_format: Literal["table", "json"] = "table",
) -> None:
    """
    Evaluate one or more traces using specified scorers and display the results.

    This command runs MLflow's genai.evaluate() on specified traces, applying the
    specified scorers and displaying the evaluation results in table or JSON format.

    \b
    Examples:
    # Evaluate a single trace with built-in scorers
    mlflow traces evaluate --trace-ids tr-abc123 --scorers Correctness,Safety

    \b
    # Evaluate multiple traces
    mlflow traces evaluate --trace-ids tr-abc123,tr-def456,tr-ghi789 \\
        --scorers RelevanceToQuery

    \b
    # Evaluate with JSON output
    mlflow traces evaluate --trace-ids tr-abc123 \\
        --scorers Correctness --output json

    \b
    # Evaluate with custom registered scorer
    mlflow traces evaluate --trace-ids tr-abc123,tr-def456 \\
        --scorers my_custom_scorer,Correctness

    \b
    Available built-in scorers (use either PascalCase or snake_case):
    - Correctness / correctness: Ensures responses are correct and accurate
    - Safety / safety: Ensures responses don't contain harmful/toxic content
    - RelevanceToQuery / relevance_to_query: Ensures response addresses user input directly
    - Guidelines / guidelines: Evaluates adherence to specific constraints
    - ExpectationsGuidelines / expectations_guidelines: Row-specific guidelines evaluation
    - RetrievalRelevance / retrieval_relevance: Measures chunk relevance to input request
    - RetrievalSufficiency / retrieval_sufficiency: Evaluates if retrieved docs provide
      necessary info
    - RetrievalGroundedness / retrieval_groundedness: Assesses response alignment with
      retrieved context
    """
    from mlflow.cli.eval import evaluate_traces as run_evaluation

    run_evaluation(experiment_id, trace_ids, scorers, output_format)
mlflow/cli/traces.py:859:    Available built-in scorers (use either PascalCase or snake_case):
tests/genai/judges/test_builtin.py:181:            name="relevance_to_query",
tests/genai/judges/test_builtin.py:201:                name="relevance_to_query",
tests/genai/judges/test_builtin.py:385:            "relevance_to_query",
tests/genai/judges/test_builtin.py:438:    with mock.patch("databricks.agents.evals.judges.relevance_to_query") as mock_judge:
tests/genai/scorers/test_validation.py:210:    assert " - `outputs` column is required by [relevance_to_query, guidelines]." in msg
tests/genai/scorers/test_validation.py:211:    assert " - `trace` column is required by [retrieval_groundedness]." in msg
tests/genai/scorers/test_serialization.py:57:    assert serialized["name"] == "relevance_to_query"
tests/genai/scorers/test_serialization.py:345:    # from mlflow.genai.scorers import relevance_to_query
tests/genai/scorers/test_serialization.py:354:    assert deserialized.name == "relevance_to_query"
tests/genai/scorers/test_serialization.py:361:        return_value=Feedback(name="relevance_to_query", value="yes", metadata={"chunk_index": 0}),
tests/genai/scorers/test_serialization.py:378:        name="relevance_to_query",
tests/genai/scorers/test_serialization.py:383:    assert result.name == "relevance_to_query"
tests/genai/scorers/test_scorer.py:102:                RetrievalGroundedness(name="retrieval_groundedness"),
tests/genai/scorers/test_scorer.py:133:                assessment_name="retrieval_groundedness",
tests/genai/scorers/test_scorer.py:141:                assessment_name="retrieval_groundedness",
tests/genai/scorers/test_builtin_scorers.py:68:def test_retrieval_groundedness(sample_rag_trace):
tests/genai/scorers/test_builtin_scorers.py:72:            name="retrieval_groundedness", value=CategoricalRating.YES
tests/genai/scorers/test_builtin_scorers.py:87:                name="retrieval_groundedness",
tests/genai/scorers/test_builtin_scorers.py:94:                name="retrieval_groundedness",
tests/genai/scorers/test_builtin_scorers.py:401:def test_relevance_to_query():
tests/genai/scorers/test_builtin_scorers.py:412:        name="relevance_to_query",
tests/genai/scorers/test_builtin_scorers.py:594:def test_retrieval_groundedness_get_input_fields():
tests/genai/scorers/test_builtin_scorers.py:613:def test_relevance_to_query_get_input_fields():
tests/genai/scorers/test_builtin_scorers.py:697:def test_relevance_to_query_with_trace():
tests/genai/scorers/test_builtin_scorers.py:700:            name="relevance_to_query", value="yes", rationale="Relevant"
tests/genai/scorers/test_builtin_scorers.py:707:        assert result.name == "relevance_to_query"
tests/genai/scorers/test_builtin_scorers.py:873:            name="relevance_to_query", value="yes", rationale="Relevant"
tests/genai/scorers/test_builtin_scorers.py:880:        assert result.name == "relevance_to_query"
tests/genai/evaluate/test_utils.py:527:    assert legacy_metric_builtin.name == "relevance_to_query"
tests/telemetry/test_tracked_events.py:370:        expected_params = {"builtin_scorers": ["relevance_to_query"]}
tests/cli/__init__.py
tests/cli/test_ai_commands.py
tests/cli/test_eval.py
tests/cli/test_scorers.py
tests/cli/test_traces.py
tests/genai/datasets/test_databricks_evaluation_dataset_source.py
tests/genai/datasets/test_evaluation_dataset.py
tests/genai/evaluate/__init__.py
tests/genai/evaluate/test_context.py
tests/genai/evaluate/test_evaluation.py
tests/genai/evaluate/test_telemetry.py
tests/genai/evaluate/test_to_predict_fn.py
tests/genai/evaluate/test_utils.py
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,360p' tests/cli/test_eval.py
sed -n '1,220p' tests/cli/test_scorers.py
git status --short"
```

退出码：`0`

输出：
```
from unittest import mock

import click
import pandas as pd
import pytest

import mlflow
from mlflow.cli.eval import evaluate_traces
from mlflow.entities import Trace, TraceInfo


def test_evaluate_traces_with_single_trace_table_output():
    experiment_id = mlflow.create_experiment("test_experiment")

    mock_trace = mock.Mock(spec=Trace)
    mock_trace.info = mock.Mock(spec=TraceInfo)
    mock_trace.info.trace_id = "tr-test-123"
    mock_trace.info.experiment_id = experiment_id

    mock_results = mock.Mock()
    mock_results.run_id = "run-eval-456"
    mock_results.tables = {
        "eval_results": pd.DataFrame(
            [
                {
                    "trace_id": "tr-test-123",
                    "assessments": [
                        {
                            "assessment_name": "RelevanceToQuery",
                            "feedback": {"value": "yes"},
                            "rationale": "The answer is relevant",
                            "metadata": {"mlflow.assessment.sourceRunId": "run-eval-456"},
                        }
                    ],
                }
            ]
        )
    }

    with (
        mock.patch(
            "mlflow.cli.eval.MlflowClient.get_trace", return_value=mock_trace
        ) as mock_get_trace,
        mock.patch("mlflow.cli.eval.evaluate", return_value=mock_results) as mock_evaluate,
    ):
        evaluate_traces(
            experiment_id=experiment_id,
            trace_ids="tr-test-123",
            scorers="RelevanceToQuery",
            output_format="table",
        )

        mock_get_trace.assert_called_once_with("tr-test-123", display=False)

        assert mock_evaluate.call_count == 1
        call_args = mock_evaluate.call_args
        assert "data" in call_args.kwargs

        expected_df = pd.DataFrame([{"trace_id": "tr-test-123", "trace": mock_trace}])
        pd.testing.assert_frame_equal(call_args.kwargs["data"], expected_df)

        assert "scorers" in call_args.kwargs
        assert len(call_args.kwargs["scorers"]) == 1
        assert call_args.kwargs["scorers"][0].__class__.__name__ == "RelevanceToQuery"


def test_evaluate_traces_with_multiple_traces_json_output():
    experiment = mlflow.create_experiment("test_experiment_multi")

    mock_trace1 = mock.Mock(spec=Trace)
    mock_trace1.info = mock.Mock(spec=TraceInfo)
    mock_trace1.info.trace_id = "tr-test-1"
    mock_trace1.info.experiment_id = experiment

    mock_trace2 = mock.Mock(spec=Trace)
    mock_trace2.info = mock.Mock(spec=TraceInfo)
    mock_trace2.info.trace_id = "tr-test-2"
    mock_trace2.info.experiment_id = experiment

    mock_results = mock.Mock()
    mock_results.run_id = "run-eval-789"
    mock_results.tables = {
        "eval_results": pd.DataFrame(
            [
                {
                    "trace_id": "tr-test-1",
                    "assessments": [
                        {
                            "assessment_name": "Correctness",
                            "feedback": {"value": "correct"},
                            "rationale": "Content is correct",
                            "metadata": {"mlflow.assessment.sourceRunId": "run-eval-789"},
                        }
                    ],
                },
                {
                    "trace_id": "tr-test-2",
                    "assessments": [
                        {
                            "assessment_name": "Correctness",
                            "feedback": {"value": "correct"},
                            "rationale": "Also correct",
                            "metadata": {"mlflow.assessment.sourceRunId": "run-eval-789"},
                        }
                    ],
                },
            ]
        )
    }

    with (
        mock.patch(
            "mlflow.cli.eval.MlflowClient.get_trace",
            side_effect=[mock_trace1, mock_trace2],
        ) as mock_get_trace,
        mock.patch("mlflow.cli.eval.evaluate", return_value=mock_results) as mock_evaluate,
    ):
        evaluate_traces(
            experiment_id=experiment,
            trace_ids="tr-test-1,tr-test-2",
            scorers="Correctness",
            output_format="json",
        )

        assert mock_get_trace.call_count == 2
        mock_get_trace.assert_any_call("tr-test-1", display=False)
        mock_get_trace.assert_any_call("tr-test-2", display=False)

        assert mock_evaluate.call_count == 1
        call_args = mock_evaluate.call_args
        expected_df = pd.DataFrame(
            [
                {"trace_id": "tr-test-1", "trace": mock_trace1},
                {"trace_id": "tr-test-2", "trace": mock_trace2},
            ]
        )
        pd.testing.assert_frame_equal(call_args.kwargs["data"], expected_df)


def test_evaluate_traces_with_nonexistent_trace():
    experiment = mlflow.create_experiment("test_experiment_error")

    with mock.patch("mlflow.cli.eval.MlflowClient.get_trace", return_value=None) as mock_get_trace:
        with pytest.raises(click.UsageError, match="Trace with ID 'tr-nonexistent' not found"):
            evaluate_traces(
                experiment_id=experiment,
                trace_ids="tr-nonexistent",
                scorers="RelevanceToQuery",
                output_format="table",
            )

        mock_get_trace.assert_called_once_with("tr-nonexistent", display=False)


def test_evaluate_traces_with_trace_from_wrong_experiment():
    experiment1 = mlflow.create_experiment("test_experiment_1")
    experiment2 = mlflow.create_experiment("test_experiment_2")

    mock_trace = mock.Mock(spec=Trace)
    mock_trace.info = mock.Mock(spec=TraceInfo)
    mock_trace.info.trace_id = "tr-test-123"
    mock_trace.info.experiment_id = experiment2

    with mock.patch(
        "mlflow.cli.eval.MlflowClient.get_trace", return_value=mock_trace
    ) as mock_get_trace:
        with pytest.raises(click.UsageError, match="belongs to experiment"):
            evaluate_traces(
                experiment_id=experiment1,
                trace_ids="tr-test-123",
                scorers="RelevanceToQuery",
                output_format="table",
            )

        mock_get_trace.assert_called_once_with("tr-test-123", display=False)
import json
from typing import Any
from unittest.mock import patch

import pytest
from click.testing import CliRunner

import mlflow
from mlflow.cli.scorers import commands
from mlflow.exceptions import MlflowException
from mlflow.genai.scorers import list_scorers, scorer
from mlflow.utils.string_utils import _create_table


@pytest.fixture
def mock_databricks_environment():
    with (
        patch("mlflow.genai.scorers.base.is_databricks_uri", return_value=True),
        patch("mlflow.genai.scorers.base.is_in_databricks_runtime", return_value=True),
    ):
        yield


@pytest.fixture
def runner():
    return CliRunner(catch_exceptions=False)


@pytest.fixture
def experiment():
    """Create a test experiment."""
    experiment_id = mlflow.create_experiment(
        f"test_scorers_cli_{mlflow.utils.time.get_current_time_millis()}"
    )
    yield experiment_id
    mlflow.delete_experiment(experiment_id)


@pytest.fixture
def correctness_scorer():
    """Create a correctness scorer."""

    @scorer
    def _correctness_scorer(outputs) -> bool:
        return len(outputs) > 0

    return _correctness_scorer


@pytest.fixture
def safety_scorer():
    """Create a safety scorer."""

    @scorer
    def _safety_scorer(outputs) -> bool:
        return len(outputs) > 0

    return _safety_scorer


@pytest.fixture
def relevance_scorer():
    """Create a relevance scorer."""

    @scorer
    def _relevance_scorer(outputs) -> bool:
        return len(outputs) > 0

    return _relevance_scorer


@pytest.fixture
def generic_scorer():
    """Create a generic test scorer."""

    @scorer
    def _generic_scorer(outputs) -> bool:
        return True

    return _generic_scorer


def test_commands_group_exists():
    assert commands.name == "scorers"
    assert commands.help is not None


def test_list_command_params():
    list_cmd = next((cmd for cmd in commands.commands.values() if cmd.name == "list"), None)
    assert list_cmd is not None
    param_names = {p.name for p in list_cmd.params}
    assert param_names == {"experiment_id", "output"}


def test_list_scorers_table_output(
    runner: CliRunner,
    experiment: str,
    correctness_scorer: Any,
    safety_scorer: Any,
    relevance_scorer: Any,
    mock_databricks_environment: Any,
):
    correctness_scorer.register(experiment_id=experiment, name="Correctness")
    safety_scorer.register(experiment_id=experiment, name="Safety")
    relevance_scorer.register(experiment_id=experiment, name="RelevanceToQuery")

    result = runner.invoke(commands, ["list", "--experiment-id", experiment])

    assert result.exit_code == 0

    # Construct expected table output (scorers are returned in alphabetical order)
    # Note: click.echo() adds a trailing newline
    expected_table = (
        _create_table(
            [["Correctness", ""], ["RelevanceToQuery", ""], ["Safety", ""]],
            headers=["Scorer Name", "Description"],
        )
        + "\n"
    )
    assert result.output == expected_table


def test_list_scorers_json_output(
    runner: CliRunner,
    experiment: str,
    correctness_scorer: Any,
    safety_scorer: Any,
    relevance_scorer: Any,
    mock_databricks_environment: Any,
):
    correctness_scorer.register(experiment_id=experiment, name="Correctness")
    safety_scorer.register(experiment_id=experiment, name="Safety")
    relevance_scorer.register(experiment_id=experiment, name="RelevanceToQuery")

    result = runner.invoke(commands, ["list", "--experiment-id", experiment, "--output", "json"])

    assert result.exit_code == 0
    output_json = json.loads(result.output)
    expected_scorers = [
        {"name": "Correctness", "description": None},
        {"name": "RelevanceToQuery", "description": None},
        {"name": "Safety", "description": None},
    ]
    assert output_json["scorers"] == expected_scorers


@pytest.mark.parametrize(
    ("output_format", "expected_output"),
    [
        ("table", ""),
        ("json", {"scorers": []}),
    ],
)
def test_list_scorers_empty_experiment(
    runner: CliRunner, experiment: str, output_format: str, expected_output: Any
):
    args = ["list", "--experiment-id", experiment]
    if output_format == "json":
        args.extend(["--output", "json"])

    result = runner.invoke(commands, args)
    assert result.exit_code == 0

    if output_format == "json":
        output_json = json.loads(result.output)
        assert output_json == expected_output
    else:
        # Empty table produces minimal output
        assert result.output.strip() == expected_output


def test_list_scorers_with_experiment_id_env_var(
    runner: CliRunner, experiment: str, correctness_scorer: Any, mock_databricks_environment: Any
):
    correctness_scorer.register(experiment_id=experiment, name="Correctness")

    result = runner.invoke(commands, ["list"], env={"MLFLOW_EXPERIMENT_ID": experiment})

    assert result.exit_code == 0
    assert "Correctness" in result.output


def test_list_scorers_missing_experiment_id(runner: CliRunner):
    result = runner.invoke(commands, ["list"])

    assert result.exit_code != 0
    assert "experiment-id" in result.output.lower() or "experiment_id" in result.output.lower()


def test_list_scorers_invalid_output_format(runner: CliRunner, experiment: str):
    result = runner.invoke(commands, ["list", "--experiment-id", experiment, "--output", "invalid"])

    assert result.exit_code != 0
    assert "invalid" in result.output.lower() or "choice" in result.output.lower()


def test_list_scorers_special_characters_in_names(
    runner: CliRunner, experiment: str, generic_scorer: Any, mock_databricks_environment: Any
):
    generic_scorer.register(experiment_id=experiment, name="Scorer With Spaces")
    generic_scorer.register(experiment_id=experiment, name="Scorer.With.Dots")
    generic_scorer.register(experiment_id=experiment, name="Scorer-With-Dashes")
    generic_scorer.register(experiment_id=experiment, name="Scorer_With_Underscores")

    result = runner.invoke(commands, ["list", "--experiment-id", experiment])

    assert result.exit_code == 0
    assert "Scorer With Spaces" in result.output
    assert "Scorer.With.Dots" in result.output
    assert "Scorer-With-Dashes" in result.output
    assert "Scorer_With_Underscores" in result.output


@pytest.mark.parametrize(
    "output_format",
    ["table", "json"],
)
def test_list_scorers_single_scorer(
    runner: CliRunner,
    experiment: str,
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "sed -n '240,370p' mlflow/genai/scorers/builtin_scorers.py
sed -n '111,210p' mlflow/genai/scorers/base.py
grep -n \"def name\\|name:\" mlflow/genai/scorers/builtin_scorers.py | head -60
grep -R -n \"No valid scorers\\|Failed to.*scorer\\|built-in scorers\" tests/cli mlflow/cli | head -100"
```

退出码：`0`

输出：
```
def _sanitize_scorer_feedback(feedback: Feedback) -> Feedback:
    """Sanitize feedback values from LLM judges to ensure YES/NO consistency."""
    if feedback.value:
        if isinstance(feedback.value, CategoricalRating):
            return feedback

        if isinstance(feedback.value, str):
            value_str = feedback.value.strip().lower()

            if value_str in _AFFIRMATIVE_VALUES:
                feedback.value = CategoricalRating.YES
            elif value_str in _NEGATIVE_VALUES:
                feedback.value = CategoricalRating.NO
            else:
                feedback.value = CategoricalRating(value_str)

    return feedback


class BuiltInScorer(Judge):
    """
    Abstract base class for built-in scorers that share a common implementation.
    All built-in scorers should inherit from this class.
    """

    name: str
    required_columns: set[str] = set()

    @property
    @abstractmethod
    def instructions(self) -> str:
        """
        Get the instructions of what this scorer evaluates.
        """

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Override model_dump to handle builtin scorer serialization."""
        pydantic_model_data = pydantic.BaseModel.model_dump(self, mode="json", **kwargs)
        pydantic_model_data["instructions"] = self.instructions

        serialized = SerializedScorer(
            name=self.name,
            description=self.description,
            aggregations=self.aggregations,
            mlflow_version=mlflow.__version__,
            serialization_version=_SERIALIZATION_VERSION,
            builtin_scorer_class=self.__class__.__name__,
            builtin_scorer_pydantic_data=pydantic_model_data,
        )

        return asdict(serialized)

    @classmethod
    def model_validate(cls, obj: SerializedScorer | dict[str, Any]) -> "BuiltInScorer":
        """Override model_validate to handle builtin scorer deserialization."""
        from mlflow.genai.scorers import builtin_scorers

        if isinstance(obj, SerializedScorer):
            serialized = obj
        else:
            if not isinstance(obj, dict) or "builtin_scorer_class" not in obj:
                raise MlflowException.invalid_parameter_value(
                    f"Invalid builtin scorer data: expected a dictionary with "
                    f"'builtin_scorer_class' field, got {type(obj).__name__}."
                )

            try:
                serialized = SerializedScorer(**obj)
            except Exception as e:
                raise MlflowException.invalid_parameter_value(
                    f"Failed to parse serialized scorer data: {e}"
                )

        try:
            scorer_class = getattr(builtin_scorers, serialized.builtin_scorer_class)
        except AttributeError:
            raise MlflowException.invalid_parameter_value(
                f"Unknown builtin scorer class: {serialized.builtin_scorer_class}"
            )

        constructor_args = serialized.builtin_scorer_pydantic_data or {}

        return scorer_class(**constructor_args)

    def validate_columns(self, columns: set[str]) -> None:
        missing_columns = self.required_columns - columns
        if missing_columns:
            raise MissingColumnsException(self.name, missing_columns)

    @property
    def kind(self) -> ScorerKind:
        return ScorerKind.BUILTIN


@format_docstring(_MODEL_API_DOC)
class RetrievalRelevance(BuiltInScorer):
    """
    Retrieval relevance measures whether each chunk is relevant to the input request.

    You can invoke the scorer directly with a single input for testing, or pass it to
    `mlflow.genai.evaluate` for running full evaluation on a dataset.

    Args:
        name: The name of the scorer. Defaults to "retrieval_relevance".
        model: {{ model }}

    Example (direct usage):

    .. code-block:: python

        import mlflow
        from mlflow.genai.scorers import RetrievalRelevance

        trace = mlflow.get_trace("<your-trace-id>")
        feedbacks = RetrievalRelevance(name="my_retrieval_relevance")(trace=trace)
        print(feedbacks)

    Example (with evaluate):

    .. code-block:: python

        import mlflow

        data = mlflow.search_traces(...)
        result = mlflow.genai.evaluate(data=data, scorers=[RetrievalRelevance()])
    """

    name: str = "retrieval_relevance"
    model: str | None = None
    required_columns: set[str] = {"inputs", "trace"}
    description: str = (
class Scorer(BaseModel):
    name: str
    aggregations: list[_AggregationType] | None = None
    description: str | None = None

    _cached_dump: dict[str, Any] | None = PrivateAttr(default=None)
    _sampling_config: ScorerSamplingConfig | None = PrivateAttr(default=None)
    _registered_backend: str | None = PrivateAttr(default=None)

    @property
    def sample_rate(self) -> float | None:
        """Get the sample rate for this scorer. Available when registered for monitoring."""
        return self._sampling_config.sample_rate if self._sampling_config else None

    @property
    def filter_string(self) -> str | None:
        """Get the filter string for this scorer."""
        return self._sampling_config.filter_string if self._sampling_config else None

    @property
    def status(self) -> ScorerStatus:
        """Get the status of this scorer, using only the local state."""

        if self._registered_backend is None:
            return ScorerStatus.UNREGISTERED

        return ScorerStatus.STARTED if (self.sample_rate or 0) > 0 else ScorerStatus.STOPPED

    def __repr__(self) -> str:
        # Get the standard representation from the parent class
        base_repr = super().__repr__()
        filter_string = self.filter_string
        if filter_string is not None:
            filter_string = f"'{filter_string}'"

        # Inject the property's value into the repr string
        return f"{base_repr[:-1]}, sample_rate={self.sample_rate}, filter_string={filter_string})"

    def model_dump(self, **kwargs) -> dict[str, Any]:
        """Override model_dump to include source code."""

        # Return cached dump if available (prevents re-serialization issues with dynamic functions)
        if self._cached_dump is not None:
            return self._cached_dump

        # Check if this is a decorator scorer
        if not getattr(self, "_original_func", None):
            # BuiltInScorer overrides `model_dump`, so this is neither a builtin scorer nor a
            # decorator scorer
            raise MlflowException.invalid_parameter_value(
                f"Unsupported scorer type: {self.__class__.__name__}. "
                f"Scorer serialization only supports:\n"
                f"1. Builtin scorers (from mlflow.genai.scorers.builtin_scorers)\n"
                f"2. Decorator-created scorers (using @scorer decorator)\n"
                f"Direct subclassing of Scorer is not supported for serialization. "
                f"Please use the @scorer decorator instead."
            )

        # Decorator scorer - extract and store source code
        source_info = self._extract_source_code_info()

        # Create serialized scorer with all fields at once
        serialized = SerializedScorer(
            name=self.name,
            description=self.description,
            aggregations=self.aggregations,
            mlflow_version=mlflow.__version__,
            serialization_version=_SERIALIZATION_VERSION,
            call_source=source_info.get("call_source"),
            call_signature=source_info.get("call_signature"),
            original_func_name=source_info.get("original_func_name"),
        )
        self._cached_dump = asdict(serialized)
        return self._cached_dump

    def _extract_source_code_info(self) -> dict[str, str | None]:
        """Extract source code information for the original decorated function."""
        from mlflow.genai.scorers.scorer_utils import extract_function_body

        result = {"call_source": None, "call_signature": None, "original_func_name": None}

        # Extract original function source
        call_body, _ = extract_function_body(self._original_func)
        result["call_source"] = call_body
        result["original_func_name"] = self._original_func.__name__

        # Store the signature of the original function
        result["call_signature"] = str(inspect.signature(self._original_func))

        return result

    @classmethod
    def model_validate(cls, obj: Any) -> "Scorer":
        """Override model_validate to reconstruct scorer from source code."""
        # Handle SerializedScorer object
        if isinstance(obj, SerializedScorer):
            serialized = obj
        # Handle dict object
        elif isinstance(obj, dict):
            # Parse the serialized data using our dataclass
147:    scorer_name: str,
155:        scorer_name: Name of the scorer for error messages.
265:    name: str
343:        name: The name of the scorer. Defaults to "retrieval_relevance".
367:    name: str = "retrieval_relevance"
473:        name: The name of the scorer. Defaults to "retrieval_sufficiency".
497:    name: str = "retrieval_sufficiency"
599:        name: The name of the scorer. Defaults to "retrieval_groundedness".
623:    name: str = "retrieval_groundedness"
694:        name: The name of the scorer. Defaults to "guidelines".
748:    name: str = "guidelines"
837:        name: The name of the scorer. Defaults to "expectations_guidelines".
870:    name: str = "expectations_guidelines"
989:        name: The name of the scorer. Defaults to "relevance_to_query".
1021:    name: str = "relevance_to_query"
1102:        name: The name of the scorer. Defaults to "safety".
1131:    name: str = "safety"
1204:        name: The name of the scorer. Defaults to "correctness".
1258:    name: str = "correctness"
1392:        name: The name of the scorer. Defaults to "equivalence".
1432:    name: str = "equivalence"
mlflow/cli/traces.py:816:    help="Comma-separated list of scorer names. Can be built-in scorers "
mlflow/cli/traces.py:840:    # Evaluate a single trace with built-in scorers
mlflow/cli/traces.py:859:    Available built-in scorers (use either PascalCase or snake_case):
```

## 原始行 24 · agent_message

```
The repository evidence matches the interface’s edge cases: built-ins expose both a PascalCase class name and a snake_case `.name`, while assessment rows contain nested dictionaries keyed by the run metadata constant. I’m implementing those semantics directly, including deliberate propagation of malformed-container errors.
```

## 原始行 26 · file_change

```
{
  "id": "item_16",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/cli/genai_eval_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 29 · agent_message

```
The implementation is in place. I’m now validating both the CLI integration and focused edge cases (run filtering, fallbacks, cell precedence, metadata identity, scorer resolution, and exception boundaries).
```

## 原始行 30 · command_execution

命令：
```
/bin/bash -lc 'tail -180 mlflow/cli/genai_eval_utils.py
pytest -q tests/cli/test_eval.py'
```

退出码：`0`

输出：
```
    """

    value: str
    """The formatted display value for the cell"""

    assessment: Assessment | None = None
    """The assessment data for this cell, if it represents an assessment"""


@dataclass
class EvalResult:
    """
    Container for evaluation results for a single trace.

    This dataclass provides structured access to trace evaluation data,
    replacing dict-based access for better type safety.
    """

    trace_id: str
    """The trace ID"""

    assessments: list[Assessment]
    """List of Assessment objects for this trace"""


@dataclass
class TableOutput:
    """Container for formatted table data."""

    headers: list[str]
    rows: list[list[Cell]]


def _format_assessment_cell(assessment: Assessment | None) -> Cell:
    """
    Format a single assessment cell for table display.

    Args:
        assessment: Assessment object with result, rationale, and error fields

    Returns:
        Cell object with formatted value and assessment metadata
    """
    if not assessment:
        return Cell(value=NA_VALUE)

    if assessment.error:
        display_value = f"error: {assessment.error}"
    elif assessment.result is not None and assessment.rationale:
        display_value = f"value: {assessment.result}, rationale: {assessment.rationale}"
    elif assessment.result is not None:
        display_value = f"value: {assessment.result}"
    elif assessment.rationale:
        display_value = f"rationale: {assessment.rationale}"
    else:
        display_value = NA_VALUE

    return Cell(value=display_value, assessment=assessment)


def extract_assessments_from_results(
    results_df: pd.DataFrame, evaluation_run_id: str
) -> list[EvalResult]:
    """Extract assessments created by an evaluation run from its results table."""
    output_data = []

    for _, row in results_df.iterrows():
        assessments = []
        for assessment_data in row.get("assessments", []):
            source_run_id = assessment_data.get("metadata", {}).get(
                AssessmentMetadataKey.SOURCE_RUN_ID
            )
            if source_run_id != evaluation_run_id:
                continue

            feedback = assessment_data.get("feedback")
            result = feedback.get("value") if isinstance(feedback, dict) else None
            error = assessment_data.get("error")
            assessments.append(
                Assessment(
                    name=assessment_data.get("assessment_name"),
                    result=result,
                    rationale=assessment_data.get("rationale"),
                    error=str(error) if error else None,
                )
            )

        if not assessments:
            assessments.append(
                Assessment(name=NA_VALUE, error="No assessments found on trace")
            )

        output_data.append(
            EvalResult(trace_id=row.get("trace_id", "unknown"), assessments=assessments)
        )

    return output_data


def format_table_output(output_data: list[EvalResult]) -> TableOutput:
    """Format evaluation results as trace rows and assessment columns."""
    assessment_names = sorted(
        {
            assessment.name
            for result in output_data
            for assessment in result.assessments
            if assessment.name not in (None, NA_VALUE)
        }
    )
    headers = ["trace_id", *assessment_names]
    rows = []

    for result in output_data:
        assessments_by_name = {
            assessment.name: assessment for assessment in result.assessments
        }
        rows.append(
            [Cell(value=result.trace_id)]
            + [
                _format_assessment_cell(assessments_by_name.get(name))
                for name in assessment_names
            ]
        )

    return TableOutput(headers=headers, rows=rows)


def resolve_scorers(scorer_names: list[str], experiment_id: str) -> list[Scorer]:
    """Resolve built-in scorer class/snake-case names and registered scorers."""
    built_in_scorers = get_all_scorers()
    built_in_by_name = {
        name: scorer
        for scorer in built_in_scorers
        for name in (scorer.__class__.__name__, scorer.name)
    }

    resolved_scorers = []
    for scorer_name in scorer_names:
        if scorer := built_in_by_name.get(scorer_name):
            resolved_scorers.append(scorer)
            continue

        try:
            resolved_scorers.append(
                get_scorer(name=scorer_name, experiment_id=experiment_id)
            )
        except MlflowException as e:
            available_scorers = ", ".join(sorted(built_in_by_name))
            raise click.UsageError(
                f"Scorer '{scorer_name}' not found. Available built-in scorers: "
                f"{available_scorers}. Error: {e}"
            ) from e

    if not resolved_scorers:
        raise click.UsageError("No valid scorers specified")

    return resolved_scorers























[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 4 items

tests/cli/test_eval.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                              [100%][0m

============================= slowest 10 durations =============================
2.03s call     tests/cli/test_eval.py::test_evaluate_traces_with_single_trace_table_output
1.79s call     tests/cli/test_eval.py::test_evaluate_traces_with_nonexistent_trace
1.72s call     tests/cli/test_eval.py::test_evaluate_traces_with_multiple_traces_json_output
1.67s call     tests/cli/test_eval.py::test_evaluate_traces_with_trace_from_wrong_experiment

(6 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                     | Duration | Tests | Min    | Max    | Avg    |
| ---- | ------------------------ | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/cli/test_eval.py` | 7.22s    | 4     | 1.672s | 2.032s | 1.804s |

::endgroup::

[32m============================== [32m[1m4 passed[0m[32m in 7.38s[0m[32m ===============================[0m
```

## 原始行 34 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from unittest.mock import Mock, patch
import click
import pandas as pd
from mlflow.cli.genai_eval_utils import (
    Assessment, EvalResult, extract_assessments_from_results,
    format_table_output, resolve_scorers,
)
from mlflow.exceptions import MlflowException
from mlflow.tracing.constant import AssessmentMetadataKey

run_key = AssessmentMetadataKey.SOURCE_RUN_ID
frame = pd.DataFrame([
    {\"trace_id\": \"t1\", \"assessments\": [
        {\"assessment_name\": \"z\", \"feedback\": {\"value\": 0}, \"rationale\": \"because\", \"metadata\": {run_key: \"run\"}},
        {\"assessment_name\": \"old\", \"feedback\": {\"value\": 1}, \"metadata\": {run_key: \"other\"}},
        {\"assessment_name\": \"a\", \"feedback\": \"bad\", \"error\": {\"message\": \"failed\"}, \"metadata\": {run_key: \"run\"}},
    ]},
    {\"trace_id\": \"t2\", \"assessments\": []},
])
extracted = extract_assessments_from_results(frame, \"run\")
assert extracted[0].assessments[0] == Assessment(\"z\", 0, \"because\", None)
assert extracted[0].assessments[1].error == \"{'message': 'failed'}\"
assert extracted[1].assessments == [Assessment(\"N/A\", error=\"No assessments found on trace\")]
table = format_table_output(extracted)
assert table.headers == [\"trace_id\", \"a\", \"z\"]
assert [c.value for c in table.rows[0]] == [\"t1\", \"error: {'message': 'failed'}\", \"value: 0, rationale: because\"]
assert table.rows[0][1].assessment is extracted[0].assessments[1]
assert table.rows[1][1].assessment is None

builtin = Mock(name=\"builtin\")
builtin.name = \"some_scorer\"
builtin.__class__.__name__ = \"SomeScorer\"
registered = Mock(name=\"registered\")
with patch(\"mlflow.cli.genai_eval_utils.get_all_scorers\", return_value=[builtin]), patch(
    \"mlflow.cli.genai_eval_utils.get_scorer\", return_value=registered
) as get_registered:
    assert resolve_scorers([\"SomeScorer\", \"some_scorer\", \"custom\"], \"exp\") == [builtin, builtin, registered]
    get_registered.assert_called_once_with(name=\"custom\", experiment_id=\"exp\")
with patch(\"mlflow.cli.genai_eval_utils.get_all_scorers\", return_value=[]):
    try:
        resolve_scorers([], \"exp\")
    except click.UsageError:
        pass
    else:
        raise AssertionError(\"empty scorer list did not fail\")
with patch(\"mlflow.cli.genai_eval_utils.get_all_scorers\", return_value=[]), patch(
    \"mlflow.cli.genai_eval_utils.get_scorer\", side_effect=MlflowException(\"missing\")
):
    try:
        resolve_scorers([\"missing\"], \"exp\")
    except click.UsageError:
        pass
    else:
        raise AssertionError(\"MlflowException was not converted\")
print(\"focused checks passed\")
PY
ruff check mlflow/cli/genai_eval_utils.py"
```

退出码：`2`

输出：
```
focused checks passed
ruff failed
  Cause: Required version `==0.12.10` does not match the running version `0.14.5`
```

## 原始行 37 · command_execution

命令：
```
/bin/bash -lc "grep -R -n -E \"No valid .* specified|Available built-in|not found\\. Available\" mlflow/cli tests/cli | head -200
grep -R -n \"except MlflowException as e:\" mlflow/cli | head -100
python -m compileall -q mlflow/cli/genai_eval_utils.py
git diff --check
git diff -- mlflow/cli/genai_eval_utils.py"
```

退出码：`0`

输出：
```
grep: mlflow/cli/__pycache__/genai_eval_utils.cpython-311.pyc: binary file matches
grep: mlflow/cli/__pycache__/traces.cpython-311.pyc: binary file matches
mlflow/cli/traces.py:859:    Available built-in scorers (use either PascalCase or snake_case):
mlflow/cli/genai_eval_utils.py:191:                f"Scorer '{scorer_name}' not found. Available built-in scorers: "
mlflow/cli/genai_eval_utils.py:196:        raise click.UsageError("No valid scorers specified")
mlflow/cli/genai_eval_utils.py:188:        except MlflowException as e:
diff --git a/mlflow/cli/genai_eval_utils.py b/mlflow/cli/genai_eval_utils.py
index c835381..37fe298 100644
--- a/mlflow/cli/genai_eval_utils.py
+++ b/mlflow/cli/genai_eval_utils.py
@@ -99,6 +99,104 @@ def _format_assessment_cell(assessment: Assessment | None) -> Cell:
     return Cell(value=display_value, assessment=assessment)
 
 
+def extract_assessments_from_results(
+    results_df: pd.DataFrame, evaluation_run_id: str
+) -> list[EvalResult]:
+    """Extract assessments created by an evaluation run from its results table."""
+    output_data = []
+
+    for _, row in results_df.iterrows():
+        assessments = []
+        for assessment_data in row.get("assessments", []):
+            source_run_id = assessment_data.get("metadata", {}).get(
+                AssessmentMetadataKey.SOURCE_RUN_ID
+            )
+            if source_run_id != evaluation_run_id:
+                continue
+
+            feedback = assessment_data.get("feedback")
+            result = feedback.get("value") if isinstance(feedback, dict) else None
+            error = assessment_data.get("error")
+            assessments.append(
+                Assessment(
+                    name=assessment_data.get("assessment_name"),
+                    result=result,
+                    rationale=assessment_data.get("rationale"),
+                    error=str(error) if error else None,
+                )
+            )
+
+        if not assessments:
+            assessments.append(
+                Assessment(name=NA_VALUE, error="No assessments found on trace")
+            )
+
+        output_data.append(
+            EvalResult(trace_id=row.get("trace_id", "unknown"), assessments=assessments)
+        )
+
+    return output_data
+
+
+def format_table_output(output_data: list[EvalResult]) -> TableOutput:
+    """Format evaluation results as trace rows and assessment columns."""
+    assessment_names = sorted(
+        {
+            assessment.name
+            for result in output_data
+            for assessment in result.assessments
+            if assessment.name not in (None, NA_VALUE)
+        }
+    )
+    headers = ["trace_id", *assessment_names]
+    rows = []
+
+    for result in output_data:
+        assessments_by_name = {
+            assessment.name: assessment for assessment in result.assessments
+        }
+        rows.append(
+            [Cell(value=result.trace_id)]
+            + [
+                _format_assessment_cell(assessments_by_name.get(name))
+                for name in assessment_names
+            ]
+        )
+
+    return TableOutput(headers=headers, rows=rows)
+
+
+def resolve_scorers(scorer_names: list[str], experiment_id: str) -> list[Scorer]:
+    """Resolve built-in scorer class/snake-case names and registered scorers."""
+    built_in_scorers = get_all_scorers()
+    built_in_by_name = {
+        name: scorer
+        for scorer in built_in_scorers
+        for name in (scorer.__class__.__name__, scorer.name)
+    }
+
+    resolved_scorers = []
+    for scorer_name in scorer_names:
+        if scorer := built_in_by_name.get(scorer_name):
+            resolved_scorers.append(scorer)
+            continue
+
+        try:
+            resolved_scorers.append(
+                get_scorer(name=scorer_name, experiment_id=experiment_id)
+            )
+        except MlflowException as e:
+            available_scorers = ", ".join(sorted(built_in_by_name))
+            raise click.UsageError(
+                f"Scorer '{scorer_name}' not found. Available built-in scorers: "
+                f"{available_scorers}. Error: {e}"
+            ) from e
+
+    if not resolved_scorers:
+        raise click.UsageError("No valid scorers specified")
+
+    return resolved_scorers
+
```

## 原始行 40 · command_execution

命令：
```
/bin/bash -lc "awk 'length("'$0) > 100 {print NR, length($0), $0}'"' mlflow/cli/genai_eval_utils.py
python - <<'PY'
from mlflow.genai.scorers import get_all_scorers
for scorer in get_all_scorers():
    print(type(scorer).__name__, scorer.name)
PY
git status --short"
```

退出码：`0`

输出：
```
ExpectationsGuidelines expectations_guidelines
Correctness correctness
RelevanceToQuery relevance_to_query
RetrievalSufficiency retrieval_sufficiency
RetrievalGroundedness retrieval_groundedness
Equivalence equivalence
 M mlflow/cli/genai_eval_utils.py
```

## 原始行 43 · agent_message

```
Focused assertions and the visible CLI tests pass. The repository’s pinned lint wrapper cannot run because the installed `ruff` binary is a different version, so I’m using compile checks, `git diff --check`, and the relevant pytest suites as the verification path.
```

## 原始行 45 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/cli/test_traces.py tests/cli/test_eval.py'
```

退出码：`0`

输出：
```
[1m============================= test session starts ==============================[0m
platform linux -- Python 3.11.14, pytest-9.0.1, pluggy-1.6.0
rootdir: /testbed
configfile: pyproject.toml
plugins: asyncio-1.3.0, xdist-3.8.0, cov-7.0.0, mock-3.15.1, anyio-4.11.0, timeout-2.4.0
asyncio: mode=Mode.STRICT, debug=False, asyncio_default_fixture_loop_scope=None, asyncio_default_test_loop_scope=function
timeout: 1200.0s
timeout method: signal
timeout func_only: False
collected 13 items

tests/cli/test_traces.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                       [ 69%][0m
tests/cli/test_eval.py [32m.[0m[32m.[0m[32m.[0m[32m.[0m[32m                                              [100%][0m

============================= slowest 10 durations =============================
1.85s call     tests/cli/test_eval.py::test_evaluate_traces_with_single_trace_table_output
1.69s call     tests/cli/test_eval.py::test_evaluate_traces_with_multiple_traces_json_output
1.66s call     tests/cli/test_eval.py::test_evaluate_traces_with_trace_from_wrong_experiment
1.60s call     tests/cli/test_eval.py::test_evaluate_traces_with_nonexistent_trace

(6 durations < 0.005s hidden.  Use -vv to show these durations.)

========================= per-file durations (sorted) ==========================
::group::per-file durations (sorted)

| Rank | File                     | Duration | Tests | Min    | Max    | Avg    |
| ---- | ------------------------ | -------- | ----- | ------ | ------ | ------ |
| 1    | `tests/cli/test_eval.py` | 6.81s    | 4     | 1.603s | 1.854s | 1.703s |

::endgroup::

[32m============================== [32m[1m13 passed[0m[32m in 6.94s[0m[32m ==============================[0m
```

## 原始行 49 · command_execution

命令：
```
/bin/bash -lc "nl -ba mlflow/cli/genai_eval_utils.py | sed -n '95,210p'
git diff --check
git status --short"
```

退出码：`0`

输出：
```
    95	        display_value = f"rationale: {assessment.rationale}"
    96	    else:
    97	        display_value = NA_VALUE
    98	
    99	    return Cell(value=display_value, assessment=assessment)
   100	
   101	
   102	def extract_assessments_from_results(
   103	    results_df: pd.DataFrame, evaluation_run_id: str
   104	) -> list[EvalResult]:
   105	    """Extract assessments created by an evaluation run from its results table."""
   106	    output_data = []
   107	
   108	    for _, row in results_df.iterrows():
   109	        assessments = []
   110	        for assessment_data in row.get("assessments", []):
   111	            source_run_id = assessment_data.get("metadata", {}).get(
   112	                AssessmentMetadataKey.SOURCE_RUN_ID
   113	            )
   114	            if source_run_id != evaluation_run_id:
   115	                continue
   116	
   117	            feedback = assessment_data.get("feedback")
   118	            result = feedback.get("value") if isinstance(feedback, dict) else None
   119	            error = assessment_data.get("error")
   120	            assessments.append(
   121	                Assessment(
   122	                    name=assessment_data.get("assessment_name"),
   123	                    result=result,
   124	                    rationale=assessment_data.get("rationale"),
   125	                    error=str(error) if error else None,
   126	                )
   127	            )
   128	
   129	        if not assessments:
   130	            assessments.append(
   131	                Assessment(name=NA_VALUE, error="No assessments found on trace")
   132	            )
   133	
   134	        output_data.append(
   135	            EvalResult(trace_id=row.get("trace_id", "unknown"), assessments=assessments)
   136	        )
   137	
   138	    return output_data
   139	
   140	
   141	def format_table_output(output_data: list[EvalResult]) -> TableOutput:
   142	    """Format evaluation results as trace rows and assessment columns."""
   143	    assessment_names = sorted(
   144	        {
   145	            assessment.name
   146	            for result in output_data
   147	            for assessment in result.assessments
   148	            if assessment.name not in (None, NA_VALUE)
   149	        }
   150	    )
   151	    headers = ["trace_id", *assessment_names]
   152	    rows = []
   153	
   154	    for result in output_data:
   155	        assessments_by_name = {
   156	            assessment.name: assessment for assessment in result.assessments
   157	        }
   158	        rows.append(
   159	            [Cell(value=result.trace_id)]
   160	            + [
   161	                _format_assessment_cell(assessments_by_name.get(name))
   162	                for name in assessment_names
   163	            ]
   164	        )
   165	
   166	    return TableOutput(headers=headers, rows=rows)
   167	
   168	
   169	def resolve_scorers(scorer_names: list[str], experiment_id: str) -> list[Scorer]:
   170	    """Resolve built-in scorer class/snake-case names and registered scorers."""
   171	    built_in_scorers = get_all_scorers()
   172	    built_in_by_name = {
   173	        name: scorer
   174	        for scorer in built_in_scorers
   175	        for name in (scorer.__class__.__name__, scorer.name)
   176	    }
   177	
   178	    resolved_scorers = []
   179	    for scorer_name in scorer_names:
   180	        if scorer := built_in_by_name.get(scorer_name):
   181	            resolved_scorers.append(scorer)
   182	            continue
   183	
   184	        try:
   185	            resolved_scorers.append(
   186	                get_scorer(name=scorer_name, experiment_id=experiment_id)
   187	            )
   188	        except MlflowException as e:
   189	            available_scorers = ", ".join(sorted(built_in_by_name))
   190	            raise click.UsageError(
   191	                f"Scorer '{scorer_name}' not found. Available built-in scorers: "
   192	                f"{available_scorers}. Error: {e}"
   193	            ) from e
   194	
   195	    if not resolved_scorers:
   196	        raise click.UsageError("No valid scorers specified")
   197	
   198	    return resolved_scorers
   199	
   200	
   201	
   202	
   203	
   204	
   205	
   206	
   207	
   208	
   209	
   210	
 M mlflow/cli/genai_eval_utils.py
```

## 原始行 52 · command_execution

命令：
```
/bin/bash -lc 'tail -40 mlflow/cli/genai_eval_utils.py | cat -A'
```

退出码：`0`

输出：
```
            continue$
$
        try:$
            resolved_scorers.append($
                get_scorer(name=scorer_name, experiment_id=experiment_id)$
            )$
        except MlflowException as e:$
            available_scorers = ", ".join(sorted(built_in_by_name))$
            raise click.UsageError($
                f"Scorer '{scorer_name}' not found. Available built-in scorers: "$
                f"{available_scorers}. Error: {e}"$
            ) from e$
$
    if not resolved_scorers:$
        raise click.UsageError("No valid scorers specified")$
$
    return resolved_scorers$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
$
```

## 原始行 55 · command_execution

命令：
```
/bin/bash -lc 'wc -l mlflow/cli/genai_eval_utils.py'
```

退出码：`0`

输出：
```
221 mlflow/cli/genai_eval_utils.py
```

## 原始行 59 · file_change

```
{
  "id": "item_40",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/cli/genai_eval_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 62 · file_change

```
{
  "id": "item_42",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/mlflow/cli/genai_eval_utils.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc 'python -m compileall -q mlflow/cli/genai_eval_utils.py
git diff --check
tail -8 mlflow/cli/genai_eval_utils.py | cat -A
git status --short'
```

退出码：`0`

输出：
```
                f"Scorer '{scorer_name}' not found. Available built-in scorers: "$
                f"{available_scorers}. Error: {e}"$
            ) from e$
$
    if not resolved_scorers:$
        raise click.UsageError("No valid scorers specified")$
$
    return resolved_scorers$
 M mlflow/cli/genai_eval_utils.py
```

## 原始行 67 · agent_message

```
Implemented all requested interfaces in [genai_eval_utils.py](/testbed/mlflow/cli/genai_eval_utils.py:102):

- Evaluation-run assessment extraction with fallbacks and error handling
- Structured table formatting with assessment metadata preservation
- Built-in and registered scorer resolution across naming conventions

Validation:

- `13 passed` across `tests/cli/test_traces.py` and `tests/cli/test_eval.py`
- Compile and `git diff --check` succeeded
```
