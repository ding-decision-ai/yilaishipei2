# Codex baseline: mwaskom__seaborn.7001ebe7.test_plot.b645d353.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 4 · agent_message

```
I’ll inspect the masked implementations, nearby helpers, and visible tests first, then restore the interfaces and run the focused test suites.
```

## 原始行 6 · command_execution

命令：
```
/bin/bash -lc "pwd && rg -n \"class _BaseVersion|class Plot|class ThemeConfig|def add\\(|def facet\\(|def pair\\(|def scale\\(|def _repr_html_\" seaborn tests 2>/dev/null"
```

退出码：`127`

输出：
```
/testbed
```

## 原始行 8 · command_execution

命令：
```
/bin/bash -lc "rg --files | sed -n '1,240p'"
```

退出码：`0`

输出：
```
/bin/bash: line 1: rg: command not found
```

## 原始行 11 · command_execution

命令：
```
/bin/bash -lc "find . -maxdepth 3 -type f | sort | sed -n '1,260p'"
```

退出码：`0`

输出：
```
./.git/COMMIT_EDITMSG
./.git/HEAD
./.git/config
./.git/description
./.git/hooks/applypatch-msg.sample
./.git/hooks/commit-msg.sample
./.git/hooks/fsmonitor-watchman.sample
./.git/hooks/post-update.sample
./.git/hooks/pre-applypatch.sample
./.git/hooks/pre-commit.sample
./.git/hooks/pre-merge-commit.sample
./.git/hooks/pre-push.sample
./.git/hooks/pre-rebase.sample
./.git/hooks/pre-receive.sample
./.git/hooks/prepare-commit-msg.sample
./.git/hooks/push-to-checkout.sample
./.git/hooks/update.sample
./.git/index
./.git/info/exclude
./.git/logs/HEAD
./.github/CONTRIBUTING.md
./.github/dependabot.yml
./.github/workflows/ci.yaml
./.gitignore
./.pre-commit-config.yaml
./CITATION.cff
./LICENSE.md
./Makefile
./README.md
./SECURITY.md
./ci/cache_datasets.py
./ci/check_gallery.py
./ci/deps_pinned.txt
./ci/getmsfonts.sh
./doc/.gitignore
./doc/Makefile
./doc/README.md
./doc/_docstrings/FacetGrid.ipynb
./doc/_docstrings/JointGrid.ipynb
./doc/_docstrings/Makefile
./doc/_docstrings/PairGrid.ipynb
./doc/_docstrings/axes_style.ipynb
./doc/_docstrings/barplot.ipynb
./doc/_docstrings/blend_palette.ipynb
./doc/_docstrings/boxenplot.ipynb
./doc/_docstrings/boxplot.ipynb
./doc/_docstrings/catplot.ipynb
./doc/_docstrings/clustermap.ipynb
./doc/_docstrings/color_palette.ipynb
./doc/_docstrings/countplot.ipynb
./doc/_docstrings/cubehelix_palette.ipynb
./doc/_docstrings/dark_palette.ipynb
./doc/_docstrings/displot.ipynb
./doc/_docstrings/diverging_palette.ipynb
./doc/_docstrings/ecdfplot.ipynb
./doc/_docstrings/heatmap.ipynb
./doc/_docstrings/histplot.ipynb
./doc/_docstrings/hls_palette.ipynb
./doc/_docstrings/husl_palette.ipynb
./doc/_docstrings/jointplot.ipynb
./doc/_docstrings/kdeplot.ipynb
./doc/_docstrings/light_palette.ipynb
./doc/_docstrings/lineplot.ipynb
./doc/_docstrings/lmplot.ipynb
./doc/_docstrings/move_legend.ipynb
./doc/_docstrings/mpl_palette.ipynb
./doc/_docstrings/objects.Agg.ipynb
./doc/_docstrings/objects.Area.ipynb
./doc/_docstrings/objects.Band.ipynb
./doc/_docstrings/objects.Bar.ipynb
./doc/_docstrings/objects.Bars.ipynb
./doc/_docstrings/objects.Count.ipynb
./doc/_docstrings/objects.Dash.ipynb
./doc/_docstrings/objects.Dodge.ipynb
./doc/_docstrings/objects.Dot.ipynb
./doc/_docstrings/objects.Dots.ipynb
./doc/_docstrings/objects.Est.ipynb
./doc/_docstrings/objects.Hist.ipynb
./doc/_docstrings/objects.Jitter.ipynb
./doc/_docstrings/objects.KDE.ipynb
./doc/_docstrings/objects.Line.ipynb
./doc/_docstrings/objects.Lines.ipynb
./doc/_docstrings/objects.Norm.ipynb
./doc/_docstrings/objects.Path.ipynb
./doc/_docstrings/objects.Paths.ipynb
./doc/_docstrings/objects.Perc.ipynb
./doc/_docstrings/objects.Plot.add.ipynb
./doc/_docstrings/objects.Plot.config.ipynb
./doc/_docstrings/objects.Plot.facet.ipynb
./doc/_docstrings/objects.Plot.label.ipynb
./doc/_docstrings/objects.Plot.layout.ipynb
./doc/_docstrings/objects.Plot.limit.ipynb
./doc/_docstrings/objects.Plot.on.ipynb
./doc/_docstrings/objects.Plot.pair.ipynb
./doc/_docstrings/objects.Plot.scale.ipynb
./doc/_docstrings/objects.Plot.share.ipynb
./doc/_docstrings/objects.Plot.theme.ipynb
./doc/_docstrings/objects.Range.ipynb
./doc/_docstrings/objects.Shift.ipynb
./doc/_docstrings/objects.Stack.ipynb
./doc/_docstrings/objects.Text.ipynb
./doc/_docstrings/pairplot.ipynb
./doc/_docstrings/plotting_context.ipynb
./doc/_docstrings/pointplot.ipynb
./doc/_docstrings/regplot.ipynb
./doc/_docstrings/relplot.ipynb
./doc/_docstrings/residplot.ipynb
./doc/_docstrings/rugplot.ipynb
./doc/_docstrings/scatterplot.ipynb
./doc/_docstrings/set_context.ipynb
./doc/_docstrings/set_style.ipynb
./doc/_docstrings/set_theme.ipynb
./doc/_docstrings/stripplot.ipynb
./doc/_docstrings/swarmplot.ipynb
./doc/_docstrings/violinplot.ipynb
./doc/_static/copybutton.js
./doc/_static/favicon.ico
./doc/_static/favicon_old.ico
./doc/_static/logo-mark-darkbg.png
./doc/_static/logo-mark-darkbg.svg
./doc/_static/logo-mark-lightbg.png
./doc/_static/logo-mark-lightbg.svg
./doc/_static/logo-mark-whitebg.png
./doc/_static/logo-tall-darkbg.png
./doc/_static/logo-tall-darkbg.svg
./doc/_static/logo-tall-lightbg.png
./doc/_static/logo-tall-lightbg.svg
./doc/_static/logo-tall-whitebg.png
./doc/_static/logo-wide-darkbg.png
./doc/_static/logo-wide-darkbg.svg
./doc/_static/logo-wide-lightbg.png
./doc/_static/logo-wide-lightbg.svg
./doc/_static/logo-wide-whitebg.png
./doc/_templates/layout.html
./doc/_templates/version.html
./doc/_tutorial/Makefile
./doc/_tutorial/aesthetics.ipynb
./doc/_tutorial/axis_grids.ipynb
./doc/_tutorial/categorical.ipynb
./doc/_tutorial/color_palettes.ipynb
./doc/_tutorial/data_structure.ipynb
./doc/_tutorial/distributions.ipynb
./doc/_tutorial/error_bars.ipynb
./doc/_tutorial/function_overview.ipynb
./doc/_tutorial/introduction.ipynb
./doc/_tutorial/objects_interface.ipynb
./doc/_tutorial/properties.ipynb
./doc/_tutorial/regression.ipynb
./doc/_tutorial/relational.ipynb
./doc/api.rst
./doc/citing.rst
./doc/conf.py
./doc/example_thumbs/.gitkeep
./doc/faq.rst
./doc/index.rst
./doc/installing.rst
./doc/make.bat
./doc/matplotlibrc
./doc/sphinxext/gallery_generator.py
./doc/sphinxext/tutorial_builder.py
./doc/tools/extract_examples.py
./doc/tools/generate_logos.py
./doc/tools/nb_to_doc.py
./doc/tools/set_nb_kernels.py
./doc/tutorial.yaml
./doc/whatsnew/index.rst
./doc/whatsnew/v0.10.0.rst
./doc/whatsnew/v0.10.1.rst
./doc/whatsnew/v0.11.0.rst
./doc/whatsnew/v0.11.1.rst
./doc/whatsnew/v0.11.2.rst
./doc/whatsnew/v0.12.0.rst
./doc/whatsnew/v0.12.1.rst
./doc/whatsnew/v0.12.2.rst
./doc/whatsnew/v0.13.0.rst
./doc/whatsnew/v0.13.1.rst
./doc/whatsnew/v0.13.2.rst
./doc/whatsnew/v0.2.0.rst
./doc/whatsnew/v0.2.1.rst
./doc/whatsnew/v0.3.0.rst
./doc/whatsnew/v0.3.1.rst
./doc/whatsnew/v0.4.0.rst
./doc/whatsnew/v0.5.0.rst
./doc/whatsnew/v0.5.1.rst
./doc/whatsnew/v0.6.0.rst
./doc/whatsnew/v0.7.0.rst
./doc/whatsnew/v0.7.1.rst
./doc/whatsnew/v0.8.0.rst
./doc/whatsnew/v0.8.1.rst
./doc/whatsnew/v0.9.0.rst
./doc/whatsnew/v0.9.1.rst
./examples/.gitignore
./examples/anscombes_quartet.py
./examples/different_scatter_variables.py
./examples/errorband_lineplots.py
./examples/faceted_histogram.py
./examples/faceted_lineplot.py
./examples/grouped_barplot.py
./examples/grouped_boxplot.py
./examples/grouped_violinplots.py
./examples/heat_scatter.py
./examples/hexbin_marginals.py
./examples/histogram_stacked.py
./examples/horizontal_boxplot.py
./examples/jitter_stripplot.py
./examples/joint_histogram.py
./examples/joint_kde.py
./examples/kde_ridgeplot.py
./examples/large_distributions.py
./examples/layered_bivariate_plot.py
./examples/logistic_regression.py
./examples/many_facets.py
./examples/many_pairwise_correlations.py
./examples/marginal_ticks.py
./examples/multiple_bivariate_kde.py
./examples/multiple_conditional_kde.py
./examples/multiple_ecdf.py
./examples/multiple_regression.py
./examples/pair_grid_with_kde.py
./examples/paired_pointplots.py
./examples/pairgrid_dotplot.py
./examples/palette_choices.py
./examples/palette_generation.py
./examples/part_whole_bars.py
./examples/pointplot_anova.py
./examples/radial_facets.py
./examples/regression_marginals.py
./examples/residplot.py
./examples/scatter_bubbles.py
./examples/scatterplot_categorical.py
./examples/scatterplot_matrix.py
./examples/scatterplot_sizes.py
./examples/simple_violinplots.py
./examples/smooth_bivariate_kde.py
./examples/spreadsheet_heatmap.py
./examples/strip_regplot.py
./examples/structured_heatmap.py
./examples/three_variable_histogram.py
./examples/timeseries_facets.py
./examples/wide_data_lineplot.py
./examples/wide_form_violinplot.py
./licences/APPDIRS_LICENSE
./licences/HUSL_LICENSE
./licences/NUMPYDOC_LICENSE
./licences/PACKAGING_LICENSE
./licences/SCIPY_LICENSE
./pyproject.toml
./seaborn/__init__.py
./seaborn/_base.py
./seaborn/_compat.py
./seaborn/_core/__init__.py
./seaborn/_core/data.py
./seaborn/_core/exceptions.py
./seaborn/_core/groupby.py
./seaborn/_core/moves.py
./seaborn/_core/plot.py
./seaborn/_core/properties.py
./seaborn/_core/rules.py
./seaborn/_core/scales.py
./seaborn/_core/subplots.py
```

## 原始行 14 · command_execution

命令：
```
/bin/bash -lc "git status --short && grep -n \"class _BaseVersion\\|def __lt__\" seaborn/external/version.py && grep -n \"class Plot\\|    def add\\|    def facet\\|    def label\\|    def layout\\|    def limit\\|    def on\\|    def pair\\|    def scale\\|    def share\\|class ThemeConfig\\|def _repr_html_\" seaborn/_core/plot.py && find tests -type f | sort | grep -E 'version|plot|object|core' | sed -n '1,240p'"
```

退出码：`0`

输出：
```
41:    def __lt__(self, other: object) -> bool:
73:    def __lt__(self, other: object) -> bool:
134:class _BaseVersion:
144:class ThemeConfig(mpl.RcParams):
216:class PlotConfig:
253:class Plot:
974:class Plotter:
tests/_core/__init__.py
tests/_core/test_data.py
tests/_core/test_groupby.py
tests/_core/test_moves.py
tests/_core/test_properties.py
tests/_core/test_rules.py
tests/_core/test_scales.py
tests/_core/test_subplots.py
tests/test_miscplot.py
tests/test_objects.py
```

## 原始行 17 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,240p' seaborn/external/version.py && sed -n '1,380p' seaborn/_core/plot.py"
```

退出码：`0`

输出：
```
"""Extract reference documentation from the pypa/packaging source tree.

In the process of copying, some unused methods / classes were removed.
These include:

- parse()
- anything involving LegacyVersion

This software is made available under the terms of *either* of the licenses
found in LICENSE.APACHE or LICENSE.BSD. Contributions to this software is made
under the terms of *both* these licenses.

Vendored from:
- https://github.com/pypa/packaging/
- commit ba07d8287b4554754ac7178d177033ea3f75d489 (09/09/2021)
"""


# This file is dual licensed under the terms of the Apache License, Version
# 2.0, and the BSD License. See the LICENSE file in the root of this repository
# for complete details.


import collections
import itertools
import re
from typing import Callable, Optional, SupportsInt, Tuple, Union

__all__ = ["Version", "InvalidVersion", "VERSION_PATTERN"]


# Vendored from https://github.com/pypa/packaging/blob/main/packaging/_structures.py

class InfinityType:
    def __repr__(self) -> str:
        return "Infinity"

    def __hash__(self) -> int:
        return hash(repr(self))

    def __lt__(self, other: object) -> bool:
        return False

    def __le__(self, other: object) -> bool:
        return False

    def __eq__(self, other: object) -> bool:
        return isinstance(other, self.__class__)

    def __ne__(self, other: object) -> bool:
        return not isinstance(other, self.__class__)

    def __gt__(self, other: object) -> bool:
        return True

    def __ge__(self, other: object) -> bool:
        return True

    def __neg__(self: object) -> "NegativeInfinityType":
        return NegativeInfinity


Infinity = InfinityType()


class NegativeInfinityType:
    def __repr__(self) -> str:
        return "-Infinity"

    def __hash__(self) -> int:
        return hash(repr(self))

    def __lt__(self, other: object) -> bool:
        return True

    def __le__(self, other: object) -> bool:
        return True

    def __eq__(self, other: object) -> bool:
        return isinstance(other, self.__class__)

    def __ne__(self, other: object) -> bool:
        return not isinstance(other, self.__class__)

    def __gt__(self, other: object) -> bool:
        return False

    def __ge__(self, other: object) -> bool:
        return False

    def __neg__(self: object) -> InfinityType:
        return Infinity


NegativeInfinity = NegativeInfinityType()


# Vendored from https://github.com/pypa/packaging/blob/main/packaging/version.py

InfiniteTypes = Union[InfinityType, NegativeInfinityType]
PrePostDevType = Union[InfiniteTypes, Tuple[str, int]]
SubLocalType = Union[InfiniteTypes, int, str]
LocalType = Union[
    NegativeInfinityType,
    Tuple[
        Union[
            SubLocalType,
            Tuple[SubLocalType, str],
            Tuple[NegativeInfinityType, SubLocalType],
        ],
        ...,
    ],
]
CmpKey = Tuple[
    int, Tuple[int, ...], PrePostDevType, PrePostDevType, PrePostDevType, LocalType
]
LegacyCmpKey = Tuple[int, Tuple[str, ...]]
VersionComparisonMethod = Callable[
    [Union[CmpKey, LegacyCmpKey], Union[CmpKey, LegacyCmpKey]], bool
]

_Version = collections.namedtuple(
    "_Version", ["epoch", "release", "dev", "pre", "post", "local"]
)



class InvalidVersion(ValueError):
    """
    An invalid version was found, users should refer to PEP 440.
    """


class _BaseVersion:
    _key: Union[CmpKey, LegacyCmpKey]

    def __hash__(self) -> int:
        return hash(self._key)

    # Please keep the duplicated `isinstance` check
    # in the six comparisons hereunder
    # unless you find a way to avoid adding overhead function calls.






    def __le__(self, other: "_BaseVersion") -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key <= other._key

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key == other._key

    def __ge__(self, other: "_BaseVersion") -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key >= other._key

    def __gt__(self, other: "_BaseVersion") -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key > other._key

    def __ne__(self, other: object) -> bool:
        if not isinstance(other, _BaseVersion):
            return NotImplemented

        return self._key != other._key


# Deliberately not anchored to the start and end of the string, to make it
# easier for 3rd party code to reuse
VERSION_PATTERN = r"""
    v?
    (?:
        (?:(?P<epoch>[0-9]+)!)?                           # epoch
        (?P<release>[0-9]+(?:\.[0-9]+)*)                  # release segment
        (?P<pre>                                          # pre-release
            [-_\.]?
            (?P<pre_l>(a|b|c|rc|alpha|beta|pre|preview))
            [-_\.]?
            (?P<pre_n>[0-9]+)?
        )?
        (?P<post>                                         # post release
            (?:-(?P<post_n1>[0-9]+))
            |
            (?:
                [-_\.]?
                (?P<post_l>post|rev|r)
                [-_\.]?
                (?P<post_n2>[0-9]+)?
            )
        )?
        (?P<dev>                                          # dev release
            [-_\.]?
            (?P<dev_l>dev)
            [-_\.]?
            (?P<dev_n>[0-9]+)?
        )?
    )
    (?:\+(?P<local>[a-z0-9]+(?:[-_\.][a-z0-9]+)*))?       # local version
"""


class Version(_BaseVersion):

    _regex = re.compile(r"^\s*" + VERSION_PATTERN + r"\s*$", re.VERBOSE | re.IGNORECASE)

    def __init__(self, version: str) -> None:

        # Validate the version and parse it into pieces
        match = self._regex.search(version)
        if not match:
            raise InvalidVersion(f"Invalid version: '{version}'")

        # Store the parsed out pieces of the version
        self._version = _Version(
            epoch=int(match.group("epoch")) if match.group("epoch") else 0,
            release=tuple(int(i) for i in match.group("release").split(".")),
            pre=_parse_letter_version(match.group("pre_l"), match.group("pre_n")),
            post=_parse_letter_version(
                match.group("post_l"), match.group("post_n1") or match.group("post_n2")
            ),
            dev=_parse_letter_version(match.group("dev_l"), match.group("dev_n")),
            local=_parse_local_version(match.group("local")),
        )

        # Generate a key which will be used for sorting
        self._key = _cmpkey(
            self._version.epoch,
            self._version.release,
"""The classes for specifying and compiling a declarative visualization."""
from __future__ import annotations

import io
import os
import re
import inspect
import itertools
import textwrap
from contextlib import contextmanager
from collections import abc
from collections.abc import Callable, Generator, Mapping
from typing import Any, List, Literal, Optional, cast
from xml.etree import ElementTree

from cycler import cycler
import pandas as pd
from pandas import DataFrame, Series, Index
import matplotlib as mpl
from matplotlib.axes import Axes
from matplotlib.artist import Artist
from matplotlib.figure import Figure
import numpy as np
from PIL import Image

from seaborn._marks.base import Mark
from seaborn._stats.base import Stat
from seaborn._core.data import PlotData
from seaborn._core.moves import Move
from seaborn._core.scales import Scale
from seaborn._core.subplots import Subplots
from seaborn._core.groupby import GroupBy
from seaborn._core.properties import PROPERTIES, Property
from seaborn._core.typing import (
    DataSource,
    VariableSpec,
    VariableSpecList,
    OrderSpec,
    Default,
)
from seaborn._core.exceptions import PlotSpecError
from seaborn._core.rules import categorical_order
from seaborn._compat import get_layout_engine, set_layout_engine
from seaborn.utils import _version_predates
from seaborn.rcmod import axes_style, plotting_context
from seaborn.palettes import color_palette

from typing import TYPE_CHECKING, TypedDict
if TYPE_CHECKING:
    from matplotlib.figure import SubFigure


default = Default()


# ---- Definitions for internal specs ---------------------------------------------- #


class Layer(TypedDict, total=False):

    mark: Mark  # TODO allow list?
    stat: Stat | None  # TODO allow list?
    move: Move | list[Move] | None
    data: PlotData
    source: DataSource
    vars: dict[str, VariableSpec]
    orient: str
    legend: bool
    label: str | None


class FacetSpec(TypedDict, total=False):

    variables: dict[str, VariableSpec]
    structure: dict[str, list[str]]
    wrap: int | None


class PairSpec(TypedDict, total=False):

    variables: dict[str, VariableSpec]
    structure: dict[str, list[str]]
    cross: bool
    wrap: int | None


# --- Local helpers ---------------------------------------------------------------- #


@contextmanager
def theme_context(params: dict[str, Any]) -> Generator:
    """Temporarily modify specifc matplotlib rcParams."""
    orig_params = {k: mpl.rcParams[k] for k in params}
    color_codes = "bgrmyck"
    nice_colors = [*color_palette("deep6"), (.15, .15, .15)]
    orig_colors = [mpl.colors.colorConverter.colors[x] for x in color_codes]
    # TODO how to allow this to reflect the color cycle when relevant?
    try:
        mpl.rcParams.update(params)
        for (code, color) in zip(color_codes, nice_colors):
            mpl.colors.colorConverter.colors[code] = color
        yield
    finally:
        mpl.rcParams.update(orig_params)
        for (code, color) in zip(color_codes, orig_colors):
            mpl.colors.colorConverter.colors[code] = color


def build_plot_signature(cls):
    """
    Decorator function for giving Plot a useful signature.

    Currently this mostly saves us some duplicated typing, but we would
    like eventually to have a way of registering new semantic properties,
    at which point dynamic signature generation would become more important.

    """
    sig = inspect.signature(cls)
    params = [
        inspect.Parameter("args", inspect.Parameter.VAR_POSITIONAL),
        inspect.Parameter("data", inspect.Parameter.KEYWORD_ONLY, default=None)
    ]
    params.extend([
        inspect.Parameter(name, inspect.Parameter.KEYWORD_ONLY, default=None)
        for name in PROPERTIES
    ])
    new_sig = sig.replace(parameters=params)
    cls.__signature__ = new_sig

    known_properties = textwrap.fill(
        ", ".join([f"|{p}|" for p in PROPERTIES]),
        width=78, subsequent_indent=" " * 8,
    )

    if cls.__doc__ is not None:  # support python -OO mode
        cls.__doc__ = cls.__doc__.format(known_properties=known_properties)

    return cls


# ---- Plot configuration ---------------------------------------------------------- #


class ThemeConfig(mpl.RcParams):
    """
    Configuration object for the Plot.theme, using matplotlib rc parameters.
    """
    THEME_GROUPS = [
        "axes", "figure", "font", "grid", "hatch", "legend", "lines",
        "mathtext", "markers", "patch", "savefig", "scatter",
        "xaxis", "xtick", "yaxis", "ytick",
    ]

    def __init__(self):
        super().__init__()
        self.reset()

    @property
    def _default(self) -> dict[str, Any]:

        return {
            **self._filter_params(mpl.rcParamsDefault),
            **axes_style("darkgrid"),
            **plotting_context("notebook"),
            "axes.prop_cycle": cycler("color", color_palette("deep")),
        }

    def reset(self) -> None:
        """Update the theme dictionary with seaborn's default values."""
        self.update(self._default)

    def update(self, other: dict[str, Any] | None = None, /, **kwds):
        """Update the theme with a dictionary or keyword arguments of rc parameters."""
        if other is not None:
            theme = self._filter_params(other)
        else:
            theme = {}
        theme.update(kwds)
        super().update(theme)

    def _filter_params(self, params: dict[str, Any]) -> dict[str, Any]:
        """Restruct to thematic rc params."""
        return {
            k: v for k, v in params.items()
            if any(k.startswith(p) for p in self.THEME_GROUPS)
        }






















class DisplayConfig(TypedDict):
    """Configuration for IPython's rich display hooks."""
    format: Literal["png", "svg"]
    scaling: float
    hidpi: bool


class PlotConfig:
    """Configuration for default behavior / appearance of class:`Plot` instances."""
    def __init__(self):

        self._theme = ThemeConfig()
        self._display = {"format": "png", "scaling": .85, "hidpi": True}

    @property
    def theme(self) -> dict[str, Any]:
        """
        Dictionary of base theme parameters for :class:`Plot`.

        Keys and values correspond to matplotlib rc params, as documented here:
        https://matplotlib.org/stable/tutorials/introductory/customizing.html

        """
        return self._theme

    @property
    def display(self) -> DisplayConfig:
        """
        Dictionary of parameters for rich display in Jupyter notebook.

        Valid parameters:

        - format ("png" or "svg"): Image format to produce
        - scaling (float): Relative scaling of embedded image
        - hidpi (bool): When True, double the DPI while preserving the size

        """
        return self._display


# ---- The main interface for declarative plotting --------------------------------- #


@build_plot_signature
class Plot:
    """
    An interface for declaratively specifying statistical graphics.

    Plots are constructed by initializing this class and adding one or more
    layers, comprising a `Mark` and optional `Stat` or `Move`.  Additionally,
    faceting variables or variable pairings may be defined to divide the space
    into multiple subplots. The mappings from data values to visual properties
    can be parametrized using scales, although the plot will try to infer good
    defaults when scales are not explicitly defined.

    The constructor accepts a data source (a :class:`pandas.DataFrame` or
    dictionary with columnar values) and variable assignments. Variables can be
    passed as keys to the data source or directly as data vectors.  If multiple
    data-containing objects are provided, they will be index-aligned.

    The data source and variables defined in the constructor will be used for
    all layers in the plot, unless overridden or disabled when adding a layer.

    The following variables can be defined in the constructor:
        {known_properties}

    The `data`, `x`, and `y` variables can be passed as positional arguments or
    using keywords. Whether the first positional argument is interpreted as a
    data source or `x` variable depends on its type.

    The methods of this class return a copy of the instance; use chaining to
    build up a plot through multiple calls. Methods can be called in any order.

    Most methods only add information to the plot spec; no actual processing
    happens until the plot is shown or saved. It is also possible to compile
    the plot without rendering it to access the lower-level representation.

    """
    config = PlotConfig()

    _data: PlotData
    _layers: list[Layer]

    _scales: dict[str, Scale]
    _shares: dict[str, bool | str]
    _limits: dict[str, tuple[Any, Any]]
    _labels: dict[str, str | Callable[[str], str]]
    _theme: dict[str, Any]

    _facet_spec: FacetSpec
    _pair_spec: PairSpec

    _figure_spec: dict[str, Any]
    _subplot_spec: dict[str, Any]
    _layout_spec: dict[str, Any]

    def __init__(
        self,
        *args: DataSource | VariableSpec,
        data: DataSource = None,
        **variables: VariableSpec,
    ):

        if args:
            data, variables = self._resolve_positionals(args, data, variables)

        unknown = [x for x in variables if x not in PROPERTIES]
        if unknown:
            err = f"Plot() got unexpected keyword argument(s): {', '.join(unknown)}"
            raise TypeError(err)

        self._data = PlotData(data, variables)

        self._layers = []

        self._scales = {}
        self._shares = {}
        self._limits = {}
        self._labels = {}
        self._theme = {}

        self._facet_spec = {}
        self._pair_spec = {}

        self._figure_spec = {}
        self._subplot_spec = {}
        self._layout_spec = {}

        self._target = None

    def _resolve_positionals(
        self,
        args: tuple[DataSource | VariableSpec, ...],
        data: DataSource,
        variables: dict[str, VariableSpec],
    ) -> tuple[DataSource, dict[str, VariableSpec]]:
        """Handle positional arguments, which may contain data / x / y."""
        if len(args) > 3:
            err = "Plot() accepts no more than 3 positional arguments (data, x, y)."
            raise TypeError(err)

        if (
            isinstance(args[0], (abc.Mapping, pd.DataFrame))
            or hasattr(args[0], "__dataframe__")
        ):
            if data is not None:
                raise TypeError("`data` given by both name and position.")
            data, args = args[0], args[1:]

        if len(args) == 2:
            x, y = args
        elif len(args) == 1:
            x, y = *args, None
        else:
            x = y = None

        for name, var in zip("yx", (y, x)):
            if var is not None:
                if name in variables:
                    raise TypeError(f"`{name}` given by both name and position.")
                # Keep coordinates at the front of the variables dict
                # Cast type because we know this isn't a DataSource at this point
                variables = {name: cast(VariableSpec, var), **variables}

        return data, variables

    def __add__(self, other):

        if isinstance(other, Mark) or isinstance(other, Stat):
            raise TypeError("Sorry, this isn't ggplot! Perhaps try Plot.add?")

        other_type = other.__class__.__name__
```

## 原始行 19 · command_execution

命令：
```
/bin/bash -lc "sed -n '380,1020p' seaborn/_core/plot.py"
```

退出码：`0`

输出：
```
        other_type = other.__class__.__name__
        raise TypeError(f"Unsupported operand type(s) for +: 'Plot' and '{other_type}")

    def _repr_png_(self) -> tuple[bytes, dict[str, float]] | None:

        if Plot.config.display["format"] != "png":
            return None
        return self.plot()._repr_png_()

    def _repr_svg_(self) -> str | None:

        if Plot.config.display["format"] != "svg":
            return None
        return self.plot()._repr_svg_()

    def _clone(self) -> Plot:
        """Generate a new object with the same information as the current spec."""
        new = Plot()

        # TODO any way to enforce that data does not get mutated?
        new._data = self._data

        new._layers.extend(self._layers)

        new._scales.update(self._scales)
        new._shares.update(self._shares)
        new._limits.update(self._limits)
        new._labels.update(self._labels)
        new._theme.update(self._theme)

        new._facet_spec.update(self._facet_spec)
        new._pair_spec.update(self._pair_spec)

        new._figure_spec.update(self._figure_spec)
        new._subplot_spec.update(self._subplot_spec)
        new._layout_spec.update(self._layout_spec)

        new._target = self._target

        return new

    def _theme_with_defaults(self) -> dict[str, Any]:

        theme = self.config.theme.copy()
        theme.update(self._theme)
        return theme

    @property
    def _variables(self) -> list[str]:

        variables = (
            list(self._data.frame)
            + list(self._pair_spec.get("variables", []))
            + list(self._facet_spec.get("variables", []))
        )
        for layer in self._layers:
            variables.extend(v for v in layer["vars"] if v not in variables)

        # Coerce to str in return to appease mypy; we know these will only
        # ever be strings but I don't think we can type a DataFrame that way yet
        return [str(v) for v in variables]




































































































































































































































































    # TODO def twin()?






























































































































































    # TODO def legend (ugh)

    def theme(self, config: Mapping[str, Any], /) -> Plot:
        """
        Control the appearance of elements in the plot.

        .. note::

            The API for customizing plot appearance is not yet finalized.
            Currently, the only valid argument is a dict of matplotlib rc parameters.
            (This dict must be passed as a positional argument.)

            It is likely that this method will be enhanced in future releases.

        Matplotlib rc parameters are documented on the following page:
        https://matplotlib.org/stable/tutorials/introductory/customizing.html

        Examples
        --------
        .. include:: ../docstrings/objects.Plot.theme.rst

        """
        new = self._clone()

        rc = mpl.RcParams(config)
        new._theme.update(rc)

        return new

    def save(self, loc, **kwargs) -> Plot:
        """
        Compile the plot and write it to a buffer or file on disk.

        Parameters
        ----------
        loc : str, path, or buffer
            Location on disk to save the figure, or a buffer to write into.
        kwargs
            Other keyword arguments are passed through to
            :meth:`matplotlib.figure.Figure.savefig`.

        """
        # TODO expose important keyword arguments in our signature?
        with theme_context(self._theme_with_defaults()):
            self._plot().save(loc, **kwargs)
        return self

    def show(self, **kwargs) -> None:
        """
        Compile the plot and display it by hooking into pyplot.

        Calling this method is not necessary to render a plot in notebook context,
        but it may be in other environments (e.g., in a terminal). After compiling the
        plot, it calls :func:`matplotlib.pyplot.show` (passing any keyword parameters).

        Unlike other :class:`Plot` methods, there is no return value. This should be
        the last method you call when specifying a plot.

        """
        # TODO make pyplot configurable at the class level, and when not using,
        # import IPython.display and call on self to populate cell output?

        # Keep an eye on whether matplotlib implements "attaching" an existing
        # figure to pyplot: https://github.com/matplotlib/matplotlib/pull/14024

        self.plot(pyplot=True).show(**kwargs)

    def plot(self, pyplot: bool = False) -> Plotter:
        """
        Compile the plot spec and return the Plotter object.
        """
        with theme_context(self._theme_with_defaults()):
            return self._plot(pyplot)

    def _plot(self, pyplot: bool = False) -> Plotter:

        # TODO if we have _target object, pyplot should be determined by whether it
        # is hooked into the pyplot state machine (how do we check?)

        plotter = Plotter(pyplot=pyplot, theme=self._theme_with_defaults())

        # Process the variable assignments and initialize the figure
        common, layers = plotter._extract_data(self)
        plotter._setup_figure(self, common, layers)

        # Process the scale spec for coordinate variables and transform their data
        coord_vars = [v for v in self._variables if re.match(r"^x|y", v)]
        plotter._setup_scales(self, common, layers, coord_vars)

        # Apply statistical transform(s)
        plotter._compute_stats(self, layers)

        # Process scale spec for semantic variables and coordinates computed by stat
        plotter._setup_scales(self, common, layers)

        # TODO Remove these after updating other methods
        # ---- Maybe have debug= param that attaches these when True?
        plotter._data = common
        plotter._layers = layers

        # Process the data for each layer and add matplotlib artists
        for layer in layers:
            plotter._plot_layer(self, layer)

        # Add various figure decorations
        plotter._make_legend(self)
        plotter._finalize_figure(self)

        return plotter


# ---- The plot compilation engine ---------------------------------------------- #


class Plotter:
    """
    Engine for compiling a :class:`Plot` spec into a Matplotlib figure.

    This class is not intended to be instantiated directly by users.

    """
    # TODO decide if we ever want these (Plot.plot(debug=True))?
    _data: PlotData
    _layers: list[Layer]
    _figure: Figure

    def __init__(self, pyplot: bool, theme: dict[str, Any]):

        self._pyplot = pyplot
        self._theme = theme
        self._legend_contents: list[tuple[
            tuple[str, str | int], list[Artist], list[str],
        ]] = []
        self._scales: dict[str, Scale] = {}

    def save(self, loc, **kwargs) -> Plotter:  # TODO type args
        kwargs.setdefault("dpi", 96)
        try:
            loc = os.path.expanduser(loc)
        except TypeError:
            # loc may be a buffer in which case that would not work
            pass
        self._figure.savefig(loc, **kwargs)
        return self

    def show(self, **kwargs) -> None:
        """
        Display the plot by hooking into pyplot.

        This method calls :func:`matplotlib.pyplot.show` with any keyword parameters.

        """
        # TODO if we did not create the Plotter with pyplot, is it possible to do this?
        # If not we should clearly raise.
        import matplotlib.pyplot as plt
        with theme_context(self._theme):
            plt.show(**kwargs)

    # TODO API for accessing the underlying matplotlib objects
    # TODO what else is useful in the public API for this class?
```

## 原始行 21 · agent_message

```
The targeted methods are fully masked rather than partially broken. I’m mapping their expected internal spec shapes from the compiler and tests so the restoration remains compatible with the rest of this repository.
```

## 原始行 23 · command_execution

命令：
```
/bin/bash -lc "grep -n \"Plot\\|ThemeConfig\\|facet\\|pair\\|scale(\\|share(\\|limit(\\|layout(\\|\\.on(\\|\\.add(\" tests/test_objects.py | sed -n '1,320p' && grep -R -n \"_facet_spec\\|_pair_spec\\|_layout_spec\\|_subplot_spec\\|_figure_spec\\|_shares\\|_limits\\|_labels\\|_scales\\|\\[\\\"stat\\\"\\]\\|\\[\\\"move\\\"\\]\" seaborn/_core tests/test_objects.py | sed -n '1,400p'"
```

退出码：`0`

输出：
```
2:from seaborn._core.plot import Plot
14:            assert issubclass(obj, (Plot, Mark, Stat, Move, Scale))
seaborn/_core/scales.py:212:        if name not in p._limits:
seaborn/_core/scales.py:329:        if name not in p._limits:
seaborn/_core/plot.py:292:    _scales: dict[str, Scale]
seaborn/_core/plot.py:293:    _shares: dict[str, bool | str]
seaborn/_core/plot.py:294:    _limits: dict[str, tuple[Any, Any]]
seaborn/_core/plot.py:295:    _labels: dict[str, str | Callable[[str], str]]
seaborn/_core/plot.py:298:    _facet_spec: FacetSpec
seaborn/_core/plot.py:299:    _pair_spec: PairSpec
seaborn/_core/plot.py:301:    _figure_spec: dict[str, Any]
seaborn/_core/plot.py:302:    _subplot_spec: dict[str, Any]
seaborn/_core/plot.py:303:    _layout_spec: dict[str, Any]
seaborn/_core/plot.py:324:        self._scales = {}
seaborn/_core/plot.py:325:        self._shares = {}
seaborn/_core/plot.py:326:        self._limits = {}
seaborn/_core/plot.py:327:        self._labels = {}
seaborn/_core/plot.py:330:        self._facet_spec = {}
seaborn/_core/plot.py:331:        self._pair_spec = {}
seaborn/_core/plot.py:333:        self._figure_spec = {}
seaborn/_core/plot.py:334:        self._subplot_spec = {}
seaborn/_core/plot.py:335:        self._layout_spec = {}
seaborn/_core/plot.py:404:        new._scales.update(self._scales)
seaborn/_core/plot.py:405:        new._shares.update(self._shares)
seaborn/_core/plot.py:406:        new._limits.update(self._limits)
seaborn/_core/plot.py:407:        new._labels.update(self._labels)
seaborn/_core/plot.py:410:        new._facet_spec.update(self._facet_spec)
seaborn/_core/plot.py:411:        new._pair_spec.update(self._pair_spec)
seaborn/_core/plot.py:413:        new._figure_spec.update(self._figure_spec)
seaborn/_core/plot.py:414:        new._subplot_spec.update(self._subplot_spec)
seaborn/_core/plot.py:415:        new._layout_spec.update(self._layout_spec)
seaborn/_core/plot.py:432:            + list(self._pair_spec.get("variables", []))
seaborn/_core/plot.py:433:            + list(self._facet_spec.get("variables", []))
seaborn/_core/plot.py:947:        plotter._setup_scales(self, common, layers, coord_vars)
seaborn/_core/plot.py:953:        plotter._setup_scales(self, common, layers)
seaborn/_core/plot.py:993:        self._scales: dict[str, Scale] = {}
seaborn/_core/plot.py:1075:            .join(None, p._facet_spec.get("variables"))
seaborn/_core/plot.py:1076:            .join(None, p._pair_spec.get("variables"))
seaborn/_core/plot.py:1090:            key = var if var in p._labels else var[0]
seaborn/_core/plot.py:1095:        if key in p._labels:
seaborn/_core/plot.py:1096:            manual_label = p._labels[key]
seaborn/_core/plot.py:1111:        subplot_spec = p._subplot_spec.copy()
seaborn/_core/plot.py:1112:        facet_spec = p._facet_spec.copy()
seaborn/_core/plot.py:1113:        pair_spec = p._pair_spec.copy()
seaborn/_core/plot.py:1116:            if axis in p._shares:
seaborn/_core/plot.py:1117:                subplot_spec[f"share{axis}"] = p._shares[axis]
seaborn/_core/plot.py:1128:            pair_spec, self._pyplot, p._figure_spec, p._target,
seaborn/_core/plot.py:1160:                    or not p._pair_spec.get("cross", True)
seaborn/_core/plot.py:1162:                        axis in p._pair_spec.get("structure", {})
seaborn/_core/plot.py:1163:                        and bool(p._pair_spec.get("wrap"))
seaborn/_core/plot.py:1168:                show_tick_labels = (
seaborn/_core/plot.py:1176:                    axis_obj.set_tick_params(**{f"label{side}": show_tick_labels})
seaborn/_core/plot.py:1178:                        t.set_visible(show_tick_labels)
seaborn/_core/plot.py:1187:                    if dim in p._labels:
seaborn/_core/plot.py:1196:                or (has_col or has_row) and p._facet_spec.get("wrap")
seaborn/_core/plot.py:1214:        pair_vars = spec._pair_spec.get("structure", {})
seaborn/_core/plot.py:1220:            stat = layer["stat"]
seaborn/_core/plot.py:1240:                scales = self._scales.copy()
seaborn/_core/plot.py:1268:            key = var if var in p._scales else var[0]
seaborn/_core/plot.py:1272:        if key in p._scales:
seaborn/_core/plot.py:1273:            arg = p._scales[key]
seaborn/_core/plot.py:1305:    def _setup_scales(
seaborn/_core/plot.py:1322:            variables = [v for v in variables if v not in self._scales]
seaborn/_core/plot.py:1373:                self._scales[var] = Scale._identity()
seaborn/_core/plot.py:1376:                    self._scales[var] = scale._setup(var_df[var], prop)
seaborn/_core/plot.py:1421:        move = layer["move"]
seaborn/_core/plot.py:1426:        pair_variables = p._pair_spec.get("structure", {})
seaborn/_core/plot.py:1444:                        df, orient, view, p._shares.get(orient)
seaborn/_core/plot.py:1550:            scales = self._scales.copy()
seaborn/_core/plot.py:1552:                scales["x"] = self._scales[x]
seaborn/_core/plot.py:1554:                scales["y"] = self._scales[y]
seaborn/_core/plot.py:1595:            order = getattr(self._scales[var], "order", None)
seaborn/_core/plot.py:1685:            legend_title = str(p._labels.get("legend", ""))
seaborn/_core/plot.py:1788:                if axis_key in p._limits or axis in p._limits:
seaborn/_core/plot.py:1790:                    a, b = p._limits.get(axis_key) or p._limits[axis]
seaborn/_core/plot.py:1799:                if axis_key in self._scales:  # TODO when would it not be?
seaborn/_core/plot.py:1800:                    self._scales[axis_key]._finalize(p, axis_obj)
seaborn/_core/plot.py:1802:        if (engine_name := p._layout_spec.get("engine", default)) is not default:
seaborn/_core/plot.py:1812:        if (extent := p._layout_spec.get("extent")) is not None:
```

## 原始行 26 · command_execution

命令：
```
/bin/bash -lc "find tests -type f | sort | sed -n '1,400p' && sed -n '1,260p' tests/test_objects.py && sed -n '1020,1470p' seaborn/_core/plot.py && sed -n '1740,1840p' seaborn/_core/plot.py"
```

退出码：`0`

输出：
```
tests/__init__.py
tests/_core/__init__.py
tests/_core/test_data.py
tests/_core/test_groupby.py
tests/_core/test_moves.py
tests/_core/test_properties.py
tests/_core/test_rules.py
tests/_core/test_scales.py
tests/_core/test_subplots.py
tests/_marks/__init__.py
tests/_marks/test_area.py
tests/_marks/test_bar.py
tests/_marks/test_base.py
tests/_marks/test_dot.py
tests/_marks/test_line.py
tests/_marks/test_text.py
tests/_stats/__init__.py
tests/_stats/test_aggregation.py
tests/_stats/test_counting.py
tests/_stats/test_density.py
tests/_stats/test_order.py
tests/_stats/test_regression.py
tests/conftest.py
tests/test_algorithms.py
tests/test_axisgrid.py
tests/test_base.py
tests/test_categorical.py
tests/test_distributions.py
tests/test_docstrings.py
tests/test_matrix.py
tests/test_miscplot.py
tests/test_objects.py
tests/test_palettes.py
tests/test_rcmod.py
tests/test_regression.py
tests/test_relational.py
tests/test_statistics.py
tests/test_utils.py
import seaborn.objects
from seaborn._core.plot import Plot
from seaborn._core.moves import Move
from seaborn._core.scales import Scale
from seaborn._marks.base import Mark
from seaborn._stats.base import Stat


def test_objects_namespace():

    for name in dir(seaborn.objects):
        if not name.startswith("__"):
            obj = getattr(seaborn.objects, name)
            assert issubclass(obj, (Plot, Mark, Stat, Move, Scale))

    def _repr_png_(self) -> tuple[bytes, dict[str, float]] | None:

        # TODO use matplotlib backend directly instead of going through savefig?

        # TODO perhaps have self.show() flip a switch to disable this, so that
        # user does not end up with two versions of the figure in the output

        # TODO use bbox_inches="tight" like the inline backend?
        # pro: better results,  con: (sometimes) confusing results
        # Better solution would be to default (with option to change)
        # to using constrained/tight layout.

        if Plot.config.display["format"] != "png":
            return None

        buffer = io.BytesIO()

        factor = 2 if Plot.config.display["hidpi"] else 1
        scaling = Plot.config.display["scaling"] / factor
        dpi = 96 * factor  # TODO put dpi in Plot.config?

        with theme_context(self._theme):  # TODO _theme_with_defaults?
            self._figure.savefig(buffer, dpi=dpi, format="png", bbox_inches="tight")
        data = buffer.getvalue()

        w, h = Image.open(buffer).size
        metadata = {"width": w * scaling, "height": h * scaling}
        return data, metadata

    def _repr_svg_(self) -> str | None:

        if Plot.config.display["format"] != "svg":
            return None

        # TODO DPI for rasterized artists?

        scaling = Plot.config.display["scaling"]

        buffer = io.StringIO()
        with theme_context(self._theme):  # TODO _theme_with_defaults?
            self._figure.savefig(buffer, format="svg", bbox_inches="tight")

        root = ElementTree.fromstring(buffer.getvalue())
        w = scaling * float(root.attrib["width"][:-2])
        h = scaling * float(root.attrib["height"][:-2])
        root.attrib.update(width=f"{w}pt", height=f"{h}pt", viewbox=f"0 0 {w} {h}")
        ElementTree.ElementTree(root).write(out := io.BytesIO())

        return out.getvalue().decode()

    def _extract_data(self, p: Plot) -> tuple[PlotData, list[Layer]]:

        common_data = (
            p._data
            .join(None, p._facet_spec.get("variables"))
            .join(None, p._pair_spec.get("variables"))
        )

        layers: list[Layer] = []
        for layer in p._layers:
            spec = layer.copy()
            spec["data"] = common_data.join(layer.get("source"), layer.get("vars"))
            layers.append(spec)

        return common_data, layers

    def _resolve_label(self, p: Plot, var: str, auto_label: str | None) -> str:

        if re.match(r"[xy]\d+", var):
            key = var if var in p._labels else var[0]
        else:
            key = var

        label: str
        if key in p._labels:
            manual_label = p._labels[key]
            if callable(manual_label) and auto_label is not None:
                label = manual_label(auto_label)
            else:
                label = cast(str, manual_label)
        elif auto_label is None:
            label = ""
        else:
            label = auto_label
        return label

    def _setup_figure(self, p: Plot, common: PlotData, layers: list[Layer]) -> None:

        # --- Parsing the faceting/pairing parameterization to specify figure grid

        subplot_spec = p._subplot_spec.copy()
        facet_spec = p._facet_spec.copy()
        pair_spec = p._pair_spec.copy()

        for axis in "xy":
            if axis in p._shares:
                subplot_spec[f"share{axis}"] = p._shares[axis]

        for dim in ["col", "row"]:
            if dim in common.frame and dim not in facet_spec["structure"]:
                order = categorical_order(common.frame[dim])
                facet_spec["structure"][dim] = order

        self._subplots = subplots = Subplots(subplot_spec, facet_spec, pair_spec)

        # --- Figure initialization
        self._figure = subplots.init_figure(
            pair_spec, self._pyplot, p._figure_spec, p._target,
        )

        # --- Figure annotation
        for sub in subplots:
            ax = sub["ax"]
            for axis in "xy":
                axis_key = sub[axis]

                # ~~ Axis labels

                # TODO Should we make it possible to use only one x/y label for
                # all rows/columns in a faceted plot? Maybe using sub{axis}label,
                # although the alignments of the labels from that method leaves
                # something to be desired (in terms of how it defines 'centered').
                names = [
                    common.names.get(axis_key),
                    *(layer["data"].names.get(axis_key) for layer in layers)
                ]
                auto_label = next((name for name in names if name is not None), None)
                label = self._resolve_label(p, axis_key, auto_label)
                ax.set(**{f"{axis}label": label})

                # ~~ Decoration visibility

                # TODO there should be some override (in Plot.layout?) so that
                # axis / tick labels can be shown on interior shared axes if desired

                axis_obj = getattr(ax, f"{axis}axis")
                visible_side = {"x": "bottom", "y": "left"}.get(axis)
                show_axis_label = (
                    sub[visible_side]
                    or not p._pair_spec.get("cross", True)
                    or (
                        axis in p._pair_spec.get("structure", {})
                        and bool(p._pair_spec.get("wrap"))
                    )
                )
                axis_obj.get_label().set_visible(show_axis_label)

                show_tick_labels = (
                    show_axis_label
                    or subplot_spec.get(f"share{axis}") not in (
                        True, "all", {"x": "col", "y": "row"}[axis]
                    )
                )
                for group in ("major", "minor"):
                    side = {"x": "bottom", "y": "left"}[axis]
                    axis_obj.set_tick_params(**{f"label{side}": show_tick_labels})
                    for t in getattr(axis_obj, f"get_{group}ticklabels")():
                        t.set_visible(show_tick_labels)

            # TODO we want right-side titles for row facets in most cases?
            # Let's have what we currently call "margin titles" but properly using the
            # ax.set_title interface (see my gist)
            title_parts = []
            for dim in ["col", "row"]:
                if sub[dim] is not None:
                    val = self._resolve_label(p, "title", f"{sub[dim]}")
                    if dim in p._labels:
                        key = self._resolve_label(p, dim, common.names.get(dim))
                        val = f"{key} {val}"
                    title_parts.append(val)

            has_col = sub["col"] is not None
            has_row = sub["row"] is not None
            show_title = (
                has_col and has_row
                or (has_col or has_row) and p._facet_spec.get("wrap")
                or (has_col and sub["top"])
                # TODO or has_row and sub["right"] and <right titles>
                or has_row  # TODO and not <right titles>
            )
            if title_parts:
                title = " | ".join(title_parts)
                title_text = ax.set_title(title)
                title_text.set_visible(show_title)
            elif not (has_col or has_row):
                title = self._resolve_label(p, "title", None)
                title_text = ax.set_title(title)

    def _compute_stats(self, spec: Plot, layers: list[Layer]) -> None:

        grouping_vars = [v for v in PROPERTIES if v not in "xy"]
        grouping_vars += ["col", "row", "group"]

        pair_vars = spec._pair_spec.get("structure", {})

        for layer in layers:

            data = layer["data"]
            mark = layer["mark"]
            stat = layer["stat"]

            if stat is None:
                continue

            iter_axes = itertools.product(*[
                pair_vars.get(axis, [axis]) for axis in "xy"
            ])

            old = data.frame

            if pair_vars:
                data.frames = {}
                data.frame = data.frame.iloc[:0]  # TODO to simplify typing

            for coord_vars in iter_axes:

                pairings = "xy", coord_vars

                df = old.copy()
                scales = self._scales.copy()

                for axis, var in zip(*pairings):
                    if axis != var:
                        df = df.rename(columns={var: axis})
                        drop_cols = [x for x in df if re.match(rf"{axis}\d+", str(x))]
                        df = df.drop(drop_cols, axis=1)
                        scales[axis] = scales[var]

                orient = layer["orient"] or mark._infer_orient(scales)

                if stat.group_by_orient:
                    grouper = [orient, *grouping_vars]
                else:
                    grouper = grouping_vars
                groupby = GroupBy(grouper)
                res = stat(df, groupby, orient, scales)

                if pair_vars:
                    data.frames[coord_vars] = res
                else:
                    data.frame = res

    def _get_scale(
        self, p: Plot, var: str, prop: Property, values: Series
    ) -> Scale:

        if re.match(r"[xy]\d+", var):
            key = var if var in p._scales else var[0]
        else:
            key = var

        if key in p._scales:
            arg = p._scales[key]
            if arg is None or isinstance(arg, Scale):
                scale = arg
            else:
                scale = prop.infer_scale(arg, values)
        else:
            scale = prop.default_scale(values)

        return scale

    def _get_subplot_data(self, df, var, view, share_state):

        if share_state in [True, "all"]:
            # The all-shared case is easiest, every subplot sees all the data
            seed_values = df[var]
        else:
            # Otherwise, we need to setup separate scales for different subplots
            if share_state in [False, "none"]:
                # Fully independent axes are also easy: use each subplot's data
                idx = self._get_subplot_index(df, view)
            elif share_state in df:
                # Sharing within row/col is more complicated
                use_rows = df[share_state] == view[share_state]
                idx = df.index[use_rows]
            else:
                # This configuration doesn't make much sense, but it's fine
                idx = df.index

            seed_values = df.loc[idx, var]

        return seed_values

    def _setup_scales(
        self,
        p: Plot,
        common: PlotData,
        layers: list[Layer],
        variables: list[str] | None = None,
    ) -> None:

        if variables is None:
            # Add variables that have data but not a scale, which happens
            # because this method can be called multiple time, to handle
            # variables added during the Stat transform.
            variables = []
            for layer in layers:
                variables.extend(layer["data"].frame.columns)
                for df in layer["data"].frames.values():
                    variables.extend(str(v) for v in df if v not in variables)
            variables = [v for v in variables if v not in self._scales]

        for var in variables:

            # Determine whether this is a coordinate variable
            # (i.e., x/y, paired x/y, or derivative such as xmax)
            m = re.match(r"^(?P<coord>(?P<axis>x|y)\d*).*", var)
            if m is None:
                coord = axis = None
            else:
                coord = m["coord"]
                axis = m["axis"]

            # Get keys that handle things like x0, xmax, properly where relevant
            prop_key = var if axis is None else axis
            scale_key = var if coord is None else coord

            if prop_key not in PROPERTIES:
                continue

            # Concatenate layers, using only the relevant coordinate and faceting vars,
            # This is unnecessarily wasteful, as layer data will often be redundant.
            # But figuring out the minimal amount we need is more complicated.
            cols = [var, "col", "row"]
            parts = [common.frame.filter(cols)]
            for layer in layers:
                parts.append(layer["data"].frame.filter(cols))
                for df in layer["data"].frames.values():
                    parts.append(df.filter(cols))
            var_df = pd.concat(parts, ignore_index=True)

            prop = PROPERTIES[prop_key]
            scale = self._get_scale(p, scale_key, prop, var_df[var])

            if scale_key not in p._variables:
                # TODO this implies that the variable was added by the stat
                # It allows downstream orientation inference to work properly.
                # But it feels rather hacky, so ideally revisit.
                scale._priority = 0  # type: ignore

            if axis is None:
                # We could think about having a broader concept of (un)shared properties
                # In general, not something you want to do (different scales in facets)
                # But could make sense e.g. with paired plots. Build later.
                share_state = None
                subplots = []
            else:
                share_state = self._subplots.subplot_spec[f"share{axis}"]
                subplots = [view for view in self._subplots if view[axis] == coord]

            if scale is None:
                self._scales[var] = Scale._identity()
            else:
                try:
                    self._scales[var] = scale._setup(var_df[var], prop)
                except Exception as err:
                    raise PlotSpecError._during("Scale setup", var) from err

            if axis is None or (var != coord and coord in p._variables):
                # Everything below here applies only to coordinate variables
                continue

            # Set up an empty series to receive the transformed values.
            # We need this to handle piecemeal transforms of categories -> floats.
            transformed_data = []
            for layer in layers:
                index = layer["data"].frame.index
                empty_series = pd.Series(dtype=float, index=index, name=var)
                transformed_data.append(empty_series)

            for view in subplots:

                axis_obj = getattr(view["ax"], f"{axis}axis")
                seed_values = self._get_subplot_data(var_df, var, view, share_state)
                view_scale = scale._setup(seed_values, prop, axis=axis_obj)
                view["ax"].set(**{f"{axis}scale": view_scale._matplotlib_scale})

                for layer, new_series in zip(layers, transformed_data):
                    layer_df = layer["data"].frame
                    if var not in layer_df:
                        continue

                    idx = self._get_subplot_index(layer_df, view)
                    try:
                        new_series.loc[idx] = view_scale(layer_df.loc[idx, var])
                    except Exception as err:
                        spec_error = PlotSpecError._during("Scaling operation", var)
                        raise spec_error from err

            # Now the transformed data series are complete, update the layer data
            for layer, new_series in zip(layers, transformed_data):
                layer_df = layer["data"].frame
                if var in layer_df:
                    layer_df[var] = pd.to_numeric(new_series)

    def _plot_layer(self, p: Plot, layer: Layer) -> None:

        data = layer["data"]
        mark = layer["mark"]
        move = layer["move"]

        default_grouping_vars = ["col", "row", "group"]  # TODO where best to define?
        grouping_properties = [v for v in PROPERTIES if v[0] not in "xy"]

        pair_variables = p._pair_spec.get("structure", {})

        for subplots, df, scales in self._generate_pairings(data, pair_variables):

            orient = layer["orient"] or mark._infer_orient(scales)

            def get_order(var):
                # Ignore order for x/y: they have been scaled to numeric indices,
                # so any original order is no longer valid. Default ordering rules
                # sorted unique numbers will correctly reconstruct intended order
                # TODO This is tricky, make sure we add some tests for this
                if var not in "xy" and var in scales:
                    return getattr(scales[var], "order", None)

            if orient in df:
                width = pd.Series(index=df.index, dtype=float)
                for view in subplots:
                    view_idx = self._get_subplot_data(
                        df, orient, view, p._shares.get(orient)
                    ).index
                    view_df = df.loc[view_idx]
                    if "width" in mark._mappable_props:
                        view_width = mark._resolve(view_df, "width", None)
                    elif "width" in df:
                        view_width = view_df["width"]
                    else:
                        view_width = 0.8  # TODO what default?
                    spacing = scales[orient]._spacing(view_df.loc[view_idx, orient])
                    width.loc[view_idx] = view_width * spacing
                df["width"] = width

            if "baseline" in mark._mappable_props:
                # TODO what marks should have this?
                # If we can set baseline with, e.g., Bar(), then the
                # "other" (e.g. y for x oriented bars) parameterization
                # is somewhat ambiguous.
                baseline = mark._resolve(df, "baseline", None)
            else:
                # TODO unlike width, we might not want to add baseline to data
                # if the mark doesn't use it. Practically, there is a concern about
                # Mark abstraction like Area / Ribbon
                baseline = 0 if "baseline" not in df else df["baseline"]
            df["baseline"] = baseline

            if move is not None:
            # but will need the name in the next step to title the legend
            if key not in merged_contents:
                # Matplotlib accepts a tuple of artists and will overlay them
                new_artist_tuples = [tuple([a]) for a in new_artists]
                merged_contents[key] = new_artist_tuples, labels
            else:
                existing_artists = merged_contents[key][0]
                for i, new_artist in enumerate(new_artists):
                    existing_artists[i] += tuple([new_artist])

        # When using pyplot, an "external" legend won't be shown, so this
        # keeps it inside the axes (though still attached to the figure)
        # This is necessary because matplotlib layout engines currently don't
        # support figure legends — ideally this will change.
        loc = "center right" if self._pyplot else "center left"

        base_legend = None
        for (name, _), (handles, labels) in merged_contents.items():

            legend = mpl.legend.Legend(
                self._figure,
                handles,  # type: ignore  # matplotlib/issues/26639
                labels,
                title=name,
                loc=loc,
                bbox_to_anchor=(.98, .55),
            )

            if base_legend:
                # Matplotlib has no public API for this so it is a bit of a hack.
                # Ideally we'd define our own legend class with more flexibility,
                # but that is a lot of work!
                base_legend_box = base_legend.get_children()[0]
                this_legend_box = legend.get_children()[0]
                base_legend_box.get_children().extend(this_legend_box.get_children())
            else:
                base_legend = legend
                self._figure.legends.append(legend)

    def _finalize_figure(self, p: Plot) -> None:

        for sub in self._subplots:
            ax = sub["ax"]
            for axis in "xy":
                axis_key = sub[axis]
                axis_obj = getattr(ax, f"{axis}axis")

                # Axis limits
                if axis_key in p._limits or axis in p._limits:
                    convert_units = getattr(ax, f"{axis}axis").convert_units
                    a, b = p._limits.get(axis_key) or p._limits[axis]
                    lo = a if a is None else convert_units(a)
                    hi = b if b is None else convert_units(b)
                    if isinstance(a, str):
                        lo = cast(float, lo) - 0.5
                    if isinstance(b, str):
                        hi = cast(float, hi) + 0.5
                    ax.set(**{f"{axis}lim": (lo, hi)})

                if axis_key in self._scales:  # TODO when would it not be?
                    self._scales[axis_key]._finalize(p, axis_obj)

        if (engine_name := p._layout_spec.get("engine", default)) is not default:
            # None is a valid arg for Figure.set_layout_engine, hence `default`
            set_layout_engine(self._figure, engine_name)
        elif p._target is None:
            # Don't modify the layout engine if the user supplied their own
            # matplotlib figure and didn't specify an engine through Plot
            # TODO switch default to "constrained"?
            # TODO either way, make configurable
            set_layout_engine(self._figure, "tight")

        if (extent := p._layout_spec.get("extent")) is not None:
            engine = get_layout_engine(self._figure)
            if engine is None:
                self._figure.subplots_adjust(*extent)
            else:
                # Note the different parameterization for the layout engine rect...
                left, bottom, right, top = extent
                width, height = right - left, top - bottom
                try:
                    # The base LayoutEngine.set method doesn't have rect= so we need
                    # to avoid typechecking this statement. We also catch a TypeError
                    # as a plugin LayoutEngine may not support it either.
                    # Alternatively we could guard this with a check on the engine type,
                    # but that would make later-developed engines would un-useable.
                    engine.set(rect=[left, bottom, width, height])  # type: ignore
                except TypeError:
                    # Should we warn / raise? Note that we don't expect to get here
                    # under any normal circumstances.
                    pass
```

## 原始行 29 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,520p' seaborn/_core/subplots.py && sed -n '1,430p' seaborn/_core/scales.py && sed -n '1,360p' seaborn/_core/properties.py && sed -n '1,300p' seaborn/_core/data.py"
```

退出码：`0`

输出：
```
from __future__ import annotations
from collections.abc import Generator

import numpy as np
import matplotlib as mpl
import matplotlib.pyplot as plt

from matplotlib.axes import Axes
from matplotlib.figure import Figure
from typing import TYPE_CHECKING
if TYPE_CHECKING:  # TODO move to seaborn._core.typing?
    from seaborn._core.plot import FacetSpec, PairSpec
    from matplotlib.figure import SubFigure


class Subplots:
    """
    Interface for creating and using matplotlib subplots based on seaborn parameters.

    Parameters
    ----------
    subplot_spec : dict
        Keyword args for :meth:`matplotlib.figure.Figure.subplots`.
    facet_spec : dict
        Parameters that control subplot faceting.
    pair_spec : dict
        Parameters that control subplot pairing.
    data : PlotData
        Data used to define figure setup.

    """
    def __init__(
        self,
        subplot_spec: dict,  # TODO define as TypedDict
        facet_spec: FacetSpec,
        pair_spec: PairSpec,
    ):

        self.subplot_spec = subplot_spec

        self._check_dimension_uniqueness(facet_spec, pair_spec)
        self._determine_grid_dimensions(facet_spec, pair_spec)
        self._handle_wrapping(facet_spec, pair_spec)
        self._determine_axis_sharing(pair_spec)

    def _check_dimension_uniqueness(
        self, facet_spec: FacetSpec, pair_spec: PairSpec
    ) -> None:
        """Reject specs that pair and facet on (or wrap to) same figure dimension."""
        err = None

        facet_vars = facet_spec.get("variables", {})

        if facet_spec.get("wrap") and {"col", "row"} <= set(facet_vars):
            err = "Cannot wrap facets when specifying both `col` and `row`."
        elif (
            pair_spec.get("wrap")
            and pair_spec.get("cross", True)
            and len(pair_spec.get("structure", {}).get("x", [])) > 1
            and len(pair_spec.get("structure", {}).get("y", [])) > 1
        ):
            err = "Cannot wrap subplots when pairing on both `x` and `y`."

        collisions = {"x": ["columns", "rows"], "y": ["rows", "columns"]}
        for pair_axis, (multi_dim, wrap_dim) in collisions.items():
            if pair_axis not in pair_spec.get("structure", {}):
                continue
            elif multi_dim[:3] in facet_vars:
                err = f"Cannot facet the {multi_dim} while pairing on `{pair_axis}``."
            elif wrap_dim[:3] in facet_vars and facet_spec.get("wrap"):
                err = f"Cannot wrap the {wrap_dim} while pairing on `{pair_axis}``."
            elif wrap_dim[:3] in facet_vars and pair_spec.get("wrap"):
                err = f"Cannot wrap the {multi_dim} while faceting the {wrap_dim}."

        if err is not None:
            raise RuntimeError(err)  # TODO what err class? Define PlotSpecError?

    def _determine_grid_dimensions(
        self, facet_spec: FacetSpec, pair_spec: PairSpec
    ) -> None:
        """Parse faceting and pairing information to define figure structure."""
        self.grid_dimensions: dict[str, list] = {}
        for dim, axis in zip(["col", "row"], ["x", "y"]):

            facet_vars = facet_spec.get("variables", {})
            if dim in facet_vars:
                self.grid_dimensions[dim] = facet_spec["structure"][dim]
            elif axis in pair_spec.get("structure", {}):
                self.grid_dimensions[dim] = [
                    None for _ in pair_spec.get("structure", {})[axis]
                ]
            else:
                self.grid_dimensions[dim] = [None]

            self.subplot_spec[f"n{dim}s"] = len(self.grid_dimensions[dim])

        if not pair_spec.get("cross", True):
            self.subplot_spec["nrows"] = 1

        self.n_subplots = self.subplot_spec["ncols"] * self.subplot_spec["nrows"]

    def _handle_wrapping(
        self, facet_spec: FacetSpec, pair_spec: PairSpec
    ) -> None:
        """Update figure structure parameters based on facet/pair wrapping."""
        self.wrap = wrap = facet_spec.get("wrap") or pair_spec.get("wrap")
        if not wrap:
            return

        wrap_dim = "row" if self.subplot_spec["nrows"] > 1 else "col"
        flow_dim = {"row": "col", "col": "row"}[wrap_dim]
        n_subplots = self.subplot_spec[f"n{wrap_dim}s"]
        flow = int(np.ceil(n_subplots / wrap))

        if wrap < self.subplot_spec[f"n{wrap_dim}s"]:
            self.subplot_spec[f"n{wrap_dim}s"] = wrap
        self.subplot_spec[f"n{flow_dim}s"] = flow
        self.n_subplots = n_subplots
        self.wrap_dim = wrap_dim

    def _determine_axis_sharing(self, pair_spec: PairSpec) -> None:
        """Update subplot spec with default or specified axis sharing parameters."""
        axis_to_dim = {"x": "col", "y": "row"}
        key: str
        val: str | bool
        for axis in "xy":
            key = f"share{axis}"
            # Always use user-specified value, if present
            if key not in self.subplot_spec:
                if axis in pair_spec.get("structure", {}):
                    # Paired axes are shared along one dimension by default
                    if self.wrap is None and pair_spec.get("cross", True):
                        val = axis_to_dim[axis]
                    else:
                        val = False
                else:
                    # This will pick up faceted plots, as well as single subplot
                    # figures, where the value doesn't really matter
                    val = True
                self.subplot_spec[key] = val

    def init_figure(
        self,
        pair_spec: PairSpec,
        pyplot: bool = False,
        figure_kws: dict | None = None,
        target: Axes | Figure | SubFigure | None = None,
    ) -> Figure:
        """Initialize matplotlib objects and add seaborn-relevant metadata."""
        # TODO reduce need to pass pair_spec here?

        if figure_kws is None:
            figure_kws = {}

        if isinstance(target, mpl.axes.Axes):

            if max(self.subplot_spec["nrows"], self.subplot_spec["ncols"]) > 1:
                err = " ".join([
                    "Cannot create multiple subplots after calling `Plot.on` with",
                    f"a {mpl.axes.Axes} object.",
                    f" You may want to use a {mpl.figure.SubFigure} instead.",
                ])
                raise RuntimeError(err)

            self._subplot_list = [{
                "ax": target,
                "left": True,
                "right": True,
                "top": True,
                "bottom": True,
                "col": None,
                "row": None,
                "x": "x",
                "y": "y",
            }]
            self._figure = target.figure
            return self._figure

        elif isinstance(target, mpl.figure.SubFigure):
            figure = target.figure
        elif isinstance(target, mpl.figure.Figure):
            figure = target
        else:
            if pyplot:
                figure = plt.figure(**figure_kws)
            else:
                figure = mpl.figure.Figure(**figure_kws)
            target = figure
        self._figure = figure

        axs = target.subplots(**self.subplot_spec, squeeze=False)

        if self.wrap:
            # Remove unused Axes and flatten the rest into a (2D) vector
            axs_flat = axs.ravel({"col": "C", "row": "F"}[self.wrap_dim])
            axs, extra = np.split(axs_flat, [self.n_subplots])
            for ax in extra:
                ax.remove()
            if self.wrap_dim == "col":
                axs = axs[np.newaxis, :]
            else:
                axs = axs[:, np.newaxis]

        # Get i, j coordinates for each Axes object
        # Note that i, j are with respect to faceting/pairing,
        # not the subplot grid itself, (which only matters in the case of wrapping).
        iter_axs: np.ndenumerate | zip
        if not pair_spec.get("cross", True):
            indices = np.arange(self.n_subplots)
            iter_axs = zip(zip(indices, indices), axs.flat)
        else:
            iter_axs = np.ndenumerate(axs)

        self._subplot_list = []
        for (i, j), ax in iter_axs:

            info = {"ax": ax}

            nrows, ncols = self.subplot_spec["nrows"], self.subplot_spec["ncols"]
            if not self.wrap:
                info["left"] = j % ncols == 0
                info["right"] = (j + 1) % ncols == 0
                info["top"] = i == 0
                info["bottom"] = i == nrows - 1
            elif self.wrap_dim == "col":
                info["left"] = j % ncols == 0
                info["right"] = ((j + 1) % ncols == 0) or ((j + 1) == self.n_subplots)
                info["top"] = j < ncols
                info["bottom"] = j >= (self.n_subplots - ncols)
            elif self.wrap_dim == "row":
                info["left"] = i < nrows
                info["right"] = i >= self.n_subplots - nrows
                info["top"] = i % nrows == 0
                info["bottom"] = ((i + 1) % nrows == 0) or ((i + 1) == self.n_subplots)

            if not pair_spec.get("cross", True):
                info["top"] = j < ncols
                info["bottom"] = j >= self.n_subplots - ncols

            for dim in ["row", "col"]:
                idx = {"row": i, "col": j}[dim]
                info[dim] = self.grid_dimensions[dim][idx]

            for axis in "xy":

                idx = {"x": j, "y": i}[axis]
                if axis in pair_spec.get("structure", {}):
                    key = f"{axis}{idx}"
                else:
                    key = axis
                info[axis] = key

            self._subplot_list.append(info)

        return figure

    def __iter__(self) -> Generator[dict, None, None]:  # TODO TypedDict?
        """Yield each subplot dictionary with Axes object and metadata."""
        yield from self._subplot_list

    def __len__(self) -> int:
        """Return the number of subplots in this figure."""
        return len(self._subplot_list)
from __future__ import annotations
import re
from copy import copy
from collections.abc import Sequence
from dataclasses import dataclass
from functools import partial
from typing import Any, Callable, Tuple, Optional, ClassVar

import numpy as np
import matplotlib as mpl
from matplotlib.ticker import (
    Locator,
    Formatter,
    AutoLocator,
    AutoMinorLocator,
    FixedLocator,
    LinearLocator,
    LogLocator,
    SymmetricalLogLocator,
    MaxNLocator,
    MultipleLocator,
    EngFormatter,
    FuncFormatter,
    LogFormatterSciNotation,
    ScalarFormatter,
    StrMethodFormatter,
)
from matplotlib.dates import (
    AutoDateLocator,
    AutoDateFormatter,
    ConciseDateFormatter,
)
from matplotlib.axis import Axis
from matplotlib.scale import ScaleBase
from pandas import Series

from seaborn._core.rules import categorical_order
from seaborn._core.typing import Default, default

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from seaborn._core.plot import Plot
    from seaborn._core.properties import Property
    from numpy.typing import ArrayLike, NDArray

    TransFuncs = Tuple[
        Callable[[ArrayLike], ArrayLike], Callable[[ArrayLike], ArrayLike]
    ]

    # TODO Reverting typing to Any as it was proving too complicated to
    # work out the right way to communicate the types to mypy. Revisit!
    Pipeline = Sequence[Optional[Callable[[Any], Any]]]


class Scale:
    """Base class for objects that map data values to visual properties."""

    values: tuple | str | list | dict | None

    _priority: ClassVar[int]
    _pipeline: Pipeline
    _matplotlib_scale: ScaleBase
    _spacer: staticmethod
    _legend: tuple[list[Any], list[str]] | None

    def __post_init__(self):

        self._tick_params = None
        self._label_params = None
        self._legend = None

    def tick(self):
        raise NotImplementedError()

    def label(self):
        raise NotImplementedError()

    def _get_locators(self):
        raise NotImplementedError()

    def _get_formatter(self, locator: Locator | None = None):
        raise NotImplementedError()

    def _get_scale(self, name: str, forward: Callable, inverse: Callable):

        major_locator, minor_locator = self._get_locators(**self._tick_params)
        major_formatter = self._get_formatter(major_locator, **self._label_params)

        class InternalScale(mpl.scale.FuncScale):
            def set_default_locators_and_formatters(self, axis):
                axis.set_major_locator(major_locator)
                if minor_locator is not None:
                    axis.set_minor_locator(minor_locator)
                axis.set_major_formatter(major_formatter)

        return InternalScale(name, (forward, inverse))

    def _spacing(self, x: Series) -> float:
        space = self._spacer(x)
        if np.isnan(space):
            # This happens when there is no variance in the orient coordinate data
            # Not exactly clear what the right default is, but 1 seems reasonable?
            return 1
        return space

    def _setup(
        self, data: Series, prop: Property, axis: Axis | None = None,
    ) -> Scale:
        raise NotImplementedError()

    def _finalize(self, p: Plot, axis: Axis) -> None:
        """Perform scale-specific axis tweaks after adding artists."""
        pass

    def __call__(self, data: Series) -> ArrayLike:

        trans_data: Series | NDArray | list

        # TODO sometimes we need to handle scalars (e.g. for Line)
        # but what is the best way to do that?
        scalar_data = np.isscalar(data)
        if scalar_data:
            trans_data = np.array([data])
        else:
            trans_data = data

        for func in self._pipeline:
            if func is not None:
                trans_data = func(trans_data)

        if scalar_data:
            return trans_data[0]
        else:
            return trans_data

    @staticmethod
    def _identity():

        class Identity(Scale):
            _pipeline = []
            _spacer = None
            _legend = None
            _matplotlib_scale = None

        return Identity()


@dataclass
class Boolean(Scale):
    """
    A scale with a discrete domain of True and False values.

    The behavior is similar to the :class:`Nominal` scale, but property
    mappings and legends will use a [True, False] ordering rather than
    a sort using numeric rules. Coordinate variables accomplish this by
    inverting axis limits so as to maintain underlying numeric positioning.
    Input data are cast to boolean values, respecting missing data.

    """
    values: tuple | list | dict | None = None

    _priority: ClassVar[int] = 3

    def _setup(
        self, data: Series, prop: Property, axis: Axis | None = None,
    ) -> Scale:

        new = copy(self)
        if new._tick_params is None:
            new = new.tick()
        if new._label_params is None:
            new = new.label()

        def na_safe_cast(x):
            # TODO this doesn't actually need to be a closure
            if np.isscalar(x):
                return float(bool(x))
            else:
                if hasattr(x, "notna"):
                    # Handle pd.NA; np<>pd interop with NA is tricky
                    use = x.notna().to_numpy()
                else:
                    use = np.isfinite(x)
                out = np.full(len(x), np.nan, dtype=float)
                out[use] = x[use].astype(bool).astype(float)
                return out

        new._pipeline = [na_safe_cast, prop.get_mapping(new, data)]
        new._spacer = _default_spacer
        if prop.legend:
            new._legend = [True, False], ["True", "False"]

        forward, inverse = _make_identity_transforms()
        mpl_scale = new._get_scale(str(data.name), forward, inverse)

        axis = PseudoAxis(mpl_scale) if axis is None else axis
        mpl_scale.set_default_locators_and_formatters(axis)
        new._matplotlib_scale = mpl_scale

        return new

    def _finalize(self, p: Plot, axis: Axis) -> None:

        # We want values to appear in a True, False order but also want
        # True/False to be drawn at 1/0 positions respectively to avoid nasty
        # surprises if additional artists are added through the matplotlib API.
        # We accomplish this using axis inversion akin to what we do in Nominal.

        ax = axis.axes
        name = axis.axis_name
        axis.grid(False, which="both")
        if name not in p._limits:
            nticks = len(axis.get_major_ticks())
            lo, hi = -.5, nticks - .5
            if name == "x":
                lo, hi = hi, lo
            set_lim = getattr(ax, f"set_{name}lim")
            set_lim(lo, hi, auto=None)

    def tick(self, locator: Locator | None = None):
        new = copy(self)
        new._tick_params = {"locator": locator}
        return new

    def label(self, formatter: Formatter | None = None):
        new = copy(self)
        new._label_params = {"formatter": formatter}
        return new

    def _get_locators(self, locator):
        if locator is not None:
            return locator
        return FixedLocator([0, 1]), None

    def _get_formatter(self, locator, formatter):
        if formatter is not None:
            return formatter
        return FuncFormatter(lambda x, _: str(bool(x)))


@dataclass
class Nominal(Scale):
    """
    A categorical scale without relative importance / magnitude.
    """
    # Categorical (convert to strings), un-sortable

    values: tuple | str | list | dict | None = None
    order: list | None = None

    _priority: ClassVar[int] = 4

    def _setup(
        self, data: Series, prop: Property, axis: Axis | None = None,
    ) -> Scale:

        new = copy(self)
        if new._tick_params is None:
            new = new.tick()
        if new._label_params is None:
            new = new.label()

        # TODO flexibility over format() which isn't great for numbers / dates
        stringify = np.vectorize(format, otypes=["object"])

        units_seed = categorical_order(data, new.order)

        # TODO move to Nominal._get_scale?
        # TODO this needs some more complicated rethinking about how to pass
        # a unit dictionary down to these methods, along with how much we want
        # to invest in their API. What is it useful for tick() to do here?
        # (Ordinal may be different if we draw that contrast).
        # Any customization we do to allow, e.g., label wrapping will probably
        # require defining our own Formatter subclass.
        # We could also potentially implement auto-wrapping in an Axis subclass
        # (see Axis.draw ... it already is computing the bboxes).
        # major_locator, minor_locator = new._get_locators(**new._tick_params)
        # major_formatter = new._get_formatter(major_locator, **new._label_params)

        class CatScale(mpl.scale.LinearScale):
            def set_default_locators_and_formatters(self, axis):
                ...
                # axis.set_major_locator(major_locator)
                # if minor_locator is not None:
                #     axis.set_minor_locator(minor_locator)
                # axis.set_major_formatter(major_formatter)

        mpl_scale = CatScale(data.name)
        if axis is None:
            axis = PseudoAxis(mpl_scale)

            # TODO Currently just used in non-Coordinate contexts, but should
            # we use this to (A) set the padding we want for categorial plots
            # and (B) allow the values parameter for a Coordinate to set xlim/ylim
            axis.set_view_interval(0, len(units_seed) - 1)

        new._matplotlib_scale = mpl_scale

        # TODO array cast necessary to handle float/int mixture, which we need
        # to solve in a more systematic way probably
        # (i.e. if we have [1, 2.5], do we want [1.0, 2.5]? Unclear)
        axis.update_units(stringify(np.array(units_seed)))

        # TODO define this more centrally
        def convert_units(x):
            # TODO only do this with explicit order?
            # (But also category dtype?)
            # TODO isin fails when units_seed mixes numbers and strings (numpy error?)
            # but np.isin also does not seem any faster? (Maybe not broadcasting in C)
            # keep = x.isin(units_seed)
            keep = np.array([x_ in units_seed for x_ in x], bool)
            out = np.full(len(x), np.nan)
            out[keep] = axis.convert_units(stringify(x[keep]))
            return out

        new._pipeline = [convert_units, prop.get_mapping(new, data)]
        new._spacer = _default_spacer

        if prop.legend:
            new._legend = units_seed, list(stringify(units_seed))

        return new

    def _finalize(self, p: Plot, axis: Axis) -> None:

        ax = axis.axes
        name = axis.axis_name
        axis.grid(False, which="both")
        if name not in p._limits:
            nticks = len(axis.get_major_ticks())
            lo, hi = -.5, nticks - .5
            if name == "y":
                lo, hi = hi, lo
            set_lim = getattr(ax, f"set_{name}lim")
            set_lim(lo, hi, auto=None)

    def tick(self, locator: Locator | None = None) -> Nominal:
        """
        Configure the selection of ticks for the scale's axis or legend.

        .. note::
            This API is under construction and will be enhanced over time.
            At the moment, it is probably not very useful.

        Parameters
        ----------
        locator : :class:`matplotlib.ticker.Locator` subclass
            Pre-configured matplotlib locator; other parameters will not be used.

        Returns
        -------
        Copy of self with new tick configuration.

        """
        new = copy(self)
        new._tick_params = {"locator": locator}
        return new

    def label(self, formatter: Formatter | None = None) -> Nominal:
        """
        Configure the selection of labels for the scale's axis or legend.

        .. note::
            This API is under construction and will be enhanced over time.
            At the moment, it is probably not very useful.

        Parameters
        ----------
        formatter : :class:`matplotlib.ticker.Formatter` subclass
            Pre-configured matplotlib formatter; other parameters will not be used.

        Returns
        -------
        scale
            Copy of self with new tick configuration.

        """
        new = copy(self)
        new._label_params = {"formatter": formatter}
        return new

    def _get_locators(self, locator):

        if locator is not None:
            return locator, None

        locator = mpl.category.StrCategoryLocator({})

        return locator, None

    def _get_formatter(self, locator, formatter):

        if formatter is not None:
            return formatter

        formatter = mpl.category.StrCategoryFormatter({})

        return formatter


@dataclass
class Ordinal(Scale):
    # Categorical (convert to strings), sortable, can skip ticklabels
    ...


@dataclass
class Discrete(Scale):
    # Numeric, integral, can skip ticks/ticklabels
    ...


@dataclass
class ContinuousBase(Scale):

    values: tuple | str | None = None
    norm: tuple | None = None

    def _setup(
        self, data: Series, prop: Property, axis: Axis | None = None,
    ) -> Scale:

        new = copy(self)
        if new._tick_params is None:
            new = new.tick()
        if new._label_params is None:
            new = new.label()

        forward, inverse = new._get_transform()

from __future__ import annotations
import itertools
import warnings

import numpy as np
from numpy.typing import ArrayLike
from pandas import Series
import matplotlib as mpl
from matplotlib.colors import to_rgb, to_rgba, to_rgba_array
from matplotlib.markers import MarkerStyle
from matplotlib.path import Path

from seaborn._core.scales import Scale, Boolean, Continuous, Nominal, Temporal
from seaborn._core.rules import categorical_order, variable_type
from seaborn.palettes import QUAL_PALETTES, color_palette, blend_palette
from seaborn.utils import get_color_cycle

from typing import Any, Callable, Tuple, List, Union, Optional

RGBTuple = Tuple[float, float, float]
RGBATuple = Tuple[float, float, float, float]
ColorSpec = Union[RGBTuple, RGBATuple, str]

DashPattern = Tuple[float, ...]
DashPatternWithOffset = Tuple[float, Optional[DashPattern]]

MarkerPattern = Union[
    float,
    str,
    Tuple[int, int, float],
    List[Tuple[float, float]],
    Path,
    MarkerStyle,
]

Mapping = Callable[[ArrayLike], ArrayLike]


# =================================================================================== #
# Base classes
# =================================================================================== #


class Property:
    """Base class for visual properties that can be set directly or be data scaling."""

    # When True, scales for this property will populate the legend by default
    legend = False

    # When True, scales for this property normalize data to [0, 1] before mapping
    normed = False

    def __init__(self, variable: str | None = None):
        """Initialize the property with the name of the corresponding plot variable."""
        if not variable:
            variable = self.__class__.__name__.lower()
        self.variable = variable

    def default_scale(self, data: Series) -> Scale:
        """Given data, initialize appropriate scale class."""

        var_type = variable_type(data, boolean_type="boolean", strict_boolean=True)
        if var_type == "numeric":
            return Continuous()
        elif var_type == "datetime":
            return Temporal()
        elif var_type == "boolean":
            return Boolean()
        else:
            return Nominal()

    def infer_scale(self, arg: Any, data: Series) -> Scale:
        """Given data and a scaling argument, initialize appropriate scale class."""
        # TODO put these somewhere external for validation
        # TODO putting this here won't pick it up if subclasses define infer_scale
        # (e.g. color). How best to handle that? One option is to call super after
        # handling property-specific possibilities (e.g. for color check that the
        # arg is not a valid palette name) but that could get tricky.
        trans_args = ["log", "symlog", "logit", "pow", "sqrt"]
        if isinstance(arg, str):
            if any(arg.startswith(k) for k in trans_args):
                # TODO validate numeric type? That should happen centrally somewhere
                return Continuous(trans=arg)
            else:
                msg = f"Unknown magic arg for {self.variable} scale: '{arg}'."
                raise ValueError(msg)
        else:
            arg_type = type(arg).__name__
            msg = f"Magic arg for {self.variable} scale must be str, not {arg_type}."
            raise TypeError(msg)

    def get_mapping(self, scale: Scale, data: Series) -> Mapping:
        """Return a function that maps from data domain to property range."""
        def identity(x):
            return x
        return identity

    def standardize(self, val: Any) -> Any:
        """Coerce flexible property value to standardized representation."""
        return val

    def _check_dict_entries(self, levels: list, values: dict) -> None:
        """Input check when values are provided as a dictionary."""
        missing = set(levels) - set(values)
        if missing:
            formatted = ", ".join(map(repr, sorted(missing, key=str)))
            err = f"No entry in {self.variable} dictionary for {formatted}"
            raise ValueError(err)

    def _check_list_length(self, levels: list, values: list) -> list:
        """Input check when values are provided as a list."""
        message = ""
        if len(levels) > len(values):
            message = " ".join([
                f"\nThe {self.variable} list has fewer values ({len(values)})",
                f"than needed ({len(levels)}) and will cycle, which may",
                "produce an uninterpretable plot."
            ])
            values = [x for _, x in zip(levels, itertools.cycle(values))]

        elif len(values) > len(levels):
            message = " ".join([
                f"The {self.variable} list has more values ({len(values)})",
                f"than needed ({len(levels)}), which may not be intended.",
            ])
            values = values[:len(levels)]

        # TODO look into custom PlotSpecWarning with better formatting
        if message:
            warnings.warn(message, UserWarning)

        return values


# =================================================================================== #
# Properties relating to spatial position of marks on the plotting axes
# =================================================================================== #


class Coordinate(Property):
    """The position of visual marks with respect to the axes of the plot."""
    legend = False
    normed = False


# =================================================================================== #
# Properties with numeric values where scale range can be defined as an interval
# =================================================================================== #


class IntervalProperty(Property):
    """A numeric property where scale range can be defined as an interval."""
    legend = True
    normed = True

    _default_range: tuple[float, float] = (0, 1)

    @property
    def default_range(self) -> tuple[float, float]:
        """Min and max values used by default for semantic mapping."""
        return self._default_range

    def _forward(self, values: ArrayLike) -> ArrayLike:
        """Transform applied to native values before linear mapping into interval."""
        return values

    def _inverse(self, values: ArrayLike) -> ArrayLike:
        """Transform applied to results of mapping that returns to native values."""
        return values

    def infer_scale(self, arg: Any, data: Series) -> Scale:
        """Given data and a scaling argument, initialize appropriate scale class."""

        # TODO infer continuous based on log/sqrt etc?

        var_type = variable_type(data, boolean_type="boolean", strict_boolean=True)

        if var_type == "boolean":
            return Boolean(arg)
        elif isinstance(arg, (list, dict)):
            return Nominal(arg)
        elif var_type == "categorical":
            return Nominal(arg)
        elif var_type == "datetime":
            return Temporal(arg)
        # TODO other variable types
        else:
            return Continuous(arg)

    def get_mapping(self, scale: Scale, data: Series) -> Mapping:
        """Return a function that maps from data domain to property range."""
        if isinstance(scale, Nominal):
            return self._get_nominal_mapping(scale, data)
        elif isinstance(scale, Boolean):
            return self._get_boolean_mapping(scale, data)

        if scale.values is None:
            vmin, vmax = self._forward(self.default_range)
        elif isinstance(scale.values, tuple) and len(scale.values) == 2:
            vmin, vmax = self._forward(scale.values)
        else:
            if isinstance(scale.values, tuple):
                actual = f"{len(scale.values)}-tuple"
            else:
                actual = str(type(scale.values))
            scale_class = scale.__class__.__name__
            err = " ".join([
                f"Values for {self.variable} variables with {scale_class} scale",
                f"must be 2-tuple; not {actual}.",
            ])
            raise TypeError(err)

        def mapping(x):
            return self._inverse(np.multiply(x, vmax - vmin) + vmin)

        return mapping

    def _get_nominal_mapping(self, scale: Nominal, data: Series) -> Mapping:
        """Identify evenly-spaced values using interval or explicit mapping."""
        levels = categorical_order(data, scale.order)
        values = self._get_values(scale, levels)

        def mapping(x):
            ixs = np.asarray(x, np.intp)
            out = np.full(len(x), np.nan)
            use = np.isfinite(x)
            out[use] = np.take(values, ixs[use])
            return out

        return mapping

    def _get_boolean_mapping(self, scale: Boolean, data: Series) -> Mapping:
        """Identify evenly-spaced values using interval or explicit mapping."""
        values = self._get_values(scale, [True, False])

        def mapping(x):
            out = np.full(len(x), np.nan)
            use = np.isfinite(x)
            out[use] = np.where(x[use], *values)
            return out

        return mapping

    def _get_values(self, scale: Scale, levels: list) -> list:
        """Validate scale.values and identify a value for each level."""
        if isinstance(scale.values, dict):
            self._check_dict_entries(levels, scale.values)
            values = [scale.values[x] for x in levels]
        elif isinstance(scale.values, list):
            values = self._check_list_length(levels, scale.values)
        else:
            if scale.values is None:
                vmin, vmax = self.default_range
            elif isinstance(scale.values, tuple):
                vmin, vmax = scale.values
            else:
                scale_class = scale.__class__.__name__
                err = " ".join([
                    f"Values for {self.variable} variables with {scale_class} scale",
                    f"must be a dict, list or tuple; not {type(scale.values)}",
                ])
                raise TypeError(err)

            vmin, vmax = self._forward([vmin, vmax])
            values = list(self._inverse(np.linspace(vmax, vmin, len(levels))))

        return values


class PointSize(IntervalProperty):
    """Size (diameter) of a point mark, in points, with scaling by area."""
    _default_range = 2, 8  # TODO use rcparams?

    def _forward(self, values):
        """Square native values to implement linear scaling of point area."""
        return np.square(values)

    def _inverse(self, values):
        """Invert areal values back to point diameter."""
        return np.sqrt(values)


class LineWidth(IntervalProperty):
    """Thickness of a line mark, in points."""
    @property
    def default_range(self) -> tuple[float, float]:
        """Min and max values used by default for semantic mapping."""
        base = mpl.rcParams["lines.linewidth"]
        return base * .5, base * 2


class EdgeWidth(IntervalProperty):
    """Thickness of the edges on a patch mark, in points."""
    @property
    def default_range(self) -> tuple[float, float]:
        """Min and max values used by default for semantic mapping."""
        base = mpl.rcParams["patch.linewidth"]
        return base * .5, base * 2


class Stroke(IntervalProperty):
    """Thickness of lines that define point glyphs."""
    _default_range = .25, 2.5


class Alpha(IntervalProperty):
    """Opacity of the color values for an arbitrary mark."""
    _default_range = .3, .95
    # TODO validate / enforce that output is in [0, 1]


class Offset(IntervalProperty):
    """Offset for edge-aligned text, in point units."""
    _default_range = 0, 5
    _legend = False


class FontSize(IntervalProperty):
    """Font size for textual marks, in points."""
    _legend = False

    @property
    def default_range(self) -> tuple[float, float]:
        """Min and max values used by default for semantic mapping."""
        base = mpl.rcParams["font.size"]
        return base * .5, base * 2


# =================================================================================== #
# Properties defined by arbitrary objects with inherently nominal scaling
# =================================================================================== #


class ObjectProperty(Property):
    """A property defined by arbitrary an object, with inherently nominal scaling."""
    legend = True
    normed = False

    # Object representing null data, should appear invisible when drawn by matplotlib
    # Note that we now drop nulls in Plot._plot_layer and thus may not need this
    null_value: Any = None

    def _default_values(self, n: int) -> list:
        raise NotImplementedError()

    def default_scale(self, data: Series) -> Scale:
        var_type = variable_type(data, boolean_type="boolean", strict_boolean=True)
        return Boolean() if var_type == "boolean" else Nominal()

    def infer_scale(self, arg: Any, data: Series) -> Scale:
        var_type = variable_type(data, boolean_type="boolean", strict_boolean=True)
        return Boolean(arg) if var_type == "boolean" else Nominal(arg)

    def get_mapping(self, scale: Scale, data: Series) -> Mapping:
        """Define mapping as lookup into list of object values."""
        boolean_scale = isinstance(scale, Boolean)
        order = getattr(scale, "order", [True, False] if boolean_scale else None)
        levels = categorical_order(data, order)
        values = self._get_values(scale, levels)

"""
Components for parsing variable assignments and internally representing plot data.
"""
from __future__ import annotations

from collections.abc import Mapping, Sized
from typing import cast
import warnings

import pandas as pd
from pandas import DataFrame

from seaborn._core.typing import DataSource, VariableSpec, ColumnName
from seaborn.utils import _version_predates


class PlotData:
    """
    Data table with plot variable schema and mapping to original names.

    Contains logic for parsing variable specification arguments and updating
    the table with layer-specific data and/or mappings.

    Parameters
    ----------
    data
        Input data where variable names map to vector values.
    variables
        Keys are names of plot variables (x, y, ...) each value is one of:

        - name of a column (or index level, or dictionary entry) in `data`
        - vector in any format that can construct a :class:`pandas.DataFrame`

    Attributes
    ----------
    frame
        Data table with column names having defined plot variables.
    names
        Dictionary mapping plot variable names to names in source data structure(s).
    ids
        Dictionary mapping plot variable names to unique data source identifiers.

    """
    frame: DataFrame
    frames: dict[tuple, DataFrame]
    names: dict[str, str | None]
    ids: dict[str, str | int]
    source_data: DataSource
    source_vars: dict[str, VariableSpec]

    def __init__(
        self,
        data: DataSource,
        variables: dict[str, VariableSpec],
    ):

        data = handle_data_source(data)
        frame, names, ids = self._assign_variables(data, variables)

        self.frame = frame
        self.names = names
        self.ids = ids

        # The reason we possibly have a dictionary of frames is to support the
        # Plot.pair operation, post scaling, where each x/y variable needs its
        # own frame. This feels pretty clumsy and there are a bunch of places in
        # the client code with awkard if frame / elif frames constructions.
        # It would be great to have a cleaner abstraction here.
        self.frames = {}

        self.source_data = data
        self.source_vars = variables

    def __contains__(self, key: str) -> bool:
        """Boolean check on whether a variable is defined in this dataset."""
        if self.frame is None:
            return any(key in df for df in self.frames.values())
        return key in self.frame

    def join(
        self,
        data: DataSource,
        variables: dict[str, VariableSpec] | None,
    ) -> PlotData:
        """Add, replace, or drop variables and return as a new dataset."""
        # Inherit the original source of the upstream data by default
        if data is None:
            data = self.source_data

        # TODO allow `data` to be a function (that is called on the source data?)

        if not variables:
            variables = self.source_vars

        # Passing var=None implies that we do not want that variable in this layer
        disinherit = [k for k, v in variables.items() if v is None]

        # Create a new dataset with just the info passed here
        new = PlotData(data, variables)

        # -- Update the inherited DataSource with this new information

        drop_cols = [k for k in self.frame if k in new.frame or k in disinherit]
        parts = [self.frame.drop(columns=drop_cols), new.frame]

        # Because we are combining distinct columns, this is perhaps more
        # naturally thought of as a "merge"/"join". But using concat because
        # some simple testing suggests that it is marginally faster.
        frame = pd.concat(parts, axis=1, sort=False, copy=False)

        names = {k: v for k, v in self.names.items() if k not in disinherit}
        names.update(new.names)

        ids = {k: v for k, v in self.ids.items() if k not in disinherit}
        ids.update(new.ids)

        new.frame = frame
        new.names = names
        new.ids = ids

        # Multiple chained operations should always inherit from the original object
        new.source_data = self.source_data
        new.source_vars = self.source_vars

        return new

    def _assign_variables(
        self,
        data: DataFrame | Mapping | None,
        variables: dict[str, VariableSpec],
    ) -> tuple[DataFrame, dict[str, str | None], dict[str, str | int]]:
        """
        Assign values for plot variables given long-form data and/or vector inputs.

        Parameters
        ----------
        data
            Input data where variable names map to vector values.
        variables
            Keys are names of plot variables (x, y, ...) each value is one of:

            - name of a column (or index level, or dictionary entry) in `data`
            - vector in any format that can construct a :class:`pandas.DataFrame`

        Returns
        -------
        frame
            Table mapping seaborn variables (x, y, color, ...) to data vectors.
        names
            Keys are defined seaborn variables; values are names inferred from
            the inputs (or None when no name can be determined).
        ids
            Like the `names` dict, but `None` values are replaced by the `id()`
            of the data object that defined the variable.

        Raises
        ------
        TypeError
            When data source is not a DataFrame or Mapping.
        ValueError
            When variables are strings that don't appear in `data`, or when they are
            non-indexed vector datatypes that have a different length from `data`.

        """
        source_data: Mapping | DataFrame
        frame: DataFrame
        names: dict[str, str | None]
        ids: dict[str, str | int]

        plot_data = {}
        names = {}
        ids = {}

        given_data = data is not None
        if data is None:
            # Data is optional; all variables can be defined as vectors
            # But simplify downstream code by always having a usable source data object
            source_data = {}
        else:
            source_data = data

        # Variables can also be extracted from the index of a DataFrame
        if isinstance(source_data, pd.DataFrame):
            index = source_data.index.to_frame().to_dict("series")
        else:
            index = {}

        for key, val in variables.items():

            # Simply ignore variables with no specification
            if val is None:
                continue

            # Try to treat the argument as a key for the data collection.
            # But be flexible about what can be used as a key.
            # Usually it will be a string, but allow other hashables when
            # taking from the main data object. Allow only strings to reference
            # fields in the index, because otherwise there is too much ambiguity.

            # TODO this will be rendered unnecessary by the following pandas fix:
            # https://github.com/pandas-dev/pandas/pull/41283
            try:
                hash(val)
                val_is_hashable = True
            except TypeError:
                val_is_hashable = False

            val_as_data_key = (
                # See https://github.com/pandas-dev/pandas/pull/41283
                # (isinstance(val, abc.Hashable) and val in source_data)
                (val_is_hashable and val in source_data)
                or (isinstance(val, str) and val in index)
            )

            if val_as_data_key:
                val = cast(ColumnName, val)
                if val in source_data:
                    plot_data[key] = source_data[val]
                elif val in index:
                    plot_data[key] = index[val]
                names[key] = ids[key] = str(val)

            elif isinstance(val, str):

                # This looks like a column name but, lookup failed.

                err = f"Could not interpret value `{val}` for `{key}`. "
                if not given_data:
                    err += "Value is a string, but `data` was not passed."
                else:
                    err += "An entry with this name does not appear in `data`."
                raise ValueError(err)

            else:

                # Otherwise, assume the value somehow represents data

                # Ignore empty data structures
                if isinstance(val, Sized) and len(val) == 0:
                    continue

                # If vector has no index, it must match length of data table
                if isinstance(data, pd.DataFrame) and not isinstance(val, pd.Series):
                    if isinstance(val, Sized) and len(data) != len(val):
                        val_cls = val.__class__.__name__
                        err = (
                            f"Length of {val_cls} vectors must match length of `data`"
                            f" when both are used, but `data` has length {len(data)}"
                            f" and the vector passed to `{key}` has length {len(val)}."
                        )
                        raise ValueError(err)

                plot_data[key] = val

                # Try to infer the original name using pandas-like metadata
                if hasattr(val, "name"):
                    names[key] = ids[key] = str(val.name)  # type: ignore  # mypy/1424
                else:
                    names[key] = None
                    ids[key] = id(val)

        # Construct a tidy plot DataFrame. This will convert a number of
        # types automatically, aligning on index in case of pandas objects
        # TODO Note: this fails when variable specs *only* have scalars!
        frame = pd.DataFrame(plot_data)

        return frame, names, ids


def handle_data_source(data: object) -> pd.DataFrame | Mapping | None:
    """Convert the data source object to a common union representation."""
    if isinstance(data, pd.DataFrame) or hasattr(data, "__dataframe__"):
        # Check for pd.DataFrame inheritance could be removed once
        # minimal pandas version supports dataframe interchange (1.5.0).
        data = convert_dataframe_to_pandas(data)
    elif data is not None and not isinstance(data, Mapping):
        err = f"Data source must be a DataFrame or Mapping, not {type(data)!r}."
        raise TypeError(err)

    return data


def convert_dataframe_to_pandas(data: object) -> pd.DataFrame:
    """Use the DataFrame exchange protocol, or fail gracefully."""
    if isinstance(data, pd.DataFrame):
        return data

    if not hasattr(pd.api, "interchange"):
        msg = (
            "Support for non-pandas DataFrame objects requires a version of pandas "
            "that implements the DataFrame interchange protocol. Please upgrade "
            "your pandas version or coerce your data to pandas before passing "
            "it to seaborn."
        )
        raise TypeError(msg)

    if _version_predates(pd, "2.0.2"):
        msg = (
            "DataFrame interchange with pandas<2.0.2 has some known issues. "
            f"You are using pandas {pd.__version__}. "
```

## 原始行 32 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"_repr_html_\\|THEME_GROUPS\\|300px\\|inset\" . --exclude-dir=.git --exclude='*.ipynb' | sed -n '1,240p'; grep -R -n 'Plot(.*\\.\\|\\.facet(\\|\\.pair(\\|\\.share(\\|\\.layout(\\|\\.limit(\\|\\.scale(\\|\\.label(\\|\\.on(' doc examples tests --include='*.py' --include='*.rst' | sed -n '1,360p'"
```

退出码：`0`

输出：
```
./examples/joint_histogram.py:18:# Create an inset legend for the histogram colorbar
./tests/test_palettes.py:422:        html = pal._repr_html_()
./tests/test_palettes.py:429:        orig_repr_html = getattr(mpl.colors.Colormap, "_repr_html_", None)
./tests/test_palettes.py:434:            assert cmap._repr_html_().startswith('<img alt="Reds')
./tests/test_palettes.py:439:                mpl.colors.Colormap._repr_html_ = orig_repr_html
./seaborn/_core/plot.py:148:    THEME_GROUPS = [
./seaborn/_core/plot.py:185:            if any(k.startswith(p) for p in self.THEME_GROUPS)
./seaborn/palettes.py:80:    def _repr_html_(self):
./seaborn/palettes.py:108:    def _repr_html_(self):
./seaborn/palettes.py:119:    mpl.colors.Colormap._repr_html_ = _repr_html_
doc/sphinxext/tutorial_builder.py:230:        p.add(so.Dot(color=".3"), pointsize=x).scale(pointsize=(4, 18)),
doc/sphinxext/tutorial_builder.py:239:        p.on(ax).plot()
doc/sphinxext/tutorial_builder.py:255:    ax.text(0, .52, "Plot(data, 'x', 'y', color='var1')", size=fontsize, color=".2")
tests/_core/test_scales.py:46:        s = Continuous().label(*args, **kwargs)._setup(x, Coordinate())
tests/_core/test_scales.py:228:        s = Continuous(trans="log").label(base=None)._setup(x, Coordinate())
tests/_core/test_scales.py:320:            s.label("{x}")
tests/_core/test_scales.py:323:            s.label(like=2)
tests/_core/test_scales.py:578:        s._finalize(Plot(), ax.yaxis)
tests/_core/test_scales.py:669:        s = Temporal().label(formatter)
tests/_core/test_scales.py:678:        Temporal().label(concise=True)._setup(t, Coordinate(), ax.xaxis)
tests/_core/test_scales.py:799:        s._finalize(Plot(), ax.xaxis)
tests/_marks/test_line.py:20:        p = Plot(x=x, y=y, group=g).add(Path()).plot()
tests/_marks/test_line.py:33:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:44:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:55:        p = Plot(x=x, y=y, color=c).add(m).plot()
tests/_marks/test_line.py:69:        p = Plot(x=x, y=y, color=c, fillcolor=d).add(m).plot()
tests/_marks/test_line.py:81:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:91:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:101:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:114:        p = Plot(x=x, y=y, marker=g, linestyle=g, pointsize=g).add(m).plot()
tests/_marks/test_line.py:126:        p = Plot(x, y).add(Path()).theme(rc).plot()
tests/_marks/test_line.py:130:        p = Plot(x, y).add(Path(linestyle="--")).theme(rc).plot()
tests/_marks/test_line.py:134:        p = Plot(x, y).add(Path({"solid_capstyle": "butt"})).theme(rc).plot()
tests/_marks/test_line.py:148:        p = Plot(x=x, y=y, group=g).add(Line()).plot()
tests/_marks/test_line.py:164:        p = Plot(x=x, y=y, group=g).add(Paths()).plot()
tests/_marks/test_line.py:179:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:190:        p = Plot(x=x, y=y, color=g, linewidth=g, linestyle=g).add(Paths()).plot()
tests/_marks/test_line.py:201:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:209:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:219:            p = Plot(x, y).add(Paths()).plot()
tests/_marks/test_line.py:223:            p = Plot(x, y).add(Paths(linestyle="--")).plot()
tests/_marks/test_line.py:227:            p = Plot(x, y).add(Paths({"capstyle": "butt"})).plot()
tests/_marks/test_line.py:239:        p = Plot(x=x, y=y, group=g).add(Lines()).plot()
tests/_marks/test_line.py:254:        p = Plot(x, y).add(Lines()).plot()
tests/_marks/test_line.py:269:        p = Plot(x=x, ymin=ymin, ymax=ymax).add(Range()).plot()
tests/_marks/test_line.py:282:        p = Plot(x=x, y=y).add(Range()).plot()
tests/_marks/test_line.py:295:        p = Plot(x=x, ymin=ymin, ymax=ymax, color=group).add(Range()).plot()
tests/_marks/test_line.py:312:        p = Plot(x=x, ymin=ymin, ymax=ymax).add(m).plot()
tests/_marks/test_line.py:327:        p = Plot(x=x, y=y).add(Dash()).plot()
tests/_marks/test_line.py:341:        p = Plot(x=x, y=y, color=color).add(Dash()).plot()
tests/_marks/test_line.py:356:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_line.py:371:        p = Plot(x=x, y=y, color=color, linewidth=linewidth).add(Dash()).plot()
tests/_marks/test_line.py:386:        p = Plot(x=x, y=y).add(Dash(width=.4)).plot()
tests/_marks/test_line.py:400:        p = Plot(x=x, y=y, group=group).add(Dash(), Dodge()).plot()
tests/_marks/test_text.py:26:        p = Plot(x, y, text=s).add(Text()).plot()
tests/_marks/test_text.py:46:        p = Plot(x, y, text=s).add(m).plot()
tests/_marks/test_text.py:61:        p = Plot(x, y, color=color, fontsize=fontsize, text=s).add(Text()).plot()
tests/_marks/test_text.py:75:        p = Plot(x=x, y=x, halign=x, valign=x, text=x).add(Text()).plot()
tests/_marks/test_text.py:88:        p = Plot(x, y, text=s, fontsize=fs).add(Text()).scale(fontsize=None).plot()
tests/_marks/test_text.py:97:        p = Plot(x, y, text=s).add(Text()).plot()
tests/_marks/test_text.py:108:        p = Plot(x, y, text=s).add(m).plot()
tests/_marks/test_text.py:122:        p = Plot(x, y, text=s).add(m).plot()
tests/_marks/test_area.py:16:        p = Plot(x=x, y=y).add(Area()).plot()
tests/_marks/test_area.py:48:        p = Plot(x=x, y=y).add(mark).plot()
tests/_marks/test_area.py:71:        p = Plot(x=x, y=y, color=g, edgewidth=g).scale(color=cs).add(Area()).plot()
tests/_marks/test_area.py:95:        p = Plot(x=x, y=y).add(Area(fill=False, color=c)).plot()
tests/_marks/test_area.py:106:        p = Plot(x=x, ymin=ymin, ymax=ymax).add(Band()).plot()
tests/_marks/test_area.py:120:        p = Plot(x=x, y=y).add(Band()).plot()
tests/_marks/test_dot.py:39:        p = Plot(x=x, y=y).add(Dot()).plot()
tests/_marks/test_dot.py:55:        p = Plot(x=x, y=y).add(mark, marker=marker).scale(marker=shapes).plot()
tests/_marks/test_dot.py:71:        p = Plot(x=x, y=y).add(Dot()).plot()
tests/_marks/test_dot.py:83:        p = Plot(x=x, y=y, **{prop: z}).add(Dot()).plot()
tests/_marks/test_dot.py:95:        p = Plot(x=x, y=y).add(Dots()).plot()
tests/_marks/test_dot.py:108:        p = Plot(x=x, y=y).add(m).plot()
tests/_marks/test_dot.py:120:        p = Plot(x=x, y=y, color=c).add(Dots()).plot()
tests/_marks/test_dot.py:133:        p = Plot(x=x, y=y, color=c).add(Dots(fill=False)).plot()
tests/_marks/test_dot.py:146:        p = Plot(x=x, y=y).add(Dots(pointsize=s)).plot()
tests/_marks/test_dot.py:157:        p = Plot(x=x, y=y).add(Dots(stroke=s)).plot()
tests/_marks/test_dot.py:171:        p = Plot(x=x, y=y).add(mark, marker=marker).scale(marker=shapes).plot()
tests/_marks/test_bar.py:17:        p = Plot(**variables).add(Bar(**mark_kws), **layer_kws).plot()
tests/_marks/test_bar.py:78:        p = Plot(x, y).add(mark).plot()
tests/_marks/test_bar.py:93:        p = Plot(x, y, color=x, edgewidth=y).add(mark).plot()
tests/_marks/test_bar.py:103:        p = Plot(["a", "b", "c"], [1, 0, 2]).add(Bar()).plot()
tests/_marks/test_bar.py:109:        p = Plot(["a", "b"], [1, 2]).add(Bar({"clip_on": False})).plot()
tests/_marks/test_bar.py:130:        p = Plot(x, y).add(Bars()).plot()
tests/_marks/test_bar.py:143:        p = Plot(x=y, y=x).add(Bars(), orient="h").plot()
tests/_marks/test_bar.py:156:        p = Plot(x, y).add(Bars(width=.4)).plot()
tests/_marks/test_bar.py:167:        p = Plot(x, y, color=color).add(Bars(alpha=alpha)).plot()
tests/_marks/test_bar.py:176:        p = Plot(x, y, edgewidth=y).add(Bars()).plot()
tests/_marks/test_bar.py:186:        p0 = Plot(x0, x0).add(Bars()).plot()
tests/_marks/test_bar.py:187:        p1 = Plot(x1, x1).add(Bars()).plot()
tests/_marks/test_bar.py:196:        p = Plot(x, y).add(Bars(fill=False, edgecolor="C4")).plot()
tests/_marks/test_bar.py:207:        p = Plot(x, y).add(Bars()).scale(x="log").plot()
```

## 原始行 35 · command_execution

命令：
```
/bin/bash -lc "grep -n '"'^version'"\\|requires-python' pyproject.toml; grep -R -n \"class TestPlot\\|test_plot_\\|_layers\\|_facet_spec\\|_pair_spec\" tests --include='*.py' | sed -n '1,400p'; sed -n '1,280p' seaborn/_core/typing.py; grep -n '"'^class .*Stat'"\\|"'^class .*Move'"' seaborn/_stats/base.py seaborn/_core/moves.py"
```

退出码：`0`

输出：
```
25:requires-python = ">=3.8"
tests/_core/test_data.py:15:class TestPlotData:
tests/test_categorical.py:2960:    def test_plot_elements(self):
tests/test_categorical.py:3034:    def test_plot_colors(self):
tests/test_rcmod.py:183:class TestPlottingContext(RCParamFixtures):
tests/test_matrix.py:956:    def test_plot_dendrograms(self):
from __future__ import annotations

from collections.abc import Iterable, Mapping
from datetime import date, datetime, timedelta
from typing import Any, Optional, Union, Tuple, List, Dict

from numpy import ndarray  # TODO use ArrayLike?
from pandas import Series, Index, Timestamp, Timedelta
from matplotlib.colors import Colormap, Normalize


ColumnName = Union[
    str, bytes, date, datetime, timedelta, bool, complex, Timestamp, Timedelta
]
Vector = Union[Series, Index, ndarray]

VariableSpec = Union[ColumnName, Vector, None]
VariableSpecList = Union[List[VariableSpec], Index, None]

# A DataSource can be an object implementing __dataframe__, or a Mapping
# (and is optional in all contexts where it is used).
# I don't think there's an abc for "has __dataframe__", so we type as object
# but keep the (slightly odd) Union alias for better user-facing annotations.
DataSource = Union[object, Mapping, None]

OrderSpec = Union[Iterable, None]  # TODO technically str is iterable
NormSpec = Union[Tuple[Optional[float], Optional[float]], Normalize, None]

# TODO for discrete mappings, it would be ideal to use a parameterized type
# as the dict values / list entries should be of specific type(s) for each method
PaletteSpec = Union[str, list, dict, Colormap, None]
DiscreteValueSpec = Union[dict, list, None]
ContinuousValueSpec = Union[
    Tuple[float, float], List[float], Dict[Any, float], None,
]


class Default:
    def __repr__(self):
        return "<default>"


class Deprecated:
    def __repr__(self):
        return "<deprecated>"


default = Default()
deprecated = Deprecated()
seaborn/_stats/base.py:16:class Stat:
seaborn/_core/moves.py:16:class Move:
seaborn/_core/moves.py:28:class Jitter(Move):
seaborn/_core/moves.py:81:class Dodge(Move):
seaborn/_core/moves.py:154:class Stack(Move):
seaborn/_core/moves.py:194:class Shift(Move):
seaborn/_core/moves.py:222:class Norm(Move):
```

## 原始行 38 · command_execution

命令：
```
/bin/bash -lc "grep -R -n \"_figure_spec\\|figsize\\|layout(engine\\|extent=\" doc tests seaborn --include='*.py' --include='*.rst' | sed -n '1,300p'; grep -n \"def set_layout_engine\\|def get_layout_engine\" -A80 seaborn/_compat.py; python - <<'PY'
import matplotlib as mpl, inspect
print(mpl.__version__)
print(inspect.signature(mpl.figure.Figure.set_layout_engine))
PY"
```

退出码：`1`

输出：
```
doc/tools/generate_logos.py:187:        fig, ax = plt.subplots(figsize=(2, 2), facecolor="w", dpi=100)
doc/tools/generate_logos.py:193:        fig, axs = plt.subplots(1, 2, figsize=(8, 2), dpi=100,
doc/tools/generate_logos.py:210:        fig, axs = plt.subplots(2, 1, figsize=(2, 2.5), dpi=100,
doc/faq.rst:166:In matplotlib, you can usually set the default size for all figures through the `rc parameters <https://matplotlib.org/stable/tutorials/introductory/customizing.html>`_, specifically `figure.figsize`. And you can set the size of an individual figure when you create it (e.g. `plt.subplots(figsize=(w, h))`). If you're using an axes-level seaborn function, both of these will work as expected.
doc/sphinxext/tutorial_builder.py:101:    f = mpl.figure.Figure(figsize=(5, 5))
doc/sphinxext/tutorial_builder.py:134:    f = mpl.figure.Figure(figsize=(7, 5))
doc/sphinxext/tutorial_builder.py:184:    f = mpl.figure.Figure(figsize=(7, 5))
doc/sphinxext/tutorial_builder.py:219:    f = mpl.figure.Figure(figsize=(5, 5))
doc/sphinxext/tutorial_builder.py:248:    f = mpl.figure.Figure(figsize=(5, 4))
doc/sphinxext/tutorial_builder.py:342:    f = mpl.figure.Figure(figsize=(5, 5))
doc/sphinxext/tutorial_builder.py:354:    f = mpl.figure.Figure(figsize=(5, 5))
doc/sphinxext/gallery_generator.py:144:    fig = plt.figure(figsize=(width / dpi, height / dpi), dpi=dpi)
tests/test_distributions.py:1798:        f, ax1 = plt.subplots(figsize=(10, 5))
tests/test_distributions.py:1799:        f, ax2 = plt.subplots(figsize=(2, 5))
tests/test_distributions.py:1804:        f, ax1 = plt.subplots(figsize=(4, 5))
tests/test_distributions.py:1805:        f, ax2 = plt.subplots(figsize=(4, 5))
tests/test_distributions.py:1810:        f, ax1 = plt.subplots(figsize=(4, 5))
tests/test_distributions.py:1811:        f, ax2 = plt.subplots(figsize=(4, 5))
tests/test_matrix.py:425:        f, ax = plt.subplots(figsize=(2, 2))
tests/test_matrix.py:440:        f, ax = plt.subplots(figsize=(2, 2))
tests/test_matrix.py:713:        f, ax = plt.subplots(figsize=(2, 2))
tests/test_matrix.py:725:        f, ax = plt.subplots(figsize=(2, 2))
tests/test_matrix.py:733:        f, ax = plt.subplots(figsize=(2, 2))
tests/test_matrix.py:753:                       figsize=(10, 10), row_colors=None, col_colors=None,
tests/test_utils.py:295:    f, ax = plt.subplots(figsize=(2, 2))
seaborn/matrix.py:699:                 figsize=None, row_colors=None, col_colors=None, mask=None,
seaborn/matrix.py:715:        self._figure = plt.figure(figsize=figsize)
seaborn/matrix.py:1149:    z_score=None, standard_scale=None, figsize=(10, 10),
seaborn/matrix.py:1189:    figsize : tuple of (width, height), optional
seaborn/matrix.py:1252:    plotter = ClusterGrid(data, pivot_kws=pivot_kws, figsize=figsize,
seaborn/miscplot.py:21:    _, ax = plt.subplots(1, 1, figsize=(n * size, size))
seaborn/miscplot.py:42:    f, ax = plt.subplots(figsize=(5, 5), dpi=100)
seaborn/_core/plot.py:301:    _figure_spec: dict[str, Any]
seaborn/_core/plot.py:333:        self._figure_spec = {}
seaborn/_core/plot.py:413:        new._figure_spec.update(self._figure_spec)
seaborn/_core/plot.py:1128:            pair_spec, self._pyplot, p._figure_spec, p._target,
seaborn/axisgrid.py:436:        figsize = (ncol * height * aspect, nrow * height)
seaborn/axisgrid.py:453:            fig = plt.figure(figsize=figsize)
seaborn/axisgrid.py:1277:        figsize = len(x_vars) * height * aspect, len(y_vars) * height
seaborn/axisgrid.py:1280:            fig = plt.figure(figsize=figsize)
seaborn/axisgrid.py:1696:        f = plt.figure(figsize=(height, height))
seaborn/widgets.py:41:        f, ax = plt.subplots(figsize=(8.25, .75))
76:def set_layout_engine(
77-    fig: Figure,
78-    engine: Literal["constrained", "compressed", "tight", "none"],
79-) -> None:
80-    """Handle changes to auto layout engine interface in 3.6"""
81-    if hasattr(fig, "set_layout_engine"):
82-        fig.set_layout_engine(engine)
83-    else:
84-        # _version_predates(mpl, 3.6)
85-        if engine == "tight":
86-            fig.set_tight_layout(True)  # type: ignore  # predates typing
87-        elif engine == "constrained":
88-            fig.set_constrained_layout(True)  # type: ignore
89-        elif engine == "none":
90-            fig.set_tight_layout(False)  # type: ignore
91-            fig.set_constrained_layout(False)  # type: ignore
92-
93-
94:def get_layout_engine(fig: Figure) -> mpl.layout_engine.LayoutEngine | None:
95-    """Handle changes to auto layout engine interface in 3.6"""
96-    if hasattr(fig, "get_layout_engine"):
97-        return fig.get_layout_engine()
98-    else:
99-        # _version_predates(mpl, 3.6)
100-        return None
101-
102-
103-def share_axis(ax0, ax1, which):
104-    """Handle changes to post-hoc axis sharing."""
105-    if _version_predates(mpl, "3.5"):
106-        group = getattr(ax0, f"get_shared_{which}_axes")()
107-        group.join(ax1, ax0)
108-    else:
109-        getattr(ax1, f"share{which}")(ax0)
110-
111-
112-def get_legend_handles(legend):
113-    """Handle legendHandles attribute rename."""
114-    if _version_predates(mpl, "3.7"):
115-        return legend.legendHandles
116-    else:
117-        return legend.legend_handles
118-
119-
120-def groupby_apply_include_groups(val):
121-    if _version_predates(pd, "2.2.0"):
122-        return {}
123-    return {"include_groups": val}
124-
125-
126-def get_converter(axis):
127-    if _version_predates(mpl, "3.10.0"):
128-        return axis.converter
129-    return axis.get_converter()
3.10.7
Traceback (most recent call last):
  File "<stdin>", line 3, in <module>
  File "/opt/miniconda3/envs/testbed/lib/python3.10/site-packages/matplotlib/_api/__init__.py", line 218, in __getattr__
    raise AttributeError(
AttributeError: module 'matplotlib' has no attribute 'figure'
```

## 原始行 42 · command_execution

命令：
```
/bin/bash -lc "sed -n '1380,1590p' seaborn/_core/plot.py; grep -R -n \"Plot.add\\|Plot.facet\\|Plot.pair\\|transform.*Stat\\|must be a.*Mark\\|must be a list of variable\" doc --include='*.rst' --include='*.py' | sed -n '1,260p'; grep -R -n '\"x0\"\\|\"y0\"\\|x0\\|y0' seaborn tests --include='*.py' | sed -n '1,240p'"
```

退出码：`0`

输出：
```
            if axis is None or (var != coord and coord in p._variables):
                # Everything below here applies only to coordinate variables
                continue

            # Set up an empty series to receive the transformed values.
            # We need this to handle piecemeal transforms of categories -> floats.
            transformed_data = []
            for layer in layers:
                index = layer["data"].frame.index
                empty_series = pd.Series(dtype=float, index=index, name=var)
                transformed_data.append(empty_series)

            for view in subplots:

                axis_obj = getattr(view["ax"], f"{axis}axis")
                seed_values = self._get_subplot_data(var_df, var, view, share_state)
                view_scale = scale._setup(seed_values, prop, axis=axis_obj)
                view["ax"].set(**{f"{axis}scale": view_scale._matplotlib_scale})

                for layer, new_series in zip(layers, transformed_data):
                    layer_df = layer["data"].frame
                    if var not in layer_df:
                        continue

                    idx = self._get_subplot_index(layer_df, view)
                    try:
                        new_series.loc[idx] = view_scale(layer_df.loc[idx, var])
                    except Exception as err:
                        spec_error = PlotSpecError._during("Scaling operation", var)
                        raise spec_error from err

            # Now the transformed data series are complete, update the layer data
            for layer, new_series in zip(layers, transformed_data):
                layer_df = layer["data"].frame
                if var in layer_df:
                    layer_df[var] = pd.to_numeric(new_series)

    def _plot_layer(self, p: Plot, layer: Layer) -> None:

        data = layer["data"]
        mark = layer["mark"]
        move = layer["move"]

        default_grouping_vars = ["col", "row", "group"]  # TODO where best to define?
        grouping_properties = [v for v in PROPERTIES if v[0] not in "xy"]

        pair_variables = p._pair_spec.get("structure", {})

        for subplots, df, scales in self._generate_pairings(data, pair_variables):

            orient = layer["orient"] or mark._infer_orient(scales)

            def get_order(var):
                # Ignore order for x/y: they have been scaled to numeric indices,
                # so any original order is no longer valid. Default ordering rules
                # sorted unique numbers will correctly reconstruct intended order
                # TODO This is tricky, make sure we add some tests for this
                if var not in "xy" and var in scales:
                    return getattr(scales[var], "order", None)

            if orient in df:
                width = pd.Series(index=df.index, dtype=float)
                for view in subplots:
                    view_idx = self._get_subplot_data(
                        df, orient, view, p._shares.get(orient)
                    ).index
                    view_df = df.loc[view_idx]
                    if "width" in mark._mappable_props:
                        view_width = mark._resolve(view_df, "width", None)
                    elif "width" in df:
                        view_width = view_df["width"]
                    else:
                        view_width = 0.8  # TODO what default?
                    spacing = scales[orient]._spacing(view_df.loc[view_idx, orient])
                    width.loc[view_idx] = view_width * spacing
                df["width"] = width

            if "baseline" in mark._mappable_props:
                # TODO what marks should have this?
                # If we can set baseline with, e.g., Bar(), then the
                # "other" (e.g. y for x oriented bars) parameterization
                # is somewhat ambiguous.
                baseline = mark._resolve(df, "baseline", None)
            else:
                # TODO unlike width, we might not want to add baseline to data
                # if the mark doesn't use it. Practically, there is a concern about
                # Mark abstraction like Area / Ribbon
                baseline = 0 if "baseline" not in df else df["baseline"]
            df["baseline"] = baseline

            if move is not None:
                moves = move if isinstance(move, list) else [move]
                for move_step in moves:
                    move_by = getattr(move_step, "by", None)
                    if move_by is None:
                        move_by = grouping_properties
                    move_groupers = [*move_by, *default_grouping_vars]
                    if move_step.group_by_orient:
                        move_groupers.insert(0, orient)
                    order = {var: get_order(var) for var in move_groupers}
                    groupby = GroupBy(order)
                    df = move_step(df, groupby, orient, scales)

            df = self._unscale_coords(subplots, df, orient)

            grouping_vars = mark._grouping_props + default_grouping_vars
            split_generator = self._setup_split_generator(grouping_vars, df, subplots)

            mark._plot(split_generator, scales, orient)

        # TODO is this the right place for this?
        for view in self._subplots:
            view["ax"].autoscale_view()

        if layer["legend"]:
            self._update_legend_contents(p, mark, data, scales, layer["label"])

    def _unscale_coords(
        self, subplots: list[dict], df: DataFrame, orient: str,
    ) -> DataFrame:
        # TODO do we still have numbers in the variable name at this point?
        coord_cols = [c for c in df if re.match(r"^[xy]\D*$", str(c))]
        out_df = (
            df
            .drop(coord_cols, axis=1)
            .reindex(df.columns, axis=1)  # So unscaled columns retain their place
            .copy(deep=False)
        )

        for view in subplots:
            view_df = self._filter_subplot_data(df, view)
            axes_df = view_df[coord_cols]
            for var, values in axes_df.items():

                axis = getattr(view["ax"], f"{str(var)[0]}axis")
                # TODO see https://github.com/matplotlib/matplotlib/issues/22713
                transform = axis.get_transform().inverted().transform
                inverted = transform(values)
                out_df.loc[values.index, str(var)] = inverted

        return out_df

    def _generate_pairings(
        self, data: PlotData, pair_variables: dict,
    ) -> Generator[
        tuple[list[dict], DataFrame, dict[str, Scale]], None, None
    ]:
        # TODO retype return with subplot_spec or similar

        iter_axes = itertools.product(*[
            pair_variables.get(axis, [axis]) for axis in "xy"
        ])

        for x, y in iter_axes:

            subplots = []
            for view in self._subplots:
                if (view["x"] == x) and (view["y"] == y):
                    subplots.append(view)

            if data.frame.empty and data.frames:
                out_df = data.frames[(x, y)].copy()
            elif not pair_variables:
                out_df = data.frame.copy()
            else:
                if data.frame.empty and data.frames:
                    out_df = data.frames[(x, y)].copy()
                else:
                    out_df = data.frame.copy()

            scales = self._scales.copy()
            if x in out_df:
                scales["x"] = self._scales[x]
            if y in out_df:
                scales["y"] = self._scales[y]

            for axis, var in zip("xy", (x, y)):
                if axis != var:
                    out_df = out_df.rename(columns={var: axis})
                    cols = [col for col in out_df if re.match(rf"{axis}\d+", str(col))]
                    out_df = out_df.drop(cols, axis=1)

            yield subplots, out_df, scales

    def _get_subplot_index(self, df: DataFrame, subplot: dict) -> Index:

        dims = df.columns.intersection(["col", "row"])
        if dims.empty:
            return df.index

        keep_rows = pd.Series(True, df.index, dtype=bool)
        for dim in dims:
            keep_rows &= df[dim] == subplot[dim]
        return df.index[keep_rows]

    def _filter_subplot_data(self, df: DataFrame, subplot: dict) -> DataFrame:
        # TODO note redundancies with preceding function ... needs refactoring
        dims = df.columns.intersection(["col", "row"])
        if dims.empty:
            return df

        keep_rows = pd.Series(True, df.index, dtype=bool)
        for dim in dims:
            keep_rows &= df[dim] == subplot[dim]
        return df[keep_rows]

    def _setup_split_generator(
        self, grouping_vars: list[str], df: DataFrame, subplots: list[dict[str, Any]],
    ) -> Callable[[], Generator]:

        grouping_keys = []
doc/whatsnew/v0.13.0.rst:110:- |Feature| Added the concept of a "layer legend" in :class:`objects.Plot` via the new `label` parameter in :meth:`objects.Plot.add` (:pr:`3456`).
doc/_templates/autosummary/plot.rst:18:   ~Plot.add
doc/_templates/autosummary/plot.rst:27:   ~Plot.facet
doc/_templates/autosummary/plot.rst:28:   ~Plot.pair
seaborn/categorical.py:1135:                    (x0, x1, x2), (y0, y1, y2) = pos, val
seaborn/categorical.py:1137:                    (x0, x1, x2), (y0, y1, y2) = val, pos
seaborn/categorical.py:1153:                ax.plot(invx(x0), invy(y0), **line_kws)
seaborn/_core/plot.py:1335:            # Get keys that handle things like x0, xmax, properly where relevant
seaborn/_compat.py:103:def share_axis(ax0, ax1, which):
seaborn/_compat.py:106:        group = getattr(ax0, f"get_shared_{which}_axes")()
seaborn/_compat.py:107:        group.join(ax1, ax0)
seaborn/_compat.py:109:        getattr(ax1, f"share{which}")(ax0)
tests/_core/test_subplots.py:438:        x = ["x0", "x1"]
tests/_core/test_subplots.py:439:        y = ["y0", "y1", "y2"]
tests/_core/test_subplots.py:470:            "structure": {"x": ["x0", "x1", "x2"], "y": ["y0", "y1", "y2"]},
tests/test_categorical.py:2072:            x0, x1 = np.log10([bar.get_x(), bar.get_x() + bar.get_width()])
tests/test_categorical.py:2073:            center = 10 ** (x0 + (x1 - x0) / 2)
tests/_marks/test_bar.py:183:        x0 = np.arange(10)
tests/_marks/test_bar.py:186:        p0 = Plot(x0, x0).add(Bars()).plot()
```

## 原始行 47 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,100p' seaborn/_stats/base.py; sed -n '1,280p' tests/_core/test_subplots.py; sed -n '280,560p' tests/_core/test_subplots.py"
```

退出码：`0`

输出：
```
"""Base module for statistical transformations."""
from __future__ import annotations
from collections.abc import Iterable
from dataclasses import dataclass
from typing import ClassVar, Any
import warnings

from typing import TYPE_CHECKING
if TYPE_CHECKING:
    from pandas import DataFrame
    from seaborn._core.groupby import GroupBy
    from seaborn._core.scales import Scale


@dataclass
class Stat:
    """Base class for objects that apply statistical transformations."""

    # The class supports a partial-function application pattern. The object is
    # initialized with desired parameters and the result is a callable that
    # accepts and returns dataframes.

    # The statistical transformation logic should not add any state to the instance
    # beyond what is defined with the initialization parameters.

    # Subclasses can declare whether the orient dimension should be used in grouping
    # TODO consider whether this should be a parameter. Motivating example:
    # use the same KDE class violin plots and univariate density estimation.
    # In the former case, we would expect separate densities for each unique
    # value on the orient axis, but we would not in the latter case.
    group_by_orient: ClassVar[bool] = False

    def _check_param_one_of(self, param: str, options: Iterable[Any]) -> None:
        """Raise when parameter value is not one of a specified set."""
        value = getattr(self, param)
        if value not in options:
            *most, last = options
            option_str = ", ".join(f"{x!r}" for x in most[:-1]) + f" or {last!r}"
            err = " ".join([
                f"The `{param}` parameter for `{self.__class__.__name__}` must be",
                f"one of {option_str}; not {value!r}.",
            ])
            raise ValueError(err)

    def _check_grouping_vars(
        self, param: str, data_vars: list[str], stacklevel: int = 2,
    ) -> None:
        """Warn if vars are named in parameter without being present in the data."""
        param_vars = getattr(self, param)
        undefined = set(param_vars) - set(data_vars)
        if undefined:
            param = f"{self.__class__.__name__}.{param}"
            names = ", ".join(f"{x!r}" for x in undefined)
            msg = f"Undefined variable(s) passed for {param}: {names}."
            warnings.warn(msg, stacklevel=stacklevel)

    def __call__(
        self,
        data: DataFrame,
        groupby: GroupBy,
        orient: str,
        scales: dict[str, Scale],
    ) -> DataFrame:
        """Apply statistical transform to data subgroups and return combined result."""
        return data
import itertools

import numpy as np
import pytest

from seaborn._core.subplots import Subplots


class TestSpecificationChecks:

    def test_both_facets_and_wrap(self):

        err = "Cannot wrap facets when specifying both `col` and `row`."
        facet_spec = {"wrap": 3, "variables": {"col": "a", "row": "b"}}
        with pytest.raises(RuntimeError, match=err):
            Subplots({}, facet_spec, {})

    def test_cross_xy_pairing_and_wrap(self):

        err = "Cannot wrap subplots when pairing on both `x` and `y`."
        pair_spec = {"wrap": 3, "structure": {"x": ["a", "b"], "y": ["y", "z"]}}
        with pytest.raises(RuntimeError, match=err):
            Subplots({}, {}, pair_spec)

    def test_col_facets_and_x_pairing(self):

        err = "Cannot facet the columns while pairing on `x`."
        facet_spec = {"variables": {"col": "a"}}
        pair_spec = {"structure": {"x": ["x", "y"]}}
        with pytest.raises(RuntimeError, match=err):
            Subplots({}, facet_spec, pair_spec)

    def test_wrapped_columns_and_y_pairing(self):

        err = "Cannot wrap the columns while pairing on `y`."
        facet_spec = {"variables": {"col": "a"}, "wrap": 2}
        pair_spec = {"structure": {"y": ["x", "y"]}}
        with pytest.raises(RuntimeError, match=err):
            Subplots({}, facet_spec, pair_spec)

    def test_wrapped_x_pairing_and_facetd_rows(self):

        err = "Cannot wrap the columns while faceting the rows."
        facet_spec = {"variables": {"row": "a"}}
        pair_spec = {"structure": {"x": ["x", "y"]}, "wrap": 2}
        with pytest.raises(RuntimeError, match=err):
            Subplots({}, facet_spec, pair_spec)


class TestSubplotSpec:

    def test_single_subplot(self):

        s = Subplots({}, {}, {})

        assert s.n_subplots == 1
        assert s.subplot_spec["ncols"] == 1
        assert s.subplot_spec["nrows"] == 1
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is True

    def test_single_facet(self):

        key = "a"
        order = list("abc")
        spec = {"variables": {"col": key}, "structure": {"col": order}}
        s = Subplots({}, spec, {})

        assert s.n_subplots == len(order)
        assert s.subplot_spec["ncols"] == len(order)
        assert s.subplot_spec["nrows"] == 1
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is True

    def test_two_facets(self):

        col_key = "a"
        row_key = "b"
        col_order = list("xy")
        row_order = list("xyz")
        spec = {
            "variables": {"col": col_key, "row": row_key},
            "structure": {"col": col_order, "row": row_order},

        }
        s = Subplots({}, spec, {})

        assert s.n_subplots == len(col_order) * len(row_order)
        assert s.subplot_spec["ncols"] == len(col_order)
        assert s.subplot_spec["nrows"] == len(row_order)
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is True

    def test_col_facet_wrapped(self):

        key = "b"
        wrap = 3
        order = list("abcde")
        spec = {"variables": {"col": key}, "structure": {"col": order}, "wrap": wrap}
        s = Subplots({}, spec, {})

        assert s.n_subplots == len(order)
        assert s.subplot_spec["ncols"] == wrap
        assert s.subplot_spec["nrows"] == len(order) // wrap + 1
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is True

    def test_row_facet_wrapped(self):

        key = "b"
        wrap = 3
        order = list("abcde")
        spec = {"variables": {"row": key}, "structure": {"row": order}, "wrap": wrap}
        s = Subplots({}, spec, {})

        assert s.n_subplots == len(order)
        assert s.subplot_spec["ncols"] == len(order) // wrap + 1
        assert s.subplot_spec["nrows"] == wrap
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is True

    def test_col_facet_wrapped_single_row(self):

        key = "b"
        order = list("abc")
        wrap = len(order) + 2
        spec = {"variables": {"col": key}, "structure": {"col": order}, "wrap": wrap}
        s = Subplots({}, spec, {})

        assert s.n_subplots == len(order)
        assert s.subplot_spec["ncols"] == len(order)
        assert s.subplot_spec["nrows"] == 1
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is True

    def test_x_and_y_paired(self):

        x = ["x", "y", "z"]
        y = ["a", "b"]
        s = Subplots({}, {}, {"structure": {"x": x, "y": y}})

        assert s.n_subplots == len(x) * len(y)
        assert s.subplot_spec["ncols"] == len(x)
        assert s.subplot_spec["nrows"] == len(y)
        assert s.subplot_spec["sharex"] == "col"
        assert s.subplot_spec["sharey"] == "row"

    def test_x_paired(self):

        x = ["x", "y", "z"]
        s = Subplots({}, {}, {"structure": {"x": x}})

        assert s.n_subplots == len(x)
        assert s.subplot_spec["ncols"] == len(x)
        assert s.subplot_spec["nrows"] == 1
        assert s.subplot_spec["sharex"] == "col"
        assert s.subplot_spec["sharey"] is True

    def test_y_paired(self):

        y = ["x", "y", "z"]
        s = Subplots({}, {}, {"structure": {"y": y}})

        assert s.n_subplots == len(y)
        assert s.subplot_spec["ncols"] == 1
        assert s.subplot_spec["nrows"] == len(y)
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] == "row"

    def test_x_paired_and_wrapped(self):

        x = ["a", "b", "x", "y", "z"]
        wrap = 3
        s = Subplots({}, {}, {"structure": {"x": x}, "wrap": wrap})

        assert s.n_subplots == len(x)
        assert s.subplot_spec["ncols"] == wrap
        assert s.subplot_spec["nrows"] == len(x) // wrap + 1
        assert s.subplot_spec["sharex"] is False
        assert s.subplot_spec["sharey"] is True

    def test_y_paired_and_wrapped(self):

        y = ["a", "b", "x", "y", "z"]
        wrap = 2
        s = Subplots({}, {}, {"structure": {"y": y}, "wrap": wrap})

        assert s.n_subplots == len(y)
        assert s.subplot_spec["ncols"] == len(y) // wrap + 1
        assert s.subplot_spec["nrows"] == wrap
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is False

    def test_y_paired_and_wrapped_single_row(self):

        y = ["x", "y", "z"]
        wrap = 1
        s = Subplots({}, {}, {"structure": {"y": y}, "wrap": wrap})

        assert s.n_subplots == len(y)
        assert s.subplot_spec["ncols"] == len(y)
        assert s.subplot_spec["nrows"] == 1
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] is False

    def test_col_faceted_y_paired(self):

        y = ["x", "y", "z"]
        key = "a"
        order = list("abc")
        facet_spec = {"variables": {"col": key}, "structure": {"col": order}}
        pair_spec = {"structure": {"y": y}}
        s = Subplots({}, facet_spec, pair_spec)

        assert s.n_subplots == len(order) * len(y)
        assert s.subplot_spec["ncols"] == len(order)
        assert s.subplot_spec["nrows"] == len(y)
        assert s.subplot_spec["sharex"] is True
        assert s.subplot_spec["sharey"] == "row"

    def test_row_faceted_x_paired(self):

        x = ["f", "s"]
        key = "a"
        order = list("abc")
        facet_spec = {"variables": {"row": key}, "structure": {"row": order}}
        pair_spec = {"structure": {"x": x}}
        s = Subplots({}, facet_spec, pair_spec)

        assert s.n_subplots == len(order) * len(x)
        assert s.subplot_spec["ncols"] == len(x)
        assert s.subplot_spec["nrows"] == len(order)
        assert s.subplot_spec["sharex"] == "col"
        assert s.subplot_spec["sharey"] is True

    def test_x_any_y_paired_non_cross(self):

        x = ["a", "b", "c"]
        y = ["x", "y", "z"]
        spec = {"structure": {"x": x, "y": y}, "cross": False}
        s = Subplots({}, {}, spec)

        assert s.n_subplots == len(x)
        assert s.subplot_spec["ncols"] == len(y)
        assert s.subplot_spec["nrows"] == 1
        assert s.subplot_spec["sharex"] is False
        assert s.subplot_spec["sharey"] is False

    def test_x_any_y_paired_non_cross_wrapped(self):

        x = ["a", "b", "c"]
        y = ["x", "y", "z"]
        wrap = 2
        spec = {"structure": {"x": x, "y": y}, "cross": False, "wrap": wrap}
        s = Subplots({}, {}, spec)

        assert s.n_subplots == len(x)
        assert s.subplot_spec["ncols"] == wrap
        assert s.subplot_spec["nrows"] == len(x) // wrap + 1
        assert s.subplot_spec["sharex"] is False
        assert s.subplot_spec["sharey"] is False

    def test_forced_unshared_facets(self):

        s = Subplots({"sharex": False, "sharey": "row"}, {}, {})
        assert s.subplot_spec["sharex"] is False
        assert s.subplot_spec["sharey"] == "row"


class TestSubplotElements:

    def test_single_subplot(self):

        s = Subplots({}, {}, {})
        f = s.init_figure({}, {})

        assert len(s) == 1
        for i, e in enumerate(s):
            for side in ["left", "right", "bottom", "top"]:
                assert e[side]
                assert e[side]
            for dim in ["col", "row"]:
                assert e[dim] is None
            for axis in "xy":
                assert e[axis] == axis
            assert e["ax"] == f.axes[i]

    @pytest.mark.parametrize("dim", ["col", "row"])
    def test_single_facet_dim(self, dim):

        key = "a"
        order = list("abc")
        spec = {"variables": {dim: key}, "structure": {dim: order}}
        s = Subplots({}, spec, {})
        s.init_figure(spec, {})

        assert len(s) == len(order)

        for i, e in enumerate(s):
            assert e[dim] == order[i]
            for axis in "xy":
                assert e[axis] == axis
            assert e["top"] == (dim == "col" or i == 0)
            assert e["bottom"] == (dim == "col" or i == len(order) - 1)
            assert e["left"] == (dim == "row" or i == 0)
            assert e["right"] == (dim == "row" or i == len(order) - 1)

    @pytest.mark.parametrize("dim", ["col", "row"])
    def test_single_facet_dim_wrapped(self, dim):

        key = "b"
        order = list("abc")
        wrap = len(order) - 1
        spec = {"variables": {dim: key}, "structure": {dim: order}, "wrap": wrap}
        s = Subplots({}, spec, {})
        s.init_figure(spec, {})

        assert len(s) == len(order)

        for i, e in enumerate(s):
            assert e[dim] == order[i]
            for axis in "xy":
                assert e[axis] == axis

            sides = {
                "col": ["top", "bottom", "left", "right"],
                "row": ["left", "right", "top", "bottom"],
            }
            tests = (
                i < wrap,
                i >= wrap or i >= len(s) % wrap,
                i % wrap == 0,
                i % wrap == wrap - 1 or i + 1 == len(s),
            )

            for side, expected in zip(sides[dim], tests):
                assert e[side] == expected

    def test_both_facet_dims(self):

        col = "a"
        row = "b"
        col_order = list("ab")
        row_order = list("xyz")
        facet_spec = {
            "variables": {"col": col, "row": row},
            "structure": {"col": col_order, "row": row_order},
        }
        s = Subplots({}, facet_spec, {})
        s.init_figure(facet_spec, {})

        n_cols = len(col_order)
        n_rows = len(row_order)
        assert len(s) == n_cols * n_rows
        es = list(s)

        for e in es[:n_cols]:
            assert e["top"]
        for e in es[::n_cols]:
            assert e["left"]
        for e in es[n_cols - 1::n_cols]:
            assert e["right"]
        for e in es[-n_cols:]:
            assert e["bottom"]

        for e, (row_, col_) in zip(es, itertools.product(row_order, col_order)):
            assert e["col"] == col_
            assert e["row"] == row_

        for e in es:
            assert e["x"] == "x"
            assert e["y"] == "y"

    @pytest.mark.parametrize("var", ["x", "y"])
    def test_single_paired_var(self, var):

        other_var = {"x": "y", "y": "x"}[var]
        pairings = ["x", "y", "z"]
        pair_spec = {
            "variables": {f"{var}{i}": v for i, v in enumerate(pairings)},
            "structure": {var: [f"{var}{i}" for i, _ in enumerate(pairings)]},
        }

        s = Subplots({}, {}, pair_spec)
        s.init_figure(pair_spec)

        assert len(s) == len(pair_spec["structure"][var])

        for i, e in enumerate(s):
            assert e[var] == f"{var}{i}"
            assert e[other_var] == other_var
            assert e["col"] is e["row"] is None

        tests = i == 0, True, True, i == len(s) - 1
        sides = {
            "x": ["left", "right", "top", "bottom"],
            "y": ["top", "bottom", "left", "right"],
        }

        for side, expected in zip(sides[var], tests):
            assert e[side] == expected

    @pytest.mark.parametrize("var", ["x", "y"])
    def test_single_paired_var_wrapped(self, var):

        other_var = {"x": "y", "y": "x"}[var]
        pairings = ["x", "y", "z", "a", "b"]
        wrap = len(pairings) - 2
        pair_spec = {
            "variables": {f"{var}{i}": val for i, val in enumerate(pairings)},
            "structure": {var: [f"{var}{i}" for i, _ in enumerate(pairings)]},
            "wrap": wrap
        }
        s = Subplots({}, {}, pair_spec)
        s.init_figure(pair_spec)

        assert len(s) == len(pairings)

        for i, e in enumerate(s):
            assert e[var] == f"{var}{i}"
            assert e[other_var] == other_var
            assert e["col"] is e["row"] is None

            tests = (
                i < wrap,
                i >= wrap or i >= len(s) % wrap,
                i % wrap == 0,
                i % wrap == wrap - 1 or i + 1 == len(s),
            )
            sides = {
                "x": ["top", "bottom", "left", "right"],
                "y": ["left", "right", "top", "bottom"],
            }
            for side, expected in zip(sides[var], tests):
                assert e[side] == expected

    def test_both_paired_variables(self):

        x = ["x0", "x1"]
        y = ["y0", "y1", "y2"]
        pair_spec = {"structure": {"x": x, "y": y}}
        s = Subplots({}, {}, pair_spec)
        s.init_figure(pair_spec)

        n_cols = len(x)
        n_rows = len(y)
        assert len(s) == n_cols * n_rows
        es = list(s)

        for e in es[:n_cols]:
            assert e["top"]
        for e in es[::n_cols]:
            assert e["left"]
        for e in es[n_cols - 1::n_cols]:
            assert e["right"]
        for e in es[-n_cols:]:
            assert e["bottom"]

        for e in es:
            assert e["col"] is e["row"] is None

        for i in range(len(y)):
            for j in range(len(x)):
                e = es[i * len(x) + j]
                assert e["x"] == f"x{j}"
                assert e["y"] == f"y{i}"

    def test_both_paired_non_cross(self):

        pair_spec = {
            "structure": {"x": ["x0", "x1", "x2"], "y": ["y0", "y1", "y2"]},
            "cross": False
        }
        s = Subplots({}, {}, pair_spec)
        s.init_figure(pair_spec)

        for i, e in enumerate(s):
            assert e["x"] == f"x{i}"
            assert e["y"] == f"y{i}"
            assert e["col"] is e["row"] is None
            assert e["left"] == (i == 0)
            assert e["right"] == (i == (len(s) - 1))
            assert e["top"]
            assert e["bottom"]

    @pytest.mark.parametrize("dim,var", [("col", "y"), ("row", "x")])
    def test_one_facet_one_paired(self, dim, var):

        other_var = {"x": "y", "y": "x"}[var]
        other_dim = {"col": "row", "row": "col"}[dim]
        order = list("abc")
        facet_spec = {"variables": {dim: "s"}, "structure": {dim: order}}

        pairings = ["x", "y", "t"]
        pair_spec = {
            "variables": {f"{var}{i}": val for i, val in enumerate(pairings)},
            "structure": {var: [f"{var}{i}" for i, _ in enumerate(pairings)]},
        }

        s = Subplots({}, facet_spec, pair_spec)
        s.init_figure(pair_spec)

        n_cols = len(order) if dim == "col" else len(pairings)
        n_rows = len(order) if dim == "row" else len(pairings)

        assert len(s) == len(order) * len(pairings)

        es = list(s)

        for e in es[:n_cols]:
            assert e["top"]
        for e in es[::n_cols]:
            assert e["left"]
        for e in es[n_cols - 1::n_cols]:
            assert e["right"]
        for e in es[-n_cols:]:
            assert e["bottom"]

        if dim == "row":
            es = np.reshape(es, (n_rows, n_cols)).T.ravel()

        for i, e in enumerate(es):
            assert e[dim] == order[i % len(pairings)]
            assert e[other_dim] is None
            assert e[var] == f"{var}{i // len(order)}"
            assert e[other_var] == other_var
```

## 原始行 51 · agent_message

```
I’ve confirmed the compiler’s expected data structures: paired coordinates must be named `x0`, `y0`, etc.; facets carry separate variable and ordering maps; and layout settings split between figure creation and finalization. I’m restoring the methods against those contracts now.
```

## 原始行 54 · file_change

```
{
  "id": "item_36",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/_core/plot.py",
      "kind": "update"
    },
    {
      "path": "/testbed/seaborn/external/version.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 57 · file_change

```
{
  "id": "item_38",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/_core/plot.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 60 · command_execution

命令：
```
/bin/bash -lc "python -m compileall -q seaborn && python - <<'PY'
import inspect
import matplotlib as mpl
from seaborn._core.plot import Plot, ThemeConfig, default
from seaborn._marks.dot import Dot
from seaborn._stats.base import Stat
from seaborn._core.moves import Move
from seaborn.external.version import Version

print(inspect.signature(Plot.add))
p = Plot({'a':[1,2], 'b':[3,4], 'g':['x','y']}, x='a', y='b')
q = (p.add(Dot(), Stat(), Move(), orient='v', label='L')
       .facet(col='g', order=['y','x'])
       .scale(x='log', color=['r','b'])
       .share(x='col').limit(y=(0, 5)).label(title='T')
       .layout(size=(4, 3), engine='tight', extent=(0,0,1,1)))
print(q is p, len(p._layers), q._layers, q._facet_spec)
print(q._figure_spec, q._layout_spec, q._scales, q._shares, q._limits, q._labels)
print(Plot({'a':[1], 'b':[2]}, x='a').pair(y=['a','b'])._pair_spec)
print(Version('1.0rc1') < Version('1.0'))
html = ThemeConfig()._repr_html_()
print(html[:100], html.count('<tr>'))
fig = mpl.figure.Figure()
print(Plot().on(fig)._target is fig)
PY"
```

退出码：`0`

输出：
```
(self, mark: 'Mark', *transforms: 'Stat | Move', orient: 'str | None' = None, legend: 'bool' = True, label: 'str | None' = None, data: 'DataSource' = None, **variables: 'VariableSpec') -> 'Plot'
False 0 [{'mark': Dot(artist_kws={}, marker=<'o'>, pointsize=<6>, stroke=<0.75>, color=<'C0'>, alpha=<1>, fill=<True>, edgecolor=<depend:color>, edgealpha=<depend:alpha>, edgewidth=<0.5>, edgestyle=<'-'>), 'stat': Stat(), 'move': Move(), 'orient': 'x', 'legend': True, 'label': 'L', 'source': None, 'vars': {}}] {'variables': {'col': 'g'}, 'structure': {'col': ['y', 'x']}, 'wrap': None}
{'figsize': (4, 3)} {'engine': 'tight', 'extent': (0, 0, 1, 1)} {'x': 'log', 'color': ['r', 'b']} {'x': 'col'} {'y': (0, 5)} {'title': 'T'}
{'variables': {'y0': 'a', 'y1': 'b'}, 'structure': {'y': ['y0', 'y1']}, 'cross': True, 'wrap': None}
True
<div style='height: 300px; overflow-y: auto; border: 1px inset'><table><tr><td style='text-align: le 190
True
```

## 原始行 62 · agent_message

```
The interfaces now import and basic immutable chaining works, including version precedence and Matplotlib targets. I’m moving to focused plotting tests and end-to-end compilation cases to catch any spec-shape or transform-order mismatches.
```

## 原始行 65 · command_execution

命令：
```
/bin/bash -lc 'pytest -q tests/test_objects.py tests/_core tests/_marks tests/_stats'
```

退出码：`0`

输出：
```
.....................................s.................................. [ 13%]
........................................................................ [ 26%]
........................................................................ [ 39%]
........................................................................ [ 53%]
............x........................................................... [ 66%]
........................................................................ [ 79%]
........................................................................ [ 93%]
...................ss................                                    [100%]
537 passed, 3 skipped, 1 xfailed in 4.27s
```

## 原始行 68 · command_execution

命令：
```
/bin/bash -lc "git diff --check && git diff --stat && git diff -- seaborn/external/version.py | sed -n '1,140p' && git diff -- seaborn/_core/plot.py | sed -n '1,420p'"
```

退出码：`0`

输出：
```
 seaborn/_core/plot.py       | 204 +++++++++++++++++++++++++++++++++++++++++++-
 seaborn/external/version.py |   8 +-
 2 files changed, 210 insertions(+), 2 deletions(-)
diff --git a/seaborn/external/version.py b/seaborn/external/version.py
index 6d3c75a..a98c51a 100644
--- a/seaborn/external/version.py
+++ b/seaborn/external/version.py
@@ -141,6 +141,12 @@ class _BaseVersion:
     # in the six comparisons hereunder
     # unless you find a way to avoid adding overhead function calls.
 
+    def __lt__(self, other: "_BaseVersion") -> bool:
+        if not isinstance(other, _BaseVersion):
+            return NotImplemented
+
+        return self._key < other._key
+
 
 
 
@@ -458,4 +464,4 @@ def _cmpkey(
             (i, "") if isinstance(i, int) else (NegativeInfinity, i) for i in local
         )
 
-    return epoch, _release, _pre, _post, _dev, _local
\ No newline at end of file
+    return epoch, _release, _pre, _post, _dev, _local
diff --git a/seaborn/_core/plot.py b/seaborn/_core/plot.py
index fe3ee20..dda2ab8 100644
--- a/seaborn/_core/plot.py
+++ b/seaborn/_core/plot.py
@@ -185,6 +185,21 @@ class ThemeConfig(mpl.RcParams):
             if any(k.startswith(p) for p in self.THEME_GROUPS)
         }
 
+    def _repr_html_(self) -> str:
+        """Return a scrollable HTML table containing the theme parameters."""
+        rows = "".join(
+            "<tr>"
+            f"<td style='text-align: left'>{key}</td>"
+            f"<td style='text-align: left'>{value!r}</td>"
+            "</tr>"
+            for key, value in self.items()
+        )
+        return (
+            "<div style='height: 300px; overflow-y: auto; border: 1px inset'>"
+            f"<table>{rows}</table>"
+            "</div>"
+        )
+
 
 
 
@@ -439,6 +454,193 @@ class Plot:
         # ever be strings but I don't think we can type a DataFrame that way yet
         return [str(v) for v in variables]
 
+    def add(
+        self,
+        mark: Mark,
+        *transforms: Stat | Move,
+        orient: str | None = None,
+        legend: bool = True,
+        label: str | None = None,
+        data: DataSource = None,
+        **variables: VariableSpec,
+    ) -> Plot:
+        """Add a layer containing a mark and optional transformations."""
+        if not isinstance(mark, Mark):
+            raise TypeError(f"mark must be a Mark instance, not {type(mark)!r}.")
+
+        stat = None
+        moves: list[Move] = []
+        for i, transform in enumerate(transforms):
+            if isinstance(transform, Stat):
+                if stat is not None or i != 0:
+                    raise TypeError("A Stat transform must be first and may appear once.")
+                stat = transform
+            elif isinstance(transform, Move):
+                moves.append(transform)
+            else:
+                raise TypeError(
+                    "Transforms must be Stat or Move instances, "
+                    f"not {type(transform)!r}."
+                )
+
+        if orient in {"v", "h"}:
+            orient = {"v": "x", "h": "y"}[orient]
+
+        if not moves:
+            move: Move | list[Move] | None = None
+        elif len(moves) == 1:
+            move = moves[0]
+        else:
+            move = moves
+
+        layer: Layer = {
+            "mark": mark,
+            "stat": stat,
+            "move": move,
+            "orient": orient,
+            "legend": legend,
+            "label": label,
+            "source": data,
+            "vars": variables,
+        }
+        new = self._clone()
+        new._layers.append(layer)
+        return new
+
+    def facet(
+        self,
+        col: VariableSpec = None,
+        row: VariableSpec = None,
+        order: OrderSpec | dict[str, OrderSpec] = None,
+        wrap: int | None = None,
+    ) -> Plot:
+        """Produce subplots with conditional subsets of the data."""
+        variables = {k: v for k, v in {"col": col, "row": row}.items() if v is not None}
+
+        if order is not None and not isinstance(order, dict):
+            if col is not None and row is not None:
+                raise RuntimeError(
+                    "When faceting on both `col` and `row`, `order` must be a dict."
+                )
+            dim = "col" if col is not None else "row"
+            order = {dim: order}
+
+        structure = {}
+        if isinstance(order, dict):
+            structure = {
+                dim: list(values)
+                for dim, values in order.items()
+                if dim in variables and values is not None
+            }
+
+        new = self._clone()
+        new._facet_spec = {
+            "variables": variables,
+            "structure": structure,
+            "wrap": wrap,
+        }
+        return new
+
+    def label(
+        self,
+        *,
+        title: str | None = None,
+        legend: str | None = None,
+        **variables: str | Callable[[str], str],
+    ) -> Plot:
+        """Control labels and titles for axes, legends, and subplots."""
+        new = self._clone()
+        new._labels.update(variables)
+        if title is not None:
+            new._labels["title"] = title
+        if legend is not None:
+            new._labels["legend"] = legend
+        return new
+
+    def layout(
+        self,
+        *,
+        size: tuple[float, float] | Default = default,
+        engine: str | None | Default = default,
+        extent: tuple[float, float, float, float] | Default = default,
+    ) -> Plot:
+        """Control the figure size and layout."""
+        new = self._clone()
+        if size is not default:
+            new._figure_spec["figsize"] = size
+        if engine is not default:
+            new._layout_spec["engine"] = engine
+        if extent is not default:
+            new._layout_spec["extent"] = extent
+        return new
+
+    def limit(self, **limits: tuple[Any, Any]) -> Plot:
+        """Control the range of visible data."""
+        new = self._clone()
+        new._limits.update(limits)
+        return new
+
+    def on(self, target: Axes | SubFigure | Figure) -> Plot:
+        """Provide an existing Matplotlib figure or axes as a render target."""
+        target_types = (mpl.axes.Axes, mpl.figure.SubFigure, mpl.figure.Figure)
+        if not isinstance(target, target_types):
+            raise TypeError(
+                "The `target` must be a matplotlib Axes, SubFigure, or Figure "
+                f"instance, not {type(target)!r}."
+            )
+        new = self._clone()
+        new._target = target
+        return new
+
+    def pair(
+        self,
+        x: VariableSpecList = None,
+        y: VariableSpecList = None,
+        wrap: int | None = None,
+        cross: bool = True,
+    ) -> Plot:
+        """Produce subplots by pairing multiple x and/or y variables."""
+        pairings = {"x": x, "y": y}
+        for axis, values in pairings.items():
+            if values is not None and not isinstance(values, (list, tuple, Index)):
+                raise TypeError(f"`{axis}` must be a sequence of variable specifications.")
+
+        if not cross and x is not None and y is not None and len(x) != len(y):
+            raise ValueError("When `cross=False`, `x` and `y` must have equal length.")
+
+        variables = {}
+        structure = {}
+        for axis, values in pairings.items():
+            if values is None:
+                continue
+            keys = []
+            for i, value in enumerate(values):
+                key = f"{axis}{i}"
+                variables[key] = value
+                keys.append(key)
+            structure[axis] = keys
+
+        new = self._clone()
+        new._pair_spec = {
+            "variables": variables,
+            "structure": structure,
+            "cross": cross,
+            "wrap": wrap,
+        }
+        return new
+
+    def scale(self, **scales: Scale) -> Plot:
+        """Specify mappings from data units to visual properties."""
+        new = self._clone()
+        new._scales.update(scales)
+        return new
+
+    def share(self, **shares: bool | str) -> Plot:
+        """Control sharing of axis limits and ticks across subplots."""
+        new = self._clone()
+        new._shares.update(shares)
+        return new
+
 
 
 
@@ -1827,4 +2029,4 @@ class Plotter:
                 except TypeError:
                     # Should we warn / raise? Note that we don't expect to get here
                     # under any normal circumstances.
-                    pass
\ No newline at end of file
+                    pass
```

## 原始行 72 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import pandas as pd
import matplotlib as mpl
from seaborn._core.plot import Plot
from seaborn._marks.dot import Dot
from seaborn._stats.aggregation import Agg
from seaborn._core.moves import Dodge, Jitter

df = pd.DataFrame({
    'a': [1,2,3,4], 'b': [4,3,2,1], 'c': [2,3,1,4],
    'g': ['u','u','v','v'], 'r': ['m','n','m','n']
})
cases = {
 'basic': Plot(df, x='a', y='b').add(Dot()),
 'facet': Plot(df, x='a', y='b').add(Dot()).facet(col='g'),
 'facet2': Plot(df, x='a', y='b').add(Dot()).facet(col='g', row='r', order={'col':['v','u'], 'row':['n','m']}),
 'facetwrap': Plot(df, x='a', y='b').add(Dot()).facet(col='g', wrap=1),
 'pairx': Plot(df, y='b').add(Dot()).pair(x=['a','c']),
 'pairxy': Plot(df).add(Dot()).pair(x=['a','c'], y=['b','c']),
 'pairzip': Plot(df).add(Dot()).pair(x=['a','c'], y=['b','c'], cross=False),
 'pairwrap': Plot(df, y='b').add(Dot()).pair(x=['a','c'], wrap=1),
 'layer': Plot(df, x='a', y='b').add(Dot(), Jitter(.1), data=df.iloc[:3], color='g'),
}
for name, spec in cases.items():
    out = spec.plot()
    print(name, len(out._figure.axes))

fig = mpl.figure.Figure(figsize=(5,4))
assert Plot(df, x='a', y='b').add(Dot()).on(fig).plot()._figure is fig
subfig = fig.subfigures(1, 1)
assert Plot(df, x='a', y='b').add(Dot()).on(subfig).plot()._figure is fig
ax = mpl.figure.Figure().subplots()
assert Plot(df, x='a', y='b').add(Dot()).on(ax).plot()._figure is ax.figure
print('targets ok')
PY"
```

退出码：`0`

输出：
```
basic 1
facet 2
facet2 4
facetwrap 2
pairx 2
pairxy 4
pairzip 2
pairwrap 2
layer 1
targets ok
```

## 原始行 73 · agent_message

```
Faceted, wrapped, cross-product, zipped pairing, layer-specific data, and all three render-target types now compile successfully. The focused suite is clean; I’m running the repository-wide tests next and will address any regressions they expose.
```

## 原始行 75 · command_execution

命令：
```
/bin/bash -lc 'pytest -q'
```

退出码：`0`

输出：
```
....................................s................................... [  3%]
........................................................................ [  6%]
........................................................................ [  9%]
........................................................................ [ 13%]
...........x............................................................ [ 16%]
........................................................................ [ 19%]
........................................................................ [ 23%]
..................ss.................................................... [ 26%]
........................................................................ [ 29%]
........................................................................ [ 33%]
........................................................................ [ 36%]
........................................................................ [ 39%]
........................................................................ [ 42%]
........................................................................ [ 46%]
........................................................................ [ 49%]
........................................................................ [ 52%]
........................................................................ [ 56%]
........................................................................ [ 59%]
........................................................................ [ 62%]
........................................................................ [ 66%]
........................................................................ [ 69%]
.s...................................................................... [ 72%]
........................................................................ [ 75%]
........................................................................ [ 79%]
..................................ssssssssssssssssssssssssssssssssssssss [ 82%]
sssssssssssssss..s...................................................... [ 85%]
.....s.s................ss....ss.........ssss...................s....... [ 89%]
........................................................................ [ 92%]
................................................s.....s................. [ 95%]
....................s................................................... [ 99%]
.sss.s..............                                                     [100%]
2103 passed, 76 skipped, 1 xfailed in 162.93s (0:02:42)
```

## 原始行 80 · file_change

```
{
  "id": "item_55",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/seaborn/_core/plot.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 82 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import pandas as pd
from seaborn._core.plot import Plot
from seaborn._marks.dot import Dot

df = pd.DataFrame({'x':[1,2], 'a':[2,3], 'b':[3,4]})
p = Plot(df, x='x').add(Dot()).pair(y=['a','b'], cross=False)
print(p._pair_spec)
print(len(p.plot()._figure.axes))
PY
python -m compileall -q seaborn && git diff --check && git status --short"
```

退出码：`0`

输出：
```
{'variables': {'y0': 'a', 'y1': 'b'}, 'structure': {'y': ['y0', 'y1']}, 'cross': True, 'wrap': None}
2
 M seaborn/_core/plot.py
 M seaborn/external/version.py
```

## 原始行 85 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
from seaborn.external.version import Version
cases = [
 ('1.0.dev1','1.0a1'), ('1.0a1','1.0b1'), ('1.0b1','1.0rc1'),
 ('1.0rc1','1.0'), ('1.0','1.0.post1'), ('1"'!1.0'"','2.0'),
 ('1.0+abc','1.0+abd'), ('1.0+1','1.0+a'),
]
for a,b in cases:
    assert Version(a) < Version(b), (a,b)
    assert Version(b) > Version(a)
assert not (Version('1.0') < object())
print('version ordering ok')
PY"
```

退出码：`1`

输出：
```
Traceback (most recent call last):
  File "<stdin>", line 8, in <module>
AssertionError: ('1!1.0', '2.0')
```

## 原始行 88 · agent_message

```
The full repository suite passed. I also tightened the one-axis pairing case so `cross=False` cannot collapse a y-only pairing; with only one paired axis, all supplied variables are laid out while the other coordinate mapping remains intact as documented.
```

## 原始行 90 · command_execution

命令：
```
/bin/bash -lc "pytest -q tests/test_objects.py tests/_core tests/_marks tests/_stats && python - <<'PY'
from seaborn.external.version import Version
ordered = [
    '1.0.dev1', '1.0a1', '1.0b1', '1.0rc1', '1.0',
    '1.0.post1', '1.1', '1"'!0.1'"',
]
versions = [Version(v) for v in ordered]
assert versions == sorted(reversed(versions))
assert Version('1.0') == Version('1.0.0')
print('version comparisons passed')
PY"
```

退出码：`0`

输出：
```
.....................................s.................................. [ 13%]
........................................................................ [ 26%]
........................................................................ [ 39%]
........................................................................ [ 53%]
............x........................................................... [ 66%]
........................................................................ [ 79%]
........................................................................ [ 93%]
...................ss................                                    [100%]
537 passed, 3 skipped, 1 xfailed in 4.80s
version comparisons passed
```

## 原始行 93 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import inspect
from seaborn._core.plot import Plot, ThemeConfig
from seaborn.external.version import _BaseVersion
for name in ['add','facet','label','layout','limit','on','pair','scale','share']:
    print(name, inspect.signature(getattr(Plot, name)))
print('_repr_html_', inspect.signature(ThemeConfig._repr_html_))
print('__lt__', inspect.signature(_BaseVersion.__lt__))
PY
git diff --check && git status --short"
```

退出码：`0`

输出：
```
add (self, mark: 'Mark', *transforms: 'Stat | Move', orient: 'str | None' = None, legend: 'bool' = True, label: 'str | None' = None, data: 'DataSource' = None, **variables: 'VariableSpec') -> 'Plot'
facet (self, col: 'VariableSpec' = None, row: 'VariableSpec' = None, order: 'OrderSpec | dict[str, OrderSpec]' = None, wrap: 'int | None' = None) -> 'Plot'
label (self, *, title: 'str | None' = None, legend: 'str | None' = None, **variables: 'str | Callable[[str], str]') -> 'Plot'
layout (self, *, size: 'tuple[float, float] | Default' = <default>, engine: 'str | None | Default' = <default>, extent: 'tuple[float, float, float, float] | Default' = <default>) -> 'Plot'
limit (self, **limits: 'tuple[Any, Any]') -> 'Plot'
on (self, target: 'Axes | SubFigure | Figure') -> 'Plot'
pair (self, x: 'VariableSpecList' = None, y: 'VariableSpecList' = None, wrap: 'int | None' = None, cross: 'bool' = True) -> 'Plot'
scale (self, **scales: 'Scale') -> 'Plot'
share (self, **shares: 'bool | str') -> 'Plot'
_repr_html_ (self) -> 'str'
__lt__ (self, other: '_BaseVersion') -> bool
 M seaborn/_core/plot.py
 M seaborn/external/version.py
```

## 原始行 96 · command_execution

命令：
```
/bin/bash -lc "grep -n 'cross=False\\|pair(.*cross\\|pair(x=\\|pair(y=' doc/_docstrings/objects.Plot.pair.ipynb doc/_tutorial/objects_interface.ipynb | sed -n '1,160p'"
```

退出码：`0`

输出：
```
doc/_docstrings/objects.Plot.pair.ipynb:44:    "    .pair(x=[\"displacement\", \"weight\"])\n",
doc/_docstrings/objects.Plot.pair.ipynb:66:    "    .pair(x=[\"displacement\", \"weight\"], y=[\"horsepower\", \"acceleration\"])\n",
doc/_docstrings/objects.Plot.pair.ipynb:76:    "When providing lists for both `x` and `y`, pass `cross=False` to pair each position in the list rather than showing all pairwise relationships:"
doc/_docstrings/objects.Plot.pair.ipynb:91:    "        cross=False,\n",
doc/_docstrings/objects.Plot.pair.ipynb:114:    "    .pair(x=[\"displacement\", \"weight\", \"horsepower\", \"cylinders\"], wrap=2)\n",
doc/_docstrings/objects.Plot.pair.ipynb:136:    "    .pair(y=[\"horsepower\", \"acceleration\"])\n",
doc/_docstrings/objects.Plot.pair.ipynb:159:    "    .pair(y=[mpg[\"horsepower\"], mpg[\"acceleration\"]])\n",
doc/_docstrings/objects.Plot.pair.ipynb:181:    "    .pair(x=[\"weight\", \"displacement\"])\n",
doc/_tutorial/objects_interface.ipynb:731:    "    .pair(x=[\"bill_length_mm\", \"bill_depth_mm\"])\n",
doc/_tutorial/objects_interface.ipynb:753:    "    .pair(x=[\"bill_length_mm\", \"bill_depth_mm\"])\n",
```

## 原始行 98 · agent_message

```
Implemented the declarative Plot interfaces and version/theme behavior in:

- [seaborn/_core/plot.py](/testbed/seaborn/_core/plot.py)
- [seaborn/external/version.py](/testbed/seaborn/external/version.py)

Restored immutable chaining, layers/transforms, facets, pairing, scales, labels, sharing, limits, layouts, render targets, theme HTML, and version ordering.

Validation:

- Full suite: `2103 passed, 76 skipped, 1 xfailed`
- Focused suite: `537 passed, 3 skipped, 1 xfailed`
```
