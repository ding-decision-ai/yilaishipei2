# Codex baseline: matplotlib__matplotlib.86a476d2.test_backend_registry.872ba384.lv1

原始记录：`codex_events.jsonl`。以下按原始行号展示已完成的助手回复、工具操作和执行输出；完整事件保留在原始文件。

## 原始行 3 · agent_message

```
I’ll inspect the registry, its tests, and nearby consumers first, then implement the missing methods and run the focused test suite.
```

## 原始行 5 · command_execution

命令：
```
/bin/bash -lc "sed -n '1,320p' lib/matplotlib/backends/registry.py && rg -n \"BackendRegistry|backend_registry|BackendFilter|resolve_gui_or_backend\" lib/matplotlib tests | head -240"
```

退出码：`0`

输出：
```
from enum import Enum
import importlib


class BackendFilter(Enum):
    """
    Filter used with :meth:`~matplotlib.backends.registry.BackendRegistry.list_builtin`

    .. versionadded:: 3.9
    """
    INTERACTIVE = 0
    NON_INTERACTIVE = 1


class BackendRegistry:
    """
    Registry of backends available within Matplotlib.

    This is the single source of truth for available backends.

    All use of ``BackendRegistry`` should be via the singleton instance
    ``backend_registry`` which can be imported from ``matplotlib.backends``.

    Each backend has a name, a module name containing the backend code, and an
    optional GUI framework that must be running if the backend is interactive.
    There are three sources of backends: built-in (source code is within the
    Matplotlib repository), explicit ``module://some.backend`` syntax (backend is
    obtained by loading the module), or via an entry point (self-registering
    backend in an external package).

    .. versionadded:: 3.9
    """
    # Mapping of built-in backend name to GUI framework, or "headless" for no
    # GUI framework. Built-in backends are those which are included in the
    # Matplotlib repo. A backend with name 'name' is located in the module
    # f"matplotlib.backends.backend_{name.lower()}"
    _BUILTIN_BACKEND_TO_GUI_FRAMEWORK = {
        "gtk3agg": "gtk3",
        "gtk3cairo": "gtk3",
        "gtk4agg": "gtk4",
        "gtk4cairo": "gtk4",
        "macosx": "macosx",
        "nbagg": "nbagg",
        "notebook": "nbagg",
        "qtagg": "qt",
        "qtcairo": "qt",
        "qt5agg": "qt5",
        "qt5cairo": "qt5",
        "tkagg": "tk",
        "tkcairo": "tk",
        "webagg": "webagg",
        "wx": "wx",
        "wxagg": "wx",
        "wxcairo": "wx",
        "agg": "headless",
        "cairo": "headless",
        "pdf": "headless",
        "pgf": "headless",
        "ps": "headless",
        "svg": "headless",
        "template": "headless",
    }

    # Reverse mapping of gui framework to preferred built-in backend.
    _GUI_FRAMEWORK_TO_BACKEND = {
        "gtk3": "gtk3agg",
        "gtk4": "gtk4agg",
        "headless": "agg",
        "macosx": "macosx",
        "qt": "qtagg",
        "qt5": "qt5agg",
        "qt6": "qtagg",
        "tk": "tkagg",
        "wx": "wxagg",
    }

    def __init__(self):
        # Only load entry points when first needed.
        self._loaded_entry_points = False

        # Mapping of non-built-in backend to GUI framework, added dynamically from
        # entry points and from matplotlib.use("module://some.backend") format.
        # New entries have an "unknown" GUI framework that is determined when first
        # needed by calling _get_gui_framework_by_loading.
        self._backend_to_gui_framework = {}

        # Mapping of backend name to module name, where different from
        # f"matplotlib.backends.backend_{backend_name.lower()}". These are either
        # hardcoded for backward compatibility, or loaded from entry points or
        # "module://some.backend" syntax.
        self._name_to_module = {
            "notebook": "nbagg",
        }

    def _backend_module_name(self, backend):
        if backend.startswith("module://"):
            return backend[9:]

        # Return name of module containing the specified backend.
        # Does not check if the backend is valid, use is_valid_backend for that.
        backend = backend.lower()

        # Check if have specific name to module mapping.
        backend = self._name_to_module.get(backend, backend)

        return (backend[9:] if backend.startswith("module://")
                else f"matplotlib.backends.backend_{backend}")

    def _clear(self):
        # Clear all dynamically-added data, used for testing only.
        self.__init__()


























































































    def is_valid_backend(self, backend):
        """
        Return True if the backend name is valid, False otherwise.

        A backend name is valid if it is one of the built-in backends or has been
        dynamically added via an entry point. Those beginning with ``module://`` are
        always considered valid and are added to the current list of all backends
        within this function.

        Even if a name is valid, it may not be importable or usable. This can only be
        determined by loading and using the backend module.

        Parameters
        ----------
        backend : str
            Name of backend.

        Returns
        -------
        bool
            True if backend is valid, False otherwise.
        """
        if not backend.startswith("module://"):
            backend = backend.lower()

        # For backward compatibility, convert ipympl and matplotlib-inline long
        # module:// names to their shortened forms.
        backwards_compat = {
            "module://ipympl.backend_nbagg": "widget",
            "module://matplotlib_inline.backend_inline": "inline",
        }
        backend = backwards_compat.get(backend, backend)

        if (backend in self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK or
                backend in self._backend_to_gui_framework):
            return True

        if backend.startswith("module://"):
            self._backend_to_gui_framework[backend] = "unknown"
            return True

        # Only load entry points if really need to and not already done so.
        self._ensure_entry_points_loaded()
        if backend in self._backend_to_gui_framework:
            return True

        return False





















































    def load_backend_module(self, backend):
        """
        Load and return the module containing the specified backend.

        Parameters
        ----------
        backend : str
            Name of backend to load.

        Returns
        -------
        Module
            Module containing backend.
        """
        module_name = self._backend_module_name(backend)
        return importlib.import_module(module_name)



/bin/bash: line 1: rg: command not found
```

## 原始行 7 · agent_message

```
The target file is deliberately sparse: the requested methods are absent, while helper methods already define module naming, compatibility aliases, validity checks, and lazy discovery hooks that may also be missing. `rg` is unavailable here, so I’m switching to scoped `find`/`grep` inspection.
```

## 原始行 9 · command_execution

命令：
```
/bin/bash -lc "nl -ba lib/matplotlib/backends/registry.py; grep -RInE \"(_validate_and_store_entry_points|list_builtin|list_gui_frameworks|resolve_backend|resolve_gui_or_backend|_ensure_entry_points_loaded|_get_gui_framework_by_loading)\" lib/matplotlib tests 2>/dev/null | head -300; find . -name '*registry*' -o -name '*backend*test*' | head -100"
```

退出码：`0`

输出：
```
     1	from enum import Enum
     2	import importlib
     3	
     4	
     5	class BackendFilter(Enum):
     6	    """
     7	    Filter used with :meth:`~matplotlib.backends.registry.BackendRegistry.list_builtin`
     8	
     9	    .. versionadded:: 3.9
    10	    """
    11	    INTERACTIVE = 0
    12	    NON_INTERACTIVE = 1
    13	
    14	
    15	class BackendRegistry:
    16	    """
    17	    Registry of backends available within Matplotlib.
    18	
    19	    This is the single source of truth for available backends.
    20	
    21	    All use of ``BackendRegistry`` should be via the singleton instance
    22	    ``backend_registry`` which can be imported from ``matplotlib.backends``.
    23	
    24	    Each backend has a name, a module name containing the backend code, and an
    25	    optional GUI framework that must be running if the backend is interactive.
    26	    There are three sources of backends: built-in (source code is within the
    27	    Matplotlib repository), explicit ``module://some.backend`` syntax (backend is
    28	    obtained by loading the module), or via an entry point (self-registering
    29	    backend in an external package).
    30	
    31	    .. versionadded:: 3.9
    32	    """
    33	    # Mapping of built-in backend name to GUI framework, or "headless" for no
    34	    # GUI framework. Built-in backends are those which are included in the
    35	    # Matplotlib repo. A backend with name 'name' is located in the module
    36	    # f"matplotlib.backends.backend_{name.lower()}"
    37	    _BUILTIN_BACKEND_TO_GUI_FRAMEWORK = {
    38	        "gtk3agg": "gtk3",
    39	        "gtk3cairo": "gtk3",
    40	        "gtk4agg": "gtk4",
    41	        "gtk4cairo": "gtk4",
    42	        "macosx": "macosx",
    43	        "nbagg": "nbagg",
    44	        "notebook": "nbagg",
    45	        "qtagg": "qt",
    46	        "qtcairo": "qt",
    47	        "qt5agg": "qt5",
    48	        "qt5cairo": "qt5",
    49	        "tkagg": "tk",
    50	        "tkcairo": "tk",
    51	        "webagg": "webagg",
    52	        "wx": "wx",
    53	        "wxagg": "wx",
    54	        "wxcairo": "wx",
    55	        "agg": "headless",
    56	        "cairo": "headless",
    57	        "pdf": "headless",
    58	        "pgf": "headless",
    59	        "ps": "headless",
    60	        "svg": "headless",
    61	        "template": "headless",
    62	    }
    63	
    64	    # Reverse mapping of gui framework to preferred built-in backend.
    65	    _GUI_FRAMEWORK_TO_BACKEND = {
    66	        "gtk3": "gtk3agg",
    67	        "gtk4": "gtk4agg",
    68	        "headless": "agg",
    69	        "macosx": "macosx",
    70	        "qt": "qtagg",
    71	        "qt5": "qt5agg",
    72	        "qt6": "qtagg",
    73	        "tk": "tkagg",
    74	        "wx": "wxagg",
    75	    }
    76	
    77	    def __init__(self):
    78	        # Only load entry points when first needed.
    79	        self._loaded_entry_points = False
    80	
    81	        # Mapping of non-built-in backend to GUI framework, added dynamically from
    82	        # entry points and from matplotlib.use("module://some.backend") format.
    83	        # New entries have an "unknown" GUI framework that is determined when first
    84	        # needed by calling _get_gui_framework_by_loading.
    85	        self._backend_to_gui_framework = {}
    86	
    87	        # Mapping of backend name to module name, where different from
    88	        # f"matplotlib.backends.backend_{backend_name.lower()}". These are either
    89	        # hardcoded for backward compatibility, or loaded from entry points or
    90	        # "module://some.backend" syntax.
    91	        self._name_to_module = {
    92	            "notebook": "nbagg",
    93	        }
    94	
    95	    def _backend_module_name(self, backend):
    96	        if backend.startswith("module://"):
    97	            return backend[9:]
    98	
    99	        # Return name of module containing the specified backend.
   100	        # Does not check if the backend is valid, use is_valid_backend for that.
   101	        backend = backend.lower()
   102	
   103	        # Check if have specific name to module mapping.
   104	        backend = self._name_to_module.get(backend, backend)
   105	
   106	        return (backend[9:] if backend.startswith("module://")
   107	                else f"matplotlib.backends.backend_{backend}")
   108	
   109	    def _clear(self):
   110	        # Clear all dynamically-added data, used for testing only.
   111	        self.__init__()
   112	
   113	
   114	
   115	
   116	
   117	
   118	
   119	
   120	
   121	
   122	
   123	
   124	
   125	
   126	
   127	
   128	
   129	
   130	
   131	
   132	
   133	
   134	
   135	
   136	
   137	
   138	
   139	
   140	
   141	
   142	
   143	
   144	
   145	
   146	
   147	
   148	
   149	
   150	
   151	
   152	
   153	
   154	
   155	
   156	
   157	
   158	
   159	
   160	
   161	
   162	
   163	
   164	
   165	
   166	
   167	
   168	
   169	
   170	
   171	
   172	
   173	
   174	
   175	
   176	
   177	
   178	
   179	
   180	
   181	
   182	
   183	
   184	
   185	
   186	
   187	
   188	
   189	
   190	
   191	
   192	
   193	
   194	
   195	
   196	
   197	
   198	
   199	
   200	
   201	
   202	    def is_valid_backend(self, backend):
   203	        """
   204	        Return True if the backend name is valid, False otherwise.
   205	
   206	        A backend name is valid if it is one of the built-in backends or has been
   207	        dynamically added via an entry point. Those beginning with ``module://`` are
   208	        always considered valid and are added to the current list of all backends
   209	        within this function.
   210	
   211	        Even if a name is valid, it may not be importable or usable. This can only be
   212	        determined by loading and using the backend module.
   213	
   214	        Parameters
   215	        ----------
   216	        backend : str
   217	            Name of backend.
   218	
   219	        Returns
   220	        -------
   221	        bool
   222	            True if backend is valid, False otherwise.
   223	        """
   224	        if not backend.startswith("module://"):
   225	            backend = backend.lower()
   226	
   227	        # For backward compatibility, convert ipympl and matplotlib-inline long
   228	        # module:// names to their shortened forms.
   229	        backwards_compat = {
   230	            "module://ipympl.backend_nbagg": "widget",
   231	            "module://matplotlib_inline.backend_inline": "inline",
   232	        }
   233	        backend = backwards_compat.get(backend, backend)
   234	
   235	        if (backend in self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK or
   236	                backend in self._backend_to_gui_framework):
   237	            return True
   238	
   239	        if backend.startswith("module://"):
   240	            self._backend_to_gui_framework[backend] = "unknown"
   241	            return True
   242	
   243	        # Only load entry points if really need to and not already done so.
   244	        self._ensure_entry_points_loaded()
   245	        if backend in self._backend_to_gui_framework:
   246	            return True
   247	
   248	        return False
   249	
   250	
   251	
   252	
   253	
   254	
   255	
   256	
   257	
   258	
   259	
   260	
   261	
   262	
   263	
   264	
   265	
   266	
   267	
   268	
   269	
   270	
   271	
   272	
   273	
   274	
   275	
   276	
   277	
   278	
   279	
   280	
   281	
   282	
   283	
   284	
   285	
   286	
   287	
   288	
   289	
   290	
   291	
   292	
   293	
   294	
   295	
   296	
   297	
   298	
   299	
   300	
   301	
   302	    def load_backend_module(self, backend):
   303	        """
   304	        Load and return the module containing the specified backend.
   305	
   306	        Parameters
   307	        ----------
   308	        backend : str
   309	            Name of backend to load.
   310	
   311	        Returns
   312	        -------
   313	        Module
   314	            Module containing backend.
   315	        """
   316	        module_name = self._backend_module_name(backend)
   317	        return importlib.import_module(module_name)
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	
   402	
   403	
   404	
   405	
   406	
   407	
   408	
   409	
   410	
   411	
   412	
   413	# Singleton
   414	backend_registry = BackendRegistry()
lib/matplotlib/pyplot.py:337:        _, ipython_gui_name = backend_registry.resolve_backend(get_backend())
lib/matplotlib/pyplot.py:2847:    available_backends = backend_registry.list_builtin(BackendFilter.INTERACTIVE)
lib/matplotlib/backends/registry.pyi:20:    def _ensure_entry_points_loaded(self) -> None: ...
lib/matplotlib/backends/registry.pyi:21:    def _get_gui_framework_by_loading(self, backend: str) -> str: ...
lib/matplotlib/backends/registry.pyi:23:    def _validate_and_store_entry_points(self, entries: list[tuple[str, str]]) -> None: ...
lib/matplotlib/backends/registry.pyi:28:    def list_builtin(self, filter_: BackendFilter | None) -> list[str]: ...
lib/matplotlib/backends/registry.pyi:29:    def list_gui_frameworks(self) -> list[str]: ...
lib/matplotlib/backends/registry.pyi:31:    def resolve_backend(self, backend: str | None) -> tuple[str, str | None]: ...
lib/matplotlib/backends/registry.pyi:32:    def resolve_gui_or_backend(self, gui_or_backend: str | None) -> tuple[str, str | None]: ...
lib/matplotlib/backends/registry.py:7:    Filter used with :meth:`~matplotlib.backends.registry.BackendRegistry.list_builtin`
lib/matplotlib/backends/registry.py:84:        # needed by calling _get_gui_framework_by_loading.
lib/matplotlib/backends/registry.py:244:        self._ensure_entry_points_loaded()
lib/matplotlib/tests/test_matplotlib.py:64:            set(backend_registry.list_builtin(BackendFilter.INTERACTIVE)))
lib/matplotlib/tests/test_matplotlib.py:66:            set(backend_registry.list_builtin(BackendFilter.NON_INTERACTIVE)))
./lib/matplotlib/backends/registry.pyi
./lib/matplotlib/backends/registry.py
./doc/api/backend_registry_api.rst
```

## 原始行 12 · command_execution

命令：
```
/bin/bash -lc "cat lib/matplotlib/backends/registry.pyi; sed -n '1,130p' lib/matplotlib/tests/test_matplotlib.py; grep -RIn \"matplotlib.backend\\|backend_registry\\|entry_points\" lib/matplotlib/tests tests 2>/dev/null | head -400; grep -RIn \"importlib.metadata\\|entry_points(group\" lib/matplotlib | head -120; sed -n '1,180p' lib/matplotlib/backends/__init__.py; grep -RIn \"resolve_gui_or_backend\\|list_gui_frameworks\\|backend_for_gui_framework\" . --exclude=registry.py --exclude=registry.pyi 2>/dev/null | head -200"
```

退出码：`0`

输出：
```
from enum import Enum
from types import ModuleType


class BackendFilter(Enum):
    INTERACTIVE = 0
    NON_INTERACTIVE = 1


class BackendRegistry:
    _BUILTIN_BACKEND_TO_GUI_FRAMEWORK: dict[str, str]
    _GUI_FRAMEWORK_TO_BACKEND: dict[str, str]

    _loaded_entry_points: bool
    _backend_to_gui_framework: dict[str, str]
    _name_to_module: dict[str, str]

    def _backend_module_name(self, backend: str) -> str: ...
    def _clear(self) -> None: ...
    def _ensure_entry_points_loaded(self) -> None: ...
    def _get_gui_framework_by_loading(self, backend: str) -> str: ...
    def _read_entry_points(self) -> list[tuple[str, str]]: ...
    def _validate_and_store_entry_points(self, entries: list[tuple[str, str]]) -> None: ...

    def backend_for_gui_framework(self, framework: str) -> str | None: ...
    def is_valid_backend(self, backend: str) -> bool: ...
    def list_all(self) -> list[str]: ...
    def list_builtin(self, filter_: BackendFilter | None) -> list[str]: ...
    def list_gui_frameworks(self) -> list[str]: ...
    def load_backend_module(self, backend: str) -> ModuleType: ...
    def resolve_backend(self, backend: str | None) -> tuple[str, str | None]: ...
    def resolve_gui_or_backend(self, gui_or_backend: str | None) -> tuple[str, str | None]: ...


backend_registry: BackendRegistry
import os
import subprocess
import sys
from unittest.mock import patch

import pytest

import matplotlib
from matplotlib.testing import subprocess_run_for_testing


@pytest.mark.parametrize('version_str, version_tuple', [
    ('3.5.0', (3, 5, 0, 'final', 0)),
    ('3.5.0rc2', (3, 5, 0, 'candidate', 2)),
    ('3.5.0.dev820+g6768ef8c4c', (3, 5, 0, 'alpha', 820)),
    ('3.5.0.post820+g6768ef8c4c', (3, 5, 1, 'alpha', 820)),
])
def test_parse_to_version_info(version_str, version_tuple):
    assert matplotlib._parse_to_version_info(version_str) == version_tuple


@pytest.mark.skipif(sys.platform == "win32",
                    reason="chmod() doesn't work as is on Windows")
@pytest.mark.skipif(sys.platform != "win32" and os.geteuid() == 0,
                    reason="chmod() doesn't work as root")
def test_tmpconfigdir_warning(tmp_path):
    """Test that a warning is emitted if a temporary configdir must be used."""
    mode = os.stat(tmp_path).st_mode
    try:
        os.chmod(tmp_path, 0)
        proc = subprocess_run_for_testing(
            [sys.executable, "-c", "import matplotlib"],
            env={**os.environ, "MPLCONFIGDIR": str(tmp_path)},
            stderr=subprocess.PIPE, text=True, check=True)
        assert "set the MPLCONFIGDIR" in proc.stderr
    finally:
        os.chmod(tmp_path, mode)


def test_importable_with_no_home(tmp_path):
    subprocess_run_for_testing(
        [sys.executable, "-c",
         "import pathlib; pathlib.Path.home = lambda *args: 1/0; "
         "import matplotlib.pyplot"],
        env={**os.environ, "MPLCONFIGDIR": str(tmp_path)}, check=True)


def test_use_doc_standard_backends():
    """
    Test that the standard backends mentioned in the docstring of
    matplotlib.use() are the same as in matplotlib.rcsetup.
    """
    def parse(key):
        backends = []
        for line in matplotlib.use.__doc__.split(key)[1].split('\n'):
            if not line.strip():
                break
            backends += [e.strip().lower() for e in line.split(',') if e]
        return backends

    from matplotlib.backends import BackendFilter, backend_registry

    assert (set(parse('- interactive backends:\n')) ==
            set(backend_registry.list_builtin(BackendFilter.INTERACTIVE)))
    assert (set(parse('- non-interactive backends:\n')) ==
            set(backend_registry.list_builtin(BackendFilter.NON_INTERACTIVE)))


def test_importable_with__OO():
    """
    When using -OO or export PYTHONOPTIMIZE=2, docstrings are discarded,
    this simple test may prevent something like issue #17970.
    """
    program = (
        "import matplotlib as mpl; "
        "import matplotlib.pyplot as plt; "
        "import matplotlib.cbook as cbook; "
        "import matplotlib.patches as mpatches"
    )
    subprocess_run_for_testing(
        [sys.executable, "-OO", "-c", program],
        env={**os.environ, "MPLBACKEND": ""}, check=True
        )


@patch('matplotlib.subprocess.check_output')
def test_get_executable_info_timeout(mock_check_output):
    """
    Test that _get_executable_info raises ExecutableNotFoundError if the
    command times out.
    """

    mock_check_output.side_effect = subprocess.TimeoutExpired(cmd=['mock'], timeout=30)

    with pytest.raises(matplotlib.ExecutableNotFoundError, match='Timed out'):
        matplotlib._get_executable_info.__wrapped__('inkscape')
lib/matplotlib/tests/test_backend_webagg.py:5:import matplotlib.backends.backend_webagg_core
lib/matplotlib/tests/test_backend_webagg.py:31:    fm = matplotlib.backends.backend_webagg_core.FigureManagerWebAgg
lib/matplotlib/tests/test_artist.py:16:import matplotlib.backend_bases as mbackend_bases
lib/matplotlib/tests/test_backend_pgf.py:15:from matplotlib.backends.backend_pgf import PdfPages
lib/matplotlib/tests/test_figure.py:18:from matplotlib.backend_bases import KeyEvent, MouseEvent
lib/matplotlib/tests/test_backend_tools.py:3:from matplotlib.backend_tools import ToolHelpBase
lib/matplotlib/tests/test_matplotlib.py:61:    from matplotlib.backends import BackendFilter, backend_registry
lib/matplotlib/tests/test_matplotlib.py:64:            set(backend_registry.list_builtin(BackendFilter.INTERACTIVE)))
lib/matplotlib/tests/test_matplotlib.py:66:            set(backend_registry.list_builtin(BackendFilter.NON_INTERACTIVE)))
lib/matplotlib/tests/test_widgets.py:6:from matplotlib.backend_bases import DrawEvent, KeyEvent, MouseEvent
lib/matplotlib/tests/test_agg.py:12:from matplotlib.backends.backend_agg import RendererAgg
lib/matplotlib/tests/meson.build:23:  'test_backend_registry.py',
lib/matplotlib/tests/test_pickle.py:187:    from matplotlib.backends.backend_pdf import FigureCanvasPdf
lib/matplotlib/tests/test_pickle.py:196:    from matplotlib.backends.backend_agg import RendererAgg
lib/matplotlib/tests/test_pickle.py:204:    from matplotlib.backends.backend_agg import new_figure_manager
lib/matplotlib/tests/test_patheffects.py:10:from matplotlib.backend_bases import RendererBase
lib/matplotlib/tests/test_backend_bases.py:4:from matplotlib.backend_bases import (
lib/matplotlib/tests/test_backend_bases.py:7:from matplotlib.backend_tools import RubberbandBase
lib/matplotlib/tests/test_backend_bases.py:335:    from matplotlib.backends.backend_agg import FigureCanvas
lib/matplotlib/tests/test_backend_bases.py:336:    test_backend = importlib.import_module(f'matplotlib.backends.backend_{backend}')
lib/matplotlib/tests/test_backend_template.py:11:from matplotlib.backends import backend_template
lib/matplotlib/tests/test_backend_template.py:12:from matplotlib.backends.backend_template import (
lib/matplotlib/tests/test_text.py:14:from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_text.py:15:from matplotlib.backends.backend_agg import RendererAgg
lib/matplotlib/tests/test_offsetbox.py:12:from matplotlib.backend_bases import MouseButton, MouseEvent
lib/matplotlib/tests/test_image.py:333:    from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_image.py:415:    from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_image.py:445:    from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_backend_pdf.py:16:from matplotlib.backends._backend_pdf_ps import get_glyphs_subset, font_as_file
lib/matplotlib/tests/test_backend_pdf.py:17:from matplotlib.backends.backend_pdf import PdfPages
lib/matplotlib/tests/test_backend_macosx.py:44:    with (mock.patch("matplotlib.backends._macosx.choose_save_file",
lib/matplotlib/tests/test_backend_macosx.py:73:    prop = "matplotlib.backends._macosx.choose_save_file"
lib/matplotlib/tests/test_backends_interactive.py:21:from matplotlib.backend_tools import ToolToggleBase
lib/matplotlib/tests/test_backends_interactive.py:75:            (["matplotlib.backends._macosx"], {"MPLBACKEND": "macosx"}),
lib/matplotlib/tests/test_backends_interactive.py:160:    from matplotlib.backend_bases import KeyEvent, FigureCanvasBase
lib/matplotlib/tests/test_backends_interactive.py:190:                    f"matplotlib.backends.backend_{alt_backend}")
lib/matplotlib/tests/test_backends_interactive.py:199:    assert type(fig.canvas).__module__ == f"matplotlib.backends.backend_{backend}"
lib/matplotlib/tests/test_backends_interactive.py:360:    import matplotlib.backends.backend_qt5agg  # noqa
lib/matplotlib/tests/test_backends_interactive.py:369:    import matplotlib.backends.backend_qt5cairo  # noqa
lib/matplotlib/tests/test_backends_interactive.py:378:    import matplotlib.backends.backend_qt5  # noqa
lib/matplotlib/tests/test_backends_interactive.py:432:    import matplotlib.backends.backend_qt
lib/matplotlib/tests/test_backends_interactive.py:438:    matplotlib.backends.backend_qt._create_qApp()
lib/matplotlib/tests/test_basic.py:36:    import matplotlib.backend_bases
lib/matplotlib/tests/test_path.py:15:from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_backend_qt.py:18:    from matplotlib.backends.qt_compat import QtCore  # type: ignore[attr-defined]
lib/matplotlib/tests/test_backend_qt.py:19:    from matplotlib.backends.qt_compat import QtGui  # type: ignore[attr-defined]  # noqa: E501, F401
lib/matplotlib/tests/test_backend_qt.py:20:    from matplotlib.backends.qt_compat import QtWidgets  # type: ignore[attr-defined]
lib/matplotlib/tests/test_backend_qt.py:21:    from matplotlib.backends.qt_editor import _formlayout
lib/matplotlib/tests/test_backend_qt.py:106:    from matplotlib.backends.qt_compat import _to_int, QtCore
lib/matplotlib/tests/test_backend_qt.py:141:    prop = 'matplotlib.backends.backend_qt.FigureCanvasQT.devicePixelRatioF'
lib/matplotlib/tests/test_backend_qt.py:205:    with mock.patch("matplotlib.backends.qt_compat._exec", lambda obj: None):
lib/matplotlib/tests/test_backend_qt.py:217:    with mock.patch("matplotlib.backends.qt_compat._exec", lambda obj: None):
lib/matplotlib/tests/test_backend_qt.py:226:    prop = "matplotlib.backends.qt_compat.QtWidgets.QFileDialog.getSaveFileName"
lib/matplotlib/tests/test_backend_qt.py:244:    with mock.patch("matplotlib.backends.qt_compat._exec", lambda obj: None):
lib/matplotlib/tests/test_backend_qt.py:270:    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
lib/matplotlib/tests/test_backend_qt.py:289:    from matplotlib.backends.backend_qt import _create_qApp
lib/matplotlib/tests/test_backend_qt.py:330:    from matplotlib.backends.backend_qt5 import _BackendQT5
lib/matplotlib/tests/test_backend_qt.py:361:        matplotlib.backends.backend_qt._BackendQT.mainloop()
lib/matplotlib/tests/test_backend_tk.py:79:    import matplotlib.backends.backend_tkagg  # noqa
lib/matplotlib/tests/test_backend_tk.py:80:    from matplotlib.backends import _backend_tk, _tkagg
lib/matplotlib/tests/test_backend_tk.py:188:    from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
lib/matplotlib/tests/test_backend_tk.py:250:    from matplotlib.backends.backend_tkagg import (
lib/matplotlib/tests/test_backend_tk.py:252:    from matplotlib.backend_bases import key_press_handler
lib/matplotlib/pyplot.py:520:        import importlib.metadata as im
from .registry import BackendFilter, backend_registry  # noqa: F401

# NOTE: plt.switch_backend() (called at import time) will add a "backend"
# attribute here for backcompat.
_QT_FORCE_QT5_BINDING = False
./lib/matplotlib/pyplot.py:415:                (backend := backend_registry.backend_for_gui_framework(
```

## 原始行 15 · command_execution

命令：
```
/bin/bash -lc "ls -la lib/matplotlib/tests/test_backend_registry.py 2>&1; sed -n '285,445p' lib/matplotlib/pyplot.py; sed -n '480,545p' lib/matplotlib/pyplot.py; grep -RIn \"entry_points\" pyproject.toml setup.py setup.cfg meson.build lib 2>/dev/null | head -100; grep -RIn \"required_interactive_framework\" lib/matplotlib/backends lib/matplotlib/backend_bases.py | head -100; grep -RIn \"_auto_backend_sentinel\\|validate_backend\" lib/matplotlib | head -100"
```

退出码：`0`

输出：
```
ls: cannot access 'lib/matplotlib/tests/test_backend_registry.py': No such file or directory

## Global ##


# The state controlled by {,un}install_repl_displayhook().
_ReplDisplayHook = Enum("_ReplDisplayHook", ["NONE", "PLAIN", "IPYTHON"])
_REPL_DISPLAYHOOK = _ReplDisplayHook.NONE


def _draw_all_if_interactive() -> None:
    if matplotlib.is_interactive():
        draw_all()


def install_repl_displayhook() -> None:
    """
    Connect to the display hook of the current shell.

    The display hook gets called when the read-evaluate-print-loop (REPL) of
    the shell has finished the execution of a command. We use this callback
    to be able to automatically update a figure in interactive mode.

    This works both with IPython and with vanilla python shells.
    """
    global _REPL_DISPLAYHOOK

    if _REPL_DISPLAYHOOK is _ReplDisplayHook.IPYTHON:
        return

    # See if we have IPython hooks around, if so use them.
    # Use ``sys.modules.get(name)`` rather than ``name in sys.modules`` as
    # entries can also have been explicitly set to None.
    mod_ipython = sys.modules.get("IPython")
    if not mod_ipython:
        _REPL_DISPLAYHOOK = _ReplDisplayHook.PLAIN
        return
    ip = mod_ipython.get_ipython()
    if not ip:
        _REPL_DISPLAYHOOK = _ReplDisplayHook.PLAIN
        return

    ip.events.register("post_execute", _draw_all_if_interactive)
    _REPL_DISPLAYHOOK = _ReplDisplayHook.IPYTHON

    if mod_ipython.version_info[:2] < (8, 24):
        # Use of backend2gui is not needed for IPython >= 8.24 as that functionality
        # has been moved to Matplotlib.
        # This code can be removed when Python 3.12, the latest version supported by
        # IPython < 8.24, reaches end-of-life in late 2028.
        from IPython.core.pylabtools import backend2gui
        ipython_gui_name = backend2gui.get(get_backend())
    else:
        _, ipython_gui_name = backend_registry.resolve_backend(get_backend())
    # trigger IPython's eventloop integration, if available
    if ipython_gui_name:
        ip.enable_gui(ipython_gui_name)


def uninstall_repl_displayhook() -> None:
    """Disconnect from the display hook of the current shell."""
    global _REPL_DISPLAYHOOK
    if _REPL_DISPLAYHOOK is _ReplDisplayHook.IPYTHON:
        from IPython import get_ipython
        ip = get_ipython()
        ip.events.unregister("post_execute", _draw_all_if_interactive)
    _REPL_DISPLAYHOOK = _ReplDisplayHook.NONE


draw_all = _pylab_helpers.Gcf.draw_all


# Ensure this appears in the pyplot docs.
@_copy_docstring_and_deprecators(matplotlib.set_loglevel)
def set_loglevel(level: LogLevel) -> None:
    return matplotlib.set_loglevel(level)


@_copy_docstring_and_deprecators(Artist.findobj)
def findobj(
    o: Artist | None = None,
    match: Callable[[Artist], bool] | type[Artist] | None = None,
    include_self: bool = True
) -> list[Artist]:
    if o is None:
        o = gcf()
    return o.findobj(match, include_self=include_self)


_backend_mod: type[matplotlib.backend_bases._Backend] | None = None


def _get_backend_mod() -> type[matplotlib.backend_bases._Backend]:
    """
    Ensure that a backend is selected and return it.

    This is currently private, but may be made public in the future.
    """
    if _backend_mod is None:
        # Use rcParams._get("backend") to avoid going through the fallback
        # logic (which will (re)import pyplot and then call switch_backend if
        # we need to resolve the auto sentinel)
        switch_backend(rcParams._get("backend"))
    return cast(type[matplotlib.backend_bases._Backend], _backend_mod)


def switch_backend(newbackend: str) -> None:
    """
    Set the pyplot backend.

    Switching to an interactive backend is possible only if no event loop for
    another interactive backend has started.  Switching to and from
    non-interactive backends is always possible.

    If the new backend is different than the current backend then all open
    Figures will be closed via ``plt.close('all')``.

    Parameters
    ----------
    newbackend : str
        The case-insensitive name of the backend to use.

    """
    global _backend_mod
    # make sure the init is pulled up so we can assign to it later
    import matplotlib.backends

    if newbackend is rcsetup._auto_backend_sentinel:
        current_framework = cbook._get_running_interactive_framework()

        if (current_framework and
                (backend := backend_registry.backend_for_gui_framework(
                    current_framework))):
            candidates = [backend]
        else:
            candidates = []
        candidates += [
            "macosx", "qtagg", "gtk4agg", "gtk3agg", "tkagg", "wxagg"]

        # Don't try to fallback on the cairo-based backends as they each have
        # an additional dependency (pycairo) over the agg-based backend, and
        # are of worse quality.
        for candidate in candidates:
            try:
                switch_backend(candidate)
            except ImportError:
                continue
            else:
                rcParamsOrig['backend'] = candidate
                return
        else:
            # Switching to Agg should always succeed; if it doesn't, let the
            # exception propagate out.
            switch_backend("agg")
            rcParamsOrig["backend"] = "agg"
            return
    old_backend = rcParams._get('backend')  # get without triggering backend resolution

    module = backend_registry.load_backend_module(newbackend)
    canvas_class = module.FigureCanvas

    required_framework = canvas_class.required_interactive_framework
            return new_figure_manager_given_figure(num, fig)

        def draw_if_interactive() -> None:
            if matplotlib.is_interactive():
                manager = _pylab_helpers.Gcf.get_active()
                if manager:
                    manager.canvas.draw_idle()

        backend_mod.new_figure_manager_given_figure = (  # type: ignore[method-assign]
            new_figure_manager_given_figure)
        backend_mod.new_figure_manager = (  # type: ignore[method-assign]
            new_figure_manager)
        backend_mod.draw_if_interactive = (  # type: ignore[method-assign]
            draw_if_interactive)

    # If the manager explicitly overrides pyplot_show, use it even if a global
    # show is already present, as the latter may be here for backcompat.
    manager_class = getattr(canvas_class, "manager_class", None)
    # We can't compare directly manager_class.pyplot_show and FMB.pyplot_show because
    # pyplot_show is a classmethod so the above constructs are bound classmethods, and
    # thus always different (being bound to different classes).  We also have to use
    # getattr_static instead of vars as manager_class could have no __dict__.
    manager_pyplot_show = inspect.getattr_static(manager_class, "pyplot_show", None)
    base_pyplot_show = inspect.getattr_static(FigureManagerBase, "pyplot_show", None)
    if (show is None
            or (manager_pyplot_show is not None
                and manager_pyplot_show != base_pyplot_show)):
        if not manager_pyplot_show:
            raise ValueError(
                f"Backend {newbackend} defines neither FigureCanvas.manager_class nor "
                f"a toplevel show function")
        _pyplot_show = cast('Any', manager_class).pyplot_show
        backend_mod.show = _pyplot_show  # type: ignore[method-assign]

    _log.debug("Loaded backend %s version %s.",
               newbackend, backend_mod.backend_version)

    if newbackend in ("ipympl", "widget"):
        # ipympl < 0.9.4 expects rcParams["backend"] to be the fully-qualified backend
        # name "module://ipympl.backend_nbagg" not short names "ipympl" or "widget".
        import importlib.metadata as im
        from matplotlib import _parse_to_version_info  # type: ignore[attr-defined]
        try:
            module_version = im.version("ipympl")
            if _parse_to_version_info(module_version) < (0, 9, 4):
                newbackend = "module://ipympl.backend_nbagg"
        except im.PackageNotFoundError:
            pass

    rcParams['backend'] = rcParamsDefault['backend'] = newbackend
    _backend_mod = backend_mod
    for func_name in ["new_figure_manager", "draw_if_interactive", "show"]:
        globals()[func_name].__signature__ = inspect.signature(
            getattr(backend_mod, func_name))

    # Need to keep a global reference to the backend for compatibility reasons.
    # See https://github.com/matplotlib/matplotlib/issues/6092
    matplotlib.backends.backend = newbackend  # type: ignore[attr-defined]

    # Make sure the repl display hook is installed in case we become interactive.
    try:
        install_repl_displayhook()
    except NotImplementedError as err:
        _log.warning("Fallback to a different backend")
        raise ImportError from err

lib/matplotlib/backends/registry.pyi:14:    _loaded_entry_points: bool
lib/matplotlib/backends/registry.pyi:20:    def _ensure_entry_points_loaded(self) -> None: ...
lib/matplotlib/backends/registry.pyi:22:    def _read_entry_points(self) -> list[tuple[str, str]]: ...
lib/matplotlib/backends/registry.pyi:23:    def _validate_and_store_entry_points(self, entries: list[tuple[str, str]]) -> None: ...
lib/matplotlib/backends/registry.py:79:        self._loaded_entry_points = False
lib/matplotlib/backends/registry.py:244:        self._ensure_entry_points_loaded()
lib/matplotlib/backends/backend_gtk4.py:45:    required_interactive_framework = "gtk4"
lib/matplotlib/backends/backend_gtk3.py:52:    required_interactive_framework = "gtk3"
lib/matplotlib/backends/_backend_tk.py:191:    required_interactive_framework = "tk"
lib/matplotlib/backends/backend_qt.py:217:    required_interactive_framework = "qt"
lib/matplotlib/backends/backend_wx.py:403:    required_interactive_framework = "wx"
lib/matplotlib/backends/backend_macosx.py:38:    required_interactive_framework = "macosx"
lib/matplotlib/backend_bases.py:1713:    required_interactive_framework = None
lib/matplotlib/backend_bases.py:1807:        }.get(cls.required_interactive_framework)
lib/matplotlib/rcsetup.pyi:43:_auto_backend_sentinel: object
lib/matplotlib/rcsetup.pyi:45:def validate_backend(s: Any) -> str: ...
lib/matplotlib/pyplot.py:411:    if newbackend is rcsetup._auto_backend_sentinel:
lib/matplotlib/pyplot.py:2852:        rcParams._set("backend", rcsetup._auto_backend_sentinel)
lib/matplotlib/rcsetup.py:270:_auto_backend_sentinel = object()
lib/matplotlib/rcsetup.py:273:def validate_backend(s):
lib/matplotlib/rcsetup.py:274:    if s is _auto_backend_sentinel or backend_registry.is_valid_backend(s):
lib/matplotlib/rcsetup.py:927:    "backend":           validate_backend,
lib/matplotlib/tests/test_rcparams.py:584:         "sentinel = mpl.rcsetup._auto_backend_sentinel; "
lib/matplotlib/__init__.py:749:        corresponding line starts with ##, not #; we fill in _auto_backend_sentinel
lib/matplotlib/__init__.py:752:        fill in _auto_backend_sentinel.
lib/matplotlib/__init__.py:754:        dict.setdefault(self, "backend", rcsetup._auto_backend_sentinel)
lib/matplotlib/__init__.py:758:                and val is rcsetup._auto_backend_sentinel
lib/matplotlib/__init__.py:775:            if val is rcsetup._auto_backend_sentinel:
lib/matplotlib/__init__.py:777:                plt.switch_backend(rcsetup._auto_backend_sentinel)
lib/matplotlib/__init__.py:783:        return None if backend is rcsetup._auto_backend_sentinel else backend
lib/matplotlib/__init__.py:990:        key: [(rcsetup._auto_backend_sentinel if key == "backend" else
lib/matplotlib/__init__.py:1243:    name = rcsetup.validate_backend(backend)
lib/matplotlib/__init__.py:1304:        if backend is rcsetup._auto_backend_sentinel:
lib/matplotlib/__init__.py:1551:@_api.deprecated("3.10", alternative="matplotlib.rcsetup.validate_backend")
lib/matplotlib/__init__.py:1552:def validate_backend(s):
lib/matplotlib/__init__.py:1553:    return rcsetup.validate_backend(s)
```

## 原始行 18 · command_execution

命令：
```
/bin/bash -lc "sed -n '250,286p' lib/matplotlib/rcsetup.py; grep -RIn \"BackendRegistry\\|backend registry\\|entry-point backend\\|entry point.*backend\\|matplotlib.backend\" doc lib/matplotlib/tests 2>/dev/null | head -300; find . -maxdepth 3 -type f \\( -name 'pyproject.toml' -o -name 'setup.cfg' -o -name 'meson.build' \\) -print | xargs grep -n \"backend\" 2>/dev/null | head -100; sed -n '1220,1265p' lib/matplotlib/__init__.py; sed -n '1290,1315p' lib/matplotlib/__init__.py"
```

退出码：`0`

输出：
```
    convert to.
    """
    fonttypes = {'type3':    3,
                 'truetype': 42}
    try:
        fonttype = validate_int(s)
    except ValueError:
        try:
            return fonttypes[s.lower()]
        except KeyError as e:
            raise ValueError('Supported Postscript/PDF font types are %s'
                             % list(fonttypes)) from e
    else:
        if fonttype not in fonttypes.values():
            raise ValueError(
                'Supported Postscript/PDF font types are %s' %
                list(fonttypes.values()))
        return fonttype


_auto_backend_sentinel = object()


def validate_backend(s):
    if s is _auto_backend_sentinel or backend_registry.is_valid_backend(s):
        return s
    else:
        msg = (f"'{s}' is not a valid value for backend; supported values are "
               f"{backend_registry.list_all()}")
        raise ValueError(msg)


def _validate_toolbar(s):
    s = ValidateInStrings(
        'toolbar', ['None', 'toolbar2', 'toolmanager'], ignorecase=True)(s)
    if s == 'toolmanager':
        _api.warn_external(
doc/release/prev_whats_new/whats_new_1.4.rst:47:same way as any other matplotlib backend. Because figures require a connection
doc/release/prev_whats_new/github_stats_3.9.0.rst:330:* :ghpull:`27719`: Add BackendRegistry singleton class
doc/release/prev_whats_new/whats_new_2.1.0.rst:124:  :func:`~matplotlib.backends.backend_pdf.PdfFile.writeInfoDict` for a list of
doc/release/prev_whats_new/whats_new_3.0.rst:123:    from matplotlib.backends.backend_pgf import PdfPages
doc/release/prev_whats_new/github_stats_3.3.1.rst:92:* :ghpull:`18032`: Backport PR #18026 on branch v3.3.x (FIX: Be sure matplotlib.backends is imported before we use it)
doc/release/prev_whats_new/github_stats_3.3.1.rst:93:* :ghpull:`18026`: FIX: Be sure matplotlib.backends is imported before we use it
doc/release/prev_whats_new/changelog.rst:3253:    - lib/matplotlib/backends/backend_pdf.py: Added support for 14 PDF core
doc/release/prev_whats_new/whats_new_2.0.0.rst:309:Extension to `matplotlib.backend_bases.GraphicsContextBase`
doc/release/prev_whats_new/whats_new_2.0.0.rst:313:the `matplotlib.backend_bases.GraphicsContextBase.get_hatch_color`
doc/release/prev_whats_new/whats_new_2.0.0.rst:314:method as added to `matplotlib.backend_bases.GraphicsContextBase`.
doc/release/prev_whats_new/whats_new_2.0.0.rst:319:`~matplotlib.backend_bases.GraphicsContextBase` this method is now
doc/release/prev_whats_new/whats_new_1.5.rst:169:matplotlib backend.
doc/release/prev_whats_new/whats_new_1.5.rst:568:Add a new method :meth:`~matplotlib.backends.backend_pdf.PdfPages.attach_note`
doc/release/prev_whats_new/whats_new_1.5.rst:593:Federico Ariza wrote the new `~matplotlib.backend_managers.ToolManager`
doc/release/prev_whats_new/whats_new_1.5.rst:600:Tools (located in `~matplotlib.backend_tools`), and defines a way to
doc/release/prev_whats_new/whats_new_1.5.rst:640:    from matplotlib.backend_tools import ToolBase
doc/release/prev_whats_new/whats_new_1.3.rst:28:  `matplotlib.backends.backend_pdf.PdfPages`).
doc/release/prev_whats_new/whats_new_3.5.0.rst:299:`~matplotlib.backends.backend_pdf` and `~matplotlib.backends.backend_ps` now
doc/release/prev_whats_new/github_stats_3.9.1.rst:106:* :ghpull:`28392`: Backport PR #28388 on branch v3.9.x (Allow duplicate (name, value) entry points for backends)
doc/release/prev_whats_new/github_stats_3.9.1.rst:108:* :ghpull:`28388`: Allow duplicate (name, value) entry points for backends
doc/release/prev_whats_new/whats_new_3.1.0.rst:339:represented using the `enum.IntEnum` class `matplotlib.backend_bases.MouseButton`,
doc/release/prev_whats_new/whats_new_3.9.0.rst:314:BackendRegistry
doc/release/prev_whats_new/whats_new_3.9.0.rst:317:New :class:`~matplotlib.backends.registry.BackendRegistry` class is the single source of
doc/release/prev_whats_new/whats_new_3.9.0.rst:319:``matplotlib.backends.backend_registry``. It is used internally by Matplotlib, and also
doc/release/prev_whats_new/whats_new_3.9.0.rst:324:the module), or via an entry point (self-registering backend in an external package).
doc/release/prev_whats_new/whats_new_3.9.0.rst:328:    >>> from matplotlib.backends import backend_registry
doc/devel/release_guide.rst:115:   jupyter notebook lib/matplotlib/backends/web_backend/nbagg_uat.ipynb
doc/devel/coding_guide.rst:230:   DEBUG:matplotlib.backends:backend MacOSX version unknown
doc/missing-references.json:9:    "matplotlib.backend_bases._Backend": [
doc/missing-references.json:10:      "lib/matplotlib/backend_bases.py:docstring of matplotlib.backend_bases.ShowBase:1"
doc/missing-references.json:12:    "matplotlib.backends._backend_pdf_ps.RendererPDFPSBase": [
doc/missing-references.json:13:      "lib/matplotlib/backends/backend_pdf.py:docstring of matplotlib.backends.backend_pdf.RendererPdf:1",
doc/missing-references.json:14:      "lib/matplotlib/backends/backend_ps.py:docstring of matplotlib.backends.backend_ps.RendererPS:1"
doc/missing-references.json:16:    "matplotlib.backends._backend_tk.FigureCanvasTk": [
doc/missing-references.json:17:      "lib/matplotlib/backends/backend_tkagg.py:docstring of matplotlib.backends.backend_tkagg.FigureCanvasTkAgg:1",
doc/missing-references.json:18:      "lib/matplotlib/backends/backend_tkcairo.py:docstring of matplotlib.backends.backend_tkcairo.FigureCanvasTkCairo:1"
doc/api/backend_pgf_api.rst:2:``matplotlib.backends.backend_pgf``
doc/api/backend_pgf_api.rst:5:.. automodule:: matplotlib.backends.backend_pgf
doc/api/backend_svg_api.rst:2:``matplotlib.backends.backend_svg``
doc/api/backend_svg_api.rst:5:.. automodule:: matplotlib.backends.backend_svg
doc/api/backend_webagg_api.rst:2:``matplotlib.backends.backend_webagg``
doc/api/backend_webagg_api.rst:5:.. automodule:: matplotlib.backends.backend_webagg
doc/api/backend_gtk4_api.rst:2:``matplotlib.backends.backend_gtk4agg``, ``matplotlib.backends.backend_gtk4cairo``
doc/api/backend_gtk4_api.rst:11:.. module:: matplotlib.backends.backend_gtk4
doc/api/backend_gtk4_api.rst:12:.. module:: matplotlib.backends.backend_gtk4agg
doc/api/backend_gtk4_api.rst:13:.. module:: matplotlib.backends.backend_gtk4cairo
doc/api/backend_tk_api.rst:2:``matplotlib.backends.backend_tkagg``, ``matplotlib.backends.backend_tkcairo``
doc/api/backend_tk_api.rst:5:.. automodule:: matplotlib.backends.backend_tkagg
doc/api/backend_tk_api.rst:10:.. automodule:: matplotlib.backends.backend_tkcairo
doc/api/backend_bases_api.rst:2:``matplotlib.backend_bases``
doc/api/backend_bases_api.rst:5:.. automodule:: matplotlib.backend_bases
doc/api/backend_mixed_api.rst:2:``matplotlib.backends.backend_mixed``
doc/api/backend_mixed_api.rst:5:.. automodule:: matplotlib.backends.backend_mixed
doc/api/backend_webagg_core_api.rst:2:``matplotlib.backends.backend_webagg_core``
doc/api/backend_webagg_core_api.rst:5:.. automodule:: matplotlib.backends.backend_webagg_core
doc/api/prev_api_changes/api_changes_2.0.1.rst:5:Extensions to `matplotlib.backend_bases.GraphicsContextBase`
doc/api/prev_api_changes/api_changes_2.0.1.rst:9:`matplotlib.backend_bases.GraphicsContextBase.set_hatch_color` was
doc/api/prev_api_changes/api_changes_2.0.1.rst:13:which do not extend `~matplotlib.backend_bases.GraphicsContextBase`.
doc/api/prev_api_changes/api_changes_2.0.1.rst:16:`matplotlib.backend_bases.GraphicsContextBase.get_hatch_color` (which
doc/api/prev_api_changes/api_changes_2.0.1.rst:23:`~matplotlib.backend_bases.GraphicsContextBase` to make adapting to
doc/api/prev_api_changes/api_changes_3.2.0/removals.rst:10:- the ``matplotlib.backends.tkagg``, ``matplotlib.backends.windowing``,
doc/api/prev_api_changes/api_changes_3.2.0/removals.rst:11:  ``matplotlib.backends.wx_compat``, and ``matplotlib.compat.subprocess``
doc/api/prev_api_changes/api_changes_3.2.0/removals.rst:66:The following members of ``matplotlib.backends.backend_pdf.PdfFile`` were removed:
doc/api/prev_api_changes/api_changes_2.1.0.rst:396:The ``matplotlib.backends.backend_ps.seq_allequal`` function has been removed.
doc/api/prev_api_changes/api_changes_2.1.0.rst:437::class:`matplotlib.backends.backend_pdf.PdfFile` have been removed.  It is
doc/api/prev_api_changes/api_changes_0.98.0.rst:256::mod:`matplotlib.backend_bases`
doc/api/prev_api_changes/api_changes_0.98.0.rst:272:.. [7] :meth:`matplotlib.backend_bases.GraphicsContextBase.get_clip_path`
doc/api/prev_api_changes/api_changes_0.98.0.rst:277:.. [8] :meth:`matplotlib.backend_bases.GraphicsContextBase.set_clip_path` now
doc/api/prev_api_changes/api_changes_0.98.0.rst:280::class:`~matplotlib.backend_bases.RendererBase`
doc/api/prev_api_changes/api_changes_0.98.0.rst:286:  <matplotlib.backend_bases.RendererBase.draw_path>`
doc/api/prev_api_changes/api_changes_0.98.0.rst:289:  <matplotlib.backend_bases.RendererBase.draw_markers>`
doc/api/prev_api_changes/api_changes_0.98.0.rst:294:  <matplotlib.backend_bases.RendererBase.draw_path_collection>`
doc/api/prev_api_changes/api_changes_0.98.0.rst:301:  <matplotlib.backend_bases.RendererBase.draw_image>`
doc/api/prev_api_changes/api_changes_1.4.x.rst:42:  ``matplotlib.backends.qt4_compat`` was renamed to
doc/api/prev_api_changes/api_changes_1.4.x.rst:43:  ``matplotlib.backends.qt_compat``.  ``qt4_compat`` is deprecated in 1.4 and
doc/api/prev_api_changes/api_changes_0.99.x.rst:63:  of the class :class:`matplotlib.backends.backend_pdf.PdfPages` for
doc/api/prev_api_changes/api_changes_1.3.x.rst:124:  :meth:`~matplotlib.backend_bases.GraphicsContextBase.set_foreground` (and
doc/api/prev_api_changes/api_changes_3.3.0/deprecations.rst:188:``matplotlib.backends.qt_editor.formsubplottool``
doc/api/prev_api_changes/api_changes_3.3.0/deprecations.rst:190:This module is deprecated.  Use ``matplotlib.backends.backend_qt5.SubplotToolQt``
doc/api/prev_api_changes/api_changes_3.3.0/deprecations.rst:612:global variables of the ``matplotlib.backends.backend_qt4agg``,
doc/api/prev_api_changes/api_changes_3.3.0/deprecations.rst:613:``matplotlib.backends.backend_qt4cairo``,
doc/api/prev_api_changes/api_changes_3.3.0/deprecations.rst:614::mod:`matplotlib.backends.backend_qt5agg` and
doc/api/prev_api_changes/api_changes_3.3.0/deprecations.rst:615::mod:`matplotlib.backends.backend_qt5cairo` modules are deprecated.
doc/api/prev_api_changes/api_changes_3.0.1.rst:12:- ``matplotlib.backends.backend_agg._png``
doc/api/prev_api_changes/api_changes_3.1.0.rst:977:- ``matplotlib.backends.qt_editor.formlayout`` module
doc/api/prev_api_changes/api_changes_0.50.rst:9:    Figure.  matplotlib.backend_bases.FigureBase moved to
doc/api/prev_api_changes/api_changes_3.0.0.rst:356:- ``matplotlib.backends.wx_compat``. Python 3 is only compatible with
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:72:* ``matplotlib.backend_bases.FigureCanvasBase.draw_cursor`` has been removed.
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:73:* ``matplotlib.backends.backend_gtk.ConfigureSubplotsGTK3.destroy`` and
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:74:  ``matplotlib.backends.backend_gtk.ConfigureSubplotsGTK3.init_window`` methods
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:76:* ``matplotlib.backends.backend_gtk.ConfigureSubplotsGTK3.window`` property has
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:78:* ``matplotlib.backends.backend_macosx.FigureCanvasMac.invalidate`` has been
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:80:* ``matplotlib.backends.backend_pgf.RendererPgf.latexManager`` has been removed.
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:81:* ``matplotlib.backends.backend_wx.FigureFrameWx.statusbar``,
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:82:  ``matplotlib.backends.backend_wx.NavigationToolbar2Wx.set_status_bar``, and
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:83:  ``matplotlib.backends.backend_wx.NavigationToolbar2Wx.statbar`` have been
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:87:* ``matplotlib.backends.backend_wx.ConfigureSubplotsWx.configure_subplots`` and
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:88:  ``matplotlib.backends.backend_wx.ConfigureSubplotsWx.get_canvas`` have been
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:100:- ``matplotlib.backends.backend_pgf.repl_escapetext`` and
doc/api/prev_api_changes/api_changes_3.4.0/removals.rst:101:  ``matplotlib.backends.backend_pgf.repl_mathdefault`` have been removed.
doc/api/prev_api_changes/api_changes_3.4.0/behaviour.rst:257:In the Qt5 backend, the ``matplotlib.backends.backend_qt5.SPECIAL_KEYS``
doc/api/prev_api_changes/api_changes_3.5.0/deprecations.rst:240:- ``matplotlib.backends.backend_gtk3.SetCursorGTK3``
doc/api/prev_api_changes/api_changes_3.5.0/deprecations.rst:241:- ``matplotlib.backends.backend_qt5.SetCursorQt``
doc/api/prev_api_changes/api_changes_3.5.0/deprecations.rst:242:- ``matplotlib.backends._backend_tk.SetCursorTk``
doc/api/prev_api_changes/api_changes_3.5.0/deprecations.rst:243:- ``matplotlib.backends.backend_wx.SetCursorWx``
doc/api/prev_api_changes/api_changes_3.5.0/removals.rst:122:- ``matplotlib.backends.qt_editor.formsubplottool``; use
doc/api/prev_api_changes/api_changes_3.5.0/removals.rst:123:  ``matplotlib.backends.backend_qt.SubplotToolQt`` instead.
doc/api/prev_api_changes/api_changes_3.5.0/removals.rst:140:  `matplotlib.backends.backend_qt5agg` and
doc/api/prev_api_changes/api_changes_3.5.0/removals.rst:141:  `matplotlib.backends.backend_qt5cairo`
doc/api/prev_api_changes/api_changes_3.7.0/removals.rst:42:- ``matplotlib.backends.backend_gtk3.SetCursorGTK3``
doc/api/prev_api_changes/api_changes_3.7.0/removals.rst:43:- ``matplotlib.backends.backend_qt5.SetCursorQt``
doc/api/prev_api_changes/api_changes_3.7.0/removals.rst:44:- ``matplotlib.backends._backend_tk.SetCursorTk``
doc/api/prev_api_changes/api_changes_3.7.0/removals.rst:45:- ``matplotlib.backends.backend_wx.SetCursorWx``
doc/api/prev_api_changes/api_changes_3.9.0/deprecations.rst:76:... are deprecated and replaced by ``matplotlib.backends.backend_registry.list_builtin``
doc/api/prev_api_changes/api_changes_3.9.0/deprecations.rst:79:- ``matplotlib.backends.BackendFilter.INTERACTIVE``
doc/api/prev_api_changes/api_changes_3.9.0/deprecations.rst:80:- ``matplotlib.backends.BackendFilter.NON_INTERACTIVE``
doc/api/prev_api_changes/api_changes_3.9.0/removals.rst:153:- ``matplotlib.backend.backend_agg.BufferRegion.to_string``
doc/api/prev_api_changes/api_changes_3.9.0/removals.rst:154:- ``matplotlib.backend.backend_agg.BufferRegion.to_string_argb``
doc/api/prev_api_changes/api_changes_3.9.0/removals.rst:155:- ``matplotlib.backends.backend_ps.PsBackendHelper``
doc/api/prev_api_changes/api_changes_3.9.0/removals.rst:156:- ``matplotlib.backends.backend_webagg.ServerThread``
doc/api/prev_api_changes/api_changes_2.2.0.rst:144:(e.g. `~.Figure` from :mod:`matplotlib.backends.backend_agg` instead of
doc/api/prev_api_changes/api_changes_2.2.0.rst:219:   [matplotlib.backends.backend_qt5agg.FigureCanvasQTAgg,
doc/api/prev_api_changes/api_changes_2.2.0.rst:220:    matplotlib.backends.backend_qt5agg.FigureCanvasQTAggBase,
doc/api/prev_api_changes/api_changes_2.2.0.rst:221:    matplotlib.backends.backend_agg.FigureCanvasAgg,
doc/api/prev_api_changes/api_changes_2.2.0.rst:222:    matplotlib.backends.backend_qt5.FigureCanvasQT,
doc/api/prev_api_changes/api_changes_2.2.0.rst:228:    matplotlib.backend_bases.FigureCanvasBase,
doc/api/prev_api_changes/api_changes_2.2.0.rst:234:   [matplotlib.backends.backend_qt5agg.FigureCanvasQTAggBase,
doc/api/prev_api_changes/api_changes_2.2.0.rst:235:    matplotlib.backends.backend_agg.FigureCanvasAgg,
doc/api/prev_api_changes/api_changes_2.2.0.rst:236:    matplotlib.backend_bases.FigureCanvasBase,
doc/api/prev_api_changes/api_changes_2.2.0.rst:242:   [matplotlib.backends.backend_qt5agg.FigureCanvasQTAgg,
doc/api/prev_api_changes/api_changes_2.2.0.rst:243:    matplotlib.backends.backend_agg.FigureCanvasAgg,
doc/api/prev_api_changes/api_changes_2.2.0.rst:244:    matplotlib.backends.backend_qt5.FigureCanvasQT,
doc/api/prev_api_changes/api_changes_2.2.0.rst:250:    matplotlib.backend_bases.FigureCanvasBase,
doc/api/prev_api_changes/api_changes_2.2.0.rst:255:   [matplotlib.backends.backend_qt5agg.FigureCanvasQTAggBase,
doc/api/prev_api_changes/api_changes_2.2.0.rst:256:    matplotlib.backends.backend_qt5agg.FigureCanvasQTAgg,
doc/api/prev_api_changes/api_changes_2.2.0.rst:257:    matplotlib.backends.backend_agg.FigureCanvasAgg,
doc/api/prev_api_changes/api_changes_2.2.0.rst:258:    matplotlib.backends.backend_qt5.FigureCanvasQT,
doc/api/prev_api_changes/api_changes_2.2.0.rst:264:    matplotlib.backend_bases.FigureCanvasBase,
doc/api/next_api_changes/removals/30067-OG.rst:9:... are removed and replaced by ``matplotlib.backends.backend_registry.list_builtin``
doc/api/next_api_changes/removals/30067-OG.rst:12:- ``matplotlib.backends.BackendFilter.INTERACTIVE``
doc/api/next_api_changes/removals/30067-OG.rst:13:- ``matplotlib.backends.BackendFilter.NON_INTERACTIVE``
doc/api/index_backend_api.rst:2:``matplotlib.backends``
doc/api/index_backend_api.rst:5:.. module:: matplotlib.backends
doc/api/backend_nbagg_api.rst:2:``matplotlib.backends.backend_nbagg``
doc/api/backend_nbagg_api.rst:5:.. automodule:: matplotlib.backends.backend_nbagg
doc/api/backend_template_api.rst:2:``matplotlib.backends.backend_template``
doc/api/backend_template_api.rst:5:.. automodule:: matplotlib.backends.backend_template
doc/api/backend_tools_api.rst:2:``matplotlib.backend_tools``
doc/api/backend_tools_api.rst:5:.. automodule:: matplotlib.backend_tools
doc/api/backend_wx_api.rst:2:``matplotlib.backends.backend_wxagg``, ``matplotlib.backends.backend_wxcairo``
doc/api/backend_wx_api.rst:10:.. module:: matplotlib.backends.backend_wx
doc/api/backend_wx_api.rst:11:.. module:: matplotlib.backends.backend_wxagg
doc/api/backend_wx_api.rst:12:.. module:: matplotlib.backends.backend_wxcairo
doc/api/backend_pdf_api.rst:2:``matplotlib.backends.backend_pdf``
doc/api/backend_pdf_api.rst:5:.. automodule:: matplotlib.backends.backend_pdf
doc/api/backend_cairo_api.rst:2:``matplotlib.backends.backend_cairo``
doc/api/backend_cairo_api.rst:5:.. automodule:: matplotlib.backends.backend_cairo
doc/api/backend_agg_api.rst:2:``matplotlib.backends.backend_agg``
doc/api/backend_agg_api.rst:5:.. automodule:: matplotlib.backends.backend_agg
doc/api/backend_registry_api.rst:2:``matplotlib.backends.registry``
doc/api/backend_registry_api.rst:5:.. automodule:: matplotlib.backends.registry
doc/api/backend_ps_api.rst:2:``matplotlib.backends.backend_ps``
doc/api/backend_ps_api.rst:5:.. automodule:: matplotlib.backends.backend_ps
doc/api/backend_gtk3_api.rst:2:``matplotlib.backends.backend_gtk3agg``, ``matplotlib.backends.backend_gtk3cairo``
doc/api/backend_gtk3_api.rst:11:.. module:: matplotlib.backends.backend_gtk3
doc/api/backend_gtk3_api.rst:12:.. module:: matplotlib.backends.backend_gtk3agg
doc/api/backend_gtk3_api.rst:13:.. module:: matplotlib.backends.backend_gtk3cairo
doc/api/backend_qt_api.rst:2:``matplotlib.backends.backend_qtagg``, ``matplotlib.backends.backend_qtcairo``
doc/api/backend_qt_api.rst:13:.. module:: matplotlib.backends.qt_compat
doc/api/backend_qt_api.rst:14:.. module:: matplotlib.backends.backend_qt
doc/api/backend_qt_api.rst:15:.. module:: matplotlib.backends.backend_qtagg
doc/api/backend_qt_api.rst:16:.. module:: matplotlib.backends.backend_qtcairo
doc/api/backend_qt_api.rst:17:.. module:: matplotlib.backends.backend_qt5agg
doc/api/backend_qt_api.rst:18:.. module:: matplotlib.backends.backend_qt5cairo
doc/api/backend_qt_api.rst:31:qtagg and qtcairo backends (``matplotlib.backends.backend_qtagg`` and
doc/api/backend_qt_api.rst:32:``matplotlib.backend.backend_qtcairo``) support all these bindings, with common
doc/api/backend_qt_api.rst:33:parts factored out in the ``matplotlib.backends.backend_qt`` module.
doc/api/backend_qt_api.rst:47:(e.g. qt4agg/``matplotlib.backends.backend_qt4agg`` and
doc/api/backend_qt_api.rst:48:qt5agg/``matplotlib.backends.backend_qt5agg``).  This scheme was dropped when
doc/api/backend_qt_api.rst:59:`matplotlib.backends.qt_compat` which covers our needs.  Despite being a public
doc/api/backend_managers_api.rst:2:``matplotlib.backend_managers``
doc/api/backend_managers_api.rst:5:.. automodule:: matplotlib.backend_managers
lib/matplotlib/tests/test_backend_webagg.py:5:import matplotlib.backends.backend_webagg_core
lib/matplotlib/tests/test_backend_webagg.py:31:    fm = matplotlib.backends.backend_webagg_core.FigureManagerWebAgg
lib/matplotlib/tests/test_artist.py:16:import matplotlib.backend_bases as mbackend_bases
lib/matplotlib/tests/test_backend_pgf.py:15:from matplotlib.backends.backend_pgf import PdfPages
lib/matplotlib/tests/test_figure.py:18:from matplotlib.backend_bases import KeyEvent, MouseEvent
lib/matplotlib/tests/test_backend_tools.py:3:from matplotlib.backend_tools import ToolHelpBase
lib/matplotlib/tests/test_matplotlib.py:61:    from matplotlib.backends import BackendFilter, backend_registry
lib/matplotlib/tests/test_widgets.py:6:from matplotlib.backend_bases import DrawEvent, KeyEvent, MouseEvent
lib/matplotlib/tests/test_agg.py:12:from matplotlib.backends.backend_agg import RendererAgg
lib/matplotlib/tests/test_pickle.py:187:    from matplotlib.backends.backend_pdf import FigureCanvasPdf
lib/matplotlib/tests/test_pickle.py:196:    from matplotlib.backends.backend_agg import RendererAgg
lib/matplotlib/tests/test_pickle.py:204:    from matplotlib.backends.backend_agg import new_figure_manager
lib/matplotlib/tests/test_patheffects.py:10:from matplotlib.backend_bases import RendererBase
lib/matplotlib/tests/test_backend_bases.py:4:from matplotlib.backend_bases import (
lib/matplotlib/tests/test_backend_bases.py:7:from matplotlib.backend_tools import RubberbandBase
lib/matplotlib/tests/test_backend_bases.py:335:    from matplotlib.backends.backend_agg import FigureCanvas
lib/matplotlib/tests/test_backend_bases.py:336:    test_backend = importlib.import_module(f'matplotlib.backends.backend_{backend}')
lib/matplotlib/tests/test_backend_template.py:11:from matplotlib.backends import backend_template
lib/matplotlib/tests/test_backend_template.py:12:from matplotlib.backends.backend_template import (
lib/matplotlib/tests/test_text.py:14:from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_text.py:15:from matplotlib.backends.backend_agg import RendererAgg
lib/matplotlib/tests/test_offsetbox.py:12:from matplotlib.backend_bases import MouseButton, MouseEvent
lib/matplotlib/tests/test_image.py:333:    from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_image.py:415:    from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_image.py:445:    from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_backend_pdf.py:16:from matplotlib.backends._backend_pdf_ps import get_glyphs_subset, font_as_file
lib/matplotlib/tests/test_backend_pdf.py:17:from matplotlib.backends.backend_pdf import PdfPages
lib/matplotlib/tests/test_backend_macosx.py:44:    with (mock.patch("matplotlib.backends._macosx.choose_save_file",
lib/matplotlib/tests/test_backend_macosx.py:73:    prop = "matplotlib.backends._macosx.choose_save_file"
lib/matplotlib/tests/test_backends_interactive.py:21:from matplotlib.backend_tools import ToolToggleBase
lib/matplotlib/tests/test_backends_interactive.py:75:            (["matplotlib.backends._macosx"], {"MPLBACKEND": "macosx"}),
lib/matplotlib/tests/test_backends_interactive.py:160:    from matplotlib.backend_bases import KeyEvent, FigureCanvasBase
lib/matplotlib/tests/test_backends_interactive.py:190:                    f"matplotlib.backends.backend_{alt_backend}")
lib/matplotlib/tests/test_backends_interactive.py:199:    assert type(fig.canvas).__module__ == f"matplotlib.backends.backend_{backend}"
lib/matplotlib/tests/test_backends_interactive.py:360:    import matplotlib.backends.backend_qt5agg  # noqa
lib/matplotlib/tests/test_backends_interactive.py:369:    import matplotlib.backends.backend_qt5cairo  # noqa
lib/matplotlib/tests/test_backends_interactive.py:378:    import matplotlib.backends.backend_qt5  # noqa
lib/matplotlib/tests/test_backends_interactive.py:432:    import matplotlib.backends.backend_qt
lib/matplotlib/tests/test_backends_interactive.py:438:    matplotlib.backends.backend_qt._create_qApp()
lib/matplotlib/tests/test_basic.py:36:    import matplotlib.backend_bases
lib/matplotlib/tests/test_path.py:15:from matplotlib.backend_bases import MouseEvent
lib/matplotlib/tests/test_backend_qt.py:18:    from matplotlib.backends.qt_compat import QtCore  # type: ignore[attr-defined]
lib/matplotlib/tests/test_backend_qt.py:19:    from matplotlib.backends.qt_compat import QtGui  # type: ignore[attr-defined]  # noqa: E501, F401
lib/matplotlib/tests/test_backend_qt.py:20:    from matplotlib.backends.qt_compat import QtWidgets  # type: ignore[attr-defined]
lib/matplotlib/tests/test_backend_qt.py:21:    from matplotlib.backends.qt_editor import _formlayout
lib/matplotlib/tests/test_backend_qt.py:106:    from matplotlib.backends.qt_compat import _to_int, QtCore
lib/matplotlib/tests/test_backend_qt.py:141:    prop = 'matplotlib.backends.backend_qt.FigureCanvasQT.devicePixelRatioF'
lib/matplotlib/tests/test_backend_qt.py:205:    with mock.patch("matplotlib.backends.qt_compat._exec", lambda obj: None):
lib/matplotlib/tests/test_backend_qt.py:217:    with mock.patch("matplotlib.backends.qt_compat._exec", lambda obj: None):
lib/matplotlib/tests/test_backend_qt.py:226:    prop = "matplotlib.backends.qt_compat.QtWidgets.QFileDialog.getSaveFileName"
lib/matplotlib/tests/test_backend_qt.py:244:    with mock.patch("matplotlib.backends.qt_compat._exec", lambda obj: None):
lib/matplotlib/tests/test_backend_qt.py:270:    from matplotlib.backends.backend_qtagg import FigureCanvasQTAgg
lib/matplotlib/tests/test_backend_qt.py:289:    from matplotlib.backends.backend_qt import _create_qApp
lib/matplotlib/tests/test_backend_qt.py:330:    from matplotlib.backends.backend_qt5 import _BackendQT5
lib/matplotlib/tests/test_backend_qt.py:361:        matplotlib.backends.backend_qt._BackendQT.mainloop()
lib/matplotlib/tests/test_backend_tk.py:79:    import matplotlib.backends.backend_tkagg  # noqa
lib/matplotlib/tests/test_backend_tk.py:80:    from matplotlib.backends import _backend_tk, _tkagg
lib/matplotlib/tests/test_backend_tk.py:188:    from matplotlib.backends.backend_tkagg import NavigationToolbar2Tk
lib/matplotlib/tests/test_backend_tk.py:250:    from matplotlib.backends.backend_tkagg import (
lib/matplotlib/tests/test_backend_tk.py:252:    from matplotlib.backend_bases import key_press_handler
./meson.build:8:  # qt_editor backend is MIT
./meson.build:9:  # ResizeObserver at end of lib/matplotlib/backends/web_backend/js/mpl.js is CC0
./pyproject.toml:70:build-backend = "mesonpy"
./pyproject.toml:196:"lib/matplotlib/backends/backend_template.py" = ["F401"]
./pyproject.toml:229:  ".*/matplotlib/(sphinxext|backends|pylab|testing/jpl_units)",
./pyproject.toml:234:  #removing tests causes errors in backends
./src/meson.build:34:  '_backend_agg': {
./src/meson.build:35:    'subdir': 'matplotlib/backends',
./src/meson.build:37:      '_backend_agg.cpp',
./src/meson.build:38:      '_backend_agg_wrapper.cpp',
./src/meson.build:93:    'subdir': 'matplotlib/backends',
./src/meson.build:142:    subdir: 'matplotlib/backends',
./lib/matplotlib/meson.build:27:  'backend_bases.py',
./lib/matplotlib/meson.build:28:  'backend_managers.py',
./lib/matplotlib/meson.build:29:  'backend_tools.py',
./lib/matplotlib/meson.build:97:  'backend_bases.pyi',
./lib/matplotlib/meson.build:98:  'backend_managers.pyi',
./lib/matplotlib/meson.build:99:  'backend_tools.pyi',
./lib/matplotlib/meson.build:162:subdir('backends')

        or a string of the form: ``module://my.module.name``.

        notebook is a synonym for nbAgg.

        Switching to an interactive backend is not possible if an unrelated
        event loop has already been started (e.g., switching to GTK3Agg if a
        TkAgg window has already been opened).  Switching to a non-interactive
        backend is always possible.

    force : bool, default: True
        If True (the default), raise an `ImportError` if the backend cannot be
        set up (either because it fails to import, or because an incompatible
        GUI interactive framework is already running); if False, silently
        ignore the failure.

    See Also
    --------
    :ref:`backends`
    matplotlib.get_backend
    matplotlib.pyplot.switch_backend

    """
    name = rcsetup.validate_backend(backend)
    # don't (prematurely) resolve the "auto" backend setting
    if rcParams._get_backend_or_none() == name:
        # Nothing to do if the requested backend is already set
        pass
    else:
        # if pyplot is not already imported, do not import it.  Doing
        # so may trigger a `plt.switch_backend` to the _default_ backend
        # before we get a chance to change to the one the user just requested
        plt = sys.modules.get('matplotlib.pyplot')
        # if pyplot is imported, then try to change backends
        if plt is not None:
            try:
                # we need this import check here to re-raise if the
                # user does not have the libraries to support their
                # chosen backend installed.
                plt.switch_backend(name)
            except ImportError:
                if force:
                    raise
        # if we have not imported pyplot, then we can set the rcParam
        # value which will be respected when the user finally imports
        # pyplot

        .. admonition:: Provisional

           The *auto_select* flag is provisional. It may be changed or removed
           without prior warning.

    See Also
    --------
    matplotlib.use
    """
    if auto_select:
        return rcParams['backend']
    else:
        backend = rcParams._get('backend')
        if backend is rcsetup._auto_backend_sentinel:
            return None
        else:
            return backend


def interactive(b):
    """
    Set whether to redraw after every plotting command (e.g. `.pyplot.xlabel`).
    """
    rcParams['interactive'] = b
```

## 原始行 21 · command_execution

命令：
```
/bin/bash -lc "sed -n '300,355p' doc/release/prev_whats_new/whats_new_3.9.0.rst; sed -n '60,92p' doc/api/prev_api_changes/api_changes_3.9.0/deprecations.rst; grep -RIn \"backend_registry\\.\" doc | head -200; grep -RIn \"matplotlib.backend\" . --exclude='*.pyc' 2>/dev/null | grep -E \"entry|plugin|project.entry\" | head -150; find . -type f | wc -l; git status --short 2>/dev/null || true"
```

退出码：`0`

输出：
```
    :include-source:
    :alt: Example of the new behavior of 3D axis limits, and how setting the rcParam reverts to the old behavior.

    fig, axs = plt.subplots(1, 2, subplot_kw={'projection': '3d'})

    plt.rcParams['axes3d.automargin'] = True
    axs[0].set(xlim=(0, 1), ylim=(0, 1), zlim=(0, 1), title='Old Behavior')

    plt.rcParams['axes3d.automargin'] = False  # the default in 3.9.0
    axs[1].set(xlim=(0, 1), ylim=(0, 1), zlim=(0, 1), title='New Behavior')

Other improvements
==================

BackendRegistry
---------------

New :class:`~matplotlib.backends.registry.BackendRegistry` class is the single source of
truth for available backends. The singleton instance is
``matplotlib.backends.backend_registry``. It is used internally by Matplotlib, and also
IPython (and therefore Jupyter) starting with IPython 8.24.0.

There are three sources of backends: built-in (source code is within the Matplotlib
repository), explicit ``module://some.backend`` syntax (backend is obtained by loading
the module), or via an entry point (self-registering backend in an external package).

To obtain a list of all registered backends use:

    >>> from matplotlib.backends import backend_registry
    >>> backend_registry.list_all()

Add ``widths``, ``heights`` and ``angles`` setter to ``EllipseCollection``
--------------------------------------------------------------------------

The ``widths``, ``heights`` and ``angles`` values of the
`~matplotlib.collections.EllipseCollection` can now be changed after the collection has
been created.

.. plot::
    :include-source:

    from matplotlib.collections import EllipseCollection

    rng = np.random.default_rng(0)

    widths = (2, )
    heights = (3, )
    angles = (45, )
    offsets = rng.random((10, 2)) * 10

    fig, ax = plt.subplots()

    ec = EllipseCollection(
        widths=widths,
        heights=heights,
        angles=angles,

*nth_coord* parameter to axisartist helpers for fixed axis
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Helper APIs in `.axisartist` for generating a "fixed" axis on rectilinear axes
(`.FixedAxisArtistHelperRectilinear`) no longer take a *nth_coord* parameter, as that
parameter is entirely inferred from the (required) *loc* parameter and having
inconsistent *nth_coord* and *loc* is an error.

For curvilinear axes, the *nth_coord* parameter remains supported (it affects the
*ticks*, not the axis position itself), but that parameter will become keyword-only, for
consistency with the rectilinear case.

``rcsetup.interactive_bk``, ``rcsetup.non_interactive_bk`` and ``rcsetup.all_backends``
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

... are deprecated and replaced by ``matplotlib.backends.backend_registry.list_builtin``
with the following arguments

- ``matplotlib.backends.BackendFilter.INTERACTIVE``
- ``matplotlib.backends.BackendFilter.NON_INTERACTIVE``
- ``None``

respectively.

Miscellaneous deprecations
^^^^^^^^^^^^^^^^^^^^^^^^^^

- ``backend_ps.get_bbox_header`` is considered an internal helper
- ``BboxTransformToMaxOnly``; if you rely on this, please make a copy of the code
- ``ContourLabeler.add_label_clabeltext``
- ``TransformNode.is_bbox``; instead check the object using ``isinstance(...,
  BboxBase)``
doc/release/prev_whats_new/whats_new_3.9.0.rst:329:    >>> backend_registry.list_all()
doc/api/prev_api_changes/api_changes_3.9.0/deprecations.rst:76:... are deprecated and replaced by ``matplotlib.backends.backend_registry.list_builtin``
doc/api/next_api_changes/removals/30067-OG.rst:9:... are removed and replaced by ``matplotlib.backends.backend_registry.list_builtin``
./galleries/users_explain/figure/writing_a_backend_pyplot_interface.rst:123:    [project.entry-points."matplotlib.backend"]
10626
```

## 原始行 23 · command_execution

命令：
```
/bin/bash -lc "sed -n '95,150p' galleries/users_explain/figure/writing_a_backend_pyplot_interface.rst; find . -type f | grep -E '(backend_registry|registry)'"
```

退出码：`0`

输出：
```
Built-in
^^^^^^^^

A backend built into Matplotlib must have its name and
``FigureCanvas.required_interactive_framework`` hard-coded in the
:class:`~matplotlib.backends.registry.BackendRegistry`.  If the backend module
is not ``f"matplotlib.backends.backend_{backend_name.lower()}"`` then there
must also be an entry in the ``BackendRegistry._name_to_module``.

module:// syntax
^^^^^^^^^^^^^^^^

Any backend in a separate module (not built into Matplotlib) can be used by
specifying the path to the module in the form ``module://some.backend.module``.
An example is ``module://mplcairo.qt`` for
`mplcairo <https://github.com/matplotlib/mplcairo>`_.  The backend's
interactive framework will be taken from its
``FigureCanvas.required_interactive_framework``.

Entry point
^^^^^^^^^^^

An external backend module can self-register as a backend using an
``entry point`` in its ``pyproject.toml`` such as the one used by
``matplotlib-inline``:

.. code-block:: toml

    [project.entry-points."matplotlib.backend"]
    inline = "matplotlib_inline.backend_inline"

The backend's interactive framework will be taken from its
``FigureCanvas.required_interactive_framework``.  All entry points are loaded
together but only when first needed, such as when a backend name is not
recognised as a built-in backend, or when
:meth:`~matplotlib.backends.registry.BackendRegistry.list_all` is first called.
./lib/matplotlib/backends/registry.pyi
./lib/matplotlib/backends/registry.py
./doc/api/backend_registry_api.rst
```

## 原始行 29 · agent_message

```
The nearby API contracts confirm two additional private helpers are required for the public methods to work: entry-point discovery and GUI inspection by loading the backend module. I’ll implement those as part of the registry, keeping discovery lazy and dynamic GUI state cached only after successful resolution.
```

## 原始行 31 · file_change

```
{
  "id": "item_20",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/lib/matplotlib/backends/registry.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 34 · file_change

```
{
  "id": "item_22",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/lib/matplotlib/backends/registry.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 37 · command_execution

命令：
```
/bin/bash -lc "sed -n '90,360p' lib/matplotlib/backends/registry.py; python -m py_compile lib/matplotlib/backends/registry.py; python -m pytest -q lib/matplotlib/tests/test_matplotlib.py -k 'use_doc_standard_backends'"
```

退出码：`4`

输出：
```
        # "module://some.backend" syntax.
        self._name_to_module = {
            "notebook": "nbagg",
        }

    def _backend_module_name(self, backend):
        if backend.startswith("module://"):
            return backend[9:]

        # Return name of module containing the specified backend.
        # Does not check if the backend is valid, use is_valid_backend for that.
        backend = backend.lower()

        # Check if have specific name to module mapping.
        backend = self._name_to_module.get(backend, backend)

        return (backend[9:] if backend.startswith("module://")
                else f"matplotlib.backends.backend_{backend}")

    def _clear(self):
        # Clear all dynamically-added data, used for testing only.
        self.__init__()

    def _ensure_entry_points_loaded(self):
        """Load and register backend entry points, once."""
        if not self._loaded_entry_points:
            entries = self._read_entry_points()
            self._validate_and_store_entry_points(entries)
            self._loaded_entry_points = True

    def _get_gui_framework_by_loading(self, backend):
        """Load *backend* and return its GUI framework designation."""
        module = self.load_backend_module(backend)
        framework = module.FigureCanvas.required_interactive_framework
        return framework or "headless"

    def _read_entry_points(self):
        """Return ``(name, module)`` pairs advertised as backend entry points."""
        import importlib.metadata as im

        return [(entry.name, entry.value)
                for entry in im.entry_points(group="matplotlib.backend")]

    def _validate_and_store_entry_points(self, entries):
        """Validate and store entry points for later backend resolution."""
        # Collapse only exact duplicates.  In particular, entries which differ
        # merely in the case of their name are conflicting entries, rather than
        # duplicates, because backend names are case-insensitive.
        entries = list(dict.fromkeys(entries))
        normalized = [(name.lower(), module) for name, module in entries]

        for name, _ in normalized:
            if name.startswith("module://"):
                raise RuntimeError(
                    f"Entry point name {name!r} cannot start with 'module://'")
            if name in self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK:
                raise RuntimeError(
                    f"Entry point name {name!r} is a built-in backend")

        names = [name for name, _ in normalized]
        if len(names) != len(set(names)):
            raise RuntimeError("Entry point backend name is duplicated")

        # Do not partly update the registry if validation above fails.
        for name, module in normalized:
            self._name_to_module[name] = module
            self._backend_to_gui_framework[name] = "unknown"

    def backend_for_gui_framework(self, framework):
        """Return the preferred built-in backend for *framework*, if any."""
        return self._GUI_FRAMEWORK_TO_BACKEND.get(framework.lower())

    def list_all(self):
        """Return all built-in and dynamically registered backend names."""
        self._ensure_entry_points_loaded()
        return [*self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK,
                *self._backend_to_gui_framework]

    def list_builtin(self, filter_=None):
        """Return built-in backend names, optionally filtered by interactivity."""
        if filter_ is BackendFilter.INTERACTIVE:
            return [backend for backend, framework in
                    self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK.items()
                    if framework != "headless"]
        if filter_ is BackendFilter.NON_INTERACTIVE:
            return [backend for backend, framework in
                    self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK.items()
                    if framework == "headless"]
        return list(self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK)

    def list_gui_frameworks(self):
        """Return GUI framework names having a preferred built-in backend."""
        return [framework for framework in self._GUI_FRAMEWORK_TO_BACKEND
                if framework != "headless"]

    def is_valid_backend(self, backend):
        """
        Return True if the backend name is valid, False otherwise.

        A backend name is valid if it is one of the built-in backends or has been
        dynamically added via an entry point. Those beginning with ``module://`` are
        always considered valid and are added to the current list of all backends
        within this function.

        Even if a name is valid, it may not be importable or usable. This can only be
        determined by loading and using the backend module.

        Parameters
        ----------
        backend : str
            Name of backend.

        Returns
        -------
        bool
            True if backend is valid, False otherwise.
        """
        if not backend.startswith("module://"):
            backend = backend.lower()

        # For backward compatibility, convert ipympl and matplotlib-inline long
        # module:// names to their shortened forms.
        backwards_compat = {
            "module://ipympl.backend_nbagg": "widget",
            "module://matplotlib_inline.backend_inline": "inline",
        }
        backend = backwards_compat.get(backend, backend)

        if (backend in self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK or
                backend in self._backend_to_gui_framework):
            return True

        if backend.startswith("module://"):
            self._backend_to_gui_framework[backend] = "unknown"
            return True

        # Only load entry points if really need to and not already done so.
        self._ensure_entry_points_loaded()
        if backend in self._backend_to_gui_framework:
            return True

        return False

    def resolve_backend(self, backend):
        """Return the normalized backend name and its required GUI framework."""
        if not isinstance(backend, str):
            import matplotlib

            backend = matplotlib.get_backend()

        # Module names are case-sensitive, unlike ordinary backend names.
        if not backend.startswith("module://"):
            backend = backend.lower()

        if backend in self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK:
            framework = self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK[backend]
        else:
            if backend.startswith("module://"):
                # An explicit module specification is intrinsically a valid
                # backend, but its GUI requirement is not known until import.
                self._backend_to_gui_framework.setdefault(backend, "unknown")
            elif backend not in self._backend_to_gui_framework:
                # Do not inspect entry points for built-ins, explicit modules,
                # or dynamic backends that are already known.
                self._ensure_entry_points_loaded()

            try:
                framework = self._backend_to_gui_framework[backend]
            except KeyError:
                raise RuntimeError(
                    f"{backend!r} is not a recognised backend name") from None

            if framework == "unknown":
                # Assign only after a successful import and inspection, so a
                # transient import error can be retried on the next call.
                framework = self._get_gui_framework_by_loading(backend)
                self._backend_to_gui_framework[backend] = framework

        return backend, (None if framework == "headless" else framework)

    def resolve_gui_or_backend(self, gui_or_backend):
        """Resolve a string interpreted first as a GUI loop, then a backend."""
        # Deliberately use a string method before resolve_backend: unlike that
        # method, None is not a request for the current backend here.
        if gui_or_backend.startswith("module://"):
            normalized = gui_or_backend
        else:
            normalized = gui_or_backend.lower()

        backend = self.backend_for_gui_framework(normalized)
        if backend is not None:
            return backend, (None if normalized == "headless" else normalized)

        try:
            return self.resolve_backend(normalized)
        except Exception:
            raise RuntimeError(
                f"{gui_or_backend!r} is not a recognised GUI loop or "
                "backend name") from None

    def load_backend_module(self, backend):
        """
        Load and return the module containing the specified backend.

        Parameters
        ----------
        backend : str
            Name of backend to load.

        Returns
        -------
        Module
            Module containing backend.
        """
        module_name = self._backend_module_name(backend)
        return importlib.import_module(module_name)























































ninja: error: rebuilding 'build.ninja': subcommand failed
ImportError while loading conftest '/testbed/lib/matplotlib/tests/conftest.py'.
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_matplotlib_editable_loader.py:311: in find_spec
    tree = self._rebuild()
           ^^^^^^^^^^^^^^^
/opt/miniconda3/envs/testbed/lib/python3.11/site-packages/_matplotlib_editable_loader.py:347: in _rebuild
    raise ImportError(f're-building the {self._name} meson-python editable wheel package failed') from exc
E   ImportError: re-building the matplotlib meson-python editable wheel package failed
```

## 原始行 39 · agent_message

```
The implementation compiles. The focused pytest run is currently blocked before collection by the repository’s editable-install rebuild hook (`ninja` fails while rebuilding), so I’m checking the build failure separately and will also exercise the registry directly with isolated mocks.
```

## 原始行 41 · command_execution

命令：
```
/bin/bash -lc 'find build -maxdepth 2 -name build.ninja -print 2>/dev/null; ninja -C build -v 2>&1 | tail -120'
```

退出码：`0`

输出：
```
build/cp311/build.ninja
ninja: Entering directory `build'
ninja: error: loading 'build.ninja': No such file or directory
```

## 原始行 44 · command_execution

命令：
```
/bin/bash -lc 'ninja -C build/cp311 -v'
```

退出码：`1`

输出：
```
ninja: Entering directory `build/cp311'
[0/1] /opt/miniconda3/envs/testbed/bin/meson --internal regenerate /testbed .
The Meson build system
Version: 1.9.1
Source dir: /testbed
Build dir: /testbed/build/cp311
Build type: native build
Program python found: YES 3.11.14 3.11.14
Project name: matplotlib
Project version: 0.1.0.dev1+g5317930.d20261010
C compiler for the host machine: cc (gcc 11.4.0 "cc (Ubuntu 11.4.0-1ubuntu1~22.04.2) 11.4.0")
C linker for the host machine: cc ld.bfd 2.38
C++ compiler for the host machine: c++ (gcc 11.4.0 "c++ (Ubuntu 11.4.0-1ubuntu1~22.04.2) 11.4.0")
C++ linker for the host machine: c++ ld.bfd 2.38
Host machine cpu family: x86_64
Host machine cpu: x86_64
Program python found: YES (/opt/miniconda3/envs/testbed/bin/python)
Dependency pybind11 found: YES 3.0.1 (cached)

Executing subproject freetype-2.6.1 

freetype-2.6.1| Project name: freetype2
freetype-2.6.1| Project version: 2.6.1
freetype-2.6.1| C compiler for the host machine: cc (gcc 11.4.0 "cc (Ubuntu 11.4.0-1ubuntu1~22.04.2) 11.4.0")
freetype-2.6.1| C linker for the host machine: cc ld.bfd 2.38
freetype-2.6.1| Has header "unistd.h" : YES (cached)
freetype-2.6.1| Has header "fcntl.h" : YES (cached)
freetype-2.6.1| Has header "stdint.h" : YES (cached)
freetype-2.6.1| Configuring ftconfig.h using configuration
freetype-2.6.1| Configuring ftoption.h using configuration
freetype-2.6.1| Build targets in project: 2
freetype-2.6.1| Subproject freetype-2.6.1 finished.


Executing subproject qhull 

qhull| Project name: qhull
qhull| Project version: 8.0.2
qhull| C compiler for the host machine: cc (gcc 11.4.0 "cc (Ubuntu 11.4.0-1ubuntu1~22.04.2) 11.4.0")
qhull| C linker for the host machine: cc ld.bfd 2.38
qhull| Build targets in project: 3
qhull| Subproject qhull finished.

Dependency dl found: YES unknown (cached)
Configuring _version.py using configuration
Program /testbed/tools/generate_matplotlibrc.py found: YES (/testbed/tools/generate_matplotlibrc.py)

../../lib/matplotlib/tests/meson.build:97:4: ERROR: File test_backend_registry.py does not exist.

A full log can be found at /testbed/build/cp311/meson-logs/meson-log.txt
FAILED: build.ninja 
/opt/miniconda3/envs/testbed/bin/meson --internal regenerate /testbed .
ninja: error: rebuilding 'build.ninja': subcommand failed
```

## 原始行 48 · command_execution

命令：
```
/bin/bash -lc "grep -RInE \"ipympl|matplotlib.inline|matplotlib_inline|widget.*backend|inline.*backend\" doc lib/matplotlib | head -250; sed -n '85,115p' doc/release/prev_whats_new/github_stats_3.9.1.rst; grep -RIn \"BackendRegistry\" doc/release | head -80"
```

退出码：`0`

输出：
```
doc/release/prev_whats_new/github_stats_3.5.0.rst:1104:* :ghpull:`16788`: Adding png image return for inline backend figures with _repr_html_
doc/release/prev_whats_new/github_stats_3.8.0.rst:840:* :ghissue:`15913`: Switching to inline backend closes GUI windows
doc/release/prev_whats_new/whats_new_3.6.0.rst:567:ps, and inline backends.
doc/release/prev_whats_new/github_stats_3.6.0.rst:262:* :ghpull:`23755`: Backport PR #23742 on branch v3.6.x (FIX: unbreak ipympl)
doc/release/prev_whats_new/github_stats_3.6.0.rst:264:* :ghpull:`23742`: FIX: unbreak ipympl
doc/release/prev_whats_new/github_stats_3.0.2.rst:300:* :ghissue:`4853`: %matplotlib notebook creates much bigger figures than %matplotlib inline
doc/release/prev_whats_new/github_stats_3.0.2.rst:425:* :ghissue:`12370`: ImageGrid bug when using inline backend
doc/release/prev_whats_new/github_stats_3.4.2.rst:152:* :ghissue:`19958`: subfigures missing bbox_inches attribute in inline backend
doc/release/prev_whats_new/github_stats_3.3.0.rst:1288:* :ghissue:`16463`: Jupyter "inline" backend seems to misinterpret "figsize" with Axes3D
doc/release/prev_whats_new/github_stats_3.3.0.rst:1339:* :ghissue:`14596`: forward port jquery removal from ipympl
doc/release/prev_whats_new/github_stats_3.7.1.rst:48:* :ghpull:`25354`: Backport PR #25353 on branch v3.7.x (link to ipympl docs instead of github)
doc/release/prev_whats_new/github_stats_3.0.3.rst:136:* :ghissue:`10360`: creating PathCollection proxy artist with %matplotlib inline raises ValueError: cannot convert float NaN to integer
doc/devel/release_guide.rst:113:Run the User Acceptance Tests for the NBAgg and ipympl backends::
doc/devel/release_guide.rst:117:For ipympl, restart the kernel, add a cell for ``%matplotlib widget`` and do
doc/devel/release_guide.rst:120:to work for ``ipympl``.
lib/matplotlib/pyplot.py:517:    if newbackend in ("ipympl", "widget"):
lib/matplotlib/pyplot.py:518:        # ipympl < 0.9.4 expects rcParams["backend"] to be the fully-qualified backend
lib/matplotlib/pyplot.py:519:        # name "module://ipympl.backend_nbagg" not short names "ipympl" or "widget".
lib/matplotlib/pyplot.py:523:            module_version = im.version("ipympl")
lib/matplotlib/pyplot.py:525:                newbackend = "module://ipympl.backend_nbagg"
lib/matplotlib/pyplot.py:637:    The jupyter backends (activated via ``%matplotlib inline``,
lib/matplotlib/text.py:709:        by ``%matplotlib inline`` in IPython/Jupyter). The 'tight' setting
lib/matplotlib/backends/backend_webagg_core.py:389:        # This handler is for backwards-compatibility with older ipympl.
lib/matplotlib/backends/backend_webagg_core.py:460:    # This must be None to not break ipympl
lib/matplotlib/backends/registry.py:210:        # For backward compatibility, convert ipympl and matplotlib-inline long
lib/matplotlib/backends/registry.py:213:            "module://ipympl.backend_nbagg": "widget",
lib/matplotlib/backends/registry.py:214:            "module://matplotlib_inline.backend_inline": "inline",
lib/matplotlib/tests/test_backend_inline.py:12:pytest.importorskip('matplotlib_inline')
lib/matplotlib/tests/test_backend_inline.py:40:        expected_backend = "module://matplotlib_inline.backend_inline"
lib/matplotlib/tests/data/test_inline_01.ipynb:9:    "%matplotlib inline\n",
* :ghpull:`28459`: DOC: Document kwargs scope for tick setter functions
* :ghpull:`28450`: Backport of 28371 and 28411
* :ghpull:`28446`: Backport PR #28403 on branch v3.9.x (FIX: Autoscale support in add_collection3d for Line3DCollection and Poly3DCollection
* :ghpull:`28445`: Backport PR #28403 on branch v3.9.x (FIX: Autoscale support in add_collection3d for Line3DCollection and Poly3DCollection)
* :ghpull:`28438`: Backport PR #28436 on branch v3.9.x (Fix ``is_color_like`` for 2-tuple of strings and fix ``to_rgba`` for ``(nth_color, alpha)``)
* :ghpull:`28403`: FIX: Autoscale support in add_collection3d for Line3DCollection and Poly3DCollection
* :ghpull:`28443`: Backport PR #28441 on branch v3.9.x (MNT: Update basic units example to work with numpy 2.0)
* :ghpull:`28441`: MNT: Update basic units example to work with numpy 2.0
* :ghpull:`28436`: Fix ``is_color_like`` for 2-tuple of strings and fix ``to_rgba`` for ``(nth_color, alpha)``
* :ghpull:`28426`: Backport PR #28425 on branch v3.9.x (Fix Circle yaml line length)
* :ghpull:`28427`: Fix circleci yaml
* :ghpull:`28425`: Fix Circle yaml line length
* :ghpull:`28422`: Backport PR #28401 on branch v3.9.x (FIX: Fix text wrapping)
* :ghpull:`28424`: Backport PR #28423 on branch v3.9.x (Update return type for Axes.axhspan and Axes.axvspan)
* :ghpull:`28423`: Update return type for Axes.axhspan and Axes.axvspan
* :ghpull:`28401`: FIX: Fix text wrapping
* :ghpull:`28419`: Backport PR #28414 on branch v3.9.x (Clean up obsolete widget code)
* :ghpull:`28411`: Bump the actions group with 3 updates
* :ghpull:`28414`: Clean up obsolete widget code
* :ghpull:`28415`: Backport PR #28413 on branch v3.9.x (CI: update action that got moved org)
* :ghpull:`28413`: CI: update action that got moved org
* :ghpull:`28392`: Backport PR #28388 on branch v3.9.x (Allow duplicate (name, value) entry points for backends)
* :ghpull:`28362`: Backport PR #28337 on branch v3.9.x (Bump the actions group across 1 directory with 3 updates)
* :ghpull:`28388`: Allow duplicate (name, value) entry points for backends
* :ghpull:`28389`: Backport PR #28380 on branch v3.9.x (Remove outdated docstring section in RendererBase.draw_text.)
* :ghpull:`28380`: Remove outdated docstring section in RendererBase.draw_text.
* :ghpull:`28385`: Backport PR #28377 on branch v3.9.x (DOC: Clarify scope of wrap.)
* :ghpull:`28377`: DOC: Clarify scope of wrap.
* :ghpull:`28368`: Backport PR #28359 on branch v3.9.x (Document that axes unsharing is impossible.)
* :ghpull:`28359`: Document that axes unsharing is impossible.
* :ghpull:`28337`: Bump the actions group across 1 directory with 3 updates
doc/release/prev_whats_new/github_stats_3.9.0.rst:330:* :ghpull:`27719`: Add BackendRegistry singleton class
doc/release/prev_whats_new/whats_new_3.9.0.rst:314:BackendRegistry
doc/release/prev_whats_new/whats_new_3.9.0.rst:317:New :class:`~matplotlib.backends.registry.BackendRegistry` class is the single source of
```

## 原始行 51 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import importlib.util
from types import SimpleNamespace
from unittest.mock import Mock, patch

spec = importlib.util.spec_from_file_location('tested_registry', 'lib/matplotlib/backends/registry.py')
mod = importlib.util.module_from_spec(spec)
spec.loader.exec_module(mod)
R, F = mod.BackendRegistry, mod.BackendFilter
r = R()
r._read_entry_points = Mock(return_value=[('CuStOm', 'custom.module'), ('same', 'x'), ('same', 'x')])
assert r.list_builtin(F.INTERACTIVE)[0] == 'gtk3agg'
assert r.list_builtin(F.NON_INTERACTIVE) == ['agg', 'cairo', 'pdf', 'pgf', 'ps', 'svg', 'template']
assert r.list_gui_frameworks() == ['gtk3', 'gtk4', 'macosx', 'qt', 'qt5', 'qt6', 'tk', 'wx']
assert r.backend_for_gui_framework('QT6') == 'qtagg'
assert r.resolve_backend('AgG') == ('agg', None)
assert r._read_entry_points.call_count == 0
assert r.list_all()[-2:] == ['custom', 'same']
assert r._read_entry_points.call_count == 1
fake = SimpleNamespace(FigureCanvas=SimpleNamespace(required_interactive_framework='special'))
r.load_backend_module = Mock(return_value=fake)
assert r.resolve_backend('CUSTOM') == ('custom', 'special')
assert r.resolve_backend('custom') == ('custom', 'special')
assert r.load_backend_module.call_count == 1
assert r.resolve_gui_or_backend('Qt6') == ('qtagg', 'qt6')
assert r.resolve_gui_or_backend('HEADLESS') == ('agg', None)
r.load_backend_module = Mock(return_value=SimpleNamespace(
    FigureCanvas=SimpleNamespace(required_interactive_framework=None)))
name = 'module://CaseSensitive.Backend'
assert r.resolve_backend(name) == (name, None)
assert name in r.list_all()

for entries in [
        [('agg', 'x')], [('MODULE://bad', 'x')],
        [('foo', 'x'), ('FOO', 'x')], [('foo', 'x'), ('foo', 'y')]]:
    rr = R()
    try:
        rr._validate_and_store_entry_points(entries)
    except RuntimeError:
        pass
    else:
        raise AssertionError(entries)
print('direct registry checks passed')
PY"
```

退出码：`0`

输出：
```
direct registry checks passed
```

## 原始行 54 · command_execution

命令：
```
/bin/bash -lc 'git diff -- lib/matplotlib/backends/registry.py; git status --short'
```

退出码：`0`

输出：
```
diff --git a/lib/matplotlib/backends/registry.py b/lib/matplotlib/backends/registry.py
index 55e4d8f..603af8d 100644
--- a/lib/matplotlib/backends/registry.py
+++ b/lib/matplotlib/backends/registry.py
@@ -110,94 +110,77 @@ class BackendRegistry:
         # Clear all dynamically-added data, used for testing only.
         self.__init__()
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+    def _ensure_entry_points_loaded(self):
+        """Load and register backend entry points, once."""
+        if not self._loaded_entry_points:
+            entries = self._read_entry_points()
+            self._validate_and_store_entry_points(entries)
+            self._loaded_entry_points = True
+
+    def _get_gui_framework_by_loading(self, backend):
+        """Load *backend* and return its GUI framework designation."""
+        module = self.load_backend_module(backend)
+        framework = module.FigureCanvas.required_interactive_framework
+        return framework or "headless"
+
+    def _read_entry_points(self):
+        """Return ``(name, module)`` pairs advertised as backend entry points."""
+        import importlib.metadata as im
+
+        return [(entry.name, entry.value)
+                for entry in im.entry_points(group="matplotlib.backend")]
+
+    def _validate_and_store_entry_points(self, entries):
+        """Validate and store entry points for later backend resolution."""
+        # Collapse only exact duplicates.  In particular, entries which differ
+        # merely in the case of their name are conflicting entries, rather than
+        # duplicates, because backend names are case-insensitive.
+        entries = list(dict.fromkeys(entries))
+        normalized = [(name.lower(), module) for name, module in entries]
+
+        for name, _ in normalized:
+            if name.startswith("module://"):
+                raise RuntimeError(
+                    f"Entry point name {name!r} cannot start with 'module://'")
+            if name in self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK:
+                raise RuntimeError(
+                    f"Entry point name {name!r} is a built-in backend")
+
+        names = [name for name, _ in normalized]
+        if len(names) != len(set(names)):
+            raise RuntimeError("Entry point backend name is duplicated")
+
+        # Do not partly update the registry if validation above fails.
+        for name, module in normalized:
+            self._name_to_module[name] = module
+            self._backend_to_gui_framework[name] = "unknown"
+
+    def backend_for_gui_framework(self, framework):
+        """Return the preferred built-in backend for *framework*, if any."""
+        return self._GUI_FRAMEWORK_TO_BACKEND.get(framework.lower())
+
+    def list_all(self):
+        """Return all built-in and dynamically registered backend names."""
+        self._ensure_entry_points_loaded()
+        return [*self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK,
+                *self._backend_to_gui_framework]
+
+    def list_builtin(self, filter_=None):
+        """Return built-in backend names, optionally filtered by interactivity."""
+        if filter_ is BackendFilter.INTERACTIVE:
+            return [backend for backend, framework in
+                    self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK.items()
+                    if framework != "headless"]
+        if filter_ is BackendFilter.NON_INTERACTIVE:
+            return [backend for backend, framework in
+                    self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK.items()
+                    if framework == "headless"]
+        return list(self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK)
+
+    def list_gui_frameworks(self):
+        """Return GUI framework names having a preferred built-in backend."""
+        return [framework for framework in self._GUI_FRAMEWORK_TO_BACKEND
+                if framework != "headless"]
 
     def is_valid_backend(self, backend):
         """
@@ -247,57 +230,62 @@ class BackendRegistry:
 
         return False
 
+    def resolve_backend(self, backend):
+        """Return the normalized backend name and its required GUI framework."""
+        if not isinstance(backend, str):
+            import matplotlib
 
+            backend = matplotlib.get_backend()
 
+        # Module names are case-sensitive, unlike ordinary backend names.
+        if not backend.startswith("module://"):
+            backend = backend.lower()
 
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
-
+        if backend in self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK:
+            framework = self._BUILTIN_BACKEND_TO_GUI_FRAMEWORK[backend]
+        else:
+            if backend.startswith("module://"):
+                # An explicit module specification is intrinsically a valid
+                # backend, but its GUI requirement is not known until import.
+                self._backend_to_gui_framework.setdefault(backend, "unknown")
+            elif backend not in self._backend_to_gui_framework:
+                # Do not inspect entry points for built-ins, explicit modules,
+                # or dynamic backends that are already known.
+                self._ensure_entry_points_loaded()
+
+            try:
+                framework = self._backend_to_gui_framework[backend]
+            except KeyError:
+                raise RuntimeError(
+                    f"{backend!r} is not a recognised backend name") from None
+
+            if framework == "unknown":
+                # Assign only after a successful import and inspection, so a
+                # transient import error can be retried on the next call.
+                framework = self._get_gui_framework_by_loading(backend)
+                self._backend_to_gui_framework[backend] = framework
+
+        return backend, (None if framework == "headless" else framework)
+
+    def resolve_gui_or_backend(self, gui_or_backend):
+        """Resolve a string interpreted first as a GUI loop, then a backend."""
+        # Deliberately use a string method before resolve_backend: unlike that
+        # method, None is not a request for the current backend here.
+        if gui_or_backend.startswith("module://"):
+            normalized = gui_or_backend
+        else:
+            normalized = gui_or_backend.lower()
+
+        backend = self.backend_for_gui_framework(normalized)
+        if backend is not None:
+            return backend, (None if normalized == "headless" else normalized)
+
+        try:
+            return self.resolve_backend(normalized)
+        except Exception:
+            raise RuntimeError(
+                f"{gui_or_backend!r} is not a recognised GUI loop or "
+                "backend name") from None
 
     def load_backend_module(self, backend):
         """
@@ -411,4 +399,4 @@ class BackendRegistry:
 
 
 # Singleton
-backend_registry = BackendRegistry()
\ No newline at end of file
+backend_registry = BackendRegistry()
 M lib/matplotlib/backends/registry.py
```

## 原始行 57 · command_execution

命令：
```
/bin/bash -lc "python - <<'PY'
import sys
for x in sys.meta_path:
 print(type(x), x)
PY
find build/cp311 -maxdepth 3 -type f | head -30"
```

退出码：`0`

输出：
```
<class '_matplotlib_editable_loader.MesonpyMetaFinder'> MesonpyMetaFinder('matplotlib', '/testbed/build/cp311')
<class '_distutils_hack.DistutilsMetaFinder'> <_distutils_hack.DistutilsMetaFinder object at 0x7b050b4be0d0>
<class 'type'> <class '_frozen_importlib.BuiltinImporter'>
<class 'type'> <class '_frozen_importlib.FrozenImporter'>
<class 'type'> <class '_frozen_importlib_external.PathFinder'>
build/cp311/meson-info/intro-targets.json
build/cp311/meson-info/intro-projectinfo.json
build/cp311/meson-info/intro-benchmarks.json
build/cp311/meson-info/intro-tests.json
build/cp311/meson-info/intro-buildsystem_files.json
build/cp311/meson-info/intro-dependencies.json
build/cp311/meson-info/intro-compilers.json
build/cp311/meson-info/meson-info.json
build/cp311/meson-info/intro-install_plan.json
build/cp311/meson-info/intro-buildoptions.json
build/cp311/meson-info/intro-installed.json
build/cp311/meson-info/intro-machines.json
build/cp311/compile_commands.json
build/cp311/meson-logs/meson-log.txt
build/cp311/.ninja_deps
build/cp311/src/_backend_agg.cpython-311-x86_64-linux-gnu.so
build/cp311/src/ft2font.cpython-311-x86_64-linux-gnu.so.p/ft2font.cpp.o
build/cp311/src/ft2font.cpython-311-x86_64-linux-gnu.so.p/ft2font_wrapper.cpp.o
build/cp311/src/_qhull.cpython-311-x86_64-linux-gnu.so
build/cp311/src/_image.cpython-311-x86_64-linux-gnu.so.p/py_converters.cpp.o
build/cp311/src/_image.cpython-311-x86_64-linux-gnu.so.p/_image_wrapper.cpp.o
build/cp311/src/_tri.cpython-311-x86_64-linux-gnu.so
build/cp311/src/_path.cpython-311-x86_64-linux-gnu.so
build/cp311/src/_c_internal_utils.cpython-311-x86_64-linux-gnu.so
build/cp311/src/_image.cpython-311-x86_64-linux-gnu.so
build/cp311/src/_tkagg.cpython-311-x86_64-linux-gnu.so
build/cp311/src/_qhull.cpython-311-x86_64-linux-gnu.so.p/_qhull_wrapper.cpp.o
build/cp311/src/_tri.cpython-311-x86_64-linux-gnu.so.p/tri__tri.cpp.o
build/cp311/src/_tri.cpython-311-x86_64-linux-gnu.so.p/tri__tri_wrapper.cpp.o
build/cp311/src/_tkagg.cpython-311-x86_64-linux-gnu.so.p/_tkagg.cpp.o
```

## 原始行 62 · command_execution

命令：
```
/bin/bash -lc "ruff check lib/matplotlib/backends/registry.py 2>&1 || true; python - <<'PY'
import importlib.util
from unittest.mock import Mock

spec = importlib.util.spec_from_file_location('registry_under_test', 'lib/matplotlib/backends/registry.py')
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)
r = m.BackendRegistry()
r._read_entry_points = Mock(return_value=[])
try:
    r.resolve_backend('does-not-exist')
except RuntimeError as e:
    assert 'recognised backend name' in str(e)
else:
    raise AssertionError
assert r._read_entry_points.call_count == 1
# Discovery is not repeated after an unknown backend miss.
try:
    r.resolve_backend('another-miss')
except RuntimeError:
    pass
assert r._read_entry_points.call_count == 1
# GUI fallback intentionally converts import/inspection failures.
r._backend_to_gui_framework['broken'] = 'unknown'
r._get_gui_framework_by_loading = Mock(side_effect=ValueError('inspection failed'))
try:
    r.resolve_gui_or_backend('BROKEN')
except RuntimeError as e:
    assert 'GUI loop or backend name' in str(e)
else:
    raise AssertionError
# Direct backend resolution leaves that same inspection error untouched.
try:
    r.resolve_backend('broken')
except ValueError as e:
    assert str(e) == 'inspection failed'
else:
    raise AssertionError
print('lazy discovery and exception checks passed')
PY"
```

退出码：`0`

输出：
```
/bin/bash: line 1: ruff: command not found
lazy discovery and exception checks passed
```

## 原始行 67 · command_execution

命令：
```
/bin/bash -lc 'nl -ba lib/matplotlib/backends/registry.py | tail -125'
```

退出码：`0`

输出：
```
   278	
   279	        backend = self.backend_for_gui_framework(normalized)
   280	        if backend is not None:
   281	            return backend, (None if normalized == "headless" else normalized)
   282	
   283	        try:
   284	            return self.resolve_backend(normalized)
   285	        except Exception:
   286	            raise RuntimeError(
   287	                f"{gui_or_backend!r} is not a recognised GUI loop or "
   288	                "backend name") from None
   289	
   290	    def load_backend_module(self, backend):
   291	        """
   292	        Load and return the module containing the specified backend.
   293	
   294	        Parameters
   295	        ----------
   296	        backend : str
   297	            Name of backend to load.
   298	
   299	        Returns
   300	        -------
   301	        Module
   302	            Module containing backend.
   303	        """
   304	        module_name = self._backend_module_name(backend)
   305	        return importlib.import_module(module_name)
   306	
   307	
   308	
   309	
   310	
   311	
   312	
   313	
   314	
   315	
   316	
   317	
   318	
   319	
   320	
   321	
   322	
   323	
   324	
   325	
   326	
   327	
   328	
   329	
   330	
   331	
   332	
   333	
   334	
   335	
   336	
   337	
   338	
   339	
   340	
   341	
   342	
   343	
   344	
   345	
   346	
   347	
   348	
   349	
   350	
   351	
   352	
   353	
   354	
   355	
   356	
   357	
   358	
   359	
   360	
   361	
   362	
   363	
   364	
   365	
   366	
   367	
   368	
   369	
   370	
   371	
   372	
   373	
   374	
   375	
   376	
   377	
   378	
   379	
   380	
   381	
   382	
   383	
   384	
   385	
   386	
   387	
   388	
   389	
   390	
   391	
   392	
   393	
   394	
   395	
   396	
   397	
   398	
   399	
   400	
   401	# Singleton
   402	backend_registry = BackendRegistry()
```

## 原始行 70 · agent_message

```
Direct behavioral checks now cover case normalization, built-in filtering, lazy one-time discovery, duplicate/conflict rejection, module-string preservation, GUI caching, and exception conversion/propagation. Those checks pass; the only unavailable verification is repository pytest collection because the masked `test_backend_registry.py` is referenced by Meson but absent from this checkout.
```

## 原始行 72 · command_execution

命令：
```
/bin/bash -lc "git diff --check; python -m py_compile lib/matplotlib/backends/registry.py; python - <<'PY'
import ast
from pathlib import Path
p = Path('lib/matplotlib/backends/registry.py')
tree = ast.parse(p.read_text())
cls = next(n for n in tree.body if isinstance(n, ast.ClassDef) and n.name == 'BackendRegistry')
methods = {n.name for n in cls.body if isinstance(n, ast.FunctionDef)}
required = {
    '_validate_and_store_entry_points', 'backend_for_gui_framework',
    'list_all', 'list_builtin', 'list_gui_frameworks', 'resolve_backend',
    'resolve_gui_or_backend', '_ensure_entry_points_loaded',
    '_get_gui_framework_by_loading', '_read_entry_points',
}
assert required <= methods, required - methods
print('interface and syntax checks passed')
PY"
```

退出码：`0`

输出：
```
interface and syntax checks passed
```

## 原始行 75 · file_change

```
{
  "id": "item_52",
  "type": "file_change",
  "changes": [
    {
      "path": "/testbed/lib/matplotlib/backends/registry.py",
      "kind": "update"
    }
  ],
  "status": "completed"
}
```

## 原始行 77 · command_execution

命令：
```
/bin/bash -lc 'tail -12 lib/matplotlib/backends/registry.py | nl -ba; git diff --check; git status --short'
```

退出码：`0`

输出：
```
     1	
     2	        Returns
     3	        -------
     4	        Module
     5	            Module containing backend.
     6	        """
     7	        module_name = self._backend_module_name(backend)
     8	        return importlib.import_module(module_name)
     9	
    10	
    11	# Singleton
    12	backend_registry = BackendRegistry()
 M lib/matplotlib/backends/registry.py
```

## 原始行 80 · command_execution

命令：
```
/bin/bash -lc 'git diff --stat; python -m py_compile lib/matplotlib/backends/registry.py'
```

退出码：`0`

输出：
```
 lib/matplotlib/backends/registry.py | 355 +++++++++++++-----------------------
 1 file changed, 125 insertions(+), 230 deletions(-)
```

## 原始行 82 · agent_message

```
Implemented `BackendRegistry` operations in [registry.py](/testbed/lib/matplotlib/backends/registry.py), including:

- Lazy entry-point discovery and validation
- Built-in backend filtering
- GUI framework mappings
- Case normalization with `module://` preservation
- Dynamic backend GUI resolution and caching
- Backend/GUI combined resolution
- Conflict and duplicate detection

Validation:

- Syntax compilation passed
- Direct behavioral checks passed
- `git diff --check` passed
- Full pytest collection is blocked because the masked `test_backend_registry.py` is referenced by Meson but absent from this checkout.
```
