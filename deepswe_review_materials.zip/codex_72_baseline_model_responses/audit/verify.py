"""Recompute the archived audit counts without running recorded commands."""
import csv
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
RECORDS = HERE.parent


def main():
    rows = [json.loads(s) for s in (HERE / "diagnoses.jsonl").read_text().splitlines()]
    summary = json.loads((HERE / "summary.json").read_text())
    manifest = json.loads((RECORDS / "manifest.json").read_text())["records"]
    assert len(rows) == len(manifest) == summary["cohort_runs"] == 72
    assert {r["order"] for r in rows} == set(range(1, 73))
    assert len({r["instance_id"] for r in rows}) == 72
    assert {r["instance_id"] for r in rows} == {r["instance_id"] for r in manifest}
    assert {r["model"] for r in manifest} == {"gpt-5.6-sol"}
    assert {r["reasoning_effort"] for r in manifest} == {"high"}
    for item in manifest:
        folder = RECORDS / item["folder"]
        for name, info in item["files"].items():
            path = folder / name
            assert path.is_file() and not path.is_symlink()
            with path.open("rb") as stream:
                assert hashlib.file_digest(stream, "sha256").hexdigest() == info["sha256"]
        events = [json.loads(s) for s in (folder / "codex_events.jsonl").read_text().splitlines()]
        assert len(events) == item["raw_event_count"]
        task = RECORDS / item["task_statement"]["path"]
        assert hashlib.sha256(task.read_bytes()).hexdigest() == item["task_statement"]["sha256"]
        assert item["task_statement"]["output_model_patch_matches_copied_patch"]
    with (HERE / "diagnoses.csv").open(encoding="utf-8-sig", newline="") as stream:
        exported = list(csv.DictReader(stream))
    assert len(exported) == 72
    for source, target in zip(rows, exported):
        assert target == {key: str(source[key]) for key in target}
        for path in source["evidence_files"].values():
            for name in path if isinstance(path, list) else [path]:
                assert (RECORDS / name).is_file(), name
    recovery = {r["order"] for r in rows if r["recovery_status"] == "execution_supported"}
    execution = {r["order"] for r in rows if r["terminal_status"] == "execution_supported"}
    strict = {r["order"] for r in rows if r["terminal_status"] == "execution_supported"
              and r["terminal_scope"] == "undisputed"}
    diagnosed = {r["order"] for r in rows if r["terminal_status"] in
                 {"execution_supported", "source_supported"}}
    for key, terminal in [("strict_execution_undisputed", strict),
                          ("execution_all_scopes", execution),
                          ("diagnostic_extension_including_source_support", diagnosed)]:
        actual = summary[key]
        assert actual["terminal_run_ids"] == sorted(terminal)
        assert actual["recovery_run_ids"] == sorted(recovery)
        assert actual["overlap_run_ids"] == sorted(terminal & recovery)
        assert actual["ever_observed_run_ids"] == sorted(terminal | recovery)
        for field, count in [("terminal", len(terminal)), ("recovery", len(recovery)),
                             ("ever_observed", len(terminal | recovery))]:
            assert actual[field + "_runs"] == count
            assert math.isclose(actual[field + "_rate"], count / 72)
    for row in rows:
        n = row["order"]
        assert row["strict_terminal"] == (n in strict)
        assert row["strict_recovery"] == (n in recovery)
        assert row["strict_ever_observed"] == (n in strict | recovery)
    print(f"PASS: 72 archived baselines; strict terminal={len(strict)}, "
          f"recovery={len(recovery)}, overlap={len(strict & recovery)}, "
          f"ever={len(strict | recovery)} ({len(strict | recovery) / 72:.1%}).")


if __name__ == "__main__":
    main()
