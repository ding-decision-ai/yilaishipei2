# Codex 72条基线：修改诱导依赖失配审计

日期：2026-11-11。模型：Codex CLI / GPT-5.6 Sol / high。固定分母为72条正式基线，每题一条，含8条原评测通过和64条未全过运行。原始回复、任务正文、最终补丁、评分及逐测试日志均已复制到records/。

## 主要结果

按“执行支持且任务范围无争议”的口径，12/72条运行曾观察到修改诱导依赖失配，比例为16.7%。其中11条含恢复事件，2条有终态遗漏，1条同时具有两种状态：2+11−1=12。

| 口径 | 终态遗漏 | 含恢复事件 | 两者共存 | 曾观察到失配（并集） |
|---|---:|---:|---:|---:|
| 执行支持且范围无争议（主要口径） | 2/72（2.8%） | 11/72（15.3%） | 1 | 12/72（16.7%） |
| 全部执行支持，另含范围争议 | 3/72（4.2%） | 11/72（15.3%） | 1 | 13/72（18.1%） |
| 诊断扩展口径，再含一条源码支持终态 | 4/72（5.6%） | 11/72（15.3%） | 1 | 14/72（19.4%） |

范围争议项058：代码用窄协议grouper替代既有协议，实际破坏旧mean路径；但题面明确排除general aggregation，因此不进主要口径。源码支持项012：entry-point裸模块名与旧module://解析协议冲突，下游真实导入未在档案中执行，不标为执行支持。

以上为本次AI辅助档案审计识别的比例，尚未作为新增人工盲审或专家确认结果。未识别事件不等于证明没有缺陷；没有把64条任务评测未通过直接当成64条失配。

## 判据与复核

每项诊断需要实际修改、由此产生的适配义务、补丁前已有的独立消费者、具体错误之间的证据链。普通新增函数局部算法/参数/格式错误、任务裁剪已经删除的依赖未恢复、环境问题及正常连续编辑的编译中间态均单列排除。

恢复要求同一条基线内出现消费者行为失败、修补和对应验证。终态要求同一缺口仍绑定最终补丁；ORTG后续修补不作为基线恢复。主要正例及分类边界由不同审阅agent交叉复核，root裁定；逐题首轮记录与交叉复核记录保存在audit/下。

## 已纳入诊断的运行

| 序号 | 状态及证据 | 具体消费关系 | 原始回复 |
|---|---|---|---|
| 010 | 恢复／执行支持 | StructuredUnit新运算与旧UnitBase左乘派发；基线内恢复。 | [查看](records/010-astropy__astropy.b0db0daa.test_quantity_erfa_ufuncs.3fc54395.lv1/model_response.md) |
| 012 | 终态／源码支持 | entry-point存裸模块名，旧解析器要求module://；源码支持终态。 | [查看](records/012-matplotlib__matplotlib.86a476d2.test_backend_registry.872ba384.lv1/model_response.md) |
| 034 | 恢复／执行支持 | 通用RGB映射扩为RGBA，旧resolve_color误作显式alpha；恢复。 | [查看](records/034-mwaskom__seaborn.7001ebe7.test_scales.d9dcdef6.lv1/model_response.md) |
| 037 | 终态／执行支持 | 新ASCII parser异常/大小写协议与旧格式比较和猜测不兼容；终态。 | [查看](records/037-astropy__astropy.b0db0daa.test_compressed.8daeb7d6.lv1/model_response.md) |
| 038 | 恢复／执行支持 | 同类ASCII异常/格式猜测消费者适配；恢复。 | [查看](records/038-astropy__astropy.b0db0daa.test_compression_failures.48dc420b.lv1/model_response.md) |
| 039 | 终态／执行支持；恢复／执行支持 | 动态Distribution MRO与旧Quantity构造协议不兼容；终态；另恢复padded dtype旧setter。 | [查看](records/039-astropy__astropy.b0db0daa.test_containers.6079987d.lv1/model_response.md) |
| 040 | 恢复／执行支持 | 动态Distribution构造协议和padded dtype旧setter；两类缺口均恢复。 | [查看](records/040-astropy__astropy.b0db0daa.test_functions.40530bf7.lv1/model_response.md) |
| 044 | 恢复／执行支持 | PathLike新文件入口与旧writeto资源关闭判断；恢复。 | [查看](records/044-astropy__astropy.b0db0daa.test_tilde_path.383d7c0c.lv1/model_response.md) |
| 045 | 恢复／执行支持 | lazy reader定位状态与旧HDU替换；恢复。 | [查看](records/045-astropy__astropy.b0db0daa.test_tiled_compression.a4fe298a.lv1/model_response.md) |
| 056 | 恢复／执行支持 | BaseGrouper新增dropna假设与旧BinGrouper继承使用；恢复。 | [查看](records/056-pandas-dev__pandas.82fa2715.test_describe.3b919815.lv1/model_response.md) |
| 058 | 终态／执行支持／范围争议 | fake grouper缺旧mean所需_cython_operation；终态，任务范围争议。 | [查看](records/058-pandas-dev__pandas.82fa2715.test_groupby_shift_diff.e13d5358.lv1/model_response.md) |
| 065 | 恢复／执行支持 | 只读categorical codes与旧DLPack buffer导出；恢复。 | [查看](records/065-pandas-dev__pandas.82fa2715.test_spec_conformance.3aff206b.lv1/model_response.md) |
| 067 | 恢复／执行支持 | 新env配置上下文未进入旧依赖格式化consumer；恢复。 | [查看](records/067-pypa__hatch.ff4b4040.test_fmt.782c88a8.lv1/model_response.md) |
| 069 | 恢复／执行支持 | 新顶部import与旧模块初始化回边形成运行时导入循环；恢复。 | [查看](records/069-pytest-dev__pytest.68016f0e.raises_group.c28bf36a.lv1/model_response.md) |

## 未混入主要计数的候选

002为新方法调用renderer API与既有上下文边界；009为新增私有metadata输出约定的分类边界；020未观测到可归因的序列化失败；033为构造后修改lowess标志与新函数自身校验边界；035为新类型转换/helper自身契约与旧消费者适配的边界；045 PLIO终态缺少完整因果栈；047字段遍历顺序未建立精确旧生产consumer因果；058额外import修正处于编辑暂态边界；063是新恢复helper未满足原有condition参数契约。均保留记录，不自动升级为确诊。

## 使用范围

这72题预先选自原Qwen未通过任务（32正常提交未解决、40超时未通过），不是FeatureBench全体任务的随机样本。该比例描述Codex在这批固定任务中的观测结果，不直接估计一般Codex失配概率，也不用于与DeepSWE比例作模型排名。

此前另行核查的sklearn public_functions与xarray treenode两条Codex恢复案例不在本72题内，没有加入本次分子。

## 数据与复算

- [72条逐运行标签（CSV）](audit/diagnoses.csv)
- [完整标签及材料路径（JSONL）](audit/diagnoses.jsonl)
- [汇总与逐项成员（JSON）](audit/summary.json)
- [72条原始模型回复索引](INDEX.md)

所有比例按运行去重；一条运行多个事件不重复计入，终态和恢复可共存。运行下列命令复核标签集合、汇总及所指材料：

```sh
python3 audit/verify.py
```
